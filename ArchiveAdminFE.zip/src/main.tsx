import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { AuthProvider, QueryProvider } from "@/app/providers";
import { App } from "@/app/App";
import { ToastProvider } from "@/components/ui";
import { initNewRelic } from "@/lib/newRelic";
import "@/styles/index.css";

initNewRelic();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <QueryProvider>
      <BrowserRouter>
        <AuthProvider>
          <ToastProvider>
            <App />
          </ToastProvider>
        </AuthProvider>
      </BrowserRouter>
    </QueryProvider>
  </StrictMode>,
);
