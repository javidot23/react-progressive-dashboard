import { Outlet } from "react-router-dom";
// import { Footer } from "@/components/atoms";
import { Header } from "@/components/organisms/Header";

export function AdminLayout() {
  return (
    <div className="flex min-h-screen flex-col bg-white">
      <Header />
      <main className="mx-auto w-full max-w-(--breakpoint-2xl) flex-1 px-4 py-6 sm:px-6 lg:px-8">
        <Outlet />
      </main>
      {/* <Footer /> */}
    </div>
  );
}
