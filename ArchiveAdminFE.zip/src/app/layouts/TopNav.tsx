import { CircleUserRound, LogOut, Menu } from "lucide-react";
import { useAuth } from "@/app/providers";
import { useProfile } from "@/hooks/useProfile";
import { getUserEmail, getUserFullName } from "@/lib/profileHelpers";
import { useUiStore } from "@/stores";
import { Button } from "@/components/ui";

interface TopNavProps {
  title?: string;
}

export function TopNav({ title = "Admin Console" }: TopNavProps) {
  const toggleMobileSidebar = useUiStore((state) => state.toggleMobileSidebar);
  const { logout } = useAuth();
  const { profile } = useProfile();

  const displayName = getUserFullName(profile);
  const email = getUserEmail(profile);

  return (
    <header className="sticky top-0 z-50 h-[75px] md:h-[83px] border-b border-[#E2E8F0] bg-white">
      <div className="mx-auto flex h-full w-full max-w-(--breakpoint-2xl) items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Left */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            className="lg:hidden rounded-lg hover:bg-gray-100"
            onClick={toggleMobileSidebar}
            aria-label="Toggle sidebar"
          >
            <Menu className="h-5 w-5 text-[#525252]" />
          </Button>

          <h1 className="text-lg font-semibold text-[#1E293B]">{title}</h1>
        </div>

        {/* Right */}
        <div className="flex items-center gap-4">
          {/* User Info */}
          <div className="hidden text-right md:block">
            <p className="truncate text-sm font-semibold text-[#1E293B]" title={displayName || email || undefined}>
              {displayName || "User"}
            </p>

            {email && (
              <p className="truncate text-xs text-[#64748B]" title={email}>
                {email}
              </p>
            )}
          </div>

          {/* Avatar */}
          {profile?.photoDataUrl ? (
            <img src={profile.photoDataUrl} alt="Profile" className="h-10 w-10 rounded-full object-cover ring-1 ring-gray-200" />
          ) : (
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#F3F0FF]">
              <CircleUserRound className="h-6 w-6 text-[#461E96]" />
            </div>
          )}

          {/* Logout */}
          <Button
            variant="ghost"
            onClick={() => void logout()}
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-[#525252] hover:bg-gray-100 hover:text-[#461E96]"
          >
            <LogOut className="h-5 w-5" />
            <span className="hidden lg:inline font-medium">Sign out</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
