import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { getApiErrorMessage } from "@/lib/apiError";
import { getEndSessionUrl, redirectToLogin, type LogoutResponse } from "@/lib/authUrls";
import { clearNewRelicUser, setNewRelicUser } from "@/lib/newRelicUser";
import { extractAuthMeUserPayload, mapApiResponseToProfile } from "@/hooks/useProfile";
import { queryClient } from "./queryClient";
import {
  apiClient,
  DOMAIN_NOT_ALLOWED_CODE,
  DomainNotAllowedError,
  EMAIL_NOT_ALLOWED_CODE,
  EmailNotAllowedError,
  onAuthFailure,
  resetAuthRedirectSuppression,
  suppressAuthRedirects,
} from "@/services/http";

export interface User {
  entra_id: string;
  email: string;
  first_name: string;
  last_name: string;
  is_active: boolean;
  date_joined?: string;
  last_login?: string;
}

interface AppAuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  isLoading: boolean;
  error: string | null;
  login: () => void;
  logout: () => Promise<void>;
  checkAuthStatus: () => Promise<void>;
}

type SessionProbeResult =
  { status: "authenticated"; user: User } | { status: "unauthenticated" } | { status: "error"; message: string };

const AppAuthContext = createContext<AppAuthContextType | undefined>(undefined);

export function useAuth(): AppAuthContextType {
  const context = useContext(AppAuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

function resolveProbeErrorMessage(err: unknown): string {
  const responseCode =
    err && typeof err === "object" && (err as { response?: { data?: { code?: string } } }).response?.data?.code;
  const errCode =
    err instanceof DomainNotAllowedError
      ? DOMAIN_NOT_ALLOWED_CODE
      : err instanceof EmailNotAllowedError
        ? EMAIL_NOT_ALLOWED_CODE
        : (err && typeof err === "object" && (err as { code?: string }).code) || responseCode;

  if (errCode === DOMAIN_NOT_ALLOWED_CODE) {
    return "Your domain is not allowed to access this application. Please contact your administrator.";
  }
  if (errCode === EMAIL_NOT_ALLOWED_CODE) {
    return "Your email is not allowed to access this application. Please contact your administrator.";
  }
  return err instanceof Error ? err.message : "Failed to fetch user information";
}

function SigningOutScreen({ error, onRetry, onDismiss }: { error: string | null; onRetry: () => void; onDismiss: () => void }) {
  if (!error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-white">
        <div
          className="size-16 animate-spin rounded-full border-2 border-brand-primary-main border-t-transparent"
          role="status"
          aria-label="Signing out"
        />
        <p className="text-sm text-ui-text-secondary">Signing you out…</p>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-white px-4">
      <div className="w-full max-w-md rounded-lg border border-ui-border-secondary p-6 text-center">
        <h1 className="text-lg font-semibold text-ui-text-heading">Sign out failed</h1>
        <p className="mt-2 text-sm text-ui-text-secondary">{error}</p>
        <p className="mt-2 text-sm text-ui-text-secondary">You are still signed in.</p>
        <div className="mt-5 flex items-center justify-center gap-3">
          <button
            type="button"
            onClick={onDismiss}
            className="rounded-md border border-ui-border-secondary px-4 py-2 text-sm font-medium text-ui-text-heading hover:bg-ui-background-muted"
          >
            Back to app
          </button>
          <button
            type="button"
            onClick={onRetry}
            className="rounded-md bg-brand-primary-main px-4 py-2 text-sm font-medium text-white hover:bg-brand-primary-dark"
          >
            Try again
          </button>
        </div>
      </div>
    </div>
  );
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [appUser, setAppUser] = useState<User | null>(null);
  const [appError, setAppError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSigningOut, setIsSigningOut] = useState(false);
  const [signOutError, setSignOutError] = useState<string | null>(null);

  const mapProfileToUser = useCallback((body: unknown): User => {
    const profile = mapApiResponseToProfile(body);
    const raw = extractAuthMeUserPayload(body);
    return {
      entra_id: profile.id,
      email: profile.mail || "",
      first_name: profile.givenName || "",
      last_name: profile.surname || "",
      is_active: raw.status ? raw.status === "active" : true,
      last_login: typeof raw.last_login === "string" ? raw.last_login : undefined,
      date_joined: typeof raw.created_at === "string" ? raw.created_at : undefined,
    };
  }, []);

  const probeSession = useCallback(async (): Promise<SessionProbeResult> => {
    try {
      const response = await apiClient.get("/auth/me/", {
        skipAuthRedirect: true,
      });
      if (response.data.success) {
        return {
          status: "authenticated",
          user: mapProfileToUser(response.data),
        };
      }
      return {
        status: "error",
        message: response.data.error || "Failed to get user information",
      };
    } catch (err: unknown) {
      if (err && typeof err === "object" && (err as { name?: string }).name === "AuthenticationError") {
        return { status: "unauthenticated" };
      }
      console.error("Failed to fetch user from backend:", err);
      return { status: "error", message: resolveProbeErrorMessage(err) };
    }
  }, [mapProfileToUser]);

  const applySessionResult = useCallback((result: SessionProbeResult) => {
    if (result.status === "authenticated") {
      setAppUser(result.user);
      setAppError(null);
      setNewRelicUser({
        id: result.user.entra_id,
        email: result.user.email,
        firstName: result.user.first_name,
        lastName: result.user.last_name,
      });
      return;
    }
    setAppUser(null);
    if (result.status === "error") {
      setAppError(result.message);
    } else {
      setAppError(null);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthFailure(() => {
      setAppUser(null);
      setAppError("Your session has expired. Please sign in again.");
      clearNewRelicUser();
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    let cancelled = false;
    const bootstrap = async () => {
      setIsLoading(true);
      const result = await probeSession();
      if (cancelled) return;
      applySessionResult(result);
      setIsLoading(false);
    };
    void bootstrap();
    return () => {
      cancelled = true;
    };
  }, [probeSession, applySessionResult]);

  const login = useCallback(() => {
    setAppError(null);
    redirectToLogin();
  }, []);

  const logout = useCallback(async () => {
    suppressAuthRedirects();
    setAppError(null);
    // Hold this screen until the browser leaves for the IdP: clearing the user first
    // would render the login page for a moment before the end-session redirect commits.
    setIsSigningOut(true);
    setSignOutError(null);
    try {
      await queryClient.cancelQueries();
      queryClient.clear();
      const response = await apiClient.post<LogoutResponse>("/logout/", undefined, {
        skipAuthRedirect: true,
      });
      const endSessionUrl = getEndSessionUrl(response.data);
      clearNewRelicUser();
      setAppUser(null);
      if (endSessionUrl) {
        window.location.assign(endSessionUrl);
      } else {
        window.location.assign("/login");
      }
    } catch (err: unknown) {
      // The server session survives a failed /logout/, so sending the user to /login
      // would only bounce them back in. Report it instead of faking a sign-out.
      console.error("Logout failed:", err);
      setSignOutError(getApiErrorMessage(err, "We could not end your session. Please try again."));
    }
  }, []);

  const dismissSignOutError = useCallback(() => {
    setIsSigningOut(false);
    setSignOutError(null);
    resetAuthRedirectSuppression();
  }, []);

  const checkAuthStatus = useCallback(async () => {
    setIsLoading(true);
    const result = await probeSession();
    applySessionResult(result);
    setIsLoading(false);
  }, [probeSession, applySessionResult]);

  const contextValue: AppAuthContextType = {
    isAuthenticated: !!appUser,
    user: appUser,
    isLoading,
    error: appError,
    login,
    logout,
    checkAuthStatus,
  };

  return (
    <AppAuthContext.Provider value={contextValue}>
      {isSigningOut ? (
        <SigningOutScreen error={signOutError} onRetry={() => void logout()} onDismiss={dismissSignOutError} />
      ) : (
        children
      )}
    </AppAuthContext.Provider>
  );
}
