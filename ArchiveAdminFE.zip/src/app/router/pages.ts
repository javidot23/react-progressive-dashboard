import { lazy } from "react";

export const LoginPage = lazy(() => import("@/pages/LoginPage").then((m) => ({ default: m.LoginPage })));

export const TenantsPage = lazy(() => import("@/pages/TenantsPage").then((m) => ({ default: m.TenantsPage })));

export const TenantDetailPage = lazy(() => import("@/pages/TenantDetailPage").then((m) => ({ default: m.TenantDetailPage })));

export const UsersPage = lazy(() => import("@/pages/UsersPage").then((m) => ({ default: m.UsersPage })));

export const AuditLogPage = lazy(() => import("@/pages/AuditLogPage").then((m) => ({ default: m.AuditLogPage })));

export const NotFoundPage = lazy(() => import("@/pages/NotFoundPage").then((m) => ({ default: m.NotFoundPage })));

export const ErrorPage = lazy(() => import("@/pages/ErrorPage").then((m) => ({ default: m.ErrorPage })));
