import { ErrorBoundary } from "@/components/common";
import { AppRoutes } from "@/routes";

export function App() {
  return (
    <ErrorBoundary>
      <AppRoutes />
    </ErrorBoundary>
  );
}

export default App;
