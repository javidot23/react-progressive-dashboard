import { useQuery } from "@tanstack/react-query";
import { auditApi, type AuditLogsListParams } from "@/services/api/audit";
import type { AuditEventTypeEnum } from "@/services/api/enums";
import { mapAuditLogApiToRow } from "./audit.data";

export const auditQueryKeys = {
  all: ["audit"] as const,
  list: (params: AuditLogsListParams) => [...auditQueryKeys.all, "list", params] as const,
};

export type AuditLogsQueryFilters = {
  tenant?: string;
  actorUser?: string;
  auditEventType?: AuditEventTypeEnum;
  eventTimestampAfter?: string;
  eventTimestampBefore?: string;
  limit?: number;
  offset?: number;
  ordering?: string;
};

function toListParams(filters: AuditLogsQueryFilters): AuditLogsListParams {
  const params: AuditLogsListParams = {
    limit: filters.limit ?? 50,
    offset: filters.offset ?? 0,
    ordering: filters.ordering ?? "-event_timestamp",
  };

  if (filters.tenant) params.tenant = filters.tenant;
  if (filters.actorUser) params.actor_user = filters.actorUser;
  if (filters.auditEventType) params.audit_event_type = filters.auditEventType;
  if (filters.eventTimestampAfter) params.event_timestamp_after = filters.eventTimestampAfter;
  if (filters.eventTimestampBefore) params.event_timestamp_before = filters.eventTimestampBefore;

  return params;
}

export function useAuditLogsQuery(filters: AuditLogsQueryFilters, enabled = true) {
  const params = toListParams(filters);

  return useQuery({
    queryKey: auditQueryKeys.list(params),
    enabled,
    queryFn: async ({ signal }) => {
      const { data } = await auditApi.list(params, signal);
      const page = data.data;

      return {
        count: page.count,
        next: page.next,
        previous: page.previous,
        logs: page.results.map(mapAuditLogApiToRow),
      };
    },
    placeholderData: (previous) => previous,
  });
}
