import { keepPreviousData, useInfiniteQuery } from "@tanstack/react-query";
import { auditApi, type AuditLogsListParams } from "@/services/api/audit";
import type { AuditEventTypeEnum } from "@/services/api/enums";
import { mapAuditLogApiToRow, type AuditLogRow } from "./audit.data";

export const DEFAULT_AUDIT_LOGS_PAGE_SIZE = 50;

export const auditQueryKeys = {
  all: ["audit"] as const,
  list: (params: Omit<AuditLogsListParams, "offset">) => [...auditQueryKeys.all, "list", params] as const,
};

export type AuditLogsQueryFilters = {
  tenant?: string;
  actorUser?: string;
  auditEventType?: AuditEventTypeEnum;
  eventTimestampAfter?: string;
  eventTimestampBefore?: string;
  limit?: number;
  ordering?: string;
};

export type AuditLogsPageResult = {
  count: number;
  next: string | null;
  previous: string | null;
  logs: AuditLogRow[];
};

function toListParams(filters: AuditLogsQueryFilters, offset: number): AuditLogsListParams {
  const params: AuditLogsListParams = {
    limit: filters.limit ?? DEFAULT_AUDIT_LOGS_PAGE_SIZE,
    offset,
    ordering: filters.ordering ?? "-event_timestamp",
  };

  if (filters.tenant) params.tenant = filters.tenant;
  if (filters.actorUser) params.actor_user = filters.actorUser;
  if (filters.auditEventType) params.audit_event_type = filters.auditEventType;
  if (filters.eventTimestampAfter) params.event_timestamp_after = filters.eventTimestampAfter;
  if (filters.eventTimestampBefore) params.event_timestamp_before = filters.eventTimestampBefore;

  return params;
}

function toQueryKeyParams(filters: AuditLogsQueryFilters): Omit<AuditLogsListParams, "offset"> {
  const { offset: _offset, ...params } = toListParams(filters, 0);
  return params;
}

export function flattenAuditLogsPages(data: { pages: AuditLogsPageResult[] } | undefined): AuditLogRow[] {
  return data?.pages.flatMap((page) => page.logs) ?? [];
}

export function getAuditLogsTotalCount(data: { pages: AuditLogsPageResult[] } | undefined): number {
  return data?.pages[0]?.count ?? 0;
}

export function useAuditLogsQuery(filters: AuditLogsQueryFilters, enabled = true) {
  const keyParams = toQueryKeyParams(filters);

  return useInfiniteQuery({
    queryKey: auditQueryKeys.list(keyParams),
    enabled,
    initialPageParam: 0,
    queryFn: async ({ pageParam, signal }) => {
      const params = { ...keyParams, offset: pageParam };
      const { data } = await auditApi.list(params, signal);
      const page = data.data;

      return {
        count: page.count,
        next: page.next,
        previous: page.previous,
        logs: page.results.map(mapAuditLogApiToRow),
      } satisfies AuditLogsPageResult;
    },
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage.next) return undefined;
      return allPages.reduce((sum, page) => sum + page.logs.length, 0);
    },
    placeholderData: keepPreviousData,
  });
}
