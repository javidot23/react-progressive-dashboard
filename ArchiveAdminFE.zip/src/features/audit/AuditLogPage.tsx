import { useDocumentTitle } from "@/hooks";

export function AuditLogPage() {
  useDocumentTitle("Audit Log");

  return (
    <div>
      <h1 className="text-3xl font-bold tracking-tight text-ui-text-heading">Audit Log</h1>
      <p className="mt-1 text-sm text-ui-text-secondary">Audit activity will appear here.</p>
    </div>
  );
}
