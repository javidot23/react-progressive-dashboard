import type { AuditEventTypeEnum } from "@/services/api/enums";
import type { AuditLogApi } from "@/services/api/audit";

export type AuditLogRow = {
  id: string;
  actionId: string;
  timestamp: string;
  eventTime: string;
  actor: string;
  source: string;
  ipAddress: string;
  eventType: AuditEventTypeEnum;
};

const SOURCE_LABELS: Record<string, string> = {
  admin_portal: "Admin Portal",
  stratium_api: "Stratium API",
};

function formatTimestampDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function formatEventTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
  });
}

function formatSource(source: string | null): string {
  if (!source?.trim()) return "—";
  return SOURCE_LABELS[source] ?? source;
}

export function mapAuditLogApiToRow(log: AuditLogApi): AuditLogRow {
  const actor =
    log.actor_user?.display_name?.trim() ||
    [log.actor_user?.first_name, log.actor_user?.last_name].filter(Boolean).join(" ").trim() ||
    log.actor_user?.email ||
    "—";

  return {
    id: log.audit_log_uuid,
    actionId: log.audit_log_uuid,
    timestamp: formatTimestampDate(log.event_timestamp),
    eventTime: formatEventTime(log.event_timestamp),
    actor,
    source: formatSource(log.source),
    ipAddress: log.source_ip?.trim() || "—",
    eventType: log.audit_event_type,
  };
}
