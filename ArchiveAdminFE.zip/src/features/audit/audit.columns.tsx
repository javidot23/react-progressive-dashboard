import { createColumnHelper } from "@/components/organisms/DataGrid";
import type { AuditLogRow } from "./audit.data";

const columnHelper = createColumnHelper<AuditLogRow>();

export function createAuditLogColumns() {
  return [
    columnHelper.accessor("actionId", {
      header: "Action ID",
      cell: (info) => <span className="font-medium text-ui-text-heading">{info.getValue()}</span>,
      meta: { minWidth: 220 },
    }),
    columnHelper.accessor("timestamp", {
      header: "Timestamp",
      cell: (info) => info.getValue(),
      meta: { minWidth: 120 },
    }),
    columnHelper.accessor("eventTime", {
      header: "Event Time",
      cell: (info) => info.getValue(),
      meta: { minWidth: 110 },
    }),
    columnHelper.accessor("actor", {
      header: "Actor",
      cell: (info) => info.getValue(),
      meta: { minWidth: 140 },
    }),
    columnHelper.accessor("source", {
      header: "Source",
      cell: (info) => info.getValue(),
      meta: { minWidth: 120 },
    }),
    columnHelper.accessor("ipAddress", {
      header: "IP address",
      cell: (info) => info.getValue(),
      meta: { minWidth: 120 },
    }),
  ];
}
