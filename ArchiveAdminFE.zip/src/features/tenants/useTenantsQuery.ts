import { keepPreviousData, useInfiniteQuery } from "@tanstack/react-query";
import type { EntitlementTierEnum, TenantTypeEnum } from "@/services/api/enums";
import { tenantsApi, type TenantsListParams } from "@/services/api/tenants";
import { mapTenantApiToRow, type Tenant } from "./tenants.data";

export const DEFAULT_TENANTS_PAGE_SIZE = 50;

export const tenantsQueryKeys = {
  all: ["tenants"] as const,
  list: (params: Omit<TenantsListParams, "offset">) => [...tenantsQueryKeys.all, "list", params] as const,
};

export type TenantsQueryFilters = {
  search: string;
  tenantType: "all" | TenantTypeEnum;
  entitlement: "all" | EntitlementTierEnum;
  status: "all" | "active" | "inactive";
  limit?: number;
};

export type TenantsPageResult = {
  count: number;
  next: string | null;
  previous: string | null;
  tenants: Tenant[];
};

function toListParams(filters: TenantsQueryFilters, offset: number): TenantsListParams {
  const params: TenantsListParams = {
    limit: filters.limit ?? DEFAULT_TENANTS_PAGE_SIZE,
    offset,
    ordering: "tenant_name",
  };

  const search = filters.search.trim();
  if (search) params.search = search;
  if (filters.tenantType !== "all") params.tenant_type = filters.tenantType;
  if (filters.entitlement !== "all") params.entitlement_tier = filters.entitlement;
  if (filters.status === "active") params.is_active = true;
  if (filters.status === "inactive") params.is_active = false;

  return params;
}

function toQueryKeyParams(filters: TenantsQueryFilters): Omit<TenantsListParams, "offset"> {
  const { offset: _offset, ...params } = toListParams(filters, 0);
  return params;
}

export function flattenTenantsPages(data: { pages: TenantsPageResult[] } | undefined): Tenant[] {
  return data?.pages.flatMap((page) => page.tenants) ?? [];
}

export function getTenantsTotalCount(data: { pages: TenantsPageResult[] } | undefined): number {
  return data?.pages[0]?.count ?? 0;
}

export function useTenantsQuery(filters: TenantsQueryFilters, enabled = true) {
  const keyParams = toQueryKeyParams(filters);

  return useInfiniteQuery({
    queryKey: tenantsQueryKeys.list(keyParams),
    enabled,
    initialPageParam: 0,
    queryFn: async ({ pageParam, signal }) => {
      const params = { ...keyParams, offset: pageParam };
      const { data } = await tenantsApi.list(params, signal);
      const page = data.data;

      return {
        count: page.count,
        next: page.next,
        previous: page.previous,
        tenants: page.results.map(mapTenantApiToRow),
      } satisfies TenantsPageResult;
    },
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage.next) return undefined;
      return allPages.reduce((sum, page) => sum + page.tenants.length, 0);
    },
    placeholderData: keepPreviousData,
  });
}
