import { useQuery } from "@tanstack/react-query";
import type { EntitlementTierEnum, TenantTypeEnum } from "@/services/api/enums";
import { tenantsApi, type TenantsListParams } from "@/services/api/tenants";
import { mapTenantApiToRow } from "./tenants.data";

export const tenantsQueryKeys = {
  all: ["tenants"] as const,
  list: (params: TenantsListParams) => [...tenantsQueryKeys.all, "list", params] as const,
};

export type TenantsQueryFilters = {
  search: string;
  tenantType: "all" | TenantTypeEnum;
  entitlement: "all" | EntitlementTierEnum;
  status: "all" | "active" | "inactive";
  limit?: number;
  offset?: number;
};

function toListParams(filters: TenantsQueryFilters): TenantsListParams {
  const params: TenantsListParams = {
    limit: filters.limit ?? 50,
    offset: filters.offset ?? 0,
    ordering: "tenant_name",
  };

  const search = filters.search.trim();
  if (search) params.search = search;
  if (filters.tenantType !== "all") params.tenant_type = filters.tenantType;
  if (filters.entitlement !== "all") params.entitlement_tier = filters.entitlement;
  if (filters.status === "active") params.is_active = true;
  if (filters.status === "inactive") params.is_active = false;

  return params;
}

export function useTenantsQuery(filters: TenantsQueryFilters, enabled = true) {
  const params = toListParams(filters);

  return useQuery({
    queryKey: tenantsQueryKeys.list(params),
    enabled,
    queryFn: async ({ signal }) => {
      const { data } = await tenantsApi.list(params, signal);
      const page = data.data;

      return {
        count: page.count,
        next: page.next,
        previous: page.previous,
        tenants: page.results.map(mapTenantApiToRow),
      };
    },
    placeholderData: (previous) => previous,
  });
}
