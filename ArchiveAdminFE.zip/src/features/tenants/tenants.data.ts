import { ENTITLEMENT_TIER_LABELS, TENANT_TYPE_LABELS, type EntitlementTierEnum, type TenantTypeEnum } from "@/services/api/enums";
import type { TenantApi } from "@/services/api/tenants";

export type TenantStatus = "Active" | "Deactivated";
export type TenantTypeLabel = (typeof TENANT_TYPE_LABELS)[TenantTypeEnum];
export type TenantEntitlementLabel = (typeof ENTITLEMENT_TIER_LABELS)[EntitlementTierEnum];

export type Tenant = {
  id: string;
  name: string;
  tenantId: string;
  userCount: number | null;
  tenantType: TenantTypeLabel;
  entitlement: TenantEntitlementLabel;
  domain: string;
  extraDomains?: number;
  lastUpdated: string;
  status: TenantStatus;
};

function formatDomain(domain: string): string {
  const trimmed = domain.trim();
  if (!trimmed) return "—";
  return trimmed.startsWith("@") ? trimmed : `@${trimmed}`;
}

function formatLastUpdated(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function mapTenantApiToRow(tenant: TenantApi): Tenant {
  const [primaryDomain, ...rest] = tenant.domains ?? [];

  return {
    id: tenant.tenant_uuid,
    name: tenant.tenant_name,
    tenantId: tenant.tenant_code,
    userCount: typeof tenant.user_count === "number" ? tenant.user_count : null,
    tenantType: TENANT_TYPE_LABELS[tenant.tenant_type] ?? TENANT_TYPE_LABELS.customer,
    entitlement: ENTITLEMENT_TIER_LABELS[tenant.entitlement_tier] ?? ENTITLEMENT_TIER_LABELS.standard,
    domain: primaryDomain ? formatDomain(primaryDomain.domain) : "—",
    extraDomains: rest.length > 0 ? rest.length : undefined,
    lastUpdated: formatLastUpdated(tenant.updated_at),
    status: tenant.is_active ? "Active" : "Deactivated",
  };
}
