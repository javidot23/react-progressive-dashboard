import type { EntitlementTierEnum, TenantTypeEnum } from "@/services/api/enums";
import { TenantFormModal } from "./TenantFormModal";
import { collectTenantDomains, tenantApiToFormValues, type AddTenantFormValues } from "./tenantForm";
import { useTenantDetailQuery } from "./useTenantDetailQuery";
import { useUpdateTenantMutation } from "./useTenantMutations";

export type EditTenantModalProps = {
  open: boolean;
  tenantUuid: string | null;
  onClose: () => void;
};

export function EditTenantModal({ open, tenantUuid, onClose }: EditTenantModalProps) {
  const { data: tenant, isLoading } = useTenantDetailQuery(open ? (tenantUuid ?? undefined) : undefined);
  const updateTenant = useUpdateTenantMutation(tenantUuid ?? "");
  const initialValues = tenant ? tenantApiToFormValues(tenant) : null;

  const handleSave = (values: AddTenantFormValues) => {
    if (!tenantUuid) return;

    const port = Number.parseInt(values.databasePort, 10);
    updateTenant.mutate(
      {
        tenant_code: values.tenantId.trim(),
        tenant_name: values.tenantName.trim(),
        tenant_type: values.tenantType as TenantTypeEnum,
        entitlement_tier: values.entitlementTier ? (values.entitlementTier as EntitlementTierEnum) : undefined,
        is_active: values.active === "active",
        is_federated: values.federated === "yes",
        database_host: values.databaseHost.trim() || undefined,
        database_name: values.databaseName.trim() || undefined,
        database_port: Number.isFinite(port) ? port : undefined,
        database_schema: values.databaseSchema.trim() || undefined,
        database_username: values.databaseUsername.trim() || undefined,
        domains: collectTenantDomains(values),
      },
      { onSuccess: () => onClose() },
    );
  };

  return (
    <TenantFormModal
      open={open}
      mode="edit"
      title="View Tenant Details"
      onClose={onClose}
      initialValues={initialValues}
      isLoading={isLoading}
      isSaving={updateTenant.isPending}
      onSave={handleSave}
    />
  );
}
