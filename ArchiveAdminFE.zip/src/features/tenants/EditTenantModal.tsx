import type { EntitlementTierEnum, TenantTypeEnum } from "@/services/api/enums";
import { getApiErrorMessage } from "@/lib/apiError";
import { TenantFormModal } from "./TenantFormModal";
import { collectTenantDomains, tenantApiToFormValues, type AddTenantFormValues } from "./tenantForm";
import { useTenantDetailQuery } from "./useTenantDetailQuery";
import { useUpdateTenantMutation } from "./useTenantMutations";

export type EditTenantModalProps = {
  open: boolean;
  tenantUuid: string | null;
  onClose: () => void;
};

export function EditTenantModal({ open, tenantUuid, onClose }: EditTenantModalProps) {
  const { data: tenant, isLoading, isError, error, refetch } = useTenantDetailQuery(open ? (tenantUuid ?? undefined) : undefined);
  const updateTenant = useUpdateTenantMutation(tenantUuid ?? "");
  const initialValues = tenant ? tenantApiToFormValues(tenant) : null;
  const loadErrorMessage = isError ? getApiErrorMessage(error, "Failed to load tenant details.") : undefined;

  const toNullableText = (value: string): string | null => {
    const normalized = value.trim();
    return normalized ? normalized : null;
  };

  const toNullablePort = (value: string): number | null => {
    const normalized = value.trim();
    if (!normalized) return null;
    const parsed = Number.parseInt(normalized, 10);
    return Number.isFinite(parsed) ? parsed : null;
  };

  const handleSave = (values: AddTenantFormValues) => {
    if (!tenantUuid) return;

    updateTenant.mutate(
      {
        tenant_code: values.tenantId.trim(),
        tenant_name: values.tenantName.trim(),
        tenant_type: values.tenantType as TenantTypeEnum,
        entitlement_tier: values.entitlementTier ? (values.entitlementTier as EntitlementTierEnum) : null,
        is_active: values.active === "active",
        is_federated: values.federated === "yes",
        database_host: toNullableText(values.databaseHost),
        database_name: toNullableText(values.databaseName),
        database_port: toNullablePort(values.databasePort),
        database_schema: toNullableText(values.databaseSchema),
        database_username: toNullableText(values.databaseUsername),
        domains: collectTenantDomains(values),
      },
      { onSuccess: () => onClose() },
    );
  };

  return (
    <TenantFormModal
      open={open}
      mode="edit"
      title="View Tenant Details"
      onClose={onClose}
      initialValues={initialValues}
      isLoading={isLoading}
      loadErrorMessage={loadErrorMessage}
      onRetryLoad={() => {
        void refetch();
      }}
      isSaving={updateTenant.isPending}
      onSave={handleSave}
    />
  );
}
