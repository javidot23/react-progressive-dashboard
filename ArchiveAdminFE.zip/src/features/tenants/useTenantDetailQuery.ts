import { useQuery } from "@tanstack/react-query";
import { tenantsApi } from "@/services/api/tenants";
import { tenantsQueryKeys } from "./useTenantsQuery";

export function useTenantDetailQuery(tenantUuid: string | undefined) {
  return useQuery({
    queryKey: [...tenantsQueryKeys.all, "detail", tenantUuid] as const,
    enabled: Boolean(tenantUuid),
    queryFn: async ({ signal }) => {
      const { data } = await tenantsApi.get(tenantUuid!, signal);
      return data.data;
    },
  });
}
