import { useEffect, useState } from "react";
import { Button } from "@/components/atoms";
import { DataGridShell, DataGridTable, useDataGrid } from "@/components/organisms/DataGrid";
import { PageHeader, SearchInput, Select } from "@/components/ui";
import { useDocumentTitle } from "@/hooks";
import type { EntitlementTierApi, TenantTypeApi } from "@/services/api/tenants";
import { AddTenantModal } from "./AddTenantModal";
import { tenantColumns } from "./tenants.columns";
import { useTenantsQuery } from "./useTenantsQuery";

export function TenantsPage() {
  useDocumentTitle("Tenants");

  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | TenantTypeApi>("all");
  const [entitlementFilter, setEntitlementFilter] = useState<"all" | EntitlementTierApi>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all");
  const [isAddTenantOpen, setIsAddTenantOpen] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => setSearch(searchInput), 300);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const { data, isLoading, isFetching, isError, refetch } = useTenantsQuery({
    search,
    tenantType: typeFilter,
    entitlement: entitlementFilter,
    status: statusFilter,
  });

  const tenants = data?.tenants ?? [];
  const organizationCount = data?.count ?? 0;

  const { table } = useDataGrid({
    data: tenants,
    columns: tenantColumns,
    getRowId: (row) => row.id,
    enableSorting: false,
  });

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Tenants"
        description={isLoading ? "Loading organizations…" : `${organizationCount} Organizations`}
        actions={
          <>
            <Button type="button" className="h-8" onClick={() => setIsAddTenantOpen(true)}>
              Add Tenant
            </Button>
            <Button type="button" variant="outline" className="h-8">
              Add Multi Tenant User
            </Button>
          </>
        }
      />

      <div className="flex w-full flex-row items-center gap-3">
        <form
          className="min-w-0 flex-1"
          onSubmit={(event) => {
            event.preventDefault();
            setSearch(searchInput.trim());
          }}
          role="search"
        >
          <label htmlFor="tenant-search" className="sr-only">
            Search Tenants
          </label>
          <SearchInput
            id="tenant-search"
            value={searchInput}
            onChange={(event) => setSearchInput(event.target.value)}
            placeholder="Search Tenants"
            aria-label="Search tenants"
          />
        </form>

        <Select
          id="tenant-type-filter"
          aria-label="Tenant type"
          containerClassName="min-w-0 flex-1"
          value={typeFilter}
          onChange={(event) => setTypeFilter(event.target.value as "all" | TenantTypeApi)}
          options={[
            { value: "all", label: "All Types" },
            { value: "customer", label: "Customer" },
            { value: "vendor", label: "Vendor" },
            { value: "customer_vendor", label: "Customer/Vendor" },
          ]}
        />
        <Select
          id="tenant-entitlement-filter"
          aria-label="Entitlement"
          containerClassName="min-w-0 flex-1"
          value={entitlementFilter}
          onChange={(event) => setEntitlementFilter(event.target.value as "all" | EntitlementTierApi)}
          options={[
            { value: "all", label: "All Entitlements" },
            { value: "standard", label: "Standard" },
            { value: "premium", label: "Premium" },
            { value: "platinum", label: "Platinum" },
          ]}
        />
        <Select
          id="tenant-status-filter"
          aria-label="Status"
          containerClassName="min-w-0 flex-1"
          value={statusFilter}
          onChange={(event) => setStatusFilter(event.target.value as "all" | "active" | "inactive")}
          options={[
            { value: "all", label: "All Status" },
            { value: "active", label: "Active" },
            { value: "inactive", label: "Deactivated" },
          ]}
        />
      </div>

      <DataGridShell table={table} size="sm" variant="plain" className="rounded-lg bg-white">
        <DataGridTable
          table={table}
          emptyMessage="No tenants match your filters."
          minWidth={980}
          isLoading={isLoading}
          isUpdating={isFetching && !isLoading}
          isError={isError}
          onRetry={() => void refetch()}
        />
      </DataGridShell>

      <AddTenantModal open={isAddTenantOpen} onClose={() => setIsAddTenantOpen(false)} />
    </div>
  );
}
