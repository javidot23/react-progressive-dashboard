import { Link, useNavigate } from "react-router-dom";
import { MoreVertical } from "lucide-react";
import { createColumnHelper } from "@/components/organisms/DataGrid";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, StatusBadge } from "@/components/ui";
import { ROUTES } from "@/constants/routes";
import type { Tenant } from "./tenants.data";

const columnHelper = createColumnHelper<Tenant>();

export type TenantColumnsOptions = {
  onAddUser?: (tenant: Tenant) => void;
  onEdit?: (tenant: Tenant) => void;
  onDeactivate?: (tenant: Tenant) => void;
};

function TenantRowActions({
  tenant,
  onAddUser,
  onEdit,
  onDeactivate,
}: {
  tenant: Tenant;
  onAddUser?: (tenant: Tenant) => void;
  onEdit?: (tenant: Tenant) => void;
  onDeactivate?: (tenant: Tenant) => void;
}) {
  const navigate = useNavigate();
  const canDeactivate = tenant.status === "Active";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        showChevron={false}
        aria-label={`Actions for ${tenant.name}`}
        className="inline-flex size-8 items-center justify-center rounded-full border-0 bg-transparent p-0 text-ui-text-heading hover:bg-transparent"
      >
        <MoreVertical className="size-5" strokeWidth={2} aria-hidden />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[11rem]">
        <DropdownMenuItem onClick={() => navigate(ROUTES.tenantDetail(tenant.id))}>View Details</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onAddUser?.(tenant)}>Add user</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onEdit?.(tenant)}>Edit Tenant</DropdownMenuItem>
        {canDeactivate ? (
          <DropdownMenuItem destructive onClick={() => onDeactivate?.(tenant)}>
            Deactivate
          </DropdownMenuItem>
        ) : null}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function createTenantColumns({ onAddUser, onEdit, onDeactivate }: TenantColumnsOptions = {}) {
  return [
    columnHelper.accessor("name", {
      header: "Tenant",
      cell: (info) => (
        <Link
          to={ROUTES.tenantDetail(info.row.original.id)}
          className="font-medium text-ui-text-heading hover:text-brand-primary-main hover:underline"
        >
          {info.getValue()}
        </Link>
      ),
      meta: { minWidth: 120 },
    }),
    columnHelper.accessor("tenantId", {
      header: "Tenant ID",
      cell: (info) => info.getValue(),
      meta: { minWidth: 100 },
    }),
    columnHelper.accessor("userCount", {
      header: "User Count",
      cell: (info) => {
        const value = info.getValue();
        return value == null ? "—" : value;
      },
      meta: { minWidth: 100 },
    }),
    columnHelper.accessor("tenantType", {
      header: "Tenant Type",
      cell: (info) => info.getValue(),
      meta: { minWidth: 130 },
    }),
    columnHelper.accessor("entitlement", {
      header: "Entitlement",
      cell: (info) => info.getValue(),
      meta: { minWidth: 110 },
    }),
    columnHelper.accessor("domain", {
      header: "Domains",
      cell: (info) => {
        const row = info.row.original;
        return (
          <span className="inline-flex items-center gap-1.5">
            <span>{row.domain}</span>
            {row.extraDomains ? <span className="text-xs font-medium text-ui-text-secondary">+{row.extraDomains}</span> : null}
          </span>
        );
      },
      meta: { minWidth: 140 },
    }),
    columnHelper.accessor("lastUpdated", {
      header: "Last updated",
      cell: (info) => info.getValue(),
      meta: { minWidth: 120 },
    }),
    columnHelper.accessor("status", {
      header: "Status",
      cell: (info) => <StatusBadge status={info.getValue()} />,
      meta: { minWidth: 110 },
    }),
    columnHelper.display({
      id: "actions",
      header: "",
      cell: ({ row }) => (
        <TenantRowActions tenant={row.original} onAddUser={onAddUser} onEdit={onEdit} onDeactivate={onDeactivate} />
      ),
      meta: { align: "center" as const, minWidth: 48, nowrap: true },
    }),
  ];
}

/** @deprecated Prefer createTenantColumns */
export const tenantColumns = createTenantColumns();
