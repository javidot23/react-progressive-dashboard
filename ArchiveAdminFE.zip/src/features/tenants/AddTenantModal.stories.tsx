import { useState, type ReactNode } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { fn } from "storybook/test";
import { Button } from "@/components/atoms";
import { ToastProvider } from "@/components/ui";
import { AddTenantModal } from "@/features/tenants/AddTenantModal";

function StoryProviders({ children }: { children: ReactNode }) {
  const [client] = useState(() => new QueryClient({ defaultOptions: { queries: { retry: false } } }));
  return (
    <QueryClientProvider client={client}>
      <ToastProvider>{children}</ToastProvider>
    </QueryClientProvider>
  );
}

const meta: Meta<typeof AddTenantModal> = {
  title: "Features/Tenants/AddTenantModal",
  component: AddTenantModal,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
  },
  decorators: [
    (Story) => (
      <StoryProviders>
        <Story />
      </StoryProviders>
    ),
  ],
  args: {
    open: true,
    onClose: fn(),
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const FromPageAction: Story = {
  args: {
    open: false,
  },
  render: function FromPageActionStory(args) {
    const [open, setOpen] = useState(false);

    return (
      <div className="flex min-h-screen items-start justify-end bg-white p-8">
        <Button type="button" className="h-8" onClick={() => setOpen(true)}>
          Add Tenant
        </Button>
        <AddTenantModal
          {...args}
          open={open}
          onClose={() => {
            setOpen(false);
            args.onClose?.();
          }}
        />
      </div>
    );
  },
};
