import { Button } from "@/components/atoms";
import { Modal } from "@/components/ui";
import { useDeactivateTenantMutation } from "./useTenantMutations";
import type { Tenant } from "./tenants.data";

export type DeactivateTenantModalProps = {
  open: boolean;
  tenant: Tenant | null;
  onClose: () => void;
};

export function DeactivateTenantModal({ open, tenant, onClose }: DeactivateTenantModalProps) {
  const deactivateTenant = useDeactivateTenantMutation();

  const handleConfirm = () => {
    if (!tenant) return;
    deactivateTenant.mutate(tenant, {
      onSuccess: () => onClose(),
    });
  };

  return (
    <Modal
      open={open}
      className="!rounded-[1px]"
      title={tenant ? `Deactivating '${tenant.name}'` : "Deactivating tenant"}
      titleClassName="font-semibold"
      footerClassName="bg-[#E8E8E8]"
      onClose={onClose}
      tone="danger"
      footer={
        <>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-8 font-bold text-brand-primary-main hover:bg-brand-primary-50"
            onClick={onClose}
            disabled={deactivateTenant.isPending}
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-8 border-status-error-main font-bold text-status-error-main bg-transparent hover:bg-status-error-light"
            onClick={handleConfirm}
            disabled={!tenant || deactivateTenant.isPending}
          >
            {deactivateTenant.isPending ? "Deactivating…" : "Deactivate"}
          </Button>
        </>
      }
    >
      <p className="font-body-sm text-[length:var(--text-body-sm)] leading-body-sm text-[#3B3B3B]">
        Deactivating this tenant will immediately revoke access for all tenant users. This action can be reversed later by
        reactivating the tenant.
      </p>
    </Modal>
  );
}
