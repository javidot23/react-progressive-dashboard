import { TenantFormModal } from "./TenantFormModal";
import type { AddTenantFormValues } from "./tenantForm";
import { useCreateTenantMutation } from "./useTenantMutations";

export type { AddTenantFormValues } from "./tenantForm";

export type AddTenantModalProps = {
  open: boolean;
  onClose: () => void;
  onCreated?: () => void;
};

export function AddTenantModal({ open, onClose, onCreated }: AddTenantModalProps) {
  const createTenant = useCreateTenantMutation();

  const handleSave = (values: AddTenantFormValues) => {
    createTenant.mutate(values, {
      onSuccess: () => {
        onCreated?.();
        onClose();
      },
    });
  };

  return (
    <TenantFormModal
      open={open}
      mode="create"
      title="Add Tenant"
      onClose={onClose}
      isSaving={createTenant.isPending}
      onSave={handleSave}
    />
  );
}
