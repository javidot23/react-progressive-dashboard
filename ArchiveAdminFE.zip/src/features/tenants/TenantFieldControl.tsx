import { FormField, Input, Select } from "@/components/ui";
import { cn } from "@/utils";
import { TENANT_FORM_DISABLED_FIELD_CLASS } from "./tenantForm";

const INVALID_FIELD_CLASS = "border-status-error-main focus-visible:ring-status-error-main";

export type TenantFieldControlProps = {
  id: string;
  label: string;
  value: string;
  required: boolean;
  disabled: boolean;
  error?: string;
  placeholder?: string;
  inputMode?: "numeric";
  options?: ReadonlyArray<{ value: string; label: string }>;
  onChange: (value: string) => void;
  onBlur: () => void;
};

export function TenantFieldControl({
  id,
  label,
  value,
  required,
  disabled,
  error,
  placeholder,
  inputMode,
  options,
  onChange,
  onBlur,
}: TenantFieldControlProps) {
  const className = cn(disabled ? TENANT_FORM_DISABLED_FIELD_CLASS : undefined, error ? INVALID_FIELD_CLASS : undefined);

  return (
    <FormField id={id} label={label} required={required} error={error}>
      {options ? (
        <Select
          id={id}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          onBlur={onBlur}
          options={options}
          placeholder={placeholder ?? "Select"}
          required={required}
          aria-invalid={Boolean(error)}
          disabled={disabled}
          className={className}
        />
      ) : (
        <Input
          id={id}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          onBlur={onBlur}
          placeholder={placeholder}
          inputMode={inputMode}
          required={required}
          aria-invalid={Boolean(error)}
          disabled={disabled}
          className={className}
        />
      )}
    </FormField>
  );
}
