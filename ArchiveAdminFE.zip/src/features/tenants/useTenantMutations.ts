import { useMutation, useQueryClient } from "@tanstack/react-query";
import { getApiErrorMessage } from "@/lib/apiError";
import type { EntitlementTierEnum, TenantTypeEnum } from "@/services/api/enums";
import { tenantsApi, type TenantWritePayload } from "@/services/api/tenants";
import { useToast } from "@/components/ui";
import { tenantsQueryKeys } from "./useTenantsQuery";
import { normalizeDomains } from "./useTenantDomainsQuery";
import { collectTenantDomains, normalizeTenantDomain, type AddTenantFormValues } from "./tenantForm";
import type { Tenant } from "./tenants.data";

function toWritePayload(values: AddTenantFormValues): TenantWritePayload {
  const port = Number.parseInt(values.databasePort, 10);

  return {
    tenant_code: values.tenantId.trim(),
    tenant_name: values.tenantName.trim(),
    tenant_type: values.tenantType as TenantTypeEnum,
    entitlement_tier: values.entitlementTier ? (values.entitlementTier as EntitlementTierEnum) : undefined,
    is_active: values.active ? values.active === "active" : undefined,
    is_federated: values.federated ? values.federated === "yes" : undefined,
    database_host: values.databaseHost.trim() || undefined,
    database_name: values.databaseName.trim() || undefined,
    database_port: Number.isFinite(port) ? port : undefined,
    database_schema: values.databaseSchema.trim() || undefined,
    database_username: values.databaseUsername.trim() || undefined,
  };
}

/** Domains live on their own endpoint, so a tenant write has to add/remove them separately. */
async function syncTenantDomains(tenantUuid: string, desired: string[]): Promise<void> {
  const { data } = await tenantsApi.listDomains(tenantUuid);
  const existing = new Map(normalizeDomains(data.data).map((entry) => [normalizeTenantDomain(entry.domain), entry]));
  const wanted = new Set(desired);

  await Promise.all([
    ...desired.filter((domain) => !existing.has(domain)).map((domain) => tenantsApi.addDomain(tenantUuid, domain)),
    ...[...existing]
      .filter(([domain]) => domain && !wanted.has(domain))
      .map(([, entry]) => tenantsApi.removeDomain(tenantUuid, entry.tenant_domain_uuid)),
  ]);
}

export function useCreateTenantMutation() {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async (values: AddTenantFormValues) => {
      const { data } = await tenantsApi.create(toWritePayload(values));
      const tenant = data.data;

      await syncTenantDomains(tenant.tenant_uuid, collectTenantDomains(values));

      // POST /tenants/ responds before its child domains exist. Refetch so
      // mutation consumers receive the completed tenant instead of domains: [].
      const { data: refreshed } = await tenantsApi.get(tenant.tenant_uuid);
      return refreshed.data;
    },
    onSuccess: (tenant) => {
      void queryClient.invalidateQueries({ queryKey: tenantsQueryKeys.all });
      success(`Tenant "${tenant.tenant_name}" has been added successfully`);
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to create tenant."));
    },
  });
}

export type UpdateTenantInput = Partial<TenantWritePayload> & {
  /** Full desired domain list; when present, domains are added/removed to match it. */
  domains?: string[];
};

export function useUpdateTenantMutation(tenantUuid: string) {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async ({ domains, ...payload }: UpdateTenantInput) => {
      const { data } = await tenantsApi.update(tenantUuid, payload);
      if (!domains) return data.data;

      await syncTenantDomains(tenantUuid, domains);

      const { data: refreshed } = await tenantsApi.get(tenantUuid);
      return refreshed.data;
    },
    onSuccess: (tenant) => {
      void queryClient.invalidateQueries({ queryKey: tenantsQueryKeys.all });
      void queryClient.invalidateQueries({ queryKey: ["tenants", "detail", tenantUuid] });
      success(`Changes to tenant "${tenant.tenant_name}" has been saved`);
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to update tenant."));
    },
  });
}

export function useDeactivateTenantMutation() {
  const queryClient = useQueryClient();
  const { toast, error } = useToast();

  return useMutation({
    mutationFn: async (tenant: Tenant) => {
      const { data } = await tenantsApi.update(tenant.id, { is_active: false });
      return { apiTenant: data.data, name: tenant.name };
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: tenantsQueryKeys.all });
      toast("Tenant has been deactivated", "warning");
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to deactivate tenant."));
    },
  });
}
