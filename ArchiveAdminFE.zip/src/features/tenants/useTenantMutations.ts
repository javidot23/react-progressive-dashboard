import { useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { getApiErrorMessage } from "@/lib/apiError";
import type { EntitlementTierEnum, TenantTypeEnum } from "@/services/api/enums";
import type { TenantDomain } from "@/services/api/tenants";
import { tenantsApi, type TenantWritePayload } from "@/services/api/tenants";
import { useToast } from "@/components/ui";
import { tenantsQueryKeys } from "./useTenantsQuery";
import { normalizeDomains } from "./useTenantDomainsQuery";
import { collectTenantDomains, normalizeTenantDomain, type AddTenantFormValues } from "./tenantForm";
import type { Tenant } from "./tenants.data";

function toWritePayload(values: AddTenantFormValues): TenantWritePayload {
  const port = Number.parseInt(values.databasePort, 10);

  return {
    tenant_code: values.tenantId.trim(),
    tenant_name: values.tenantName.trim(),
    tenant_type: values.tenantType as TenantTypeEnum,
    entitlement_tier: values.entitlementTier ? (values.entitlementTier as EntitlementTierEnum) : undefined,
    is_active: values.active ? values.active === "active" : undefined,
    is_federated: values.federated ? values.federated === "yes" : undefined,
    database_host: values.databaseHost.trim() || undefined,
    database_name: values.databaseName.trim() || undefined,
    database_port: Number.isFinite(port) ? port : undefined,
    database_schema: values.databaseSchema.trim() || undefined,
    database_username: values.databaseUsername.trim() || undefined,
  };
}

/** Domains live on their own endpoint, so a tenant write has to add/remove them separately. */
async function syncTenantDomains(tenantUuid: string, desired: string[]): Promise<void> {
  const listNormalizedDomains = async (): Promise<TenantDomain[]> => {
    const { data } = await tenantsApi.listDomains(tenantUuid);
    return normalizeDomains(data.data);
  };

  const addDomainIdempotent = async (domain: string): Promise<void> => {
    try {
      await tenantsApi.addDomain(tenantUuid, domain);
    } catch (err) {
      // Idempotent retry support: already exists.
      if (!axios.isAxiosError(err) || err.response?.status !== 409) throw err;
    }
  };

  const removeDomainIdempotent = async (domainUuid: string): Promise<void> => {
    try {
      await tenantsApi.removeDomain(tenantUuid, domainUuid);
    } catch (err) {
      // Idempotent retry support: already removed.
      if (!axios.isAxiosError(err) || err.response?.status !== 404) throw err;
    }
  };

  const existingDomains = await listNormalizedDomains();
  const existing = new Map(existingDomains.map((entry) => [normalizeTenantDomain(entry.domain), entry]));
  const wanted = new Set(desired);

  const currentPrimary = normalizeTenantDomain(existingDomains[0]?.domain ?? "");
  const desiredPrimary = desired[0] ?? "";

  // The API doesn't expose a primary marker/order mutation. Block unsupported promotion in edit.
  if (currentPrimary && desiredPrimary && currentPrimary !== desiredPrimary && wanted.has(currentPrimary)) {
    throw new Error("Changing the primary domain is not supported yet.");
  }

  const domainsToAdd = desired.filter((domain) => !existing.has(domain));
  for (const domain of domainsToAdd) {
    await addDomainIdempotent(domain);
  }

  if (domainsToAdd.length > 0) {
    const afterAdds = await listNormalizedDomains();
    const addedSet = new Set(afterAdds.map((entry) => normalizeTenantDomain(entry.domain)));
    const missingDomains = domainsToAdd.filter((domain) => !addedSet.has(domain));
    if (missingDomains.length > 0) {
      throw new Error(`Failed to add tenant domain(s): ${missingDomains.join(", ")}`);
    }
  }

  const domainsToRemove = [...existing]
    .filter(([domain]) => domain && !wanted.has(domain))
    .map(([, entry]) => entry.tenant_domain_uuid);

  for (const domainUuid of domainsToRemove) {
    await removeDomainIdempotent(domainUuid);
  }
}

export function useCreateTenantMutation() {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async (values: AddTenantFormValues) => {
      const { data } = await tenantsApi.create(toWritePayload(values));
      const tenant = data.data;

      try {
        await syncTenantDomains(tenant.tenant_uuid, collectTenantDomains(values));
      } catch (err) {
        // Compensate to avoid leaving an orphan tenant when child-domain creation fails.
        await tenantsApi.remove(tenant.tenant_uuid).catch(() => undefined);
        throw err;
      }

      // POST /tenants/ responds before its child domains exist. Refetch so
      // mutation consumers receive the completed tenant instead of domains: [].
      const { data: refreshed } = await tenantsApi.get(tenant.tenant_uuid);
      return refreshed.data;
    },
    onSuccess: (tenant) => {
      void queryClient.invalidateQueries({ queryKey: tenantsQueryKeys.all });
      success(`Tenant "${tenant.tenant_name}" has been added successfully`);
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to create tenant."));
    },
  });
}

export type UpdateTenantInput = Partial<TenantWritePayload> & {
  /** Full desired domain list; when present, domains are added/removed to match it. */
  domains?: string[];
};

export function useUpdateTenantMutation(tenantUuid: string) {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async ({ domains, ...payload }: UpdateTenantInput) => {
      const { data } = await tenantsApi.update(tenantUuid, payload);
      if (!domains) return data.data;

      await syncTenantDomains(tenantUuid, domains);

      const { data: refreshed } = await tenantsApi.get(tenantUuid);
      return refreshed.data;
    },
    onSuccess: (tenant) => {
      void queryClient.invalidateQueries({ queryKey: tenantsQueryKeys.all });
      void queryClient.invalidateQueries({ queryKey: ["tenants", "detail", tenantUuid] });
      success(`Changes to tenant "${tenant.tenant_name}" has been saved`);
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to update tenant."));
    },
  });
}

export function useDeactivateTenantMutation() {
  const queryClient = useQueryClient();
  const { toast, error } = useToast();

  return useMutation({
    mutationFn: async (tenant: Tenant) => {
      const { data } = await tenantsApi.update(tenant.id, { is_active: false });
      return { apiTenant: data.data, name: tenant.name };
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: tenantsQueryKeys.all });
      toast("Tenant has been deactivated", "warning");
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to deactivate tenant."));
    },
  });
}
