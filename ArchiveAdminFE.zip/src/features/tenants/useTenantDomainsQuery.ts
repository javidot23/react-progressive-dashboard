import { useQuery } from "@tanstack/react-query";
import { tenantsApi, type TenantDomain } from "@/services/api/tenants";
import { tenantsQueryKeys } from "./useTenantsQuery";

/** The API returns a single domain, a plain list, or a paginated envelope depending on tenant configuration. */
export function normalizeDomains(data: unknown): TenantDomain[] {
  const entries = Array.isArray(data)
    ? data
    : data && typeof data === "object" && Array.isArray((data as { results?: unknown }).results)
      ? ((data as { results: unknown[] }).results as TenantDomain[])
      : data
        ? [data as TenantDomain]
        : [];

  return entries.filter((entry): entry is TenantDomain => Boolean(entry) && typeof entry.domain === "string");
}

export function useTenantDomainsQuery(tenantUuid: string | undefined) {
  return useQuery({
    queryKey: [...tenantsQueryKeys.all, "domains", tenantUuid] as const,
    enabled: Boolean(tenantUuid),
    queryFn: async ({ signal }) => {
      const { data } = await tenantsApi.listDomains(tenantUuid!, signal);
      return normalizeDomains(data.data);
    },
  });
}
