import type { ReactNode } from "react";
import { Minus } from "lucide-react";
import { Button } from "@/components/atoms";
import { FormField, Input } from "@/components/ui";
import { cn } from "@/utils";
import { ENTITLEMENT_TIER_OPTIONS, TENANT_TYPE_OPTIONS } from "@/services/api/enums";
import { TenantFieldControl } from "./TenantFieldControl";
import {
  TENANT_ACTIVE_OPTIONS,
  TENANT_FEDERATED_OPTIONS,
  TENANT_FORM_DISABLED_FIELD_CLASS,
  TENANT_REQUIRED_FIELD_KEYS,
  type AddTenantFormValues,
  type TenantRequiredFieldKey,
} from "./tenantForm";

function FormSection({
  title,
  showRequiredLegend,
  children,
}: {
  title: string;
  showRequiredLegend?: boolean;
  children: ReactNode;
}) {
  return (
    <section className="rounded-lg border border-[#E8E8E8] bg-white p-4">
      <h3 className="mb-4 text-lg font-normal tracking-normal text-[#0F172A]">{title}</h3>
      <hr className="my-3" />
      {showRequiredLegend ? (
        <p className="mb-4 text-sm text-status-error-main">
          <span aria-hidden>*</span> Indicates a required field
        </p>
      ) : null}
      <div className="space-y-4">{children}</div>
    </section>
  );
}

export type TenantFormFieldsProps = {
  idPrefix: string;
  values: AddTenantFormValues;
  disabled: boolean;
  showRequiredIndicators?: boolean;
  showErrors?: boolean;
  touchedFields?: Partial<Record<TenantRequiredFieldKey, boolean>>;
  onBlurField?: (key: TenantRequiredFieldKey) => void;
  onChange: <K extends keyof AddTenantFormValues>(key: K, value: AddTenantFormValues[K]) => void;
};

function resolveRequiredError(
  values: AddTenantFormValues,
  key: TenantRequiredFieldKey,
  showErrors: boolean,
  touchedFields?: TenantFormFieldsProps["touchedFields"],
): string | undefined {
  if (!showErrors && !touchedFields?.[key]) return undefined;
  if (values[key].trim()) return undefined;
  return "This field is required";
}

export function TenantFormFields({
  idPrefix,
  values,
  disabled,
  showRequiredIndicators = false,
  showErrors = false,
  touchedFields,
  onBlurField,
  onChange,
}: TenantFormFieldsProps) {
  const showRequired = showRequiredIndicators && !disabled;
  const errorFor = (key: TenantRequiredFieldKey) => resolveRequiredError(values, key, showErrors, touchedFields);
  const isRequiredKey = (key: TenantRequiredFieldKey) => showRequired && TENANT_REQUIRED_FIELD_KEYS.includes(key);

  return (
    <div className="space-y-4">
      <FormSection title="Tenant Details" showRequiredLegend={showRequired}>
        <TenantFieldControl
          id={`${idPrefix}-tenant-id`}
          label="Tenant ID"
          value={values.tenantId}
          required={isRequiredKey("tenantId")}
          disabled={disabled}
          error={errorFor("tenantId")}
          placeholder="T-1234"
          onChange={(value) => onChange("tenantId", value)}
          onBlur={() => onBlurField?.("tenantId")}
        />
        <TenantFieldControl
          id={`${idPrefix}-tenant-name`}
          label="Tenant Name"
          value={values.tenantName}
          required={isRequiredKey("tenantName")}
          disabled={disabled}
          error={errorFor("tenantName")}
          placeholder="Corporation"
          onChange={(value) => onChange("tenantName", value)}
          onBlur={() => onBlurField?.("tenantName")}
        />
        <TenantFieldControl
          id={`${idPrefix}-tenant-type`}
          label="Tenant Type"
          value={values.tenantType}
          required={isRequiredKey("tenantType")}
          disabled={disabled}
          error={errorFor("tenantType")}
          options={TENANT_TYPE_OPTIONS}
          onChange={(value) => onChange("tenantType", value)}
          onBlur={() => onBlurField?.("tenantType")}
        />
        <TenantFieldControl
          id={`${idPrefix}-tenant-entitlement`}
          label="Entitlement Tier"
          value={values.entitlementTier}
          required={false}
          disabled={disabled}
          options={ENTITLEMENT_TIER_OPTIONS}
          onChange={(value) => onChange("entitlementTier", value)}
          onBlur={() => undefined}
        />
        <TenantFieldControl
          id={`${idPrefix}-tenant-active`}
          label="Active"
          value={values.active}
          required={false}
          disabled={disabled}
          options={[...TENANT_ACTIVE_OPTIONS]}
          onChange={(value) => onChange("active", value)}
          onBlur={() => undefined}
        />
        <TenantFieldControl
          id={`${idPrefix}-tenant-federated`}
          label="Federated?"
          value={values.federated}
          required={false}
          disabled={disabled}
          options={[...TENANT_FEDERATED_OPTIONS]}
          onChange={(value) => onChange("federated", value)}
          onBlur={() => undefined}
        />
      </FormSection>

      <FormSection title="Domains">
        <TenantFieldControl
          id={`${idPrefix}-primary-domain`}
          label="Primary Domain"
          value={values.primaryDomain}
          required={false}
          disabled={disabled}
          placeholder="example.com"
          onChange={(value) => onChange("primaryDomain", value)}
          onBlur={() => undefined}
        />
        {values.additionalDomains.map((domain, index) => {
          const className = disabled ? TENANT_FORM_DISABLED_FIELD_CLASS : undefined;

          return (
            <FormField
              key={`${idPrefix}-additional-domain-${index}`}
              id={`${idPrefix}-additional-domain-${index}`}
              label={`Additional Domain ${index + 1}`}
            >
              <div className="flex items-center gap-2">
                <Input
                  id={`${idPrefix}-additional-domain-${index}`}
                  value={domain}
                  onChange={(event) => {
                    const next = [...values.additionalDomains];
                    next[index] = event.target.value;
                    onChange("additionalDomains", next);
                  }}
                  placeholder="example.com"
                  disabled={disabled}
                  className={cn(className)}
                />
                {!disabled ? (
                  <button
                    type="button"
                    className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-ui-border-secondary text-ui-text-secondary hover:bg-ui-background-muted"
                    aria-label={`Remove additional domain ${index + 1}`}
                    onClick={() =>
                      onChange(
                        "additionalDomains",
                        values.additionalDomains.filter((_, i) => i !== index),
                      )
                    }
                  >
                    <Minus className="h-4 w-4" aria-hidden />
                  </button>
                ) : null}
              </div>
            </FormField>
          );
        })}
        {!disabled ? (
          <div className="flex justify-end">
            <Button
              type="button"
              size="sm"
              className="h-8 border-0 bg-[#E8E8E8] px-3 font-bold text-[#461E96] hover:bg-[#DDDBF7] hover:bg-brand-primary-200"
              onClick={() => onChange("additionalDomains", [...values.additionalDomains, ""])}
            >
              Add Additional Domain
            </Button>
          </div>
        ) : null}
      </FormSection>

      <FormSection title="Database Configuration">
        <TenantFieldControl
          id={`${idPrefix}-db-host`}
          label="Database Host"
          value={values.databaseHost}
          required={false}
          disabled={disabled}
          placeholder="Database Host"
          onChange={(value) => onChange("databaseHost", value)}
          onBlur={() => undefined}
        />
        <TenantFieldControl
          id={`${idPrefix}-db-name`}
          label="Database Name"
          value={values.databaseName}
          required={false}
          disabled={disabled}
          placeholder="Tenant Database Name"
          onChange={(value) => onChange("databaseName", value)}
          onBlur={() => undefined}
        />
        <TenantFieldControl
          id={`${idPrefix}-db-port`}
          label="Database Port"
          value={values.databasePort}
          required={false}
          disabled={disabled}
          placeholder="Database Port"
          inputMode="numeric"
          onChange={(value) => onChange("databasePort", value)}
          onBlur={() => undefined}
        />
        <TenantFieldControl
          id={`${idPrefix}-db-schema`}
          label="Database Schema"
          value={values.databaseSchema}
          required={false}
          disabled={disabled}
          placeholder="Database Schema"
          onChange={(value) => onChange("databaseSchema", value)}
          onBlur={() => undefined}
        />
        <TenantFieldControl
          id={`${idPrefix}-db-username`}
          label="Database Username"
          value={values.databaseUsername}
          required={false}
          disabled={disabled}
          placeholder="Database Username"
          onChange={(value) => onChange("databaseUsername", value)}
          onBlur={() => undefined}
        />
      </FormSection>
    </div>
  );
}
