import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Button } from "@/components/atoms";
import { Drawer } from "@/components/ui";
import { TenantFormFields } from "./TenantFormFields";
import {
  areTenantFormValuesEqual,
  createEmptyTenantFormValues,
  isTenantFormComplete,
  type AddTenantFormValues,
  type TenantFormStep,
  type TenantRequiredFieldKey,
} from "./tenantForm";

export type TenantFormModalProps = {
  open: boolean;
  mode: "create" | "edit";
  title: string;
  onClose: () => void;
  initialValues?: AddTenantFormValues | null;
  isLoading?: boolean;
  isSaving?: boolean;
  /** Called only from the review-step Save Changes action — never from Review Changes. */
  onSave: (values: AddTenantFormValues) => void;
};

export function TenantFormModal({
  open,
  mode,
  title,
  onClose,
  initialValues,
  isLoading = false,
  isSaving = false,
  onSave,
}: TenantFormModalProps) {
  const [step, setStep] = useState<TenantFormStep>(mode === "edit" ? "view" : "edit");
  const [baseline, setBaseline] = useState<AddTenantFormValues>(createEmptyTenantFormValues);
  const [values, setValues] = useState<AddTenantFormValues>(createEmptyTenantFormValues);
  const [touchedFields, setTouchedFields] = useState<Partial<Record<TenantRequiredFieldKey, boolean>>>({});
  const [showAllErrors, setShowAllErrors] = useState(false);
  const hydratedOpenRef = useRef(false);

  useEffect(() => {
    if (!open) {
      hydratedOpenRef.current = false;
      return;
    }

    if (mode === "create") {
      if (hydratedOpenRef.current) return;
      const empty = createEmptyTenantFormValues();
      setBaseline(empty);
      setValues(empty);
      setStep("edit");
      setTouchedFields({});
      setShowAllErrors(false);
      hydratedOpenRef.current = true;
      return;
    }

    if (initialValues && !hydratedOpenRef.current) {
      setBaseline(initialValues);
      setValues(initialValues);
      setStep("view");
      setTouchedFields({});
      setShowAllErrors(false);
      hydratedOpenRef.current = true;
    }
  }, [open, mode, initialValues]);

  const updateField = <K extends keyof AddTenantFormValues>(key: K, value: AddTenantFormValues[K]) => {
    setValues((current) => ({ ...current, [key]: value }));
  };

  const markTouched = (key: TenantRequiredFieldKey) => {
    setTouchedFields((current) => ({ ...current, [key]: true }));
  };

  const hasChanges = !areTenantFormValuesEqual(values, baseline);
  const isComplete = isTenantFormComplete(values);
  const fieldsDisabled = step === "view" || step === "review";
  const isEditingStep = step === "edit";

  /** Review is enabled after the user changes something; required-field checks run on click. */
  const canReview = hasChanges && !isSaving;

  const goToReview = () => {
    if (!isComplete) {
      setShowAllErrors(true);
      return;
    }
    setShowAllErrors(false);
    setStep("review");
  };

  const goBackToEdit = () => {
    setStep("edit");
  };

  /** Sole path that invokes create/update — never called from Review Changes. */
  const persistChanges = () => {
    if (step !== "review") return;
    if (!isComplete || isSaving) return;
    onSave(values);
  };

  /** Block native form submit (e.g. Enter in an input). API save is button-driven only. */
  const blockNativeSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  };

  const formId = mode === "create" ? "add-tenant-form" : "edit-tenant-form";
  const idPrefix = mode === "create" ? "add" : "edit";

  let footer: ReactNode;
  if (step === "view") {
    footer = (
      <Button type="button" size="sm" className="h-8" onClick={() => setStep("edit")} disabled={isLoading || !initialValues}>
        Edit
      </Button>
    );
  } else if (step === "edit") {
    footer = (
      <>
        <Button type="button" variant="outline_bold" size="sm" className="h-8" onClick={onClose} disabled={isSaving}>
          Cancel
        </Button>
        <Button type="button" size="sm" className="h-8" disabled={!canReview} onClick={goToReview}>
          Review Changes
        </Button>
      </>
    );
  } else {
    footer = (
      <>
        <Button type="button" variant="outline_bold" size="sm" className="h-8" onClick={goBackToEdit} disabled={isSaving}>
          Back
        </Button>
        <Button type="button" size="sm" className="h-8" disabled={!isComplete || isSaving} onClick={persistChanges}>
          {isSaving ? "Saving…" : "Add Tenant"}
        </Button>
      </>
    );
  }

  return (
    <Drawer open={open} title={title} onClose={onClose} footer={footer}>
      {isLoading || (mode === "edit" && !initialValues) ? (
        <p className="text-sm text-ui-text-secondary">Loading tenant…</p>
      ) : (
        <form id={formId} className="space-y-4" onSubmit={blockNativeSubmit} noValidate>
          <TenantFormFields
            idPrefix={idPrefix}
            values={values}
            disabled={fieldsDisabled}
            showRequiredIndicators={isEditingStep}
            showErrors={isEditingStep && showAllErrors}
            touchedFields={isEditingStep ? touchedFields : undefined}
            onBlurField={isEditingStep ? markTouched : undefined}
            onChange={updateField}
          />
        </form>
      )}
    </Drawer>
  );
}
