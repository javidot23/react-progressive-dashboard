import type { TenantApi } from "@/services/api/tenants";

export type AddTenantFormValues = {
  tenantId: string;
  tenantName: string;
  tenantType: string;
  entitlementTier: string;
  active: string;
  federated: string;
  primaryDomain: string;
  additionalDomains: string[];
  databaseHost: string;
  databaseName: string;
  databasePort: string;
  databaseSchema: string;
  databaseUsername: string;
};

export type TenantFormStep = "view" | "edit" | "review";

/** API-required fields when creating/updating a tenant. */
export type TenantRequiredFieldKey = "tenantId" | "tenantName" | "tenantType";

export const TENANT_REQUIRED_FIELD_KEYS: TenantRequiredFieldKey[] = ["tenantId", "tenantName", "tenantType"];

export function createEmptyTenantFormValues(): AddTenantFormValues {
  return {
    tenantId: "",
    tenantName: "",
    tenantType: "",
    entitlementTier: "",
    active: "",
    federated: "",
    primaryDomain: "",
    additionalDomains: [],
    databaseHost: "",
    databaseName: "",
    databasePort: "",
    databaseSchema: "",
    databaseUsername: "",
  };
}

export function tenantApiToFormValues(tenant: TenantApi): AddTenantFormValues {
  const [primary, ...rest] = tenant.domains ?? [];
  return {
    tenantId: tenant.tenant_code ?? "",
    tenantName: tenant.tenant_name ?? "",
    tenantType: tenant.tenant_type ?? "",
    entitlementTier: tenant.entitlement_tier ?? "",
    active: tenant.is_active ? "active" : "inactive",
    federated: tenant.is_federated ? "yes" : "no",
    primaryDomain: primary?.domain ?? "",
    additionalDomains: rest.map((domain) => domain.domain),
    databaseHost: tenant.database_host ?? "",
    databaseName: tenant.database_name ?? "",
    databasePort: tenant.database_port != null ? String(tenant.database_port) : "",
    databaseSchema: tenant.database_schema ?? "",
    databaseUsername: tenant.database_username ?? "",
  };
}

export function isTenantFieldFilled(values: AddTenantFormValues, key: TenantRequiredFieldKey): boolean {
  return Boolean(values[key].trim());
}

export function isTenantFormComplete(values: AddTenantFormValues): boolean {
  return TENANT_REQUIRED_FIELD_KEYS.every((key) => isTenantFieldFilled(values, key));
}

export function areTenantFormValuesEqual(a: AddTenantFormValues, b: AddTenantFormValues): boolean {
  return (
    a.tenantId === b.tenantId &&
    a.tenantName === b.tenantName &&
    a.tenantType === b.tenantType &&
    a.entitlementTier === b.entitlementTier &&
    a.active === b.active &&
    a.federated === b.federated &&
    a.primaryDomain === b.primaryDomain &&
    a.databaseHost === b.databaseHost &&
    a.databaseName === b.databaseName &&
    a.databasePort === b.databasePort &&
    a.databaseSchema === b.databaseSchema &&
    a.databaseUsername === b.databaseUsername &&
    a.additionalDomains.length === b.additionalDomains.length &&
    a.additionalDomains.every((domain, index) => domain === b.additionalDomains[index])
  );
}

/** Domains are stored without the leading "@" and compared case-insensitively. */
export function normalizeTenantDomain(domain: string): string {
  return domain.trim().replace(/^@+/, "").toLowerCase();
}

export function collectTenantDomains(values: AddTenantFormValues): string[] {
  return [...new Set([values.primaryDomain, ...values.additionalDomains].map(normalizeTenantDomain).filter(Boolean))];
}

export const TENANT_FORM_DISABLED_FIELD_CLASS = "disabled:bg-[#F5F5F5] disabled:opacity-100";

export const TENANT_ACTIVE_OPTIONS = [
  { value: "active", label: "Active" },
  { value: "inactive", label: "Deactivated" },
] as const;

export const TENANT_FEDERATED_OPTIONS = [
  { value: "yes", label: "Yes" },
  { value: "no", label: "No" },
] as const;
