import { PageHeader, Table, TableHead, TableBody, TableRow, TableHeaderCell, TableCell, Button } from "@/components/ui";

export function RolesPage() {
  return (
    <div>
      <PageHeader
        title="Roles"
        description="Define and assign administrative roles."
        actions={<Button disabled>Add role</Button>}
      />
      <Table>
        <TableHead>
          <TableRow>
            <TableHeaderCell>Role</TableHeaderCell>
            <TableHeaderCell>Description</TableHeaderCell>
            <TableHeaderCell>Users</TableHeaderCell>
            <TableHeaderCell>Actions</TableHeaderCell>
          </TableRow>
        </TableHead>
        <TableBody>
          <TableRow>
            <TableCell colSpan={4} className="py-10 text-center text-ui-text-primary">
              No roles yet. Role definitions will appear here.
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </div>
  );
}
