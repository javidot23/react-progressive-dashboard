import { useQuery } from "@tanstack/react-query";
import { Activity, Users, Shield, KeyRound } from "lucide-react";
import { PageHeader, Card, CardContent, CardHeader, CardTitle } from "@/components/ui";
import { useProfile } from "@/hooks/useProfile";
import { getUserFirstName } from "@/lib/profileHelpers";
import { dashboardApi, type DashboardSummary } from "@/services/api";

export const dashboardQueryKeys = {
  all: ["dashboard"] as const,
  summary: () => [...dashboardQueryKeys.all, "summary"] as const,
};

const fallbackSummary: DashboardSummary = {
  kpis: [
    { id: "users", label: "Total Users", value: "—", change: "Pending API" },
    { id: "roles", label: "Roles", value: "—", change: "Pending API" },
    { id: "permissions", label: "Permissions", value: "—", change: "Pending API" },
    { id: "activity", label: "Active Sessions", value: "—", change: "Pending API" },
  ],
  recentActivity: [
    { id: "1", description: "Connect the dashboard API to populate recent activity.", timestamp: new Date().toISOString() },
  ],
};

const kpiIcons = [Users, Shield, KeyRound, Activity];

export function useDashboardSummaryQuery() {
  return useQuery({
    queryKey: dashboardQueryKeys.summary(),
    queryFn: async ({ signal }) => {
      try {
        const { data } = await dashboardApi.getSummary(signal);
        return data;
      } catch {
        return fallbackSummary;
      }
    },
  });
}

export function DashboardPage() {
  const { data, isLoading } = useDashboardSummaryQuery();
  const { profile } = useProfile();
  const summary = data ?? fallbackSummary;
  const firstName = getUserFirstName(profile);

  return (
    <div>
      <PageHeader title={`Welcome, ${firstName}`} description="Administrative overview and recent activity." />

      <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {summary.kpis.map((kpi, index) => {
          const Icon = kpiIcons[index % kpiIcons.length];
          return (
            <Card key={kpi.id}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-ui-text-primary">{kpi.label}</CardTitle>
                <Icon className="size-4 text-brand-primary-main" />
              </CardHeader>
              <CardContent className="pt-2">
                <p className="text-2xl font-semibold text-ui-text-heading">{isLoading ? "…" : kpi.value}</p>
                {kpi.change && <p className="mt-1 text-xs text-ui-text-primary">{kpi.change}</p>}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
