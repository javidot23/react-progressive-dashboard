import { beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AxiosHeaders } from "axios";
import type { DashboardSummary } from "@/services/api";
import { DashboardPage } from "@/pages/DashboardPage";

type GetDashboardSummary = (typeof import("@/services/api"))["dashboardApi"]["getSummary"];

const { getSummaryMock } = vi.hoisted(() => ({
  getSummaryMock: vi.fn<GetDashboardSummary>(),
}));

vi.mock("@/services/api", () => ({
  dashboardApi: {
    getSummary: getSummaryMock,
  },
}));

vi.mock("@/hooks/useProfile", () => ({
  useProfile: () => ({
    profile: {
      id: "1",
      displayName: "Jane Doe",
      givenName: "Jane",
      surname: "Doe",
      mail: "jane.doeexample.com",
    },
    isLoading: false,
    error: null,
    refetch: vi.fn(),
  }),
}));

const summaryFixture: DashboardSummary = {
  kpis: [
    { id: "users", label: "Total Users", value: "42", change: "+2" },
    { id: "roles", label: "Roles", value: "8", change: "+1" },
    { id: "permissions", label: "Permissions", value: "16", change: "0" },
    { id: "activity", label: "Active Sessions", value: "3", change: "-1" },
  ],
  recentActivity: [
    {
      id: "1",
      description: "User role updated",
      timestamp: "2026-07-29T12:00:00.000Z",
    },
  ],
};

function renderDashboard() {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
    },
  });

  return render(
    <QueryClientProvider client={queryClient}>
      <DashboardPage />
    </QueryClientProvider>,
  );
}

describe("DashboardPage", () => {
  beforeEach(() => {
    getSummaryMock.mockReset();
    getSummaryMock.mockResolvedValue({
      data: summaryFixture,
      status: 200,
      statusText: "OK",
      headers: new AxiosHeaders(),
      config: { headers: new AxiosHeaders() },
    });
  });

  it("shows KPI cards", async () => {
    renderDashboard();
    await waitFor(() => {
      expect(screen.getByText("Total Users")).toBeTruthy();
      expect(screen.getByText("Roles")).toBeTruthy();
      expect(screen.getByText("Permissions")).toBeTruthy();
    });
    expect(getSummaryMock).toHaveBeenCalled();
  });
});
