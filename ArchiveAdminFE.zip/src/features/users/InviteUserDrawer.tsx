import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Button } from "@/components/atoms";
import { Drawer, FormField, Input, Select } from "@/components/ui";
import { useTenantDomainsQuery } from "@/features/tenants/useTenantDomainsQuery";
import { flattenTenantsPages, useTenantsQuery } from "@/features/tenants/useTenantsQuery";
import { useInviteUserMutation } from "./useUserMutations";

export type InviteUserDrawerProps = {
  open: boolean;
  onClose: () => void;
  /** When provided, tenant is fixed; otherwise a tenant selector is shown. */
  tenantUuid?: string;
  tenantName?: string;
};

export function InviteUserDrawer({ open, onClose, tenantUuid, tenantName }: InviteUserDrawerProps) {
  const [emailLocal, setEmailLocal] = useState("");
  const [emailDomain, setEmailDomain] = useState("");
  const [selectedTenant, setSelectedTenant] = useState(tenantUuid ?? "");
  const inviteUser = useInviteUserMutation();
  const needsTenantSelect = !tenantUuid;

  const tenantsQuery = useTenantsQuery(
    {
      search: "",
      tenantType: "all",
      entitlement: "all",
      status: "active",
      limit: 100,
    },
    open && needsTenantSelect,
  );
  const tenants = useMemo(
    () => (needsTenantSelect && open ? flattenTenantsPages(tenantsQuery.data) : []),
    [needsTenantSelect, open, tenantsQuery.data],
  );

  const resolvedTenant = tenantUuid || selectedTenant;
  const domainsQuery = useTenantDomainsQuery(open ? resolvedTenant || undefined : undefined);

  const domainOptions = useMemo(
    () =>
      (domainsQuery.data ?? [])
        .map((entry) => (entry?.domain ?? "").trim().replace(/^@+/, ""))
        .filter(Boolean)
        .map((domain) => ({ value: domain, label: `@${domain}` })),
    [domainsQuery.data],
  );

  useEffect(() => {
    if (!open) return;
    setEmailLocal("");
    setEmailDomain("");
    setSelectedTenant(tenantUuid ?? "");
  }, [open, tenantUuid]);

  const canSubmit = Boolean(emailLocal.trim() && emailDomain.trim() && resolvedTenant) && !inviteUser.isPending;

  const selectTenant = (value: string) => {
    setSelectedTenant(value);
    // Allowed domains are per tenant, so a previous pick no longer applies.
    setEmailDomain("");
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!canSubmit || !resolvedTenant) return;

    const resolvedTenantName = tenantName || tenants.find((tenant) => tenant.id === resolvedTenant)?.name;

    inviteUser.mutate(
      {
        email: `${emailLocal.trim()}@${emailDomain.trim()}`,
        tenant_uuid: resolvedTenant,
        tenantName: resolvedTenantName,
      },
      {
        onSuccess: () => onClose(),
      },
    );
  };

  return (
    <Drawer
      open={open}
      title="Invite User"
      onClose={onClose}
      footer={
        <>
          <Button type="button" variant="outline" size="sm" className="h-8" onClick={onClose} disabled={inviteUser.isPending}>
            Cancel
          </Button>
          <Button type="submit" form="invite-user-form" size="sm" className="h-8" disabled={!canSubmit}>
            {inviteUser.isPending ? "Sending…" : "Send Invite"}
          </Button>
        </>
      }
    >
      <form id="invite-user-form" className="space-y-4" onSubmit={handleSubmit}>
        {tenantName && !needsTenantSelect ? (
          <p className="font-body-sm text-[length:var(--text-body-sm)] leading-body-sm text-ui-text-secondary">
            Invite a user to <span className="font-medium text-ui-text-heading">{tenantName}</span>.
          </p>
        ) : null}

        {needsTenantSelect ? (
          <FormField id="invite-user-tenant" label="Tenant">
            <Select
              id="invite-user-tenant"
              value={selectedTenant}
              onChange={(event) => selectTenant(event.target.value)}
              placeholder="Select tenant"
              options={tenants.map((tenant) => ({
                value: tenant.id,
                label: tenant.name,
              }))}
              required
            />
          </FormField>
        ) : null}

        <FormField id="invite-user-email-local" label="Primary Email" required>
          <div className="flex items-center gap-2">
            <Input
              id="invite-user-email-local"
              value={emailLocal}
              onChange={(event) => setEmailLocal(event.target.value)}
              placeholder="john.doe"
              required
            />
            <span className="shrink-0 text-sm font-medium text-ui-text-heading" aria-hidden>
              @
            </span>
            <Select
              id="invite-user-email-domain"
              aria-label="Email domain"
              value={emailDomain}
              onChange={(event) => setEmailDomain(event.target.value)}
              options={domainOptions}
              placeholder={domainsQuery.isLoading ? "Loading…" : "Select"}
              required
              disabled={!resolvedTenant || domainsQuery.isLoading}
            />
          </div>
        </FormField>

        {resolvedTenant && !domainsQuery.isLoading && domainOptions.length === 0 ? (
          <p className="text-xs text-ui-text-secondary">
            This tenant has no allowed domains yet. Add a domain to the tenant before inviting users.
          </p>
        ) : null}
      </form>
    </Drawer>
  );
}
