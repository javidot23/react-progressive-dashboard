import { useEffect, useState, type FormEvent } from "react";
import { Button } from "@/components/atoms";
import { Drawer, FormField, Input, Select, Switch } from "@/components/ui";
import { USER_STATUS_OPTIONS, type UserStatusEnum } from "@/services/api/enums";
import { useCreateInternalUserMutation, useUpdateUserMutation } from "./useUserMutations";
import type { UserRow } from "./users.data";

export type UserFormDrawerProps = {
  open: boolean;
  onClose: () => void;
  mode: "create" | "edit";
  user?: UserRow | null;
  /** When creating from a tenant row, associates the new user with this tenant. */
  tenantUuid?: string;
  tenantName?: string;
};

type FormValues = {
  displayName: string;
  email: string;
  jobTitle: string;
  department: string;
  isPlatformAdmin: boolean;
  status: UserStatusEnum;
};

function createEmptyValues(): FormValues {
  return {
    displayName: "",
    email: "",
    jobTitle: "",
    department: "",
    isPlatformAdmin: false,
    status: "active",
  };
}

function fromUser(user: UserRow): FormValues {
  return {
    displayName: user.displayName || user.name,
    email: user.email,
    jobTitle: user.jobTitle === "—" ? "" : user.jobTitle,
    department: user.department === "—" ? "" : user.department,
    isPlatformAdmin: user.isPlatformAdmin,
    status: user.statusApi,
  };
}

export function UserFormDrawer({ open, onClose, mode, user, tenantUuid, tenantName }: UserFormDrawerProps) {
  const [values, setValues] = useState<FormValues>(createEmptyValues);
  const createUser = useCreateInternalUserMutation();
  const updateUser = useUpdateUserMutation(user?.id ?? "");

  useEffect(() => {
    if (!open) return;
    setValues(mode === "edit" && user ? fromUser(user) : createEmptyValues());
  }, [open, mode, user]);

  const updateField = <K extends keyof FormValues>(key: K, value: FormValues[K]) => {
    setValues((current) => ({ ...current, [key]: value }));
  };

  const isPending = createUser.isPending || updateUser.isPending;
  const canSubmit =
    Boolean(
      values.displayName.trim() &&
      values.email.trim() &&
      values.jobTitle.trim() &&
      values.department.trim() &&
      (mode === "edit" ? values.status && user?.id : true),
    ) && !isPending;

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!canSubmit) return;

    if (mode === "create") {
      createUser.mutate(
        {
          email: values.email.trim(),
          display_name: values.displayName.trim(),
          job_title: values.jobTitle.trim(),
          department: values.department.trim(),
          is_platform_admin: values.isPlatformAdmin,
          status: values.status,
          tenantUuids: tenantUuid ? [tenantUuid] : undefined,
          tenantName,
        },
        { onSuccess: () => onClose() },
      );
      return;
    }

    updateUser.mutate(
      {
        display_name: values.displayName.trim(),
        job_title: values.jobTitle.trim(),
        department: values.department.trim(),
        is_platform_admin: values.isPlatformAdmin,
        status: values.status,
      },
      { onSuccess: () => onClose() },
    );
  };

  return (
    <Drawer
      open={open}
      title={mode === "create" ? "Add user" : "Edit user"}
      onClose={onClose}
      footer={
        <>
          <Button type="button" variant="outline" size="sm" className="h-8" onClick={onClose} disabled={isPending}>
            Cancel
          </Button>
          <Button type="submit" form="user-form" size="sm" className="h-8" disabled={!canSubmit}>
            {isPending ? "Saving…" : mode === "create" ? "Add user" : "Save changes"}
          </Button>
        </>
      }
    >
      <form id="user-form" className="space-y-4" onSubmit={handleSubmit}>
        {mode === "create" && tenantName ? (
          <p className="font-body-sm text-[length:var(--text-body-sm)] leading-body-sm text-ui-text-secondary">
            Adding a user to <span className="font-medium text-ui-text-heading">{tenantName}</span>.
          </p>
        ) : null}

        <FormField id="user-display-name" label="Display name">
          <Input
            id="user-display-name"
            value={values.displayName}
            onChange={(event) => updateField("displayName", event.target.value)}
            placeholder="Jane Doe"
            required
          />
        </FormField>
        <FormField id="user-email" label="Email">
          <Input
            id="user-email"
            type="email"
            value={values.email}
            onChange={(event) => updateField("email", event.target.value)}
            placeholder="userexample.com"
            required
            disabled={mode === "edit"}
          />
        </FormField>
        <FormField id="user-platform-admin" label="Platform admin">
          <div className="flex h-10 items-center">
            <Switch
              id="user-platform-admin"
              checked={values.isPlatformAdmin}
              onCheckedChange={(checked) => updateField("isPlatformAdmin", checked)}
              label="Platform admin"
            />
          </div>
        </FormField>
        <FormField id="user-job-title" label="Job title">
          <Input
            id="user-job-title"
            value={values.jobTitle}
            onChange={(event) => updateField("jobTitle", event.target.value)}
            placeholder="Analyst"
            required
          />
        </FormField>
        <FormField id="user-department" label="Department">
          <Input
            id="user-department"
            value={values.department}
            onChange={(event) => updateField("department", event.target.value)}
            placeholder="Finance"
            required
          />
        </FormField>
        {mode === "edit" ? (
          <FormField id="user-status" label="Status">
            <Select
              id="user-status"
              value={values.status}
              onChange={(event) => updateField("status", event.target.value as UserStatusEnum)}
              options={USER_STATUS_OPTIONS}
              required
            />
          </FormField>
        ) : null}
      </form>
    </Drawer>
  );
}
