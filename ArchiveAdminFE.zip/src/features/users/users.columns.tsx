import { MoreVertical } from "lucide-react";
import { createColumnHelper } from "@/components/organisms/DataGrid";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, StatusBadge } from "@/components/ui";
import type { UserRow } from "./users.data";

const columnHelper = createColumnHelper<UserRow>();

export type UserColumnsOptions = {
  onEdit?: (user: UserRow) => void;
  onDeactivate?: (user: UserRow) => void;
  showDepartment?: boolean;
  showJobTitle?: boolean;
  /** When true, shows first_name / last_name instead of the combined Name column. */
  showNameParts?: boolean;
  /** Platform Users page columns: Tenant instead of department/job title. */
  showPlatformFields?: boolean;
};

function UserRowActions({
  user,
  onEdit,
  onDeactivate,
}: {
  user: UserRow;
  onEdit?: (user: UserRow) => void;
  onDeactivate?: (user: UserRow) => void;
}) {
  const canDeactivate = user.statusApi !== "inactive" && user.statusApi !== "disabled" && user.statusApi !== "deleted";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger showChevron={false} aria-label={`Actions for ${user.name}`}>
        <MoreVertical className="h-4 w-4" aria-hidden />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[10rem]">
        <DropdownMenuItem onClick={() => onEdit?.(user)}>Edit user</DropdownMenuItem>
        {canDeactivate ? (
          <DropdownMenuItem destructive onClick={() => onDeactivate?.(user)}>
            Deactivate
          </DropdownMenuItem>
        ) : null}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function createUserColumns({
  onEdit,
  onDeactivate,
  showDepartment = true,
  showJobTitle = true,
  showNameParts = false,
  showPlatformFields = false,
}: UserColumnsOptions = {}) {
  return [
    ...(showNameParts
      ? [
          columnHelper.accessor("firstName", {
            header: "First Name",
            cell: (info) => <span className="font-medium text-ui-text-heading">{info.getValue() || "—"}</span>,
            meta: { minWidth: 110 },
          }),
          columnHelper.accessor("lastName", {
            header: "Last Name",
            cell: (info) => info.getValue() || "—",
            meta: { minWidth: 110 },
          }),
        ]
      : [
          columnHelper.accessor("name", {
            header: "Name",
            cell: (info) => <span className="font-medium text-ui-text-heading">{info.getValue()}</span>,
            meta: { minWidth: 140 },
          }),
        ]),
    columnHelper.accessor("email", {
      header: "Email",
      cell: (info) => info.getValue(),
      meta: { minWidth: 180 },
    }),
    ...(showPlatformFields
      ? [
          columnHelper.accessor("tenantLabel", {
            header: "Tenant",
            cell: (info) => info.getValue(),
            meta: { minWidth: 160 },
          }),
        ]
      : [
          ...(showDepartment
            ? [
                columnHelper.accessor("department", {
                  header: "Department",
                  cell: (info) => info.getValue(),
                  meta: { minWidth: 120 },
                }),
              ]
            : []),
          ...(showJobTitle
            ? [
                columnHelper.accessor("jobTitle", {
                  header: "Job Title",
                  cell: (info) => info.getValue(),
                  meta: { minWidth: 120 },
                }),
              ]
            : []),
        ]),
    columnHelper.accessor("lastLogin", {
      header: "Last Login",
      cell: (info) => info.getValue(),
      meta: { minWidth: 110 },
    }),
    columnHelper.accessor("status", {
      header: "Status",
      cell: (info) => <StatusBadge status={info.getValue()} />,
      meta: { minWidth: 110 },
    }),
    columnHelper.display({
      id: "actions",
      header: "",
      cell: ({ row }) => <UserRowActions user={row.original} onEdit={onEdit} onDeactivate={onDeactivate} />,
      meta: { align: "center" as const, minWidth: 48, nowrap: true },
    }),
  ];
}
