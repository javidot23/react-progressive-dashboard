import type { StatusBadgeStatus } from "@/components/ui";
import type { UserStatusEnum } from "@/services/api/enums";
import type { UserApi } from "@/services/api/users";

export type UserRow = {
  id: string;
  name: string;
  email: string;
  department: string;
  jobTitle: string;
  tenantLabel: string;
  status: StatusBadgeStatus;
  statusApi: UserStatusEnum;
  lastLogin: string;
  isPlatformAdmin: boolean;
  tenantAccessScope: UserApi["tenant_access_scope"];
  firstName: string;
  lastName: string;
  displayName: string;
};

const STATUS_BADGE_BY_API: Record<UserStatusEnum, StatusBadgeStatus> = {
  active: "Active",
  pending_verification: "Pending verification",
  suspended: "Suspended",
  inactive: "Inactive",
  disabled: "Disabled",
  deleted: "Deleted",
};

export function formatRelativeTime(value: string | null): string {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  const diffMs = Date.now() - date.getTime();
  const minutes = Math.floor(diffMs / 60_000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes} min${minutes === 1 ? "" : "s"} ago`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hr${hours === 1 ? "" : "s"} ago`;

  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} day${days === 1 ? "" : "s"} ago`;

  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function formatTenantLabel(user: UserApi): string {
  if (user.tenant_access_scope === "all_tenants") return "All tenants";
  const names = (user.tenants ?? []).map((tenant) => tenant.tenant_name?.trim() || tenant.tenant_code?.trim()).filter(Boolean);
  return names.length > 0 ? names.join(", ") : "—";
}

export function mapUserApiToRow(user: UserApi): UserRow {
  const name = user.display_name?.trim() || [user.first_name, user.last_name].filter(Boolean).join(" ").trim() || user.email;

  return {
    id: user.user_uuid,
    name,
    email: user.email,
    department: user.department || "—",
    jobTitle: user.job_title || "—",
    tenantLabel: formatTenantLabel(user),
    status: STATUS_BADGE_BY_API[user.status] ?? "Inactive",
    statusApi: user.status,
    lastLogin: formatRelativeTime(user.last_login),
    isPlatformAdmin: user.is_platform_admin,
    tenantAccessScope: user.tenant_access_scope,
    firstName: user.first_name ?? "",
    lastName: user.last_name ?? "",
    displayName: user.display_name ?? "",
  };
}
