import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Button } from "@/components/atoms";
import { Drawer, FormField, Input, Select } from "@/components/ui";
import { cn } from "@/utils";
import { useCreateInternalUserMutation } from "./useUserMutations";

export type MultiTenantUserDrawerProps = {
  open: boolean;
  onClose: () => void;
};

type FormStep = "edit" | "review";

type EmailParts = {
  local: string;
  domain: string;
};

type FormValues = {
  firstName: string;
  lastName: string;
  primaryEmail: EmailParts;
  /** DO NOT DELETE — stays empty while the additional-email UI is commented out below. */
  additionalEmails: EmailParts[];
};

type RequiredFieldKey = "emailLocal" | "emailDomain";

const DISABLED_FIELD_CLASS = "disabled:bg-[#F5F5F5] disabled:opacity-100";
const INVALID_FIELD_CLASS = "border-status-error-main focus-visible:ring-status-error-main";

/** Multi-tenant users are internal, so the allowed domains are fixed rather than tenant-derived. */
const MULTI_TENANT_EMAIL_DOMAINS = ["cencorapr.com", "cencora.com", "amerisourcebergen.com", "stratium.com"] as const;

const DOMAIN_OPTIONS = MULTI_TENANT_EMAIL_DOMAINS.map((domain) => ({ value: domain, label: `@${domain}` }));

function createEmptyEmail(): EmailParts {
  return { local: "", domain: "" };
}

function createEmptyValues(): FormValues {
  return {
    firstName: "",
    lastName: "",
    primaryEmail: createEmptyEmail(),
    additionalEmails: [],
  };
}

function buildEmail(parts: EmailParts): string {
  const local = parts.local.trim();
  const domain = parts.domain.trim().replace(/^@+/, "");
  if (!local || !domain) return "";
  return `${local}@${domain}`;
}

function areValuesEqual(a: FormValues, b: FormValues): boolean {
  if (a.firstName !== b.firstName || a.lastName !== b.lastName) return false;
  if (a.primaryEmail.local !== b.primaryEmail.local || a.primaryEmail.domain !== b.primaryEmail.domain) return false;
  if (a.additionalEmails.length !== b.additionalEmails.length) return false;
  return a.additionalEmails.every(
    (email, index) => email.local === b.additionalEmails[index]?.local && email.domain === b.additionalEmails[index]?.domain,
  );
}

function isFormComplete(values: FormValues): boolean {
  return Boolean(values.primaryEmail.local.trim() && values.primaryEmail.domain.trim());
}

export function MultiTenantUserDrawer({ open, onClose }: MultiTenantUserDrawerProps) {
  const [step, setStep] = useState<FormStep>("edit");
  const [baseline, setBaseline] = useState<FormValues>(createEmptyValues);
  const [values, setValues] = useState<FormValues>(createEmptyValues);
  const [touchedFields, setTouchedFields] = useState<Partial<Record<RequiredFieldKey, boolean>>>({});
  const [showAllErrors, setShowAllErrors] = useState(false);
  const hydratedOpenRef = useRef(false);
  const createUser = useCreateInternalUserMutation();

  useEffect(() => {
    if (!open) {
      hydratedOpenRef.current = false;
      return;
    }
    if (hydratedOpenRef.current) return;
    const empty = createEmptyValues();
    setBaseline(empty);
    setValues(empty);
    setStep("edit");
    setTouchedFields({});
    setShowAllErrors(false);
    hydratedOpenRef.current = true;
  }, [open]);

  const hasChanges = !areValuesEqual(values, baseline);
  const isComplete = isFormComplete(values);
  const fieldsDisabled = step === "review";
  const isEditing = step === "edit";
  const canReview = hasChanges && !createUser.isPending;
  const primaryEmail = buildEmail(values.primaryEmail);

  const fieldError = (key: RequiredFieldKey, filled: boolean): string | undefined => {
    if (!isEditing) return undefined;
    if (!showAllErrors && !touchedFields[key]) return undefined;
    if (filled) return undefined;
    return "This field is required";
  };

  const markTouched = (key: RequiredFieldKey) => {
    setTouchedFields((current) => ({ ...current, [key]: true }));
  };

  const goToReview = () => {
    if (!isComplete) {
      setShowAllErrors(true);
      return;
    }
    setShowAllErrors(false);
    setStep("review");
  };

  const persistUser = () => {
    if (step !== "review" || !isComplete || createUser.isPending || !primaryEmail) return;
    createUser.mutate(
      { email: primaryEmail },
      {
        onSuccess: () => onClose(),
      },
    );
  };

  const blockNativeSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  };

  const controlClass = (hasError: boolean) =>
    cn(fieldsDisabled ? DISABLED_FIELD_CLASS : undefined, hasError ? INVALID_FIELD_CLASS : undefined);

  const emailLocalError = fieldError("emailLocal", Boolean(values.primaryEmail.local.trim()));
  const emailDomainError = fieldError("emailDomain", Boolean(values.primaryEmail.domain.trim()));
  const emailError = emailLocalError || emailDomainError;

  let footer: ReactNode;
  if (isEditing) {
    footer = (
      <>
        <Button type="button" variant="outline_bold" size="sm" className="h-8" onClick={onClose} disabled={createUser.isPending}>
          Cancel
        </Button>
        <Button type="button" size="sm" className="h-8" disabled={!canReview} onClick={goToReview}>
          Review Multi Tenant User
        </Button>
      </>
    );
  } else {
    footer = (
      <>
        <Button
          type="button"
          variant="outline_bold"
          size="sm"
          className="h-8"
          onClick={() => setStep("edit")}
          disabled={createUser.isPending}
        >
          Back
        </Button>
        <Button type="button" size="sm" className="h-8" disabled={!isComplete || createUser.isPending} onClick={persistUser}>
          {createUser.isPending ? "Adding…" : "Add User"}
        </Button>
      </>
    );
  }

  return (
    <Drawer open={open} title="Add Multi Tenant User" onClose={onClose} footer={footer}>
      <form id="multi-tenant-user-form" className="space-y-4" onSubmit={blockNativeSubmit} noValidate>
        <section className="rounded-lg border border-[#E8E8E8] bg-white p-4">
          <h3 className="mb-2 text-lg font-normal tracking-normal text-[#0F172A]">Multi Tenant User Details</h3>
          <p className="mb-4 font-body-sm text-[length:var(--text-body-sm)] leading-body-sm italic text-ui-text-secondary">
            Multi-tenant users can access all tenants. Grant this permission only to users who require it.
          </p>
          <hr className="mb-4" />

          <div className="space-y-4">
            <FormField id="mtu-first-name" label="First Name">
              <Input
                id="mtu-first-name"
                value={values.firstName}
                onChange={(event) => setValues((current) => ({ ...current, firstName: event.target.value }))}
                placeholder="John"
                disabled={fieldsDisabled}
                className={controlClass(false)}
              />
            </FormField>

            <FormField id="mtu-last-name" label="Last Name">
              <Input
                id="mtu-last-name"
                value={values.lastName}
                onChange={(event) => setValues((current) => ({ ...current, lastName: event.target.value }))}
                placeholder="Doe"
                disabled={fieldsDisabled}
                className={controlClass(false)}
              />
            </FormField>

            <FormField id="mtu-email-local" label="Primary Email" required={isEditing} error={emailError}>
              <div className="flex items-center gap-2">
                <Input
                  id="mtu-email-local"
                  value={values.primaryEmail.local}
                  onChange={(event) =>
                    setValues((current) => ({
                      ...current,
                      primaryEmail: { ...current.primaryEmail, local: event.target.value },
                    }))
                  }
                  onBlur={() => markTouched("emailLocal")}
                  placeholder="john.doe"
                  required={isEditing}
                  disabled={fieldsDisabled}
                  aria-invalid={Boolean(emailLocalError)}
                  className={controlClass(Boolean(emailLocalError))}
                />
                <span className="shrink-0 text-sm font-medium text-ui-text-heading" aria-hidden>
                  @
                </span>
                <Select
                  id="mtu-email-domain"
                  aria-label="Email domain"
                  value={values.primaryEmail.domain}
                  onChange={(event) =>
                    setValues((current) => ({
                      ...current,
                      primaryEmail: { ...current.primaryEmail, domain: event.target.value },
                    }))
                  }
                  onBlur={() => markTouched("emailDomain")}
                  options={DOMAIN_OPTIONS}
                  placeholder="Select"
                  required={isEditing}
                  disabled={fieldsDisabled}
                  aria-invalid={Boolean(emailDomainError)}
                  className={controlClass(Boolean(emailDomainError))}
                />
              </div>
            </FormField>

            {/* DO NOT DELETE */}
            {/* Additional emails are unsupported by the API for now; restore once the endpoint accepts them.
            {values.additionalEmails.map((email, index) => (
              <FormField
                key={`mtu-additional-email-${index}`}
                id={`mtu-additional-email-local-${index}`}
                label={`Additional Email ${index + 1}`}
              >
                <div className="flex items-center gap-2">
                  <Input
                    id={`mtu-additional-email-local-${index}`}
                    value={email.local}
                    onChange={(event) =>
                      setValues((current) => {
                        const next = [...current.additionalEmails];
                        next[index] = { ...next[index], local: event.target.value };
                        return { ...current, additionalEmails: next };
                      })
                    }
                    placeholder="john.doe"
                    disabled={fieldsDisabled}
                    className={fieldsDisabled ? DISABLED_FIELD_CLASS : undefined}
                  />
                  <span className="shrink-0 text-sm font-medium text-ui-text-heading" aria-hidden>
                    @
                  </span>
                  <Select
                    id={`mtu-additional-email-domain-${index}`}
                    aria-label={`Additional email ${index + 1} domain`}
                    value={email.domain}
                    onChange={(event) =>
                      setValues((current) => {
                        const next = [...current.additionalEmails];
                        next[index] = { ...next[index], domain: event.target.value };
                        return { ...current, additionalEmails: next };
                      })
                    }
                    options={DOMAIN_OPTIONS}
                    placeholder="Select"
                    disabled={fieldsDisabled}
                    className={fieldsDisabled ? DISABLED_FIELD_CLASS : undefined}
                  />
                  {isEditing ? (
                    <button
                      type="button"
                      className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-ui-border-secondary text-ui-text-secondary hover:bg-ui-background-muted"
                      aria-label={`Remove additional email ${index + 1}`}
                      onClick={() =>
                        setValues((current) => ({
                          ...current,
                          additionalEmails: current.additionalEmails.filter((_, i) => i !== index),
                        }))
                      }
                    >
                      <Minus className="h-4 w-4" aria-hidden />
                    </button>
                  ) : null}
                </div>
              </FormField>
            ))}

            {isEditing ? (
              <div className="flex justify-end">
                <Button
                  type="button"
                  size="sm"
                  className="h-8 border-0 bg-[#E8E8E8] px-3 font-bold text-[#461E96] hover:bg-[#DDDBF7] hover:bg-brand-primary-200"
                  onClick={() =>
                    setValues((current) => ({
                      ...current,
                      additionalEmails: [...current.additionalEmails, createEmptyEmail()],
                    }))
                  }
                >
                  Add Additional Email
                </Button>
              </div>
            ) : null}
            */}
          </div>
        </section>
      </form>
    </Drawer>
  );
}
