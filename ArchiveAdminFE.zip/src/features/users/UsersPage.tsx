import { PageHeader, Table, TableHead, TableBody, TableRow, TableHeaderCell, TableCell, Button } from "@/components/ui";

export function UsersPage() {
  return (
    <div>
      <PageHeader title="Users" description="Manage administrative users." actions={<Button disabled>Add user</Button>} />
      <Table>
        <TableHead>
          <TableRow>
            <TableHeaderCell>Name</TableHeaderCell>
            <TableHeaderCell>Email</TableHeaderCell>
            <TableHeaderCell>Status</TableHeaderCell>
            <TableHeaderCell>Actions</TableHeaderCell>
          </TableRow>
        </TableHead>
        <TableBody>
          <TableRow>
            <TableCell colSpan={4} className="py-10 text-center text-ui-text-primary">
              No users yet. User management will appear here.
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </div>
  );
}
