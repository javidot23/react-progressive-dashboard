import { useEffect, useState, type FormEvent } from "react";
import { Button } from "@/components/atoms";
import { Drawer, FormField, Input, Select } from "@/components/ui";
import { USER_STATUS_OPTIONS, type UserStatusEnum } from "@/services/api/enums";
import { useUpdateUserMutation } from "./useUserMutations";
import type { UserRow } from "./users.data";

export type EditUserDrawerProps = {
  open: boolean;
  onClose: () => void;
  user: UserRow | null;
};

type FormValues = {
  firstName: string;
  lastName: string;
  status: UserStatusEnum;
};

function fromUser(user: UserRow): FormValues {
  return {
    firstName: user.firstName ?? "",
    lastName: user.lastName ?? "",
    status: user.statusApi,
  };
}

export function EditUserDrawer({ open, onClose, user }: EditUserDrawerProps) {
  const [values, setValues] = useState<FormValues>({ firstName: "", lastName: "", status: "active" });
  const updateUser = useUpdateUserMutation(user?.id ?? "");

  useEffect(() => {
    if (!open || !user) return;
    setValues(fromUser(user));
  }, [open, user]);

  const canSubmit = Boolean(values.status && user?.id) && !updateUser.isPending;

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!canSubmit || !user) return;

    updateUser.mutate(
      {
        first_name: values.firstName.trim(),
        last_name: values.lastName.trim(),
        status: values.status,
      },
      { onSuccess: () => onClose() },
    );
  };

  return (
    <Drawer
      open={open}
      title="Edit user"
      onClose={onClose}
      footer={
        <>
          <Button type="button" variant="outline" size="sm" className="h-8" onClick={onClose} disabled={updateUser.isPending}>
            Cancel
          </Button>
          <Button type="submit" form="edit-user-form" size="sm" className="h-8" disabled={!canSubmit}>
            {updateUser.isPending ? "Saving…" : "Save changes"}
          </Button>
        </>
      }
    >
      <form id="edit-user-form" className="space-y-4" onSubmit={handleSubmit}>
        {user?.email ? (
          <p className="font-body-sm text-[length:var(--text-body-sm)] leading-body-sm text-ui-text-secondary">
            Editing <span className="font-medium text-ui-text-heading">{user.email}</span>.
          </p>
        ) : null}

        <FormField id="edit-user-first-name" label="First name">
          <Input
            id="edit-user-first-name"
            value={values.firstName}
            onChange={(event) => setValues((current) => ({ ...current, firstName: event.target.value }))}
            placeholder="Jane"
          />
        </FormField>

        <FormField id="edit-user-last-name" label="Last name">
          <Input
            id="edit-user-last-name"
            value={values.lastName}
            onChange={(event) => setValues((current) => ({ ...current, lastName: event.target.value }))}
            placeholder="Doe"
          />
        </FormField>

        <FormField id="edit-user-status" label="Status">
          <Select
            id="edit-user-status"
            value={values.status}
            onChange={(event) => setValues((current) => ({ ...current, status: event.target.value as UserStatusEnum }))}
            options={USER_STATUS_OPTIONS}
            required
          />
        </FormField>
      </form>
    </Drawer>
  );
}
