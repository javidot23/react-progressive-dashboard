import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui";
import { getApiErrorMessage } from "@/lib/apiError";
import {
  usersApi,
  type CreateInternalUserPayload,
  type InviteUserPayload,
  type TenantAccessScopePayload,
  type UserPatchPayload,
} from "@/services/api/users";
import { tenantsApi, type TenantMembershipWritePayload } from "@/services/api/tenants";
import { usersQueryKeys } from "./useUsersQuery";
import { tenantsQueryKeys } from "@/features/tenants/useTenantsQuery";

export type InviteUserMutationInput = InviteUserPayload & {
  tenantName?: string;
};

export function useInviteUserMutation() {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async ({ tenantName, ...payload }: InviteUserMutationInput) => {
      const { data } = await usersApi.invite(payload);
      return { user: data.data, tenantName };
    },
    onSuccess: ({ user, tenantName }) => {
      void queryClient.invalidateQueries({ queryKey: usersQueryKeys.all });
      void queryClient.invalidateQueries({ queryKey: tenantsQueryKeys.all });
      const display = user.display_name?.trim() || user.email;
      success(tenantName ? `New user "${display}" was invited to ${tenantName}` : `New user "${display}" was invited`);
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to invite user."));
    },
  });
}

export function useCreateInternalUserMutation() {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async (
      payload: CreateInternalUserPayload &
        UserPatchPayload & {
          tenantUuids?: string[];
          tenantName?: string;
          tenant_access_scope?: TenantAccessScopePayload["tenant_access_scope"];
        },
    ) => {
      const { data } = await usersApi.createInternal({ email: payload.email });
      const created = data.data;

      const patch: UserPatchPayload = {
        display_name: payload.display_name,
        first_name: payload.first_name,
        last_name: payload.last_name,
        job_title: payload.job_title,
        department: payload.department,
        is_platform_admin: payload.is_platform_admin,
        status: payload.status,
      };

      const hasPatch = Object.values(patch).some((value) => value !== undefined && value !== "");
      let user = created;
      if (hasPatch) {
        const updated = await usersApi.update(created.user_uuid, patch);
        user = updated.data.data;
      }

      if (payload.tenant_access_scope === "all_tenants") {
        const scoped = await usersApi.setTenantAccessScope(created.user_uuid, {
          tenant_access_scope: "all_tenants",
        });
        user = scoped.data.data;
      } else if (payload.tenantUuids?.length) {
        const scoped = await usersApi.setTenantAccessScope(created.user_uuid, {
          tenant_access_scope: "tenant",
          tenant_uuids: payload.tenantUuids,
        });
        user = scoped.data.data;
      }

      return user;
    },
    onSuccess: (user, variables) => {
      void queryClient.invalidateQueries({ queryKey: usersQueryKeys.all });
      const display = user.display_name || user.email;
      success(
        variables.tenantName
          ? `New user "${display}" was invited to ${variables.tenantName}`
          : `User "${display}" was created successfully.`,
      );
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to create user."));
    },
  });
}

export function useUpdateUserMutation(userUuid: string) {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async (payload: UserPatchPayload) => {
      const { data } = await usersApi.update(userUuid, payload);
      return data.data;
    },
    onSuccess: (user) => {
      void queryClient.invalidateQueries({ queryKey: usersQueryKeys.all });
      void queryClient.invalidateQueries({ queryKey: usersQueryKeys.detail(userUuid) });
      success(`User '${user.display_name || user.email}' was updated successfully.`);
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to update user."));
    },
  });
}

export function useSetTenantAccessScopeMutation(userUuid: string) {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async (payload: TenantAccessScopePayload) => {
      const { data } = await usersApi.setTenantAccessScope(userUuid, payload);
      return data.data;
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: usersQueryKeys.all });
      void queryClient.invalidateQueries({ queryKey: usersQueryKeys.detail(userUuid) });
      void queryClient.invalidateQueries({ queryKey: usersQueryKeys.memberships(userUuid) });
      success("Tenant access updated successfully.");
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to update tenant access."));
    },
  });
}

export function useAddMembershipMutation(tenantUuid: string) {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async (payload: TenantMembershipWritePayload) => {
      const { data } = await tenantsApi.addMembership(tenantUuid, payload);
      return data.data;
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: usersQueryKeys.all });
      void queryClient.invalidateQueries({ queryKey: ["tenants", "memberships", tenantUuid] });
      success("Tenant membership added successfully.");
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to add membership."));
    },
  });
}

export function useDeactivateUserMutation() {
  const queryClient = useQueryClient();
  const { success, error } = useToast();

  return useMutation({
    mutationFn: async ({ userUuid, name }: { userUuid: string; name: string }) => {
      const { data } = await usersApi.update(userUuid, { status: "inactive" });
      return { user: data.data, name };
    },
    onSuccess: ({ name }) => {
      void queryClient.invalidateQueries({ queryKey: usersQueryKeys.all });
      success(`User '${name}' was successfully deactivated.`);
    },
    onError: (err) => {
      error(getApiErrorMessage(err, "Failed to deactivate user."));
    },
  });
}
