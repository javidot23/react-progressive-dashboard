import { useQuery } from "@tanstack/react-query";
import type { TenantAccessScopeEnum, UserStatusEnum } from "@/services/api/enums";
import { usersApi, type UsersListParams } from "@/services/api/users";
import { mapUserApiToRow } from "./users.data";

export const usersQueryKeys = {
  all: ["users"] as const,
  list: (params: UsersListParams) => [...usersQueryKeys.all, "list", params] as const,
  detail: (userUuid: string) => [...usersQueryKeys.all, "detail", userUuid] as const,
  memberships: (userUuid: string) => [...usersQueryKeys.all, "memberships", userUuid] as const,
};

export type UsersQueryFilters = {
  search: string;
  status: "all" | UserStatusEnum;
  tenant?: string;
  tenantAccessScope?: "all" | TenantAccessScopeEnum;
  isPlatformAdmin?: "all" | "true" | "false";
  limit?: number;
  offset?: number;
};

function toListParams(filters: UsersQueryFilters): UsersListParams {
  const params: UsersListParams = {
    limit: filters.limit ?? 50,
    offset: filters.offset ?? 0,
    ordering: "display_name",
  };

  const search = filters.search.trim();
  if (search) params.search = search;
  if (filters.status !== "all") params.status = filters.status;
  if (filters.tenant) params.tenant = filters.tenant;
  if (filters.tenantAccessScope && filters.tenantAccessScope !== "all") {
    params.tenant_access_scope = filters.tenantAccessScope;
  }
  if (filters.isPlatformAdmin === "true") params.is_platform_admin = true;
  if (filters.isPlatformAdmin === "false") params.is_platform_admin = false;

  return params;
}

export function useUsersQuery(filters: UsersQueryFilters) {
  const params = toListParams(filters);

  return useQuery({
    queryKey: usersQueryKeys.list(params),
    queryFn: async ({ signal }) => {
      const { data } = await usersApi.list(params, signal);
      const page = data.data;

      return {
        count: page.count,
        next: page.next,
        previous: page.previous,
        users: page.results.map(mapUserApiToRow),
      };
    },
    placeholderData: (previous) => previous,
  });
}
