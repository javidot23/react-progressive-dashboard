import { keepPreviousData, useInfiniteQuery } from "@tanstack/react-query";
import type { TenantAccessScopeEnum, UserStatusEnum } from "@/services/api/enums";
import { usersApi, type UsersListParams } from "@/services/api/users";
import { mapUserApiToRow, type UserRow } from "./users.data";

export const DEFAULT_USERS_PAGE_SIZE = 50;

export const usersQueryKeys = {
  all: ["users"] as const,
  list: (params: Omit<UsersListParams, "offset">) => [...usersQueryKeys.all, "list", params] as const,
  detail: (userUuid: string) => [...usersQueryKeys.all, "detail", userUuid] as const,
  memberships: (userUuid: string) => [...usersQueryKeys.all, "memberships", userUuid] as const,
};

export type UsersQueryFilters = {
  search: string;
  status: "all" | UserStatusEnum;
  tenant?: string;
  tenantAccessScope?: "all" | TenantAccessScopeEnum;
  isPlatformAdmin?: "all" | "true" | "false";
  limit?: number;
};

export type UsersPageResult = {
  count: number;
  next: string | null;
  previous: string | null;
  users: UserRow[];
};

function toListParams(filters: UsersQueryFilters, offset: number): UsersListParams {
  const params: UsersListParams = {
    limit: filters.limit ?? DEFAULT_USERS_PAGE_SIZE,
    offset,
    ordering: "display_name",
  };

  const search = filters.search.trim();
  if (search) params.search = search;
  if (filters.status !== "all") params.status = filters.status;
  if (filters.tenant) params.tenant = filters.tenant;
  if (filters.tenantAccessScope && filters.tenantAccessScope !== "all") {
    params.tenant_access_scope = filters.tenantAccessScope;
  }
  if (filters.isPlatformAdmin === "true") params.is_platform_admin = true;
  if (filters.isPlatformAdmin === "false") params.is_platform_admin = false;

  return params;
}

function toQueryKeyParams(filters: UsersQueryFilters): Omit<UsersListParams, "offset"> {
  const { offset: _offset, ...params } = toListParams(filters, 0);
  return params;
}

export function flattenUsersPages(data: { pages: UsersPageResult[] } | undefined): UserRow[] {
  return data?.pages.flatMap((page) => page.users) ?? [];
}

export function getUsersTotalCount(data: { pages: UsersPageResult[] } | undefined): number {
  return data?.pages[0]?.count ?? 0;
}

export function useUsersQuery(filters: UsersQueryFilters, enabled = true) {
  const keyParams = toQueryKeyParams(filters);

  return useInfiniteQuery({
    queryKey: usersQueryKeys.list(keyParams),
    enabled,
    initialPageParam: 0,
    queryFn: async ({ pageParam, signal }) => {
      const params = { ...keyParams, offset: pageParam };
      const { data } = await usersApi.list(params, signal);
      const page = data.data;

      return {
        count: page.count,
        next: page.next,
        previous: page.previous,
        users: page.results.map(mapUserApiToRow),
      } satisfies UsersPageResult;
    },
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage.next) return undefined;
      return allPages.reduce((sum, page) => sum + page.users.length, 0);
    },
    placeholderData: keepPreviousData,
  });
}
