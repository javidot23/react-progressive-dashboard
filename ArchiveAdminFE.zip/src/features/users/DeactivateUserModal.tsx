import { Button } from "@/components/atoms";
import { Modal } from "@/components/ui";
import { useDeactivateUserMutation } from "./useUserMutations";
import type { UserRow } from "./users.data";

export type DeactivateUserModalProps = {
  open: boolean;
  user: UserRow | null;
  onClose: () => void;
};

export function DeactivateUserModal({ open, user, onClose }: DeactivateUserModalProps) {
  const deactivateUser = useDeactivateUserMutation();

  const handleConfirm = () => {
    if (!user) return;
    deactivateUser.mutate({ userUuid: user.id, name: user.name }, { onSuccess: () => onClose() });
  };

  return (
    <Modal
      className="!rounded-[1px]"
      open={open}
      title={user ? `Deactivating ${user.name}` : "Deactivate user"}
      titleClassName="font-semibold"
      footerClassName="bg-[#E8E8E8]"
      onClose={onClose}
      tone="danger"
      footer={
        <>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-8 font-bold text-brand-primary-main hover:bg-brand-primary-50"
            onClick={onClose}
            disabled={deactivateUser.isPending}
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-8 border-status-error-main font-bold text-status-error-main bg-transparent hover:bg-status-error-light"
            onClick={handleConfirm}
            disabled={!user || deactivateUser.isPending}
          >
            {deactivateUser.isPending ? "Deactivating…" : "Deactivate"}
          </Button>
        </>
      }
    >
      <p className="font-body-sm text-[length:var(--text-body-sm)] leading-body-sm text-[#3B3B3B]">
        This will set the user status to inactive. They will no longer be able to access the platform until reactivated.
      </p>
    </Modal>
  );
}
