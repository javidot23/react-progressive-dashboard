import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Button } from "@/components/atoms";
import { Drawer, FormField, Input, Select } from "@/components/ui";
import { cn } from "@/utils";
import { useTenantDomainsQuery } from "@/features/tenants/useTenantDomainsQuery";
import { flattenTenantsPages, useTenantsQuery } from "@/features/tenants/useTenantsQuery";
import { useInviteUserMutation } from "./useUserMutations";

export type AddUserDrawerProps = {
  open: boolean;
  onClose: () => void;
  /** When omitted, the drawer asks which tenant the user belongs to. */
  tenantUuid?: string;
  tenantName?: string;
};

type FormStep = "edit" | "review";

type FormValues = {
  firstName: string;
  lastName: string;
  emailLocal: string;
  emailDomain: string;
};

type FieldKey = keyof FormValues;
/** /api/users/invite/ only accepts an email, so the name fields stay optional. */
type RequiredFieldKey = "emailLocal" | "emailDomain";

const DISABLED_FIELD_CLASS = "disabled:bg-[#F5F5F5] disabled:opacity-100";
const INVALID_FIELD_CLASS = "border-status-error-main focus-visible:ring-status-error-main";

function createEmptyValues(): FormValues {
  return { firstName: "", lastName: "", emailLocal: "", emailDomain: "" };
}

function isFormComplete(values: FormValues): boolean {
  return Boolean(values.emailLocal.trim() && values.emailDomain.trim());
}

function hasAnyValue(values: FormValues): boolean {
  return Object.values(values).some((value) => value.trim());
}

export function AddUserDrawer({ open, onClose, tenantUuid, tenantName }: AddUserDrawerProps) {
  const [step, setStep] = useState<FormStep>("edit");
  const [values, setValues] = useState<FormValues>(createEmptyValues);
  const [selectedTenant, setSelectedTenant] = useState("");
  const [touchedFields, setTouchedFields] = useState<Partial<Record<RequiredFieldKey, boolean>>>({});
  const [tenantTouched, setTenantTouched] = useState(false);
  const [showAllErrors, setShowAllErrors] = useState(false);
  const hydratedOpenRef = useRef(false);

  const inviteUser = useInviteUserMutation();
  const needsTenantSelect = !tenantUuid;
  const resolvedTenant = tenantUuid || selectedTenant;

  const tenantsQuery = useTenantsQuery(
    { search: "", tenantType: "all", entitlement: "all", status: "active", limit: 100 },
    open && needsTenantSelect,
  );
  const domainsQuery = useTenantDomainsQuery(open ? resolvedTenant || undefined : undefined);

  const tenantOptions = useMemo(
    () => flattenTenantsPages(tenantsQuery.data).map((tenant) => ({ value: tenant.id, label: tenant.name })),
    [tenantsQuery.data],
  );

  const domainOptions = useMemo(
    () =>
      (domainsQuery.data ?? [])
        .map((entry) => (entry?.domain ?? "").trim().replace(/^@+/, ""))
        .filter(Boolean)
        .map((domain) => ({ value: domain, label: `@${domain}` })),
    [domainsQuery.data],
  );

  useEffect(() => {
    if (!open) {
      hydratedOpenRef.current = false;
      return;
    }
    if (hydratedOpenRef.current) return;
    setValues(createEmptyValues());
    setSelectedTenant("");
    setStep("edit");
    setTouchedFields({});
    setTenantTouched(false);
    setShowAllErrors(false);
    hydratedOpenRef.current = true;
  }, [open]);

  const isEditing = step === "edit";
  const fieldsDisabled = !isEditing;
  const isComplete = isFormComplete(values) && Boolean(resolvedTenant);
  const canReview = (hasAnyValue(values) || Boolean(selectedTenant)) && !inviteUser.isPending;
  const email = isFormComplete(values) ? `${values.emailLocal.trim()}@${values.emailDomain.trim()}` : "";
  const resolvedTenantName = tenantName || tenantOptions.find((option) => option.value === resolvedTenant)?.label;

  const updateField = (key: FieldKey, value: string) => {
    setValues((current) => ({ ...current, [key]: value }));
  };

  const markTouched = (key: RequiredFieldKey) => {
    setTouchedFields((current) => ({ ...current, [key]: true }));
  };

  const errorFor = (key: RequiredFieldKey): string | undefined => {
    if (!isEditing) return undefined;
    if (!showAllErrors && !touchedFields[key]) return undefined;
    if (values[key].trim()) return undefined;
    return "This field is required";
  };

  const selectTenant = (value: string) => {
    setSelectedTenant(value);
    // Allowed domains are per tenant, so a previous pick no longer applies.
    setValues((current) => ({ ...current, emailDomain: "" }));
  };

  const tenantError = isEditing && (showAllErrors || tenantTouched) && !resolvedTenant ? "This field is required" : undefined;

  const goToReview = () => {
    if (!isComplete) {
      setShowAllErrors(true);
      return;
    }
    setShowAllErrors(false);
    setStep("review");
  };

  /** Sole path that invites the user — never reached from Review User. */
  const persistUser = () => {
    if (step !== "review" || !isComplete || !resolvedTenant || inviteUser.isPending) return;

    inviteUser.mutate({ email, tenant_uuid: resolvedTenant, tenantName: resolvedTenantName }, { onSuccess: () => onClose() });
  };

  const blockNativeSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  };

  const controlClass = (hasError: boolean) =>
    cn(fieldsDisabled ? DISABLED_FIELD_CLASS : undefined, hasError ? INVALID_FIELD_CLASS : undefined);

  const emailError = errorFor("emailLocal") ?? errorFor("emailDomain");

  let footer: ReactNode;
  if (isEditing) {
    footer = (
      <>
        <Button type="button" variant="outline_bold" size="sm" className="h-8" onClick={onClose} disabled={inviteUser.isPending}>
          Cancel
        </Button>
        <Button type="button" size="sm" className="h-8" disabled={!canReview} onClick={goToReview}>
          Review User
        </Button>
      </>
    );
  } else {
    footer = (
      <>
        <Button
          type="button"
          variant="outline_bold"
          size="sm"
          className="h-8"
          onClick={() => setStep("edit")}
          disabled={inviteUser.isPending}
        >
          Back
        </Button>
        <Button type="button" size="sm" className="h-8" disabled={!isComplete || inviteUser.isPending} onClick={persistUser}>
          {inviteUser.isPending ? "Adding…" : "Add User"}
        </Button>
      </>
    );
  }

  return (
    <Drawer open={open} title="Add User" onClose={onClose} footer={footer}>
      <form id="add-user-form" className="space-y-4" onSubmit={blockNativeSubmit} noValidate>
        <section className="rounded-lg border border-[#E8E8E8] bg-white p-4">
          <h3 className="mb-2 text-lg font-normal tracking-normal text-[#0F172A]">User Details</h3>
          {resolvedTenantName ? (
            <p className="mb-4 font-body-sm text-[length:var(--text-body-sm)] leading-body-sm italic text-ui-text-secondary">
              This user will be invited to {resolvedTenantName}. Only domains allowed for this tenant can be used.
            </p>
          ) : null}
          <hr className="mb-4" />

          <div className="space-y-4">
            {needsTenantSelect ? (
              <FormField id="add-user-tenant" label="Tenant" required={isEditing} error={tenantError}>
                <Select
                  id="add-user-tenant"
                  value={selectedTenant}
                  onChange={(event) => selectTenant(event.target.value)}
                  onBlur={() => setTenantTouched(true)}
                  options={tenantOptions}
                  placeholder={tenantsQuery.isLoading ? "Loading…" : "Select tenant"}
                  required={isEditing}
                  disabled={fieldsDisabled || tenantsQuery.isLoading}
                  aria-invalid={Boolean(tenantError)}
                  className={controlClass(Boolean(tenantError))}
                />
              </FormField>
            ) : null}

            <FormField id="add-user-first-name" label="First Name">
              <Input
                id="add-user-first-name"
                value={values.firstName}
                onChange={(event) => updateField("firstName", event.target.value)}
                placeholder="John"
                disabled={fieldsDisabled}
                className={controlClass(false)}
              />
            </FormField>

            <FormField id="add-user-last-name" label="Last Name">
              <Input
                id="add-user-last-name"
                value={values.lastName}
                onChange={(event) => updateField("lastName", event.target.value)}
                placeholder="Doe"
                disabled={fieldsDisabled}
                className={controlClass(false)}
              />
            </FormField>

            <FormField id="add-user-email-local" label="Primary Email" required={isEditing} error={emailError}>
              <div className="flex items-center gap-2">
                <Input
                  id="add-user-email-local"
                  value={values.emailLocal}
                  onChange={(event) => updateField("emailLocal", event.target.value)}
                  onBlur={() => markTouched("emailLocal")}
                  placeholder="john.doe"
                  required={isEditing}
                  disabled={fieldsDisabled}
                  aria-invalid={Boolean(errorFor("emailLocal"))}
                  className={controlClass(Boolean(errorFor("emailLocal")))}
                />
                <span className="shrink-0 text-sm font-medium text-ui-text-heading" aria-hidden>
                  @
                </span>
                <Select
                  id="add-user-email-domain"
                  aria-label="Email domain"
                  value={values.emailDomain}
                  onChange={(event) => updateField("emailDomain", event.target.value)}
                  onBlur={() => markTouched("emailDomain")}
                  options={domainOptions}
                  placeholder={domainsQuery.isLoading ? "Loading…" : "Select"}
                  required={isEditing}
                  disabled={fieldsDisabled || !resolvedTenant || domainsQuery.isLoading}
                  aria-invalid={Boolean(errorFor("emailDomain"))}
                  className={controlClass(Boolean(errorFor("emailDomain")))}
                />
              </div>
            </FormField>

            {isEditing && resolvedTenant && !domainsQuery.isLoading && domainOptions.length === 0 ? (
              <p className="text-xs text-ui-text-secondary">
                This tenant has no allowed domains yet. Add a domain to the tenant before inviting users.
              </p>
            ) : null}
          </div>
        </section>
      </form>
    </Drawer>
  );
}
