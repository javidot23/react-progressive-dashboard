import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/app/providers";
import { Button } from "@/components/ui";

import Logo from "@/assets/icons/white-logo.svg";
// import CopyrightIcon from "@/assets/icons/c-icon.svg";

export function LoginPage() {
  const { login, isAuthenticated, isLoading, error } = useAuth();
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();

  const from = (location.state as { from?: string } | null)?.from ?? "/";

  useEffect(() => {
    if (isAuthenticated && !isLoading) {
      navigate(from, { replace: true });
    }
  }, [isAuthenticated, isLoading, navigate, from]);

  const handleLogin = () => {
    setIsLoggingIn(true);
    login();
  };

  if (isLoading) {
    return (
      <div className="relative min-h-screen overflow-hidden bg-[url('/src/public/images/login-disclaimer-bg.jpg')] bg-cover bg-center bg-no-repeat">
        <div className="relative z-10 flex min-h-screen flex-col items-center justify-center px-4">
          <div className="h-20 w-20 animate-spin rounded-full border-b-2 border-white sm:h-32 sm:w-32" />
          <p className="mt-4 px-4 text-center text-sm text-white sm:text-base">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-[url('/src/public/images/login-disclaimer-bg.jpg')] bg-cover bg-center bg-no-repeat">
      <div className="relative z-10 flex min-h-screen flex-col items-center justify-center px-4 sm:px-6">
        <div className="mb-4 sm:mb-6">
          <img src={Logo} alt="Stratium" width={224} height={32} className="my-5 h-auto w-[160px] sm:w-[200px] md:w-[224px]" />
        </div>

        <div className="flex min-h-[160px] w-full max-w-[340px] flex-col space-y-4 rounded-md bg-white px-4 py-5 shadow-xl sm:max-w-[420px] sm:space-y-6 sm:px-6 sm:py-6 md:max-w-[491px] md:px-8">
          <h1 className="text-base font-semibold text-[#1E1E1E] sm:text-lg">Log in</h1>

          {error && (
            <div className="rounded border-l-4 border-red-400 bg-red-50 p-3 sm:p-4" role="alert">
              <p className="text-xs text-red-700 sm:text-sm">{error}</p>
            </div>
          )}

          <Button
            type="button"
            size="lg"
            onClick={handleLogin}
            disabled={isLoggingIn}
            className="w-full bg-brand-primary-main py-2.5 text-white hover:bg-brand-primary-dark disabled:cursor-not-allowed disabled:opacity-50 sm:py-3"
          >
            <div className="flex items-center gap-2 font-bold text-sm sm:text-base">
              {isLoggingIn && <div className="h-5 w-5 animate-spin rounded-full border-b-2 border-white" />}
              <span>{isLoggingIn ? "Signing in..." : "Continue with Microsoft Entra ID"}</span>
            </div>
          </Button>

          <p className="text-center text-xs font-medium leading-relaxed text-[#3B3B3B] sm:text-sm">
            Contact your site administrator to request access.
          </p>
        </div>
      </div>

      {/* <div className="absolute bottom-4 left-4 right-4 sm:bottom-4 sm:left-7 sm:right-auto">
        <p className="flex items-center justify-center gap-1 text-xs text-[#838383] sm:justify-start sm:text-sm">
          <img
            src={CopyrightIcon}
            alt="Copyright"
            width={15}
            className="w-[12px] sm:w-[15px]"
          />
          <span>All rights reserved to Cencora, Inc.</span>
        </p>
      </div> */}
    </div>
  );
}

export default LoginPage;
