import { PageHeader, Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui";
import { useUiStore, type ThemePreference } from "@/stores";

const themes: { value: ThemePreference; label: string }[] = [
  { value: "light", label: "Light" },
  { value: "dark", label: "Dark" },
  { value: "system", label: "System" },
];

export function SettingsPage() {
  const theme = useUiStore((state) => state.theme);
  const setTheme = useUiStore((state) => state.setTheme);

  return (
    <div>
      <PageHeader title="Settings" description="Application preferences for the admin console." />

      <div className="grid gap-4 max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Theme preference is stored in client UI state (Zustand).</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {themes.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setTheme(option.value)}
                  className={
                    theme === option.value
                      ? "rounded-md bg-brand-600 px-3 py-2 text-sm text-white"
                      : "rounded-md border border-surface-300 bg-white px-3 py-2 text-sm text-surface-900 hover:bg-surface-50"
                  }
                >
                  {option.label}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Environment</CardTitle>
            <CardDescription>Build and API configuration (read-only).</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-surface-700">
            <p>
              <span className="font-medium text-surface-900">API URL:</span> {import.meta.env.VITE_API_URL}
            </p>
            <p>
              <span className="font-medium text-surface-900">Mode:</span> {import.meta.env.MODE}
            </p>
            {/* <p>
              <span className="font-medium text-surface-900">Version:</span> {__APP_VERSION__}
            </p> */}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
