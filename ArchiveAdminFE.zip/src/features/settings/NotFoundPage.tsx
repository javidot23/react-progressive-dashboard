import { Link } from "react-router-dom";
import { Button } from "@/components/ui";

export function NotFoundPage() {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-4 text-center">
      <p className="text-sm font-medium uppercase tracking-wide text-brand-primary-main">404</p>
      <h1 className="text-2xl font-semibold text-ui-text-heading">Page not found</h1>
      <p className="max-w-md text-sm text-ui-text-primary">The page you requested does not exist or may have been moved.</p>
      <Link to="/">
        <Button>Back to Dashboard</Button>
      </Link>
    </div>
  );
}
