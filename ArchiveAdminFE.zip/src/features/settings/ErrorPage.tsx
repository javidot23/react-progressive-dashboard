import { Link } from "react-router-dom";
import { Button } from "@/components/ui";

export function ErrorPage() {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-4 text-center">
      <p className="text-sm font-medium uppercase tracking-wide text-status-error-main">Error</p>
      <h1 className="text-2xl font-semibold text-ui-text-heading">Something went wrong</h1>
      <p className="max-w-md text-sm text-ui-text-primary">
        An unexpected error occurred while loading this page. Please try again later.
      </p>
      <div className="flex gap-2">
        <Button onClick={() => window.location.reload()}>Reload</Button>
        <Link to="/">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
}
