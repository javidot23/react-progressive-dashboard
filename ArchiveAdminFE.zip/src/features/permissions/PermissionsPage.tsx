import { PageHeader, Table, TableHead, TableBody, TableRow, TableHeaderCell, TableCell, Button } from "@/components/ui";

export function PermissionsPage() {
  return (
    <div>
      <PageHeader
        title="Permissions"
        description="Configure fine-grained access permissions."
        actions={<Button disabled>Add permission</Button>}
      />
      <Table>
        <TableHead>
          <TableRow>
            <TableHeaderCell>Permission</TableHeaderCell>
            <TableHeaderCell>Resource</TableHeaderCell>
            <TableHeaderCell>Action</TableHeaderCell>
            <TableHeaderCell>Actions</TableHeaderCell>
          </TableRow>
        </TableHead>
        <TableBody>
          <TableRow>
            <TableCell colSpan={4} className="py-10 text-center text-ui-text-primary">
              No permissions yet. Permission catalog will appear here.
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </div>
  );
}
