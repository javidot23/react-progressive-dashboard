import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/atoms";
import { DataGridInfiniteScroll, DataGridShell, DataGridTable, useDataGrid } from "@/components/organisms/DataGrid";
import { PageHeader, SearchInput, Select } from "@/components/ui";
import { useDocumentTitle } from "@/hooks";
import { ROUTES } from "@/constants/routes";
import {
  AUDIT_EVENT_TYPE_OPTIONS,
  USER_STATUS_OPTIONS,
  type AuditEventTypeEnum,
  type UserStatusEnum,
} from "@/services/api/enums";
import { createAuditLogColumns, flattenAuditLogsPages, getAuditLogsTotalCount, useAuditLogsQuery } from "@/features/audit";
import { DeactivateUserModal } from "@/features/users/DeactivateUserModal";
import { InviteUserDrawer } from "@/features/users/InviteUserDrawer";
import { EditUserDrawer } from "@/features/users/EditUserDrawer";
import { createUserColumns } from "@/features/users/users.columns";
import type { UserRow } from "@/features/users/users.data";
import { flattenUsersPages, getUsersTotalCount, useUsersQuery } from "@/features/users/useUsersQuery";
import { mapTenantApiToRow } from "@/features/tenants/tenants.data";
import { useTenantDetailQuery } from "@/features/tenants/useTenantDetailQuery";
import { cn } from "@/utils";

type TenantDetailTab = "users" | "audit";

export function TenantDetailPage() {
  const { tenantUuid = "" } = useParams<{ tenantUuid: string }>();
  const {
    data: tenant,
    isLoading: tenantLoading,
    isError: tenantError,
    refetch: refetchTenant,
  } = useTenantDetailQuery(tenantUuid);

  const tenantRow = tenant ? mapTenantApiToRow(tenant) : null;
  const [activeTab, setActiveTab] = useState<TenantDetailTab>("users");

  useDocumentTitle(tenantRow?.name ? `${tenantRow.name} · ${activeTab === "users" ? "Users" : "Audit Log"}` : "Tenant");

  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | UserStatusEnum>("all");
  const [eventTypeFilter, setEventTypeFilter] = useState<"all" | AuditEventTypeEnum>("all");
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserRow | null>(null);
  const [deactivatingUser, setDeactivatingUser] = useState<UserRow | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => setSearch(searchInput), 300);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const usersQuery = useUsersQuery(
    {
      search,
      status: statusFilter,
      tenant: tenantUuid || undefined,
      tenantAccessScope: "tenant",
    },
    Boolean(tenantUuid),
  );

  const auditQuery = useAuditLogsQuery(
    {
      tenant: tenantUuid || undefined,
      auditEventType: eventTypeFilter === "all" ? undefined : eventTypeFilter,
    },
    Boolean(tenantUuid) && activeTab === "audit",
  );

  const users = useMemo(() => flattenUsersPages(usersQuery.data), [usersQuery.data]);
  const auditLogs = useMemo(() => flattenAuditLogsPages(auditQuery.data), [auditQuery.data]);
  const usersTotalCount = getUsersTotalCount(usersQuery.data);
  const auditTotalCount = getAuditLogsTotalCount(auditQuery.data);

  const userColumns = useMemo(
    () =>
      createUserColumns({
        onEdit: setEditingUser,
        onDeactivate: setDeactivatingUser,
        showNameParts: true,
        // DO NOT DELETE — department / job title columns are skipped for now; restore when we surface them again.
        showDepartment: false,
        showJobTitle: false,
        // showDepartment: true,
        // showJobTitle: true,
      }),
    [],
  );

  const auditColumns = useMemo(() => createAuditLogColumns(), []);

  const { table: usersTable } = useDataGrid({
    data: users,
    columns: userColumns,
    getRowId: (row) => row.id,
    enableSorting: false,
  });

  const { table: auditTable } = useDataGrid({
    data: auditLogs,
    columns: auditColumns,
    getRowId: (row) => row.id,
    enableSorting: false,
  });

  if (tenantError) {
    return (
      <div className="flex flex-col gap-4">
        <Link to={ROUTES.TENANTS} className="inline-flex items-center gap-2 text-sm text-brand-primary-main hover:underline">
          <ArrowLeft className="h-4 w-4" aria-hidden />
          Go back
        </Link>
        <p className="text-sm text-status-error-main">Failed to load tenant.</p>
        <Button type="button" className="h-8 w-fit" onClick={() => void refetchTenant()}>
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-3">
        <Link
          to={ROUTES.TENANTS}
          className="inline-flex w-fit items-center gap-2 text-sm text-brand-primary-main hover:underline"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden />
          Go back
        </Link>

        <PageHeader
          title={tenantLoading ? "Loading…" : (tenantRow?.name ?? "Tenant")}
          description={
            tenantRow ? (
              <span className="inline-flex items-center gap-2">
                {/* <StatusBadge status={tenantRow.status} className="w-auto px-3" /> */}
                <span className="text-sm font-medium text-[#6E6E6E]">{tenantRow.entitlement}</span>
              </span>
            ) : undefined
          }
          actions={
            activeTab === "users" ? (
              <Button type="button" className="h-8" onClick={() => setIsInviteOpen(true)} disabled={!tenantUuid}>
                Invite User
              </Button>
            ) : undefined
          }
        />
      </div>
      <hr className="" />

      <div className="w-fit border-b border-ui-border-secondary">
        <nav className="-mb-px flex gap-6" aria-label="Tenant sections">
          <button
            type="button"
            className={cn(
              "px-4 pb-2 text-sm",
              activeTab === "users"
                ? "border-b-2 border-brand-primary-main font-semibold text-brand-primary-main"
                : "font-medium text-ui-text-secondary hover:text-ui-text-heading",
            )}
            aria-current={activeTab === "users" ? "page" : undefined}
            onClick={() => setActiveTab("users")}
          >
            Users
          </button>
          <button
            type="button"
            className={cn(
              "px-4 pb-2 text-sm",
              activeTab === "audit"
                ? "border-b-2 border-brand-primary-main font-semibold text-brand-primary-main"
                : "font-medium text-ui-text-secondary hover:text-ui-text-heading",
            )}
            aria-current={activeTab === "audit" ? "page" : undefined}
            onClick={() => setActiveTab("audit")}
          >
            Audit Log
          </button>
        </nav>
      </div>

      {activeTab === "users" ? (
        <>
          <div className="flex w-full flex-col items-center gap-3 md:flex-row">
            <form
              className="min-w-0 w-full flex-1 md:flex-2"
              onSubmit={(event) => {
                event.preventDefault();
                setSearch(searchInput.trim());
              }}
              role="search"
            >
              <label htmlFor="tenant-user-search" className="sr-only">
                Search users
              </label>
              <SearchInput
                id="tenant-user-search"
                value={searchInput}
                onChange={(event) => setSearchInput(event.target.value)}
                placeholder="Search users"
                aria-label="Search users"
              />
            </form>

            <Select
              id="tenant-user-status-filter"
              aria-label="Status"
              containerClassName="min-w-0 flex-1"
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value as "all" | UserStatusEnum)}
              options={[{ value: "all", label: "All Statuses" }, ...USER_STATUS_OPTIONS]}
            />
          </div>

          <DataGridShell table={usersTable} size="sm" variant="plain" className="rounded-lg bg-white">
            <DataGridTable
              table={usersTable}
              emptyMessage="No users in this tenant."
              minWidth={900}
              isLoading={usersQuery.isLoading || tenantLoading}
              isUpdating={usersQuery.isFetching && !usersQuery.isLoading && !usersQuery.isFetchingNextPage}
              isError={usersQuery.isError}
              onRetry={() => void usersQuery.refetch()}
            />
            <DataGridInfiniteScroll
              hasNextPage={Boolean(usersQuery.hasNextPage)}
              isFetchingNextPage={usersQuery.isFetchingNextPage}
              loadedCount={users.length}
              totalCount={usersTotalCount}
              fetchNextPage={() => {
                void usersQuery.fetchNextPage();
              }}
            />
          </DataGridShell>
        </>
      ) : (
        <>
          <div className="flex w-full flex-col items-center gap-3 md:flex-row md:justify-end">
            <Select
              id="tenant-audit-event-type-filter"
              aria-label="Event Type"
              containerClassName="min-w-0 w-full md:max-w-xs"
              value={eventTypeFilter}
              onChange={(event) => setEventTypeFilter(event.target.value as "all" | AuditEventTypeEnum)}
              options={[{ value: "all", label: "All Event Types" }, ...AUDIT_EVENT_TYPE_OPTIONS]}
            />
          </div>

          <DataGridShell table={auditTable} size="sm" variant="plain" className="rounded-lg bg-white">
            <DataGridTable
              table={auditTable}
              emptyMessage="No audit events for this tenant."
              minWidth={900}
              isLoading={auditQuery.isLoading}
              isUpdating={auditQuery.isFetching && !auditQuery.isLoading && !auditQuery.isFetchingNextPage}
              isError={auditQuery.isError}
              onRetry={() => void auditQuery.refetch()}
            />
            <DataGridInfiniteScroll
              hasNextPage={Boolean(auditQuery.hasNextPage)}
              isFetchingNextPage={auditQuery.isFetchingNextPage}
              loadedCount={auditLogs.length}
              totalCount={auditTotalCount}
              fetchNextPage={() => {
                void auditQuery.fetchNextPage();
              }}
            />
          </DataGridShell>
        </>
      )}

      <InviteUserDrawer
        open={isInviteOpen}
        onClose={() => setIsInviteOpen(false)}
        tenantUuid={tenantUuid}
        tenantName={tenantRow?.name}
      />
      <EditUserDrawer open={Boolean(editingUser)} user={editingUser} onClose={() => setEditingUser(null)} />
      <DeactivateUserModal open={Boolean(deactivatingUser)} user={deactivatingUser} onClose={() => setDeactivatingUser(null)} />
    </div>
  );
}
