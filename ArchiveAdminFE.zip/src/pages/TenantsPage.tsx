import { useCallback, useEffect, useMemo, useState } from "react";
import type { RowSelectionState } from "@tanstack/react-table";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/atoms";
import { DataGridInfiniteScroll, DataGridShell, DataGridTable, useDataGrid } from "@/components/organisms/DataGrid";
import { PageHeader, SearchInput, Select } from "@/components/ui";
import { useDocumentTitle } from "@/hooks";
import { ROUTES } from "@/constants/routes";
import {
  ENTITLEMENT_TIER_OPTIONS,
  TENANT_TYPE_OPTIONS,
  type EntitlementTierEnum,
  type TenantTypeEnum,
} from "@/services/api/enums";
import { AddUserDrawer } from "@/features/users/AddUserDrawer";
import { MultiTenantUserDrawer } from "@/features/users/MultiTenantUserDrawer";
import { AddTenantModal } from "@/features/tenants/AddTenantModal";
import { DeactivateTenantModal } from "@/features/tenants/DeactivateTenantModal";
import { EditTenantModal } from "@/features/tenants/EditTenantModal";
import { createTenantColumns } from "@/features/tenants/tenants.columns";
import type { Tenant } from "@/features/tenants/tenants.data";
import { flattenTenantsPages, getTenantsTotalCount, useTenantsQuery } from "@/features/tenants/useTenantsQuery";

export function TenantsPage() {
  useDocumentTitle("Tenants");
  const navigate = useNavigate();

  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | TenantTypeEnum>("all");
  const [entitlementFilter, setEntitlementFilter] = useState<"all" | EntitlementTierEnum>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all");
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const [isAddTenantOpen, setIsAddTenantOpen] = useState(false);
  const [isMultiTenantUserOpen, setIsMultiTenantUserOpen] = useState(false);
  const [addUserTenant, setAddUserTenant] = useState<Tenant | null>(null);
  const [editTenantUuid, setEditTenantUuid] = useState<string | null>(null);
  const [deactivateTenant, setDeactivateTenant] = useState<Tenant | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => setSearch(searchInput), 300);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const { data, isLoading, isFetching, isFetchingNextPage, hasNextPage, fetchNextPage, isError, refetch } = useTenantsQuery({
    search,
    tenantType: typeFilter,
    entitlement: entitlementFilter,
    status: statusFilter,
  });

  const tenants = useMemo(() => flattenTenantsPages(data), [data]);
  const organizationCount = getTenantsTotalCount(data);

  const columns = useMemo(
    () =>
      createTenantColumns({
        onAddUser: setAddUserTenant,
        onEdit: (tenant) => setEditTenantUuid(tenant.id),
        onDeactivate: setDeactivateTenant,
      }),
    [],
  );

  const { table } = useDataGrid({
    data: tenants,
    columns,
    getRowId: (row) => row.id,
    enableSorting: false,
    enableRowSelection: true,
    enableMultiRowSelection: false,
    onRowSelectionChange: setRowSelection,
    state: { rowSelection },
  });

  const handleRowClick = useCallback(
    (tenant: Tenant) => {
      setRowSelection({ [tenant.id]: true });
      navigate(ROUTES.tenantDetail(tenant.id));
    },
    [navigate],
  );

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Tenants"
        description={isLoading ? "Loading organizations…" : `${organizationCount} Organizations`}
        actions={
          <>
            <Button type="button" className="h-8" onClick={() => setIsAddTenantOpen(true)}>
              Add Tenant
            </Button>
            <Button type="button" variant="outline" className="h-8" onClick={() => setIsMultiTenantUserOpen(true)}>
              Add Multi Tenant User
            </Button>
          </>
        }
      />
      <hr />
      <div className="flex w-full flex-col items-center gap-3 md:flex-row">
        <form
          className="min-w-0 w-full flex-1 md:flex-2"
          onSubmit={(event) => {
            event.preventDefault();
            setSearch(searchInput.trim());
          }}
          role="search"
        >
          <label htmlFor="tenant-search" className="sr-only">
            Search Tenants
          </label>
          <SearchInput
            id="tenant-search"
            value={searchInput}
            onChange={(event) => setSearchInput(event.target.value)}
            placeholder="Search Tenants"
            aria-label="Search tenants"
          />
        </form>

        <Select
          id="tenant-type-filter"
          aria-label="Tenant type"
          containerClassName="min-w-0 flex-1"
          value={typeFilter}
          onChange={(event) => setTypeFilter(event.target.value as "all" | TenantTypeEnum)}
          options={[{ value: "all", label: "All Types" }, ...TENANT_TYPE_OPTIONS]}
        />
        <Select
          id="tenant-entitlement-filter"
          aria-label="Entitlement"
          containerClassName="min-w-0 flex-1"
          value={entitlementFilter}
          onChange={(event) => setEntitlementFilter(event.target.value as "all" | EntitlementTierEnum)}
          options={[{ value: "all", label: "All Entitlements" }, ...ENTITLEMENT_TIER_OPTIONS]}
        />
        <Select
          id="tenant-status-filter"
          aria-label="Status"
          containerClassName="min-w-0 flex-1"
          value={statusFilter}
          onChange={(event) => setStatusFilter(event.target.value as "all" | "active" | "inactive")}
          options={[
            { value: "all", label: "All Status" },
            { value: "active", label: "Active" },
            { value: "inactive", label: "Deactivated" },
          ]}
        />
      </div>

      <DataGridShell table={table} size="sm" variant="plain" className="rounded-lg bg-white">
        <DataGridTable
          table={table}
          emptyMessage="No tenants match your filters."
          minWidth={980}
          bodyClassName="min-h-[600px]"
          isLoading={isLoading}
          isUpdating={isFetching && !isLoading && !isFetchingNextPage}
          isError={isError}
          onRetry={() => void refetch()}
          onRowClick={handleRowClick}
          getRowAriaLabel={(tenant) => `Open ${tenant.name}`}
        />
        <DataGridInfiniteScroll
          hasNextPage={Boolean(hasNextPage)}
          isFetchingNextPage={isFetchingNextPage}
          loadedCount={tenants.length}
          totalCount={organizationCount}
          fetchNextPage={() => {
            void fetchNextPage();
          }}
        />
      </DataGridShell>

      <AddTenantModal open={isAddTenantOpen} onClose={() => setIsAddTenantOpen(false)} />
      <MultiTenantUserDrawer open={isMultiTenantUserOpen} onClose={() => setIsMultiTenantUserOpen(false)} />
      <AddUserDrawer
        open={Boolean(addUserTenant)}
        tenantUuid={addUserTenant?.id}
        tenantName={addUserTenant?.name}
        onClose={() => setAddUserTenant(null)}
      />
      <EditTenantModal open={Boolean(editTenantUuid)} tenantUuid={editTenantUuid} onClose={() => setEditTenantUuid(null)} />
      <DeactivateTenantModal
        open={Boolean(deactivateTenant)}
        tenant={deactivateTenant}
        onClose={() => setDeactivateTenant(null)}
      />
    </div>
  );
}
