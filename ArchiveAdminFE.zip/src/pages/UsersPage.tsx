import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/atoms";
import { DataGridInfiniteScroll, DataGridShell, DataGridTable, useDataGrid } from "@/components/organisms/DataGrid";
import { PageHeader, SearchInput, Select } from "@/components/ui";
import { useDocumentTitle } from "@/hooks";
import { USER_STATUS_OPTIONS, type UserStatusEnum } from "@/services/api/enums";
import { AddUserDrawer } from "@/features/users/AddUserDrawer";
import { DeactivateUserModal } from "@/features/users/DeactivateUserModal";
import { EditUserDrawer } from "@/features/users/EditUserDrawer";
import { MultiTenantUserDrawer } from "@/features/users/MultiTenantUserDrawer";
import { createUserColumns } from "@/features/users/users.columns";
import type { UserRow } from "@/features/users/users.data";
import { flattenUsersPages, getUsersTotalCount, useUsersQuery } from "@/features/users/useUsersQuery";
import { cn } from "@/utils";

type UsersTab = "tenant" | "internal";

export function UsersPage() {
  useDocumentTitle("Users");

  const [activeTab, setActiveTab] = useState<UsersTab>("tenant");
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | UserStatusEnum>("all");
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [isMultiTenantUserOpen, setIsMultiTenantUserOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserRow | null>(null);
  const [deactivatingUser, setDeactivatingUser] = useState<UserRow | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => setSearch(searchInput), 300);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const { data, isLoading, isFetching, isFetchingNextPage, hasNextPage, fetchNextPage, isError, refetch } = useUsersQuery({
    search,
    status: statusFilter,
    // Tenant Users always requests tenant-scoped users only (not a UI filter).
    tenantAccessScope: activeTab === "tenant" ? "tenant" : "all_tenants",
  });

  const users = useMemo(() => flattenUsersPages(data), [data]);
  const userCount = getUsersTotalCount(data);

  const columns = useMemo(
    () =>
      createUserColumns({
        onEdit: setEditingUser,
        onDeactivate: setDeactivatingUser,
        showPlatformFields: true,
        showDepartment: false,
        showJobTitle: false,
      }),
    [],
  );

  const { table } = useDataGrid({
    data: users,
    columns,
    getRowId: (row) => row.id,
    enableSorting: false,
  });

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Users"
        description={isLoading ? "Loading users…" : `${userCount} users`}
        actions={
          activeTab === "tenant" ? (
            <Button type="button" className="h-8" onClick={() => setIsInviteOpen(true)}>
              Invite User
            </Button>
          ) : (
            <Button type="button" className="h-8" onClick={() => setIsMultiTenantUserOpen(true)}>
              Add Multi Tenant User
            </Button>
          )
        }
      />

      <div className="w-fit border-b border-ui-border-secondary">
        <nav className="-mb-px flex gap-6" aria-label="User sections">
          <button
            type="button"
            className={cn(
              "px-4 pb-2 text-sm",
              activeTab === "tenant"
                ? "border-b-2 border-brand-primary-main font-semibold text-brand-primary-main"
                : "font-medium text-ui-text-secondary hover:text-ui-text-heading",
            )}
            aria-current={activeTab === "tenant" ? "page" : undefined}
            onClick={() => setActiveTab("tenant")}
          >
            Tenant Users
          </button>
          <button
            type="button"
            className={cn(
              "px-4 pb-2 text-sm",
              activeTab === "internal"
                ? "border-b-2 border-brand-primary-main font-semibold text-brand-primary-main"
                : "font-medium text-ui-text-secondary hover:text-ui-text-heading",
            )}
            aria-current={activeTab === "internal" ? "page" : undefined}
            onClick={() => setActiveTab("internal")}
          >
            Internal Users
          </button>
        </nav>
      </div>

      <div className="flex w-full flex-col items-center gap-3 md:flex-row">
        <form
          className="min-w-0 w-full flex-1 md:flex-2"
          onSubmit={(event) => {
            event.preventDefault();
            setSearch(searchInput.trim());
          }}
          role="search"
        >
          <label htmlFor="user-search" className="sr-only">
            Search users
          </label>
          <SearchInput
            id="user-search"
            value={searchInput}
            onChange={(event) => setSearchInput(event.target.value)}
            placeholder="Search users"
            aria-label="Search users"
          />
        </form>

        <Select
          id="user-status-filter"
          aria-label="Status"
          containerClassName="min-w-0 flex-1"
          value={statusFilter}
          onChange={(event) => setStatusFilter(event.target.value as "all" | UserStatusEnum)}
          options={[{ value: "all", label: "All Statuses" }, ...USER_STATUS_OPTIONS]}
        />
      </div>

      <DataGridShell table={table} size="sm" variant="plain" className="rounded-lg bg-white">
        <DataGridTable
          table={table}
          emptyMessage="No users match your filters."
          minWidth={900}
          bodyClassName="min-h-[600px]"
          isLoading={isLoading}
          isUpdating={isFetching && !isLoading && !isFetchingNextPage}
          isError={isError}
          onRetry={() => void refetch()}
        />
        <DataGridInfiniteScroll
          hasNextPage={Boolean(hasNextPage)}
          isFetchingNextPage={isFetchingNextPage}
          loadedCount={users.length}
          totalCount={userCount}
          fetchNextPage={() => {
            void fetchNextPage();
          }}
        />
      </DataGridShell>

      <AddUserDrawer open={isInviteOpen} onClose={() => setIsInviteOpen(false)} />
      <MultiTenantUserDrawer open={isMultiTenantUserOpen} onClose={() => setIsMultiTenantUserOpen(false)} />
      <EditUserDrawer open={Boolean(editingUser)} user={editingUser} onClose={() => setEditingUser(null)} />
      <DeactivateUserModal open={Boolean(deactivatingUser)} user={deactivatingUser} onClose={() => setDeactivatingUser(null)} />
    </div>
  );
}
