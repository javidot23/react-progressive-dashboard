import { PageHeader, Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui";

export function SettingsPage() {
  return (
    <div>
      <PageHeader title="Settings" description="Application preferences for the admin console." />

      <div className="grid gap-4 max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>Environment</CardTitle>
            <CardDescription>Build and API configuration (read-only).</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-surface-700">
            <p>
              <span className="font-medium text-surface-900">API URL:</span> {import.meta.env.VITE_API_URL}
            </p>
            <p>
              <span className="font-medium text-surface-900">Mode:</span> {import.meta.env.MODE}
            </p>
            {/* <p>
              <span className="font-medium text-surface-900">Version:</span> {__APP_VERSION__}
            </p> */}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
