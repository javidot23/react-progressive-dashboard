export const ROUTES = {
  HOME: "/",
  TENANTS: "/",
  TENANT_DETAIL: "/tenants/:tenantUuid",
  USERS: "/users",
  AUDIT_LOG: "/audit-actions", // This will be implemented in the future
  EXPORT_ACTIONS: "/audit-log",
  LOGIN: "/login",
  ERROR: "/error",
  tenantDetail: (tenantUuid: string) => `/tenants/${tenantUuid}`,
} as const;

export type AppRoute = (typeof ROUTES)[keyof typeof ROUTES];
