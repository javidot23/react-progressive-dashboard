/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Django BFF base URL including /api suffix (cookie-session auth). */
  readonly VITE_API_URL: string;
  readonly VITE_APP_VERSION?: string;
  readonly MODE: string;
  readonly DEV: boolean;
  readonly PROD: boolean;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

declare const __BUILD_DATE__: string;
declare const __APP_VERSION__: string;
