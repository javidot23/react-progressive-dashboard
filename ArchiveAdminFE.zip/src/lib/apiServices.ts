import { apiClient } from "@/services/http";

export type UserAction = {
  id: string;
  action?: string;
  material_name?: string;
  vendor_name?: string;
  vendor_nbr?: string;
  created_at: string;
  potential_action?: {
    recommendation: string;
  };
  substituted_material?: {
    vendor_name?: string;
    vendor_nbr?: string;
  };
};

type UserActionsPage = {
  count: number;
  next: string | null;
  previous: string | null;
  results: UserAction[];
};

type ApiEnvelope<T> = {
  success: boolean;
  data: T;
};

export const userActionService = {
  getUserActions: (limit: number, offset: number, date: string) =>
    apiClient.get<ApiEnvelope<UserActionsPage>>("/user-actions/", {
      params: { limit, offset, date },
    }),

  exportUserActions: (startDate: string, endDate: string) =>
    apiClient.get<Blob>("/user-actions/export/", {
      params: { start_date: startDate, end_date: endDate },
      responseType: "blob",
    }),
};
