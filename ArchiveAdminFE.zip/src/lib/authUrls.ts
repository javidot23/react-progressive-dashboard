/**
 * BFF auth navigation URLs — must match axios `baseURL` (VITE_API_URL).
 * Login uses top-level navigation only; never fetch/axios.
 */

import { getApiUrl } from "@/utils/env";

export interface LogoutResponse {
  success?: boolean;
  data?: {
    end_session_url?: string | null;
  };
  end_session_url?: string | null;
}

export function getEndSessionUrl(body: LogoutResponse | null | undefined): string | null {
  const nested = body?.data?.end_session_url;
  if (typeof nested === "string" && nested.length > 0) {
    return nested;
  }
  const flat = body?.end_session_url;
  if (typeof flat === "string" && flat.length > 0) {
    return flat;
  }
  return null;
}

/** Resolved API base (absolute URL, no trailing slash). */
export function getAuthBaseUrl(): string {
  const raw = getApiUrl().replace(/\/$/, "");
  if (/^https?:\/\//i.test(raw)) {
    return raw;
  }
  const path = raw.startsWith("/") ? raw : `/${raw}`;
  return `${window.location.origin}${path}`.replace(/\/$/, "");
}

export function getLoginUrl(): string {
  return `${getAuthBaseUrl()}/login/start/`;
}

export function redirectToLogin(): void {
  window.location.assign(getLoginUrl());
}

/** SPA routes where an unauthenticated /auth/me/ should not auto-redirect to the IdP. */
const PUBLIC_AUTH_PATHS = new Set(["/login"]);

export function isPublicAuthPath(pathname: string = window.location.pathname): boolean {
  return PUBLIC_AUTH_PATHS.has(pathname);
}
