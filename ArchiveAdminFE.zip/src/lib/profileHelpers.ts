import type { AuthMeProfile } from "@/hooks/useProfile";

export function getUserEmail(profile?: AuthMeProfile | null): string {
  return profile?.mail || profile?.userPrincipalName || "";
}

export function getUserFirstName(profile?: AuthMeProfile | null): string {
  const email = getUserEmail(profile);
  if (!profile) return email || "User";

  if (profile.givenName?.trim()) return profile.givenName.trim();
  if (profile.displayName?.trim()) return profile.displayName.trim().split(/\s+/)[0] ?? email;
  return email || "User";
}

export function getUserFullName(profile?: AuthMeProfile | null): string {
  if (!profile) return getUserEmail(profile);
  if (profile.displayName?.trim()) return profile.displayName.trim();
  const fromParts = [profile.givenName, profile.surname].filter(Boolean).join(" ");
  if (fromParts) return fromParts;
  return getUserEmail(profile);
}

export function getUserInitials(
  profile?: {
    givenName?: string;
    surname?: string;
  } | null,
): string {
  const first = profile?.givenName?.[0] ?? "";
  const last = profile?.surname?.[0] ?? "";
  if (!first && !last) return "?";
  return `${first}${last}`;
}
