export { cn } from "@/utils/cn";

const MATERIAL_STATUS_LABELS: Record<string, string> = {
  AC: "Active",
  UM: "Under Monitoring",
  AM: "At Risk",
  NW: "New",
  DB: "Discontinued Buy",
  TM: "Temporarily Unavailable",
  DM: "Discontinued Manufacture",
};

const PRODUCT_CATEGORY_LABELS: Record<string, string> = {
  GRX: "Generic Rx",
  BRX: "Brand Rx",
  OTC: "OTC",
  OTG: "OTC Generics",
  HBC: "Health Beauty Care",
  MSU: "Medical Supplies",
  HHC: "Home Health Care",
};

export function getMaterialStatusDescription(status: string): string {
  return MATERIAL_STATUS_LABELS[status] ?? status;
}

export function getProductCategoryLabel(category: string): string {
  return PRODUCT_CATEGORY_LABELS[category] ?? category;
}
