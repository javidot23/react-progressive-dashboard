import { apiClient } from "@/services/http";

export interface DashboardKpi {
  id: string;
  label: string;
  value: number | string;
  change?: string;
}

export interface DashboardActivityItem {
  id: string;
  description: string;
  timestamp: string;
}

export interface DashboardSummary {
  kpis: DashboardKpi[];
  recentActivity: DashboardActivityItem[];
}

export const dashboardApi = {
  getSummary: (signal?: AbortSignal) => apiClient.get<DashboardSummary>("/admin/dashboard/summary", { signal }),
};
