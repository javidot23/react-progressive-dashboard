import { apiClient } from "@/services/http";
import type { EntitlementTierEnum, TenantTypeEnum } from "./enums";

/** @deprecated Prefer EntitlementTierEnum */
export type EntitlementTierApi = EntitlementTierEnum;
/** @deprecated Prefer TenantTypeEnum */
export type TenantTypeApi = TenantTypeEnum;

export type TenantDomain = {
  tenant_domain_uuid: string;
  domain: string;
  created_at: string;
};

export type TenantApi = {
  tenant_uuid: string;
  tenant_code: string;
  tenant_name: string;
  tenant_type: TenantTypeApi;
  entitlement_tier: EntitlementTierApi;
  metadata: Record<string, unknown> | string;
  database_host: string;
  database_name: string;
  database_port: number;
  database_schema: string;
  database_username: string;
  database_managed_identity_client_id: string;
  is_federated: boolean;
  domains: TenantDomain[];
  is_active: boolean;
  /** Present when API includes membership aggregate. */
  user_count?: number | null;
  created_at: string;
  updated_at: string;
};

export type TenantWritePayload = {
  tenant_code: string;
  tenant_name: string;
  tenant_type: TenantTypeApi;
  entitlement_tier?: EntitlementTierApi;
  metadata?: Record<string, unknown> | string;
  database_host?: string;
  database_name?: string;
  database_port?: number;
  database_schema?: string;
  database_username?: string;
  database_managed_identity_client_id?: string;
  is_federated?: boolean;
  is_active?: boolean;
};

export type TenantsListParams = {
  search?: string;
  tenant_type?: TenantTypeApi;
  entitlement_tier?: EntitlementTierApi;
  is_active?: boolean;
  limit?: number;
  offset?: number;
  ordering?: string;
};

export type TenantsListData = {
  count: number;
  next: string | null;
  previous: string | null;
  results: TenantApi[];
};

export type ApiSuccessResponse<T> = {
  success: boolean;
  data: T;
};

export type TenantsListResponse = ApiSuccessResponse<TenantsListData>;
export type TenantResponse = ApiSuccessResponse<TenantApi>;
export type TenantDomainResponse = ApiSuccessResponse<TenantDomain>;

export type TenantMembershipApi = {
  tenant_membership_uuid: string;
  tenant: string;
  tenant_code: string;
  user: string;
  effective_from: string | null;
  effective_to: string | null;
  is_active: boolean;
  created_at: string;
};

export type TenantMembershipWritePayload = {
  user: string;
  effective_from?: string | null;
  effective_to?: string | null;
  is_active?: boolean;
};

export type TenantMembershipsListData = {
  count: number;
  next: string | null;
  previous: string | null;
  results: TenantMembershipApi[];
};

export type TenantMembershipResponse = ApiSuccessResponse<TenantMembershipApi>;
export type TenantMembershipsListResponse = ApiSuccessResponse<
  TenantMembershipsListData | TenantMembershipApi | TenantMembershipApi[]
>;

function normalizeDomain(domain: string): string {
  return domain.trim().replace(/^@+/, "");
}

export const tenantsApi = {
  list: (params: TenantsListParams = {}, signal?: AbortSignal) =>
    apiClient.get<TenantsListResponse>("/tenants/", { params, signal }),

  get: (tenantUuid: string, signal?: AbortSignal) => apiClient.get<TenantResponse>(`/tenants/${tenantUuid}/`, { signal }),

  create: (payload: TenantWritePayload) => apiClient.post<TenantResponse>("/tenants/", payload),

  update: (tenantUuid: string, payload: Partial<TenantWritePayload>) =>
    apiClient.patch<TenantResponse>(`/tenants/${tenantUuid}/`, payload),

  remove: (tenantUuid: string) => apiClient.delete(`/tenants/${tenantUuid}/`),

  listDomains: (tenantUuid: string, signal?: AbortSignal) =>
    apiClient.get<ApiSuccessResponse<TenantDomain | TenantDomain[]>>(`/tenants/${tenantUuid}/domains/`, { signal }),

  addDomain: (tenantUuid: string, domain: string) =>
    apiClient.post<TenantDomainResponse>(`/tenants/${tenantUuid}/domains/`, {
      domain: normalizeDomain(domain),
    }),

  removeDomain: (tenantUuid: string, domainUuid: string) => apiClient.delete(`/tenants/${tenantUuid}/domains/${domainUuid}/`),

  listMemberships: (tenantUuid: string, signal?: AbortSignal) =>
    apiClient.get<TenantMembershipsListResponse>(`/tenants/${tenantUuid}/memberships/`, { signal }),

  addMembership: (tenantUuid: string, payload: TenantMembershipWritePayload) =>
    apiClient.post<TenantMembershipResponse>(`/tenants/${tenantUuid}/memberships/`, payload),

  removeMembership: (tenantUuid: string, membershipUuid: string) =>
    apiClient.delete(`/tenants/${tenantUuid}/memberships/${membershipUuid}/`),
};

export function normalizeTenantMemberships(
  data: TenantMembershipsListData | TenantMembershipApi | TenantMembershipApi[],
): TenantMembershipApi[] {
  if (Array.isArray(data)) return data;
  if ("results" in data && Array.isArray(data.results)) return data.results;
  if ("tenant_membership_uuid" in data) return [data];
  return [];
}
