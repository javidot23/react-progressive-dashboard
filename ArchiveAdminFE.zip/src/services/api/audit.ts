import { apiClient } from "@/services/http";
import type { AuditEventTypeEnum } from "./enums";
import type { ApiSuccessResponse } from "./tenants";

export type AuditLogTenantRef = {
  tenant_uuid: string;
  tenant_code: string;
  tenant_name: string;
};

export type AuditLogActorUser = {
  user_uuid: string;
  display_name: string;
  first_name: string;
  last_name: string;
  email: string;
};

export type AuditLogApi = {
  audit_log_uuid: string;
  tenant: AuditLogTenantRef | null;
  actor_user: AuditLogActorUser | null;
  audit_event_type: AuditEventTypeEnum;
  trace_id: string | null;
  source: string | null;
  reason_code: string | null;
  request_id: string | null;
  source_ip: string | null;
  target_entity: string | null;
  action: string | null;
  metadata: string | null;
  before_state: string | null;
  after_state: string | null;
  event_timestamp: string;
};

export type AuditLogsListParams = {
  actor_user?: string;
  audit_event_type?: AuditEventTypeEnum;
  event_timestamp_after?: string;
  event_timestamp_before?: string;
  limit?: number;
  offset?: number;
  ordering?: string;
  tenant?: string;
};

export type AuditLogsListData = {
  count: number;
  next: string | null;
  previous: string | null;
  results: AuditLogApi[];
};

export type AuditLogsListResponse = ApiSuccessResponse<AuditLogsListData>;

export const auditApi = {
  list: (params: AuditLogsListParams = {}, signal?: AbortSignal) =>
    apiClient.get<AuditLogsListResponse>("/audit/logs/", { params, signal }),
};
