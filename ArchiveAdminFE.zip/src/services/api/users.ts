import { apiClient } from "@/services/http";
import type { TenantAccessScopeEnum, UserStatusEnum } from "./enums";
import type { ApiSuccessResponse, TenantMembershipApi } from "./tenants";

/** @deprecated Prefer UserStatusEnum */
export type UserStatusApi = UserStatusEnum;
/** @deprecated Prefer TenantAccessScopeEnum */
export type TenantAccessScopeApi = TenantAccessScopeEnum;

export type UserTenantRef = {
  tenant_uuid: string;
  tenant_code: string;
  tenant_name: string;
};

export type UserApi = {
  user_uuid: string;
  status: UserStatusApi;
  display_name: string;
  first_name: string;
  last_name: string;
  email: string;
  job_title: string;
  department: string;
  is_platform_admin: boolean;
  tenant_access_scope: TenantAccessScopeApi;
  tenants?: UserTenantRef[];
  last_login: string | null;
  created_at: string;
  updated_at: string;
};

export type UsersListParams = {
  is_platform_admin?: boolean;
  limit?: number;
  offset?: number;
  ordering?: string;
  search?: string;
  status?: UserStatusApi;
  tenant?: string;
  tenant_access_scope?: TenantAccessScopeApi;
};

export type UsersListData = {
  count: number;
  next: string | null;
  previous: string | null;
  results: UserApi[];
};

export type UsersListResponse = ApiSuccessResponse<UsersListData>;
export type UserResponse = ApiSuccessResponse<UserApi>;

export type UserPatchPayload = {
  status?: UserStatusApi;
  display_name?: string;
  first_name?: string;
  last_name?: string;
  email?: string;
  job_title?: string;
  department?: string;
  is_platform_admin?: boolean;
};

export type InviteUserPayload = {
  email: string;
  tenant_uuid: string;
  role_uuid?: string;
};

export type CreateInternalUserPayload = {
  email: string;
};

export type TenantAccessScopePayload = {
  tenant_access_scope: TenantAccessScopeApi;
  tenant_uuids?: string[];
};

export type UserMembershipsListData = {
  count: number;
  next: string | null;
  previous: string | null;
  results: TenantMembershipApi[];
};

export type UserMembershipsListResponse = ApiSuccessResponse<UserMembershipsListData>;

/** @deprecated Prefer UserApi — kept for transitional imports. */
export type User = UserApi;

export const usersApi = {
  list: (params: UsersListParams = {}, signal?: AbortSignal) => apiClient.get<UsersListResponse>("/users/", { params, signal }),

  get: (userUuid: string, signal?: AbortSignal) => apiClient.get<UserResponse>(`/users/${userUuid}/`, { signal }),

  update: (userUuid: string, payload: UserPatchPayload) => apiClient.patch<UserResponse>(`/users/${userUuid}/`, payload),

  listMemberships: (userUuid: string, params: { limit?: number; offset?: number } = {}, signal?: AbortSignal) =>
    apiClient.get<UserMembershipsListResponse>(`/users/${userUuid}/memberships/`, { params, signal }),

  setTenantAccessScope: (userUuid: string, payload: TenantAccessScopePayload) =>
    apiClient.put<UserResponse>(`/users/${userUuid}/tenant-access-scope/`, payload),

  createInternal: (payload: CreateInternalUserPayload) => apiClient.post<UserResponse>("/users/internal/", payload),

  invite: (payload: InviteUserPayload) => apiClient.post<UserResponse>("/users/invite/", payload),
};
