/** API schema enums — keep in sync with OpenAPI. */

export const ENTITLEMENT_TIERS = ["standard", "premium", "platinum"] as const;
export type EntitlementTierEnum = (typeof ENTITLEMENT_TIERS)[number];

export const USER_STATUSES = ["active", "pending_verification", "suspended", "inactive", "disabled", "deleted"] as const;
export type UserStatusEnum = (typeof USER_STATUSES)[number];

export const ASSIGNMENT_SOURCES = ["direct", "inherited", "synced", "delegated", "system"] as const;
export type AssignmentSourceEnum = (typeof ASSIGNMENT_SOURCES)[number];

export const AUDIT_EVENT_TYPES = [
  "login_success",
  "login_failure",
  "logout",
  "role_assigned",
  "role_revoked",
  "permission_checked",
  "access_granted",
  "access_denied",
  "tenant_updated",
  "tenant_selected",
  "user_updated",
  "action_created",
  "action_updated",
  "action_deleted",
  "issue_note_created",
  "issue_note_updated",
  "issue_note_deleted",
  "custom_list_created",
  "custom_list_updated",
  "custom_list_deleted",
  "custom_list_items_synced",
  "user_setting_updated",
  "user_feedback_created",
  "user_feedback_updated",
  "api_request",
] as const;
export type AuditEventTypeEnum = (typeof AUDIT_EVENT_TYPES)[number];

export const AUTH_PROVIDERS = ["sap_cdc", "entra_id"] as const;
export type AuthProviderEnum = (typeof AUTH_PROVIDERS)[number];

export const FEEDBACK_STATUSES = ["open", "in_progress", "resolved", "closed"] as const;
export type FeedbackStatusEnum = (typeof FEEDBACK_STATUSES)[number];

export const PERMISSION_TYPES = ["view", "manage", "approve", "disable", "delete"] as const;
export type PermissionTypeEnum = (typeof PERMISSION_TYPES)[number];

export const RESOURCE_TYPES = ["menu", "page", "widget"] as const;
export type ResourceTypeEnum = (typeof RESOURCE_TYPES)[number];

export const TENANT_ACCESS_SCOPES = ["tenant", "all_tenants"] as const;
export type TenantAccessScopeEnum = (typeof TENANT_ACCESS_SCOPES)[number];

export const TENANT_TYPES = ["customer", "vendor", "customer_vendor"] as const;
export type TenantTypeEnum = (typeof TENANT_TYPES)[number];

export const ENTITLEMENT_TIER_LABELS: Record<EntitlementTierEnum, string> = {
  standard: "Standard",
  premium: "Premium",
  platinum: "Platinum",
};

export const USER_STATUS_LABELS: Record<UserStatusEnum, string> = {
  active: "Active",
  pending_verification: "Pending verification",
  suspended: "Suspended",
  inactive: "Inactive",
  disabled: "Disabled",
  deleted: "Deleted",
};

export const ASSIGNMENT_SOURCE_LABELS: Record<AssignmentSourceEnum, string> = {
  direct: "Direct",
  inherited: "Inherited",
  synced: "Synced",
  delegated: "Delegated",
  system: "System",
};

export const AUDIT_EVENT_TYPE_LABELS: Record<AuditEventTypeEnum, string> = {
  login_success: "Login success",
  login_failure: "Login failure",
  logout: "Logout",
  role_assigned: "Role assigned",
  role_revoked: "Role revoked",
  permission_checked: "Permission checked",
  access_granted: "Access granted",
  access_denied: "Access denied",
  tenant_updated: "Tenant updated",
  tenant_selected: "Tenant selected",
  user_updated: "User updated",
  action_created: "Action created",
  action_updated: "Action updated",
  action_deleted: "Action deleted",
  issue_note_created: "Issue note created",
  issue_note_updated: "Issue note updated",
  issue_note_deleted: "Issue note deleted",
  custom_list_created: "Custom list created",
  custom_list_updated: "Custom list updated",
  custom_list_deleted: "Custom list deleted",
  custom_list_items_synced: "Custom list items synced",
  user_setting_updated: "User setting updated",
  user_feedback_created: "User feedback created",
  user_feedback_updated: "User feedback updated",
  api_request: "API request",
};

export const AUTH_PROVIDER_LABELS: Record<AuthProviderEnum, string> = {
  sap_cdc: "SAP CDC",
  entra_id: "Entra ID",
};

export const FEEDBACK_STATUS_LABELS: Record<FeedbackStatusEnum, string> = {
  open: "Open",
  in_progress: "In Progress",
  resolved: "Resolved",
  closed: "Closed",
};

export const PERMISSION_TYPE_LABELS: Record<PermissionTypeEnum, string> = {
  view: "View",
  manage: "Manage",
  approve: "Approve",
  disable: "Disable",
  delete: "Delete",
};

export const RESOURCE_TYPE_LABELS: Record<ResourceTypeEnum, string> = {
  menu: "Menu",
  page: "Page",
  widget: "Widget",
};

export const TENANT_ACCESS_SCOPE_LABELS: Record<TenantAccessScopeEnum, string> = {
  tenant: "Scoped to memberships",
  all_tenants: "All tenants",
};

export const TENANT_TYPE_LABELS: Record<TenantTypeEnum, string> = {
  customer: "Customer",
  vendor: "Vendor",
  customer_vendor: "Customer/Vendor",
};

export function enumOptions<T extends string>(
  values: readonly T[],
  labels: Record<T, string>,
): Array<{ value: T; label: string }> {
  return values.map((value) => ({ value, label: labels[value] }));
}

export const ENTITLEMENT_TIER_OPTIONS = enumOptions(ENTITLEMENT_TIERS, ENTITLEMENT_TIER_LABELS);
export const USER_STATUS_OPTIONS = enumOptions(USER_STATUSES, USER_STATUS_LABELS);
export const TENANT_TYPE_OPTIONS = enumOptions(TENANT_TYPES, TENANT_TYPE_LABELS);
export const TENANT_ACCESS_SCOPE_OPTIONS = enumOptions(TENANT_ACCESS_SCOPES, TENANT_ACCESS_SCOPE_LABELS);
export const AUDIT_EVENT_TYPE_OPTIONS = enumOptions(AUDIT_EVENT_TYPES, AUDIT_EVENT_TYPE_LABELS);
