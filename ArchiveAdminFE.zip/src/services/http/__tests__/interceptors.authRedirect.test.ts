import { afterEach, describe, expect, it } from "vitest";
import { resetAuthRedirectSuppression, shouldRedirectOnUnauthorized, suppressAuthRedirects } from "../interceptors";

describe("shouldRedirectOnUnauthorized", () => {
  const originalPathname = window.location.pathname;

  afterEach(() => {
    resetAuthRedirectSuppression();
    window.history.replaceState({}, "", originalPathname || "/");
  });

  it("redirects on protected routes by default", () => {
    window.history.replaceState({}, "", "/tenants");
    expect(shouldRedirectOnUnauthorized()).toBe(true);
  });

  it("does not redirect when skipAuthRedirect is set", () => {
    window.history.replaceState({}, "", "/tenants");
    expect(shouldRedirectOnUnauthorized({ skipAuthRedirect: true })).toBe(false);
  });

  it("does not redirect on public auth paths", () => {
    window.history.replaceState({}, "", "/login");
    expect(shouldRedirectOnUnauthorized()).toBe(false);
  });

  it("does not redirect while auth redirects are suppressed (logout)", () => {
    window.history.replaceState({}, "", "/tenants");
    suppressAuthRedirects();
    expect(shouldRedirectOnUnauthorized()).toBe(false);
  });
});
