export { apiClient, default as default } from "./axios";
export {
  setupInterceptors,
  attachCsrfHeader,
  attachAuthorizationHeader,
  handleUnauthorized,
  suppressAuthRedirects,
  resetAuthRedirectSuppression,
  shouldRedirectOnUnauthorized,
  onAuthFailure,
  DOMAIN_NOT_ALLOWED_CODE,
  EMAIL_NOT_ALLOWED_CODE,
  DomainNotAllowedError,
  EmailNotAllowedError,
} from "./interceptors";
export { redirectToLogin } from "@/lib/authUrls";
