import axios, { type AxiosInstance, type AxiosRequestConfig } from "axios";
import { getApiUrl } from "@/utils/env";
import { setupInterceptors } from "./interceptors";

declare module "axios" {
  interface AxiosRequestConfig {
    /** When true, 401 does not trigger full-page redirect to login. */
    skipAuthRedirect?: boolean;
  }
}

export const apiClient: AxiosInstance = axios.create({
  baseURL: getApiUrl(),
  timeout: 120_000,
  withCredentials: true,
  headers: {
    "Content-Type": "application/json",
  },
});

setupInterceptors(apiClient);

export type { AxiosRequestConfig };
export default apiClient;
