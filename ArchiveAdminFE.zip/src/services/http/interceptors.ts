import type { AxiosError, AxiosInstance, AxiosResponse, InternalAxiosRequestConfig } from "axios";
import { isPublicAuthPath, redirectToLogin } from "@/lib/authUrls";

type AuthFailureListener = () => void;

let authFailureListeners: AuthFailureListener[] = [];
let authRedirectSuppressed = false;

export function suppressAuthRedirects(): void {
  authRedirectSuppressed = true;
}

export function resetAuthRedirectSuppression(): void {
  authRedirectSuppressed = false;
}

export function shouldRedirectOnUnauthorized(config?: { skipAuthRedirect?: boolean } | null): boolean {
  if (authRedirectSuppressed) return false;
  if (config?.skipAuthRedirect) return false;
  if (isPublicAuthPath()) return false;
  return true;
}

export const onAuthFailure = (callback: AuthFailureListener) => {
  authFailureListeners.push(callback);
  return () => {
    authFailureListeners = authFailureListeners.filter((cb) => cb !== callback);
  };
};

const notifyAuthFailure = () => {
  authFailureListeners.forEach((callback) => callback());
};

const UNSAFE_METHODS = new Set(["post", "put", "patch", "delete"]);

function getCsrfToken(): string | null {
  if (typeof document === "undefined") return null;
  const match = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]*)/);
  if (!match) return null;
  try {
    return decodeURIComponent(match[1]);
  } catch {
    return match[1];
  }
}

interface ApiErrorBody {
  code?: string;
  error?: string;
  success?: boolean;
  type?: string;
}

export const DOMAIN_NOT_ALLOWED_CODE = "domain_not_allowed";
export const EMAIL_NOT_ALLOWED_CODE = "email_not_allowed";

export class DomainNotAllowedError extends Error {
  code = DOMAIN_NOT_ALLOWED_CODE;

  constructor(message: string = "Access denied") {
    super(message);
    this.name = "DomainNotAllowedError";
  }
}

export class EmailNotAllowedError extends Error {
  code = EMAIL_NOT_ALLOWED_CODE;

  constructor(message: string = "Access denied") {
    super(message);
    this.name = "EmailNotAllowedError";
  }
}

/** Attach CSRF header for unsafe methods. Never set Authorization: Bearer. */
export function attachCsrfHeader(config: InternalAxiosRequestConfig): InternalAxiosRequestConfig {
  const method = (config.method ?? "get").toLowerCase();
  if (UNSAFE_METHODS.has(method)) {
    const csrf = getCsrfToken();
    if (csrf) {
      config.headers.set("X-CSRFToken", csrf);
    } else if (import.meta.env.DEV) {
      console.warn("[apiClient] Missing csrftoken cookie for", method.toUpperCase(), config.url);
    }
  }
  return config;
}

/** @deprecated Use attachCsrfHeader — session auth uses cookies, not Bearer tokens. */
export function attachAuthorizationHeader(config: InternalAxiosRequestConfig): InternalAxiosRequestConfig {
  return attachCsrfHeader(config);
}

export function handleUnauthorized(error: AxiosError): void {
  if (shouldRedirectOnUnauthorized(error.config)) {
    redirectToLogin();
  }
}

export function setupInterceptors(client: AxiosInstance): void {
  client.interceptors.request.use(
    (config) => attachCsrfHeader(config),
    (error) => Promise.reject(error),
  );

  client.interceptors.response.use(
    (response: AxiosResponse) => response,
    async (error: AxiosError) => {
      const errorBody = error.response?.data as ApiErrorBody | undefined;

      if (error.response?.status === 401 && errorBody?.code === DOMAIN_NOT_ALLOWED_CODE) {
        notifyAuthFailure();
        return Promise.reject(new DomainNotAllowedError(errorBody.error || "Access denied"));
      }

      if (error.response?.status === 401 && errorBody?.code === EMAIL_NOT_ALLOWED_CODE) {
        notifyAuthFailure();
        return Promise.reject(new EmailNotAllowedError(errorBody.error || "Access denied"));
      }

      if (error.response?.status === 401) {
        handleUnauthorized(error);
        const authError = new Error("SESSION_EXPIRED");
        authError.name = "AuthenticationError";
        return Promise.reject(authError);
      }

      if (error.response?.status === 403) {
        console.warn("Access forbidden - insufficient permissions");
      }

      return Promise.reject(error);
    },
  );
}
