import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/services/http";

export interface AuthMeProfile {
  id: string;
  displayName?: string;
  mail?: string;
  userPrincipalName?: string;
  givenName?: string;
  surname?: string;
  jobTitle?: string;
  photoDataUrl?: string;
  department?: string;
  isPlatformAdmin?: boolean;
}

/** Raw user object from admin BFF `/auth/me/` (and Entra-shaped flat variants). */
interface ApiUserPayload {
  id?: string;
  user_uuid?: string;
  displayName?: string;
  display_name?: string;
  mail?: string;
  email?: string;
  userPrincipalName?: string;
  user_principal_name?: string;
  givenName?: string;
  first_name?: string;
  firstName?: string;
  surname?: string;
  last_name?: string;
  lastName?: string;
  jobTitle?: string;
  job_title?: string;
  department?: string;
  profilePicture?: string;
  profile_picture?: string;
  photoDataUrl?: string;
  photo_data_url?: string;
  is_platform_admin?: boolean;
  status?: string;
  last_login?: string;
  created_at?: string;
}

interface AuthMeEnvelope {
  user?: ApiUserPayload;
  identities?: Array<{ email?: string; is_primary?: boolean }>;
}

function pickString(...values: Array<string | undefined | null>): string | undefined {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }
  return undefined;
}

/** Unwrap `{ success, data: { user } }` or flat profile payloads. */
export function extractAuthMeUserPayload(body: unknown): ApiUserPayload {
  if (!body || typeof body !== "object") return {};

  const root = body as Record<string, unknown>;
  const data = (root.data ?? root) as AuthMeEnvelope & ApiUserPayload;

  if (data.user && typeof data.user === "object") {
    return data.user;
  }

  return data as ApiUserPayload;
}

export const mapApiResponseToProfile = (payload: unknown): AuthMeProfile => {
  const user = extractAuthMeUserPayload(payload);
  const envelope =
    payload && typeof payload === "object"
      ? ((payload as { data?: AuthMeEnvelope }).data ?? (payload as AuthMeEnvelope))
      : undefined;

  const identityEmail = envelope?.identities?.find((identity) => identity.is_primary)?.email ?? envelope?.identities?.[0]?.email;

  const mail = pickString(user.mail, user.email, user.userPrincipalName, user.user_principal_name, identityEmail);
  const givenName = pickString(user.givenName, user.first_name, user.firstName);
  const surname = pickString(user.surname, user.last_name, user.lastName);
  const displayName =
    pickString(user.displayName, user.display_name) || [givenName, surname].filter(Boolean).join(" ") || undefined;

  return {
    id: pickString(user.user_uuid, user.id) ?? "",
    displayName,
    mail,
    userPrincipalName: pickString(user.userPrincipalName, user.user_principal_name, mail),
    givenName,
    surname,
    jobTitle: pickString(user.jobTitle, user.job_title),
    department: pickString(user.department),
    photoDataUrl: pickString(user.profilePicture, user.profile_picture, user.photoDataUrl, user.photo_data_url),
    isPlatformAdmin: user.is_platform_admin === true,
  };
};

export const PROFILE_QUERY_KEY = ["auth", "me"] as const;

export function useProfile() {
  const query = useQuery<AuthMeProfile>({
    queryKey: PROFILE_QUERY_KEY,
    queryFn: async () => {
      // AuthProvider owns session state; a 401 here must not redirect to the IdP on its own.
      const res = await apiClient.get("/auth/me/", { skipAuthRedirect: true });
      return mapApiResponseToProfile(res?.data);
    },
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });

  return {
    profile: query.data,
    isLoading: query.isLoading,
    error: (query.error as Error) || null,
    refetch: query.refetch,
  };
}

export default useProfile;
