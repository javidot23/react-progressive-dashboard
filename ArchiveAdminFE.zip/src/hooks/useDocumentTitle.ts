import { useEffect } from "react";

/** Sets `document.title` for the current page. */
export function useDocumentTitle(title: string, suffix = "Stratium Admin") {
  useEffect(() => {
    const previous = document.title;
    document.title = title ? `${title} · ${suffix}` : suffix;
    return () => {
      document.title = previous;
    };
  }, [title, suffix]);
}
