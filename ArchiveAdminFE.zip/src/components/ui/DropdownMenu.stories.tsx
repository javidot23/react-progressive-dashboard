import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { Home, Settings, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuSubTrigger,
  DropdownMenuSwitchItem,
  DropdownMenuTrigger,
} from "@/components/ui/DropdownMenu";

const options = ["Option one", "Option two", "Option three", "Option four", "Option five"] as const;

const meta: Meta<typeof DropdownMenu> = {
  title: "UI/DropdownMenu",
  component: DropdownMenu,
  tags: ["autodocs"],
  args: {
    defaultOpen: true,
    tone: "default",
  },
  argTypes: {
    tone: {
      control: "select",
      options: ["default", "primary"],
    },
  },
  parameters: {
    layout: "centered",
  },
  decorators: [
    (Story) => (
      <div className="flex min-h-[320px] items-start justify-center pt-4">
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const SimpleText: Story = {
  render: (args) => (
    <DropdownMenu {...args}>
      <DropdownMenuTrigger>Select option</DropdownMenuTrigger>
      <DropdownMenuContent>
        {options.map((option) => (
          <DropdownMenuItem key={option}>{option}</DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  ),
};

export const WithDescription: Story = {
  render: (args) => (
    <DropdownMenu {...args}>
      <DropdownMenuTrigger>Select option</DropdownMenuTrigger>
      <DropdownMenuContent className="min-w-[18rem]">
        {options.map((option) => (
          <DropdownMenuItem key={option} description="Secondary text">
            {option}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  ),
};

export const WithIcons: Story = {
  render: (args) => (
    <DropdownMenu {...args}>
      <DropdownMenuTrigger>Select option</DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuItem startIcon={<Home className="size-4" />}>Home</DropdownMenuItem>
        <DropdownMenuItem startIcon={<User className="size-4" />}>Profile</DropdownMenuItem>
        <DropdownMenuItem startIcon={<Settings className="size-4" />}>Settings</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  ),
};

export const WithSubmenuIndicators: Story = {
  render: (args) => (
    <DropdownMenu {...args}>
      <DropdownMenuTrigger>Select option</DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuSubTrigger>Option one</DropdownMenuSubTrigger>
        <DropdownMenuSubTrigger>Option two</DropdownMenuSubTrigger>
        <DropdownMenuSubTrigger>Option three</DropdownMenuSubTrigger>
      </DropdownMenuContent>
    </DropdownMenu>
  ),
};

export const WithShortcuts: Story = {
  render: (args) => (
    <DropdownMenu {...args}>
      <DropdownMenuTrigger>Select option</DropdownMenuTrigger>
      <DropdownMenuContent className="min-w-[16rem]">
        <DropdownMenuItem startIcon={<Home className="size-4" />} shortcut="⌘H">
          Home
        </DropdownMenuItem>
        <DropdownMenuItem startIcon={<User className="size-4" />} shortcut="⌘P">
          Profile
        </DropdownMenuItem>
        <DropdownMenuItem startIcon={<Settings className="size-4" />} shortcut="⌘,">
          Settings
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  ),
};

export const MultiSelect: Story = {
  render: function MultiSelectStory(args) {
    const [checked, setChecked] = useState<Record<string, boolean>>({
      "Option one": true,
      "Option two": false,
      "Option three": true,
    });

    return (
      <DropdownMenu {...args}>
        <DropdownMenuTrigger>Select options</DropdownMenuTrigger>
        <DropdownMenuContent>
          {options.slice(0, 3).map((option) => (
            <DropdownMenuCheckboxItem
              key={option}
              checked={Boolean(checked[option])}
              onCheckedChange={(value) => setChecked((prev) => ({ ...prev, [option]: value }))}
            >
              {option}
            </DropdownMenuCheckboxItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  },
};

export const SingleSelect: Story = {
  render: function SingleSelectStory(args) {
    const [selected, setSelected] = useState("Option one");

    return (
      <DropdownMenu {...args}>
        <DropdownMenuTrigger>{selected}</DropdownMenuTrigger>
        <DropdownMenuContent>
          {options.slice(0, 3).map((option) => (
            <DropdownMenuRadioItem key={option} checked={selected === option} onSelectItem={() => setSelected(option)}>
              {option}
            </DropdownMenuRadioItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  },
};

export const WithToggles: Story = {
  render: function WithTogglesStory(args) {
    const [enabled, setEnabled] = useState<Record<string, boolean>>({
      Notifications: true,
      "Dark mode": false,
      Compact: true,
    });

    return (
      <DropdownMenu {...args}>
        <DropdownMenuTrigger>Preferences</DropdownMenuTrigger>
        <DropdownMenuContent className="min-w-[16rem]">
          {Object.keys(enabled).map((label) => (
            <DropdownMenuSwitchItem
              key={label}
              checked={enabled[label]}
              onCheckedChange={(value) => setEnabled((prev) => ({ ...prev, [label]: value }))}
            >
              {label}
            </DropdownMenuSwitchItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  },
};

export const Grouped: Story = {
  render: (args) => (
    <DropdownMenu {...args}>
      <DropdownMenuTrigger>Select option</DropdownMenuTrigger>
      <DropdownMenuContent className="min-w-[16rem]">
        <DropdownMenuLabel>Account</DropdownMenuLabel>
        <DropdownMenuItem startIcon={<User className="size-4" />}>Profile</DropdownMenuItem>
        <DropdownMenuItem startIcon={<Settings className="size-4" />}>Settings</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuLabel>Actions</DropdownMenuLabel>
        <DropdownMenuItem>Export</DropdownMenuItem>
        <DropdownMenuItem destructive>Delete</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  ),
};

export const PrimaryTone: Story = {
  args: { tone: "primary" },
  render: function PrimaryToneStory(args) {
    const [selected, setSelected] = useState("Option two");

    return (
      <DropdownMenu {...args}>
        <DropdownMenuTrigger>{selected}</DropdownMenuTrigger>
        <DropdownMenuContent>
          {options.slice(0, 4).map((option) => (
            <DropdownMenuItem key={option} selected={selected === option} onClick={() => setSelected(option)}>
              {option}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  },
};
