import type { Meta, StoryObj } from "@storybook/react-vite";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/Card";

const meta: Meta<typeof Card> = {
  title: "UI/Card",
  component: Card,
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: (args) => (
    <Card {...args} className="max-w-md">
      <CardHeader>
        <CardTitle>Card title</CardTitle>
        <CardDescription>Supporting description for this card.</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-ui-text-primary">Card body content goes here.</p>
      </CardContent>
    </Card>
  ),
};

export const Elevated: Story = {
  render: (args) => (
    <Card {...args} variant="elevated" className="max-w-md">
      <CardHeader>
        <CardTitle>Elevated card</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-ui-text-primary">Uses the elevated variant.</p>
      </CardContent>
    </Card>
  ),
};
