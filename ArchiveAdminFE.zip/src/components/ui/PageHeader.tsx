import type { ReactNode } from "react";
import { cn } from "@/utils";

export interface PageHeaderProps {
  title: string;
  description?: ReactNode;
  actions?: ReactNode;
  className?: string;
}

export function PageHeader({ title, description, actions, className }: PageHeaderProps) {
  return (
    <div className={cn("flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between", className)}>
      <div>
        <h1
          className={cn(
            "align-middle font-body-xl text-[length:var(--text-body-xl)] leading-body-xl",
            "font-bold tracking-normal text-[#0F172A]",
          )}
        >
          {title}
        </h1>
        {description ? (
          <div
            className={cn(
              "mt-1 align-middle font-body-sm text-[length:var(--text-body-sm)] leading-body-sm",
              "font-medium tracking-normal text-[#6E6E6E]",
            )}
          >
            {description}
          </div>
        ) : null}
      </div>
      {actions ? <div className="flex shrink-0 flex-wrap items-center justify-end gap-3 self-end">{actions}</div> : null}
    </div>
  );
}
