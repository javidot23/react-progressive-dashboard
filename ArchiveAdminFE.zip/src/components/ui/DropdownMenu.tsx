import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type ReactNode,
} from "react";
import { Check, ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "@/utils";

type DropdownMenuContextValue = {
  open: boolean;
  setOpen: (open: boolean) => void;
  tone: "default" | "primary";
  menuId: string;
};

const DropdownMenuContext = createContext<DropdownMenuContextValue | null>(null);

function useDropdownMenuContext(component: string) {
  const ctx = useContext(DropdownMenuContext);
  if (!ctx) {
    throw new Error(`${component} must be used within <DropdownMenu>`);
  }
  return ctx;
}

export type DropdownMenuProps = {
  children: ReactNode;
  open?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  /** Visual emphasis for the trigger and selected items. */
  tone?: "default" | "primary";
  className?: string;
};

export function DropdownMenu({
  children,
  open: openProp,
  defaultOpen = false,
  onOpenChange,
  tone = "default",
  className,
}: DropdownMenuProps) {
  const [uncontrolledOpen, setUncontrolledOpen] = useState(defaultOpen);
  const open = openProp ?? uncontrolledOpen;
  const menuId = useId();
  const rootRef = useRef<HTMLDivElement>(null);

  const setOpen = useCallback(
    (next: boolean) => {
      if (openProp === undefined) setUncontrolledOpen(next);
      onOpenChange?.(next);
    },
    [onOpenChange, openProp],
  );

  useEffect(() => {
    if (!open) return;

    const onPointerDown = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };

    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open, setOpen]);

  const value = useMemo(() => ({ open, setOpen, tone, menuId }), [open, setOpen, tone, menuId]);

  return (
    <DropdownMenuContext.Provider value={value}>
      <div ref={rootRef} className={cn("relative inline-block text-left", className)}>
        {children}
      </div>
    </DropdownMenuContext.Provider>
  );
}

export type DropdownMenuTriggerProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  /** When false, hides the trailing chevron (useful for icon-only triggers). */
  showChevron?: boolean;
};

export function DropdownMenuTrigger({ children, className, showChevron = true, ...props }: DropdownMenuTriggerProps) {
  const { open, setOpen, tone, menuId } = useDropdownMenuContext("DropdownMenuTrigger");

  return (
    <button
      type="button"
      aria-haspopup="menu"
      aria-expanded={open}
      aria-controls={menuId}
      onClick={() => setOpen(!open)}
      className={cn(
        "inline-flex items-center justify-between gap-2 rounded-md text-sm font-medium transition-colors",
        "focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-1",
        "disabled:pointer-events-none disabled:opacity-50",
        showChevron ? "h-9 min-w-[10rem] px-3" : "h-8 min-w-0 justify-center p-1.5",
        tone === "primary"
          ? "bg-brand-primary-main text-white hover:bg-brand-primary-dark"
          : showChevron
            ? "border border-ui-border-secondary bg-white text-ui-text-heading hover:bg-ui-background-secondary"
            : "border-0 bg-transparent text-ui-text-secondary hover:bg-ui-background-muted hover:text-ui-text-primary",
        className,
      )}
      {...props}
    >
      {showChevron ? <span className="truncate">{children}</span> : children}
      {showChevron ? (
        <ChevronDown
          className={cn("size-4 shrink-0", tone === "primary" ? "text-white" : "text-ui-text-secondary")}
          aria-hidden
        />
      ) : null}
    </button>
  );
}

export type DropdownMenuContentProps = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode;
  /** `end` aligns the menu to the trigger's right edge (opens leftward — avoids viewport overflow). */
  align?: "start" | "end";
};

export function DropdownMenuContent({ children, className, align = "start", ...props }: DropdownMenuContentProps) {
  const { open, menuId } = useDropdownMenuContext("DropdownMenuContent");
  if (!open) return null;

  return (
    <div
      id={menuId}
      role="menu"
      className={cn(
        "absolute top-full z-50 mt-1 min-w-[10rem] overflow-hidden rounded-md border border-ui-border-secondary bg-white py-1 shadow-lg",
        align === "end" ? "right-0 left-auto" : "left-0",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}

export type DropdownMenuItemProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  selected?: boolean;
  /** When false, selected styling is kept but the trailing check icon is hidden. */
  showSelectedCheck?: boolean;
  destructive?: boolean;
  description?: ReactNode;
  startIcon?: ReactNode;
  endIcon?: ReactNode;
  shortcut?: string;
  inset?: boolean;
};

export function DropdownMenuItem({
  children,
  className,
  selected = false,
  showSelectedCheck = true,
  destructive = false,
  description,
  startIcon,
  endIcon,
  shortcut,
  inset,
  disabled,
  onClick,
  ...props
}: DropdownMenuItemProps) {
  const { setOpen, tone } = useDropdownMenuContext("DropdownMenuItem");

  return (
    <button
      type="button"
      role="menuitem"
      disabled={disabled}
      onClick={(event) => {
        onClick?.(event);
        if (!event.defaultPrevented) setOpen(false);
      }}
      className={cn(
        "flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition-colors",
        "focus-visible:outline-hidden focus-visible:bg-ui-background-muted",
        "disabled:pointer-events-none disabled:opacity-40",
        destructive
          ? "text-status-error-main hover:bg-status-error-light"
          : selected && tone === "primary"
            ? "bg-brand-primary-50 text-brand-primary-main hover:bg-brand-primary-50"
            : selected
              ? "bg-ui-background-muted text-ui-text-heading"
              : "text-ui-text-heading hover:bg-ui-background-muted",
        inset && "pl-8",
        className,
      )}
      {...props}
    >
      {startIcon ? <span className="inline-flex size-4 shrink-0 items-center justify-center">{startIcon}</span> : null}
      <span className="min-w-0 flex-1">
        <span className={cn("block truncate", description && "font-medium")}>{children}</span>
        {description ? <span className="mt-0.5 block truncate text-xs text-ui-text-secondary">{description}</span> : null}
      </span>
      {shortcut ? <span className="ml-auto shrink-0 text-xs text-ui-text-secondary">{shortcut}</span> : null}
      {endIcon ? <span className="ml-auto inline-flex size-4 shrink-0 items-center justify-center">{endIcon}</span> : null}
      {selected && showSelectedCheck && !endIcon && !shortcut ? (
        <Check
          className={cn("ml-auto size-4 shrink-0", tone === "primary" ? "text-brand-primary-main" : "text-ui-text-heading")}
          aria-hidden
        />
      ) : null}
    </button>
  );
}

export type DropdownMenuCheckboxItemProps = Omit<DropdownMenuItemProps, "startIcon" | "selected"> & {
  checked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
};

export function DropdownMenuCheckboxItem({
  checked = false,
  onCheckedChange,
  children,
  onClick,
  ...props
}: DropdownMenuCheckboxItemProps) {
  return (
    <DropdownMenuItem
      role="menuitemcheckbox"
      aria-checked={checked}
      selected={checked}
      showSelectedCheck={false}
      startIcon={
        <span
          className={cn(
            "flex size-3.5 items-center justify-center rounded-[2px] border",
            checked ? "border-brand-primary-main bg-brand-primary-main text-white" : "border-ui-border-secondary bg-white",
          )}
        >
          {checked ? <Check className="size-2.5" aria-hidden /> : null}
        </span>
      }
      onClick={(event) => {
        event.preventDefault();
        onCheckedChange?.(!checked);
        onClick?.(event);
      }}
      {...props}
    >
      {children}
    </DropdownMenuItem>
  );
}

export type DropdownMenuRadioItemProps = Omit<DropdownMenuItemProps, "startIcon" | "selected"> & {
  checked?: boolean;
  onSelectItem?: () => void;
};

export function DropdownMenuRadioItem({
  checked = false,
  onSelectItem,
  children,
  onClick,
  ...props
}: DropdownMenuRadioItemProps) {
  return (
    <DropdownMenuItem
      role="menuitemradio"
      aria-checked={checked}
      selected={checked}
      showSelectedCheck={false}
      startIcon={
        <span
          className={cn(
            "flex size-3.5 items-center justify-center rounded-full border",
            checked ? "border-brand-primary-main" : "border-ui-border-secondary",
          )}
        >
          {checked ? <span className="size-2 rounded-full bg-brand-primary-main" /> : null}
        </span>
      }
      onClick={(event) => {
        event.preventDefault();
        onSelectItem?.();
        onClick?.(event);
      }}
      {...props}
    >
      {children}
    </DropdownMenuItem>
  );
}

export type DropdownMenuSwitchItemProps = Omit<DropdownMenuItemProps, "endIcon" | "selected"> & {
  checked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
};

export function DropdownMenuSwitchItem({
  checked = false,
  onCheckedChange,
  children,
  onClick,
  ...props
}: DropdownMenuSwitchItemProps) {
  return (
    <DropdownMenuItem
      role="menuitemcheckbox"
      aria-checked={checked}
      selected={checked}
      showSelectedCheck={false}
      endIcon={
        <span
          className={cn("relative h-5 w-9 rounded-full transition-colors", checked ? "bg-brand-primary-main" : "bg-neutral-300")}
        >
          <span
            className={cn(
              "absolute top-0.5 left-0.5 size-4 rounded-full bg-white transition-transform",
              checked && "translate-x-4",
            )}
          />
        </span>
      }
      onClick={(event) => {
        event.preventDefault();
        onCheckedChange?.(!checked);
        onClick?.(event);
      }}
      {...props}
    >
      {children}
    </DropdownMenuItem>
  );
}

export function DropdownMenuSeparator({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div role="separator" className={cn("my-1 h-px bg-ui-border-secondary", className)} {...props} />;
}

export function DropdownMenuLabel({ className, children, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("px-3 py-1.5 text-[10px] font-semibold tracking-wider text-ui-text-secondary uppercase", className)}
      {...props}
    >
      {children}
    </div>
  );
}

export function DropdownMenuSubTrigger({ children, className, startIcon, ...props }: Omit<DropdownMenuItemProps, "endIcon">) {
  return (
    <DropdownMenuItem
      endIcon={<ChevronRight className="size-4 text-ui-text-secondary" aria-hidden />}
      startIcon={startIcon}
      className={className}
      onClick={(event) => event.preventDefault()}
      {...props}
    >
      {children}
    </DropdownMenuItem>
  );
}
