import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Button } from "@/components/ui/Button";
import { Drawer } from "@/components/ui/Drawer";

const lorem =
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";

const meta: Meta<typeof Drawer> = {
  title: "UI/Drawer",
  component: Drawer,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
  },
  args: {
    open: true,
    title: "Drawer header",
    onClose: fn(),
    children: <p className="text-sm leading-relaxed text-ui-text-heading">{lorem}</p>,
    footer: (
      <Button type="button" size="sm" className="h-8" onClick={fn()}>
        Close
      </Button>
    ),
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const WithSecondaryAction: Story = {
  args: {
    footer: (
      <>
        <Button type="button" variant="outline" size="sm" className="h-8">
          Cancel
        </Button>
        <Button type="button" size="sm" className="h-8">
          Confirm
        </Button>
      </>
    ),
  },
};

export const ScrollableBody: Story = {
  args: {
    children: (
      <div className="space-y-4 text-sm leading-relaxed text-ui-text-heading">
        {Array.from({ length: 8 }, (_, i) => (
          <p key={i}>{lorem}</p>
        ))}
      </div>
    ),
  },
};

export const WithoutFooter: Story = {
  args: {
    footer: undefined,
  },
};
