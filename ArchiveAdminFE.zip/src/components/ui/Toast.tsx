import type { HTMLAttributes, ReactNode } from "react";
import { AlertTriangle, CheckCircle2, Info, Lightbulb, Megaphone, OctagonAlert, X } from "lucide-react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/utils";

export type ToastType = "info" | "update" | "feature" | "success" | "warning" | "error";

const toastVariants = cva(
  "flex w-full items-center gap-3 rounded-md px-4 py-3 font-body-sm text-[length:var(--text-body-sm)] leading-body-sm tracking-normal",
  {
    variants: {
      variant: {
        subtle: "bg-[#2B2B2B] text-white",
        "colored-icon": "bg-[#2B2B2B] text-white",
        prominent: "bg-[#2B2B2B] text-white",
        solid: "text-white",
        "solid-dark": "text-white",
        "solid-vibrant": "text-white",
      },
      type: {
        info: "",
        update: "",
        feature: "",
        success: "",
        warning: "",
        error: "",
      },
    },
    compoundVariants: [
      { variant: "solid", type: "info", class: "bg-[#2F6FED]" },
      { variant: "solid", type: "update", class: "bg-brand-primary-main" },
      { variant: "solid", type: "feature", class: "bg-[#3A3A3A]" },
      { variant: "solid", type: "success", class: "bg-[#2E9B57]" },
      { variant: "solid", type: "warning", class: "bg-[#E08A1E]" },
      { variant: "solid", type: "error", class: "bg-[#D64545]" },

      { variant: "solid-dark", type: "info", class: "bg-[#1F5BC4]" },
      { variant: "solid-dark", type: "update", class: "bg-brand-primary-dark" },
      { variant: "solid-dark", type: "feature", class: "bg-[#2B2B2B]" },
      { variant: "solid-dark", type: "success", class: "bg-[#217A45]" },
      { variant: "solid-dark", type: "warning", class: "bg-[#C46F10]" },
      { variant: "solid-dark", type: "error", class: "bg-[#B53636]" },

      { variant: "solid-vibrant", type: "info", class: "bg-[#4B8CFF]" },
      { variant: "solid-vibrant", type: "update", class: "bg-brand-primary-light" },
      { variant: "solid-vibrant", type: "feature", class: "bg-[#525252]" },
      { variant: "solid-vibrant", type: "success", class: "bg-[#3CB371]" },
      { variant: "solid-vibrant", type: "warning", class: "bg-[#F0A030]" },
      { variant: "solid-vibrant", type: "error", class: "bg-[#EF5350]" },
    ],
    defaultVariants: {
      variant: "solid",
      type: "info",
    },
  },
);

const typeIcons: Record<ToastType, typeof Info> = {
  info: Info,
  update: Megaphone,
  feature: Lightbulb,
  success: CheckCircle2,
  warning: AlertTriangle,
  error: OctagonAlert,
};

const typeIconColors: Record<ToastType, string> = {
  info: "text-[#4B8CFF]",
  update: "text-brand-primary-light",
  feature: "text-white",
  success: "text-[#3CB371]",
  warning: "text-[#EF5350]",
  error: "text-[#EF5350]",
};

export type ToastProps = Omit<HTMLAttributes<HTMLDivElement>, "children"> &
  VariantProps<typeof toastVariants> & {
    type?: ToastType;
    children: ReactNode;
    onClose?: () => void;
    dismissible?: boolean;
  };

export function Toast({
  type = "info",
  variant = "solid",
  children,
  onClose,
  dismissible = true,
  className,
  ...props
}: ToastProps) {
  const Icon = typeIcons[type];
  const isSolid = variant === "solid" || variant === "solid-dark" || variant === "solid-vibrant";
  const isDarkSurface = variant === "subtle" || variant === "colored-icon" || variant === "prominent";

  const iconClass = isSolid ? "text-white" : typeIconColors[type];
  const closeClass = isSolid || isDarkSurface ? "text-white/90 hover:text-white" : "text-[#C8C8C8] hover:text-white";

  return (
    <div
      role="status"
      className={cn(toastVariants({ variant, type }), className)}
      data-type={type}
      data-variant={variant}
      {...props}
    >
      <Icon className={cn("size-5 shrink-0", iconClass)} aria-hidden />
      <div className="min-w-0 flex-1 text-white">{children}</div>
      {dismissible ? (
        <button
          type="button"
          onClick={onClose}
          className={cn(
            "inline-flex size-5 shrink-0 items-center justify-center rounded-sm transition-colors",
            "focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-white/60",
            closeClass,
          )}
          aria-label="Dismiss"
        >
          <X className="size-3.5" aria-hidden />
        </button>
      ) : null}
    </div>
  );
}
