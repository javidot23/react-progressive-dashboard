import type { Meta, StoryObj } from "@storybook/react-vite";
import { Select } from "@/components/ui/Select";

const meta: Meta<typeof Select> = {
  title: "UI/Select",
  component: Select,
  tags: ["autodocs"],
  args: {
    placeholder: "Select",
    options: [
      { value: "one", label: "Option one" },
      { value: "two", label: "Option two" },
      { value: "three", label: "Option three" },
    ],
    defaultValue: "",
  },
  decorators: [
    (Story) => (
      <div className="w-64">
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const WithValue: Story = {
  args: {
    defaultValue: "two",
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    defaultValue: "one",
  },
};
