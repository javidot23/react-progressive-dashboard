import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Toast, type ToastType } from "@/components/ui/Toast";

const types: ToastType[] = ["info", "update", "feature", "success", "warning", "error"];

const messages: Record<ToastType, string> = {
  info: "You are in offline mode.",
  update: "An update is currently available.",
  feature: "Explore the new features in the 'What's New' section.",
  success: "Your purchase is complete.",
  warning: "Your saved credit card is about to expire.",
  error: "There was an error processing your payment.",
};

const variants = ["subtle", "colored-icon", "prominent", "solid", "solid-dark", "solid-vibrant"] as const;

const meta: Meta<typeof Toast> = {
  title: "UI/Toast",
  component: Toast,
  tags: ["autodocs"],
  args: {
    type: "info",
    variant: "solid",
    children: messages.info,
    onClose: fn(),
  },
  argTypes: {
    type: {
      control: "select",
      options: types,
    },
    variant: {
      control: "select",
      options: [...variants],
    },
    dismissible: { control: "boolean" },
  },
  parameters: {
    backgrounds: { default: "light" },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const AllVariants: Story = {
  parameters: {
    controls: { disable: true },
    layout: "padded",
  },
  render: () => (
    <div className="mx-auto grid max-w-7xl grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
      {variants.map((variant) => (
        <div key={variant} className="space-y-2">
          <p className="text-xs font-medium uppercase tracking-wide text-neutral-400">{variant}</p>
          <div className="space-y-2">
            {types.map((type) => (
              <Toast key={`${variant}-${type}`} type={type} variant={variant} onClose={fn()}>
                {messages[type]}
              </Toast>
            ))}
          </div>
        </div>
      ))}
    </div>
  ),
};

export const Info: Story = {
  args: { type: "info", children: messages.info },
};

export const Update: Story = {
  args: { type: "update", children: messages.update },
};

export const Feature: Story = {
  args: { type: "feature", children: messages.feature },
};

export const Success: Story = {
  args: { type: "success", children: messages.success },
};

export const Warning: Story = {
  args: { type: "warning", children: messages.warning },
};

export const Error: Story = {
  args: { type: "error", children: messages.error },
};

export const Subtle: Story = {
  args: { variant: "subtle", type: "info", children: messages.info },
};

export const ColoredIcon: Story = {
  args: { variant: "colored-icon", type: "warning", children: messages.warning },
};

export const Prominent: Story = {
  args: { variant: "prominent", type: "error", children: messages.error },
};
