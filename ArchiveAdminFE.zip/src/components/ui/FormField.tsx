import type { ReactNode } from "react";
import { Diamond } from "lucide-react";
import { cn } from "@/utils";

export type FormFieldProps = {
  id: string;
  label: string;
  children: ReactNode;
  className?: string;
  required?: boolean;
  hint?: string;
  error?: string;
};

export function FormField({ id, label, children, className, required, hint, error }: FormFieldProps) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <label
        htmlFor={id}
        className="font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-semibold tracking-normal text-ui-text-heading"
      >
        {required ? (
          <span className="mr-1 text-status-error-main" aria-hidden>
            *
          </span>
        ) : null}
        {label}
        {required ? <span className="sr-only"> (required)</span> : null}
      </label>
      {children}
      {error ? (
        <p id={`${id}-error`} role="alert" className="flex items-center gap-1.5 text-xs font-medium text-status-error-main">
          <Diamond className="size-3 shrink-0 fill-current" aria-hidden />
          <span>{error}</span>
        </p>
      ) : hint ? (
        <p id={`${id}-hint`} className="text-xs text-ui-text-secondary">
          {hint}
        </p>
      ) : null}
    </div>
  );
}
