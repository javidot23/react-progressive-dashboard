import type { HTMLAttributes } from "react";
import { cn } from "@/utils";

export type StatusBadgeStatus =
  "Active" | "Pending verification" | "Pending" | "Suspended" | "Inactive" | "Disabled" | "Deleted" | "Deactivated";

export type StatusBadgeProps = HTMLAttributes<HTMLSpanElement> & {
  status: StatusBadgeStatus;
};

const statusStyles: Record<StatusBadgeStatus, string> = {
  Active: "bg-[#D8FEE7] text-[#3B3B3B]",
  "Pending verification": "bg-[#D6EAF8] text-[#3B3B3B]",
  Pending: "bg-[#D6EAF8] text-[#3B3B3B]",
  Suspended: "bg-[#FCD9D1] text-[#3B3B3B]",
  Inactive: "bg-[#E2E8F0] text-[#3B3B3B]",
  Disabled: "bg-[#E2E8F0] text-[#3B3B3B]",
  Deleted: "bg-[#FCD9D1] text-[#3B3B3B]",
  Deactivated: "bg-[#FCD9D1] text-[#3B3B3B]",
};

export function StatusBadge({ status, className, ...props }: StatusBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex w-full items-center justify-center rounded-full px-2 py-1 ",
        "font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-medium tracking-normal",
        statusStyles[status],
        className,
      )}
      {...props}
    >
      {status}
    </span>
  );
}
