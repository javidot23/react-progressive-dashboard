import type { Meta, StoryObj } from "@storybook/react-vite";
import { StatusBadge } from "@/components/ui/StatusBadge";

const meta: Meta<typeof StatusBadge> = {
  title: "UI/StatusBadge",
  component: StatusBadge,
  tags: ["autodocs"],
  args: {
    status: "Active",
  },
  decorators: [
    (Story) => (
      <div className="w-28">
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Active: Story = {
  args: { status: "Active" },
};

export const Deactivated: Story = {
  args: { status: "Deactivated" },
};
