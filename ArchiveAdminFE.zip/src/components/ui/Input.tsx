import { forwardRef, type InputHTMLAttributes, type ReactNode } from "react";
import { Search } from "lucide-react";
import { cn } from "@/utils";

export const inputBaseClassName = cn(
  "h-8 w-full rounded-md border border-[#8A8A8A] bg-white px-3",
  "font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-medium italic tracking-normal",
  "text-ui-text-heading placeholder:italic placeholder:text-ui-text-secondary",
  "focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-1",
  "disabled:cursor-not-allowed disabled:opacity-50",
);

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  endAdornment?: ReactNode;
  containerClassName?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, endAdornment, containerClassName, ...props }, ref) => {
    if (endAdornment) {
      return (
        <div className={cn("relative flex w-full items-center", containerClassName)}>
          <input ref={ref} className={cn(inputBaseClassName, "pr-10", className)} {...props} />
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-0">{endAdornment}</div>
        </div>
      );
    }

    return <input ref={ref} className={cn(inputBaseClassName, className)} {...props} />;
  },
);

Input.displayName = "Input";

export type SearchInputProps = Omit<InputHTMLAttributes<HTMLInputElement>, "type"> & {
  containerClassName?: string;
  onSearch?: () => void;
};

export const SearchInput = forwardRef<HTMLInputElement, SearchInputProps>(
  ({ className, containerClassName, onSearch, ...props }, ref) => {
    return (
      <div className={cn("flex h-8 w-full overflow-hidden rounded-md border border-[#8A8A8A] bg-white", containerClassName)}>
        <input
          ref={ref}
          type="search"
          className={cn(
            "h-full min-w-0 flex-1 border-0 bg-transparent px-3",
            "font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-medium italic tracking-normal",
            "text-ui-text-heading placeholder:italic placeholder:text-ui-text-secondary",
            "focus-visible:outline-hidden",
            className,
          )}
          {...props}
        />
        <button
          type={onSearch ? "button" : "submit"}
          onClick={onSearch}
          className="inline-flex h-8 w-8 shrink-0 items-center justify-center bg-[#DDDBF7] text-[#461E96] transition-colors hover:bg-brand-primary-200 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-inset"
          aria-label={props["aria-label"] ?? "Search"}
        >
          <Search className="h-4 w-4" aria-hidden />
        </button>
      </div>
    );
  },
);

SearchInput.displayName = "SearchInput";
