import { useEffect, useId, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { useDialogFocusTrap } from "@/components/atoms";
import { cn } from "@/utils";

export type DrawerProps = {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  className?: string;
  /** Panel max width. Defaults to design-system drawer width. */
  panelClassName?: string;
};

export function Drawer({ open, title, onClose, children, footer, className, panelClassName }: DrawerProps) {
  const titleId = useId();
  const panelRef = useRef<HTMLDivElement>(null);

  useDialogFocusTrap({
    isOpen: open,
    onClose,
    containerRef: panelRef,
  });

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  if (!open) return null;

  return createPortal(
    <div className={cn("fixed inset-0 z-50 mt-[80px] flex justify-end", className)} role="presentation">
      <button type="button" className="absolute inset-0 bg-neutral-900/40" aria-label="Close dialog overlay" onClick={onClose} />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={cn("relative z-10 flex h-full w-full max-w-md flex-col bg-white shadow-xl outline-hidden", panelClassName)}
      >
        <header className="flex shrink-0 items-center justify-between border-b border-[#E8E8E8] px-5 py-4">
          <h2
            id={titleId}
            className="font-body-lg text-[length:var(--text-body-xl)] leading-body-xl font-semibold tracking-normal text-[#0F172A]"
          >
            {title}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-8 w-8 items-center justify-center rounded-md text-ui-text-secondary transition-colors hover:bg-ui-background-muted hover:text-ui-text-heading focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main"
            aria-label="Close"
          >
            <X className="h-6 w-6" aria-hidden />
          </button>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">{children}</div>

        {footer ? (
          <footer className="flex shrink-0 items-center justify-end gap-3 border-t border-ui-border-secondary px-5 py-4">
            {footer}
          </footer>
        ) : null}
      </div>
    </div>,
    document.body,
  );
}
