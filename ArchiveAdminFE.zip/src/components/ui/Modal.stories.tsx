import type { Meta, StoryObj } from "@storybook/react-vite";
import { fn } from "storybook/test";
import { Checkbox } from "@/components/atoms";
import { Button } from "@/components/ui/Button";
import { FormField } from "@/components/ui/FormField";
import { Input } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";

const shortCopy =
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";

const longCopy = Array.from({ length: 3 }, () => shortCopy).join("\n\n");

const secondaryButtonClass =
  "border-brand-primary-main text-brand-primary-main hover:bg-brand-primary-50 hover:text-brand-primary-main";

function DefaultFooter() {
  return (
    <>
      <Button type="button" variant="outline" size="sm" className={secondaryButtonClass}>
        Secondary
      </Button>
      <Button type="button" size="sm">
        Primary
      </Button>
    </>
  );
}

const meta: Meta<typeof Modal> = {
  title: "UI/Modal",
  component: Modal,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
  },
  args: {
    open: true,
    title: "Modal dialog",
    onClose: fn(),
    children: <p className="text-sm leading-relaxed text-ui-text-heading">{shortCopy}</p>,
    footer: <DefaultFooter />,
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const ScrollableContent: Story = {
  args: {
    children: <div className="space-y-4 text-sm leading-relaxed whitespace-pre-line text-ui-text-heading">{longCopy}</div>,
  },
};

export const FormContent: Story = {
  args: {
    panelClassName: "max-w-xl",
    children: (
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <FormField id="first-name" label="First name">
            <Input id="first-name" />
          </FormField>
          <FormField id="last-name" label="Last name">
            <Input id="last-name" />
          </FormField>
        </div>
        <FormField id="company-name" label="Company name">
          <Input id="company-name" />
        </FormField>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <FormField id="phone" label="Phone number">
            <Input id="phone" placeholder="555-555-5555" />
          </FormField>
          <FormField id="extension" label="Extension">
            <Input id="extension" placeholder="5555" />
          </FormField>
        </div>
        <FormField id="comments" label="Additional comments">
          <textarea
            id="comments"
            rows={4}
            className="w-full rounded-md border border-[#8A8A8A] bg-white px-3 py-2 text-sm text-ui-text-heading focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main"
          />
        </FormField>
        <fieldset className="space-y-2">
          <legend className="font-body-sm text-[length:var(--text-body-sm)] font-bold text-ui-text-heading">Select one</legend>
          <label className="flex items-start gap-2 text-sm text-ui-text-heading">
            <input type="radio" name="select-one" className="mt-1 accent-brand-primary-main" defaultChecked />
            <span>{shortCopy.slice(0, 80)}.</span>
          </label>
          <label className="flex items-start gap-2 text-sm text-ui-text-heading">
            <input type="radio" name="select-one" className="mt-1 accent-brand-primary-main" />
            <span>{shortCopy.slice(0, 90)}.</span>
          </label>
          <label className="flex items-start gap-2 text-sm text-ui-text-heading">
            <Checkbox className="mt-1" />
            <span>{shortCopy.slice(0, 70)}.</span>
          </label>
        </fieldset>
        <p className="text-sm leading-relaxed text-ui-text-heading">{shortCopy}</p>
      </div>
    ),
  },
};

export const Danger: Story = {
  args: {
    tone: "danger",
    children: <p className="text-sm leading-relaxed text-ui-text-heading">{shortCopy}</p>,
    footer: (
      <>
        <Button type="button" variant="outline" size="sm" className={secondaryButtonClass}>
          Secondary
        </Button>
        <Button type="button" variant="destructive" size="sm">
          Primary
        </Button>
      </>
    ),
  },
};
