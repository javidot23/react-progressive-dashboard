import type { Meta, StoryObj } from "@storybook/react-vite";
import { Button } from "@/components/ui/Button";
import { PageHeader } from "@/components/ui/PageHeader";

const meta: Meta<typeof PageHeader> = {
  title: "UI/PageHeader",
  component: PageHeader,
  tags: ["autodocs"],
  args: {
    title: "Tenants",
    description: "54 Organizations",
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const WithActions: Story = {
  args: {
    actions: (
      <>
        <Button type="button" className="!h-[32px]">
          Add Tenant
        </Button>
        <Button type="button" variant="outline" className="!h-[32px]">
          Add Multi Tenant User
        </Button>
      </>
    ),
  },
};
