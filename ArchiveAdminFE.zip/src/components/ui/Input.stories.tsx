import type { Meta, StoryObj } from "@storybook/react-vite";
import { Input, SearchInput } from "@/components/ui/Input";

const meta: Meta<typeof Input> = {
  title: "UI/Input",
  component: Input,
  tags: ["autodocs"],
  args: {
    placeholder: "Search Tenants",
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const WithValue: Story = {
  args: {
    defaultValue: "Ajanta",
  },
};

export const Search: StoryObj<typeof SearchInput> = {
  render: (args) => (
    <form
      className="max-w-xl"
      onSubmit={(event) => {
        event.preventDefault();
      }}
    >
      <SearchInput {...args} placeholder="Search Tenants" aria-label="Search tenants" />
    </form>
  ),
};
