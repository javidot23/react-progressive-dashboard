import { useMemo } from "react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./DropdownMenu";
import { cn } from "@/utils";

export type DropdownSelectOption = {
  value: string;
  label: string;
};

export type DropdownSelectProps = {
  id?: string;
  value: string;
  onValueChange: (value: string) => void;
  options: ReadonlyArray<DropdownSelectOption>;
  placeholder?: string;
  disabled?: boolean;
  "aria-label"?: string;
  className?: string;
  containerClassName?: string;
  contentClassName?: string;
};

/**
 * Simple-list select built on DropdownMenu (Storybook: SimpleText).
 */
export function DropdownSelect({
  id,
  value,
  onValueChange,
  options,
  placeholder = "Select",
  disabled,
  "aria-label": ariaLabel,
  className,
  containerClassName,
  contentClassName,
}: DropdownSelectProps) {
  const selected = useMemo(() => options.find((option) => option.value === value), [options, value]);
  const label = selected?.label ?? placeholder;
  const isEmpty = !selected;

  return (
    <DropdownMenu className={cn("w-full", containerClassName)}>
      <DropdownMenuTrigger
        id={id}
        disabled={disabled}
        aria-label={ariaLabel}
        className={cn(
          "h-10 w-full min-w-0 justify-between border border-ui-border-secondary bg-white px-3",
          "font-body-sm text-[length:var(--text-body-sm)] leading-body-sm italic tracking-normal",
          isEmpty ? "text-ui-text-secondary" : "text-ui-text-heading not-italic",
          className,
        )}
      >
        {label}
      </DropdownMenuTrigger>
      <DropdownMenuContent className={cn("w-full min-w-full", contentClassName)}>
        {options.map((option) => (
          <DropdownMenuItem
            key={option.value}
            selected={option.value === value}
            showSelectedCheck={false}
            onClick={() => onValueChange(option.value)}
          >
            {option.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
