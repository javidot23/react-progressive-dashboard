import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none gap-1.5",
  {
    variants: {
      variant: {
        default: "bg-brand-primary-main text-white hover:bg-brand-primary-dark",
        secondary: "bg-neutral-100 text-ui-text-heading hover:bg-neutral-200",
        outline: "border border-ui-border-secondary bg-white hover:bg-ui-background-secondary",
        ghost: "hover:bg-neutral-100",
        destructive: "bg-status-error-main text-white hover:opacity-90",
      },
      size: {
        sm: "h-8 px-3 text-xs [&_svg]:size-3",
        md: "h-10 px-4 py-2 text-sm [&_svg]:size-4",
        lg: "h-12 px-8 text-base [&_svg]:size-5",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "md",
    },
  },
);

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  isLoading?: boolean;
  startIcon?: ReactNode;
  endIcon?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, isLoading, children, disabled, startIcon, endIcon, ...props }, ref) => {
    return (
      <button
        {...props}
        className={cn(buttonVariants({ variant, size }), className)}
        ref={ref}
        disabled={disabled || isLoading}
        aria-busy={isLoading || undefined}
      >
        {isLoading ? (
          <span
            aria-hidden="true"
            className="h-4 w-4 shrink-0 animate-spin rounded-full border-2 border-current border-t-transparent"
          />
        ) : (
          startIcon && (
            <span aria-hidden="true" className="inline-flex shrink-0">
              {startIcon}
            </span>
          )
        )}
        {children}
        {!isLoading && endIcon && (
          <span aria-hidden="true" className="inline-flex shrink-0">
            {endIcon}
          </span>
        )}
      </button>
    );
  },
);

Button.displayName = "Button";
