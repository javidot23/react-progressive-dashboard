import { useEffect, useId, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AlertTriangle, X } from "lucide-react";
import { useDialogFocusTrap } from "@/components/atoms";
import { cn } from "@/utils";

export type ModalTone = "default" | "danger";

export type ModalProps = {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  tone?: ModalTone;
  className?: string;
  /** Dialog panel width classes. Defaults to a mid-size modal. */
  panelClassName?: string;
  titleClassName?: string;
  footerClassName?: string;
};

export function Modal({
  open,
  title,
  onClose,
  children,
  footer,
  tone = "default",
  className,
  panelClassName,
  titleClassName,
  footerClassName,
}: ModalProps) {
  const titleId = useId();
  const panelRef = useRef<HTMLDivElement>(null);
  const isDanger = tone === "danger";

  useDialogFocusTrap({
    isOpen: open,
    onClose,
    containerRef: panelRef,
  });

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  if (!open) return null;

  return createPortal(
    <div className={cn("fixed inset-0 z-50 flex items-center justify-center p-4", className)} role="presentation">
      <button type="button" className="absolute inset-0 bg-neutral-900/40" aria-label="Close dialog overlay" onClick={onClose} />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={cn(
          "relative z-10 flex max-h-[min(90vh,720px)] w-full max-w-lg flex-col overflow-hidden rounded-lg border border-ui-border-secondary bg-white shadow-xl outline-hidden",
          panelClassName,
        )}
      >
        <header className="flex shrink-0 items-center justify-between gap-3 border-b border-ui-border-secondary px-5 py-4">
          <div className="flex min-w-0 items-center gap-2">
            {isDanger ? <AlertTriangle className="size-5 shrink-0 text-status-error-main" aria-hidden /> : null}
            <h2
              id={titleId}
              className={cn(
                "font-body-xl text-[length:var(--text-body-xl)] leading-body-xl font-bold tracking-normal",
                isDanger ? "text-status-error-main" : "text-[#0F172A]",
                titleClassName,
              )}
            >
              {title}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md text-ui-text-secondary transition-colors hover:bg-ui-background-muted hover:text-ui-text-heading focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main"
            aria-label="Close"
          >
            <X className="h-5 w-5" aria-hidden />
          </button>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">{children}</div>

        {footer ? (
          <footer
            className={cn(
              "flex shrink-0 items-center justify-end gap-3 border-t border-ui-border-secondary px-5 py-4",
              footerClassName,
            )}
          >
            {footer}
          </footer>
        ) : null}
      </div>
    </div>,
    document.body,
  );
}
