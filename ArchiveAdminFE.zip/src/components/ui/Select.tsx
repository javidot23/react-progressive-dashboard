import { forwardRef, type SelectHTMLAttributes } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/utils";
import { inputBaseClassName } from "./Input";

export type SelectOption = {
  value: string;
  label: string;
};

export type SelectProps = Omit<SelectHTMLAttributes<HTMLSelectElement>, "children"> & {
  options: ReadonlyArray<SelectOption>;
  placeholder?: string;
  containerClassName?: string;
};

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ className, options, placeholder, containerClassName, value, ...props }, ref) => {
    const isEmpty = value === undefined || value === "";

    return (
      <div className={cn("relative w-full", containerClassName)}>
        <select
          ref={ref}
          value={value}
          className={cn(inputBaseClassName, "appearance-none pr-9", isEmpty && "text-ui-text-secondary", className)}
          {...props}
        >
          {placeholder ? (
            <option value="" disabled>
              {placeholder}
            </option>
          ) : null}
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <ChevronDown
          className="pointer-events-none absolute top-1/2 right-3 h-4 w-4 -translate-y-1/2 text-ui-text-secondary"
          aria-hidden
        />
      </div>
    );
  },
);

Select.displayName = "Select";
