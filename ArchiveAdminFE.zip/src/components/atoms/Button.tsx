import { forwardRef } from "react";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "secondary" | "outline" | "outline_bold" | "ghost" | "destructive";
  size?: "sm" | "md" | "lg";
  isLoading?: boolean;
  asChild?: boolean;
  startIcon?: ReactNode;
  endIcon?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { className, variant = "default", size = "md", isLoading, children, disabled, asChild = false, startIcon, endIcon, ...props },
    ref,
  ) => {
    const baseStyles =
      "inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none gap-1";

    const variants = {
      default: "bg-brand-primary-main text-white hover:bg-brand-primary-dark",
      secondary: "bg-ui-background-muted text-ui-text-primary hover:bg-ui-background-secondary",
      outline_bold:
        "border border-2 border-brand-primary-main bg-ui-background-primary text-brand-primary-main hover:bg-ui-background-muted font-bold",
      outline:
        "border border-2 border-brand-primary-main bg-ui-background-primary text-brand-primary-main hover:bg-ui-background-muted",
      ghost: "hover:bg-ui-background-muted",
      destructive: "bg-status-error-main text-white hover:bg-status-error-dark",
    };

    const sizes = {
      sm: "h-8 px-3 text-xs [&_svg]:size-3",
      md: "h-10 px-4 py-2 text-sm [&_svg]:size-4",
      lg: "h-12 px-8 text-lg [&_svg]:size-5",
    };

    if (asChild) {
      return children as React.ReactElement;
    }

    return (
      <button
        {...props}
        className={cn(baseStyles, variants[variant], sizes[size], className)}
        ref={ref}
        disabled={disabled || isLoading}
        aria-busy={isLoading || undefined}
      >
        {isLoading ? (
          <span
            aria-hidden="true"
            className="h-4 w-4 shrink-0 animate-spin rounded-full border-2 border-current border-t-transparent"
          />
        ) : (
          startIcon && (
            <span aria-hidden="true" className="inline-flex shrink-0">
              {startIcon}
            </span>
          )
        )}

        {children}

        {!isLoading && endIcon && (
          <span aria-hidden="true" className="inline-flex shrink-0">
            {endIcon}
          </span>
        )}
      </button>
    );
  },
);

Button.displayName = "Button";
