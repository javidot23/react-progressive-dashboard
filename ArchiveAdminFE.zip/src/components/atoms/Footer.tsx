import { cn } from "@/lib/utils";

export type FooterProps = {
  className?: string;
  contentClassName?: string;
};

export function Footer({ className, contentClassName }: FooterProps) {
  // const version = import.meta.env.VITE_APP_VERSION || (globalThis as { __APP_VERSION__?: string }).__APP_VERSION__;

  return (
    <footer className={cn("w-full border-t border-[#E2E8F0] bg-ui-background-primary", className)}>
      <div className="mx-auto w-full max-w-(--breakpoint-2xl)">
        <div className={cn("space-y-3 px-4 sm:px-6 lg:px-9", contentClassName)}>
          <div className="py-8 text-xs text-[#3B3B3B]">Copyright © Cencora, Inc. All Rights Reserved.</div>
        </div>
      </div>
    </footer>
  );
}
