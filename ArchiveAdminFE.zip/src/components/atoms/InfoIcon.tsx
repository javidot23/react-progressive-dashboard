import { Info } from "lucide-react";
import { cn } from "@/lib/utils";

export type InfoIconProps = {
  className?: string;
  label?: string;
};

export function InfoIcon({ className, label = "More information" }: InfoIconProps) {
  return <Info className={cn("h-4 w-4 text-ui-text-secondary", className)} aria-label={label} />;
}
