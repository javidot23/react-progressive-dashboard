import type { ElementType, HTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

type TypographyVariant = "body2" | "caption" | "body1" | "label";
type TypographyColor = "primary" | "secondary" | "inherit";

export type TypographyProps = HTMLAttributes<HTMLElement> & {
  as?: ElementType;
  variant?: TypographyVariant;
  color?: TypographyColor;
  children?: ReactNode;
};

const variantClasses: Record<TypographyVariant, string> = {
  body1: "text-sm leading-5",
  body2: "text-sm leading-5",
  caption: "text-xs leading-4",
  label: "text-sm font-medium leading-5",
};

const colorClasses: Record<TypographyColor, string> = {
  primary: "text-ui-text-primary",
  secondary: "text-ui-text-secondary",
  inherit: "text-inherit",
};

export function Typography({ as, variant = "body2", color = "primary", className, children, ...props }: TypographyProps) {
  const Component = as ?? "p";

  return (
    <Component className={cn(variantClasses[variant], colorClasses[color], className)} {...props}>
      {children}
    </Component>
  );
}
