import { useRef, useEffect, useCallback, useState, type KeyboardEvent, type FocusEvent } from "react";
import { LogOut, CircleUserRound } from "lucide-react";
import { useProfile } from "@/hooks/useProfile";
import { useAuth } from "@/app/providers";
import { getUserFullName, getUserInitials } from "@/lib/profileHelpers";

export const ProfilePictureDropdown = () => {
  const { profile } = useProfile();
  const { logout } = useAuth();
  const containerRef = useRef<HTMLDivElement>(null);

  const [isOpen, setIsOpen] = useState(false);

  const toggleIsOpen = useCallback(() => setIsOpen((prev) => !prev), []);
  const handleClose = useCallback(() => setIsOpen(false), []);

  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        handleClose();
      }
    },
    [handleClose],
  );

  const handleBlur = useCallback(
    (event: FocusEvent) => {
      if (!containerRef.current?.contains(event.relatedTarget as Node)) {
        handleClose();
      }
    },
    [handleClose],
  );

  useEffect(() => {
    if (isOpen && containerRef.current) {
      containerRef.current.focus();
    }
  }, [isOpen]);

  const handleSignOut = () => {
    handleClose();
    void logout();
  };

  const displayName = getUserFullName(profile);
  const initials = getUserInitials(profile);
  const showInitials = initials && initials !== "?";

  return (
    <div ref={containerRef} className="relative ml-2" onKeyDown={handleKeyDown} onBlur={handleBlur} tabIndex={-1}>
      <button
        type="button"
        onClick={toggleIsOpen}
        className="flex items-center justify-center transition-colors duration-200 hover:opacity-80"
        aria-label="User profile menu"
        aria-expanded={isOpen}
        aria-haspopup="true"
        title={displayName || profile?.mail || "User"}
      >
        {profile?.photoDataUrl ? (
          <img
            src={profile.photoDataUrl}
            alt="Profile"
            className="h-10 w-10 rounded-full border-2 border-[#E2E8F0] object-cover"
          />
        ) : showInitials ? (
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[linear-gradient(56.03deg,_#461E96_50%,_#00DC8C_85.83%)] text-xs font-semibold text-white">
            {initials}
          </div>
        ) : (
          <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-[#E2E8F0] bg-white">
            <CircleUserRound className="h-6 w-6 text-[#461E96]" />
          </div>
        )}
      </button>
      {isOpen && (
        <div className="absolute top-full right-0 z-10000 mt-2 w-56 rounded-lg border border-gray-200 bg-white py-2 shadow-lg">
          <div className="border-b border-gray-100 px-3 pb-2">
            <p className="truncate text-sm text-gray-600">{profile?.mail || profile?.userPrincipalName || "No email"}</p>
          </div>
          <div className="px-1 pt-1">
            <button
              type="button"
              onClick={handleSignOut}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm font-medium text-red-600 transition-colors hover:bg-red-50"
            >
              <LogOut className="h-4 w-4" />
              <span>Sign out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfilePictureDropdown;
