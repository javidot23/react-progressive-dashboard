import { useState, useRef, useEffect, useLayoutEffect, type RefObject, type UIEvent } from "react";
import { Download, Eye } from "lucide-react";
import { Link } from "react-router-dom";
import { useIsMobile } from "@/hooks/useMobile";
import { userActionService, type UserAction } from "@/lib/apiServices";
import { ROUTES } from "@/constants/routes";

interface UserMenuDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  triggerRef: RefObject<HTMLButtonElement | null>;
}

const getTodayDate = (): string => {
  return new Date().toISOString().split("T")[0] ?? "";
};

const formatActionDate = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "a few moments ago";
  if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? "s" : ""} ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
  if (diffDays === 1) return "yesterday";
  if (diffDays < 7) return `${diffDays} days ago`;

  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
};

const getActionText = (action: UserAction): string => {
  if (action.substituted_material) {
    const fromVendor = `${action.vendor_name}${action.vendor_nbr ? ` • ${action.vendor_nbr}` : ""}`;
    const toVendor = `${action.substituted_material.vendor_name}${action.substituted_material.vendor_nbr ? ` • ${action.substituted_material.vendor_nbr}` : ""}`;
    return `You've switched Manufacturer from ${fromVendor} to ${toVendor}`;
  }
  if (action.potential_action) {
    return `You've ${action.potential_action.recommendation} for ${action.material_name}`;
  }
  if (action.action === "no_action") {
    return `You've selected No Action Required for ${action.material_name}`;
  }
  return `You've performed an action for ${action.material_name}`;
};

const LIMIT = 10;

export function UserMenuDropdown({ isOpen, onClose, triggerRef }: UserMenuDropdownProps) {
  const dropdownRef = useRef<HTMLDivElement>(null);
  const isFetchingRef = useRef(false);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 72, right: 16 });
  const [isPositioned, setIsPositioned] = useState(false);
  const isMobile = useIsMobile();
  const [activityItems, setActivityItems] = useState<UserAction[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [offset, setOffset] = useState(0);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useLayoutEffect(() => {
    if (isOpen && triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      setDropdownPosition({
        top: rect.bottom + 8,
        right: isMobile ? 16 : window.innerWidth - rect.right,
      });
      setIsPositioned(true);
    } else {
      setIsPositioned(false);
    }
  }, [isOpen, isMobile, triggerRef]);

  useEffect(() => {
    if (!isOpen) return;

    const fetchInitialActions = async () => {
      if (isFetchingRef.current) return;

      isFetchingRef.current = true;
      setLoading(true);
      setError(null);
      setActivityItems([]);
      setOffset(0);
      setHasMore(true);

      try {
        const response = await userActionService.getUserActions(LIMIT, 0, getTodayDate());

        if (response.data.success && response.data.data) {
          setActivityItems(response.data.data.results);
          setOffset(LIMIT);
          setHasMore(response.data.data.next !== null);
        }
      } catch (err) {
        console.error("Error fetching user actions:", err);
        setError("Failed to load actions. Please try again.");
      } finally {
        setLoading(false);
        isFetchingRef.current = false;
      }
    };

    void fetchInitialActions();
  }, [isOpen]);

  const handleScroll = async (e: UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    const isNearBottom = scrollTop + clientHeight >= scrollHeight - 10;

    if (!isNearBottom || !hasMore || loading || isFetchingRef.current) return;

    isFetchingRef.current = true;
    setLoading(true);

    try {
      const response = await userActionService.getUserActions(LIMIT, offset, getTodayDate());

      if (response.data.success && response.data.data) {
        setActivityItems((prev) => [...prev, ...response.data.data.results]);
        setOffset((prev) => prev + LIMIT);
        setHasMore(response.data.data.next !== null);
      }
    } catch (err) {
      console.error("Error fetching more actions:", err);
    } finally {
      setLoading(false);
      isFetchingRef.current = false;
    }
  };

  const handleExport = async () => {
    if (exporting) return;

    setExporting(true);
    try {
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const todayStr = today.toISOString().split("T")[0] ?? "";
      const tomorrowStr = tomorrow.toISOString().split("T")[0] ?? "";

      const response = await userActionService.exportUserActions(todayStr, tomorrowStr);

      const blob = new Blob([response.data], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `actions_${todayStr}_to_${tomorrowStr}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Error exporting:", err);
      alert("Failed to export actions. Please try again.");
    } finally {
      setExporting(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        triggerRef.current &&
        !triggerRef.current.contains(event.target as Node)
      ) {
        onClose();
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };

    const handleScrollClose = () => {
      if (isMobile) onClose();
    };

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEscape);
    if (isMobile) {
      window.addEventListener("scroll", handleScrollClose, { passive: true });
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
      if (isMobile) {
        window.removeEventListener("scroll", handleScrollClose);
      }
    };
  }, [isOpen, onClose, triggerRef, isMobile]);

  if (!isOpen || !isPositioned) return null;

  return (
    <div
      ref={dropdownRef}
      className="rounded-lg border border-ui-border-primary bg-ui-background-primary shadow-xl"
      style={
        isMobile
          ? {
              position: "fixed",
              top: `${dropdownPosition.top}px`,
              left: "16px",
              right: "16px",
              width: "calc(100vw - 32px)",
              maxHeight: "70vh",
              zIndex: 50,
              transform: "translate3d(0, 0, 0)",
              WebkitTransform: "translate3d(0, 0, 0)",
            }
          : {
              position: "fixed",
              top: `${dropdownPosition.top}px`,
              right: `${dropdownPosition.right}px`,
              width: "400px",
              maxHeight: "500px",
              zIndex: 50,
            }
      }
      role="dialog"
      aria-label="User action log"
    >
      <div
        className={`flex h-9 items-center justify-between border-b border-ui-border-primary px-4 md:px-6 ${isMobile ? "h-auto flex-col gap-2 py-2" : ""}`}
      >
        <h3 className="text-base font-medium text-gray-900">User Action Log</h3>
        <button
          type="button"
          className={`flex h-6 items-center space-x-1 rounded border-2 border-true-blue-700 bg-white px-3 text-sm font-medium text-true-blue-700 transition-colors hover:bg-true-blue-50 ${isMobile ? "w-full justify-center" : ""} ${exporting ? "cursor-not-allowed opacity-50" : ""}`}
          onClick={() => void handleExport()}
          disabled={exporting}
          aria-label="Export user actions as CSV"
        >
          <Download className="h-4 w-4" />
          <span>{exporting ? "Exporting..." : "Export"}</span>
        </button>
      </div>
      <div
        className={`max-h-80 overflow-y-auto py-2 ${isMobile ? "max-h-60" : ""}`}
        onScroll={(event) => void handleScroll(event)}
        role="list"
      >
        {error ? (
          <div className="px-4 py-8 text-center text-sm text-red-600 md:px-6">{error}</div>
        ) : activityItems.length === 0 && !loading ? (
          <div className="px-4 py-8 text-center text-sm text-ui-text-secondary md:px-6">No actions taken today</div>
        ) : (
          <>
            {activityItems.map((item) => (
              <div
                key={item.id}
                className={`border-b border-ui-border-primary px-4 py-4 transition-colors last:border-b-0 hover:bg-ui-background-muted md:px-6 ${isMobile ? "py-3" : ""}`}
                role="listitem"
              >
                <div className="space-y-1">
                  <p className="text-sm leading-relaxed font-medium text-ui-text-primary">{getActionText(item)}</p>
                  <p className="text-xs font-medium text-brand-primary-main">{formatActionDate(item.created_at)}</p>
                </div>
              </div>
            ))}
            {loading && <div className="px-4 py-4 text-center text-sm text-ui-text-secondary md:px-6">Loading...</div>}
          </>
        )}
      </div>
      <div
        className={`flex h-9 items-center justify-center border-t border-ui-border-primary px-4 md:px-6 ${isMobile ? "h-auto py-3" : ""}`}
      >
        <Link
          to={ROUTES.EXPORT_ACTIONS}
          onClick={onClose}
          className={`flex items-center space-x-2 text-sm font-medium text-ui-text-secondary no-underline transition-colors hover:text-ui-text-primary ${isMobile ? "w-full justify-center py-2" : ""}`}
        >
          <Eye className="h-4 w-4" />
          <span>View More</span>
        </Link>
      </div>
    </div>
  );
}
