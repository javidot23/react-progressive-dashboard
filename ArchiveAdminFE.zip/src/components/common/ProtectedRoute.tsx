import { type ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/app/providers";

interface ProtectedRouteProps {
  children: ReactNode;
  redirectTo?: string;
}

function LoadingSpinner() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div
        className="size-16 animate-spin rounded-full border-2 border-brand-primary-main border-t-transparent"
        role="status"
        aria-label="Loading"
      />
    </div>
  );
}

export function ProtectedRoute({ children, redirectTo = "/login" }: ProtectedRouteProps) {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  // Children must stay unmounted until the session is known: rendering them early
  // fires authenticated requests whose 401 sends the whole window to the IdP.
  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (!isAuthenticated) {
    return <Navigate to={redirectTo} state={{ from: location.pathname }} replace />;
  }

  return children;
}
