import { NavLink, Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState, type KeyboardEvent } from "react";
import { ProfilePictureDropdown } from "@/components/molecules";
import { useIsMobile } from "@/hooks/useMobile";
import { ROUTES } from "@/constants/routes";
import { cn } from "@/lib/utils";
import PrimaryLogo from "@/assets/icons/primary-logo.svg";

const HEADER_HEIGHT_MOBILE = 64;
const HEADER_HEIGHT_DESKTOP = 83;
const NAV_OFFSET_DESKTOP = 36;
const ACTIVE_INDICATOR_OFFSET = -22;

const NAV_ITEMS = [
  { name: "Tenants", href: ROUTES.TENANTS, end: true },
  { name: "Users", href: ROUTES.USERS, end: false },
  // { name: "Audit Log", href: ROUTES.AUDIT_LOG, end: false }, DO NOT DELETE, WILL BE IMPLEMENTED IN THE FUTURE
] as const;

function isNavItemActive(name: string, isActive: boolean, pathname: string): boolean {
  if (name === "Tenants") return isActive || pathname.startsWith("/tenants/");
  return isActive;
}

export interface HeaderProps {
  className?: string;
}

export const Header = ({ className }: HeaderProps) => {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();

  const toggleMobileMenu = useCallback(() => setIsMobileMenuOpen((prev) => !prev), []);
  const closeMobileMenu = useCallback(() => setIsMobileMenuOpen(false), []);

  useEffect(() => {
    if (isMobileMenuOpen && mobileMenuRef.current) {
      const firstLink = mobileMenuRef.current.querySelector("a");
      firstLink?.focus();
    }
  }, [isMobileMenuOpen]);

  useEffect(() => {
    if (!isMobileMenuOpen) return;
    const originalOverflow = window.document.body.style.overflow;
    window.document.body.style.overflow = "hidden";
    return () => {
      window.document.body.style.overflow = originalOverflow;
    };
  }, [isMobileMenuOpen]);

  const handleMobileMenuKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (event.key === "Escape") closeMobileMenu();
    },
    [closeMobileMenu],
  );

  return (
    <header className={cn("sticky top-0 z-9999 h-[75px] border-b border-[#E2E8F0] bg-white md:h-[83px]", className)}>
      <div className="mx-auto w-full max-w-(--breakpoint-2xl) px-4 sm:px-6 lg:px-8">
        <div
          className="flex items-center justify-between gap-2 md:gap-3 lg:gap-4"
          style={{ height: isMobile ? `${HEADER_HEIGHT_MOBILE}px` : `${HEADER_HEIGHT_DESKTOP}px` }}
        >
          <div className="flex min-w-0 shrink-0 flex-row items-center">
            <Link
              to={ROUTES.TENANTS}
              className="inline-flex shrink-0 rounded-sm focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#461E96] focus-visible:ring-offset-2 focus-visible:ring-offset-white"
            >
              <img src={PrimaryLogo} alt="Cencora" className="ml-[-5px] h-7 w-auto shrink-0 md:h-8" />
            </Link>

            <nav
              className="hidden items-center md:flex"
              style={{ marginLeft: `${NAV_OFFSET_DESKTOP}px` }}
              aria-label="Main navigation"
            >
              {NAV_ITEMS.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.href}
                  end={item.end}
                  className={({ isActive }) =>
                    cn(
                      "relative flex items-center justify-center gap-2 px-3 py-2 text-center text-sm font-brand whitespace-nowrap no-underline transition-colors duration-200",
                      isNavItemActive(item.name, isActive, location.pathname)
                        ? "font-bold text-[#461E96]"
                        : "font-medium text-[#525252] hover:text-[#461E96]",
                    )
                  }
                  style={{
                    fontFamily: 'var(--text-body-sm-font-family, "Cencora-Gilroy")',
                    fontSize: "var(--text-body-sm-font-size, 14px)",
                    lineHeight: "var(--text-body-sm-line-height, 20px)",
                  }}
                >
                  {({ isActive }) => {
                    const active = isNavItemActive(item.name, isActive, location.pathname);
                    return (
                      <>
                        {item.name}
                        {active ? (
                          <div
                            className="absolute right-0 left-0 h-[3px] bg-[#461E96]"
                            style={{ bottom: `${ACTIVE_INDICATOR_OFFSET}px` }}
                            aria-hidden="true"
                          />
                        ) : null}
                      </>
                    );
                  }}
                </NavLink>
              ))}
            </nav>
          </div>

          <div className="relative flex shrink-0 items-center">
            <button
              type="button"
              onClick={toggleMobileMenu}
              className="mr-2 p-2 text-[#525252] transition-colors duration-200 hover:text-[#461E96] touch-manipulation md:hidden"
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
              aria-expanded={isMobileMenuOpen}
              aria-controls="mobile-navigation"
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>

            <div className="flex items-center gap-3 lg:gap-5">
              <ProfilePictureDropdown />
            </div>
          </div>
        </div>

        {isMobileMenuOpen && (
          <>
            <div className="fixed inset-0 top-[64px] z-9998 bg-black/50 md:hidden" onClick={closeMobileMenu} aria-hidden="true" />
            <div
              className="fixed top-[64px] right-0 bottom-0 left-0 z-9999 overflow-y-auto bg-white transition-all duration-300 ease-in-out md:hidden"
              id="mobile-navigation"
              ref={mobileMenuRef}
              onKeyDown={handleMobileMenuKeyDown}
              tabIndex={-1}
            >
              <nav className="space-y-4 px-4 py-4" aria-label="Mobile navigation">
                <div className="space-y-1">
                  <div className="px-2 py-1.5 text-xs font-semibold tracking-wider text-[#525252] uppercase">Navigation</div>
                  {NAV_ITEMS.map((item) => (
                    <NavLink
                      key={item.name}
                      to={item.href}
                      end={item.end}
                      onClick={closeMobileMenu}
                      className={({ isActive }) =>
                        cn(
                          "flex w-full items-center rounded-lg px-4 py-3.5 text-left text-base font-brand no-underline transition-all duration-200 touch-manipulation",
                          isNavItemActive(item.name, isActive, location.pathname)
                            ? "bg-[#461E96]/10 font-bold text-[#461E96] shadow-xs"
                            : "font-medium text-[#525252] hover:bg-gray-100 active:bg-gray-200",
                        )
                      }
                    >
                      {item.name}
                    </NavLink>
                  ))}
                </div>

                <div className="my-4 border-t border-gray-200" />
              </nav>
            </div>
          </>
        )}
      </div>
    </header>
  );
};
