import { memo, useId, type KeyboardEvent, type MouseEvent, type ReactNode } from "react";
import { flexRender, type Row, type Table as TanStackTable } from "@tanstack/react-table";
import { Button } from "@/components/atoms/Button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/atoms/Table";
import { Typography } from "@/components/atoms/Typography";
import { cn } from "@/lib/utils";
import {
  dataGridSizeClasses,
  dataGridVariantClasses,
  resolveDataGridTable,
  useDataGridContext,
  useDataGridVisualContext,
} from "./DataGridContext";
import { DATA_GRID_DEFAULT_SKELETON_ROWS } from "./findScrollRoot";
import { useInDataGridScrollArea } from "./DataGridScrollArea";

const GRID_BORDER = "border-ui-border-secondary";
const GRID_ROW_BORDER = "[&_tr]:border-ui-border-secondary";
const GRID_LAST_ROW_BORDER = "[&_tbody_tr:last-child]:border-b";

const ALIGN_CLASS = {
  left: "text-left",
  center: "text-center",
  right: "text-right",
} as const;

export type DataGridTableProps<TData> = {
  table?: TanStackTable<TData>;
  caption?: string;
  emptyMessage?: string;
  emptyContent?: ReactNode;
  isLoading?: boolean;
  isUpdating?: boolean;
  isError?: boolean;
  errorContent?: ReactNode;
  onRetry?: () => void;
  minWidth?: number | string;
  loadingRowCount?: number;
  loadingContent?: ReactNode;
  className?: string;
  /** Applied to the table body (rows group). */
  bodyClassName?: string;
  onRowClick?: (row: TData) => void;
  getRowAriaLabel?: (row: TData, index: number) => string;
  getRowClassName?: (row: Row<TData>) => string | undefined;
  isRowDisabled?: (row: TData) => boolean;
};

function sortAriaValue(isSorted: false | "asc" | "desc"): "ascending" | "descending" | undefined {
  if (isSorted === "asc") return "ascending";
  if (isSorted === "desc") return "descending";
  return undefined;
}

function sortColumnLabel(header: unknown, columnId: string, ariaLabel?: string): string {
  if (ariaLabel) return ariaLabel;
  if (typeof header === "string" && header.trim()) return header;
  return columnId;
}

function sortHint(columnLabel: string, nextOrder: false | "asc" | "desc", isSorted: false | "asc" | "desc"): string {
  if (nextOrder === "asc") return `Sort ${columnLabel} ascending`;
  if (nextOrder === "desc") return `Sort ${columnLabel} descending`;
  if (isSorted) return `Clear sort on ${columnLabel}`;
  return `Sort ${columnLabel}`;
}

function sortIndicator(isSorted: false | "asc" | "desc", sortIndex: number): string {
  if (isSorted === "asc") return sortIndex > 0 ? `↑${sortIndex + 1}` : "↑";
  if (isSorted === "desc") return sortIndex > 0 ? `↓${sortIndex + 1}` : "↓";
  return "";
}

type DataGridCellMeta = {
  borderRight?: boolean;
  align?: "left" | "center" | "right";
  minWidth?: number | string;
  nowrap?: boolean;
};

function metaCellClass(meta: DataGridCellMeta | undefined) {
  return cn(
    meta?.borderRight && cn("border-r", GRID_BORDER),
    meta?.align && ALIGN_CLASS[meta.align],
    meta?.nowrap && "whitespace-nowrap",
  );
}

function metaCellStyle(meta: DataGridCellMeta | undefined) {
  if (meta?.minWidth == null) return undefined;
  return { minWidth: typeof meta.minWidth === "number" ? `${meta.minWidth}px` : meta.minWidth };
}

function isInteractiveTarget(target: EventTarget | null): boolean {
  if (!(target instanceof Element)) return false;
  return Boolean(
    target.closest(
      "a, button, input, select, textarea, label, [role='button'], [role='link'], [role='checkbox'], [role='menuitem'], [contenteditable='true']",
    ),
  );
}

function DataGridSkeletonRows({
  columnCount,
  rowCount,
  cellClass,
  skeletonHeight,
}: {
  columnCount: number;
  rowCount: number;
  cellClass: string;
  skeletonHeight: string;
}) {
  const cols = Math.max(columnCount, 1);
  return (
    <>
      {Array.from({ length: rowCount }).map((_, rowIdx) => (
        <TableRow key={`skeleton-${rowIdx}`} aria-hidden>
          {Array.from({ length: cols }).map((_, colIdx) => (
            <TableCell key={`skeleton-${rowIdx}-${colIdx}`} className={cellClass}>
              <div
                className={cn(
                  "animate-pulse rounded bg-gray-200",
                  skeletonHeight,
                  colIdx === 0 ? "w-32" : colIdx === 2 ? "w-20" : "w-16",
                )}
              />
            </TableCell>
          ))}
        </TableRow>
      ))}
    </>
  );
}

type DataGridRowProps<TData> = {
  row: Row<TData>;
  index: number;
  isSelected: boolean;
  isDisabled: boolean;
  isUpdating: boolean;
  cellClass: string;
  onRowClick?: (row: TData) => void;
  getRowAriaLabel?: (row: TData, index: number) => string;
  getRowClassName?: (row: Row<TData>) => string | undefined;
};

function DataGridRowInner<TData>({
  row,
  index,
  isSelected,
  isDisabled,
  isUpdating,
  cellClass,
  onRowClick,
  getRowAriaLabel,
  getRowClassName,
}: DataGridRowProps<TData>) {
  const interactive = Boolean(onRowClick) && !isDisabled;

  const handleRowClick = (e: MouseEvent<HTMLTableRowElement>) => {
    if (!interactive) return;
    if (isInteractiveTarget(e.target)) return;
    onRowClick?.(row.original);
  };

  const handleRowKeyDown = (e: KeyboardEvent<HTMLTableRowElement>) => {
    if (!interactive) return;
    if (e.key !== "Enter" && e.key !== " ") return;
    if (isInteractiveTarget(e.target)) return;
    e.preventDefault();
    onRowClick?.(row.original);
  };

  return (
    <TableRow
      data-state={isSelected ? "selected" : undefined}
      data-disabled={isDisabled || undefined}
      aria-disabled={isDisabled || undefined}
      inert={isDisabled ? true : undefined}
      aria-label={getRowAriaLabel?.(row.original, index)}
      tabIndex={interactive ? 0 : undefined}
      className={cn(
        !isDisabled && "hover:bg-neutral-50",
        interactive &&
          "cursor-pointer outline-hidden focus-visible:bg-interactive-focus-ring focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-1",
        isSelected && !isDisabled && "bg-[#DDDBF7] hover:bg-[#DDDBF7]",
        isDisabled && "cursor-not-allowed text-interactive-disabled",
        isUpdating && "opacity-70",
        getRowClassName?.(row),
      )}
      onClick={interactive ? handleRowClick : undefined}
      onKeyDown={interactive ? handleRowKeyDown : undefined}
    >
      {row.getVisibleCells().map((cell) => (
        <TableCell
          key={cell.id}
          className={cn(cellClass, isDisabled && "text-interactive-disabled", metaCellClass(cell.column.columnDef.meta))}
          style={metaCellStyle(cell.column.columnDef.meta)}
        >
          {flexRender(cell.column.columnDef.cell, cell.getContext())}
        </TableCell>
      ))}
    </TableRow>
  );
}

const DataGridRow = memo(DataGridRowInner) as typeof DataGridRowInner;

export function DataGridTable<TData>({
  table: tableProp,
  caption,
  emptyMessage = "No data",
  emptyContent,
  isLoading = false,
  isUpdating = false,
  isError = false,
  errorContent,
  onRetry,
  minWidth,
  loadingRowCount,
  loadingContent,
  className,
  bodyClassName,
  onRowClick,
  getRowAriaLabel,
  getRowClassName,
  isRowDisabled,
}: DataGridTableProps<TData>) {
  const contextTable = useDataGridContext<TData>();
  const table = resolveDataGridTable(tableProp, contextTable, "DataGridTable");
  const { size, variant } = useDataGridVisualContext();
  const sizeClasses = dataGridSizeClasses[size];
  const stickyHeader = useInDataGridScrollArea();
  const rows = table.getRowModel().rows;
  const visibleColumnCount = table.getVisibleLeafColumns().length;
  const skeletonRows = loadingRowCount ?? DATA_GRID_DEFAULT_SKELETON_ROWS;
  const busy = isLoading || isUpdating;
  const statusMessage = isLoading ? "Loading data" : isUpdating ? "Updating data" : isError ? "Error loading data" : null;
  const sortHintId = useId();
  const headerGroups = table.getHeaderGroups();
  const sortableHeaders = headerGroups
    .flatMap((group) => group.headers)
    .filter((header) => !header.isPlaceholder && header.column.getCanSort());

  let body: ReactNode;
  if (isLoading) {
    body = loadingContent ? (
      <TableRow>
        <TableCell colSpan={Math.max(visibleColumnCount, 1)} className={cn(sizeClasses.cell, "h-24 text-center")}>
          {typeof loadingContent === "string" || typeof loadingContent === "number" ? (
            <Typography variant="body2" color="secondary">
              {loadingContent}
            </Typography>
          ) : (
            loadingContent
          )}
        </TableCell>
      </TableRow>
    ) : (
      <DataGridSkeletonRows
        columnCount={visibleColumnCount}
        rowCount={skeletonRows}
        cellClass={sizeClasses.cell}
        skeletonHeight={sizeClasses.skeleton}
      />
    );
  } else if (isError) {
    body = (
      <TableRow>
        <TableCell colSpan={Math.max(visibleColumnCount, 1)} className={cn(sizeClasses.cell, "h-24 text-center")}>
          {errorContent != null ? (
            errorContent
          ) : (
            <div className="flex flex-col items-center gap-2">
              <Typography variant="body2" color="secondary">
                Unable to load data.
              </Typography>
              {onRetry ? (
                <Button type="button" variant="outline" size="sm" onClick={onRetry}>
                  Retry
                </Button>
              ) : null}
            </div>
          )}
        </TableCell>
      </TableRow>
    );
  } else if (rows.length === 0) {
    body = (
      <TableRow>
        <TableCell colSpan={Math.max(visibleColumnCount, 1)} className={cn(sizeClasses.cell, "h-24 text-center")}>
          {emptyContent != null ? (
            typeof emptyContent === "string" || typeof emptyContent === "number" ? (
              <Typography variant="body2" color="secondary">
                {emptyContent}
              </Typography>
            ) : (
              emptyContent
            )
          ) : (
            <Typography variant="body2" color="secondary">
              {emptyMessage}
            </Typography>
          )}
        </TableCell>
      </TableRow>
    );
  } else {
    const selectionIsPerRow = typeof table.options.enableRowSelection === "function";
    body = rows.map((row, index) => (
      <DataGridRow
        key={row.id}
        row={row}
        index={index}
        isSelected={row.getIsSelected()}
        isDisabled={isRowDisabled ? isRowDisabled(row.original) : selectionIsPerRow && !row.getCanSelect()}
        isUpdating={isUpdating}
        cellClass={sizeClasses.cell}
        onRowClick={onRowClick}
        getRowAriaLabel={getRowAriaLabel}
        getRowClassName={getRowClassName}
      />
    ));
  }

  return (
    <div className={cn("relative", dataGridVariantClasses[variant])}>
      {statusMessage ? (
        <Typography as="div" variant="body2" className="sr-only" role="status" aria-live="polite">
          {statusMessage}
        </Typography>
      ) : null}
      <div className="sr-only">
        {sortableHeaders.map((header) => {
          const meta = header.column.columnDef.meta;
          const columnLabel = sortColumnLabel(header.column.columnDef.header, header.column.id, meta?.ariaLabel);
          return (
            <span key={header.id} id={`${sortHintId}-${header.id}`}>
              {sortHint(columnLabel, header.column.getNextSortingOrder(), header.column.getIsSorted())}
            </span>
          );
        })}
      </div>
      <Table
        containerClassName={stickyHeader ? "overflow-visible" : undefined}
        className={cn("bg-transparent", GRID_ROW_BORDER, GRID_LAST_ROW_BORDER, className)}
        style={minWidth == null ? undefined : { minWidth: typeof minWidth === "number" ? `${minWidth}px` : minWidth }}
        aria-busy={busy || undefined}
      >
        {caption ? (
          <Typography as="caption" variant="body2" className="sr-only">
            {caption}
          </Typography>
        ) : null}
        <TableHeader>
          {headerGroups.map((headerGroup) => (
            <TableRow key={headerGroup.id} className="hover:bg-transparent">
              {headerGroup.headers.map((header) => {
                const canSort = header.column.getCanSort();
                const isSorted = header.column.getIsSorted();
                const sortIndex = header.column.getSortIndex();
                const nextOrder = canSort ? header.column.getNextSortingOrder() : false;
                const meta = header.column.columnDef.meta;
                const columnLabel = sortColumnLabel(header.column.columnDef.header, header.column.id, meta?.ariaLabel);
                const ariaSort = canSort ? sortAriaValue(isSorted) : undefined;

                return (
                  <TableHead
                    key={header.id}
                    colSpan={header.colSpan}
                    scope="col"
                    aria-sort={ariaSort}
                    className={cn(
                      sizeClasses.header,
                      canSort && "select-none",
                      "border-b",
                      GRID_BORDER,
                      stickyHeader && "sticky top-0 z-10 bg-ui-background-primary",
                      metaCellClass(meta),
                    )}
                    style={metaCellStyle(meta)}
                  >
                    {header.isPlaceholder ? null : canSort ? (
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          className="inline-flex h-auto min-h-0 items-center gap-1 bg-transparent p-0 font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-bold tracking-normal text-ui-text-primary focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-1"
                          onClick={header.column.getToggleSortingHandler()}
                          disabled={isLoading}
                          aria-describedby={`${sortHintId}-${header.id}`}
                          title={sortHint(columnLabel, nextOrder, isSorted)}
                        >
                          {flexRender(header.column.columnDef.header, header.getContext())}
                          <Typography
                            as="span"
                            variant="caption"
                            color="secondary"
                            className="text-ui-text-secondary"
                            aria-hidden
                          >
                            {sortIndicator(isSorted, sortIndex)}
                          </Typography>
                        </button>
                        {meta?.headerAccessory ? (
                          <span className="inline-flex shrink-0 items-center">{meta.headerAccessory}</span>
                        ) : null}
                      </div>
                    ) : (
                      <div className="inline-flex items-center gap-2">
                        {flexRender(header.column.columnDef.header, header.getContext())}
                        {meta?.headerAccessory ? (
                          <span className="inline-flex shrink-0 items-center">{meta.headerAccessory}</span>
                        ) : null}
                      </div>
                    )}
                  </TableHead>
                );
              })}
            </TableRow>
          ))}
        </TableHeader>
        <TableBody className={bodyClassName}>{body}</TableBody>
      </Table>
    </div>
  );
}
