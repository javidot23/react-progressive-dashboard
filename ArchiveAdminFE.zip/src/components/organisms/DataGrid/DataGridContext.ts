import { createContext, useContext } from "react";
import type { Table as TanStackTable } from "@tanstack/react-table";

export type DataGridSize = "sm" | "md" | "lg";
export type DataGridVariant = "plain" | "bordered" | "striped";

export type DataGridContextValue = {
  table: unknown;
  size: DataGridSize;
  variant: DataGridVariant;
};

export const DataGridContext = createContext<DataGridContextValue | null>(null);
DataGridContext.displayName = "DataGridContext";

export function useDataGridContext<TData>(): TanStackTable<TData> | null {
  const ctx = useContext(DataGridContext);
  return ctx ? (ctx.table as TanStackTable<TData>) : null;
}

export function useDataGridVisualContext(): { size: DataGridSize; variant: DataGridVariant } {
  const ctx = useContext(DataGridContext);
  return {
    size: ctx?.size ?? "md",
    variant: ctx?.variant ?? "plain",
  };
}

export function resolveDataGridTable<TData>(
  tableProp: TanStackTable<TData> | undefined,
  contextTable: TanStackTable<TData> | null,
  componentName: string,
): TanStackTable<TData> {
  const table = tableProp ?? contextTable;
  if (!table) {
    throw new Error(`${componentName} must receive a \`table\` prop or be rendered within <DataGridShell table={...}>.`);
  }
  return table;
}

export const dataGridSizeClasses = {
  sm: {
    header:
      "h-8 px-2 font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-bold tracking-normal text-ui-text-primary",
    cell: "px-2 py-1.5 align-middle font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-medium tracking-normal text-ui-text-primary",
    skeleton: "h-3",
  },
  md: {
    header:
      "h-12 px-4 font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-bold tracking-normal text-ui-text-primary",
    cell: "p-4 align-middle font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-medium tracking-normal text-ui-text-primary",
    skeleton: "h-4",
  },
  lg: {
    header:
      "h-14 px-5 font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-bold tracking-normal text-ui-text-primary",
    cell: "px-5 py-5 align-middle font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-medium tracking-normal text-ui-text-primary",
    skeleton: "h-5",
  },
} as const;

export const dataGridVariantClasses = {
  plain: "",
  bordered: "border border-ui-border-secondary rounded-md overflow-hidden",
  striped: "[&_tbody_tr:nth-child(even)]:bg-neutral-50",
} as const;
