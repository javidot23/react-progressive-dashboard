import type { ColumnDef, RowData, Table } from "@tanstack/react-table";
import { Checkbox } from "@/components/atoms/Checkbox";

export function createSelectionColumn<TData extends RowData>(): ColumnDef<TData, unknown> {
  return {
    id: "select",
    enableSorting: false,
    enableHiding: false,
    header: ({ table }: { table: Table<TData> }) => {
      const all = table.getIsAllRowsSelected();
      const some = table.getIsSomeRowsSelected();
      return (
        <Checkbox
          aria-label="Select all rows"
          checked={all}
          indeterminate={some && !all}
          onCheckedChange={(value) => table.toggleAllRowsSelected(Boolean(value))}
        />
      );
    },
    cell: ({ row }) => (
      <Checkbox
        aria-label="Select row"
        checked={row.getIsSelected()}
        disabled={!row.getCanSelect()}
        onCheckedChange={(value) => row.toggleSelected(Boolean(value))}
      />
    ),
    meta: {
      align: "center" as const,
      minWidth: 44,
      nowrap: true,
    },
  };
}
