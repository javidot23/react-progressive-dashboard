import { useEffect, useRef, useState } from "react";
import { Search, X } from "lucide-react";
import { Button } from "@/components/atoms/Button";
import { cn } from "@/lib/utils";

export type DataGridSearchProps = {
  value?: string;
  onSearch: (term: string) => void;
  placeholder?: string;
  debounceMs?: number;
  className?: string;
  "aria-label"?: string;
};

export function DataGridSearch({
  value = "",
  onSearch,
  placeholder = "Search",
  debounceMs = 300,
  className,
  "aria-label": ariaLabel = "Search",
}: DataGridSearchProps) {
  const [draft, setDraft] = useState(value);
  const onSearchRef = useRef(onSearch);

  useEffect(() => {
    onSearchRef.current = onSearch;
  }, [onSearch]);

  useEffect(() => {
    setDraft(value);
  }, [value]);

  useEffect(() => {
    if (draft === value) return;
    const timer = setTimeout(() => {
      onSearchRef.current(draft);
    }, debounceMs);
    return () => clearTimeout(timer);
  }, [draft, debounceMs, value]);

  return (
    <div className={cn("relative", className)}>
      <Search
        className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-primary-main"
        aria-hidden
      />
      <input
        type="search"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        placeholder={placeholder}
        aria-label={ariaLabel}
        className="h-9 w-48 rounded-md border-2 border-brand-primary-main bg-ui-background-primary pl-9 pr-8 text-sm text-ui-text-primary placeholder:text-ui-text-secondary focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-1"
      />
      {draft.length > 0 ? (
        <Button
          type="button"
          variant="ghost"
          size="sm"
          aria-label="Clear search"
          className="absolute right-2 top-1/2 h-auto min-h-0 -translate-y-1/2 rounded-sm p-0.5 text-ui-text-secondary hover:bg-transparent hover:text-ui-text-primary focus-visible:ring-brand-primary-main [&_svg]:size-3.5"
          onClick={() => {
            setDraft("");
            onSearchRef.current("");
          }}
        >
          <X className="h-3.5 w-3.5" aria-hidden />
        </Button>
      ) : null}
    </div>
  );
}
