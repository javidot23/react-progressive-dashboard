import { useCallback, useEffect, useRef } from "react";
import { Button } from "@/components/atoms/Button";
import { Typography } from "@/components/atoms/Typography";
import { cn } from "@/lib/utils";
import { DATA_GRID_INFINITE_ROOT_MARGIN, DATA_GRID_MAX_LOADED_ROWS, findScrollRoot } from "./findScrollRoot";

export type DataGridInfiniteScrollProps = {
  hasNextPage: boolean;
  isFetchingNextPage: boolean;
  loadedCount: number;
  totalCount?: number;
  fetchNextPage: () => void;
  maxLoadedRows?: number;
  className?: string;
};

export function DataGridInfiniteScroll({
  hasNextPage,
  isFetchingNextPage,
  loadedCount,
  totalCount,
  fetchNextPage,
  maxLoadedRows = DATA_GRID_MAX_LOADED_ROWS,
  className,
}: DataGridInfiniteScrollProps) {
  const sentinelRef = useRef<HTMLDivElement>(null);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const fetchingRef = useRef(false);
  const latestRef = useRef({ hasNextPage, loadedCount, maxLoadedRows, fetchNextPage });

  const capped = loadedCount >= maxLoadedRows;
  const showCap = capped && hasNextPage;

  useEffect(() => {
    latestRef.current = { hasNextPage, loadedCount, maxLoadedRows, fetchNextPage };
  });

  useEffect(() => {
    fetchingRef.current = isFetchingNextPage;
  }, [isFetchingNextPage, loadedCount, hasNextPage]);

  const tryFetch = useCallback(() => {
    const latest = latestRef.current;
    if (fetchingRef.current) return;
    if (!latest.hasNextPage || latest.loadedCount >= latest.maxLoadedRows) return;
    fetchingRef.current = true;
    latest.fetchNextPage();
  }, []);

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel || typeof IntersectionObserver === "undefined") return;

    const root = findScrollRoot(sentinel);
    if (root && root.clientHeight === 0) return;

    const disconnect = () => {
      observerRef.current?.disconnect();
      observerRef.current = null;
    };

    disconnect();
    if (loadedCount >= maxLoadedRows || !hasNextPage) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) return;
        tryFetch();
      },
      {
        root,
        rootMargin: DATA_GRID_INFINITE_ROOT_MARGIN,
        threshold: 0,
      },
    );
    observerRef.current = observer;
    observer.observe(sentinel);

    return disconnect;
  }, [hasNextPage, isFetchingNextPage, loadedCount, maxLoadedRows, tryFetch]);

  const statusText = showCap
    ? `Showing first ${maxLoadedRows} rows. Refine your filters to narrow results.`
    : isFetchingNextPage
      ? "Loading more…"
      : totalCount != null
        ? `Showing ${loadedCount} of ${totalCount}`
        : `Showing ${loadedCount}`;

  return (
    <div className={cn("flex flex-col items-center gap-3 py-4", className)}>
      <Typography
        as="div"
        variant="body2"
        role="status"
        aria-live="polite"
        color={showCap ? "secondary" : "primary"}
        className={showCap ? "text-center" : "sr-only"}
      >
        {statusText}
      </Typography>

      {isFetchingNextPage ? (
        <div className="flex items-center gap-2" aria-hidden>
          <div className="h-4 w-4 animate-spin rounded-full border-2 border-gray-300 border-t-brand-primary-main" />
          <Typography as="span" variant="body2" color="secondary">
            Loading more…
          </Typography>
        </div>
      ) : null}

      {hasNextPage && !capped ? (
        <Button type="button" variant="outline" size="sm" disabled={isFetchingNextPage} onClick={tryFetch}>
          Load more
        </Button>
      ) : null}

      <div ref={sentinelRef} data-testid="datagrid-infinite-sentinel" className="h-px w-full" aria-hidden />
    </div>
  );
}
