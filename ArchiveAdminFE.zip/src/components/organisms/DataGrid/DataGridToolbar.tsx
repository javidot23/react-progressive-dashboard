import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export type DataGridToolbarProps = {
  title?: ReactNode;
  description?: ReactNode;
  children?: ReactNode;
  className?: string;
};

const TITLE_CLASS =
  "m-0 min-w-0 font-heading-5xl text-[length:var(--text-heading-5xl)] leading-heading-5xl tracking-heading-5xl font-semibold text-[#000000]";

const DESCRIPTION_CLASS =
  "m-0 min-w-0 font-body-sm text-[length:var(--text-body-sm)] leading-body-sm font-medium tracking-normal text-ui-text-secondary";

export function DataGridToolbar({ title, description, children, className }: DataGridToolbarProps) {
  const hasTitle = title != null && title !== "";
  const hasDescription = description != null && description !== "";

  return (
    <div className={cn("mb-4 flex flex-col", className)}>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        {hasTitle ? (
          typeof title === "string" || typeof title === "number" ? (
            <h2 className={TITLE_CLASS}>{title}</h2>
          ) : (
            <div className={TITLE_CLASS}>{title}</div>
          )
        ) : (
          <div />
        )}
        {children ? <div className="flex w-full flex-wrap items-center justify-end gap-2 sm:w-auto">{children}</div> : null}
      </div>
      {hasDescription ? (
        typeof description === "string" || typeof description === "number" ? (
          <p className={DESCRIPTION_CLASS}>{description}</p>
        ) : (
          <div className={DESCRIPTION_CLASS}>{description}</div>
        )
      ) : null}
    </div>
  );
}
