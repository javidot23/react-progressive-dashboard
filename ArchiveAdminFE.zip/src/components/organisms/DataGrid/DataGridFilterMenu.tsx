import { useCallback, useId, useRef, useState, type ReactNode } from "react";
import { SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/atoms/Button";
import { useDialogFocusTrap } from "@/components/atoms/useDialogFocusTrap";
import { cn } from "@/lib/utils";

export type DataGridFilterMenuProps = {
  label?: string;
  activeCount?: number;
  align?: "left" | "right";
  children: ReactNode;
  className?: string;
  onOpen?: () => void;
  onClearAll?: () => void;
  onShowResults?: () => void;
  showResultsDisabled?: boolean;
  clearAllLabel?: string;
  showResultsLabel?: string;
};

export function DataGridFilterMenu({
  label = "Filters",
  activeCount,
  align = "right",
  children,
  className,
  onOpen,
  onClearAll,
  onShowResults,
  showResultsDisabled = false,
  clearAllLabel = "Clear all",
  showResultsLabel = "Show results",
}: DataGridFilterMenuProps) {
  const [open, setOpen] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const panelId = useId();

  const openPanel = useCallback(() => {
    onOpen?.();
    setOpen(true);
  }, [onOpen]);

  const closePanel = useCallback(() => {
    setOpen(false);
  }, []);

  useDialogFocusTrap({
    isOpen: open,
    onClose: closePanel,
    containerRef: panelRef,
    triggerRef,
  });

  const handleClearAll = useCallback(() => {
    onClearAll?.();
    closePanel();
  }, [onClearAll, closePanel]);

  const handleShowResults = useCallback(() => {
    onShowResults?.();
    closePanel();
  }, [onShowResults, closePanel]);

  const showBadge = typeof activeCount === "number" && activeCount > 0;

  return (
    <div className={cn("relative order-last ms-auto", className)}>
      <Button
        ref={triggerRef}
        type="button"
        variant="secondary"
        size="sm"
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? panelId : undefined}
        onClick={() => (open ? closePanel() : openPanel())}
        startIcon={<SlidersHorizontal aria-hidden="true" className="!h-4 !w-4" strokeWidth={2} />}
        className="h-8 gap-1.5 border-transparent bg-neutral-100 px-3 text-sm font-bold text-brand-primary-main hover:bg-neutral-200"
      >
        {label}
        {showBadge ? (
          <span
            className="inline-flex min-w-5 items-center justify-center rounded-full bg-brand-primary-main px-1.5 text-xs text-white"
            aria-label={`${activeCount} active filters`}
          >
            {activeCount}
          </span>
        ) : null}
      </Button>

      {open ? (
        <>
          <button
            type="button"
            tabIndex={-1}
            aria-hidden="true"
            className="fixed inset-0 z-[9998] cursor-default bg-transparent"
            onClick={closePanel}
          />
          <div
            ref={panelRef}
            id={panelId}
            role="dialog"
            aria-labelledby={titleId}
            tabIndex={-1}
            className={cn(
              "absolute top-full z-[9999] mt-2 w-[min(360px,calc(100vw-1rem))] rounded-xl border border-[#EAEAEA] bg-ui-background-primary outline-none",
              align === "right" ? "right-0" : "left-0",
            )}
            style={{ boxShadow: "0px 10px 30px -10px #00000014" }}
          >
            <div className="flex items-center justify-center border-b border-ui-border-primary px-4 py-3">
              <h2 id={titleId} className="text-base font-bold text-ui-text-primary">
                {label}
              </h2>
            </div>

            <div className="max-h-[min(70vh,28rem)] space-y-4 overflow-y-auto px-4 py-4">{children}</div>

            <div className="flex items-center justify-between gap-3 border-t border-ui-border-primary px-4 py-3">
              <button
                type="button"
                onClick={handleClearAll}
                className="text-sm font-semibold text-brand-primary-main hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-interactive-primary-focus"
              >
                {clearAllLabel}
              </button>
              <Button type="button" size="sm" onClick={handleShowResults} disabled={showResultsDisabled}>
                {showResultsLabel}
              </Button>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
