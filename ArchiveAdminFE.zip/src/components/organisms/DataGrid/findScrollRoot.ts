export function findScrollRoot(anchor: HTMLElement | null): Element | null {
  let node: HTMLElement | null = anchor;
  while (node) {
    const { overflowY } = window.getComputedStyle(node);
    if (/(auto|scroll|overlay)/.test(overflowY)) {
      return node;
    }
    node = node.parentElement;
  }
  return null;
}

export const DATA_GRID_DEFAULT_PAGE_SIZE = 25;
export const DATA_GRID_MAX_LOADED_ROWS = 1000;
export const DATA_GRID_DEFAULT_SKELETON_ROWS = 5;
export const DATA_GRID_INFINITE_ROOT_MARGIN = "400px";
