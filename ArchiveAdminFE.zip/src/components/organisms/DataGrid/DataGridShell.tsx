import { useMemo, type ReactNode } from "react";
import type { Table as TanStackTable } from "@tanstack/react-table";
import { cn } from "@/lib/utils";
import { DataGridContext, type DataGridSize, type DataGridVariant } from "./DataGridContext";

export type DataGridShellProps<TData> = {
  table: TanStackTable<TData>;
  children: ReactNode;
  className?: string;
  size?: DataGridSize;
  variant?: DataGridVariant;
};

export function DataGridShell<TData>({ table, children, className, size = "md", variant = "plain" }: DataGridShellProps<TData>) {
  const value = useMemo(() => ({ table, size, variant }), [table, size, variant]);

  return (
    <DataGridContext.Provider value={value}>
      <div className={cn("flex w-full min-w-0 flex-col", className)}>{children}</div>
    </DataGridContext.Provider>
  );
}
