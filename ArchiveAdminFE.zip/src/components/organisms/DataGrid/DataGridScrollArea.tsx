import { createContext, useContext, type ReactNode } from "react";
import { cn } from "@/lib/utils";

const DataGridScrollAreaContext = createContext(false);

export function useInDataGridScrollArea(): boolean {
  return useContext(DataGridScrollAreaContext);
}

export type DataGridScrollAreaProps = {
  children: ReactNode;
  maxHeight?: number | string;
  className?: string;
};

export function DataGridScrollArea({ children, maxHeight = 480, className }: DataGridScrollAreaProps) {
  return (
    <DataGridScrollAreaContext.Provider value={true}>
      <div
        data-datagrid-scroll-area=""
        className={cn("relative w-full min-w-0 overscroll-contain", className)}
        style={{
          overflowX: "auto",
          overflowY: "auto",
          maxHeight: typeof maxHeight === "number" ? `${maxHeight}px` : maxHeight,
        }}
      >
        {children}
      </div>
    </DataGridScrollAreaContext.Provider>
  );
}
