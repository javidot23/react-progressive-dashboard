import { useMemo, useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, fn, userEvent, within } from "storybook/test";
import { keepPreviousData, QueryClient, QueryClientProvider, useInfiniteQuery } from "@tanstack/react-query";
import { Button, InfoIcon, Typography } from "@/components/atoms";
import {
  createColumnHelper,
  createSelectionColumn,
  DataGridExportButton,
  DataGridFilterMenu,
  DataGridInfiniteScroll,
  DataGridScrollArea,
  DataGridSearch,
  DataGridShell,
  DataGridTable,
  DataGridToolbar,
  useDataGrid,
  type ColumnFiltersState,
  type RowSelectionState,
  type SortingState,
} from "@/components/organisms/DataGrid";
import { DATA_GRID_DEFAULT_PAGE_SIZE } from "@/components/organisms/DataGrid/findScrollRoot";
import { getMaterialStatusDescription, getProductCategoryLabel } from "@/lib/utils";

type MaterialStatus = "AC" | "UM" | "AM" | "NW" | "DB" | "TM" | "DM";
type ProductCategory = "GRX" | "BRX" | "OTC" | "OTG" | "HBC" | "MSU" | "HHC";

type Product = {
  id: string;
  matNbr: string;
  description: string;
  ndc: string;
  category: ProductCategory;
  plant: string;
  vendor: string;
  status: MaterialStatus;
  onHand: number;
  daysOfSupply: number;
  valueAtRisk: number;
};

const PLANTS = ["DC Columbus", "DC Indianapolis", "DC Dallas", "DC Sacramento", "DC Atlanta"] as const;

const products: Product[] = [
  {
    id: "mat-1",
    matNbr: "10001234",
    description: "Acetaminophen 500mg Tab 100ct",
    ndc: "00093-0150-01",
    category: "GRX",
    plant: PLANTS[0],
    vendor: "Amneal Pharmaceuticals",
    status: "AC",
    onHand: 12480,
    daysOfSupply: 42,
    valueAtRisk: 1840,
  },
  {
    id: "mat-2",
    matNbr: "10004567",
    description: "Lisinopril 10mg Tab 90ct",
    ndc: "68180-0518-03",
    category: "GRX",
    plant: PLANTS[1],
    vendor: "Lupin Pharmaceuticals",
    status: "AC",
    onHand: 8320,
    daysOfSupply: 28,
    valueAtRisk: 920,
  },
  {
    id: "mat-3",
    matNbr: "10007890",
    description: "Atorvastatin 40mg Tab 90ct",
    ndc: "00781-5361-10",
    category: "GRX",
    plant: PLANTS[2],
    vendor: "Teva Pharmaceuticals",
    status: "UM",
    onHand: 640,
    daysOfSupply: 4,
    valueAtRisk: 12600,
  },
  {
    id: "mat-4",
    matNbr: "20001111",
    description: "Humira 40mg/0.8mL Pen",
    ndc: "00074-0554-02",
    category: "BRX",
    plant: PLANTS[0],
    vendor: "AbbVie",
    status: "AC",
    onHand: 210,
    daysOfSupply: 11,
    valueAtRisk: 48200,
  },
  {
    id: "mat-5",
    matNbr: "20002222",
    description: "Keytruda 100mg/4mL Vial",
    ndc: "00006-3026-02",
    category: "BRX",
    plant: PLANTS[3],
    vendor: "Merck & Co.",
    status: "AM",
    onHand: 48,
    daysOfSupply: 6,
    valueAtRisk: 91500,
  },
  {
    id: "mat-6",
    matNbr: "30003333",
    description: "Ibuprofen 200mg Caplet 100ct",
    ndc: "00536-1188-01",
    category: "OTC",
    plant: PLANTS[4],
    vendor: "Perrigo",
    status: "AC",
    onHand: 22100,
    daysOfSupply: 55,
    valueAtRisk: 410,
  },
  {
    id: "mat-7",
    matNbr: "30004444",
    description: "Cetirizine 10mg Tab 30ct",
    ndc: "45802-0122-46",
    category: "OTG",
    plant: PLANTS[1],
    vendor: "Perrigo",
    status: "NW",
    onHand: 0,
    daysOfSupply: 0,
    valueAtRisk: 0,
  },
  {
    id: "mat-8",
    matNbr: "40005555",
    description: "Surgical Nitrile Glove Medium BX100",
    ndc: "N/A",
    category: "MSU",
    plant: PLANTS[2],
    vendor: "Medline Industries",
    status: "AC",
    onHand: 5400,
    daysOfSupply: 33,
    valueAtRisk: 780,
  },
  {
    id: "mat-9",
    matNbr: "40006666",
    description: "Blood Glucose Test Strips 50ct",
    ndc: "53885-0244-50",
    category: "HHC",
    plant: PLANTS[0],
    vendor: "Ascensia Diabetes Care",
    status: "DB",
    onHand: 120,
    daysOfSupply: 2,
    valueAtRisk: 3400,
  },
  {
    id: "mat-10",
    matNbr: "50007777",
    description: "Omeprazole 20mg DR Cap 42ct",
    ndc: "00536-1331-42",
    category: "HBC",
    plant: PLANTS[4],
    vendor: "Dr. Reddy's",
    status: "TM",
    onHand: 860,
    daysOfSupply: 9,
    valueAtRisk: 2100,
  },
  {
    id: "mat-11",
    matNbr: "50008888",
    description: "Metformin 500mg Tab 1000ct",
    ndc: "23155-0102-10",
    category: "GRX",
    plant: PLANTS[3],
    vendor: "Aurobindo Pharma",
    status: "AC",
    onHand: 15600,
    daysOfSupply: 61,
    valueAtRisk: 640,
  },
  {
    id: "mat-12",
    matNbr: "60009999",
    description: "Insulin Glargine 100u/mL Vial 10mL",
    ndc: "00088-2220-33",
    category: "BRX",
    plant: PLANTS[1],
    vendor: "Sanofi",
    status: "DM",
    onHand: 0,
    daysOfSupply: 0,
    valueAtRisk: 0,
  },
];

const columnHelper = createColumnHelper<Product>();

const baseColumns = [
  columnHelper.accessor("matNbr", {
    header: "Material #",
    cell: (info) => info.getValue(),
    meta: { minWidth: 120, nowrap: true },
  }),
  columnHelper.accessor("description", {
    header: "Description",
    cell: (info) => info.getValue(),
    meta: { minWidth: 260 },
  }),
  columnHelper.accessor("ndc", {
    header: "NDC",
    cell: (info) => info.getValue(),
    enableSorting: false,
    meta: { minWidth: 140, nowrap: true },
  }),
  columnHelper.accessor("category", {
    header: "Category",
    cell: (info) => getProductCategoryLabel(info.getValue()),
    meta: { minWidth: 180, nowrap: true },
  }),
  columnHelper.accessor("plant", {
    header: "Plant",
    cell: (info) => info.getValue(),
    meta: { minWidth: 150, nowrap: true },
  }),
  columnHelper.accessor("vendor", {
    header: "Vendor",
    cell: (info) => info.getValue(),
    meta: { minWidth: 180, nowrap: true },
  }),
  columnHelper.accessor("status", {
    header: "Status",
    cell: (info) => getMaterialStatusDescription(info.getValue()),
    enableSorting: false,
    meta: { minWidth: 190, nowrap: true },
  }),
  columnHelper.accessor("onHand", {
    header: "On hand",
    cell: (info) => info.getValue().toLocaleString("en-US"),
    meta: {
      align: "right" as const,
      minWidth: 110,
      nowrap: true,
      headerAccessory: <InfoIcon aria-label="Units currently on hand at the plant" />,
    },
  }),
  columnHelper.accessor("daysOfSupply", {
    header: "Days of supply",
    cell: (info) => info.getValue().toLocaleString("en-US"),
    meta: {
      align: "right" as const,
      minWidth: 130,
      nowrap: true,
      headerAccessory: <InfoIcon aria-label="Estimated days of supply at current demand" />,
    },
  }),
  columnHelper.accessor("valueAtRisk", {
    header: "Value at risk",
    cell: (info) =>
      info.getValue().toLocaleString("en-US", {
        style: "currency",
        currency: "USD",
        maximumFractionDigits: 0,
      }),
    meta: {
      align: "right" as const,
      minWidth: 130,
      nowrap: true,
      headerAccessory: <InfoIcon aria-label="Estimated inventory value exposed to supply risk" />,
    },
  }),
];

function InteractiveGrid({ onExport = fn(), onRowClick = fn() }: { onExport?: () => void; onRowClick?: (row: Product) => void }) {
  const columns = useMemo(() => baseColumns, []);
  const data = useMemo(() => products, []);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [draftStatus, setDraftStatus] = useState("");

  const { table } = useDataGrid({
    data,
    columns,
    getRowId: (row) => row.id,
    state: { sorting, columnFilters, globalFilter },
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
  });

  const statusFilter = (table.getColumn("status")?.getFilterValue() as string) ?? "";

  return (
    <DataGridShell table={table} className="w-full max-w-6xl">
      <DataGridToolbar
        title="Materials"
        description="Inventory across distribution centers. Search, filter by material status, and export the current view."
      >
        <DataGridSearch value={globalFilter} onSearch={setGlobalFilter} placeholder="Search materials" />
        <DataGridFilterMenu
          activeCount={statusFilter ? 1 : 0}
          onOpen={() => setDraftStatus(statusFilter)}
          onClearAll={() => {
            setDraftStatus("");
            table.getColumn("status")?.setFilterValue(undefined);
          }}
          onShowResults={() => {
            table.getColumn("status")?.setFilterValue(draftStatus || undefined);
          }}
        >
          <section aria-label="Material status">
            <h3 className="mb-3 text-sm font-bold text-ui-text-primary">Material status</h3>
            <select
              aria-label="Filter by material status"
              value={draftStatus}
              onChange={(e) => setDraftStatus(e.target.value)}
              className="w-full rounded-md border border-ui-border-primary bg-ui-background-primary px-3 py-2 text-sm text-ui-text-primary"
            >
              <option value="">All</option>
              <option value="AC">Active</option>
              <option value="UM">Temp Unavail from Mfg</option>
              <option value="AM">Allocated by Mfg</option>
              <option value="NW">New</option>
              <option value="DB">Discontinued by ABC</option>
              <option value="TM">LongTerm Unavail from Mfg</option>
              <option value="DM">Discontinued by Mfg</option>
            </select>
          </section>
        </DataGridFilterMenu>
        <DataGridExportButton onExport={onExport} />
      </DataGridToolbar>
      <DataGridTable<Product> caption="Materials" onRowClick={onRowClick} getRowAriaLabel={(row) => `Open ${row.description}`} />
    </DataGridShell>
  );
}

function AsyncGrid({
  isLoading = false,
  isUpdating = false,
  isError = false,
  empty = false,
  emptyContent,
  errorContent,
  size = "md",
  variant = "plain",
}: {
  isLoading?: boolean;
  isUpdating?: boolean;
  isError?: boolean;
  empty?: boolean;
  emptyContent?: React.ReactNode;
  errorContent?: React.ReactNode;
  size?: "sm" | "md" | "lg";
  variant?: "plain" | "bordered" | "striped";
}) {
  const columns = useMemo(() => baseColumns, []);
  const data = useMemo(() => (empty ? [] : products.slice(0, 4)), [empty]);

  const { table } = useDataGrid({
    data,
    columns,
    getRowId: (row) => row.id,
  });

  return (
    <DataGridShell table={table} size={size} variant={variant} className="w-full max-w-6xl">
      <DataGridToolbar title="Materials" description="Async load states for material inventory." />
      <DataGridTable
        caption="Materials"
        isLoading={isLoading}
        isUpdating={isUpdating}
        isError={isError}
        emptyMessage="No materials found"
        emptyContent={emptyContent}
        errorContent={errorContent}
        loadingRowCount={3}
        onRetry={fn()}
      />
    </DataGridShell>
  );
}

type ServerPage = { results: Product[]; hasMore: boolean; total: number };

function fetchServerPage(page: number, pageSize: number, sorting: SortingState): ServerPage {
  const rows = [...products];
  const sort = sorting[0];
  if (sort?.id === "matNbr") {
    rows.sort((a, b) => (sort.desc ? b.matNbr.localeCompare(a.matNbr) : a.matNbr.localeCompare(b.matNbr)));
  } else if (sort?.id === "description") {
    rows.sort((a, b) => (sort.desc ? b.description.localeCompare(a.description) : a.description.localeCompare(b.description)));
  } else if (sort?.id === "onHand") {
    rows.sort((a, b) => (sort.desc ? b.onHand - a.onHand : a.onHand - b.onHand));
  }
  const start = (page - 1) * pageSize;
  const slice = rows.slice(start, start + pageSize);
  return {
    results: slice,
    hasMore: start + pageSize < rows.length,
    total: rows.length,
  };
}

function ServerInfiniteGrid({ scrollArea = false }: { scrollArea?: boolean }) {
  const columns = useMemo(() => baseColumns, []);
  const [sorting, setSorting] = useState<SortingState>([]);
  const pageSize = 2;

  const query = useInfiniteQuery({
    queryKey: ["storybook-datagrid-infinite", sorting],
    queryFn: async ({ pageParam }) => {
      await new Promise((r) => setTimeout(r, 80));
      return fetchServerPage(pageParam, pageSize, sorting);
    },
    initialPageParam: 1,
    getNextPageParam: (lastPage, allPages) => (lastPage.hasMore ? allPages.length + 1 : undefined),
    placeholderData: keepPreviousData,
  });

  const rows = useMemo(() => query.data?.pages.flatMap((p) => p.results) ?? [], [query.data]);

  const { table } = useDataGrid({
    data: rows,
    columns,
    getRowId: (row) => row.id,
    manualSorting: true,
    state: { sorting },
    onSortingChange: setSorting,
  });

  const grid = (
    <>
      <DataGridTable caption="Materials" isLoading={query.isPending} isUpdating={query.isFetching && !query.isPending} />
      <DataGridInfiniteScroll
        hasNextPage={Boolean(query.hasNextPage)}
        isFetchingNextPage={query.isFetchingNextPage}
        loadedCount={rows.length}
        totalCount={query.data?.pages[0]?.total}
        fetchNextPage={() => {
          void query.fetchNextPage();
        }}
      />
    </>
  );

  return (
    <DataGridShell table={table} className="w-full max-w-6xl">
      <DataGridToolbar title="Materials" description="Server-backed inventory list with sentinel infinite scroll." />
      {scrollArea ? <DataGridScrollArea maxHeight={320}>{grid}</DataGridScrollArea> : grid}
    </DataGridShell>
  );
}

function HorizontalScrollGrid() {
  const columns = useMemo(() => baseColumns, []);
  const data = useMemo(() => products.slice(0, 6), []);
  const { table } = useDataGrid({ data, columns, getRowId: (row) => row.id });

  return (
    <DataGridShell table={table} className="w-full max-w-md">
      <DataGridToolbar title="Materials" description="Wide material columns force horizontal scroll inside the scroll area." />
      <DataGridScrollArea maxHeight={360}>
        <DataGridTable caption="Materials" minWidth={1680} />
      </DataGridScrollArea>
    </DataGridShell>
  );
}

function ColumnSeparatorsGrid() {
  const columns = useMemo(
    () => [
      columnHelper.accessor("matNbr", {
        header: "Material #",
        cell: (info) => info.getValue(),
        meta: { borderRight: true, minWidth: 120, nowrap: true },
      }),
      columnHelper.accessor("description", {
        header: "Description",
        cell: (info) => info.getValue(),
        meta: { minWidth: 260 },
      }),
      columnHelper.accessor("plant", {
        header: "Plant",
        cell: (info) => info.getValue(),
        meta: { borderRight: true, minWidth: 150, nowrap: true },
      }),
      columnHelper.accessor("status", {
        header: "Status",
        cell: (info) => getMaterialStatusDescription(info.getValue()),
        enableSorting: false,
        meta: { minWidth: 190, nowrap: true },
      }),
      columnHelper.accessor("onHand", {
        header: "On hand",
        cell: (info) => info.getValue().toLocaleString("en-US"),
        meta: { align: "right" as const, minWidth: 110, nowrap: true },
      }),
    ],
    [],
  );
  const data = useMemo(() => products.slice(0, 5), []);
  const { table } = useDataGrid({ data, columns, getRowId: (row) => row.id });

  return (
    <DataGridShell table={table} className="w-full max-w-4xl">
      <DataGridToolbar
        title="Column separators"
        description="Opt-in vertical dividers via meta.borderRight on Material # and Plant."
      />
      <DataGridTable caption="Column separators" />
    </DataGridShell>
  );
}

function SelectionGrid() {
  const columns = useMemo(() => [createSelectionColumn<Product>(), ...baseColumns], []);
  const data = useMemo(() => products.slice(0, 5), []);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});

  const { table } = useDataGrid({
    data,
    columns,
    getRowId: (row) => row.id,
    enableRowSelection: true,
    state: { rowSelection },
    onRowSelectionChange: setRowSelection,
  });

  return (
    <DataGridShell table={table} className="w-full max-w-6xl">
      <DataGridToolbar title="Selectable materials" description="Select materials for bulk inventory actions." />
      <DataGridTable caption="Selectable materials" />
      <Typography variant="body2" color="secondary">
        Selected: {Object.keys(rowSelection).join(", ") || "(none)"}
      </Typography>
    </DataGridShell>
  );
}

function DisabledRowsGrid() {
  const columns = useMemo(
    () => [
      createSelectionColumn<Product>(),
      ...baseColumns,
      columnHelper.display({
        id: "action",
        header: "Action",
        cell: () => (
          <Button type="button" size="sm" variant="outline" onClick={fn()}>
            Adjust
          </Button>
        ),
        meta: { nowrap: true },
      }),
    ],
    [],
  );
  const data = useMemo(() => products.slice(0, 5), []);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});

  const { table } = useDataGrid({
    data,
    columns,
    getRowId: (row) => row.id,
    enableRowSelection: (row) => row.original.status === "AC",
    state: { rowSelection },
    onRowSelectionChange: setRowSelection,
  });

  return (
    <DataGridShell table={table} className="w-full max-w-6xl">
      <DataGridToolbar
        title="Disabled rows"
        description="Non-Active materials mute text and inert nested controls (e.g. Adjust) without a disabled row background."
      />
      <DataGridTable<Product> caption="Disabled rows" onRowClick={fn()} getRowAriaLabel={(row) => `Open ${row.description}`} />
    </DataGridShell>
  );
}

function ExplicitDisabledRowsGrid() {
  const columns = useMemo(
    () => [
      ...baseColumns,
      columnHelper.display({
        id: "action",
        header: "Action",
        cell: () => (
          <Button type="button" size="sm" variant="outline" onClick={fn()}>
            Adjust
          </Button>
        ),
        meta: { nowrap: true },
      }),
    ],
    [],
  );
  const data = useMemo(() => products.slice(0, 5), []);

  const { table } = useDataGrid({
    data,
    columns,
    getRowId: (row) => row.id,
  });

  return (
    <DataGridShell table={table} className="w-full max-w-6xl">
      <DataGridToolbar
        title="isRowDisabled"
        description="Materials that are not Active are muted via isRowDisabled — content only, not cell backgrounds."
      />
      <DataGridTable<Product>
        caption="isRowDisabled"
        isRowDisabled={(row) => row.status !== "AC"}
        onRowClick={fn()}
        getRowAriaLabel={(row) => `Open ${row.description}`}
      />
    </DataGridShell>
  );
}

function CapReachedGrid() {
  const columns = useMemo(() => baseColumns, []);
  const data = useMemo(() => products.slice(0, 4), []);
  const { table } = useDataGrid({ data, columns, getRowId: (row) => row.id });

  return (
    <DataGridShell table={table} className="w-full max-w-6xl">
      <DataGridToolbar
        title="Row cap"
        description={`Stops fetching after maxLoadedRows (default page size elsewhere is ${DATA_GRID_DEFAULT_PAGE_SIZE}).`}
      />
      <DataGridTable caption="Row cap" />
      <DataGridInfiniteScroll
        hasNextPage
        isFetchingNextPage={false}
        loadedCount={4}
        totalCount={products.length}
        maxLoadedRows={4}
        fetchNextPage={fn()}
      />
    </DataGridShell>
  );
}

function ToolbarOnly() {
  const [term, setTerm] = useState("");
  return (
    <div className="w-full max-w-6xl">
      <DataGridToolbar title="Materials" description="Search, filters, and export without a table body.">
        <DataGridSearch value={term} onSearch={setTerm} placeholder="Search materials" />
        <DataGridFilterMenu activeCount={term ? 1 : 0}>
          <Typography variant="body2" color="secondary">
            Material status and plant filters
          </Typography>
        </DataGridFilterMenu>
        <DataGridExportButton onExport={fn()} />
        <DataGridExportButton disabled />
      </DataGridToolbar>
      <Typography variant="body2" color="secondary">
        Search term: {term || "(empty)"}
      </Typography>
    </div>
  );
}

const meta: Meta = {
  title: "Organisms/DataGrid",
  tags: ["autodocs"],
  decorators: [
    (Story) => {
      const [client] = useState(
        () =>
          new QueryClient({
            defaultOptions: {
              queries: { retry: false, refetchOnWindowFocus: false },
            },
          }),
      );
      return (
        <QueryClientProvider client={client}>
          <Story />
        </QueryClientProvider>
      );
    },
  ],
  parameters: {
    layout: "padded",
    docs: {
      description: {
        component:
          "Composable TanStack Table grid for Stratium material and inventory views, with toolbar, selection, sizes/variants, and sentinel-based infinite scroll.",
      },
    },
  },
};

export default meta;
type Story = StoryObj;

export const Interactive: Story = {
  render: () => <InteractiveGrid />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByRole("table", { name: "Materials" })).toBeInTheDocument();
    await expect(canvas.getByText("Acetaminophen 500mg Tab 100ct")).toBeInTheDocument();
    await expect(canvas.getByText("Insulin Glargine 100u/mL Vial 10mL")).toBeInTheDocument();

    await userEvent.click(canvas.getByRole("button", { name: /^Material #$/i }));
    await expect(canvas.getByRole("columnheader", { name: /Material #/i })).toHaveAttribute("aria-sort", "ascending");
  },
};

export const Loading: Story = {
  render: () => <AsyncGrid isLoading empty />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByRole("table", { name: "Materials" })).toHaveAttribute("aria-busy", "true");
  },
};

export const Updating: Story = {
  render: () => <AsyncGrid isUpdating />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByRole("table", { name: "Materials" })).toHaveAttribute("aria-busy", "true");
    await expect(canvas.getByText("Acetaminophen 500mg Tab 100ct")).toBeInTheDocument();
  },
};

export const ErrorState: Story = {
  render: () => <AsyncGrid empty isError />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByText("Unable to load data.")).toBeInTheDocument();
  },
};

export const ErrorCustom: Story = {
  render: () => (
    <AsyncGrid
      empty
      isError
      errorContent={
        <Typography as="span" variant="body2" color="secondary">
          Unable to load material inventory for the selected plants
        </Typography>
      }
    />
  ),
};

export const Empty: Story = {
  render: () => <AsyncGrid empty />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByText("No materials found")).toBeInTheDocument();
  },
};

export const EmptyCustom: Story = {
  render: () => (
    <AsyncGrid
      empty
      emptyContent={
        <Typography as="span" variant="body2" color="secondary">
          No materials match the current plant and status filters
        </Typography>
      }
    />
  ),
};

export const Sizes: Story = {
  render: () => (
    <div className="flex flex-col gap-8">
      <AsyncGrid size="sm" />
      <AsyncGrid size="md" />
      <AsyncGrid size="lg" />
    </div>
  ),
};

export const Variants: Story = {
  render: () => (
    <div className="flex flex-col gap-8">
      <AsyncGrid variant="plain" />
      <AsyncGrid variant="bordered" />
      <AsyncGrid variant="striped" />
    </div>
  ),
};

export const Selection: Story = {
  render: () => <SelectionGrid />,
};

export const DisabledRows: Story = {
  render: () => <DisabledRowsGrid />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const unavailableRow = canvas.getByText("Atorvastatin 40mg Tab 90ct").closest("tr");
    await expect(unavailableRow).toHaveAttribute("aria-disabled", "true");
  },
};

export const IsRowDisabled: Story = {
  render: () => <ExplicitDisabledRowsGrid />,
};

export const HorizontalScroll: Story = {
  render: () => <HorizontalScrollGrid />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByRole("table", { name: "Materials" })).toHaveStyle({ minWidth: "1680px" });
    await expect(canvas.getByRole("columnheader", { name: /Material #/i })).toHaveStyle({
      minWidth: "120px",
    });
  },
};

export const ColumnSeparators: Story = {
  render: () => <ColumnSeparatorsGrid />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const materialHeader = canvas.getByRole("columnheader", { name: /Material #/i });
    const plantHeader = canvas.getByRole("columnheader", { name: /Plant/i });
    const statusHeader = canvas.getByRole("columnheader", { name: /Status/i });
    await expect(materialHeader).toHaveClass("border-r");
    await expect(materialHeader).toHaveClass("border-ui-border-secondary");
    await expect(plantHeader).toHaveClass("border-r");
    await expect(statusHeader).not.toHaveClass("border-r");
  },
};

export const ServerInfiniteScroll: Story = {
  render: () => <ServerInfiniteGrid />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(await canvas.findByText("Acetaminophen 500mg Tab 100ct")).toBeInTheDocument();
    await userEvent.click(canvas.getByRole("button", { name: /Load more/i }));
    await expect(await canvas.findByText("Atorvastatin 40mg Tab 90ct")).toBeInTheDocument();
  },
};

export const ScrollAreaInfiniteScroll: Story = {
  render: () => <ServerInfiniteGrid scrollArea />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(await canvas.findByText("Acetaminophen 500mg Tab 100ct")).toBeInTheDocument();
    await userEvent.click(canvas.getByRole("button", { name: /Load more/i }));
    await expect(await canvas.findByText("Atorvastatin 40mg Tab 90ct")).toBeInTheDocument();
  },
};

export const CapReached: Story = {
  render: () => <CapReachedGrid />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByText(/Showing first 4 rows/i)).toBeInTheDocument();
  },
};

export const ToolbarOnlyStory: Story = {
  name: "ToolbarOnly",
  render: () => <ToolbarOnly />,
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole("button", { name: /Filters/i }));
    await expect(canvas.getByText("Material status and plant filters")).toBeInTheDocument();
  },
};
