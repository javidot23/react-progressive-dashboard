import { Button } from "@/components/atoms/Button";
import { cn } from "@/lib/utils";

export type DataGridExportButtonProps = {
  onExport?: () => void;
  label?: string;
  disabled?: boolean;
  className?: string;
};

export function DataGridExportButton({
  onExport,
  label = "Download CSV",
  disabled = false,
  className,
}: DataGridExportButtonProps) {
  return (
    <Button
      type="button"
      variant="secondary"
      size="sm"
      disabled={disabled || !onExport}
      onClick={() => onExport?.()}
      className={cn(
        "h-8 gap-1.5 border-2 border-neutral-200 bg-ui-background-primary px-3 text-sm font-bold text-brand-primary-main hover:bg-neutral-100 disabled:pointer-events-auto disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
    >
      {label}
    </Button>
  );
}
