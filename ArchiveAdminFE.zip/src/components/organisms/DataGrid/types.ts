import type {
  ColumnDef,
  ColumnFiltersState,
  ColumnOrderState,
  OnChangeFn,
  RowData,
  RowSelectionState,
  SortingState,
  Table,
  TableOptions,
  VisibilityState,
} from "@tanstack/react-table";
import type { ReactNode } from "react";

export type {
  ColumnDef,
  ColumnFiltersState,
  ColumnOrderState,
  OnChangeFn,
  RowSelectionState,
  SortingState,
  Table,
  VisibilityState,
};

declare module "@tanstack/react-table" {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  interface ColumnMeta<TData extends RowData, TValue> {
    borderRight?: boolean;
    align?: "left" | "center" | "right";
    minWidth?: number | string;
    nowrap?: boolean;
    ariaLabel?: string;
    headerAccessory?: ReactNode;
  }
}

export const EMPTY_DATA_GRID_ROWS: never[] = [];

type ControlledStateKeys = "sorting" | "columnFilters" | "globalFilter" | "rowSelection" | "columnVisibility" | "columnOrder";

export type DataGridState = Pick<NonNullable<TableOptions<unknown>["state"]>, ControlledStateKeys>;

type DataGridOptionKeys =
  | "data"
  | "columns"
  | "getRowId"
  | "enableRowSelection"
  | "enableMultiRowSelection"
  | "enableSorting"
  | "enableMultiSort"
  | "enableFilters"
  | "enableColumnFilters"
  | "enableGlobalFilter"
  | "enableHiding"
  | "manualSorting"
  | "manualFiltering"
  | "onSortingChange"
  | "onColumnFiltersChange"
  | "onGlobalFilterChange"
  | "onRowSelectionChange"
  | "onColumnVisibilityChange"
  | "onColumnOrderChange"
  | "globalFilterFn"
  | "filterFns"
  | "sortingFns"
  | "debugTable";

export type DataGridOptions<TData> = Omit<Pick<TableOptions<TData>, DataGridOptionKeys>, "columns"> & {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  columns: ColumnDef<TData, any>[];
  state?: DataGridState;
  initialState?: DataGridState;
};

export type UseDataGridResult<TData> = {
  table: Table<TData>;
};

export function pickDefinedState(state: DataGridState | undefined): DataGridState | undefined {
  if (!state) return undefined;

  const next: DataGridState = {};
  if (state.sorting !== undefined) next.sorting = state.sorting;
  if (state.columnFilters !== undefined) next.columnFilters = state.columnFilters;
  if (state.globalFilter !== undefined) next.globalFilter = state.globalFilter;
  if (state.rowSelection !== undefined) next.rowSelection = state.rowSelection;
  if (state.columnVisibility !== undefined) next.columnVisibility = state.columnVisibility;
  if (state.columnOrder !== undefined) next.columnOrder = state.columnOrder;

  return Object.keys(next).length > 0 ? next : undefined;
}
