import { getCoreRowModel, getFilteredRowModel, getSortedRowModel, useReactTable } from "@tanstack/react-table";
import { pickDefinedState, type DataGridOptions, type UseDataGridResult } from "./types";

const coreRowModel = getCoreRowModel();
const sortedRowModel = getSortedRowModel();
const filteredRowModel = getFilteredRowModel();

export function useDataGrid<TData>(options: DataGridOptions<TData>): UseDataGridResult<TData> {
  const {
    enableSorting = true,
    enableMultiSort = true,
    enableFilters = true,
    enableColumnFilters = true,
    enableGlobalFilter = true,
    enableHiding = true,
    manualSorting = false,
    manualFiltering = false,
    state,
    initialState,
    ...rest
  } = options;

  const table = useReactTable({
    ...rest,
    enableSorting,
    enableMultiSort,
    enableFilters,
    enableColumnFilters,
    enableGlobalFilter,
    enableHiding,
    manualSorting,
    manualFiltering,
    getCoreRowModel: coreRowModel,
    getSortedRowModel: manualSorting ? undefined : sortedRowModel,
    getFilteredRowModel: manualFiltering ? undefined : filteredRowModel,
    state: pickDefinedState(state),
    initialState: pickDefinedState(initialState),
  });

  return { table };
}
