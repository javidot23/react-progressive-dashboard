import { Outlet } from "react-router-dom";
import { AdminLayout } from "@/app/layouts";
import { ProtectedRoute } from "@/components/common";
import { ROUTES } from "@/constants/routes";

/**
 * Wraps authenticated admin shell routes.
 * Child routes render inside AdminLayout via <Outlet />.
 */
export function ProtectedRoutes() {
  return (
    <ProtectedRoute redirectTo={ROUTES.LOGIN}>
      <AdminLayout />
    </ProtectedRoute>
  );
}

/** Convenience outlet for nested protected feature routes. */
export function ProtectedOutlet() {
  return <Outlet />;
}
