import { Suspense, lazy } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { ROUTES } from "@/constants/routes";
import { ProtectedRoutes } from "./ProtectedRoutes";

const LoginPage = lazy(() => import("@/pages/LoginPage").then((m) => ({ default: m.LoginPage })));
const TenantsPage = lazy(() => import("@/pages/TenantsPage").then((m) => ({ default: m.TenantsPage })));
const TenantDetailPage = lazy(() => import("@/pages/TenantDetailPage").then((m) => ({ default: m.TenantDetailPage })));
const UsersPage = lazy(() => import("@/pages/UsersPage").then((m) => ({ default: m.UsersPage })));
const AuditLogPage = lazy(() => import("@/pages/AuditLogPage").then((m) => ({ default: m.AuditLogPage })));
const ErrorPage = lazy(() => import("@/pages/ErrorPage").then((m) => ({ default: m.ErrorPage })));
const NotFoundPage = lazy(() => import("@/pages/NotFoundPage").then((m) => ({ default: m.NotFoundPage })));

function RouteFallback() {
  return (
    <div className="flex min-h-[40vh] items-center justify-center text-sm text-ui-text-primary" role="status">
      Loading…
    </div>
  );
}

export function AppRoutes() {
  return (
    <Suspense fallback={<RouteFallback />}>
      <Routes>
        <Route path={ROUTES.LOGIN} element={<LoginPage />} />

        <Route element={<ProtectedRoutes />}>
          <Route index element={<TenantsPage />} />
          <Route path="tenants/:tenantUuid" element={<TenantDetailPage />} />
          <Route path="users" element={<UsersPage />} />
          <Route path="audit-log" element={<AuditLogPage />} />
          <Route path="error" element={<ErrorPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>

        <Route path="home" element={<Navigate to={ROUTES.TENANTS} replace />} />
      </Routes>
    </Suspense>
  );
}
