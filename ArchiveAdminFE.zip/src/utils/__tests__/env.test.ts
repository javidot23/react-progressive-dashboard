import { afterEach, describe, expect, it, vi } from "vitest";
import { getApiUrl } from "../env";

describe("getApiUrl", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("reads VITE_API_URL from import.meta.env", () => {
    vi.stubEnv("VITE_API_URL", "https://api.example.com/admin ");
    expect(getApiUrl()).toBe("https://api.example.com/admin");
  });

  it("falls back when VITE_API_URL is unset", () => {
    vi.stubEnv("VITE_API_URL", undefined as unknown as string);
    expect(getApiUrl()).toBe("http://localhost:8001/api");
  });
});
