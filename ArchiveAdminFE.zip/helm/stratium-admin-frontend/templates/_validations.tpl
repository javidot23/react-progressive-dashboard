{{/* A mutable reference lets a later push silently change what's running behind a
     digest-pinned rollout's back. Require either a digest or a non-"latest" tag. */}}
{{- define "stratium-admin-frontend.validateImageImmutability" -}}
{{- if not .Values.image.digest -}}
{{- if not .Values.image.tag -}}
{{- fail "image.digest or image.tag is required; pinning to a digest is strongly preferred over a tag" -}}
{{- end -}}
{{- if eq .Values.image.tag "latest" -}}
{{- fail "image.tag must not be \"latest\" - use image.digest, or a tag that uniquely identifies a build" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/* nginx's SIGQUIT graceful shutdown only starts after preStop returns; if the sleep
     alone consumes the whole grace period, the kubelet SIGKILLs nginx mid-drain. */}}
{{- define "stratium-admin-frontend.validateGracefulShutdown" -}}
{{- if ge (.Values.preStopSleepSeconds | int) (.Values.terminationGracePeriodSeconds | int) -}}
{{- fail "preStopSleepSeconds must be less than terminationGracePeriodSeconds, or nginx is SIGKILLed before it can drain connections" -}}
{{- end -}}
{{- end -}}
