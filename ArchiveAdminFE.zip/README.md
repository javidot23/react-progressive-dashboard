# Stratium Admin Frontend

Standalone administrative frontend for Stratium. This application is **not** customer-facing and does **not** include multi-tenant logic.

## Stack

- React 19 + TypeScript
- Vite 8
- React Router v7
- Zustand (UI state only)
- TanStack React Query v5
- Axios
- Tailwind CSS v4
- Storybook 10
- Vitest + React Testing Library
- ESLint + Prettier

## Requirements

- Node.js 22.12+ (see `.nvmrc`)
- On Windows, prefer an uppercase drive cwd (for example `C:/...`). Vitest can fail under lowercase `c:` paths; the config temporarily uses the `vmThreads` pool as a workaround until the upstream drive-letter fix lands. Prefer uppercase cwd when practical—`vmThreads` has documented ESM/VM caveats.

## Getting started

```bash
npm install
npm run dev
```

The app runs on [http://localhost:5173](http://localhost:5173) by default.

## Scripts

| Script                    | Description                                |
| ------------------------- | ------------------------------------------ |
| `npm run dev`             | Start Vite in development mode             |
| `npm run build`           | Typecheck and production build             |
| `npm run preview`         | Preview the production build               |
| `npm run test`            | Run Vitest once (CI-safe)                  |
| `npm run test:watch`      | Run Vitest in watch mode                   |
| `npm run test:coverage`   | Run Vitest with V8 coverage                |
| `npm run lint`            | Run ESLint across the project              |
| `npm run typecheck`       | Run TypeScript project build (`tsc -b`)    |
| `npm run format:check`    | Check formatting without modifying files   |
| `npm run check`           | Run lint, typecheck, and formatting checks |
| `npm run format`          | Format with Prettier                       |
| `npm run storybook`       | Start Storybook on port 6006               |
| `npm run build-storybook` | Build static Storybook                     |

## Environment

Copy `.env.example` and adjust as needed. Mode-specific files:

- `.env.development`
- `.env.staging`
- `.env.production`

## Project structure

```
src/
  app/           # App shell, providers, router, layouts
  features/      # Feature modules (dashboard, users, roles, …)
  components/    # Shared UI and common components
  services/      # Axios client + API modules
  hooks/         # Shared hooks
  stores/        # Zustand UI stores
  types/         # Shared TypeScript types
  utils/         # Helpers (cn, env)
  styles/        # Global Tailwind styles
```

## Architecture notes

- **Feature-based modules** — add new admin areas under `src/features/` without restructuring.
- **Server state** — React Query only.
- **Client UI state** — Zustand only (sidebar, theme).
- **HTTP** — centralized Axios client with request/response interceptor extension points for future auth.
- **Independent deployment** — standard Vite build output in `dist/`.

## Auth

Authentication is intentionally not implemented yet.
