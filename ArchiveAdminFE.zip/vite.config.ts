import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";
import { fileURLToPath } from "node:url";
import packageJson from "./package.json" with { type: "json" };
import { fontPreloadPlugin } from "./vite-plugins/index.ts";

/** Normalize Windows drive letters so Vitest worker path maps stay consistent. */
function resolveRootDir(): string {
  const dir = path.dirname(fileURLToPath(import.meta.url));
  return process.platform === "win32" ? dir.replace(/^([a-z]):/, (_, d: string) => `${d.toUpperCase()}:`) : dir;
}

const rootDir = resolveRootDir();

/** Vendor splits for long-term caching and smaller initial route chunks. */
function manualChunks(id: string): string | undefined {
  if (!id.includes("node_modules")) {
    return undefined;
  }

  if (id.includes("@newrelic/")) {
    return "telemetry";
  }

  return undefined;
}

export default defineConfig({
  root: rootDir,
  plugins: [react(), tailwindcss(), fontPreloadPlugin()],
  // Vite 8 defaults cssMinify to lightningcss, which rejects CDS-derived
  // `@media (width >= var(--...))` rules. Use esbuild like Vite ≤7.
  build: {
    cssMinify: "esbuild",
    rollupOptions: {
      output: {
        manualChunks,
      },
    },
  },
  define: {
    __BUILD_DATE__: JSON.stringify(new Date().toISOString()),
    __APP_VERSION__: JSON.stringify(process.env.VITE_APP_VERSION || packageJson.version),
  },
  resolve: {
    alias: {
      "@": path.resolve(rootDir, "./src"),
    },
  },
  test: {
    environment: "jsdom",
    // Temporary workaround for Vitest's Windows lowercase-drive bug
    // (https://github.com/vitest-dev/vitest/issues/10692). Default forks/threads
    // can fail to find the suite when cwd uses `c:` while Vite normalizes to `C:`.
    // Prefer uppercase drive cwd when possible; vmThreads has documented ESM/VM
    // caveats and is not a permanent default for larger suites.
    pool: "vmThreads",
    setupFiles: [path.resolve(rootDir, "./src/testSetup.ts")],
  },
});
