/**
 * Generates src/lib/design-system/theme.generated.css from CDS tokens.
 * Maps tokens into Tailwind namespaces so short utilities work:
 *   --color-*     → bg-*, text-*, border-*
 *   --spacing-*   → p-*, m-*, gap-*, mb-*
 *   --radius-*    → rounded-*
 *   --font-*      → font-* (font-family)
 *   --text-*      → text-* (font-size)
 *   --leading-*   → leading-*
 *   --shadow-*    → shadow-*
 *
 * Skips keys already in theme.overrides.css (Stratium aliases preserved).
 *
 * Usage: node scripts/generate-cds-theme.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const dsDir = path.join(root, "src/lib/design-system");

const tokensPath = path.join(dsDir, "cds-tokens.css");
const overridesPath = path.join(dsDir, "theme.overrides.css");
const outPath = path.join(dsDir, "theme.generated.css");

const css = fs.readFileSync(tokensPath, "utf8");
const overridesCss = fs.readFileSync(overridesPath, "utf8");

const cdsTokens = [...new Set([...css.matchAll(/(--cds-[\w-]+):/g)].map((m) => m[1]))].sort();

const themeBlock = overridesCss.match(/@theme\s*\{([\s\S]*)\}/)?.[1] ?? "";
const existingKeys = new Set([...themeBlock.matchAll(/^\s*(--[\w-]+):/gm)].map((m) => m[1]));

function spaceSuffix(value) {
  // Tailwind spacing keys use underscore for fractions: 0-5 → 0_5
  return value.replace(/-/g, "_");
}

/**
 * Map a CDS token to one or more Tailwind @theme keys.
 * Returns [] to skip (still available as var(--cds-*)).
 */
function cdsToThemeKeys(cds) {
  if (cds.startsWith("--cds-color-")) {
    return [`--color-${cds.slice("--cds-color-".length)}`];
  }

  if (cds.startsWith("--cds-size-space-")) {
    return [`--spacing-${spaceSuffix(cds.slice("--cds-size-space-".length))}`];
  }

  // paragraph spacing → mb-paragraph-5, gap-paragraph-4, etc.
  if (cds.startsWith("--cds-size-paragraph-spacing-")) {
    return [`--spacing-paragraph-${cds.slice("--cds-size-paragraph-spacing-".length)}`];
  }

  if (cds.startsWith("--cds-size-font-")) {
    return [`--text-${cds.slice("--cds-size-font-".length)}`];
  }

  if (cds.startsWith("--cds-size-line-height-")) {
    return [`--leading-${cds.slice("--cds-size-line-height-".length)}`];
  }

  if (cds.startsWith("--cds-size-letter-spacing-")) {
    return [`--tracking-${cds.slice("--cds-size-letter-spacing-".length)}`];
  }

  if (cds.startsWith("--cds-size-border-radius-")) {
    return [`--radius-${cds.slice("--cds-size-border-radius-".length)}`];
  }

  if (cds.startsWith("--cds-size-border-width-")) {
    const map = { none: "0", sm: "1", md: "2", lg: "3", xl: "4" };
    const suffix = cds.slice("--cds-size-border-width-".length);
    return [`--border-width-${map[suffix] ?? suffix}`];
  }

  if (cds.startsWith("--cds-size-focus-ring-")) {
    return [`--ring-width-${cds.slice("--cds-size-focus-ring-".length)}`];
  }

  // Grid size tokens (margins, gutters) → spacing utilities
  if (cds.startsWith("--cds-size-grid-")) {
    return [`--spacing-grid-${cds.slice("--cds-size-grid-".length)}`];
  }

  if (cds.startsWith("--cds-size-")) {
    return [`--spacing-${cds.slice("--cds-size-".length)}`];
  }

  if (cds.startsWith("--cds-elevation-shadow-")) {
    return [`--shadow-${cds.slice("--cds-elevation-shadow-".length)}`];
  }

  if (cds.startsWith("--cds-text-font-weight-")) {
    return [`--font-weight-${cds.slice("--cds-text-font-weight-".length)}`];
  }

  if (cds.startsWith("--cds-text-font-family-")) {
    return [`--font-${cds.slice("--cds-text-font-family-".length)}`];
  }

  // Typography style tokens → short font / text / leading / spacing utilities
  if (cds.startsWith("--cds-text-")) {
    const rest = cds.slice("--cds-text-".length);

    if (rest.endsWith("-font-family")) {
      const name = rest.slice(0, -"-font-family".length);
      return [`--font-${name}`];
    }
    if (rest.endsWith("-font-size")) {
      const name = rest.slice(0, -"-font-size".length);
      return [`--text-${name}`];
    }
    if (rest.endsWith("-line-height")) {
      const name = rest.slice(0, -"-line-height".length);
      return [`--leading-${name}`];
    }
    if (rest.endsWith("-paragraph-spacing")) {
      const name = rest.slice(0, -"-paragraph-spacing".length);
      return [`--spacing-${name}-paragraph`];
    }
    if (rest.endsWith("-letter-spacing")) {
      const name = rest.slice(0, -"-letter-spacing".length);
      return [`--tracking-${name}`];
    }

    // font-weight / font-style / font-variant on styles conflict with font-* family
    // utilities — skip; use font-bold, italic, etc. (values still in cds-tokens.css)
    if (
      rest.endsWith("-font-weight") ||
      rest.endsWith("-font-style") ||
      rest.endsWith("-font-variant") ||
      rest.endsWith("-text-decoration") ||
      rest.startsWith("decoration-") ||
      rest.startsWith("font-variant")
    ) {
      return [];
    }

    return [`--font-${rest}`];
  }

  // Grid breakpoint margin/gutter → spacing.
  // Do NOT map min/max/columns to --breakpoint-*: Tailwind would emit
  // `@media (width >= var(--cds-...))`, which LightningCSS (Vite 8 default
  // cssMinify) rejects. Tokens remain usable as var(--cds-*).
  if (cds.startsWith("--cds-grid-breakpoint-")) {
    const rest = cds.slice("--cds-grid-breakpoint-".length);
    if (rest.endsWith("-min-width") || rest.endsWith("-max-width") || rest.endsWith("-columns")) {
      return [];
    }
    return [`--spacing-${rest}`];
  }

  if (cds.startsWith("--cds-grid-responsive-")) {
    const rest = cds.slice("--cds-grid-responsive-".length);
    if (rest.endsWith("-min-width") || rest.endsWith("-max-width") || rest.endsWith("-columns")) {
      return [];
    }
    return [`--spacing-responsive-${rest}`];
  }

  if (cds.startsWith("--cds-grid-")) {
    const rest = cds.slice("--cds-grid-".length);
    return [`--spacing-grid-${rest}`];
  }

  if (cds.startsWith("--cds-focus-ring-")) {
    return [`--shadow-ring-${cds.slice("--cds-focus-ring-".length)}`];
  }

  if (cds.startsWith("--cds-number-")) {
    return [];
  }

  return [`--spacing-${cds.slice("--cds-".length)}`];
}

function categorizeThemeKey(key) {
  if (key.startsWith("--color-")) return "colors";
  if (key.startsWith("--spacing-")) return "spacing";
  if (key.startsWith("--text-") && !key.startsWith("--text-decoration")) return "font-size";
  if (key.startsWith("--leading-")) return "line-height";
  if (key.startsWith("--tracking-")) return "letter-spacing";
  if (key.startsWith("--radius-") || key.startsWith("--border-width-")) return "borders";
  if (key.startsWith("--shadow-")) return "shadows";
  if (key.startsWith("--font-weight-")) return "font-weight";
  if (key.startsWith("--font-")) return "fonts";
  if (key.startsWith("--breakpoint-")) return "breakpoints";
  if (key.startsWith("--ring-")) return "focus";
  return "other";
}

const lines = [];
const usedKeys = new Set();

for (const cds of cdsTokens) {
  const keys = cdsToThemeKeys(cds);
  if (!keys.length) {
    continue;
  }
  for (const key of keys) {
    if (existingKeys.has(key) || usedKeys.has(key)) continue;
    usedKeys.add(key);
    lines.push(`  ${key}: var(${cds});`);
  }
}

const grouped = {};
for (const line of lines) {
  const key = line.trim().split(":")[0];
  const cat = categorizeThemeKey(key);
  if (!grouped[cat]) grouped[cat] = [];
  grouped[cat].push(line);
}

const catOrder = [
  "colors",
  "spacing",
  "font-size",
  "line-height",
  "letter-spacing",
  "fonts",
  "font-weight",
  "borders",
  "shadows",
  "breakpoints",
  "focus",
  "other",
];

let out = "/* Auto-generated — do not edit. Regenerate: node scripts/generate-cds-theme.mjs */\n";
out += "/* Short utilities: bg-*, p-*, mb-paragraph-5, font-body-md, text-body-md, rounded-md, shadow-raised */\n";
out += "@theme {\n";

for (const cat of catOrder) {
  if (!grouped[cat]?.length) continue;
  out += `\n  /* CDS ${cat} */\n`;
  out += `${grouped[cat].join("\n")}\n`;
}

out += "}\n";

fs.writeFileSync(outPath, out);
