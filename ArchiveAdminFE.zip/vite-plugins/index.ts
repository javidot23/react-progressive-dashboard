export { fontPreloadPlugin } from "./font-preload-plugin.ts";
export type { FontPreloadOptions } from "./font-preload-plugin.ts";
