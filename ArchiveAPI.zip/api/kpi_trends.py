from __future__ import annotations

import calendar
from datetime import date, timedelta
from typing import Literal

from rest_framework import serializers

AggregationLevel = Literal["day", "week", "month"]


class KpiTrendPointSerializer(serializers.Serializer):
    period_start = serializers.DateField()
    period_end = serializers.DateField()
    value = serializers.FloatField()
    metrics = serializers.JSONField(required=False)


class KpiTrendResponseSerializer(serializers.Serializer):
    """
    Consistent, chart-ready KPI trend response schema.
    """

    kpi = serializers.CharField()
    unit = serializers.CharField()
    points = KpiTrendPointSerializer(many=True)


def to_bucket_start(d: date, aggregation: AggregationLevel) -> date:
    if aggregation == "day":
        return d
    if aggregation == "week":
        return d - timedelta(days=d.weekday())  # Monday
    if aggregation == "month":
        return d.replace(day=1)
    raise ValueError(f"Unsupported aggregation: {aggregation}")


def _add_month(d: date) -> date:
    """
    Advance to the first day of the next month.
    """
    year = d.year + (d.month // 12)
    month = (d.month % 12) + 1
    return date(year, month, 1)


def bucket_end(bucket_start: date, aggregation: AggregationLevel, requested_end: date) -> date:
    if aggregation == "day":
        return bucket_start
    if aggregation == "week":
        return min(requested_end, bucket_start + timedelta(days=6))
    if aggregation == "month":
        last_day = calendar.monthrange(bucket_start.year, bucket_start.month)[1]
        return min(requested_end, bucket_start.replace(day=last_day))
    raise ValueError(f"Unsupported aggregation: {aggregation}")


def iter_bucket_starts(start_date: date, end_date: date, aggregation: AggregationLevel) -> list[date]:
    start_bucket = to_bucket_start(start_date, aggregation)
    end_bucket = to_bucket_start(end_date, aggregation)

    buckets: list[date] = []
    current = start_bucket
    while current <= end_bucket:
        buckets.append(current)
        if aggregation == "day":
            current = current + timedelta(days=1)
        elif aggregation == "week":
            current = current + timedelta(days=7)
        elif aggregation == "month":
            current = _add_month(current)
        else:
            raise ValueError(f"Unsupported aggregation: {aggregation}")
    return buckets


# Default trend settings (fixed, not exposed to API)
DEFAULT_TREND_DAYS = 90
DEFAULT_AGGREGATION: AggregationLevel = "week"


def build_kpi_trend_response(
    *,
    kpi: str,
    unit: str,
    bucket_to_payload: dict[date, dict],
    default_value: float = 0.0,
) -> dict:
    """
    Build a standardized KPI trend response.

    Uses fixed defaults: 90 days lookback with weekly aggregation.

    `bucket_to_payload` maps bucket_start -> payload dict that must include:
    - "value": primary numeric value for the chart
    Optional: any other keys, which will be nested under "metrics" per point.
    """
    end_date = date.today()
    start_date = end_date - timedelta(days=DEFAULT_TREND_DAYS - 1)
    aggregation = DEFAULT_AGGREGATION

    points = []
    for b in iter_bucket_starts(start_date, end_date, aggregation):
        payload = bucket_to_payload.get(b, {}) or {}
        value = payload.get("value", default_value)
        metrics = {k: v for k, v in payload.items() if k != "value"}
        points.append(
            {
                "period_start": b,
                "period_end": bucket_end(b, aggregation, end_date),
                "value": float(value or 0.0),
                "metrics": metrics,
            }
        )

    return {
        "kpi": kpi,
        "unit": unit,
        "points": points,
    }
