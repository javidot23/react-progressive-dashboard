"""Email address helpers shared by tenant resolution and authentication."""

from __future__ import annotations


def email_domain(email: str) -> str | None:
    """Return the lowercased domain part of ``email``, or ``None`` if there is none."""
    if not email or "@" not in email:
        return None
    domain = email.strip().lower().rsplit("@", 1)[-1].strip()
    return domain or None


def normalize_email(email: str) -> str:
    return (email or "").strip().lower()
