"""Base for management commands that read/write tenant-scoped models."""

from __future__ import annotations

from django.core.management.base import BaseCommand, CommandError

from config.tenant_db import use_tenant_db


class TenantScopedCommand(BaseCommand):
    """Resolve a tenant and bind its DB for the duration of ``handle``.

    Subclasses keep a normal ``handle`` / ``add_arguments``. Tenant selection flags
    are injected via ``create_parser`` so callers do not need ``super().add_arguments``.
    """

    def create_parser(self, prog_name, subcommand, **kwargs):
        parser = super().create_parser(prog_name, subcommand, **kwargs)
        parser.add_argument(
            "--tenant-uuid",
            default=None,
            help="Tenant UUID whose app database to use (default: first active tenant).",
        )
        parser.add_argument(
            "--tenant-code",
            default=None,
            help="Tenant code whose app database to use (alternative to --tenant-uuid).",
        )
        return parser

    def execute(self, *args, **options):
        tenant = self.resolve_tenant(options)
        self.stdout.write(
            self.style.NOTICE(
                f"Using tenant {tenant.tenant_code} ({tenant.pk}) @ "
                f"{tenant.database_name}"
            )
        )
        with use_tenant_db(tenant):
            return super().execute(*args, **options)

    def resolve_tenant(self, options):
        from api.tenant.models import Tenant

        tenant_uuid = options.get("tenant_uuid")
        tenant_code = options.get("tenant_code")
        qs = Tenant.objects.filter(is_deleted=False, is_active=True)

        if tenant_uuid and tenant_code:
            raise CommandError("Pass only one of --tenant-uuid or --tenant-code.")
        if tenant_uuid:
            tenant = qs.filter(pk=tenant_uuid).first()
            if tenant is None:
                raise CommandError(f"No active tenant with uuid={tenant_uuid}.")
            return tenant
        if tenant_code:
            tenant = qs.filter(tenant_code=tenant_code).first()
            if tenant is None:
                raise CommandError(f"No active tenant with code={tenant_code!r}.")
            return tenant

        tenant = qs.order_by("tenant_code").first()
        if tenant is None:
            raise CommandError(
                "No active tenant found. Create one (e.g. fake_tenants) or pass "
                "--tenant-uuid / --tenant-code."
            )
        return tenant
