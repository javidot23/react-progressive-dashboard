from django.apps import AppConfig

from config.db_scope import DBScope


class CommonConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.common'
    label = 'common'
    db_scope = DBScope.CORE
