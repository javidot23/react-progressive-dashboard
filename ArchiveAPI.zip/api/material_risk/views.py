from django.conf import settings
from django.utils.decorators import method_decorator
from datetime import datetime
from django.views.decorators.cache import cache_page
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.global_filters import get_filtered_material_subquery
from api.material_risk.serializers import MaterialRiskSerializer, WeeklyAveragesSerializer
from api.material_risk.services import MaterialRiskService
from api.kpi_trends import build_kpi_trend_response


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialRiskListView(generics.ListAPIView):
    serializer_class = MaterialRiskSerializer
    pagination_class = None

    def get_queryset(self):
        material_id = self.kwargs.get('material_id')
        return MaterialRiskService.get_material_risks(material_id)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyAveragesView(APIView):
    """
    Returns average risk score and average dollars at risk for this week and last week.
    Includes trend data for the last 90 days.
    Supports global filters.
    """

    @extend_schema(responses=WeeklyAveragesSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = MaterialRiskService.get_weekly_averages(direct_mat_nbr, mat_nbr_subquery)

        rows = MaterialRiskService.get_risk_score_trend(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )

        bucket_to_payload = {}
        for row in rows:
            bucket = row["bucket"]
            if isinstance(bucket, datetime):
                bucket = bucket.date()
            avg_risk = row.get("avg_risk_score") or 0.0
            risk_score = round(avg_risk * 100.0, 2)
            bucket_to_payload[bucket] = {
                "value": risk_score,
                "risk_score": risk_score,
                "risk_score_pct": round(avg_risk, 3),
                "avg_dollars_at_risk": round(row.get("avg_dollars_at_risk") or 0.0, 2),
                "risk_score_out_of": 100,
            }

        data["trend"] = build_kpi_trend_response(
            kpi="risk_score",
            unit="score",
            bucket_to_payload=bucket_to_payload,
            default_value=0.0,
        )
        serializer = WeeklyAveragesSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)
