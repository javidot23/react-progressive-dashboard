import logging
from datetime import timedelta

from django.db.models import Avg, Q, OuterRef, Subquery
from django.db.models.functions import TruncWeek
from django.utils import timezone

from api.material.models import Material
from api.material_risk.models import MaterialRisk
from api.material_value_at_risk_history.models import MaterialValueAtRiskHistory

logger = logging.getLogger(__name__)

EXCLUDED_MATERIAL_Q = Q(material__drop_ship_flg=1) | Q(material__short_date_flg=1)

MAX_RISK_DATA_AGE_DAYS = 14


class MaterialRiskService:
    """
    Service class for Material Risk operations.
    """

    @staticmethod
    def get_material_risks(material_id):
        """
        Retrieve the latest material risks by status_date for a specific material with time_horizon=30.
        Returns records with the latest status_date per risk_type, handling cases where
        different risk types may have different latest dates.
        Only considers data from the last MAX_RISK_DATA_AGE_DAYS (2 weeks) as a safeguard.
        """
        logger.info("Retrieving material risks for material_id: %s", material_id)

        # Safeguard: only consider data from the last 2 weeks
        min_allowed_date = timezone.now().date() - timedelta(days=MAX_RISK_DATA_AGE_DAYS)

        # Build a subquery to get the max status_date per risk_type for this material
        max_status_date_per_risk_type = MaterialRisk.objects.filter(
            material__id=material_id,
            risk_type=OuterRef('risk_type'),
            status_date__gte=min_allowed_date
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(EXCLUDED_MATERIAL_Q).order_by('-status_date').values('status_date')[:1]

        # Get all records where status_date equals the max for that risk_type
        queryset = MaterialRisk.objects.filter(
            material__id=material_id,
            status_date=Subquery(max_status_date_per_risk_type),
            status_date__gte=min_allowed_date
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(EXCLUDED_MATERIAL_Q).select_related('material').order_by('-status_date', 'risk_type')

        return queryset

    @staticmethod
    def get_weekly_averages(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Calculate average risk score and average dollars at risk for this week and last week.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Calculating weekly averages for risk score and dollars at risk")
        now = timezone.now().date()

        # Calculate current week boundaries (Monday as start of week)
        current_week_start = now - timedelta(days=now.weekday())
        current_week_end = now

        # Calculate last week boundaries
        last_week_end = current_week_start - timedelta(days=1)
        last_week_start = last_week_end - timedelta(days=6)

        # This week calculations
        this_week_base_queryset = MaterialRisk.objects.filter(
            status_date__gte=current_week_start,
            status_date__lte=current_week_end
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(EXCLUDED_MATERIAL_Q)
        if direct_mat_nbr:
            this_week_base_queryset = this_week_base_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            this_week_base_queryset = this_week_base_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        this_week_risk_score_avg = this_week_base_queryset.aggregate(avg=Avg('risk_rating'))['avg'] or 0.0
        this_week_material_ids = list(
            this_week_base_queryset.values_list('material_id', flat=True).distinct()
        )

        this_week_dollars_avg = 0.0
        if this_week_material_ids:
            this_week_dollars_avg = Material.objects.filter(
                mat_nbr__in=this_week_material_ids
            ).aggregate(avg=Avg('dollars_at_risk_this_week'))['avg'] or 0.0

        # Last week calculations
        last_week_base_queryset = MaterialRisk.objects.filter(
            status_date__gte=last_week_start,
            status_date__lte=last_week_end
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(EXCLUDED_MATERIAL_Q)
        if direct_mat_nbr:
            last_week_base_queryset = last_week_base_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            last_week_base_queryset = last_week_base_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        last_week_risk_score_avg = last_week_base_queryset.aggregate(avg=Avg('risk_rating'))['avg'] or 0.0
        last_week_material_ids = list(
            last_week_base_queryset.values_list('material__mat_nbr', flat=True).distinct()
        )

        last_week_dollars_avg = 0.0
        if last_week_material_ids:
            last_week_dollars_avg = Material.objects.filter(
                mat_nbr__in=last_week_material_ids
            ).aggregate(avg=Avg('dollars_at_risk_prev_week'))['avg'] or 0.0

        logger.info(
            "Weekly averages: this_week_risk=%.3f, last_week_risk=%.3f, "
            "this_week_dollars=%.2f, last_week_dollars=%.2f",
            this_week_risk_score_avg,
            last_week_risk_score_avg,
            this_week_dollars_avg,
            last_week_dollars_avg
        )

        return {
            "average_risk_score_this_week": round(this_week_risk_score_avg, 3),
            "average_risk_score_last_week": round(last_week_risk_score_avg, 3),
            "average_dollars_at_risk_this_week": round(this_week_dollars_avg, 2),
            "average_dollars_at_risk_last_week": round(last_week_dollars_avg, 2),
            "period": {
                "this_week_start": current_week_start.isoformat(),
                "this_week_end": current_week_end.isoformat(),
                "last_week_start": last_week_start.isoformat(),
                "last_week_end": last_week_end.isoformat(),
            }
        }

    DEFAULT_TREND_DAYS = 90

    @staticmethod
    def get_risk_score_trend(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Trend of average risk score over the last 90 days with weekly aggregation.
        Uses MaterialRisk for risk_rating and MaterialValueAtRiskHistory for dollars_at_risk.
        """
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=MaterialRiskService.DEFAULT_TREND_DAYS - 1)

        # Get risk scores from MaterialRisk
        risk_queryset = MaterialRisk.objects.filter(
            status_date__gte=start_date, status_date__lte=end_date
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(EXCLUDED_MATERIAL_Q)

        if direct_mat_nbr:
            risk_queryset = risk_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            risk_queryset = risk_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        risk_data = list(
            risk_queryset.annotate(bucket=TruncWeek("status_date"))
            .values("bucket")
            .annotate(avg_risk_score=Avg("risk_rating"))
            .order_by("bucket")
        )

        # Get dollars at risk from MaterialValueAtRiskHistory
        dollars_queryset = MaterialValueAtRiskHistory.objects.filter(
            status_date__gte=start_date, status_date__lte=end_date
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(EXCLUDED_MATERIAL_Q)

        if direct_mat_nbr:
            dollars_queryset = dollars_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            dollars_queryset = dollars_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        dollars_data = list(
            dollars_queryset.annotate(bucket=TruncWeek("status_date"))
            .values("bucket")
            .annotate(avg_dollars_at_risk=Avg("dollars_at_risk_30_day"))
            .order_by("bucket")
        )

        # Combine the data by bucket (week)
        risk_by_bucket = {row["bucket"]: row["avg_risk_score"] for row in risk_data}
        dollars_by_bucket = {row["bucket"]: row["avg_dollars_at_risk"] for row in dollars_data}

        # Get all unique buckets
        all_buckets = set(risk_by_bucket.keys()) | set(dollars_by_bucket.keys())

        # Combine into final result
        result = []
        for bucket in sorted(all_buckets):
            result.append({
                "bucket": bucket,
                "avg_risk_score": risk_by_bucket.get(bucket) or 0.0,
                "avg_dollars_at_risk": dollars_by_bucket.get(bucket) or 0.0,
            })

        return result
