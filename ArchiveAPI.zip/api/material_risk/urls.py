from django.urls import path

from .views import MaterialRiskListView, WeeklyAveragesView

app_name = "material-risk"

urlpatterns = [
    path(
        "<int:material_id>/",
        MaterialRiskListView.as_view(),
        name="list",
    ),
    path(
        "weekly-averages/",
        WeeklyAveragesView.as_view(),
        name="weekly-averages",
    ),
]
