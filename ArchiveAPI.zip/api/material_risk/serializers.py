from rest_framework import serializers
from api.material_risk.models import MaterialRisk


class MaterialRiskSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaterialRisk
        fields = '__all__'


class WeeklyAveragesSerializer(serializers.Serializer):
    average_risk_score_this_week = serializers.FloatField()
    average_risk_score_last_week = serializers.FloatField()
    average_dollars_at_risk_this_week = serializers.FloatField()
    average_dollars_at_risk_last_week = serializers.FloatField()
    period = serializers.DictField()
    trend = serializers.DictField(required=False)
