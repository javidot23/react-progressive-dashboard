from django.apps import AppConfig


class MaterialRiskConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.material_risk'
