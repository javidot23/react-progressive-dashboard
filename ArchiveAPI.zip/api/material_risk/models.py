from django.db import models
from django.utils import timezone

from api.material.models import Material


class MaterialRisk(models.Model):
    """
    Model to represent material risk.
    """

    class RiskType(models.TextChoices):
        OPERATIONAL = "operational", "Operational"
        FINANCIAL = "financial", "Financial"
        MARKET = "market", "Market"
        PATIENT = "patient", "Patient"
        SALES = "sales", "Sales"
        REGULATORY = "regulatory", "Regulatory"
        LOCATION = "location", "Location"
        REPUTATIONAL = "reputational", "Reputational"

    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
    )
    risk_type = models.CharField(
        max_length=255,
        choices=RiskType.choices,
        default=RiskType.OPERATIONAL,
        null=True
    )
    risk_rating = models.FloatField(default=0.0, null=True)
    time_horizon = models.IntegerField(default=0, null=True)
    status_date = models.DateField(null=False, blank=False, default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "material_risks"
        verbose_name = "Material Risk"
        verbose_name_plural = "Material Risks"
        unique_together = ('material', 'risk_type', 'time_horizon', 'status_date')
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["material", "risk_type"]),
            models.Index(fields=["created_at"]),
            models.Index(fields=["material", "risk_rating"]),
        ]
