from rest_framework import serializers


class ApiErrorResponseSerializer(serializers.Serializer):
    """Wire format produced by ``api.exception_formatter.ExceptionFormatter``."""

    success = serializers.BooleanField()
    type = serializers.CharField()
    code = serializers.CharField()
    error = serializers.CharField(
        help_text=(
            "Human-readable error message. Validation errors for a specific field "
            "are formatted as '<field>: <message>'."
        ),
    )
