"""OpenAPI schema helpers for envelope-aware drf-spectacular docs."""
