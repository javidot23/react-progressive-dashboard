from django.conf import settings

from drf_spectacular.extensions import OpenApiAuthenticationExtension


class CookieSessionAuthenticationScheme(OpenApiAuthenticationExtension):
    target_class = "api.identity.authentication_session.CookieSessionAuthentication"
    name = "cookieAuth"

    def get_security_definition(self, auto_schema):
        return {
            "type": "apiKey",
            "in": "cookie",
            "name": settings.SESSION_COOKIE_NAME,
            "description": (
                "Django session cookie established by the SAP CDC OIDC BFF login "
                "flow (GET /login/start/ → IdP → GET /login/)."
            ),
        }
