from typing import List

from drf_spectacular.utils import OpenApiExample
from drf_standardized_errors.openapi import AutoSchema
from rest_framework import exceptions

import api.schema.authentication  # noqa: F401  # registers CookieSessionAuthenticationScheme


class EnvelopeAwareAutoSchema(AutoSchema):
    """AutoSchema with error examples matching ``ExceptionFormatter``."""

    def _get_error_response_examples(self) -> List[OpenApiExample]:
        status_codes = set(self._get_allowed_error_status_codes())
        examples = [
            _flattened_error_example(exceptions.AuthenticationFailed()),
            _flattened_error_example(exceptions.NotAuthenticated()),
            _flattened_error_example(exceptions.PermissionDenied()),
            _flattened_error_example(exceptions.NotFound()),
            _flattened_error_example(exceptions.MethodNotAllowed("GET")),
            _flattened_error_example(exceptions.APIException()),
            OpenApiExample(
                "ValidationError",
                value={
                    "success": False,
                    "type": "validation_error",
                    "code": "invalid",
                    "error": "field_name: This field is required.",
                },
                response_only=True,
                status_codes=["400"],
            ),
        ]
        return [
            example
            for example in examples
            if status_codes.intersection(example.status_codes)
        ]


def _flattened_error_example(exc: exceptions.APIException) -> OpenApiExample:
    if 400 <= exc.status_code < 500:
        type_ = "client_error"
    else:
        type_ = "server_error"
    code = exc.get_codes()
    if isinstance(code, dict):
        code = next(iter(code.values()), "error")
    detail = exc.detail
    if isinstance(detail, (list, dict)):
        detail = str(detail)
    return OpenApiExample(
        exc.__class__.__name__,
        value={
            "success": False,
            "type": type_,
            "code": code,
            "error": detail,
        },
        response_only=True,
        status_codes=[str(exc.status_code)],
    )
