"""Postprocessing hooks for OpenAPI schema generation."""

_JSON_MEDIA_TYPES = ("application/json",)


def wrap_success_response_envelope(result, generator, request, public):
    """Wrap 2xx JSON response bodies as ``{"success": true, "data": ...}``.

    Matches ``api.success_json_response.SuccessJsonResponse``. Skips 204 (no body).
    """
    for path_item in result.get("paths", {}).values():
        if not isinstance(path_item, dict):
            continue
        for method, operation in path_item.items():
            if method.startswith("x-") or not isinstance(operation, dict):
                continue
            responses = operation.get("responses")
            if not isinstance(responses, dict):
                continue
            for status_code, response in responses.items():
                if not _is_success_status(status_code):
                    continue
                if str(status_code) == "204":
                    continue
                if not isinstance(response, dict):
                    continue
                content = response.get("content")
                if not isinstance(content, dict):
                    continue
                for media_type, media_obj in content.items():
                    if media_type not in _JSON_MEDIA_TYPES:
                        continue
                    if not isinstance(media_obj, dict):
                        continue
                    schema = media_obj.get("schema")
                    if schema is None:
                        continue
                    if _is_already_enveloped(schema):
                        continue
                    media_obj["schema"] = {
                        "type": "object",
                        "required": ["success", "data"],
                        "properties": {
                            "success": {
                                "type": "boolean",
                                "enum": [True],
                            },
                            "data": schema,
                        },
                    }
    return result


def _is_success_status(status_code) -> bool:
    try:
        code = int(status_code)
    except (TypeError, ValueError):
        return False
    return 200 <= code < 300


def _is_already_enveloped(schema) -> bool:
    if not isinstance(schema, dict):
        return False
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return False
    return "success" in properties and "data" in properties
