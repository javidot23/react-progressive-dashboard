import csv
import logging
from datetime import datetime

from django.http import StreamingHttpResponse
from rest_framework.exceptions import ValidationError
from rest_framework.views import APIView

from config.tenant_db import use_tenant_db

logger = logging.getLogger(__name__)

DEFAULT_EXPORT_MAX_ROWS = 100_000


class Echo:
    """File-like object that returns written values for StreamingHttpResponse CSV."""

    def write(self, value):
        return value


def csv_cell(value):
    if value is None:
        return ""
    return value


def csv_bool(value):
    if value is None:
        return ""
    return "true" if value else "false"


def csv_date(value):
    if value is None:
        return ""
    return value.isoformat() if hasattr(value, "isoformat") else str(value)


def csv_rounded(value, places=4):
    if value is None:
        return ""
    return round(float(value), places)


def csv_percentage(value, places=4):
    return csv_rounded(value, places)


def apply_ordering(
    queryset,
    request,
    allowed_fields,
    default_ordering,
    field_map=None,
    strict=False,
):
    """Apply comma-separated `ordering` query param, falling back to default_ordering."""
    field_map = field_map or {}
    ordering_param = request.query_params.get("ordering")
    if ordering_param:
        fields = []
        for field in ordering_param.split(","):
            field = field.strip()
            if not field:
                continue
            bare = field.lstrip("-")
            if bare in allowed_fields:
                mapped = field_map.get(bare, bare)
                fields.append(f"-{mapped}" if field.startswith("-") else mapped)
            elif strict:
                raise ValidationError({
                    "detail": (
                        "Invalid ordering. Allowed: "
                        f'{", ".join(sorted(allowed_fields))} (prefix with - for desc).'
                    )
                })
        if fields:
            return queryset.order_by(*fields)
    return queryset.order_by(*default_ordering)


def get_filtered_ordered_queryset(
    request,
    base_queryset,
    filterset_class,
    ordering_fields,
    default_ordering,
    ordering_field_map=None,
    strict_ordering=False,
):
    """
    Apply FilterSet + ordering for CSV export.
    Ignores limit/offset; pagination is never applied here.
    """
    queryset = base_queryset
    if filterset_class is not None:
        filterset = filterset_class(request.query_params, queryset=queryset)
        queryset = filterset.qs
    return apply_ordering(
        queryset,
        request,
        ordering_fields,
        default_ordering,
        ordering_field_map,
        strict_ordering,
    )


def enforce_export_row_cap(queryset, max_rows=DEFAULT_EXPORT_MAX_ROWS):
    """Reject exports larger than max_rows. Returns the matching count when under the cap."""
    total_count = queryset.count()
    if total_count > max_rows:
        raise ValidationError({
            "error": (
                f"Export exceeds the maximum of {max_rows:,} rows "
                f"({total_count:,} matching). Please narrow your filters and try again."
            )
        })
    return total_count


def enforce_export_row_cap_count(total_count, max_rows=DEFAULT_EXPORT_MAX_ROWS):
    """Reject in-memory exports larger than max_rows. Returns total_count when under the cap."""
    if total_count > max_rows:
        raise ValidationError({
            "error": (
                f"Export exceeds the maximum of {max_rows:,} rows "
                f"({total_count:,} matching). Please narrow your filters and try again."
            )
        })
    return total_count


def wrap_csv_rows_with_tenant(tenant, rows):
    """
    Re-bind the tenant DB for CSV row iteration.

    StreamingHttpResponse consumes the row generator after TenantDatabaseMiddleware
    clears the active tenant; wrap so queryset.iterator() still routes correctly.
    """
    if tenant is None:
        yield from rows
        return

    with use_tenant_db(tenant):
        yield from rows


def streaming_csv_response(rows, filename_prefix):
    """Stream CSV rows as an attachment download."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{filename_prefix}_{timestamp}.csv"
    pseudo_buffer = Echo()
    writer = csv.writer(pseudo_buffer)

    def generate():
        for row in rows:
            yield writer.writerow(row)

    response = StreamingHttpResponse(generate(), content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    response["X-Accel-Buffering"] = "no"
    return response


class CsvExportView(APIView):
    """
    Stream a filtered, unpaginated CSV export.
    Subclasses set filename_prefix, filterset_class, ordering, and row mapping.
    """

    filename_prefix = "export"
    filterset_class = None
    ordering_fields = []
    default_ordering = []
    ordering_field_map = {}
    strict_ordering = False
    max_rows = DEFAULT_EXPORT_MAX_ROWS

    def get_base_queryset(self, request):
        raise NotImplementedError

    def iter_csv_rows(self, queryset):
        raise NotImplementedError

    def get_filtered_queryset(self, request):
        return get_filtered_ordered_queryset(
            request,
            self.get_base_queryset(request),
            self.filterset_class,
            self.ordering_fields,
            self.default_ordering,
            self.ordering_field_map,
            self.strict_ordering,
        )

    def get(self, request):
        queryset = self.get_filtered_queryset(request)
        total_count = enforce_export_row_cap(queryset, self.max_rows)
        logger.info("Streaming CSV export %s (%s rows)", self.filename_prefix, total_count)
        tenant = getattr(request, "tenant", None)
        rows = self.iter_csv_rows(queryset)
        if tenant is not None:
            rows = wrap_csv_rows_with_tenant(tenant, rows)
        return streaming_csv_response(rows, self.filename_prefix)
