import csv
import logging
from datetime import datetime

from django.http import StreamingHttpResponse
from rest_framework.exceptions import ValidationError
from rest_framework.views import APIView

from api.csv_export_keyset import (
    HEADER_HAS_MORE,
    HEADER_NEXT_CURSOR,
    HEADER_PAGE_SIZE,
    HEADER_ROW_COUNT,
    HEADER_TRUNCATED,
    append_identity_ordering,
    canonical_ordering,
    export_filename,
    filter_fingerprint,
    parse_export_part,
    peek_page,
    queryset_order_by,
    sanitize_export_stem,
    seek_q,
    sign_cursor,
    tenant_cursor_id,
    unsign_cursor,
)
from config.tenant_db import use_tenant_db

logger = logging.getLogger(__name__)

DEFAULT_EXPORT_MAX_ROWS = 100_000
DEFAULT_EXPORT_PAGE_ROWS = DEFAULT_EXPORT_MAX_ROWS
DEFAULT_EXPORT_MAX_PAGES = 20
EXPORT_CEILING_ROWS = DEFAULT_EXPORT_PAGE_ROWS * DEFAULT_EXPORT_MAX_PAGES


class Echo:
    """File-like object that returns written values for StreamingHttpResponse CSV."""

    def write(self, value):
        return value


def csv_cell(value):
    if value is None:
        return ""
    return value


def csv_bool(value):
    if value is None:
        return ""
    return "true" if value else "false"


def csv_date(value):
    if value is None:
        return ""
    return value.isoformat() if hasattr(value, "isoformat") else str(value)


def csv_rounded(value, places=4):
    if value is None:
        return ""
    return round(float(value), places)


def csv_percentage(value, places=4):
    return csv_rounded(value, places)


def _append_tie_breakers(fields, tie_breaker_fields):
    ordered_fields = {field.lstrip("-") for field in fields}
    for tie_breaker_field in tie_breaker_fields:
        if tie_breaker_field.lstrip("-") not in ordered_fields:
            fields.append(tie_breaker_field)
            ordered_fields.add(tie_breaker_field.lstrip("-"))
    return fields


def apply_ordering(
    queryset,
    request,
    allowed_fields,
    default_ordering,
    field_map=None,
    tie_breaker_fields=None,
    strict=False,
):
    """Apply comma-separated `ordering` query param, falling back to default_ordering."""
    field_map = field_map or {}
    tie_breaker_fields = tie_breaker_fields or []
    ordering_param = request.query_params.get("ordering")
    if ordering_param:
        fields = []
        for field in ordering_param.split(","):
            field = field.strip()
            if not field:
                continue
            bare = field.lstrip("-")
            if bare in allowed_fields:
                mapped = field_map.get(bare, bare)
                fields.append(f"-{mapped}" if field.startswith("-") else mapped)
            elif strict:
                raise ValidationError({
                    "detail": (
                        "Invalid ordering. Allowed: "
                        f'{", ".join(sorted(allowed_fields))} (prefix with - for desc).'
                    )
                })
        if fields:
            return queryset.order_by(*_append_tie_breakers(fields, tie_breaker_fields))
    return queryset.order_by(*_append_tie_breakers(list(default_ordering), tie_breaker_fields))


def get_filtered_ordered_queryset(
    request,
    base_queryset,
    filterset_class,
    ordering_fields,
    default_ordering,
    ordering_field_map=None,
    ordering_tie_breakers=None,
    strict_ordering=False,
):
    """
    Apply FilterSet + ordering for CSV export.
    Ignores limit/offset; pagination is never applied here.
    """
    queryset = base_queryset
    if filterset_class is not None:
        filterset = filterset_class(request.query_params, queryset=queryset)
        queryset = filterset.qs
    return apply_ordering(
        queryset,
        request,
        ordering_fields,
        default_ordering,
        ordering_field_map,
        ordering_tie_breakers,
        strict_ordering,
    )


def enforce_export_row_cap(queryset, max_rows=DEFAULT_EXPORT_MAX_ROWS):
    """Reject exports larger than max_rows. Returns the matching count when under the cap."""
    total_count = queryset.count()
    if total_count > max_rows:
        raise ValidationError({
            "error": (
                f"Export exceeds the maximum of {max_rows:,} rows "
                f"({total_count:,} matching). Please narrow your filters and try again."
            )
        })
    return total_count


def enforce_export_row_cap_count(total_count, max_rows=DEFAULT_EXPORT_MAX_ROWS):
    """Reject in-memory exports larger than max_rows. Returns total_count when under the cap."""
    if total_count > max_rows:
        raise ValidationError({
            "error": (
                f"Export exceeds the maximum of {max_rows:,} rows "
                f"({total_count:,} matching). Please narrow your filters and try again."
            )
        })
    return total_count


def wrap_csv_rows_with_tenant(tenant, rows):
    """
    Re-bind the tenant DB for CSV row iteration.

    StreamingHttpResponse consumes the row generator after TenantDatabaseMiddleware
    clears the active tenant; wrap so queryset.iterator() still routes correctly.
    """
    if tenant is None:
        yield from rows
        return

    with use_tenant_db(tenant):
        yield from rows


def streaming_csv_response(rows, filename_prefix, filename=None):
    """Stream CSV rows as an attachment download with a UTF-8 BOM for Excel."""
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{filename_prefix}_{timestamp}.csv"
    pseudo_buffer = Echo()
    writer = csv.writer(pseudo_buffer)

    def generate():
        yield "\ufeff"
        for row in rows:
            yield writer.writerow(row)

    response = StreamingHttpResponse(generate(), content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    response["X-Accel-Buffering"] = "no"
    return response


def _export_ceiling_error():
    return ValidationError({
        "error": (
            f"Export exceeds the maximum of {EXPORT_CEILING_ROWS:,} rows. "
            "Please narrow your filters and try again."
        )
    })


def canonical_or_default_ordering(queryset, default_ordering, identity_fields):
    current = queryset_order_by(queryset)
    if current:
        return canonical_ordering(current, identity_fields)
    return canonical_ordering(list(default_ordering), identity_fields)


class CsvExportView(APIView):
    """
    Stream a filtered CSV export in keyset-paged parts of page_rows.

    Subclasses set filename_prefix, filterset_class, ordering, identity fields,
    and row mapping. Each response is one file; the client follows X-Export-Has-More.
    """

    filename_prefix = "export"
    filterset_class = None
    ordering_fields = []
    default_ordering = []
    ordering_field_map = {}
    ordering_tie_breakers = []
    export_identity_fields = []
    strict_ordering = False
    max_rows = DEFAULT_EXPORT_MAX_ROWS
    page_rows = DEFAULT_EXPORT_PAGE_ROWS
    max_pages = DEFAULT_EXPORT_MAX_PAGES

    def get_base_queryset(self, request):
        raise NotImplementedError

    def iter_csv_rows(self, queryset):
        raise NotImplementedError

    def get_tie_breakers(self):
        return _append_tie_breakers(
            list(self.ordering_tie_breakers),
            list(self.export_identity_fields),
        )

    def get_filtered_queryset(self, request):
        return get_filtered_ordered_queryset(
            request,
            self.get_base_queryset(request),
            self.filterset_class,
            self.ordering_fields,
            self.default_ordering,
            self.ordering_field_map,
            self.get_tie_breakers(),
            self.strict_ordering,
        )

    def get(self, request):
        identity = list(self.export_identity_fields)
        if not identity:
            raise ValidationError({
                "error": "CSV export is missing identity fields required for paging."
            })

        queryset = self.get_filtered_queryset(request)
        queryset = append_identity_ordering(queryset, identity)
        ordering = canonical_or_default_ordering(queryset, self.default_ordering, identity)
        cursor_fields = [field.lstrip("-") for field in ordering]
        filter_fp = filter_fingerprint(request.query_params)
        tenant = getattr(request, "tenant", None)
        tenant_id = tenant_cursor_id(tenant)

        cursor_token = request.query_params.get("export_cursor")
        decoded = unsign_cursor(
            cursor_token,
            ordering=ordering,
            filter_fp=filter_fp,
            tenant_id=tenant_id,
        )
        pages_completed = 0
        if decoded is not None:
            cursor_values, pages_completed = decoded
            queryset = queryset.filter(seek_q(ordering, cursor_values))

        page_number = pages_completed + 1
        if page_number > self.max_pages:
            raise _export_ceiling_error()

        has_more, last_values, row_count = peek_page(queryset, cursor_fields, self.page_rows)
        truncated = has_more and page_number >= self.max_pages
        if truncated:
            has_more = False

        stem = sanitize_export_stem(
            request.query_params.get("export_stem"),
            self.filename_prefix,
        )
        part = parse_export_part(request.query_params.get("export_part"), page_number)
        filename = export_filename(stem, part)

        logger.info(
            "Streaming CSV export %s part %s (%s rows, has_more=%s truncated=%s)",
            self.filename_prefix,
            part,
            row_count,
            has_more,
            truncated,
        )

        page_qs = queryset[: self.page_rows]
        rows = self.iter_csv_rows(page_qs)
        if tenant is not None:
            rows = wrap_csv_rows_with_tenant(tenant, rows)

        response = streaming_csv_response(rows, self.filename_prefix, filename=filename)
        response[HEADER_HAS_MORE] = "true" if has_more else "false"
        response[HEADER_ROW_COUNT] = str(row_count)
        response[HEADER_PAGE_SIZE] = str(self.page_rows)
        response[HEADER_TRUNCATED] = "true" if truncated else "false"
        if has_more and last_values is not None:
            response[HEADER_NEXT_CURSOR] = sign_cursor(
                ordering=ordering,
                values=last_values,
                filter_fp=filter_fp,
                tenant_id=tenant_id,
                pages_completed=page_number,
            )
        return response
