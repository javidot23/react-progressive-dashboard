"""Request-level audit trail.

Runs last in ``MIDDLEWARE`` so the response phase still sees the tenant bound by
``TenantDatabaseMiddleware``, and so writes land outside the view's
``ATOMIC_REQUESTS`` transaction and survive a view that raises.
"""

import logging
import time

logger = logging.getLogger(__name__)

DENIAL_STATUSES = frozenset({401, 403})
MUTATING_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})


class AuditLogMiddleware:
    """Record rejected requests as ``access_denied`` and mutations as ``api_request``.

    Denials are recorded for every method, since a refused read is as
    security-relevant as a refused write. Successful reads are not recorded: they
    carry no state change and would dominate the table on a read-heavy API.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        started = time.monotonic()
        response = self.get_response(request)
        try:
            self._record(request, response, started)
        except Exception:
            logger.exception(
                "Failed to write request audit log for %s %s",
                getattr(request, "method", ""),
                getattr(request, "path", ""),
            )
        return response

    def _record(self, request, response, started) -> None:
        from .services import AuditService  # noqa: PLC0415

        if getattr(response, "status_code", None) in DENIAL_STATUSES:
            AuditService.record_denial(request, response)
        elif request.method in MUTATING_METHODS:
            duration_ms = int((time.monotonic() - started) * 1000)
            AuditService.record_request(request, response, duration_ms=duration_ms)
