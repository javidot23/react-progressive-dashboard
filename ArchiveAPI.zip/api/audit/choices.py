from django.db import models


class AuditEventType(models.TextChoices):
    LOGIN_SUCCESS = "login_success", "Login success"
    LOGIN_FAILURE = "login_failure", "Login failure"
    LOGOUT = "logout", "Logout"
    ROLE_ASSIGNED = "role_assigned", "Role assigned"
    ROLE_REVOKED = "role_revoked", "Role revoked"
    PERMISSION_CHECKED = "permission_checked", "Permission checked"
    ACCESS_GRANTED = "access_granted", "Access granted"
    ACCESS_DENIED = "access_denied", "Access denied"
    TENANT_UPDATED = "tenant_updated", "Tenant updated"
    TENANT_SELECTED = "tenant_selected", "Tenant selected"
    USER_UPDATED = "user_updated", "User updated"
    ACTION_CREATED = "action_created", "Action created"
    ACTION_UPDATED = "action_updated", "Action updated"
    ACTION_DELETED = "action_deleted", "Action deleted"
    ISSUE_NOTE_CREATED = "issue_note_created", "Issue note created"
    ISSUE_NOTE_UPDATED = "issue_note_updated", "Issue note updated"
    ISSUE_NOTE_DELETED = "issue_note_deleted", "Issue note deleted"
    CUSTOM_LIST_CREATED = "custom_list_created", "Custom list created"
    CUSTOM_LIST_UPDATED = "custom_list_updated", "Custom list updated"
    CUSTOM_LIST_DELETED = "custom_list_deleted", "Custom list deleted"
    CUSTOM_LIST_ITEMS_SYNCED = "custom_list_items_synced", "Custom list items synced"
    USER_SETTING_UPDATED = "user_setting_updated", "User setting updated"
    USER_FEEDBACK_CREATED = "user_feedback_created", "User feedback created"
    USER_FEEDBACK_UPDATED = "user_feedback_updated", "User feedback updated"
    API_REQUEST = "api_request", "API request"


SOURCE_STRATIUM_API = "stratium_api"
