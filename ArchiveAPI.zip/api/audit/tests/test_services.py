from unittest.mock import MagicMock, patch

from django.test import RequestFactory, override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient

from api.audit.choices import SOURCE_STRATIUM_API, AuditEventType
from api.audit.services import AuditService
from tests.BaseTestCase import BaseAPITestCase, BaseTestCase
from tests.factories import add_domain, add_membership, create_admin_user
from tests.TestDataFactory import TestDataFactory


class AuditServiceTest(BaseTestCase):
    @patch("api.audit.services.AuditLog.objects.create")
    def test_record_calls_create_with_stratium_source(self, mock_create):
        user = create_admin_user()
        mock_create.return_value = MagicMock()

        AuditService.record(
            AuditEventType.LOGIN_SUCCESS,
            actor_user=user,
            metadata={"via": "unit"},
        )

        mock_create.assert_called_once()
        kwargs = mock_create.call_args.kwargs
        self.assertEqual(kwargs["audit_event_type"], AuditEventType.LOGIN_SUCCESS)
        self.assertEqual(kwargs["source"], SOURCE_STRATIUM_API)
        self.assertEqual(kwargs["actor_user"], user)
        self.assertEqual(kwargs["metadata"], {"via": "unit"})

    @patch("api.audit.services.AuditLog.objects.create", side_effect=RuntimeError("db down"))
    def test_record_swallows_failures(self, _mock_create):
        result = AuditService.record(AuditEventType.LOGIN_FAILURE)
        self.assertIsNone(result)

    @patch("api.audit.services.AuditLog.objects.create")
    def test_record_from_request_fills_context(self, mock_create):
        user = create_admin_user()
        factory = RequestFactory()
        request = factory.post("/api/tenant/active/")
        request.user = user
        request.tenant = self.test_tenant
        request.META["HTTP_X_REQUEST_ID"] = "req-1"
        request.META["REMOTE_ADDR"] = "127.0.0.1"
        mock_create.return_value = MagicMock()

        AuditService.record_from_request(
            request,
            AuditEventType.TENANT_SELECTED,
            status=200,
            target_entity={"type": "tenant", "id": str(self.test_tenant.pk)},
        )

        kwargs = mock_create.call_args.kwargs
        self.assertEqual(kwargs["audit_event_type"], AuditEventType.TENANT_SELECTED)
        self.assertEqual(kwargs["source"], SOURCE_STRATIUM_API)
        self.assertEqual(kwargs["actor_user"], user)
        self.assertEqual(kwargs["tenant"], self.test_tenant)
        self.assertEqual(kwargs["request_id"], "req-1")
        self.assertEqual(kwargs["source_ip"], "127.0.0.1")
        self.assertEqual(kwargs["action"]["method"], "POST")
        self.assertEqual(kwargs["action"]["status"], 200)
        self.assertEqual(kwargs["target_entity"]["type"], "tenant")


@override_settings(
    SAP_CDC_CLIENT_ID="test-client",
    SAP_CDC_ISSUER=None,
    SAP_CDC_METADATA_URL=None,
    SAP_CDC_JWKS_URI="https://sap.example.com/jwks",
    SAP_CDC_AUTHORIZE_URL="https://sap.example.com/authorize",
    SAP_CDC_TOKEN_URL="https://sap.example.com/token",
    SAP_CDC_USERINFO_URL="https://sap.example.com/userinfo",
    SAP_CDC_END_SESSION_URL="https://sap.example.com/logout",
    FRONTEND_URL="http://localhost:5173",
)
class AuditCallSiteTest(BaseAPITestCase):
    def setUp(self):
        super().setUp()
        self.client = APIClient()

    def _call_for(self, mock_record, event_type):
        """The one recorded call for ``event_type``.

        Views and AuditLogMiddleware share AuditService, so patching the classmethod
        catches the middleware's api_request entry alongside the view's own event.
        """
        matches = [c for c in mock_record.call_args_list if c.args[1] == event_type]
        self.assertEqual(len(matches), 1, f"expected exactly one {event_type} event, got {matches}")
        return matches[0]

    def _patch_oidc(self, claims, access_token="tok"):
        client = MagicMock()
        client.authorize_access_token.return_value = {
            "access_token": access_token,
            "id_token": "id.token.jwt",
            "userinfo": claims,
        }
        return patch("api.identity.views.get_oidc_client", return_value=("sap_cdc", client))

    @patch("api.identity.views.AuditService.record_from_request")
    def test_login_success_records_login_success(self, mock_record):
        claims = {
            "sub": "audit-login-sub",
            "email": "audit-login@test.com",
            "given_name": "Audit",
            "family_name": "Login",
        }
        with self._patch_oidc(claims), patch(
            "api.identity.views.UserService.get_user_profile_from_sap_cdc",
            return_value=None,
        ):
            response = self.client.get(
                reverse("identity:login") + "?code=abc&state=xyz",
                HTTP_X_DISABLE_TEST_AUTH="1",
            )

        self.assertEqual(response.status_code, status.HTTP_302_FOUND)
        event_types = [call.args[1] for call in mock_record.call_args_list]
        self.assertIn(AuditEventType.LOGIN_SUCCESS, event_types)

    @patch("api.identity.views.AuditService.record_from_request")
    def test_login_failure_records_login_failure(self, mock_record):
        claims = {
            "sub": "audit-fail-sub",
            "email": "bob@other.com",
            "given_name": "Bob",
            "family_name": "Smith",
        }
        with self._patch_oidc(claims), patch(
            "api.identity.views.UserService.get_user_profile_from_sap_cdc",
            return_value=None,
        ):
            response = self.client.get(
                reverse("identity:login") + "?code=abc&state=xyz",
                HTTP_X_DISABLE_TEST_AUTH="1",
            )

        self.assertEqual(response.status_code, status.HTTP_302_FOUND)
        self.assertIn("error=no_tenant_for_domain", response["Location"])
        mock_record.assert_called()
        self.assertEqual(mock_record.call_args.args[1], AuditEventType.LOGIN_FAILURE)

    @patch("api.tenant.views.AuditService.record_from_request")
    def test_set_active_tenant_records_tenant_selected(self, mock_record):
        user = create_admin_user(email="audit-tenant@example.com", subject="audit-tenant-sub")
        add_domain(self.test_tenant, "example.com")
        add_membership(user, self.test_tenant)
        self.client.force_authenticate(user=user)

        response = self.client.post(
            reverse("tenant:tenant-active"),
            {"tenant_uuid": str(self.test_tenant.pk)},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # The middleware also records api_request for the same call.
        selected = self._call_for(mock_record, AuditEventType.TENANT_SELECTED)
        self.assertEqual(selected.kwargs["target_entity"]["id"], str(self.test_tenant.pk))

    @patch("api.user_setting.views.AuditService.record_from_request")
    def test_user_setting_put_records_user_setting_updated(self, mock_record):
        user = TestDataFactory.create_test_user(email="audit-settings@example.com")
        self.client.force_authenticate(user=user, token="test-token")

        response = self.client.put(
            reverse("user_setting:my-settings"),
            {"inbound_service_level_target": 25, "products_omit_goal": 35},
            content_type="application/json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self._call_for(mock_record, AuditEventType.USER_SETTING_UPDATED)

    @patch("api.custom_lists.views.AuditService.record_from_request")
    def test_custom_list_create_records_custom_list_created(self, mock_record):
        user = TestDataFactory.create_test_user(
            entra_id="audit-list-user",
            email="audit-list@example.com",
        )
        self.client.force_authenticate(user=user)

        response = self.client.post(
            reverse("custom_lists:list-create"),
            {"name": "Audit List", "description": "for audit"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self._call_for(mock_record, AuditEventType.CUSTOM_LIST_CREATED)
