"""Request-level audit middleware behaviour."""

from __future__ import annotations

from unittest.mock import patch

from django.test import RequestFactory, SimpleTestCase
from rest_framework.response import Response

from api.audit.choices import AuditEventType
from api.audit.middleware import AuditLogMiddleware


class _Recorded:
    """Capture the events AuditService would have written."""

    def __init__(self):
        self.calls = []

    def __call__(self, request, event_type, **kwargs):
        self.calls.append((event_type, kwargs))
        return None

    @property
    def event_types(self):
        return [event for event, _ in self.calls]


class AuditLogMiddlewareTest(SimpleTestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.recorded = _Recorded()
        patcher = patch(
            "api.audit.services.AuditService.record_from_request",
            side_effect=self.recorded,
        )
        patcher.start()
        self.addCleanup(patcher.stop)

    def _run(self, request, status_code=200, data=None):
        def get_response(_req):
            response = Response(data or {}, status=status_code)
            response.status_code = status_code
            return response

        return AuditLogMiddleware(get_response)(request)

    # denials — always recorded, no settings flag, no new event type

    def test_403_is_recorded_as_access_denied(self):
        self._run(self.factory.get("/api/materials/"), status_code=403)
        self.assertEqual(self.recorded.event_types, [AuditEventType.ACCESS_DENIED])

    def test_401_is_recorded_as_access_denied(self):
        self._run(self.factory.get("/api/materials/"), status_code=401)
        self.assertEqual(self.recorded.event_types, [AuditEventType.ACCESS_DENIED])

    def test_denial_carries_the_error_code_as_reason(self):
        self._run(
            self.factory.get("/api/materials/"),
            status_code=403,
            data={"code": "tenant_required"},
        )
        _, kwargs = self.recorded.calls[0]
        self.assertEqual(kwargs["reason_code"], "tenant_required")
        self.assertEqual(kwargs["status"], 403)

    def test_denied_read_is_recorded(self):
        self._run(self.factory.get("/api/materials/"), status_code=403)
        self.assertEqual(self.recorded.event_types, [AuditEventType.ACCESS_DENIED])

    # api_request trail

    def test_mutation_is_recorded(self):
        self._run(self.factory.post("/api/actions/"), status_code=201)
        self.assertEqual(self.recorded.event_types, [AuditEventType.API_REQUEST])
        _, kwargs = self.recorded.calls[0]
        self.assertEqual(kwargs["status"], 201)
        self.assertIn("duration_ms", kwargs["action"])

    def test_successful_reads_are_not_recorded(self):
        self._run(self.factory.get("/api/materials/"), status_code=200)
        self.assertEqual(self.recorded.calls, [])

    def test_failed_mutations_are_still_recorded(self):
        self._run(self.factory.post("/api/actions/"), status_code=500)
        self.assertEqual(self.recorded.event_types, [AuditEventType.API_REQUEST])

    def test_a_denied_mutation_records_only_the_denial(self):
        self._run(self.factory.post("/api/actions/"), status_code=403)
        self.assertEqual(self.recorded.event_types, [AuditEventType.ACCESS_DENIED])

    # resilience

    def test_audit_failure_never_breaks_the_response(self):
        with patch(
            "api.audit.services.AuditService.record_request",
            side_effect=RuntimeError("core unreachable"),
        ):
            response = self._run(self.factory.post("/api/actions/"), status_code=201)
        self.assertEqual(response.status_code, 201)

    def test_view_exception_propagates(self):
        def get_response(_req):
            raise ValueError("boom")

        with self.assertRaises(ValueError):
            AuditLogMiddleware(get_response)(self.factory.post("/api/actions/"))


class AuditMiddlewareOrderingTest(SimpleTestCase):
    def test_audit_runs_inside_the_tenant_context(self):
        """Response-phase middleware runs bottom-up, so audit must sit below tenant."""
        from django.conf import settings

        middleware = list(settings.MIDDLEWARE)
        self.assertGreater(
            middleware.index("api.audit.middleware.AuditLogMiddleware"),
            middleware.index("api.tenant.middleware.TenantDatabaseMiddleware"),
        )
