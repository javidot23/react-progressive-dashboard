import uuid

from django.db import models

from .choices import AuditEventType


class AuditLog(models.Model):
    audit_log_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        "tenant.Tenant", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="audit_logs", db_column="tenant_uuid",
    )
    actor_user = models.ForeignKey(
        "user.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="audit_logs", db_column="actor_user_uuid",
    )
    audit_event_type = models.CharField(max_length=50, choices=AuditEventType.choices)
    trace_id = models.CharField(max_length=100, blank=True)
    source = models.CharField(max_length=100, blank=True)
    reason_code = models.CharField(max_length=100, blank=True)
    request_id = models.CharField(max_length=100, blank=True)
    source_ip = models.GenericIPAddressField(null=True, blank=True)
    target_entity = models.JSONField(default=dict, blank=True)
    action = models.JSONField(default=dict, blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    before_state = models.JSONField(default=dict, blank=True)
    after_state = models.JSONField(default=dict, blank=True)
    event_timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "audit_log"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(audit_event_type__in=AuditEventType.values), name="audit_log_event_type_valid"
            ),
        ]

    def __str__(self):
        return f"{self.audit_event_type} @ {self.event_timestamp}"
