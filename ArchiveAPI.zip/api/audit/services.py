import logging
from typing import Optional

from api.tenant.services import ACTIVE_TENANT_SESSION_KEY

from .choices import SOURCE_STRATIUM_API, AuditEventType
from .models import AuditLog

logger = logging.getLogger(__name__)


class AuditService:
    """Write path for the ``audit_log`` table (core DB)."""

    @staticmethod
    def record(
        audit_event_type: str,
        actor_user=None,
        tenant=None,
        *,
        source: str = SOURCE_STRATIUM_API,
        reason_code: str = "",
        request_id: str = "",
        trace_id: str = "",
        source_ip: Optional[str] = None,
        target_entity: Optional[dict] = None,
        action: Optional[dict] = None,
        metadata: Optional[dict] = None,
        before_state: Optional[dict] = None,
        after_state: Optional[dict] = None,
    ) -> Optional[AuditLog]:
        try:
            return AuditLog.objects.create(
                audit_event_type=audit_event_type,
                actor_user=actor_user,
                tenant=tenant,
                source=source,
                reason_code=reason_code,
                request_id=request_id,
                trace_id=trace_id,
                source_ip=source_ip,
                target_entity=target_entity or {},
                action=action or {},
                metadata=metadata or {},
                before_state=before_state or {},
                after_state=after_state or {},
            )
        except Exception:
            logger.exception("Failed to write audit log event=%s", audit_event_type)
            return None

    @staticmethod
    def _client_ip(request) -> Optional[str]:
        forwarded = request.META.get("HTTP_X_FORWARDED_FOR", "")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR")

    @staticmethod
    def _actor(request):
        actor = getattr(request, "user", None)
        if actor is None or not getattr(actor, "is_authenticated", False):
            return None
        if not hasattr(actor, "user_uuid") and not getattr(actor, "pk", None):
            return None
        return actor

    @staticmethod
    def _tenant(request):
        tenant = getattr(request, "tenant", None)
        if tenant is not None:
            return tenant
        session = getattr(request, "session", None)
        if not session:
            return None
        tenant_uuid = session.get(ACTIVE_TENANT_SESSION_KEY)
        if not tenant_uuid:
            return None
        from api.tenant.services import TenantService

        return TenantService.get_usable(tenant_uuid)

    @staticmethod
    def _reason_code_from_response(response) -> str:
        """Best-effort error code from a rendered DRF error body."""
        data = getattr(response, "data", None)
        if isinstance(data, dict):
            for key in ("code", "type"):
                value = data.get(key)
                if isinstance(value, str):
                    return value[:100]
        return ""

    @classmethod
    def record_request(cls, request, response, *, duration_ms: Optional[int] = None):
        """Record the request-level audit trail entry for ``request``."""
        action = {}
        if duration_ms is not None:
            action["duration_ms"] = duration_ms
        return cls.record_from_request(
            request,
            AuditEventType.API_REQUEST,
            status=getattr(response, "status_code", None),
            action=action,
        )

    @classmethod
    def record_denial(cls, request, response):
        """Record a rejected request (401/403) as an access denial."""
        return cls.record_from_request(
            request,
            AuditEventType.ACCESS_DENIED,
            reason_code=cls._reason_code_from_response(response),
            status=getattr(response, "status_code", None),
        )

    @classmethod
    def record_from_request(
        cls,
        request,
        audit_event_type: str,
        *,
        reason_code: str = "",
        target_entity: Optional[dict] = None,
        action: Optional[dict] = None,
        metadata: Optional[dict] = None,
        before_state: Optional[dict] = None,
        after_state: Optional[dict] = None,
        actor_user=None,
        tenant=None,
        status: Optional[int] = None,
    ) -> Optional[AuditLog]:
        action_payload = {
            "method": getattr(request, "method", ""),
            "path": getattr(request, "path", ""),
        }
        if status is not None:
            action_payload["status"] = status
        if action:
            action_payload.update(action)

        return cls.record(
            audit_event_type,
            actor_user=actor_user if actor_user is not None else cls._actor(request),
            tenant=tenant if tenant is not None else cls._tenant(request),
            source=SOURCE_STRATIUM_API,
            reason_code=reason_code,
            request_id=request.META.get("HTTP_X_REQUEST_ID", ""),
            trace_id=request.META.get("HTTP_X_TRACE_ID", ""),
            source_ip=cls._client_ip(request),
            target_entity=target_entity,
            action=action_payload,
            metadata=metadata,
            before_state=before_state,
            after_state=after_state,
        )
