from django.apps import AppConfig

from config.db_scope import DBScope


class AuditConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.audit'
    label = 'audit'
    db_scope = DBScope.CORE
