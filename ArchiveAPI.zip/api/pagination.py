from rest_framework.pagination import LimitOffsetPagination
from rest_framework.pagination import CursorPagination


class MaxLimitOffsetPagination(LimitOffsetPagination):
    default_limit = 1
    max_limit = 50


class Limit25OffsetPagination(MaxLimitOffsetPagination):
    """Limit/offset pagination for list endpoints that serve a full table page by default."""
    default_limit = 25


class PurchaseOrderCursorPagination(CursorPagination):
    page_size = 10
    max_page_size = 1000
    ordering = '-ordered_date'
