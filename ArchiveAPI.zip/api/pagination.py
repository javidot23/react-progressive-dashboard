from rest_framework.pagination import LimitOffsetPagination
from rest_framework.pagination import CursorPagination


class MaxLimitOffsetPagination(LimitOffsetPagination):
    default_limit = 1
    max_limit = 50


class PurchaseOrderCursorPagination(CursorPagination):
    page_size = 10
    max_page_size = 1000
    ordering = '-ordered_date'
