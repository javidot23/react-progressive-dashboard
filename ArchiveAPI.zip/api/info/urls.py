from django.urls import path

from .views import DiagnosticsAPIView, InfoAPIView, TableUpdateTimesAPIView

urlpatterns = [
    path('', InfoAPIView.as_view(), name='api_info'),
    path('diagnostics/', DiagnosticsAPIView.as_view(), name='api_diagnostics'),
    path('table-update-times/', TableUpdateTimesAPIView.as_view(), name='api_table_update_times'),
]
