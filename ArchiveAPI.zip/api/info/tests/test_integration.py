from django.urls import reverse
from rest_framework import status
from tests.BaseTestCase import BaseAPITestCase


class InfoIntegrationTestCase(BaseAPITestCase):
    def test_info_endpoint(self):
        """
        The public /info endpoint returns only version and environment.
        """
        url = reverse('api_info')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('version', response.data)
        self.assertIn('environment', response.data)
        self.assertNotIn('database_schema', response.data)

    def test_info_endpoint_is_public(self):
        """The public /info endpoint is reachable without authentication."""
        url = reverse('api_info')
        response = self.client.get(url, HTTP_X_DISABLE_TEST_AUTH='1')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_diagnostics_endpoint_returns_details_when_authenticated(self):
        """The diagnostics endpoint exposes infrastructure details to authenticated callers."""
        url = reverse('api_diagnostics')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('database_schema', response.data)
        self.assertIn('redis_connection', response.data)
        self.assertIn('neo4j_connection', response.data)
        self.assertIn('cache_backend', response.data)

    def test_diagnostics_endpoint_requires_authentication(self):
        """The diagnostics endpoint rejects unauthenticated requests."""
        url = reverse('api_diagnostics')
        response = self.client.get(url, HTTP_X_DISABLE_TEST_AUTH='1')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
