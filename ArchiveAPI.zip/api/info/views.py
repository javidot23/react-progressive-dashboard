import os

from django.conf import settings
from django.db import transaction
from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache, cache_page
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema, extend_schema_view

from api.neo4j_graph_api.connection import Neo4jConnection
from api.info.serializers import (
    DiagnosticsResponseSerializer,
    InfoResponseSerializer,
    TableUpdateTimesResponseSerializer,
)
from config.db_scope import CORE_DB_ALIAS
from config.tenant_db import get_tenant_connection


@method_decorator(never_cache, name='get')
@method_decorator(transaction.non_atomic_requests, name='dispatch')
@extend_schema_view(
    get=extend_schema(responses=InfoResponseSerializer),
)
class InfoAPIView(APIView):
    """Public liveness probe — API version and environment only, no DB transaction."""

    authentication_classes = []
    permission_classes = []

    def get(self, request):
        return Response({
            "version": os.environ.get("API_VERSION"),
            "environment": os.environ.get("API_ENV"),
        })


@method_decorator(never_cache, name='get')
@extend_schema_view(
    get=extend_schema(responses=DiagnosticsResponseSerializer),
)
class DiagnosticsAPIView(APIView):
    """Authenticated diagnostics — database schema and cache/redis/neo4j status."""

    def get(self, request):
        schema_name = None
        if CORE_DB_ALIAS in settings.DATABASES:
            options = settings.DATABASES[CORE_DB_ALIAS].get("OPTIONS", {})
            search_path = options.get("options", "")
            if "search_path=" in search_path:
                schema_name = search_path.split("search_path=")[1]

        redis_status = self._get_redis_status()
        neo4j_status = self._get_neo4j_status()
        cache_info = self._get_cache_info()

        return Response({
            "version": os.environ.get("API_VERSION"),
            "environment": os.environ.get("API_ENV"),
            "database_schema": schema_name,
            "redis_enabled": redis_status['enabled'],
            "redis_connection": redis_status['connection'],
            "neo4j_enabled": neo4j_status['enabled'],
            "neo4j_connection": neo4j_status['connection'],
            "cache_backend": cache_info['backend'],
            "cache_ttl_seconds": cache_info['ttl'],
            "cache_key_prefix": cache_info['key_prefix'],
        })

    def _get_redis_status(self):
        """Check if Redis is enabled and accessible."""
        cache_backend = settings.CACHES['default']['BACKEND']

        if 'redis' not in cache_backend.lower():
            return {'enabled': False, 'connection': 'N/A'}

        try:
            # Test Redis connection
            cache.set('health_check', 'ok', 30)
            test_value = cache.get('health_check')
            cache.delete('health_check')

            return {
                'enabled': True,
                'connection': 'connected' if test_value == 'ok' else 'error'
            }
        except Exception:
            return {'enabled': True, 'connection': 'error'}

    def _get_neo4j_status(self):
        """Check if Neo4j is enabled and accessible."""
        neo4j_uri = getattr(settings, 'NEO4J_URI', None)

        if not neo4j_uri:
            return {'enabled': False, 'connection': 'N/A'}

        try:
            is_connected = Neo4jConnection.is_connected()
            return {
                'enabled': True,
                'connection': 'connected' if is_connected else 'error'
            }
        except Exception:
            return {'enabled': True, 'connection': 'error'}

    def _get_cache_info(self):
        """Get cache configuration details."""
        cache_config = settings.CACHES['default']

        # Get default timeout from cache config
        default_timeout = cache_config.get('TIMEOUT', 300)

        return {
            'backend': cache_config['BACKEND'].split('.')[-1],
            'ttl': default_timeout,
            'key_prefix': getattr(settings, 'CACHE_MIDDLEWARE_KEY_PREFIX', 'N/A'),
        }


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
@extend_schema_view(
    get=extend_schema(responses=TableUpdateTimesResponseSerializer),
)
class TableUpdateTimesAPIView(APIView):
    def get(self, request):
        table_names = {
            'actions': 'actions',
            'customer_business_units': 'customer_business_units',
            'customer_companies': 'customer_companies',
            'customer_corp_chains': 'customer_corp_chains',
            'customer_locations': 'customer_locations',
            'customers': 'customers',
            'demand_forecast': 'demand_forecast',
            'inbound_service_level': 'inbound_service_level',
            'issue': 'issue',
            'material_formularies': 'material_formularies',
            'material_risks': 'material_risks',
            'material_substitutes': 'material_substitutes',
            'materials': 'materials',
            'order_transactions': 'order_transactions',
            'order_transactions_aggregated': 'order_transactions_aggregated',
            'plants': 'plants',
            'potential_action': 'potential_action',
            'purchase_orders': 'purchase_orders',
            'vendors': 'vendors',
        }

        result = {}
        connection = get_tenant_connection()
        with connection.cursor() as cursor:
            for table_name, db_table in table_names.items():
                try:
                    quoted_table = connection.ops.quote_name(db_table)
                    cursor.execute(
                        f'SELECT updated_at FROM {quoted_table} ORDER BY updated_at DESC LIMIT 1'
                    )
                    row = cursor.fetchone()

                    if row and row[0]:
                        # Convert datetime to ISO format string
                        result[table_name] = row[0].isoformat()
                    else:
                        result[table_name] = None
                except Exception:
                    # If there's an error (e.g., table doesn't exist, no records), return None
                    result[table_name] = None

        return Response(result)
