from rest_framework import serializers


class InfoResponseSerializer(serializers.Serializer):
    version = serializers.CharField(allow_null=True)
    environment = serializers.CharField(allow_null=True)


class DiagnosticsResponseSerializer(serializers.Serializer):
    version = serializers.CharField(allow_null=True)
    environment = serializers.CharField(allow_null=True)
    database_schema = serializers.CharField(allow_null=True)
    redis_enabled = serializers.BooleanField()
    redis_connection = serializers.CharField()
    neo4j_enabled = serializers.BooleanField()
    neo4j_connection = serializers.CharField()
    cache_backend = serializers.CharField()
    cache_backend_timeout_seconds = serializers.IntegerField()
    cache_middleware_seconds = serializers.IntegerField()
    cache_ttl_seconds = serializers.IntegerField()
    cache_key_prefix = serializers.CharField()


class TableUpdateTimesResponseSerializer(serializers.Serializer):
    actions = serializers.CharField(allow_null=True)
    customer_business_units = serializers.CharField(allow_null=True)
    customer_companies = serializers.CharField(allow_null=True)
    customer_corp_chains = serializers.CharField(allow_null=True)
    customer_locations = serializers.CharField(allow_null=True)
    customers = serializers.CharField(allow_null=True)
    demand_forecast = serializers.CharField(allow_null=True)
    inbound_service_level = serializers.CharField(allow_null=True)
    issue = serializers.CharField(allow_null=True)
    material_formularies = serializers.CharField(allow_null=True)
    material_risks = serializers.CharField(allow_null=True)
    material_substitutes = serializers.CharField(allow_null=True)
    materials = serializers.CharField(allow_null=True)
    order_transactions = serializers.CharField(allow_null=True)
    order_transactions_aggregated = serializers.CharField(allow_null=True)
    plants = serializers.CharField(allow_null=True)
    potential_action = serializers.CharField(allow_null=True)
    purchase_orders = serializers.CharField(allow_null=True)
    vendors = serializers.CharField(allow_null=True)
