from django.apps import AppConfig


class IssueNoteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.issue_note'
