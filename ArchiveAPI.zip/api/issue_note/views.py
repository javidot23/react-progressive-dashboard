import logging
from typing import Any, Dict

from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, status
from rest_framework.exceptions import (
    NotFound,
    PermissionDenied,
    ValidationError,
)
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema, extend_schema_view

from api.audit.choices import AuditEventType
from api.audit.services import AuditService
from api.issue_note.models import IssueNote
from api.issue_note.serializers import (
    IssueNoteCreateSerializer,
    IssueNoteSerializer,
    IssueNoteUpdateSerializer,
)
from api.issue_note.services import IssueNoteService
from api.pagination import MaxLimitOffsetPagination

from .filters import IssueNoteFilter

logger = logging.getLogger(__name__)


def _extract_user_data(request) -> Dict[str, Any]:
    """Build a snapshot of the authenticated user suitable for storing on a note."""
    user = request.user
    data: Dict[str, Any] = {}

    first_name = getattr(user, "first_name", None)
    last_name = getattr(user, "last_name", None)
    email = getattr(user, "email", None)
    role = getattr(user, "job_title", None)
    if first_name:
        data["first_name"] = first_name
    if last_name:
        data["last_name"] = last_name
    if email:
        data["email"] = email
    if role:
        data["role"] = role

    return data


class IssueNoteListCreateView(generics.ListCreateAPIView):
    """
    List notes on an issue (paginated, newest first) and create a new note.

    Routes:
        GET  /notes/<issue_id>/notes/
        POST /notes/<issue_id>/notes/

    Override sort with ``?ordering=created_at`` when oldest-first is needed.
    """

    serializer_class = IssueNoteSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = IssueNoteFilter
    ordering_fields = ["created_at", "updated_at", "id"]
    ordering = ["-created_at"]

    def initial(self, request, *args, **kwargs):
        super().initial(request, *args, **kwargs)
        self._get_user_id(request)

    def _get_user_id(self, request) -> str:
        user_id = str(getattr(request.user, "pk", "") or "")
        if not user_id:
            logger.warning("Unauthorized access to IssueNoteListCreateView")
            raise PermissionDenied
        return user_id

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return IssueNote.objects.none()
        return IssueNoteService.get_notes_for_issue(self.kwargs["issue_id"])

    def get_serializer_class(self):
        if self.request.method == "POST":
            return IssueNoteCreateSerializer
        return IssueNoteSerializer

    def create(self, request, *args, **kwargs):
        user_id = str(request.user.pk)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user_data = _extract_user_data(request)

        try:
            note = IssueNoteService.create_note(
                issue_id=self.kwargs["issue_id"],
                user_id=user_id,
                content=serializer.validated_data["content"],
                user_data=user_data,
            )
        except PermissionError as exc:
            logger.warning("Permission denied creating issue note: %s", str(exc))
            raise PermissionDenied(
                "You do not have permission to create notes for this issue."
            ) from exc
        except ValueError as exc:
            logger.warning("Validation error creating issue note: %s", str(exc))
            raise ValidationError(
                {"error": "Invalid request while creating issue note."},
                code="invalid_request",
            ) from exc

        AuditService.record_from_request(
            request,
            AuditEventType.ISSUE_NOTE_CREATED,
            status=status.HTTP_201_CREATED,
            target_entity={"type": "issue_note", "id": str(note.id)},
            action={"issue_id": self.kwargs["issue_id"]},
        )
        out = IssueNoteSerializer(
            note,
            context={"request": request},
        )
        return Response(out.data, status=status.HTTP_201_CREATED)


@extend_schema_view(
    get=extend_schema(responses=IssueNoteSerializer),
    patch=extend_schema(
        request=IssueNoteUpdateSerializer,
        responses=IssueNoteSerializer,
    ),
    delete=extend_schema(responses={204: None}),
)
class IssueNoteDetailView(APIView):
    """
    Retrieve, edit (PATCH) or delete (DELETE) a single note.

    Routes:
        GET    /notes/<id>/
        PATCH  /notes/<id>/
        DELETE /notes/<id>/
    """

    def _get_user_id(self, request) -> str:
        user_id = str(getattr(request.user, "pk", "") or "")
        if not user_id:
            logger.warning("Unauthorized access to IssueNoteDetailView")
            raise PermissionDenied
        return user_id

    def _serialize(self, request, note: IssueNote) -> Dict[str, Any]:
        serializer = IssueNoteSerializer(
            note,
            context={"request": request},
        )
        return serializer.data

    def get(self, request, id: int):
        self._get_user_id(request)
        try:
            note = IssueNoteService.get_note(id)
        except ValueError:
            raise NotFound({"error": "Issue note not found"})
        return Response(self._serialize(request, note))

    def patch(self, request, id: int):
        user_id = self._get_user_id(request)

        in_serializer = IssueNoteUpdateSerializer(data=request.data)
        in_serializer.is_valid(raise_exception=True)

        try:
            note = IssueNoteService.update_note(
                note_id=id,
                user_id=user_id,
                content=in_serializer.validated_data["content"],
            )
        except PermissionError as exc:
            logger.warning("Permission denied updating issue note %s: %s", id, str(exc))
            raise PermissionDenied("You do not have permission to update this issue note.") from exc
        except ValueError as exc:
            logger.warning("Issue note %s not found during update: %s", id, str(exc))
            raise NotFound({"error": "Issue note not found"}) from exc

        AuditService.record_from_request(
            request,
            AuditEventType.ISSUE_NOTE_UPDATED,
            status=status.HTTP_200_OK,
            target_entity={"type": "issue_note", "id": str(note.id)},
        )
        return Response(self._serialize(request, note))

    def delete(self, request, id: int):
        user_id = self._get_user_id(request)

        try:
            IssueNoteService.delete_note(note_id=id, user_id=user_id)
        except PermissionError as exc:
            logger.warning("Permission denied deleting issue note %s: %s", id, str(exc))
            raise PermissionDenied("You do not have permission to delete this issue note.") from exc
        except ValueError as exc:
            logger.warning("Issue note %s not found during delete: %s", id, str(exc))
            raise NotFound({"error": "Issue note not found"}) from exc

        AuditService.record_from_request(
            request,
            AuditEventType.ISSUE_NOTE_DELETED,
            status=status.HTTP_204_NO_CONTENT,
            target_entity={"type": "issue_note", "id": str(id)},
        )
        return Response(status=status.HTTP_204_NO_CONTENT)
