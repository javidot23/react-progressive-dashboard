from django.urls import path

from api.issue_note.views import IssueNoteDetailView, IssueNoteListCreateView

app_name = "issue_note"

urlpatterns = [
    path("<int:issue_id>/notes/", IssueNoteListCreateView.as_view(), name="issue-notes"),
    path("<int:id>/", IssueNoteDetailView.as_view(), name="note-detail"),
]
