from django_filters.rest_framework import FilterSet, filters

from api.issue_note.models import IssueNote


class IssueNoteFilter(FilterSet):
    """Query filters for notes on an issue (issue scope is enforced in the view)."""

    content = filters.CharFilter(lookup_expr="icontains")
    user_id = filters.CharFilter(field_name="user_id", lookup_expr="exact")
    created_at_after = filters.DateTimeFilter(field_name="created_at", lookup_expr="gte")
    created_at_before = filters.DateTimeFilter(field_name="created_at", lookup_expr="lte")

    class Meta:
        model = IssueNote
        fields = []
