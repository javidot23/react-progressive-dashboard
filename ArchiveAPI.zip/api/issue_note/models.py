from django.db import models

from api.issue.models import Issue


class IssueNote(models.Model):
    """Flat notes attached to an Issue."""

    issue = models.ForeignKey(
        Issue,
        on_delete=models.CASCADE,
        related_name="notes",
        verbose_name="Issue",
    )
    issue_nbr = models.CharField(max_length=255, verbose_name="Issue Number")
    mat_nbr = models.CharField(max_length=255, verbose_name="Material Number", null=True, blank=True)

    content = models.TextField(verbose_name="Content")

    user_id = models.CharField(max_length=255, verbose_name="User ID")
    user_data = models.JSONField(
        default=dict,
        blank=True,
        verbose_name="User Data",
        help_text="Snapshot of author identity (first_name, last_name, email, job_title).",
    )

    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Updated At")

    class Meta:
        db_table = "issue_note"
        app_label = "issue_note"
        verbose_name = "Issue Note"
        verbose_name_plural = "Issue Notes"
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["issue", "created_at"]),
            models.Index(fields=["issue_nbr", "mat_nbr"]),
            models.Index(fields=["user_id"]),
        ]

    def __str__(self):
        return f"IssueNote(id={self.pk}, issue_id={self.issue_id}, user_id={self.user_id})"

    def save(self, *args, **kwargs):
        if self.issue_id:
            if not self.issue_nbr:
                self.issue_nbr = self.issue.issue_nbr
            if not self.mat_nbr and self.issue.material_id:
                self.mat_nbr = self.issue.material.mat_nbr
        super().save(*args, **kwargs)
