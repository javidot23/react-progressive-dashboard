import logging
from typing import Any, Dict, Iterable, Optional

from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import QuerySet

from api.issue.models import Issue
from api.issue_note.models import IssueNote

logger = logging.getLogger(__name__)


class IssueNoteService:
    """
    Service layer for IssueNote.

    Owns all business logic, validation, and permission enforcement so that
    views stay thin and tests can target the logic directly.
    """

    @classmethod
    def create_note(
        cls,
        issue_id: int,
        user_id: str,
        content: str,
        user_data: Optional[Dict[str, Any]] = None,
    ) -> IssueNote:
        """
        Create a new note on an issue.

        Raises:
            ValueError: if the issue does not exist or content is blank.
        """
        if not user_id:
            raise PermissionError("User not authenticated")
        if content is None or not str(content).strip():
            raise ValueError("Content is required")

        try:
            issue = Issue.objects.get(pk=issue_id)
        except Issue.DoesNotExist as exc:
            raise ValueError(f"Issue {issue_id} not found") from exc

        with transaction.atomic():
            note = IssueNote.objects.create(
                issue=issue,
                content=content,
                user_id=user_id,
                user_data=user_data or {},
            )

        logger.info(
            "Created issue note %s on issue %s by user %s",
            note.pk, issue.pk, user_id,
        )
        return note

    @classmethod
    def update_note(cls, note_id: int, user_id: str, content: str) -> IssueNote:
        """Edit a note's content. Only the author may edit."""
        if not user_id:
            raise PermissionError("User not authenticated")
        if content is None or not str(content).strip():
            raise ValueError("Content is required")

        try:
            note = IssueNote.objects.get(pk=note_id)
        except IssueNote.DoesNotExist as exc:
            raise ValueError("Note not found") from exc

        if note.user_id != user_id:
            raise PermissionError("You can only edit your own notes")

        note.content = content
        note.save(update_fields=["content", "updated_at"])

        logger.info("Updated issue note %s by user %s", note.pk, user_id)
        return note

    @classmethod
    def delete_note(cls, note_id: int, user_id: str) -> None:
        """Hard-delete a note. Only the author may delete."""
        if not user_id:
            raise PermissionError("User not authenticated")

        try:
            note = IssueNote.objects.get(pk=note_id)
        except IssueNote.DoesNotExist as exc:
            raise ValueError("Note not found") from exc

        if note.user_id != user_id:
            raise PermissionError("You can only delete your own notes")

        deleted_pk = note.pk
        note.delete()

        logger.info("Deleted issue note %s by user %s", deleted_pk, user_id)

    @classmethod
    def get_notes_for_issue(cls, issue_id: int) -> QuerySet:
        """Return all notes for an issue with the most recently created first."""
        return IssueNote.objects.filter(issue_id=issue_id).order_by("-created_at")

    @classmethod
    def get_note(cls, note_id: int) -> IssueNote:
        try:
            return IssueNote.objects.get(pk=note_id)
        except IssueNote.DoesNotExist as exc:
            raise ValueError("Note not found") from exc

    @classmethod
    def get_user_cache_for_notes(
        cls,
        notes: Iterable[IssueNote],
    ) -> Dict[str, Dict[str, Any]]:
        """
        Bulk-load user records for a batch of notes to avoid N+1 queries when
        serializing.
        """
        all_user_ids = {note.user_id for note in notes if getattr(note, "user_id", None)}

        if not all_user_ids:
            return {}

        users = get_user_model().objects.only(
            "user_uuid", "first_name", "last_name"
        ).filter(user_uuid__in=all_user_ids)
        user_cache = {
            str(user.pk): {
                "id": str(user.pk),
                "first_name": user.first_name,
                "last_name": user.last_name,
                "email": user.email,
            }
            for user in users
        }

        logger.debug("Built user cache for %s users (notes)", len(user_cache))
        return user_cache
