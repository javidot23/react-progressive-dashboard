from rest_framework import serializers

from api.issue_note.models import IssueNote


class IssueNoteCreateSerializer(serializers.Serializer):
    """Validates payload for creating a note."""

    content = serializers.CharField(
        allow_blank=False,
        trim_whitespace=True,
        help_text="Body of the note. Must be non-empty.",
    )


class IssueNoteUpdateSerializer(serializers.Serializer):
    """Validates payload for editing a note."""

    content = serializers.CharField(
        allow_blank=False,
        trim_whitespace=True,
        help_text="New body of the note. Must be non-empty.",
    )


class IssueNoteSerializer(serializers.ModelSerializer):
    """Read serializer for a note."""

    issue_id = serializers.IntegerField(read_only=True)
    is_my_note = serializers.SerializerMethodField()

    class Meta:
        model = IssueNote
        fields = [
            "id",
            "issue_id",
            "issue_nbr",
            "mat_nbr",
            "content",
            "user_id",
            "user_data",
            "is_my_note",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_is_my_note(self, obj: IssueNote) -> bool:
        request = self.context.get("request")
        if request and getattr(request.user, "pk", None) is not None:
            return obj.user_id == str(request.user.pk)
        return False
