from rest_framework import serializers


class WeeklyScanHistorySerializer(serializers.Serializer):
    week_start = serializers.DateTimeField()
    total_scans = serializers.IntegerField()
    successful_scans = serializers.IntegerField()
    success_rate = serializers.FloatField()

    class Meta:
        ref_name = 'InboundWeeklyScanHistory'


class ScanKpisSerializer(serializers.Serializer):
    total_scans = serializers.IntegerField()
    successful_scans = serializers.IntegerField()
    unsuccessful_scans = serializers.IntegerField()


class MaterialEpcisKpisSerializer(serializers.Serializer):
    total_mat_count = serializers.IntegerField()
    total_wee_mat_count = serializers.IntegerField()
    total_mats_received_count = serializers.IntegerField()
    materials_with_epcis = serializers.IntegerField()
    materials_without_epcis = serializers.IntegerField()
    epcis_coverage_pct = serializers.FloatField()


class MaterialEpcisWeeklyTrendSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    total_materials = serializers.IntegerField()
    materials_with_epcis = serializers.IntegerField()
    materials_without_epcis = serializers.IntegerField()
    epcis_coverage_pct = serializers.FloatField()


class ReceivedQtyEpcisKpisSerializer(serializers.Serializer):
    total_received_qty = serializers.IntegerField()
    total_lines = serializers.IntegerField()
    lines_with_epcis = serializers.IntegerField()
    lines_with_issues = serializers.IntegerField()
    lines_without_data = serializers.IntegerField()
    epcis_coverage_pct = serializers.FloatField()
    epcis_coverage_pct_last_week = serializers.FloatField()
    epcis_coverage_pct_change = serializers.FloatField(allow_null=True)


class ReceivedQtyEpcisWeeklyTrendSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    total_received_qty = serializers.IntegerField()
    total_lines = serializers.IntegerField()
    lines_with_epcis = serializers.IntegerField()
    lines_with_issues = serializers.IntegerField()
    lines_without_data = serializers.IntegerField()
    epcis_coverage_pct = serializers.FloatField()


class FailedPurchaseOrderSerializer(serializers.Serializer):
    purchase_order_number = serializers.CharField(source="req_po_nbr", allow_null=True)
    total_failed_scans = serializers.IntegerField()
    lot_expiration_errors = serializers.IntegerField()
    expiration_errors = serializers.IntegerField()
    sgtin_not_found_errors = serializers.IntegerField()
    null_failure_errors = serializers.IntegerField()
    expired_product_errors = serializers.IntegerField()
    wrong_dated_scan_errors = serializers.IntegerField()
    lot_errors = serializers.IntegerField()
    missing_gtin_errors = serializers.IntegerField()


class FailedScanSerializer(serializers.Serializer):
    purchase_order_number = serializers.CharField(source="req_po_nbr", allow_null=True)
    material_number = serializers.CharField(source="material.mat_nbr", allow_null=True)
    ndc = serializers.CharField(source="material.ndc", allow_null=True)
    material_name = serializers.CharField(source="material.name", allow_null=True)
    scan_date = serializers.DateTimeField(source="req_created_date", allow_null=True)
    sgtin = serializers.CharField(source="req_epc_cd", allow_null=True)
    is_sgtin_error = serializers.BooleanField()
    is_lot_error = serializers.BooleanField()
    is_expiration_error = serializers.BooleanField()
