from django_filters import CharFilter, NumberFilter
from django_filters.rest_framework import FilterSet

from .models import InboundSerializationScan


def _min_max_filters(field_name):
    return (
        NumberFilter(field_name=field_name, lookup_expr="gte"),
        NumberFilter(field_name=field_name, lookup_expr="lte"),
    )


class FailedPurchaseOrderFilter(FilterSet):
    """
    Filters on aggregated failed-scan counts per purchase order (annotated fields).
    """

    req_po_nbr = CharFilter(field_name="req_po_nbr", lookup_expr="icontains")

    total_failed_scans_min, total_failed_scans_max = _min_max_filters("total_failed_scans")
    lot_expiration_errors_min, lot_expiration_errors_max = _min_max_filters("lot_expiration_errors")
    expiration_errors_min, expiration_errors_max = _min_max_filters("expiration_errors")
    sgtin_not_found_errors_min, sgtin_not_found_errors_max = _min_max_filters("sgtin_not_found_errors")
    null_failure_errors_min, null_failure_errors_max = _min_max_filters("null_failure_errors")
    expired_product_errors_min, expired_product_errors_max = _min_max_filters("expired_product_errors")
    wrong_dated_scan_errors_min, wrong_dated_scan_errors_max = _min_max_filters("wrong_dated_scan_errors")
    lot_errors_min, lot_errors_max = _min_max_filters("lot_errors")
    missing_gtin_errors_min, missing_gtin_errors_max = _min_max_filters("missing_gtin_errors")

    class Meta:
        model = InboundSerializationScan
        fields = []
