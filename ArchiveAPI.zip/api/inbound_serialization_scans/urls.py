from django.urls import path

from .views import (
    FailedPurchaseOrderListView,
    FailedPurchaseOrderListExportView,
    FailedScanListView,
    MaterialEpcisKpisView,
    MaterialEpcisWeeklyTrendView,
    ReceivedQtyEpcisKpisView,
    ReceivedQtyEpcisWeeklyTrendView,
    ScanKpisView,
    WeeklyScanHistoryView,
)

app_name = "inbound_serialization_scans"

urlpatterns = [
    path("kpis/", ScanKpisView.as_view(), name="kpis"),
    path("weekly-history/", WeeklyScanHistoryView.as_view(), name="weekly-history"),
    path("failed-purchase-orders/export/", FailedPurchaseOrderListExportView.as_view(),
         name="failed-purchase-orders-export"),
    path("failed-purchase-orders/", FailedPurchaseOrderListView.as_view(), name="failed-purchase-orders"),
    path("failed-scans/", FailedScanListView.as_view(), name="failed-scans"),
    path("material-epcis-kpis/", MaterialEpcisKpisView.as_view(), name="material-epcis-kpis"),
    path("material-epcis-weekly-trend/", MaterialEpcisWeeklyTrendView.as_view(), name="material-epcis-weekly-trend"),
    path("received-qty-epcis-kpis/", ReceivedQtyEpcisKpisView.as_view(), name="received-qty-epcis-kpis"),
    path("received-qty-epcis-weekly-trend/", ReceivedQtyEpcisWeeklyTrendView.as_view(),
         name="received-qty-epcis-weekly-trend"),
]
