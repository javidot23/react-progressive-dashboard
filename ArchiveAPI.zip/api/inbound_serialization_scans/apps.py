from django.apps import AppConfig


class InboundSerializationScansConfig(AppConfig):
    name = 'api.inbound_serialization_scans'
