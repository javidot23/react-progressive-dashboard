import logging
from datetime import date, timedelta

from django.db.models import (
    BooleanField,
    Case,
    Count,
    Exists,
    ExpressionWrapper,
    F,
    FloatField,
    OuterRef,
    Q,
    Sum,
    Value,
    When,
)
from django.db.models.functions import Coalesce, NullIf, TruncWeek

from api.date_bounds import iso_week_bounds
from api.material.models import Material
from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV
from .models import InboundSerializationScan

# scan_status values that map to the failed-scans table boolean columns.
SGTIN_ERROR_STATUSES = ("SGTIN Not Found",)
LOT_ERROR_STATUSES = ("Lot Error", "Lot & Expiration Error")
EXPIRATION_ERROR_STATUSES = ("Expiration Error", "Lot & Expiration Error")

logger = logging.getLogger(__name__)


class InboundSerializationScanService:

    @staticmethod
    def get_weekly_scan_history(days: int = 90, direct_mat_nbr: str = None, mat_nbr_subquery=None):
        since = date.today() - timedelta(days=days)
        logger.info("Retrieving weekly scan history for last %d days (since %s)", days, since)
        qs = InboundSerializationScan.objects.filter(req_created_date__date__gte=since).exclude(
            req_request_type='0007', req_mode_of_entry='I', req_event_type='I'
        )
        if direct_mat_nbr:
            qs = qs.filter(material=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__in=mat_nbr_subquery)
        return (
            qs
            .annotate(week_start=TruncWeek("req_created_date"))
            .values("week_start")
            .annotate(
                total_scans=Count("req_epc_cd", distinct=True, filter=Q(resp_error_cd_to_dc__in=["0000", "2015"])),
                successful_scans=Count("req_epc_cd", distinct=True, filter=Q(resp_error_cd_to_dc="0000")),
            )
            .annotate(
                success_rate=Coalesce(
                    ExpressionWrapper(
                        F("successful_scans") * 100.0 / NullIf(F("total_scans"), 0),
                        output_field=FloatField(),
                    ),
                    Value(0.0),
                    output_field=FloatField(),
                )
            )
            .order_by("week_start")
        )

    @staticmethod
    def get_scan_kpis(direct_mat_nbr: str = None, mat_nbr_subquery=None):
        this_start, this_end, _, _ = iso_week_bounds()
        logger.info(
            "Retrieving scan KPIs for this week (%s..%s)", this_start, this_end
        )
        qs = InboundSerializationScan.objects.filter(
            req_created_date__date__gte=this_start,
            req_created_date__date__lte=this_end,
        ).exclude(
            req_request_type='0007', req_mode_of_entry='I', req_event_type='I'
        )
        if direct_mat_nbr:
            qs = qs.filter(material=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__in=mat_nbr_subquery)
        result = qs.aggregate(
            total_scans=Count("req_epc_cd", distinct=True, filter=Q(resp_error_cd_to_dc__in=["0000", "2015"])),
            successful_scans=Count("req_epc_cd", distinct=True, filter=Q(resp_error_cd_to_dc="0000")),
        )
        result["unsuccessful_scans"] = result["total_scans"] - result["successful_scans"]
        return result

    @staticmethod
    def get_failed_purchase_order_list(days: int = 90, direct_mat_nbr: str = None, mat_nbr_subquery=None):
        since = date.today() - timedelta(days=days)
        logger.info("Retrieving failed purchase order list for last %d days (since %s)", days, since)
        qs = InboundSerializationScan.objects.filter(
            resp_error_cd_to_dc="2015",
            req_created_date__date__gte=since,
        ).exclude(req_po_nbr__regex=r"^\s*$").exclude(
            req_request_type='0007', req_mode_of_entry='I', req_event_type='I'
        )
        if direct_mat_nbr:
            qs = qs.filter(material=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__in=mat_nbr_subquery)
        return (
            qs
            .values("req_po_nbr")
            .annotate(
                total_failed_scans=Count("req_epc_cd", distinct=True),
                lot_expiration_errors=Count(
                    "req_epc_cd", distinct=True, filter=Q(scan_status="Lot & Expiration Error")),
                expiration_errors=Count("req_epc_cd", distinct=True, filter=Q(scan_status="Expiration Error")),
                sgtin_not_found_errors=Count("req_epc_cd", distinct=True, filter=Q(scan_status="SGTIN Not Found")),
                null_failure_errors=Count("req_epc_cd", distinct=True, filter=Q(scan_status="Null Failure")),
                expired_product_errors=Count("req_epc_cd", distinct=True, filter=Q(scan_status="Expired Product")),
                wrong_dated_scan_errors=Count("req_epc_cd", distinct=True, filter=Q(scan_status="Wrong Dated Scan")),
                lot_errors=Count("req_epc_cd", distinct=True, filter=Q(scan_status="Lot Error")),
                missing_gtin_errors=Count("req_epc_cd", distinct=True, filter=Q(scan_status="Missing GTIN")),
            )
        )

    @staticmethod
    def get_failed_scans_list(direct_mat_nbr: str = None, mat_nbr_subquery=None):
        """
        Failed inbound scans for the current ISO week (Monday through today).

        One row per scan. Line identity is (req_po_nbr, material); error flags are
        derived from scan_status.
        """
        this_start, this_end, _, _ = iso_week_bounds()
        logger.info(
            "Retrieving failed scans list for this week (%s..%s)", this_start, this_end
        )
        qs = InboundSerializationScan.objects.filter(
            resp_error_cd_to_dc="2015",
            req_created_date__date__gte=this_start,
            req_created_date__date__lte=this_end,
        ).exclude(req_po_nbr__regex=r"^\s*$").exclude(
            req_request_type='0007', req_mode_of_entry='I', req_event_type='I'
        )
        if direct_mat_nbr:
            qs = qs.filter(material=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__in=mat_nbr_subquery)
        return (
            qs
            .select_related("material")
            .annotate(
                is_sgtin_error=Case(
                    When(scan_status__in=SGTIN_ERROR_STATUSES, then=Value(True)),
                    default=Value(False),
                    output_field=BooleanField(),
                ),
                is_lot_error=Case(
                    When(scan_status__in=LOT_ERROR_STATUSES, then=Value(True)),
                    default=Value(False),
                    output_field=BooleanField(),
                ),
                is_expiration_error=Case(
                    When(scan_status__in=EXPIRATION_ERROR_STATUSES, then=Value(True)),
                    default=Value(False),
                    output_field=BooleanField(),
                ),
            )
        )

    @staticmethod
    def _build_material_scope_qs(direct_mat_nbr, mat_nbr_subquery):
        qs = Material.objects.filter(
            dqsa_exempt_flg__in=["N", "W"],
        ).exclude(
            xplant_mat_stat__in=['DB', 'DM'],
        )
        if direct_mat_nbr:
            qs = qs.filter(mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(mat_nbr__in=mat_nbr_subquery)
        return qs

    @staticmethod
    def _build_po_scope_qs(since, direct_mat_nbr, mat_nbr_subquery, until=None):
        """
        PO lines in scope for EPCIS coverage: N+W materials with received_qty > 0
        in the window, excluding discontinued (DB/DM) materials. Built on
        PurchaseOrderLatest90dMV, which is already deduped to the latest snapshot
        per (po_number, po_line_number).
        """
        qs = PurchaseOrderLatest90dMV.objects.filter(
            received_qty__gt=0,
            as_of_date__gte=since,
            material__dqsa_exempt_flg__in=["N", "W"],
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM'],
        )
        if until is not None:
            qs = qs.filter(as_of_date__lte=until)
        if direct_mat_nbr:
            qs = qs.filter(material=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__in=mat_nbr_subquery)
        return qs

    @staticmethod
    def _build_epcis_qs(since, direct_mat_nbr, mat_nbr_subquery, until=None):
        has_epcis_subquery = Exists(
            InboundSerializationScan.objects.filter(
                req_po_nbr=OuterRef("po_number"),
                material_id=OuterRef("material_id"),
                resp_error_cd_to_dc="0000",
            ).exclude(req_request_type='0007', req_mode_of_entry='I', req_event_type='I')
        )
        return InboundSerializationScanService._build_po_scope_qs(
            since, direct_mat_nbr, mat_nbr_subquery, until=until
        ).annotate(has_epcis=has_epcis_subquery)

    @staticmethod
    def _build_po_line_epcis_qs(since, direct_mat_nbr, mat_nbr_subquery, until=None):
        """
        PO lines in scope annotated for line-level EPCIS classification (Option B).

        Inbound scans carry no po_line_number, so they attach to a line via
        (po_number, material). Each line is then classified:
            has_data:  at least one inbound scan (resp code 0000 or 2015).
            has_issue: at least one failed scan (resp code 2015).
        """
        line_scans = InboundSerializationScan.objects.filter(
            req_po_nbr=OuterRef("po_number"),
            material_id=OuterRef("material_id"),
        ).exclude(req_request_type='0007', req_mode_of_entry='I', req_event_type='I')
        return InboundSerializationScanService._build_po_scope_qs(
            since, direct_mat_nbr, mat_nbr_subquery, until=until
        ).annotate(
            has_data=Exists(line_scans.filter(resp_error_cd_to_dc__in=["0000", "2015"])),
            has_issue=Exists(line_scans.filter(resp_error_cd_to_dc="2015")),
        )

    @staticmethod
    def get_material_epcis_kpis(direct_mat_nbr: str = None, mat_nbr_subquery=None):
        """
        Returns the count of distinct materials with and without EPCIS coverage
        for the current ISO calendar week (Monday through today).

        Scope: N+W materials with received_qty > 0 in the period.
        A material "has EPCIS" if its PO has at least one successful inbound scan.
        """
        this_start, this_end, _, _ = iso_week_bounds()
        logger.info(
            "Retrieving material EPCIS KPIs for this week (%s..%s)", this_start, this_end
        )
        mat_qs = InboundSerializationScanService._build_material_scope_qs(
            direct_mat_nbr, mat_nbr_subquery
        )
        qs = InboundSerializationScanService._build_epcis_qs(
            this_start, direct_mat_nbr, mat_nbr_subquery, until=this_end
        )
        result = qs.aggregate(
            total_mats_received_count=Count("material", distinct=True),
            materials_with_epcis=Count("material", distinct=True, filter=Q(has_epcis=True)),
        )
        result["total_mat_count"] = mat_qs.values("mat_nbr").distinct().count()
        result["total_wee_mat_count"] = (
            mat_qs.filter(dqsa_exempt_flg="W").values("mat_nbr").distinct().count()
        )
        result["materials_without_epcis"] = (
            result["total_mats_received_count"] - result["materials_with_epcis"]
        )
        total = result["total_mats_received_count"]
        result["epcis_coverage_pct"] = round(result["materials_with_epcis"] * 100.0 / total, 2) if total else 0.0
        return result

    @staticmethod
    def get_material_epcis_weekly_trend(days: int = 90, direct_mat_nbr: str = None, mat_nbr_subquery=None):
        """
        Returns a weekly breakdown of distinct material counts with and without EPCIS
        coverage over the given lookback window.

        Scope: N+W materials with received_qty > 0 in the period.
        Weeks are derived from purchase_orders.as_of_date.
        """
        since = date.today() - timedelta(days=days)
        logger.info("Retrieving material EPCIS weekly trend for last %d days (since %s)", days, since)
        qs = InboundSerializationScanService._build_epcis_qs(since, direct_mat_nbr, mat_nbr_subquery)
        rows = (
            qs.annotate(week_start=TruncWeek("as_of_date"))
            .values("week_start")
            .annotate(
                total_materials=Count("material", distinct=True),
                materials_with_epcis=Count("material", distinct=True, filter=Q(has_epcis=True)),
            )
            .order_by("week_start")
        )
        result = []
        for row in rows:
            row = dict(row)
            row["materials_without_epcis"] = row["total_materials"] - row["materials_with_epcis"]
            total = row["total_materials"]
            row["epcis_coverage_pct"] = round(row["materials_with_epcis"] * 100.0 / total, 2) if total else 0.0
            result.append(row)
        return result

    @staticmethod
    def _summarize_line_epcis(row):
        """Derive the line-level EPCIS coverage fields in-place on an aggregate row."""
        total_lines = row["total_lines"] or 0
        row["total_received_qty"] = row["total_received_qty"] or 0
        row["total_lines"] = total_lines
        row["lines_with_epcis"] = row["lines_with_epcis"] or 0
        row["lines_with_issues"] = row["lines_with_issues"] or 0
        row["lines_without_data"] = (
            total_lines - row["lines_with_epcis"] - row["lines_with_issues"]
        )
        row["epcis_coverage_pct"] = (
            round(row["lines_with_epcis"] * 100.0 / total_lines, 2) if total_lines else 0.0
        )
        return row

    @staticmethod
    def get_received_qty_epcis_kpis(direct_mat_nbr: str = None, mat_nbr_subquery=None):
        """
        Received-qty headline plus line-level EPCIS coverage for this ISO week,
        with last-week coverage % and week-over-week pct change.

        Coverage is reported as a count of PO lines, not units. A binary PO-line
        EPCIS flag applied to whole-line unit sums overstates coverage (one scanned
        case marks the entire line's quantity as covered), so each PO line is
        classified instead:
            lines_with_epcis:   has scan data and no 2015 error
            lines_with_issues:  has at least one 2015 error
            lines_without_data: has no inbound scans
        total_received_qty is retained as an accurate (non-EPCIS-split) headline.

        Scope: N+W materials with received_qty > 0 in the period.
        """
        this_start, this_end, last_start, last_end = iso_week_bounds()
        logger.info(
            "Retrieving received qty EPCIS KPIs, this_week=%s..%s last_week=%s..%s",
            this_start, this_end, last_start, last_end,
        )

        def _agg(start, end):
            qs = InboundSerializationScanService._build_po_line_epcis_qs(
                start, direct_mat_nbr, mat_nbr_subquery, until=end
            )
            return InboundSerializationScanService._summarize_line_epcis(
                qs.aggregate(
                    total_received_qty=Sum("received_qty"),
                    total_lines=Count("id"),
                    lines_with_epcis=Count("id", filter=Q(has_data=True, has_issue=False)),
                    lines_with_issues=Count("id", filter=Q(has_issue=True)),
                )
            )

        this_week = _agg(this_start, this_end)
        last_week = _agg(last_start, last_end)
        last_pct = last_week["epcis_coverage_pct"]
        if last_week["total_lines"] and last_pct is not None:
            pct_change = round(
                (this_week["epcis_coverage_pct"] - last_pct) / last_pct * 100, 2
            ) if last_pct != 0 else None
        else:
            pct_change = None

        this_week["epcis_coverage_pct_last_week"] = last_pct
        this_week["epcis_coverage_pct_change"] = pct_change
        return this_week

    @staticmethod
    def get_received_qty_epcis_weekly_trend(days: int = 90, direct_mat_nbr: str = None, mat_nbr_subquery=None):
        """
        Returns a weekly breakdown of received qty and line-level EPCIS coverage
        over the given lookback window. See get_received_qty_epcis_kpis for the
        line-classification methodology.

        Scope: N+W materials with received_qty > 0 in the period.
        Weeks are derived from purchase_orders.as_of_date.
        """
        since = date.today() - timedelta(days=days)
        logger.info("Retrieving received qty EPCIS weekly trend for last %d days (since %s)", days, since)
        qs = InboundSerializationScanService._build_po_line_epcis_qs(since, direct_mat_nbr, mat_nbr_subquery)
        rows = (
            qs.annotate(week_start=TruncWeek("as_of_date"))
            .values("week_start")
            .annotate(
                total_received_qty=Sum("received_qty"),
                total_lines=Count("id"),
                lines_with_epcis=Count("id", filter=Q(has_data=True, has_issue=False)),
                lines_with_issues=Count("id", filter=Q(has_issue=True)),
            )
            .order_by("week_start")
        )
        return [InboundSerializationScanService._summarize_line_epcis(dict(row)) for row in rows]
