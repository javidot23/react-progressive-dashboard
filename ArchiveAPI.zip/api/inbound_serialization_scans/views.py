from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.global_filters import get_filtered_material_subquery
from api.pagination import MaxLimitOffsetPagination
from .filters import FailedPurchaseOrderFilter, FailedScanFilter
from .serialization import (
    FailedPurchaseOrderSerializer,
    FailedScanSerializer,
    MaterialEpcisKpisSerializer,
    MaterialEpcisWeeklyTrendSerializer,
    ReceivedQtyEpcisKpisSerializer,
    ReceivedQtyEpcisWeeklyTrendSerializer,
    ScanKpisSerializer,
    WeeklyScanHistorySerializer,
)
from .services import InboundSerializationScanService


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class ScanKpisView(APIView):
    """
    GET /inbound-serialization-scans/kpis/

    Returns total, successful, and unsuccessful scan counts for the current ISO week
    (Monday through today).

    Query params:
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=ScanKpisSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = InboundSerializationScanService.get_scan_kpis(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = ScanKpisSerializer(data)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyScanHistoryView(APIView):
    """
    GET /inbound-serialization-scans/weekly-history/

    Returns weekly scan counts and success rates over a configurable lookback window.

    Query params:
        days (int, default 90): lookback window in days
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=WeeklyScanHistorySerializer(many=True))
    def get(self, request):
        p = request.query_params
        try:
            days = int(p.get("days", 90))
        except (ValueError, TypeError):
            days = 90
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = InboundSerializationScanService.get_weekly_scan_history(
            days=days,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = WeeklyScanHistorySerializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialEpcisKpisView(APIView):
    """
    GET /inbound-serialization-scans/material-epcis-kpis/

    Returns the count of distinct materials with and without EPCIS coverage for the
    current ISO week (Monday through today). A material "has EPCIS" if it produced
    at least one Success scan.

    Query params:
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=MaterialEpcisKpisSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = InboundSerializationScanService.get_material_epcis_kpis(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = MaterialEpcisKpisSerializer(data)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialEpcisWeeklyTrendView(APIView):
    """
    GET /inbound-serialization-scans/material-epcis-weekly-trend/

    Returns a weekly breakdown of distinct material counts with and without EPCIS
    coverage over the lookback window (Visual 1 trend line).

    Query params:
        days (int, default 90): lookback window in days
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=MaterialEpcisWeeklyTrendSerializer(many=True))
    def get(self, request):
        p = request.query_params
        try:
            days = int(p.get("days", 90))
        except (ValueError, TypeError):
            days = 90
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = InboundSerializationScanService.get_material_epcis_weekly_trend(
            days=days,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = MaterialEpcisWeeklyTrendSerializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class ReceivedQtyEpcisKpisView(APIView):
    """
    GET /inbound-serialization-scans/received-qty-epcis-kpis/

    Returns total received quantity plus line-level EPCIS coverage for the current
    ISO week (Monday through today), with last-week coverage % and week-over-week
    pct change. EPCIS coverage is a count of PO lines (with EPCIS / with issues /
    without data), not a unit split — a line is flagged as an issue if any of its
    scans has a 2015 error.

    Query params:
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=ReceivedQtyEpcisKpisSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = InboundSerializationScanService.get_received_qty_epcis_kpis(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = ReceivedQtyEpcisKpisSerializer(data)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class ReceivedQtyEpcisWeeklyTrendView(APIView):
    """
    GET /inbound-serialization-scans/received-qty-epcis-weekly-trend/

    Returns a weekly breakdown of received quantity plus line-level EPCIS coverage
    (lines with EPCIS / with issues / without data) over the lookback window. See
    InboundSerializationScanService.get_received_qty_epcis_kpis for the methodology.

    Query params:
        days (int, default 90): lookback window in days
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=ReceivedQtyEpcisWeeklyTrendSerializer(many=True))
    def get(self, request):
        p = request.query_params
        try:
            days = int(p.get("days", 90))
        except (ValueError, TypeError):
            days = 90
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = InboundSerializationScanService.get_received_qty_epcis_weekly_trend(
            days=days,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = ReceivedQtyEpcisWeeklyTrendSerializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class FailedPurchaseOrderListView(ListAPIView):
    """
    GET /inbound-serialization-scans/failed-purchase-orders/

    Returns a paginated list of purchase orders with failed scans over the last N days,
    broken down by error type.

    Query params:
        days (int, default 90): lookback window in days
        ordering: sort field, prefix with - for descending (default: -total_failed_scans).
            Allowed: req_po_nbr, total_failed_scans, lot_expiration_errors, expiration_errors,
            sgtin_not_found_errors, null_failure_errors, expired_product_errors,
            wrong_dated_scan_errors, lot_errors, missing_gtin_errors.
        req_po_nbr: case-insensitive substring match on PO number.
        <field>_min / <field>_max: inclusive bounds on each numeric aggregate (same names as ordering).
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    serializer_class = FailedPurchaseOrderSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = FailedPurchaseOrderFilter
    ordering_fields = [
        "req_po_nbr",
        "total_failed_scans",
        "lot_expiration_errors",
        "expiration_errors",
        "sgtin_not_found_errors",
        "null_failure_errors",
        "expired_product_errors",
        "wrong_dated_scan_errors",
        "lot_errors",
        "missing_gtin_errors",
    ]
    ordering = ["-total_failed_scans"]

    def get_queryset(self):
        p = self.request.query_params
        try:
            days = int(p.get("days", 90))
        except (ValueError, TypeError):
            days = 90
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return InboundSerializationScanService.get_failed_purchase_order_list(
            days=days,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class FailedScanListView(ListAPIView):
    """
    GET /inbound-serialization-scans/failed-scans/

    Paginated failed inbound scans for the current ISO week (Monday through today).
    One row per scan. Line identity is (purchase_order_number, material_number).

    Query params:
        ordering: sort field, prefix with - for descending (default: -req_created_date).
            Allowed: req_created_date, req_po_nbr, material__mat_nbr, material__ndc,
            material__name, req_epc_cd, is_sgtin_error, is_lot_error, is_expiration_error.
        req_po_nbr: case-insensitive substring match on PO number.
        sgtin: case-insensitive substring match on SGTIN / EPC.
        is_sgtin_error, is_lot_error, is_expiration_error: boolean filters.
        scan_date_from / scan_date_to: inclusive date bounds within the week window.
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    serializer_class = FailedScanSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = FailedScanFilter
    ordering_fields = [
        "req_created_date",
        "req_po_nbr",
        "material__mat_nbr",
        "material__ndc",
        "material__name",
        "req_epc_cd",
        "is_sgtin_error",
        "is_lot_error",
        "is_expiration_error",
    ]
    ordering = ["-req_created_date"]

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return InboundSerializationScanService.get_failed_scans_list(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
