from django.urls import path

from .views import MaterialDetailsView, MaterialSubstituteListView, Neo4jMaterialSubstituteListView

app_name = 'material-substitute'

urlpatterns = [
    path('<int:material_id>/details/', MaterialDetailsView.as_view(), name='material-details'),
    path('<int:material_id>/', MaterialSubstituteListView.as_view(), name='list'),
    path('<int:material_id>/from-graph/', Neo4jMaterialSubstituteListView.as_view(), name='neo4j-list'),
]
