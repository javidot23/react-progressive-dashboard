import logging

from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import FilterSet, filters, DjangoFilterBackend
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.material.models import Material
from api.material_substitute.models import MaterialSubstitute
from api.material_substitute.serializers import (
    MaterialSubstituteWithMaterialSerializer,
    MaterialWithDetailsSerializer,
    Neo4jMaterialSubstituteSerializer
)
from api.material_substitute.services import MaterialSubstituteService
from api.purchase_order.services import PurchaseOrderService
from api.neo4j_graph_api.exceptions import Neo4jConnectionError, Neo4jQueryError
from api.neo4j_graph_api.services import Neo4jGraphService
from api.pagination import MaxLimitOffsetPagination

logger = logging.getLogger(__name__)


class MaterialSubstituteListFilter(FilterSet):
    """
    Filter set for MaterialSubstitute with filters for substitute materials.

    All filters apply to the substitute material, not the original material being substituted.
    """
    rank = filters.NumberFilter(field_name='rank', lookup_expr='exact')

    # Supplier filters
    supplier = filters.NumberFilter(lookup_expr='exact', field_name='substitute__vendor__id')
    supplier_nbr = filters.CharFilter(lookup_expr='exact', field_name='substitute__vendor__vendor_nbr')
    supplier_name = filters.CharFilter(lookup_expr='icontains', field_name='substitute__vendor__name')

    # Product Category filters
    product_family = filters.CharFilter(lookup_expr='icontains', field_name='substitute__product_family')
    product_category = filters.CharFilter(lookup_expr='icontains', field_name='substitute__material_group')

    # Therapeutic Class filters
    therapeutic_class = filters.CharFilter(lookup_expr='icontains', field_name='substitute__hic3_therapy_class')
    hic3_therapy_class = filters.CharFilter(lookup_expr='icontains', field_name='substitute__hic3_therapy_class')

    # Buyer filters
    buyer = filters.CharFilter(lookup_expr='icontains', field_name='substitute__buyer_name')
    buyer_name = filters.CharFilter(lookup_expr='icontains', field_name='substitute__buyer_name')
    buyer_cd = filters.CharFilter(lookup_expr='exact', field_name='substitute__buyer_cd')

    # Category Manager filters
    category_manager = filters.CharFilter(lookup_expr='icontains', field_name='substitute__cat_mgr_name')
    cat_mgr_name = filters.CharFilter(lookup_expr='icontains', field_name='substitute__cat_mgr_name')
    cat_mgr_nbr = filters.CharFilter(lookup_expr='exact', field_name='substitute__cat_mgr_nbr')

    # Material filters (for the substitute)
    material = filters.CharFilter(lookup_expr='exact', field_name='substitute__mat_nbr')
    material_id = filters.NumberFilter(lookup_expr='exact', field_name='substitute__id')
    material_name = filters.CharFilter(lookup_expr='icontains', field_name='substitute__name')

    # GCN filters
    gcn = filters.CharFilter(lookup_expr='icontains', field_name='substitute__fdb_gcn_seq_nbr')
    fdb_gcn_seq_nbr = filters.CharFilter(lookup_expr='icontains', field_name='substitute__fdb_gcn_seq_nbr')

    # Formulary / Parent Program filters
    formulary = filters.CharFilter(lookup_expr='icontains', field_name='substitute__materialformulary__parent_program')
    parent_program = filters.CharFilter(lookup_expr='icontains',
                                        field_name='substitute__materialformulary__parent_program')
    material_formulary = filters.CharFilter(lookup_expr='exact',
                                            field_name='substitute__materialformulary__parent_program')


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='retrieve')
class MaterialDetailsView(generics.RetrieveAPIView):
    """
    View to retrieve material details with formularies and plant availability count.
    """
    serializer_class = MaterialWithDetailsSerializer
    lookup_field = 'id'
    lookup_url_kwarg = 'material_id'

    def get_queryset(self):
        material_id = self.kwargs.get('material_id')
        return MaterialSubstituteService.get_material_details(material_id)

    def get_object(self):
        material = super().get_object()
        material.next_po_delivery = PurchaseOrderService.get_next_scheduled_po_delivery(material)
        return material


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialSubstituteListView(generics.ListAPIView):
    """
    View to list all material substitutes.
    """
    serializer_class = MaterialSubstituteWithMaterialSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend]
    filterset_class = MaterialSubstituteListFilter

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return MaterialSubstitute.objects.none()
        material_id = self.kwargs.get('material_id')
        return MaterialSubstituteService.get_substitutes_for_material(material_id)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class Neo4jMaterialSubstituteListView(APIView):
    """
    Returns material substitutes from Neo4j for a given material.

    Uses MaxLimitOffsetPagination (limit/offset) like other list APIs.
    Raw values only; formatting ($, %) is done on the frontend.
    """
    pagination_class = MaxLimitOffsetPagination

    @extend_schema(responses=Neo4jMaterialSubstituteSerializer(many=True))
    def get(self, request, material_id):
        """Retrieve material substitutes from Neo4j with limit/offset pagination."""
        try:
            try:
                material = Material.objects.get(id=material_id)
                mat_nbr = material.mat_nbr
            except Material.DoesNotExist:
                return Response(
                    {
                        "success": False,
                        "error": f"Material with id {material_id} not found"
                    },
                    status=status.HTTP_404_NOT_FOUND
                )

            material_formulary = request.query_params.get('material_formulary')

            paginator = self.pagination_class()
            total_count = Neo4jGraphService.get_material_substitutes_count(
                mat_nbr, material_formulary=material_formulary
            )
            placeholder_queryset = list(range(total_count))
            paginator.paginate_queryset(placeholder_queryset, request)

            data = Neo4jGraphService.get_material_substitutes(
                mat_nbr=mat_nbr,
                limit=paginator.limit,
                offset=paginator.offset,
                material_formulary=material_formulary
            )

            serializer = Neo4jMaterialSubstituteSerializer(data, many=True)
            return paginator.get_paginated_response(serializer.data)

        except (Neo4jConnectionError, Neo4jQueryError) as e:
            logger.error(f"Neo4j error in Neo4jMaterialSubstituteListView: {str(e)}")
            return Response(
                {
                    "success": False,
                    "error": "Neo4j service is temporarily unavailable."
                },
                status=status.HTTP_503_SERVICE_UNAVAILABLE
            )
        except ValueError as e:
            logger.error(f"Invalid parameter in Neo4jMaterialSubstituteListView: {str(e)}")
            return Response(
                {
                    "success": False,
                    "error": "Invalid request parameter."
                },
                status=status.HTTP_400_BAD_REQUEST
            )
        except Exception as e:
            logger.error(f"Unexpected error in Neo4jMaterialSubstituteListView: {str(e)}")
            return Response(
                {
                    "success": False,
                    "error": "An unexpected error occurred while retrieving material substitutes."
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
