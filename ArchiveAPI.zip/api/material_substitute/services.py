import logging
from datetime import date, timedelta

from django.db.models import Case, Count, F, FloatField, Max, OuterRef, Prefetch, Q, Subquery, Sum, Value, When
from django.db.models.functions import Cast

from api.demand_forecast.models import DemandForecast
from api.material.models import Material
from api.material_formulary.services import MaterialFormularyService
from api.material_substitute.models import MaterialSubstitute

logger = logging.getLogger(__name__)


def _doh_subquery_annotations(latest_demand_date, material_outer_ref):
    """
    Return annotation dicts for days_on_hand: sum_saleable, sum_forecast (subqueries),
    then days_on_hand = Sum(saleable) / (Sum(forecast) / 7) when Sum(forecast) > 0.
    When latest_demand_date is None, returns only days_on_hand=Value(None).
    """
    if latest_demand_date is None:
        return (
            {},
            {'days_on_hand': Value(None, output_field=FloatField())},
        )
    saleable_subquery = (
        DemandForecast.objects.filter(
            material=material_outer_ref,
            demand_date=latest_demand_date,
        )
        .values('material')
        .annotate(s=Sum('saleable_qty_on_hand'))
        .values('s')
    )
    forecast_subquery = (
        DemandForecast.objects.filter(
            material=material_outer_ref,
            demand_date=latest_demand_date,
        )
        .values('material')
        .annotate(s=Sum('forecast_qty_7day'))
        .values('s')
    )
    first_annotations = {
        'doh_sum_saleable': Subquery(saleable_subquery, output_field=FloatField()),
        'doh_sum_forecast': Subquery(forecast_subquery, output_field=FloatField()),
    }
    doh_annotation = Case(
        When(
            doh_sum_forecast__gt=0,
            then=Cast(
                F('doh_sum_saleable') / (F('doh_sum_forecast') / 7.0),
                FloatField(),
            ),
        ),
        default=None,
        output_field=FloatField(),
    )
    return (first_annotations, {'days_on_hand': doh_annotation})


class MaterialSubstituteService:
    """
    Service class for handling MaterialSubstitute operations.
    """

    @staticmethod
    def get_latest_demand_date():
        """
        Get the most recent demand_date that's not older than a week.
        """
        cutoff_date = date.today() - timedelta(weeks=1)
        return DemandForecast.objects.filter(
            demand_date__gte=cutoff_date
        ).aggregate(max_date=Max('demand_date'))['max_date']

    @staticmethod
    def get_material_details(material_id):
        """
        Get material details with formularies and plant availability count.
        """
        logger.info("Retrieving material details for material_id: %s", material_id)

        latest_demand_date = MaterialSubstituteService.get_latest_demand_date()
        logger.info("Using latest demand date: %s for material_id: %s", latest_demand_date, material_id)

        doh_first, doh_second = _doh_subquery_annotations(
            latest_demand_date, OuterRef('mat_nbr')
        )

        queryset = (
            Material.objects.filter(id=material_id)
            .select_related('vendor')
            .prefetch_related(
                Prefetch(
                    'materialformulary_set',
                    queryset=MaterialFormularyService.queryset_unique_by_program_description(),
                )
            )
            .annotate(
                available_plants_count=Count(
                    'demandforecast',
                    filter=Q(
                        demandforecast__demand_date=latest_demand_date,
                        demandforecast__saleable_qty_on_hand__gt=0,
                    )
                    if latest_demand_date
                    else Q(id__isnull=True),
                    distinct=True,
                ),
            )
            .annotate(**doh_first)
            .annotate(**doh_second)
        )

        logger.info("Returning material details for material_id: %s", material_id)
        return queryset

    @staticmethod
    def get_substitutes_for_material(material_id):
        """
        Get all substitutes for a given material with plant availability count.
        """
        logger.info("Retrieving substitutes for material_id: %s", material_id)

        latest_demand_date = MaterialSubstituteService.get_latest_demand_date()
        logger.info("Using latest demand date: %s for material_id: %s", latest_demand_date, material_id)

        doh_first, doh_second = _doh_subquery_annotations(
            latest_demand_date, OuterRef('substitute__mat_nbr')
        )

        queryset = (
            MaterialSubstitute.objects.filter(material__id=material_id)
            .exclude(material=F('substitute'))
            .select_related('substitute', 'substitute__vendor')
            .prefetch_related('substitute__materialformulary_set')
            .annotate(
                available_plants_count=Count(
                    'substitute__demandforecast',
                    filter=Q(
                        substitute__demandforecast__demand_date=latest_demand_date,
                        substitute__demandforecast__saleable_qty_on_hand__gt=0,
                    )
                    if latest_demand_date
                    else Q(id__isnull=True),
                    distinct=True,
                ),
            )
            .annotate(**doh_first)
            .annotate(**doh_second)
            .order_by('rank')
        )

        logger.info("Returning queryset for material_id: %s", material_id)
        return queryset
