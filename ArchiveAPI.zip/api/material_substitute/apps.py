from django.apps import AppConfig


class MaterialSubstituteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.material_substitute'
