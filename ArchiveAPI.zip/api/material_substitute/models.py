from django.db import models

from api.material.models import Material


class MaterialSubstitute(models.Model):
    """
    Model representing a material substitute.
    """
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        related_name="substitutes",
    )
    substitute = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="substitute_mat_nbr",
        on_delete=models.CASCADE,
        related_name="substituted_by",
    )
    rank = models.PositiveIntegerField(
        default=0,
        help_text="Rank of the substitute, lower values indicate higher preference.",
        null=True,
        blank=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True
    )
    updated_at = models.DateTimeField(
        auto_now=True
    )

    class Meta:
        db_table = "material_substitutes"
        unique_together = ("material", "rank")
        ordering = ["rank"]
        indexes = [
            models.Index(fields=["material", "substitute"]),
            models.Index(fields=["rank"]),
        ]
