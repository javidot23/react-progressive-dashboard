from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from api.material.models import Material
from api.material.serializers import MaterialWithVendorSerializer
from api.material_formulary.serializers import MaterialFormularySerializer
from api.material_substitute.models import MaterialSubstitute


class MaterialSubstituteSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaterialSubstitute
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'updated_at']


class NextPoDeliveryPlantSerializer(serializers.Serializer):
    plant_nbr = serializers.CharField()
    name = serializers.CharField(allow_null=True)


class NextPoDeliverySerializer(serializers.Serializer):
    anticipated_date = serializers.DateField()
    predicted_delv_date = serializers.DateField(allow_null=True)
    plant = NextPoDeliveryPlantSerializer(allow_null=True)


class MaterialFormularyForDetailsSerializer(MaterialFormularySerializer):
    """Formulary row for material details; name is the unique program description."""

    name = serializers.CharField(source='program_description', read_only=True)


class MaterialWithDetailsSerializer(serializers.ModelSerializer):
    """
    Reusable serializer for Material with vendor, formularies, and available plants count.
    """
    material = MaterialWithVendorSerializer(source='*')
    material_formularies = MaterialFormularyForDetailsSerializer(
        source='materialformulary_set', many=True
    )
    available_plants_count = serializers.IntegerField(read_only=True)
    days_on_hand = serializers.FloatField(read_only=True, allow_null=True)
    next_po_delivery = serializers.SerializerMethodField()

    class Meta:
        model = Material
        fields = [
            'material',
            'material_formularies',
            'available_plants_count',
            'days_on_hand',
            'next_po_delivery',
        ]

    @extend_schema_field(NextPoDeliverySerializer(allow_null=True))
    def get_next_po_delivery(self, obj):
        po = getattr(obj, 'next_po_delivery', None)
        if po is None:
            return None
        plant = po.plant
        return {
            'anticipated_date': po.anticipated_date,
            'predicted_delv_date': po.predicted_delv_date,
            'plant': None if plant is None else {
                'plant_nbr': plant.plant_nbr,
                'name': plant.name,
            },
        }


class MaterialSubstituteWithMaterialSerializer(serializers.ModelSerializer):
    """
    Serializer for MaterialSubstitute that exposes substitute as 'material' for consistency.
    """
    material = MaterialWithVendorSerializer(source='substitute')
    material_formularies = MaterialFormularySerializer(source='substitute.materialformulary_set', many=True)
    available_plants_count = serializers.IntegerField(read_only=True)
    days_on_hand = serializers.FloatField(read_only=True, allow_null=True)

    class Meta:
        model = MaterialSubstitute
        fields = ['id', 'rank', 'material', 'material_formularies', 'available_plants_count',
                  'days_on_hand', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class Neo4jMaterialSubstituteSerializer(serializers.Serializer):
    """
    Serializer for substitute material data from Neo4j.
    Raw values only; formatting ($, %) is done on the frontend.
    """
    mat_nbr = serializers.CharField()
    sub_mat_nbr = serializers.CharField()
    name = serializers.CharField(allow_null=True)
    dollars_at_risk = serializers.FloatField(allow_null=True)
    market_share = serializers.FloatField(allow_null=True)
    forecast_qty_7day = serializers.FloatField(allow_null=True)
    saleable_qty_on_hand = serializers.FloatField(allow_null=True)
    cost_per_unit = serializers.FloatField(allow_null=True)
    vendor_nbr = serializers.CharField(allow_null=True)
    vendor_name = serializers.CharField(allow_null=True)
    substitute_material_rank = serializers.IntegerField()
    material_formularies = serializers.ListField(child=serializers.DictField(), allow_empty=True)
    available_plants_count = serializers.IntegerField()
