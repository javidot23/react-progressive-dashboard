from django.urls import path

from . import views

app_name = "tenant"

urlpatterns = [
    path("", views.TenantListView.as_view(), name="tenant-list"),
    path("active/", views.TenantActiveView.as_view(), name="tenant-active"),
    path("context/", views.TenantContextView.as_view(), name="tenant-context"),
]
