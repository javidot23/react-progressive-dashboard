from django.apps import AppConfig

from config.db_scope import DBScope


class TenantConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.tenant'
    label = 'tenant'
    db_scope = DBScope.CORE
