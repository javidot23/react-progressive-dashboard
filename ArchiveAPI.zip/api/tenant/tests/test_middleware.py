"""Tenant binding, membership enforcement and alias hygiene in the middleware."""

from __future__ import annotations

import time
import uuid
from datetime import timedelta
from unittest.mock import patch

from django.test import RequestFactory, SimpleTestCase
from django.utils import timezone

from api.tenant.exceptions import InvalidTenantDatabase
from api.tenant.middleware import TenantDatabaseMiddleware
from api.tenant.models import Tenant
from api.tenant.services import ACTIVE_TENANT_SESSION_KEY
from config.tenant_cache import active_tenant_cache_ns, tenant_cache_namespace
from config.tenant_db import (
    active_tenant_db,
    ensure_tenant_connection,
    tenant_db_alias,
)
from api.user.choices import TenantAccessScope
from tests.BaseTestCase import BaseTestCase
from tests.factories import add_domain, add_membership, create_admin_user, create_tenant


class _Session(dict):
    """Minimal stand-in for the session object the middleware reads."""


class _AliasCleanupMixin:
    """Drop DB aliases registered during the test from the process-wide registry."""

    def _track_aliases(self):
        from django.db import connections

        known = set(connections.databases)

        def cleanup():
            for alias in set(connections.databases) - known:
                connections.databases.pop(alias, None)
                # Dropping the settings entry does not evict the cached wrapper.
                if hasattr(connections._connections, alias):
                    delattr(connections._connections, alias)

        self.addCleanup(cleanup)


class TenantDatabaseMiddlewareTest(_AliasCleanupMixin, BaseTestCase):
    def setUp(self):
        super().setUp()
        self._track_aliases()
        self.factory = RequestFactory()
        self.user = create_admin_user(email="mw@cencora.com", subject="mw-sub")
        self.tenant = create_tenant(code="MW")
        add_domain(self.tenant, "cencora.com")
        self.membership = add_membership(self.user, self.tenant)

    def _run(self, *, user=None, session=None):
        """Run one request through the middleware, capturing what it bound."""
        request = self.factory.get("/api/materials/")
        request.user = user if user is not None else self.user
        request.session = session if session is not None else self._session()

        seen = {}

        def get_response(req):
            seen["alias"] = active_tenant_db.get()
            seen["tenant"] = req.tenant
            seen["cache_ns"] = active_tenant_cache_ns.get()
            return "response"

        TenantDatabaseMiddleware(get_response)(request)
        seen["cache_ns_after"] = active_tenant_cache_ns.get()
        return seen, request

    def _session(self, **extra):
        session = _Session()
        session[ACTIVE_TENANT_SESSION_KEY] = str(self.tenant.pk)
        session.update(extra)
        return session

    def test_binds_tenant_for_an_active_membership(self):
        seen, _ = self._run()
        self.assertEqual(seen["alias"], tenant_db_alias(self.tenant.pk))
        self.assertEqual(seen["tenant"].pk, self.tenant.pk)
        self.assertEqual(seen["cache_ns"], tenant_cache_namespace(self.tenant))
        self.assertIsNone(seen["cache_ns_after"])

    def test_alias_is_restored_after_the_response(self):
        before = active_tenant_db.get()
        self._run()
        self.assertEqual(active_tenant_db.get(), before)

    def test_request_tenant_is_cleared_after_the_response(self):
        _, request = self._run()
        self.assertIsNone(request.tenant)

    def test_anonymous_request_binds_nothing(self):
        class Anonymous:
            is_authenticated = False

        seen, _ = self._run(user=Anonymous())
        self.assertIsNone(seen["alias"])
        self.assertIsNone(seen["tenant"])
        self.assertIsNone(seen["cache_ns"])
        self.assertIsNone(seen["cache_ns_after"])

    def test_session_without_active_tenant_binds_nothing(self):
        seen, _ = self._run(session=_Session())
        self.assertIsNone(seen["alias"])

    def test_revoked_membership_unbinds_and_clears_the_session_key(self):
        self.membership.is_active = False
        self.membership.save(update_fields=["is_active", "updated_at"])

        session = self._session()
        seen, _ = self._run(session=session)

        self.assertIsNone(seen["alias"])
        self.assertIsNone(seen["tenant"])
        self.assertNotIn(ACTIVE_TENANT_SESSION_KEY, session)

    def test_expired_membership_window_unbinds(self):
        self.membership.effective_to = timezone.now() - timedelta(days=1)
        self.membership.save(update_fields=["effective_to", "updated_at"])

        seen, _ = self._run()
        self.assertIsNone(seen["alias"])

    def test_membership_in_a_different_tenant_does_not_grant_access(self):
        other = create_tenant(code="OTHER")
        session = _Session()
        session[ACTIVE_TENANT_SESSION_KEY] = str(other.pk)

        seen, _ = self._run(session=session)
        self.assertIsNone(seen["alias"])
        self.assertNotIn(ACTIVE_TENANT_SESSION_KEY, session)

    def test_all_tenants_user_binds_without_membership_row(self):
        user = create_admin_user(
            email="allscope@cencora.com",
            subject="all-mw-sub",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )
        tenant = create_tenant(code="ALLMW")
        session = _Session()
        session[ACTIVE_TENANT_SESSION_KEY] = str(tenant.pk)

        seen, _ = self._run(user=user, session=session)
        self.assertEqual(seen["alias"], tenant_db_alias(tenant.pk))
        self.assertEqual(seen["tenant"].pk, tenant.pk)

    def test_inactive_tenant_unbinds_and_clears_the_session_key(self):
        self.tenant.is_active = False
        self.tenant.save(update_fields=["is_active", "updated_at"])

        session = self._session()
        seen, _ = self._run(session=session)

        self.assertIsNone(seen["alias"])
        self.assertNotIn(ACTIVE_TENANT_SESSION_KEY, session)

    def test_session_past_absolute_expiry_binds_nothing(self):
        session = self._session(absolute_expiry=int(time.time()) - 1)
        seen, _ = self._run(session=session)
        self.assertIsNone(seen["alias"])
        # The session key survives; DRF authentication is what rejects the request.
        self.assertIn(ACTIVE_TENANT_SESSION_KEY, session)

    def test_session_within_absolute_expiry_still_binds(self):
        session = self._session(absolute_expiry=int(time.time()) + 3600)
        seen, _ = self._run(session=session)
        self.assertEqual(seen["alias"], tenant_db_alias(self.tenant.pk))

    def test_tenant_cache_stores_coords_payload_not_model(self):
        from django.core.cache import cache
        from django.test import override_settings

        from api.tenant.middleware import _cache_key

        with override_settings(
            CACHES={
                "default": {
                    "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
                    "LOCATION": "tenant-middleware-test",
                }
            }
        ):
            cache.clear()
            self._run()
            cached = cache.get(_cache_key("row", self.tenant.pk))
            self.assertIsInstance(cached, dict)
            self.assertEqual(cached["tenant_code"], self.tenant.tenant_code)
            self.assertEqual(cached["database_host"], self.tenant.database_host)
            self.assertNotIn("_state", cached)


class TenantConnectionRegistryTest(_AliasCleanupMixin, SimpleTestCase):
    """``ensure_tenant_connection`` only reads attributes, so unsaved rows suffice."""

    def setUp(self):
        self._track_aliases()
        self.tenant = Tenant(
            # Distinct per test, so a leftover wrapper cannot mask a refresh bug.
            tenant_uuid=uuid.uuid5(uuid.NAMESPACE_OID, self.id()),
            tenant_code="REG",
            database_host="127.0.0.1",
            database_name="stratium_data",
            database_port=5432,
            database_schema="public",
            database_username="postgres",
        )

    def test_alias_is_reregistered_when_coordinates_change(self):
        from django.db import connections

        alias = ensure_tenant_connection(self.tenant)
        self.assertEqual(connections.databases[alias]["HOST"], "127.0.0.1")

        self.tenant.database_host = "db-replica.internal"
        ensure_tenant_connection(self.tenant)

        self.assertEqual(connections.databases[alias]["HOST"], "db-replica.internal")

    def test_already_built_connection_sees_new_coordinates(self):
        """Django caches wrappers per thread, so the refresh must reach them."""
        from django.db import connections

        alias = ensure_tenant_connection(self.tenant)
        wrapper = connections[alias]
        self.assertEqual(wrapper.settings_dict["HOST"], "127.0.0.1")

        self.tenant.database_host = "db-replica.internal"
        ensure_tenant_connection(self.tenant)

        self.assertEqual(wrapper.settings_dict["HOST"], "db-replica.internal")

    def test_unchanged_coordinates_reuse_the_registration(self):
        from django.db import connections

        alias = ensure_tenant_connection(self.tenant)
        registered = connections.databases[alias]
        self.assertIs(connections.databases[ensure_tenant_connection(self.tenant)], registered)

    def test_schema_is_applied_to_the_search_path(self):
        from django.db import connections

        self.tenant.database_schema = "reporting"
        alias = ensure_tenant_connection(self.tenant)
        options = connections.databases[alias]["OPTIONS"]["options"]
        self.assertIn("-c search_path=reporting", options)
        self.assertIn("-c statement_timeout=", options)
        self.assertIn("-c lock_timeout=", options)
        self.assertIn("-c idle_in_transaction_session_timeout=", options)

    def test_invalid_schema_is_refused(self):
        self.tenant.database_schema = "public -c log_statement=all"
        with self.assertRaises(InvalidTenantDatabase):
            ensure_tenant_connection(self.tenant)

    def test_username_comes_from_tenant_row(self):
        from django.db import connections

        self.tenant.database_username = "umi-partner-a"
        alias = ensure_tenant_connection(self.tenant)
        self.assertEqual(connections.databases[alias]["USER"], "umi-partner-a")
        self.assertIsNone(connections.databases[alias]["MANAGED_IDENTITY_CLIENT_ID"])

    def test_identity_change_reregisters_alias(self):
        from django.db import connections

        self.tenant.database_username = "umi-a"
        self.tenant.database_managed_identity_client_id = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
        alias = ensure_tenant_connection(self.tenant)
        self.assertEqual(
            connections.databases[alias]["MANAGED_IDENTITY_CLIENT_ID"],
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        )

        self.tenant.database_managed_identity_client_id = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb"
        ensure_tenant_connection(self.tenant)
        self.assertEqual(
            connections.databases[alias]["MANAGED_IDENTITY_CLIENT_ID"],
            "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
        )

    def test_blank_username_is_refused(self):
        self.tenant.database_username = ""
        with self.assertRaises(InvalidTenantDatabase):
            ensure_tenant_connection(self.tenant)

    @patch.dict("os.environ", {"DB_USE_MANAGED_IDENTITY": "true"})
    def test_mi_without_client_id_is_refused(self):
        self.tenant.database_username = "umi-a"
        self.tenant.database_managed_identity_client_id = ""
        with self.assertRaises(InvalidTenantDatabase):
            ensure_tenant_connection(self.tenant)
