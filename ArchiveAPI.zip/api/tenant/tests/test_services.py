from django.urls import reverse
from rest_framework.exceptions import AuthenticationFailed, PermissionDenied, ValidationError
from rest_framework.test import APIClient

from api.tenant.exceptions import ActiveTenantRequired
from api.tenant.models import TenantDomain
from api.tenant.services import (
    ACTIVE_TENANT_SESSION_KEY,
    TenantMembershipService,
    TenantService,
)
from api.user.choices import TenantAccessScope
from api.user.services import UserService
from config.tenant_db import clear_active_tenant_db, get_active_tenant_db
from tests.BaseTestCase import BaseAPITestCase, BaseTestCase
from tests.factories import add_domain, add_membership, create_admin_user, create_tenant


class TenantResolveLoginTest(BaseTestCase):
    def test_resolve_single_domain_match(self):
        tenant = create_tenant(code="ACME")
        add_domain(tenant, "acme.com")
        resolved = TenantService.resolve_for_login("user@acme.com")
        self.assertEqual(resolved.pk, tenant.pk)

    def test_resolve_no_match_denied(self):
        with self.assertRaises(AuthenticationFailed) as ctx:
            TenantService.resolve_for_login("user@unknown.com")
        self.assertEqual(ctx.exception.get_codes(), "no_tenant_for_domain")

    def test_tenant_without_domains_cannot_be_resolved(self):
        """A tenant with no TenantDomain rows is unreachable by login."""
        create_tenant(code="NODOMAINS")
        with self.assertRaises(AuthenticationFailed) as ctx:
            TenantService.resolve_for_login("user@nodomains.com")
        self.assertEqual(ctx.exception.get_codes(), "no_tenant_for_domain")

    def test_inactive_tenant_does_not_claim_its_domain(self):
        tenant = create_tenant(code="OFF", is_active=False)
        add_domain(tenant, "off.com")
        with self.assertRaises(AuthenticationFailed) as ctx:
            TenantService.resolve_for_login("user@off.com")
        self.assertEqual(ctx.exception.get_codes(), "no_tenant_for_domain")

    def test_resolve_multi_defers_selection_without_hint(self):
        a = create_tenant(code="A")
        b = create_tenant(code="B")
        add_domain(a, "shared.com")
        add_domain(b, "shared.com")

        self.assertIsNone(TenantService.resolve_for_login("user@shared.com"))

        resolved = TenantService.resolve_for_login("user@shared.com", tenant_uuid_hint=a.pk)
        self.assertEqual(resolved.pk, a.pk)

        self.assertEqual(
            {t.pk for t in TenantService.tenants_for_email("user@shared.com")},
            {a.pk, b.pk},
        )

    def test_resolve_rejects_hint_outside_domain_matches(self):
        a = create_tenant(code="A")
        b = create_tenant(code="B")
        other = create_tenant(code="OTHER")
        add_domain(a, "shared.com")
        add_domain(b, "shared.com")
        add_domain(other, "elsewhere.com")

        with self.assertRaises(AuthenticationFailed) as ctx:
            TenantService.resolve_for_login("user@shared.com", tenant_uuid_hint=other.pk)
        self.assertEqual(ctx.exception.get_codes(), "tenant_hint_invalid")

    def test_resolve_matches_domain_case_insensitively(self):
        tenant = create_tenant(code="CASE")
        domain = add_domain(tenant, "mixed.com")
        # Stratium Admin API owns this table and does not go through our save().
        TenantDomain.objects.filter(pk=domain.pk).update(domain="Mixed.COM")

        resolved = TenantService.resolve_for_login("user@mixed.com")
        self.assertEqual(resolved.pk, tenant.pk)

    def test_domain_is_stored_lowercased(self):
        tenant = create_tenant(code="LOWER")
        saved = TenantDomain.objects.create(tenant=tenant, domain="  MiXeD.CoM ")
        saved.refresh_from_db()
        self.assertEqual(saved.domain, "mixed.com")


class FederatedProvisionTest(BaseTestCase):
    def test_federated_jit_creates_user_and_membership(self):
        tenant = create_tenant(code="FED", is_federated=True)
        add_domain(tenant, "fed.com")
        user = UserService.resolve_or_provision_for_login(
            sub="sub-1",
            email="new@fed.com",
            tenant=tenant,
            first_name="New",
            last_name="User",
        )
        self.assertTrue(user.pk)
        self.assertIsNotNone(
            TenantMembershipService.get_effective_membership(user, tenant)
        )

    def test_non_federated_without_invite_denied(self):
        tenant = create_tenant(code="NF", is_federated=False)
        add_domain(tenant, "nf.com")
        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="sub-2",
                email="nobody@nf.com",
                tenant=tenant,
            )
        self.assertEqual(ctx.exception.get_codes(), "not_provisioned")


class TenantMembershipActiveTest(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.user = create_admin_user(email="staff@partner.com")
        self.tenant = create_tenant(code="MEM")
        add_domain(self.tenant, "partner.com")

    def test_set_active_requires_membership(self):
        session = {}
        with self.assertRaises(PermissionDenied):
            TenantMembershipService.set_active(self.user, session, self.tenant.pk)

        add_membership(self.user, self.tenant)
        tenant = TenantMembershipService.set_active(self.user, session, self.tenant.pk)
        self.assertEqual(tenant.pk, self.tenant.pk)
        self.assertEqual(session[ACTIVE_TENANT_SESSION_KEY], str(self.tenant.pk))

    def test_set_active_unknown_tenant(self):
        import uuid

        with self.assertRaises(ValidationError):
            TenantMembershipService.set_active(self.user, {}, uuid.uuid4())

    def test_all_tenants_can_access_and_set_active_without_membership(self):
        user = create_admin_user(
            email="all@cencora.com",
            subject="all-sub",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )
        other = create_tenant(code="MEM2")

        self.assertTrue(TenantMembershipService.can_access(user, self.tenant))
        self.assertTrue(TenantMembershipService.can_access(user, other))
        tenants = TenantMembershipService.list_tenants_for_user(user)
        self.assertGreaterEqual({t.pk for t in tenants}, {self.tenant.pk, other.pk})

        session = {}
        tenant = TenantMembershipService.set_active(user, session, other.pk)
        self.assertEqual(tenant.pk, other.pk)
        self.assertEqual(session[ACTIVE_TENANT_SESSION_KEY], str(other.pk))
        self.assertEqual(TenantMembershipService.get_active(user, session).pk, other.pk)

    def test_list_tenants_for_membership_scoped_user(self):
        add_membership(self.user, self.tenant)
        other = create_tenant(code="OTHERMEM")
        tenants = TenantMembershipService.list_tenants_for_user(self.user)
        self.assertEqual([t.pk for t in tenants], [self.tenant.pk])
        self.assertNotIn(other.pk, {t.pk for t in tenants})


class TenantDBFailClosedTest(BaseTestCase):
    def test_raises_when_no_active_alias(self):
        clear_active_tenant_db()
        with self.assertRaises(ActiveTenantRequired):
            get_active_tenant_db()


class TenantApiTest(BaseAPITestCase):
    def setUp(self):
        super().setUp()
        self.client = APIClient()
        self.user = create_admin_user(email="api@example.com", subject="api-sub")
        add_domain(self.test_tenant, "example.com")
        add_membership(self.user, self.test_tenant)
        self.client.force_authenticate(user=self.user)

    def _list_payload(self, response):
        payload = response.data
        if isinstance(payload, dict):
            payload = payload.get("data", payload)
        return payload

    def test_list_tenants(self):
        response = self.client.get(reverse("tenant:tenant-list"))
        self.assertEqual(response.status_code, 200)
        codes = {row["tenant_code"] for row in self._list_payload(response)}
        self.assertIn(self.test_tenant.tenant_code, codes)

    def test_list_tenants_search_by_code(self):
        other = create_tenant(code="ZZZSEARCH", name="Other Corp")
        add_membership(self.user, other)

        response = self.client.get(reverse("tenant:tenant-list"), {"search": "ZZZSEARCH"})
        self.assertEqual(response.status_code, 200)
        payload = self._list_payload(response)
        codes = {row["tenant_code"] for row in payload}
        self.assertEqual(codes, {"ZZZSEARCH"})

    def test_list_tenants_search_by_name(self):
        other = create_tenant(code="NAME1", name="Unique Acme Holdings")
        add_membership(self.user, other)

        response = self.client.get(reverse("tenant:tenant-list"), {"search": "Acme"})
        self.assertEqual(response.status_code, 200)
        payload = self._list_payload(response)
        codes = {row["tenant_code"] for row in payload}
        self.assertEqual(codes, {"NAME1"})

    def test_list_tenants_filter_tenant_type(self):
        from api.tenant.choices import TenantType

        vendor = create_tenant(code="VEND1", tenant_type=TenantType.VENDOR)
        add_membership(self.user, vendor)

        response = self.client.get(
            reverse("tenant:tenant-list"),
            {"tenant_type": TenantType.VENDOR},
        )
        self.assertEqual(response.status_code, 200)
        payload = self._list_payload(response)
        codes = {row["tenant_code"] for row in payload}
        self.assertEqual(codes, {"VEND1"})
        self.assertTrue(all(row["tenant_type"] == TenantType.VENDOR for row in payload))

    def test_list_tenants_filter_entitlement_tier(self):
        premium = create_tenant(code="PREM1", entitlement_tier="premium")
        add_membership(self.user, premium)

        response = self.client.get(
            reverse("tenant:tenant-list"),
            {"entitlement_tier": "premium"},
        )
        self.assertEqual(response.status_code, 200)
        payload = self._list_payload(response)
        codes = {row["tenant_code"] for row in payload}
        self.assertEqual(codes, {"PREM1"})

    def test_list_tenants_filter_is_federated(self):
        fed = create_tenant(code="FED1", is_federated=True)
        add_membership(self.user, fed)

        response = self.client.get(reverse("tenant:tenant-list"), {"is_federated": "true"})
        self.assertEqual(response.status_code, 200)
        payload = self._list_payload(response)
        codes = {row["tenant_code"] for row in payload}
        self.assertIn("FED1", codes)
        self.assertIn(self.test_tenant.tenant_code, codes)
        self.assertTrue(all(row["is_federated"] is True for row in payload))

    def test_set_active_and_context(self):
        response = self.client.post(
            reverse("tenant:tenant-active"),
            {"tenant_uuid": str(self.test_tenant.pk)},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        payload = response.data.get("data", response.data)
        self.assertEqual(payload["tenant_code"], self.test_tenant.tenant_code)

        session = self.client.session
        session[ACTIVE_TENANT_SESSION_KEY] = str(self.test_tenant.pk)
        session.save()

        context = self.client.get(reverse("tenant:tenant-context"))
        self.assertEqual(context.status_code, 200)
        context_payload = context.data.get("data", context.data)
        self.assertEqual(str(context_payload["tenant_uuid"]), str(self.test_tenant.pk))
