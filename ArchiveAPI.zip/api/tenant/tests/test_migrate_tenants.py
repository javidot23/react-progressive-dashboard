from io import StringIO
from unittest.mock import patch

from django.core.management import call_command
from django.core.management.base import CommandError

from api.tenant.management.commands.migrate_tenants import TenantMigrateResult
from tests.BaseTestCase import BaseTransactionTestCase
from tests.factories import create_tenant


class MigrateTenantsCommandTest(BaseTransactionTestCase):
    @patch.dict("os.environ", {"ALLOW_TENANT_DB_MIGRATIONS": "false"})
    def test_refuses_without_allow_flag(self):
        with self.assertRaises(CommandError) as ctx:
            call_command("migrate_tenants", stdout=StringIO())
        self.assertIn("ALLOW_TENANT_DB_MIGRATIONS", str(ctx.exception))

    @patch.dict("os.environ", {"ALLOW_TENANT_DB_MIGRATIONS": "true"})
    def test_dry_run_lists_tenant_without_migrate(self):
        tenant = self.test_tenant
        out = StringIO()
        with patch(
            "api.tenant.management.commands.migrate_tenants._pending_migrations",
            return_value=[object(), object()],
        ), patch(
            "api.tenant.management.commands.migrate_tenants.call_command"
        ) as migrate_cmd:
            call_command(
                "migrate_tenants",
                "--dry-run",
                f"--tenant-uuid={tenant.tenant_uuid}",
                stdout=out,
            )
            migrate_cmd.assert_not_called()
        output = out.getvalue()
        self.assertIn("DRY-RUN", output)
        self.assertIn(tenant.tenant_code, output)
        self.assertIn("would apply 2 migration(s)", output)
        self.assertIn("migrations=2", output)

    @patch.dict("os.environ", {"ALLOW_TENANT_DB_MIGRATIONS": "true"})
    def test_unknown_tenant_uuid_errors(self):
        import uuid

        with self.assertRaises(CommandError):
            call_command(
                "migrate_tenants",
                f"--tenant-uuid={uuid.uuid4()}",
                stdout=StringIO(),
            )

    @patch.dict("os.environ", {"ALLOW_TENANT_DB_MIGRATIONS": "true"})
    def test_final_report_lists_all_results_sorted_before_failure(self):
        ok_tenant = create_tenant(
            code="AAA-OK",
            name="Ok Tenant",
            database_name="tenant_aaa_ok",
        )
        fail_tenant = create_tenant(
            code="ZZZ-FAIL",
            name="Fail Tenant",
            database_name="tenant_zzz_fail",
        )
        skip_tenant = create_tenant(
            code="MMM-SKIP",
            name="Skip Tenant",
            database_host="",
            database_name="",
        )

        results_by_code = {
            ok_tenant.tenant_code: TenantMigrateResult(
                tenant_uuid=str(ok_tenant.tenant_uuid),
                tenant_code=ok_tenant.tenant_code,
                alias="tenant_ok",
                ok=True,
                message="applied 2 migration(s)",
                migration_count=2,
            ),
            skip_tenant.tenant_code: TenantMigrateResult(
                tenant_uuid=str(skip_tenant.tenant_uuid),
                tenant_code=skip_tenant.tenant_code,
                alias="",
                ok=False,
                skipped=True,
                message="missing database_host or database_name",
            ),
            fail_tenant.tenant_code: TenantMigrateResult(
                tenant_uuid=str(fail_tenant.tenant_uuid),
                tenant_code=fail_tenant.tenant_code,
                alias="tenant_fail",
                ok=False,
                message="RuntimeError: boom",
            ),
            self.test_tenant.tenant_code: TenantMigrateResult(
                tenant_uuid=str(self.test_tenant.tenant_uuid),
                tenant_code=self.test_tenant.tenant_code,
                alias="tenant_test",
                ok=True,
                message="already up to date",
                migration_count=0,
            ),
        }

        def fake_migrate_one(tenant, *, dry_run):
            return results_by_code[tenant.tenant_code]

        out = StringIO()
        with patch(
            "api.tenant.management.commands.migrate_tenants._migrate_one",
            side_effect=fake_migrate_one,
        ):
            with self.assertRaises(CommandError) as ctx:
                call_command(
                    "migrate_tenants",
                    "--concurrency=3",
                    stdout=out,
                )

        self.assertIn("1 tenant migration(s) failed", str(ctx.exception))
        output = out.getvalue()
        self.assertIn("Final report:", output)
        self.assertIn("Done: ok=2 failed=1 skipped=1 total=4", output)
        self.assertIn("migrations=2", output)
        self.assertNotIn("pending=", output)

        report_section = output.split("Final report:", 1)[1]
        ok_pos = report_section.index(f"[OK] {ok_tenant.tenant_code}")
        skip_pos = report_section.index(f"[SKIP] {skip_tenant.tenant_code}")
        fail_pos = report_section.index(f"[FAIL] {fail_tenant.tenant_code}")
        self.assertLess(ok_pos, skip_pos)
        self.assertLess(skip_pos, fail_pos)

        done_pos = output.index("Done: ok=2 failed=1 skipped=1 total=4")
        final_pos = output.index("Final report:")
        self.assertLess(final_pos, done_pos)
        self.assertIn("Failures:", output[done_pos:])
        self.assertIn(fail_tenant.tenant_code, output[done_pos:])

    @patch.dict("os.environ", {"ALLOW_TENANT_DB_MIGRATIONS": "true"})
    def test_rejects_duplicate_database_targets(self):
        create_tenant(
            code="DUP-A",
            name="Dup A",
            database_host="localhost",
            database_name="shared_tenant_db",
            database_port=5432,
            database_schema="public",
        )
        create_tenant(
            code="DUP-B",
            name="Dup B",
            database_host="LocalHost",
            database_name="SHARED_TENANT_DB",
            database_port=5432,
            database_schema="Public",
        )

        with self.assertRaises(CommandError) as ctx:
            call_command("migrate_tenants", stdout=StringIO())

        message = str(ctx.exception)
        self.assertIn("duplicate tenant database targets", message)
        self.assertIn("DUP-B", message)
        self.assertIn("DUP-A", message)

    @patch.dict("os.environ", {"ALLOW_TENANT_DB_MIGRATIONS": "true"})
    def test_apply_migrations_uses_quiet_verbosity(self):
        tenant = self.test_tenant
        with patch(
            "api.tenant.management.commands.migrate_tenants._pending_migrations",
            return_value=[object()],
        ), patch(
            "api.tenant.management.commands.migrate_tenants.call_command"
        ) as migrate_cmd, patch(
            "api.tenant.management.commands.migrate_tenants.ensure_tenant_connection",
            return_value=f"tenant_{tenant.tenant_uuid}",
        ):
            call_command(
                "migrate_tenants",
                f"--tenant-uuid={tenant.tenant_uuid}",
                stdout=StringIO(),
            )

        migrate_cmd.assert_called_once()
        _, kwargs = migrate_cmd.call_args
        self.assertEqual(kwargs["verbosity"], 0)
        self.assertFalse(kwargs["interactive"])
