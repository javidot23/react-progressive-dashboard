from io import StringIO
from unittest.mock import patch

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import CommandError

from api.tenant.models import Tenant
from config.db_scope import CORE_DB_ALIAS
from tests.BaseTestCase import BaseTestCase


class FakeTenantsCommandTest(BaseTestCase):
    @patch("api.tenant.management.commands.fake_tenants.create_postgres_database")
    def test_create_database_uses_configured_postgres_server(self, create_database):
        call_command("fake_tenants", "--count=1", "--create-database", stdout=StringIO())

        tenant = Tenant.objects.exclude(pk=self.test_tenant.pk).get()
        core_database = settings.DATABASES[CORE_DB_ALIAS]
        self.assertEqual(tenant.database_host, core_database["HOST"])
        self.assertEqual(tenant.database_port, int(core_database["PORT"] or 5432))
        self.assertEqual(tenant.database_username, core_database["USER"])
        create_database.assert_called_once_with(tenant.database_name)

    @patch(
        "api.tenant.management.commands.fake_tenants.create_postgres_database",
        side_effect=RuntimeError("database creation failed"),
    )
    def test_create_database_failure_removes_tenant(self, create_database):
        tenant_count = Tenant.objects.count()

        with self.assertRaises(CommandError):
            call_command("fake_tenants", "--count=1", "--create-database", stdout=StringIO())

        self.assertEqual(Tenant.objects.count(), tenant_count)
        create_database.assert_called_once()
