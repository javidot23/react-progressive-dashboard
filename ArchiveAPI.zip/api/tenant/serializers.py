from rest_framework import serializers

from api.tenant.models import Tenant


class TenantListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tenant
        fields = [
            "tenant_uuid",
            "tenant_code",
            "tenant_name",
            "tenant_type",
            "entitlement_tier",
            "is_federated",
        ]


class TenantContextSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tenant
        fields = [
            "tenant_uuid",
            "tenant_code",
            "tenant_name",
            "tenant_type",
            "entitlement_tier",
            "is_federated",
        ]


class SetActiveTenantSerializer(serializers.Serializer):
    tenant_uuid = serializers.UUIDField()
