"""Tenant reads, login resolution, and session active-tenant selection."""

from __future__ import annotations

import logging
import uuid

from django.conf import settings
from django.core.cache import cache
from django.db.models import Q, QuerySet
from django.utils import timezone
from rest_framework.exceptions import AuthenticationFailed, PermissionDenied, ValidationError

from api.common.emails import email_domain

from .models import Tenant, TenantDomain, TenantMembership

logger = logging.getLogger(__name__)

ACTIVE_TENANT_SESSION_KEY = "active_tenant_uuid"
PENDING_TENANT_HINT_SESSION_KEY = "pending_tenant_uuid"

_TENANT_CACHE_TTL = 60

_TENANT_CACHE_FIELDS = (
    "tenant_uuid",
    "tenant_code",
    "tenant_name",
    "tenant_type",
    "entitlement_tier",
    "database_host",
    "database_name",
    "database_port",
    "database_schema",
    "database_username",
    "database_managed_identity_client_id",
    "is_federated",
    "is_active",
    "is_deleted",
)


def _cache_key(*parts) -> str:
    prefix = getattr(settings, "CACHE_MIDDLEWARE_KEY_PREFIX", "scrm")
    return ":".join([prefix, "tenant", *(str(p) for p in parts)])


def _tenant_payload(tenant) -> dict:
    return {field: getattr(tenant, field) for field in _TENANT_CACHE_FIELDS}


def _tenant_from_payload(payload: dict) -> Tenant:
    data = dict(payload)
    raw_uuid = data.get("tenant_uuid")
    if raw_uuid is not None and not isinstance(raw_uuid, uuid.UUID):
        data["tenant_uuid"] = uuid.UUID(str(raw_uuid))
    return Tenant(**data)


def _membership_currently_effective(membership: TenantMembership, now=None) -> bool:
    if not membership.is_active:
        return False
    now = now or timezone.now()
    if membership.effective_from and membership.effective_from > now:
        return False
    if membership.effective_to and membership.effective_to < now:
        return False
    return True


class TenantService:
    """Tenant lookups and login-time resolution."""

    @staticmethod
    def get_usable(tenant_uuid, *, use_cache: bool = False) -> Tenant | None:
        """Return an active, non-deleted tenant by uuid, or ``None``."""
        if use_cache:
            key = _cache_key("row", tenant_uuid)
            cached = cache.get(key)
            if cached is not None:
                tenant = _tenant_from_payload(cached)
                if tenant.is_deleted or not tenant.is_active:
                    return None
                return tenant

        tenant = Tenant.objects.filter(
            pk=tenant_uuid,
            is_deleted=False,
            is_active=True,
        ).first()
        if tenant is not None and use_cache:
            cache.set(_cache_key("row", tenant_uuid), _tenant_payload(tenant), timeout=_TENANT_CACHE_TTL)
        return tenant

    @staticmethod
    def assert_tenant_usable(tenant: Tenant) -> None:
        if tenant is None or tenant.is_deleted or not tenant.is_active:
            raise AuthenticationFailed("Access denied", code="tenant_inactive")

    @staticmethod
    def assert_email_domain_allowed(tenant: Tenant, email: str) -> None:
        allowed = {
            d.strip().lower()
            for d in tenant.domains.values_list("domain", flat=True)
            if d
        }
        if not allowed:
            raise AuthenticationFailed("Access denied", code="tenant_domain_not_configured")
        domain = email_domain(email)
        if domain is None or domain not in allowed:
            raise AuthenticationFailed("Access denied", code="domain_not_allowed")

    @staticmethod
    def list_active() -> list[Tenant]:
        """All active, non-deleted tenants ordered by ``tenant_code``."""
        return list(
            Tenant.objects.filter(is_deleted=False, is_active=True).order_by("tenant_code")
        )

    @staticmethod
    def tenants_for_email(email: str) -> list[Tenant]:
        """Active tenants whose configured domains include ``email``'s domain.

        Raises ``no_tenant_for_domain`` when nothing claims the domain.
        """
        domain = email_domain(email)
        if not domain:
            raise AuthenticationFailed("Access denied", code="invalid_email")

        matches = list(
            Tenant.objects.filter(
                is_deleted=False,
                is_active=True,
                domains__domain__iexact=domain,
            )
            .distinct()
            .order_by("tenant_code")
        )
        if not matches:
            configured = TenantDomain.objects.filter(
                tenant__is_deleted=False, tenant__is_active=True
            ).count()
            logger.warning(
                "No active tenant claims domain %r (%d tenant domain(s) configured overall); "
                "add a TenantDomain row for the tenant this user belongs to",
                domain,
                configured,
            )
            raise AuthenticationFailed("Access denied", code="no_tenant_for_domain")
        return matches

    @staticmethod
    def resolve_for_login(email: str, tenant_uuid_hint=None, *, matches=None) -> Tenant | None:
        """Resolve the login tenant from the email domain.

        Returns ``None`` when several tenants share the domain and
        no usable hint was supplied; the caller authenticates the user without an
        active tenant and the client selects one via ``POST /tenant/active/``.
        """
        if matches is None:
            matches = TenantService.tenants_for_email(email)

        if len(matches) == 1:
            tenant = matches[0]
            logger.info(
                "Login tenant resolved: matches=%d resolved=%s hint=%s",
                len(matches),
                tenant.pk,
                tenant_uuid_hint or None,
            )
        elif not tenant_uuid_hint:
            logger.info(
                "Login tenant deferred: matches=%d resolved=none hint=none",
                len(matches),
            )
            return None
        else:
            hint = str(tenant_uuid_hint)
            tenant = next((t for t in matches if str(t.pk) == hint), None)
            if tenant is None:
                raise AuthenticationFailed("Access denied", code="tenant_hint_invalid")
            logger.info(
                "Login tenant resolved: matches=%d resolved=%s hint=%s",
                len(matches),
                tenant.pk,
                hint,
            )

        TenantService.assert_tenant_usable(tenant)
        return tenant


class TenantMembershipService:
    """Membership reads/writes plus the session-scoped active-tenant selection."""

    @staticmethod
    def has_all_tenant_access(user) -> bool:
        from api.user.choices import TenantAccessScope

        return user.tenant_access_scope == TenantAccessScope.ALL_TENANTS

    @staticmethod
    def can_access(user, tenant) -> bool:
        if tenant is None or tenant.is_deleted or not tenant.is_active:
            return False
        if TenantMembershipService.has_all_tenant_access(user):
            return True
        return TenantMembershipService.get_effective_membership(user, tenant) is not None

    @staticmethod
    def users_with_access(tenant) -> QuerySet:
        from api.user.choices import TenantAccessScope
        from api.user.models import User

        return User.objects.filter(
            Q(
                tenant_memberships__tenant=tenant,
                tenant_memberships__is_active=True,
            )
            | Q(tenant_access_scope=TenantAccessScope.ALL_TENANTS),
            is_deleted=False,
        ).distinct()

    @staticmethod
    def list_active_for_user(user) -> QuerySet:
        return (
            TenantMembership.objects.filter(
                user=user,
                is_active=True,
                tenant__is_deleted=False,
                tenant__is_active=True,
            )
            .select_related("tenant")
            .order_by("tenant__tenant_code")
        )

    @staticmethod
    def get_effective_membership(user, tenant) -> TenantMembership | None:
        membership = (
            TenantMembership.objects.filter(user=user, tenant=tenant, is_active=True)
            .select_related("tenant")
            .first()
        )
        if membership is None or not _membership_currently_effective(membership):
            return None
        return membership

    @staticmethod
    def assert_can_access(user, tenant) -> None:
        if not TenantMembershipService.can_access(user, tenant):
            raise AuthenticationFailed("Access denied", code="membership_required")

    @staticmethod
    def assert_active_membership(user, tenant) -> TenantMembership | None:
        TenantMembershipService.assert_can_access(user, tenant)
        return TenantMembershipService.get_effective_membership(user, tenant)

    @staticmethod
    def list_tenants_for_user(user) -> list[Tenant]:
        if TenantMembershipService.has_all_tenant_access(user):
            return TenantService.list_active()
        memberships = TenantMembershipService.list_active_for_user(user)
        tenants = []
        now = timezone.now()
        for m in memberships:
            if _membership_currently_effective(m, now=now):
                tenants.append(m.tenant)
        return tenants

    @staticmethod
    def get_active(user, session):
        tenant_uuid = session.get(ACTIVE_TENANT_SESSION_KEY)
        if not tenant_uuid:
            return None
        tenant = TenantService.get_usable(tenant_uuid)
        if tenant is None:
            return None
        if not TenantMembershipService.can_access(user, tenant):
            return None
        return tenant

    @staticmethod
    def set_active(user, session, tenant_uuid) -> Tenant:
        tenant = TenantService.get_usable(tenant_uuid)
        if tenant is None:
            raise ValidationError("tenant_uuid: unknown or inactive tenant.")
        if not TenantMembershipService.can_access(user, tenant):
            raise PermissionDenied("You are not a member of the requested tenant.")
        session[ACTIVE_TENANT_SESSION_KEY] = str(tenant.pk)
        return tenant
