"""Bind the active tenant DB alias from the session for each request."""

from __future__ import annotations

import logging
import time

from django.conf import settings
from django.core.cache import cache

from api.tenant.exceptions import InvalidTenantDatabase
from api.tenant.services import ACTIVE_TENANT_SESSION_KEY, TenantMembershipService, TenantService
from config.tenant_cache import (
    reset_active_tenant_cache_ns,
    set_active_tenant_cache_ns,
)
from config.tenant_db import (
    ensure_tenant_connection,
    reset_active_tenant_db,
    set_active_tenant_db,
)

logger = logging.getLogger(__name__)

_MEMBERSHIP_CACHE_TTL = 30


def _cache_key(*parts) -> str:
    prefix = getattr(settings, "CACHE_MIDDLEWARE_KEY_PREFIX", "scrm")
    return ":".join([prefix, "tenant", *(str(p) for p in parts)])


class TenantDatabaseMiddleware:
    """Load the active tenant from the session and bind its database alias.

    Membership is re-checked here rather than trusted from login, so revoking a
    membership takes effect within ``_MEMBERSHIP_CACHE_TTL`` instead of lasting
    for the life of the session.

    When a tenant is bound, the cache key namespace is set for the same scope so
    ``cache_page`` and other cache ops cannot collide across tenants.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.tenant = None
        db_token = set_active_tenant_db(None)
        cache_token = set_active_tenant_cache_ns(None)
        try:
            self._bind_tenant(request)
            return self.get_response(request)
        finally:
            reset_active_tenant_db(db_token)
            reset_active_tenant_cache_ns(cache_token)
            request.tenant = None

    def _bind_tenant(self, request) -> None:
        user = getattr(request, "user", None)
        if user is None or not getattr(user, "is_authenticated", False):
            return

        session = getattr(request, "session", None)
        if session is None:
            return

        absolute_expiry = session.get("absolute_expiry")
        if absolute_expiry is not None and time.time() > absolute_expiry:
            return

        tenant_uuid = session.get(ACTIVE_TENANT_SESSION_KEY)
        if not tenant_uuid:
            return

        tenant = TenantService.get_usable(tenant_uuid, use_cache=True)
        if tenant is None:
            logger.warning("Active tenant %s missing or inactive; clearing session key", tenant_uuid)
            session.pop(ACTIVE_TENANT_SESSION_KEY, None)
            return

        if not self._has_membership(user, tenant):
            logger.warning(
                "User %s has no effective membership in tenant %s; clearing session key",
                getattr(user, "pk", None),
                tenant_uuid,
            )
            session.pop(ACTIVE_TENANT_SESSION_KEY, None)
            return

        try:
            set_active_tenant_db(ensure_tenant_connection(tenant))
        except InvalidTenantDatabase:
            logger.exception("Cannot bind database for tenant %s", tenant_uuid)
            return
        set_active_tenant_cache_ns(tenant)
        request.tenant = tenant

    def _has_membership(self, user, tenant) -> bool:
        key = _cache_key("membership", user.pk, tenant.pk)
        cached = cache.get(key)
        if cached is not None:
            return cached

        allowed = TenantMembershipService.can_access(user, tenant)
        cache.set(key, allowed, timeout=_MEMBERSHIP_CACHE_TTL)
        return allowed
