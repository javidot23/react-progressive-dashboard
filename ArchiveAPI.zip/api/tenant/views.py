from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from drf_spectacular.utils import extend_schema
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from api.audit.choices import AuditEventType
from api.audit.services import AuditService
from api.tenant.exceptions import ActiveTenantRequired
from api.tenant.serializers import (
    SetActiveTenantSerializer,
    TenantContextSerializer,
    TenantListSerializer,
)
from api.tenant.services import TenantMembershipService
from config.tenant_db import use_tenant_db


@method_decorator(never_cache, name="dispatch")
class TenantListView(APIView):
    """GET /api/tenants/"""

    @extend_schema(responses=TenantListSerializer(many=True))
    def get(self, request):
        tenants = TenantMembershipService.list_tenants_for_user(request.user)
        return Response(TenantListSerializer(tenants, many=True).data)


@method_decorator(never_cache, name="dispatch")
class TenantActiveView(APIView):
    """POST /api/tenant/active/"""

    @extend_schema(
        request=SetActiveTenantSerializer,
        responses=TenantContextSerializer,
    )
    def post(self, request):
        serializer = SetActiveTenantSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        tenant = TenantMembershipService.set_active(
            request.user,
            request.session,
            serializer.validated_data["tenant_uuid"],
        )
        with use_tenant_db(tenant):
            request.tenant = tenant
            AuditService.record_from_request(
                request,
                AuditEventType.TENANT_SELECTED,
                tenant=tenant,
                status=status.HTTP_200_OK,
                target_entity={"type": "tenant", "id": str(tenant.pk)},
            )
            return Response(TenantContextSerializer(tenant).data, status=status.HTTP_200_OK)


@method_decorator(never_cache, name="dispatch")
class TenantContextView(APIView):
    """GET /api/tenant/context/"""

    @extend_schema(responses=TenantContextSerializer)
    def get(self, request):
        tenant = getattr(request, "tenant", None)
        if tenant is None:
            tenant = TenantMembershipService.get_active(request.user, request.session)
        if tenant is None:
            AuditService.record_from_request(
                request,
                AuditEventType.ACCESS_DENIED,
                reason_code="tenant_required",
                status=status.HTTP_403_FORBIDDEN,
            )
            raise ActiveTenantRequired()
        return Response(TenantContextSerializer(tenant).data)
