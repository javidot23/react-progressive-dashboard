from django.db.models import Q
from django_filters import rest_framework as filters

from .models import Tenant


class TenantFilter(filters.FilterSet):
    search = filters.CharFilter(method="filter_search")

    class Meta:
        model = Tenant
        fields = ["tenant_type", "entitlement_tier", "is_federated", "is_active"]

    def filter_search(self, queryset, name, value):
        return queryset.filter(
            Q(tenant_code__icontains=value) | Q(tenant_name__icontains=value)
        )
