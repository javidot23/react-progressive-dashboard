"""HTTP exceptions for tenant binding and database availability."""

from rest_framework.exceptions import APIException


class ActiveTenantRequired(APIException):
    """Raised when tenant-scoped data is queried with no active tenant bound."""

    status_code = 403
    default_code = "tenant_required"
    default_detail = "An active tenant is required. Select a tenant and retry."


class InvalidTenantDatabase(APIException):
    """Raised when a tenant row's database coordinates are unusable."""

    status_code = 503
    default_code = "tenant_database_unavailable"
    default_detail = "The tenant database is not correctly configured."
