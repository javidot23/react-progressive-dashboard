from django.db import models


class TenantType(models.TextChoices):
    CUSTOMER = "customer", "Customer"
    VENDOR = "vendor", "Vendor"
    CUSTOMER_VENDOR = "customer_vendor", "Customer/Vendor"


class EntitlementTier(models.TextChoices):
    STANDARD = "standard", "Standard"
    PREMIUM = "premium", "Premium"
    PLATINUM = "platinum", "Platinum"
