import logging
from typing import Optional

from api.user.models import User
from api.user_feedback.models import UserFeedback

logger = logging.getLogger(__name__)


class UserFeedbackService:

    @staticmethod
    def get_filter_options() -> dict:
        qs = UserFeedback.objects.all()

        statuses = list(
            qs.exclude(status__isnull=True)
            .exclude(status='')
            .values_list('status', flat=True)
            .distinct()
            .order_by('status')
        )

        modules = list(
            qs.exclude(module__isnull=True)
            .exclude(module='')
            .values_list('module', flat=True)
            .distinct()
            .order_by('module')
        )

        pages = list(
            qs.exclude(page__isnull=True)
            .exclude(page='')
            .values_list('page', flat=True)
            .distinct()
            .order_by('page')
        )

        user_ids = qs.values_list('user_id', flat=True).distinct()
        users = list(
            User.objects.filter(pk__in=user_ids)
            .order_by('first_name', 'last_name')
        )

        return {
            'users': users,
            'statuses': statuses,
            'modules': modules,
            'pages': pages,
        }

    @staticmethod
    def create_feedback(
        user: User,
        feedback: Optional[str] = None,
        module: Optional[str] = None,
        page: Optional[str] = None,
        subtab: Optional[str] = None,
        screenshot: Optional[str] = None,
    ) -> UserFeedback:
        instance = UserFeedback.objects.create(
            user=user,
            feedback=feedback,
            module=module,
            page=page,
            subtab=subtab,
            screenshot=screenshot,
        )
        logger.info("Created feedback %s for user %s", instance.id, user.pk)
        return instance

    @staticmethod
    def update_feedback(
        instance: UserFeedback,
        feedback: Optional[str] = None,
        module: Optional[str] = None,
        page: Optional[str] = None,
        subtab: Optional[str] = None,
        status: Optional[str] = None,
        screenshot: Optional[str] = None,
    ) -> UserFeedback:
        if feedback is not None:
            instance.feedback = feedback
        if module is not None:
            instance.module = module
        if page is not None:
            instance.page = page
        if subtab is not None:
            instance.subtab = subtab
        if status is not None:
            instance.status = status
        if screenshot is not None:
            instance.screenshot = screenshot

        instance.save()
        logger.info("Updated feedback %s", instance.id)
        return instance

    @staticmethod
    def delete_feedback(instance: UserFeedback) -> None:
        feedback_id = instance.id
        instance.delete()
        logger.info("Deleted feedback %s", feedback_id)
