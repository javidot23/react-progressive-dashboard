from django.urls import path

from api.user_feedback.views import (
    UserFeedbackDetailView,
    UserFeedbackFilterOptionsView,
    UserFeedbackListCreateView,
)

app_name = 'user_feedback'

urlpatterns = [
    path('', UserFeedbackListCreateView.as_view(), name='list-create'),
    path('filters/', UserFeedbackFilterOptionsView.as_view(), name='filter-options'),
    path('<int:feedback_id>/', UserFeedbackDetailView.as_view(), name='detail'),
]
