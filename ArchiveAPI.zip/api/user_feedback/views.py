import logging

from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, status
from rest_framework.exceptions import NotFound
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.audit.choices import AuditEventType
from api.audit.services import AuditService
from api.user_feedback.models import UserFeedback
from api.user_feedback.serializers import (
    UserFeedbackCreateSerializer,
    UserFeedbackFilterOptionsSerializer,
    UserFeedbackSerializer,
    UserFeedbackUpdateSerializer,
)
from api.user_feedback.services import UserFeedbackService

logger = logging.getLogger(__name__)


class UserFeedbackListCreateView(generics.ListCreateAPIView):
    """
    GET: List feedback submitted by the authenticated user.
    POST: Submit new feedback.
    """

    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_fields = ['status', 'module', 'page', 'user']
    ordering_fields = ['created_at', 'updated_at', 'status']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return UserFeedbackCreateSerializer
        return UserFeedbackSerializer

    def get_queryset(self):
        return UserFeedback.objects.select_related('user').all()

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        instance = UserFeedbackService.create_feedback(
            user=request.user,
            **serializer.validated_data,
        )

        AuditService.record_from_request(
            request,
            AuditEventType.USER_FEEDBACK_CREATED,
            status=status.HTTP_201_CREATED,
            target_entity={"type": "user_feedback", "id": str(instance.id)},
            metadata={
                "module": getattr(instance, "module", None),
                "page": getattr(instance, "page", None),
                "status": getattr(instance, "status", None),
            },
        )
        return Response(UserFeedbackSerializer(instance).data, status=status.HTTP_201_CREATED)


class UserFeedbackDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: Retrieve a single feedback entry.
    PATCH: Update a feedback entry.
    DELETE: Delete a feedback entry.
    """

    lookup_field = 'id'
    lookup_url_kwarg = 'feedback_id'

    def get_serializer_class(self):
        if self.request.method == 'PATCH':
            return UserFeedbackUpdateSerializer
        return UserFeedbackSerializer

    def get_object(self):
        instance = UserFeedback.objects.filter(
            id=self.kwargs.get('feedback_id'),
        ).first()
        if not instance:
            raise NotFound("Feedback not found")
        return instance

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)

        instance = UserFeedbackService.update_feedback(
            instance=instance,
            **serializer.validated_data,
        )

        AuditService.record_from_request(
            request,
            AuditEventType.USER_FEEDBACK_UPDATED,
            status=status.HTTP_200_OK,
            target_entity={"type": "user_feedback", "id": str(instance.id)},
            metadata={
                "module": getattr(instance, "module", None),
                "page": getattr(instance, "page", None),
                "status": getattr(instance, "status", None),
            },
        )
        return Response(UserFeedbackSerializer(instance).data)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        UserFeedbackService.delete_feedback(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)


class UserFeedbackFilterOptionsView(APIView):
    """
    GET: Return distinct filter option values derived from existing feedback records,
    intended for populating frontend dropdown filters.
    """

    @extend_schema(responses=UserFeedbackFilterOptionsSerializer)
    def get(self, request, *args, **kwargs):
        data = UserFeedbackService.get_filter_options()
        serializer = UserFeedbackFilterOptionsSerializer(data)
        return Response(serializer.data)
