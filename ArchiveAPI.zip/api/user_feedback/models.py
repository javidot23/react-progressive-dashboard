from django.db import models

from api.user.models import User

from .choices import FeedbackStatus


class UserFeedback(models.Model):
    """
    Model to store user feedback.
    """

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="feedback")
    feedback = models.TextField(blank=True, null=True)
    module = models.CharField(max_length=255, blank=True, null=True)
    page = models.CharField(max_length=255, blank=True, null=True)
    subtab = models.CharField(max_length=255, blank=True, null=True)
    status = models.CharField(
        max_length=255,
        choices=FeedbackStatus.choices,
        default=FeedbackStatus.OPEN,
    )
    screenshot = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "user_feedback"
        app_label = "user_feedback"
        verbose_name = "User Feedback"
        verbose_name_plural = "User Feedback"
        indexes = [
            models.Index(fields=["user_id"]),
            models.Index(fields=["status"]),
            models.Index(fields=["created_at"]),
        ]
