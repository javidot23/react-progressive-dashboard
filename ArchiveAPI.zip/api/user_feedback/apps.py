from django.apps import AppConfig

from config.db_scope import DBScope


class UserFeedbackConfig(AppConfig):
    name = 'api.user_feedback'
    db_scope = DBScope.CORE
