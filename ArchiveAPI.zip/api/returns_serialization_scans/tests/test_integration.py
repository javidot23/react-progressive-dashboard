from datetime import timedelta

from django.urls import reverse
from django.utils import timezone
from rest_framework import status

from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class WeeklyScanHistoryViewTest(BaseAPITestCase):

    def setUp(self):
        self.url = reverse("returns_serialization_scans:weekly-history")
        self.now = timezone.now()
        self.material = TestDataFactory.create_material()

        TestDataFactory.create_returns_serialization_scan(
            material=self.material,
            req_created_date=self.now - timedelta(days=5),
            pass_fail_status="Success",
        )
        TestDataFactory.create_returns_serialization_scan(
            material=self.material,
            req_created_date=self.now - timedelta(days=6),
            pass_fail_status="Error",
            scan_status="Lot Error",
        )
        # Outside default window
        TestDataFactory.create_returns_serialization_scan(
            material=self.material,
            req_created_date=self.now - timedelta(days=100),
            pass_fail_status="Success",
        )

    def test_returns_200(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_response_structure(self):
        """Test that each item has the expected fields."""
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(len(response.data), 0)
        item = response.data[0]
        for field in ("week_start", "total_scans", "successful_scans", "success_rate"):
            self.assertIn(field, item)

    def test_default_window_excludes_old_records(self):
        """Test that the default 90-day window excludes scans older than 90 days."""
        response = self.client.get(self.url)
        total = sum(item["total_scans"] for item in response.data)
        self.assertEqual(total, 2)

    def test_days_param_narrows_window(self):
        """Test that ?days=2 returns no scans (scans are at day 5 and 6)."""
        response = self.client.get(self.url, {"days": 2})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        total = sum(item["total_scans"] for item in response.data)
        self.assertEqual(total, 0)

    def test_invalid_days_falls_back_to_default(self):
        """Test that a non-integer days value returns 200 using the 90-day default."""
        response = self.client.get(self.url, {"days": "abc"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
