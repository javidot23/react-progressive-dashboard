from django.urls import path

from .views import WeeklyScanHistoryView

app_name = "returns_serialization_scans"

urlpatterns = [
    path("weekly-history/", WeeklyScanHistoryView.as_view(), name="weekly-history"),
]
