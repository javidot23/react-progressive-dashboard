from django.apps import AppConfig


class ReturnsSerializationScansConfig(AppConfig):
    name = 'api.returns_serialization_scans'
