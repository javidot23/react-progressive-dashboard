import math


class NanSafeSerializerMixin:
    """
    Mixin for DRF serializers that converts NaN and Inf float values to None
    during serialization. This prevents the ValueError:
    'Out of range float values are not JSON compliant: nan'

    Usage:
        class MySerializer(NanSafeSerializerMixin, serializers.ModelSerializer):
            ...
    """

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return self._sanitize_floats(data)

    @staticmethod
    def _sanitize_floats(data):
        """Recursively replace NaN/Inf float values with None."""
        if isinstance(data, dict):
            return {
                key: NanSafeSerializerMixin._sanitize_floats(value)
                for key, value in data.items()
            }
        if isinstance(data, list):
            return [
                NanSafeSerializerMixin._sanitize_floats(item)
                for item in data
            ]
        if isinstance(data, float) and (math.isnan(data) or math.isinf(data)):
            return None
        return data
