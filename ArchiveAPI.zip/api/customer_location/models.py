from django.db import models

from api.customer_business_unit.models import CustomerBusinessUnit


class CustomerLocation(models.Model):
    # Level 2 Customer Location
    cust_location_nbr = models.CharField(max_length=255, unique=True)  # Customer location number from DBX
    name = models.CharField(max_length=255, null=True, blank=True)
    cust_bus_unit_nbr = models.ForeignKey(
        CustomerBusinessUnit,
        to_field="cust_bus_unit_nbr",
        db_column="cust_bus_unit_nbr",
        on_delete=models.CASCADE,
        null=True,
    )
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    class Meta:
        db_table = "customer_locations"
        verbose_name = "Customer Location"
        verbose_name_plural = "Customer Locations"
        indexes = [
            models.Index(fields=["cust_location_nbr"]),
            models.Index(fields=["cust_bus_unit_nbr"])
        ]
