from django.apps import AppConfig


class CustomerLocationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.customer_location'
