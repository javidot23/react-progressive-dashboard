from django.apps import AppConfig


class RiskModelDescriptionConfig(AppConfig):
    name = 'api.risk_model_description'
