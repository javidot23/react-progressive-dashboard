from rest_framework import serializers

from api.risk_model_description.models import RiskModelDescription


class RiskModelDescriptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = RiskModelDescription
        fields = '__all__'
        read_only_fields = ('created_at', 'updated_at')
