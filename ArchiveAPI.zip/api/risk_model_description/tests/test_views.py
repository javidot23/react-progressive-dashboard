from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient

from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class RiskModelDescriptionViewsTest(BaseTestCase):
    """Integration tests for Risk Model Description API endpoints."""

    def setUp(self):
        self.client = APIClient()

    def test_list_view_empty(self):
        """Test listing risk model descriptions when empty."""
        url = reverse("risk_model_description:risk-model-description-list")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertEqual(len(response.data), 0)

    def test_list_view_with_data(self):
        """Test listing all risk model descriptions."""
        # Create test data
        risk_model_1 = TestDataFactory.create_risk_model_description(
            model_name="test_model_1",
            model_type="base_model_operational",
            display_name="Test Model 1"
        )
        risk_model_2 = TestDataFactory.create_risk_model_description(
            model_name="test_model_2",
            model_type="base_model_location",
            display_name="Test Model 2"
        )

        url = reverse("risk_model_description:risk-model-description-list")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertEqual(len(response.data), 2)

        # Check that all fields are present
        model_names = [item["model_name"] for item in response.data]
        self.assertIn(risk_model_1.model_name, model_names)
        self.assertIn(risk_model_2.model_name, model_names)

        # Check response structure
        first_item = response.data[0]
        self.assertIn("model_name", first_item)
        self.assertIn("model_type", first_item)
        self.assertIn("model_description", first_item)
        self.assertIn("display_name", first_item)
        self.assertIn("created_at", first_item)
        self.assertIn("updated_at", first_item)

    def test_list_view_returns_all_records(self):
        """Test that list view returns all records without pagination."""
        # Create multiple records
        count = 5
        created_models = []
        for i in range(count):
            model = TestDataFactory.create_risk_model_description(
                model_name=f"test_model_{i}",
                model_type="base_model_operational",
                display_name=f"Test Model {i}"
            )
            created_models.append(model)

        url = reverse("risk_model_description:risk-model-description-list")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertEqual(len(response.data), count)

        # Verify all created models are in the response
        response_model_names = {item["model_name"] for item in response.data}
        created_model_names = {model.model_name for model in created_models}
        self.assertEqual(response_model_names, created_model_names)
