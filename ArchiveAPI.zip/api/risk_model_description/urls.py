from django.urls import path

from api.risk_model_description.views import RiskModelDescriptionListView

app_name = "risk_model_description"

urlpatterns = [
    path("", RiskModelDescriptionListView.as_view(), name="risk-model-description-list"),
]
