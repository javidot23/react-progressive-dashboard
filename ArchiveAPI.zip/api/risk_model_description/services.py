import logging

from api.risk_model_description.models import RiskModelDescription

logger = logging.getLogger(__name__)


class RiskModelDescriptionService:
    @staticmethod
    def get_all_risk_model_descriptions():
        """
        Retrieve all risk model descriptions.
        """
        logger.info("Retrieving all risk model descriptions")
        return RiskModelDescription.objects.all()
