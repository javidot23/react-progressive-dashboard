from django.db import models


class RiskModelDescription(models.Model):
    """
    Model to represent risk model description.
    """
    model_name = models.CharField(max_length=255, unique=True)
    model_description = models.TextField(blank=True, null=True)
    model_type = models.CharField(max_length=255)
    display_name = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "risk_model_descriptions"
        verbose_name = "Risk Model Description"
        verbose_name_plural = "Risk Model Descriptions"
