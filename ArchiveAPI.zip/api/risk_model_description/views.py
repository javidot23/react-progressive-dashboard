from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.risk_model_description.serializers import RiskModelDescriptionSerializer
from api.risk_model_description.services import RiskModelDescriptionService


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class RiskModelDescriptionListView(APIView):
    """
    API view to retrieve all risk model descriptions without pagination.
    """

    @extend_schema(responses=RiskModelDescriptionSerializer(many=True))
    def get(self, request):
        """Retrieve all risk model descriptions."""
        risk_model_descriptions = RiskModelDescriptionService.get_all_risk_model_descriptions()
        serializer = RiskModelDescriptionSerializer(risk_model_descriptions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
