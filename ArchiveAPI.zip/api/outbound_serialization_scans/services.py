import logging
from datetime import date, timedelta

from django.db.models import Count, ExpressionWrapper, F, FloatField, Q, Value
from django.db.models.functions import Coalesce, NullIf, TruncWeek

from .models import OutboundSerializationScan

logger = logging.getLogger(__name__)


class OutboundSerializationScanService:

    @staticmethod
    def get_weekly_scan_history(days: int = 90, direct_mat_nbr: str = None, mat_nbr_subquery=None):
        since = date.today() - timedelta(days=days)
        logger.info("Retrieving outbound weekly scan history for last %d days (since %s)", days, since)
        qs = OutboundSerializationScan.objects.filter(req_created_date__date__gte=since)
        if direct_mat_nbr:
            qs = qs.filter(material=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__in=mat_nbr_subquery)
        return (
            qs
            .annotate(week_start=TruncWeek("req_created_date"))
            .values("week_start")
            .annotate(
                total_scans=Count("req_epc_cd", distinct=True, filter=Q(resp_error_cd_to_dc__in=["0000", "2015"])),
                successful_scans=Count("req_epc_cd", distinct=True, filter=Q(resp_error_cd_to_dc="0000")),
            )
            .annotate(
                success_rate=Coalesce(
                    ExpressionWrapper(
                        F("successful_scans") * 100.0 / NullIf(F("total_scans"), 0),
                        output_field=FloatField(),
                    ),
                    Value(0.0),
                    output_field=FloatField(),
                )
            )
            .order_by("week_start")
        )
