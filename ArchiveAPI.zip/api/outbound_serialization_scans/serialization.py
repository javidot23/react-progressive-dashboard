from rest_framework import serializers


class WeeklyScanHistorySerializer(serializers.Serializer):
    week_start = serializers.DateTimeField()
    total_scans = serializers.IntegerField()
    successful_scans = serializers.IntegerField()
    success_rate = serializers.FloatField()

    class Meta:
        ref_name = 'OutboundWeeklyScanHistory'
