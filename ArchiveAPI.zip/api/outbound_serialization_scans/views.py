from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.global_filters import get_filtered_material_subquery
from .serialization import WeeklyScanHistorySerializer
from .services import OutboundSerializationScanService


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyScanHistoryView(APIView):
    """
    GET /outbound-serialization-scans/weekly-history/

    Returns weekly scan counts and success rates over a configurable lookback window.

    Query params:
        days (int, default 90): lookback window in days
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=WeeklyScanHistorySerializer(many=True))
    def get(self, request):
        p = request.query_params
        try:
            days = int(p.get("days", 90))
        except (ValueError, TypeError):
            days = 90
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = OutboundSerializationScanService.get_weekly_scan_history(
            days=days,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = WeeklyScanHistorySerializer(data, many=True)
        return Response(serializer.data)
