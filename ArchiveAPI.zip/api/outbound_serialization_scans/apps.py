from django.apps import AppConfig


class OutboundSerializationScansConfig(AppConfig):
    name = 'api.outbound_serialization_scans'
