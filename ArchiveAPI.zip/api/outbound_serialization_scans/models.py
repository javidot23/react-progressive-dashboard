from django.db import models

from api.material.models import Material


class OutboundSerializationScan(models.Model):
    material = models.ForeignKey(
        Material,
        on_delete=models.CASCADE,
        to_field="mat_nbr",
        db_column="mat_nbr",
        related_name="outbound_serialization_scans",
    )
    req_po_nbr = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="req_po_nbr"
    )
    req_invc_nbr = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="req_invc_nbr"
    )
    req_created_date = models.DateTimeField(
        null=True,
        blank=True,
        db_column="req_created_date"
    )
    pass_fail_status = models.CharField(
        max_length=50,
        null=True,
        blank=True,
        db_column="pass_fail_status"
    )
    scan_status = models.CharField(
        max_length=100,
        null=True,
        blank=True,
        db_column="scan_status"
    )
    req_guid = models.CharField(
        max_length=255,
        unique=True,
        db_column="req_guid",
        null=True
    )
    req_epc_cd = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="req_epc_cd",
    )
    resp_error_cd_to_dc = models.CharField(
        max_length=10,
        null=True,
        blank=True,
        db_column="resp_error_cd_to_dc",
    )
    resp_response_cd = models.CharField(
        max_length=10,
        null=True,
        blank=True,
        db_column="resp_response_cd",
    )
    req_request_type = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="req_request_type",
    )
    req_mode_of_entry = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="req_mode_of_entry",
    )
    req_event_type = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="req_event_type",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "outbound_serialization_scans"
        verbose_name = "Outbound Serialization Scan"
        verbose_name_plural = "Outbound Serialization Scans"
        indexes = [
            models.Index(fields=["req_created_date"]),
            models.Index(fields=["pass_fail_status", "req_created_date"]),
            models.Index(fields=["resp_error_cd_to_dc", "req_created_date"]),
            models.Index(fields=["material"]),
            models.Index(fields=["req_epc_cd"]),
        ]
