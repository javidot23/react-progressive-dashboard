from datetime import timedelta

from django.utils import timezone

from api.outbound_serialization_scans.services import OutboundSerializationScanService
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class WeeklyScanHistoryServiceTest(BaseTestCase):

    def setUp(self):
        self.now = timezone.now()
        self.material = TestDataFactory.create_material()

        # Anchor to a fully-elapsed week so scan1/scan2 always share the same
        # TruncWeek bucket, regardless of what weekday "now" happens to be.
        previous_week_monday = self.now - timedelta(days=self.now.isoweekday() + 6)
        self.scan1_date = previous_week_monday
        scan2_date = previous_week_monday + timedelta(days=1)

        self.scan1 = TestDataFactory.create_outbound_serialization_scan(
            material=self.material,
            req_created_date=self.scan1_date,
            pass_fail_status="Success",
            scan_status="Serialization Passed",
            req_epc_cd="EPC-OUT-001",
        )
        self.scan2 = TestDataFactory.create_outbound_serialization_scan(
            material=self.material,
            req_created_date=scan2_date,
            pass_fail_status="Error",
            scan_status="Lot Error",
            req_epc_cd="EPC-OUT-002",
            resp_error_cd_to_dc="2015",
        )
        # Scan outside default 90-day window
        self.old_scan = TestDataFactory.create_outbound_serialization_scan(
            material=self.material,
            req_created_date=self.now - timedelta(days=100),
            pass_fail_status="Success",
            req_epc_cd="EPC-OUT-003",
        )

    def test_returns_scans_within_window(self):
        """Test that only scans within the window are returned."""
        results = list(OutboundSerializationScanService.get_weekly_scan_history(days=90))
        total = sum(r["total_scans"] for r in results)
        self.assertEqual(total, 2)

    def test_excludes_scans_outside_window(self):
        """Test that the old scan is excluded."""
        results = list(OutboundSerializationScanService.get_weekly_scan_history(days=90))
        total = sum(r["total_scans"] for r in results)
        self.assertEqual(total, 2)

    def test_narrow_days_excludes_all(self):
        """Test that a very narrow window excludes all scans."""
        results = list(OutboundSerializationScanService.get_weekly_scan_history(days=2))
        total = sum(r["total_scans"] for r in results)
        self.assertEqual(total, 0)

    def test_successful_scan_counted(self):
        """Test that successful_scans counts only Success records."""
        results = list(OutboundSerializationScanService.get_weekly_scan_history(days=90))
        total_successful = sum(r["successful_scans"] for r in results)
        self.assertEqual(total_successful, 1)

    def test_success_rate_calculated(self):
        """Test that success_rate is computed correctly (50%)."""
        results = list(OutboundSerializationScanService.get_weekly_scan_history(days=90))
        total_success_rate = sum(r["success_rate"] for r in results)
        self.assertAlmostEqual(total_success_rate, 50.0, places=1)

    def test_ordered_by_week_start_ascending(self):
        """Test that results are ordered ascending by week_start."""
        TestDataFactory.create_outbound_serialization_scan(
            material=self.material,
            req_created_date=self.now - timedelta(days=30),
        )
        results = list(OutboundSerializationScanService.get_weekly_scan_history(days=90))
        week_starts = [r["week_start"] for r in results]
        self.assertEqual(week_starts, sorted(week_starts))

    def test_duplicate_epc_counted_once(self):
        """Two rows with the same req_epc_cd should count as one distinct item."""
        TestDataFactory.create_outbound_serialization_scan(
            material=self.material,
            req_created_date=self.scan1_date,
            pass_fail_status="Success",
            req_epc_cd="EPC-OUT-001",
        )
        results = list(OutboundSerializationScanService.get_weekly_scan_history(days=90))
        total = sum(r["total_scans"] for r in results)
        self.assertEqual(total, 2)
