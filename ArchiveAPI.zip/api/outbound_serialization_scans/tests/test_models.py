from django.utils import timezone

from api.outbound_serialization_scans.models import OutboundSerializationScan
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class OutboundSerializationScanModelTest(BaseTestCase):

    def setUp(self):
        self.material = TestDataFactory.create_material()
        self.now = timezone.now()

    def test_creation(self):
        """Test basic creation with all fields."""
        scan = OutboundSerializationScan.objects.create(
            material=self.material,
            req_po_nbr="PO123456",
            req_invc_nbr="INV123456",
            req_created_date=self.now,
            pass_fail_status="Success",
            scan_status="Serialization Passed",
        )
        self.assertEqual(scan.material, self.material)
        self.assertEqual(scan.req_po_nbr, "PO123456")
        self.assertEqual(scan.req_invc_nbr, "INV123456")
        self.assertEqual(scan.pass_fail_status, "Success")
        self.assertEqual(scan.scan_status, "Serialization Passed")

    def test_nullable_fields_default_to_none(self):
        """Test that optional fields are nullable."""
        scan = OutboundSerializationScan.objects.create(material=self.material)
        self.assertIsNone(scan.req_po_nbr)
        self.assertIsNone(scan.req_invc_nbr)
        self.assertIsNone(scan.req_created_date)
        self.assertIsNone(scan.pass_fail_status)
        self.assertIsNone(scan.scan_status)

    def test_material_cascade_delete(self):
        """Test that deleting a material deletes its scans."""
        scan = TestDataFactory.create_outbound_serialization_scan(material=self.material)
        scan_id = scan.id
        self.material.delete()
        self.assertFalse(OutboundSerializationScan.objects.filter(id=scan_id).exists())
