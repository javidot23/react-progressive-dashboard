from django.db import models

from api.issue.models import Issue


class PotentialAction(models.Model):
    paction_nbr = models.CharField(max_length=255, verbose_name="Potential Action Number", unique=True)
    issue_nbr = models.ForeignKey(
        Issue,
        to_field="issue_nbr",
        db_column="issue_nbr",
        on_delete=models.CASCADE,
        related_name="potential_actions",
        verbose_name="Issue",
        null=True,
        blank=True,
        default=None,
    )
    action_type = models.CharField(max_length=255, null=True, blank=True)
    recommendation = models.CharField(max_length=255, null=True, blank=True)
    recommendation_type_nbr = models.CharField(max_length=255, null=True, blank=True)
    recommended_action_flag = models.CharField(max_length=255, null=True, blank=True)
    status = models.CharField(max_length=255, null=True, blank=True)
    module = models.CharField(max_length=255, null=True, blank=True)
    action_category = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        db_table = "potential_action"
        verbose_name = "Potential Action"
        verbose_name_plural = "Potential Actions"
        indexes = [
            models.Index(fields=["paction_nbr"]),
            models.Index(fields=["issue_nbr"])
        ]
