from django.apps import AppConfig


class PotentialActionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.potential_action'
