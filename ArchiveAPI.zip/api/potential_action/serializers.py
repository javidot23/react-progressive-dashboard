from rest_framework import serializers

from .models import PotentialAction


class PotentialActionSerializer(serializers.ModelSerializer):
    issue_nbr = serializers.CharField(source='issue_nbr_id', read_only=True)

    class Meta:
        model = PotentialAction
        fields = '__all__'
