import uuid

from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.db import models

from api.common.models import TimestampedModel

from .choices import AuthProvider, TenantAccessScope, UserStatus


class UserManager(BaseUserManager):
    use_in_migrations = True

    def create_user(self, display_name="", **extra_fields):
        user = self.model(display_name=display_name, **extra_fields)
        user.set_unusable_password()
        user.save(using=self._db)
        return user

    def create_superuser(self, display_name="", **extra_fields):
        extra_fields.setdefault("is_platform_admin", True)
        extra_fields.setdefault("status", UserStatus.ACTIVE)
        return self.create_user(display_name=display_name, **extra_fields)


class User(AbstractBaseUser, TimestampedModel):
    user_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    status = models.CharField(
        max_length=30, choices=UserStatus.choices, default=UserStatus.PENDING_VERIFICATION
    )
    display_name = models.CharField(max_length=255)
    first_name = models.CharField(max_length=150, blank=True)
    last_name = models.CharField(max_length=150, blank=True)
    job_title = models.CharField(max_length=150, blank=True)
    department = models.CharField(max_length=100, blank=True)
    is_platform_admin = models.BooleanField(default=False)
    tenant_access_scope = models.CharField(
        max_length=20,
        choices=TenantAccessScope.choices,
        default=TenantAccessScope.TENANT,
    )
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    objects = UserManager()

    USERNAME_FIELD = "user_uuid"
    REQUIRED_FIELDS = []

    class Meta:
        db_table = "user"
        constraints = [
            models.CheckConstraint(condition=models.Q(status__in=UserStatus.values), name="user_status_valid"),
            models.CheckConstraint(
                condition=models.Q(tenant_access_scope__in=TenantAccessScope.values),
                name="user_tenant_access_scope_valid",
            ),
        ]

    def __str__(self):
        return self.display_name

    @property
    def is_active(self) -> bool:
        """Only ACTIVE users may authenticate against this portal."""
        return self.status == UserStatus.ACTIVE

    def _primary_identity(self):
        identities = getattr(self, "_prefetched_objects_cache", {}).get("identities")
        if identities is not None:
            for identity in identities:
                if identity.is_primary and not identity.is_deleted:
                    return identity
            return next((i for i in identities if not i.is_deleted), None)
        return (
            self.identities.filter(is_primary=True, is_deleted=False).first()
            or self.identities.filter(is_deleted=False).first()
        )

    @property
    def email(self) -> str:
        identity = self._primary_identity()
        return identity.email if identity else ""

    @property
    def entra_id(self) -> str:
        return str(self.pk)

    @property
    def auth_subject(self) -> str | None:
        identity = self._primary_identity()
        return identity.auth_subject if identity else None


class UserIdentity(TimestampedModel):
    user_identity_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="identities", db_column="user_uuid")
    username = models.CharField(max_length=150, unique=True, null=True, blank=True)
    email = models.EmailField(unique=True)
    auth_provider = models.CharField(max_length=20, choices=AuthProvider.choices)
    auth_subject = models.CharField(max_length=255, null=True, blank=True)
    is_primary = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)
    last_login_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "user_identity"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(auth_provider__in=AuthProvider.values), name="user_identity_auth_provider_valid"
            ),
            models.UniqueConstraint(
                fields=["auth_provider", "auth_subject"], name="user_identity_provider_subject_unique"
            ),
        ]

    def __str__(self):
        return f"{self.email} ({self.auth_provider})"
