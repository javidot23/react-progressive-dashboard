from unittest.mock import patch, MagicMock

from django.test import override_settings
from django.urls import reverse
from rest_framework import status

from tests.BaseTestCase import BaseAPITestCase, BaseTestCase
from tests.TestDataFactory import TestDataFactory


class UserProfileTest(BaseAPITestCase):
    def setUp(self):
        self.user = TestDataFactory.create_test_user(
            entra_id="user_1234",
            email="john.doe@test.com",
            first_name="John",
            last_name="Doe",
        )
        self.url = reverse("user:user-profile")

    def test_user_profile_unauthenticated(self):
        response = self.client.get(self.url, HTTP_X_DISABLE_TEST_AUTH="1")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_user_profile_returns_db_data(self):
        self.client.force_authenticate(user=self.user, token="fake-token")

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.data
        self.assertEqual(data["id"], str(self.user.entra_id))
        self.assertEqual(data["displayName"], "John Doe")
        self.assertEqual(data["mail"], self.user.email)
        self.assertEqual(data["givenName"], self.user.first_name)
        self.assertEqual(data["surname"], self.user.last_name)
        self.assertEqual(data["userPrincipalName"], self.user.email)
        self.assertEqual(data["jobTitle"], "N/A")
        self.assertIn("department", data)
        self.assertIn("profilePicture", data)

    def test_user_profile_response_format(self):
        self.client.force_authenticate(user=self.user, token="fake-token")

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        expected_keys = {"id", "displayName", "mail", "givenName", "surname", "userPrincipalName", "jobTitle",
                         "department", "profilePicture"}
        self.assertEqual(set(response.data.keys()), expected_keys)


@override_settings(
    SAP_CDC_ISSUER="https://test.aaas.cencora.com/oidc/op/v1.0/test",
    SAP_CDC_CLIENT_ID="test_client_id",
    SAP_CDC_USERINFO_URL="https://test.aaas.cencora.com/oidc/op/v1.0/test/userinfo",
)
class SapCdcProfileSyncTest(BaseAPITestCase):
    """Tests for SAP CDC profile sync on /auth/me/?sync=true"""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(
            entra_id="sap-cdc-user-123",
            email="sap.user@test.com",
            first_name="Sap",
            last_name="User",
        )
        self.url = reverse("user:user-profile")

    def test_sync_without_access_token_returns_db_data(self):
        """When no X-SAP-Access-Token header, sync should still return user data"""
        self.client.force_authenticate(user=self.user, token="fake-id-token")

        response = self.client.get(f"{self.url}?sync=true")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["id"], str(self.user.entra_id))
        self.assertEqual(response.data["mail"], self.user.email)

    def test_sync_with_access_token_calls_sap_cdc_userinfo(self):
        """When X-SAP-Access-Token header present, should fetch from SAP CDC"""
        sap_userinfo = {
            "sub": self.user.auth_subject,
            "email": "updated.sap@test.com",
            "given_name": "UpdatedSap",
            "family_name": "UpdatedUser",
        }

        with patch("api.user.services.UserService.get_user_profile_from_sap_cdc", return_value=sap_userinfo):
            self.client.force_authenticate(user=self.user, token="fake-id-token")

            response = self.client.get(
                f"{self.url}?sync=true",
                HTTP_X_SAP_ACCESS_TOKEN="fake-access-token"
            )

            self.assertEqual(response.status_code, status.HTTP_200_OK)
            self.user.refresh_from_db()
            self.assertEqual(self.user.email, "updated.sap@test.com")
            self.assertEqual(self.user.first_name, "UpdatedSap")
            self.assertEqual(self.user.last_name, "UpdatedUser")

    def test_sync_updates_only_changed_fields(self):
        """Should only update fields that are different"""
        sap_userinfo = {
            "sub": self.user.auth_subject,
            "email": "new.email@test.com",
            "given_name": "Sap",  # Same as current
            "family_name": "User",  # Same as current
        }

        with patch("api.user.services.UserService.get_user_profile_from_sap_cdc", return_value=sap_userinfo):
            self.client.force_authenticate(user=self.user, token="fake-id-token")

            response = self.client.get(
                f"{self.url}?sync=true",
                HTTP_X_SAP_ACCESS_TOKEN="fake-access-token"
            )

            self.assertEqual(response.status_code, status.HTTP_200_OK)
            self.user.refresh_from_db()
            self.assertEqual(self.user.email, "new.email@test.com")
            self.assertEqual(self.user.first_name, "Sap")
            self.assertEqual(self.user.last_name, "User")

    def test_sync_handles_sap_cdc_api_failure(self):
        """When SAP CDC API fails, should return existing user data"""
        with patch("api.user.services.UserService.get_user_profile_from_sap_cdc", return_value=None):
            self.client.force_authenticate(user=self.user, token="fake-id-token")

            response = self.client.get(
                f"{self.url}?sync=true",
                HTTP_X_SAP_ACCESS_TOKEN="fake-access-token"
            )

            self.assertEqual(response.status_code, status.HTTP_200_OK)
            self.assertEqual(response.data["mail"], self.user.email)

    def test_sync_does_not_update_when_no_changes(self):
        """When SAP CDC returns same data, no update should occur"""
        sap_userinfo = {
            "sub": self.user.auth_subject,
            "email": self.user.email,
            "given_name": self.user.first_name,
            "family_name": self.user.last_name,
        }

        with patch("api.user.services.UserService.get_user_profile_from_sap_cdc", return_value=sap_userinfo):
            self.client.force_authenticate(user=self.user, token="fake-id-token")

            response = self.client.get(
                f"{self.url}?sync=true",
                HTTP_X_SAP_ACCESS_TOKEN="fake-access-token"
            )

            self.assertEqual(response.status_code, status.HTTP_200_OK)
            self.user.refresh_from_db()
            self.assertEqual(self.user.email, "sap.user@test.com")

    def test_sync_rejects_mismatched_sub(self):
        """Token for a different user must not overwrite this session user's profile."""
        sap_userinfo = {
            "sub": "someone-else",
            "email": "attacker@test.com",
            "given_name": "Attacker",
            "family_name": "User",
        }

        with patch("api.user.services.UserService.get_user_profile_from_sap_cdc", return_value=sap_userinfo):
            self.client.force_authenticate(user=self.user, token="fake-id-token")

            response = self.client.get(
                f"{self.url}?sync=true",
                HTTP_X_SAP_ACCESS_TOKEN="fake-access-token",
            )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.user.refresh_from_db()
        self.assertEqual(self.user.email, "sap.user@test.com")
        self.assertEqual(self.user.first_name, "Sap")


@override_settings(
    SAP_CDC_USERINFO_URL="https://test.aaas.cencora.com/oidc/op/v1.0/test/userinfo",
)
class UserServiceSapCdcTest(BaseTestCase):
    """Tests for UserService.get_user_profile_from_sap_cdc"""

    def test_get_user_profile_returns_userinfo(self):
        """Should return user profile data from SAP CDC"""
        from api.user.services import UserService

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "sub": "user-123",
            "email": "test@example.com",
            "given_name": "Test",
            "family_name": "User",
        }

        with patch("api.user.services.requests.get", return_value=mock_response):
            result = UserService.get_user_profile_from_sap_cdc("fake-access-token")

            self.assertIsNotNone(result)
            self.assertEqual(result["email"], "test@example.com")
            self.assertEqual(result["given_name"], "Test")
            self.assertEqual(result["family_name"], "User")

    def test_get_user_profile_caches_result(self):
        """Should cache the result to avoid repeated API calls"""
        from api.user.services import UserService

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "email": "cached@example.com",
            "given_name": "Cached",
            "family_name": "User",
        }

        # Mock cache to verify caching behavior
        mock_cache_data = {}

        def mock_cache_get(key):
            return mock_cache_data.get(key)

        def mock_cache_set(key, value, timeout=None):
            mock_cache_data[key] = value

        with patch("api.user.services.requests.get", return_value=mock_response) as mock_get:
            with patch("api.user.services.cache.get", side_effect=mock_cache_get):
                with patch("api.user.services.cache.set", side_effect=mock_cache_set):
                    # First call - should call API and cache result
                    result1 = UserService.get_user_profile_from_sap_cdc("test-token")
                    self.assertEqual(result1["email"], "cached@example.com")
                    self.assertEqual(mock_get.call_count, 1)

                    # Verify data was cached
                    self.assertEqual(len(mock_cache_data), 1)

                    # Second call should use cache (mock returns cached value)
                    result2 = UserService.get_user_profile_from_sap_cdc("test-token")
                    self.assertEqual(result2["email"], "cached@example.com")
                    # API should still only be called once
                    self.assertEqual(mock_get.call_count, 1)

    def test_get_user_profile_returns_none_on_error(self):
        """Should return None when API call fails"""
        from api.user.services import UserService

        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.text = "Unauthorized"

        with patch("api.user.services.requests.get", return_value=mock_response):
            result = UserService.get_user_profile_from_sap_cdc("invalid-token")

            self.assertIsNone(result)

    def test_get_user_profile_returns_none_on_exception(self):
        """Should return None when an exception occurs"""
        from api.user.services import UserService

        with patch("api.user.services.requests.get", side_effect=Exception("Network error")):
            result = UserService.get_user_profile_from_sap_cdc("fake-token")

            self.assertIsNone(result)

    @override_settings(SAP_CDC_USERINFO_URL=None)
    def test_get_user_profile_returns_none_when_url_not_configured(self):
        """Should return None when SAP_CDC_USERINFO_URL is not configured"""
        from api.user.services import UserService

        result = UserService.get_user_profile_from_sap_cdc("fake-token")

        self.assertIsNone(result)

    def test_get_user_profile_sends_correct_auth_header(self):
        """Should send access token in Authorization header"""
        from api.user.services import UserService

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"email": "test@example.com"}

        with patch("api.user.services.requests.get", return_value=mock_response) as mock_get:
            UserService.get_user_profile_from_sap_cdc("my-access-token")

            mock_get.assert_called_once()
            call_kwargs = mock_get.call_args[1]
            self.assertEqual(call_kwargs["headers"]["Authorization"], "Bearer my-access-token")
