from rest_framework.exceptions import AuthenticationFailed

from api.tenant.models import TenantMembership
from api.tenant.services import TenantMembershipService
from api.user.choices import AuthProvider, TenantAccessScope, UserStatus, scope_for_email
from api.user.models import User, UserIdentity
from api.user.services import UserService
from tests.BaseTestCase import BaseTestCase
from tests.factories import add_domain, add_membership, create_admin_user, create_tenant


class ResolveOrProvisionForLoginTest(BaseTestCase):
    def test_existing_identity_by_subject_is_idempotent(self):
        tenant = create_tenant(code="EXIST", is_federated=True)
        add_domain(tenant, "exist.com")
        user = create_admin_user(email="known@exist.com", subject="sub-known")
        add_membership(user, tenant)

        resolved = UserService.resolve_or_provision_for_login(
            sub="sub-known",
            email="known@exist.com",
            tenant=tenant,
        )

        self.assertEqual(resolved.pk, user.pk)
        self.assertEqual(User.objects.count(), 1)
        self.assertEqual(UserIdentity.objects.filter(auth_subject="sub-known").count(), 1)

    def test_claims_subjectless_preprovisioned_identity_by_email_case_insensitive(self):
        tenant = create_tenant(code="INV", is_federated=False)
        add_domain(tenant, "inv.com")
        user = User(
            status=UserStatus.ACTIVE,
            display_name="Invited User",
            first_name="Invited",
            last_name="User",
            is_deleted=False,
        )
        user.set_unusable_password()
        user.save()
        identity = UserIdentity.objects.create(
            user=user,
            email="invite@inv.com",
            auth_provider=AuthProvider.SAP_CDC,
            auth_subject=None,
            is_primary=True,
            is_active=True,
            is_deleted=False,
        )
        add_membership(user, tenant)

        resolved = UserService.resolve_or_provision_for_login(
            sub="sub-invite",
            email="Invite@Inv.com",
            tenant=tenant,
        )

        identity.refresh_from_db()
        self.assertEqual(resolved.pk, user.pk)
        self.assertEqual(identity.auth_subject, "sub-invite")
        self.assertEqual(User.objects.count(), 1)

    def test_federated_jit_creates_user_and_membership(self):
        tenant = create_tenant(code="FED", is_federated=True)
        add_domain(tenant, "fed.com")

        user = UserService.resolve_or_provision_for_login(
            sub="sub-jit",
            email="New@Fed.com",
            tenant=tenant,
            first_name="New",
            last_name="User",
        )

        identity = UserIdentity.objects.get(auth_subject="sub-jit")
        self.assertEqual(user.first_name, "New")
        self.assertEqual(user.last_name, "User")
        self.assertEqual(user.display_name, "New User")
        self.assertFalse(user.has_usable_password())
        self.assertEqual(identity.email, "new@fed.com")
        self.assertTrue(identity.is_primary)
        self.assertTrue(identity.is_active)
        self.assertIsNotNone(identity.last_login_at)
        self.assertIsNotNone(TenantMembershipService.get_effective_membership(user, tenant))

    def test_repeat_federated_login_is_idempotent(self):
        tenant = create_tenant(code="FED2", is_federated=True)
        add_domain(tenant, "fed2.com")

        first = UserService.resolve_or_provision_for_login(
            sub="sub-repeat",
            email="repeat@fed2.com",
            tenant=tenant,
            first_name="Repeat",
            last_name="User",
        )
        second = UserService.resolve_or_provision_for_login(
            sub="sub-repeat",
            email="repeat@fed2.com",
            tenant=tenant,
            first_name="Repeat",
            last_name="User",
        )

        self.assertEqual(first.pk, second.pk)
        self.assertEqual(User.objects.filter(identities__auth_subject="sub-repeat").count(), 1)
        self.assertEqual(UserIdentity.objects.filter(auth_subject="sub-repeat").count(), 1)

    def test_jit_uses_email_as_display_name_fallback(self):
        tenant = create_tenant(code="DISP", is_federated=True)
        add_domain(tenant, "disp.com")

        user = UserService.resolve_or_provision_for_login(
            sub="sub-disp",
            email="fallback@disp.com",
            tenant=tenant,
        )

        self.assertEqual(user.display_name, "fallback@disp.com")

    def test_non_federated_without_invite_denied(self):
        tenant = create_tenant(code="NF", is_federated=False)
        add_domain(tenant, "nf.com")

        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="sub-nf",
                email="nobody@nf.com",
                tenant=tenant,
            )
        self.assertEqual(ctx.exception.get_codes(), "not_provisioned")

    def test_existing_user_syncs_profile_email_and_last_login(self):
        tenant = create_tenant(code="SYNC", is_federated=True)
        add_domain(tenant, "sync.com")
        user = create_admin_user(
            email="old@sync.com",
            subject="sub-sync",
            first_name="Old",
            last_name="Name",
        )
        add_membership(user, tenant)
        identity = user.identities.get()
        self.assertIsNone(identity.last_login_at)

        resolved = UserService.resolve_or_provision_for_login(
            sub="sub-sync",
            email="new@sync.com",
            tenant=tenant,
            first_name="New",
            last_name="Person",
        )

        resolved.refresh_from_db()
        identity.refresh_from_db()
        self.assertEqual(resolved.first_name, "New")
        self.assertEqual(resolved.last_name, "Person")
        self.assertEqual(identity.email, "new@sync.com")
        self.assertIsNotNone(identity.last_login_at)

    def test_federated_existing_user_gains_missing_membership(self):
        tenant = create_tenant(code="FEDM", is_federated=True)
        add_domain(tenant, "fedm.com")
        user = create_admin_user(email="member@fedm.com", subject="sub-fedm")

        resolved = UserService.resolve_or_provision_for_login(
            sub="sub-fedm",
            email="member@fedm.com",
            tenant=tenant,
        )

        self.assertEqual(resolved.pk, user.pk)
        self.assertIsNotNone(TenantMembershipService.get_effective_membership(user, tenant))

    def test_non_federated_existing_user_without_membership_denied(self):
        tenant = create_tenant(code="NFM", is_federated=False)
        add_domain(tenant, "nfm.com")
        create_admin_user(email="outsider@nfm.com", subject="sub-nfm")

        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="sub-nfm",
                email="outsider@nfm.com",
                tenant=tenant,
            )
        self.assertEqual(ctx.exception.get_codes(), "membership_required")

    def test_ambiguous_tenant_requires_existing_membership(self):
        a = create_tenant(code="A", is_federated=True)
        b = create_tenant(code="B", is_federated=True)
        add_domain(a, "shared.com")
        add_domain(b, "shared.com")
        user = create_admin_user(email="shared@shared.com", subject="sub-shared")
        add_membership(user, a)

        resolved = UserService.resolve_or_provision_for_login(
            sub="sub-shared",
            email="shared@shared.com",
            tenant=None,
            candidate_tenants=[a, b],
        )
        self.assertEqual(resolved.pk, user.pk)

        unknown = create_admin_user(email="other@shared.com", subject="sub-other")
        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="sub-other",
                email="other@shared.com",
                tenant=None,
                candidate_tenants=[a, b],
            )
        self.assertEqual(ctx.exception.get_codes(), "membership_required")
        self.assertEqual(unknown.pk, User.objects.get(identities__auth_subject="sub-other").pk)

    def test_ambiguous_tenant_denies_unknown_user(self):
        a = create_tenant(code="A2", is_federated=True)
        b = create_tenant(code="B2", is_federated=True)
        add_domain(a, "pick.com")
        add_domain(b, "pick.com")

        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="sub-pick",
                email="new@pick.com",
                tenant=None,
                candidate_tenants=[a, b],
            )
        self.assertEqual(ctx.exception.get_codes(), "tenant_selection_required")

    def test_inactive_identity_denied(self):
        tenant = create_tenant(code="IDOFF", is_federated=True)
        add_domain(tenant, "idoff.com")
        user = create_admin_user(email="off@idoff.com", subject="sub-idoff")
        add_membership(user, tenant)
        UserIdentity.objects.filter(auth_subject="sub-idoff").update(is_active=False)

        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="sub-idoff",
                email="off@idoff.com",
                tenant=tenant,
            )
        self.assertEqual(ctx.exception.get_codes(), "identity_inactive")

    def test_inactive_user_denied(self):
        tenant = create_tenant(code="UOFF", is_federated=True)
        add_domain(tenant, "uoff.com")
        user = create_admin_user(
            email="off@uoff.com",
            subject="sub-uoff",
            status=UserStatus.INACTIVE,
        )
        add_membership(user, tenant)

        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="sub-uoff",
                email="off@uoff.com",
                tenant=tenant,
            )
        self.assertEqual(ctx.exception.get_codes(), "user_inactive")

    def test_blank_email_and_missing_sub_denied(self):
        tenant = create_tenant(code="BAD", is_federated=True)
        add_domain(tenant, "bad.com")

        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="sub-bad",
                email="   ",
                tenant=tenant,
            )
        self.assertEqual(ctx.exception.get_codes(), "invalid_email")

        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="",
                email="ok@bad.com",
                tenant=tenant,
            )
        self.assertEqual(str(ctx.exception.detail), "invalid_token")

    def test_federated_jit_stamps_tenant_scope(self):
        tenant = create_tenant(code="SCOPE", is_federated=True)
        add_domain(tenant, "scope.com")

        user = UserService.resolve_or_provision_for_login(
            sub="sub-scope",
            email="new@scope.com",
            tenant=tenant,
        )

        self.assertEqual(user.tenant_access_scope, TenantAccessScope.TENANT)

    def test_repeat_login_does_not_rewrite_scope(self):
        tenant = create_tenant(code="KEEP", is_federated=True)
        add_domain(tenant, "keep.com")
        user = create_admin_user(
            email="keep@keep.com",
            subject="sub-keep",
            tenant_access_scope=TenantAccessScope.TENANT,
        )
        add_membership(user, tenant)

        UserService.resolve_or_provision_for_login(
            sub="sub-keep",
            email="keep@cencora.com",
            tenant=tenant,
        )

        user.refresh_from_db()
        self.assertEqual(user.tenant_access_scope, TenantAccessScope.TENANT)

    def test_all_tenants_user_logs_in_without_membership(self):
        tenant = create_tenant(code="INT", is_federated=False)
        user = create_admin_user(
            email="internal@cencora.com",
            subject="sub-int",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )

        resolved = UserService.resolve_or_provision_for_login(
            sub="sub-int",
            email="internal@cencora.com",
            tenant=tenant,
            candidate_tenants=[tenant],
        )

        self.assertEqual(resolved.pk, user.pk)
        self.assertFalse(TenantMembership.objects.filter(user=user).exists())
        self.assertTrue(TenantMembershipService.can_access(user, tenant))

    def test_unknown_internal_email_refuses_jit(self):
        tenant = create_tenant(code="NOJIT", is_federated=True)
        add_domain(tenant, "cencora.com")

        with self.assertRaises(AuthenticationFailed) as ctx:
            UserService.resolve_or_provision_for_login(
                sub="sub-nojit",
                email="stranger@cencora.com",
                tenant=tenant,
            )
        self.assertEqual(ctx.exception.get_codes(), "not_provisioned")
        self.assertFalse(User.objects.filter(identities__email="stranger@cencora.com").exists())

    def test_scope_for_email_maps_internal_domains(self):
        self.assertEqual(scope_for_email("a@cencora.com"), TenantAccessScope.ALL_TENANTS)
        self.assertEqual(scope_for_email("a@partner.com"), TenantAccessScope.TENANT)
        self.assertEqual(UserService.scope_for_email("b@stratium.com"), TenantAccessScope.ALL_TENANTS)
