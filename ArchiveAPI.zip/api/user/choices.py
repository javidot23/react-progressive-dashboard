from django.db import models

from api.common.emails import email_domain


class UserStatus(models.TextChoices):
    ACTIVE = "active", "Active"
    PENDING_VERIFICATION = "pending_verification", "Pending verification"
    SUSPENDED = "suspended", "Suspended"
    INACTIVE = "inactive", "Inactive"
    DISABLED = "disabled", "Disabled"
    DELETED = "deleted", "Deleted"


class AuthProvider(models.TextChoices):
    SAP_CDC = "sap_cdc", "SAP CDC"
    ENTRA_ID = "entra_id", "Entra ID"


class TenantAccessScope(models.TextChoices):
    TENANT = "tenant", "Scoped to memberships"
    ALL_TENANTS = "all_tenants", "All tenants"


INTERNAL_EMAIL_DOMAINS = frozenset({
    "cencorapr.com",
    "cencora.com",
    "amerisourcebergen.com",
    "stratium.com",
})


def scope_for_email(email: str) -> str:
    """Return the tenant access scope to stamp when creating a user for ``email``."""
    domain = email_domain(email)
    if domain and domain in INTERNAL_EMAIL_DOMAINS:
        return TenantAccessScope.ALL_TENANTS
    return TenantAccessScope.TENANT
