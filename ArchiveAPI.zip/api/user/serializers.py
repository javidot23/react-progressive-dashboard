from rest_framework import serializers

from api.user.models import User


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = "__all__"


class UserProfileResponseSerializer(serializers.Serializer):
    id = serializers.CharField()
    displayName = serializers.CharField()
    mail = serializers.CharField(allow_null=True)
    givenName = serializers.CharField(allow_blank=True)
    surname = serializers.CharField(allow_blank=True)
    userPrincipalName = serializers.CharField(allow_null=True)
    jobTitle = serializers.CharField()
    department = serializers.CharField()
    profilePicture = serializers.CharField(allow_null=True)
