"""User URL Configuration"""
from django.urls import path

from . import views

app_name = 'user'

urlpatterns = [
    path('me/', views.UserProfileView.as_view(), name='user-profile'),
]
