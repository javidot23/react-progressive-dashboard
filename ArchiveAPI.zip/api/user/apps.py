from django.apps import AppConfig

from config.db_scope import DBScope


class UserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.user'
    db_scope = DBScope.CORE
