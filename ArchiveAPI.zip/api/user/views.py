import logging

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.decorators.vary import vary_on_headers
from rest_framework import exceptions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema, extend_schema_view

from api.audit.choices import AuditEventType
from api.audit.services import AuditService
from api.user.models import UserIdentity
from api.user.serializers import UserProfileResponseSerializer
from api.user.services import UserService

logger = logging.getLogger(__name__)

User = get_user_model()


@method_decorator(never_cache, name="dispatch")
@method_decorator(vary_on_headers("Cookie"), name="dispatch")
@extend_schema_view(
    get=extend_schema(responses=UserProfileResponseSerializer),
)
class UserProfileView(APIView):
    """
    GET /auth/me/                — return the DB profile of the cookie-authenticated user.
    GET /auth/me/?sync=true      — best-effort SAP CDC refresh via ``X-SAP-Access-Token``.
    """

    def _update_user_from_sap_cdc_info(self, user, userinfo: dict) -> bool:
        token_sub = (userinfo.get("sub") or "").strip()
        identity = (
            UserIdentity.objects.filter(user=user, auth_subject=token_sub, is_deleted=False).first()
            or user._primary_identity()
        )
        if not token_sub or identity is None or identity.auth_subject != token_sub:
            logger.warning(
                "SAP CDC sync rejected: userinfo sub %r does not match session user %s",
                token_sub or None,
                user.pk,
            )
            return False

        try:
            user.refresh_from_db()
        except User.DoesNotExist:
            logger.warning("User %s not found in database", user.pk)
            return False

        user_updates = []
        identity_updates = []

        email = userinfo.get("email")
        if email and identity.email.lower() != email.strip().lower():
            identity.email = email.strip().lower()
            identity_updates.append("email")

        given_name = userinfo.get("given_name")
        if given_name and user.first_name != given_name:
            user.first_name = given_name
            user_updates.append("first_name")

        family_name = userinfo.get("family_name")
        if family_name and user.last_name != family_name:
            user.last_name = family_name
            user_updates.append("last_name")

        if not user_updates and not identity_updates:
            return False

        if user_updates:
            user_updates.append("updated_at")
            user.save(update_fields=user_updates)
        if identity_updates:
            identity_updates.append("updated_at")
            identity.save(update_fields=identity_updates)

        logger.info("Updated SAP CDC user %s fields: %s", user.pk, user_updates + identity_updates)
        return True

    def _build_user_response(self, user):
        return {
            "id": str(user.pk),
            "displayName": user.display_name or f"{user.first_name} {user.last_name}".strip(),
            "mail": user.email,
            "givenName": user.first_name,
            "surname": user.last_name,
            "userPrincipalName": user.email,
            "jobTitle": user.job_title or "N/A",
            "department": user.department or "Unknown",
            "profilePicture": None,
        }

    def get(self, request):
        try:
            user = request.user
            sync = request.query_params.get("sync", "").lower() in ("true", "1", "yes")

            if sync:
                sap_access_token = request.META.get("HTTP_X_SAP_ACCESS_TOKEN")
                if sap_access_token:
                    sap_user_info = UserService.get_user_profile_from_sap_cdc(sap_access_token)
                    if sap_user_info:
                        user_was_updated = self._update_user_from_sap_cdc_info(user, sap_user_info)
                        if user_was_updated:
                            cache.delete(f"user:{user.pk}")
                            user.refresh_from_db()
                            AuditService.record_from_request(
                                request,
                                AuditEventType.USER_UPDATED,
                                status=status.HTTP_200_OK,
                                target_entity={"type": "user", "id": str(user.pk)},
                                metadata={"via": "auth_me_sync"},
                            )
                        logger.info(
                            "SAP CDC profile synced for: %s, updated: %s",
                            user.pk,
                            user_was_updated,
                        )
                    else:
                        logger.warning("Could not fetch SAP CDC userinfo for user: %s", user.pk)
                else:
                    logger.info(
                        "sync=true requested but no X-SAP-Access-Token forwarded for: %s",
                        user.pk,
                    )

            logger.info("User profile retrieved for: %s", user.email)
            return Response(self._build_user_response(user))

        except Exception as e:
            logger.error("User profile request failed: %s", e)
            raise exceptions.APIException("Failed to retrieve user profile.") from e
