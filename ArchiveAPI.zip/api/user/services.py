import hashlib
import logging
from typing import Dict, Iterable, Optional

import requests
from django.conf import settings
from django.core.cache import cache
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import AuthenticationFailed

from api.tenant.models import Tenant, TenantMembership
from api.tenant.services import TenantMembershipService, TenantService
from api.user.choices import AuthProvider, TenantAccessScope, UserStatus, scope_for_email
from api.user.models import User, UserIdentity
from config.db_scope import CORE_DB_ALIAS

logger = logging.getLogger(__name__)


class UserService:
    """SAP CDC profile fetch and login-time user resolution against core."""

    scope_for_email = staticmethod(scope_for_email)

    @staticmethod
    def get_user_profile_from_sap_cdc(access_token: str) -> Optional[Dict]:
        """Fetch user profile from SAP CDC userinfo endpoint, cached 15 min."""
        logger.info("Fetching SAP CDC profile")
        userinfo_url = settings.SAP_CDC_USERINFO_URL
        if not userinfo_url:
            logger.warning("SAP_CDC_USERINFO_URL not configured")
            return None

        token_hash = hashlib.sha256(access_token.encode()).hexdigest()[:16]
        cache_key = f"sap_cdc_profile:{token_hash}"

        cached_profile = cache.get(cache_key)
        if cached_profile:
            logger.debug("Using cached SAP CDC profile")
            return cached_profile

        try:
            headers = {"Authorization": f"Bearer {access_token}"}
            response = requests.get(userinfo_url, headers=headers, timeout=10)

            if response.status_code != 200:
                logger.error(
                    "SAP CDC userinfo call failed: %s - %s",
                    response.status_code,
                    response.text,
                )
                return None

            user_info = response.json()
            cache.set(cache_key, user_info, timeout=900)
            logger.info("SAP CDC profile fetched for user: %s", user_info.get("email"))
            return user_info

        except Exception as e:
            logger.error("SAP CDC userinfo error: %s", e)
            return None

    @staticmethod
    def _assert_identity_usable(identity: UserIdentity) -> None:
        if identity.is_deleted or not identity.is_active:
            raise AuthenticationFailed("Access denied", code="identity_inactive")

    @staticmethod
    def _assert_user_usable(user: User) -> None:
        if user.is_deleted or user.status != UserStatus.ACTIVE:
            raise AuthenticationFailed("Access denied", code="user_inactive")

    @staticmethod
    def _assert_membership_in_any(user: User, tenants) -> None:
        """Require access to at least one of ``tenants``."""
        if TenantMembershipService.has_all_tenant_access(user):
            return
        for candidate in tenants:
            if TenantMembershipService.can_access(user, candidate):
                return
        raise AuthenticationFailed("Access denied", code="membership_required")

    @staticmethod
    def _normalize_login_email(email: str) -> str:
        normalized_email = (email or "").strip().lower()
        if not normalized_email:
            raise AuthenticationFailed("Access denied", code="invalid_email")
        return normalized_email

    @staticmethod
    def _find_identity_by_subject(sub: str) -> Optional[UserIdentity]:
        return (
            UserIdentity.objects.select_related("user")
            .filter(
                auth_provider=AuthProvider.SAP_CDC,
                auth_subject=sub,
                is_deleted=False,
            )
            .first()
        )

    @staticmethod
    def _find_subjectless_identity_by_email(email: str) -> Optional[UserIdentity]:
        return (
            UserIdentity.objects.select_related("user")
            .filter(
                auth_provider=AuthProvider.SAP_CDC,
                auth_subject__isnull=True,
                email__iexact=email,
                is_deleted=False,
            )
            .first()
        )

    @staticmethod
    def find_login_identity(sub: str, email: str) -> Optional[UserIdentity]:
        """Locate an existing identity for login without mutating it."""
        identity = UserService._find_identity_by_subject(sub)
        if identity is not None:
            return identity
        return UserService._find_subjectless_identity_by_email(email)

    @staticmethod
    def _claim_preprovisioned_identity(sub: str, email: str) -> Optional[UserIdentity]:
        """Link a subjectless pre-provisioned SAP CDC identity to ``sub``."""
        identity = UserService._find_subjectless_identity_by_email(email)
        if identity is None:
            return None
        identity.auth_subject = sub
        identity.save(update_fields=["auth_subject", "updated_at"])
        return identity

    @staticmethod
    def _grant_federated_membership(user: User, tenant: Tenant) -> None:
        TenantMembership.objects.get_or_create(
            user=user,
            tenant=tenant,
            defaults={"is_active": True},
        )

    @staticmethod
    def _jit_provision_identity(
        *,
        sub: str,
        email: str,
        tenant: Optional[Tenant],
        first_name: str,
        last_name: str,
    ) -> UserIdentity:
        """Create user, identity, and membership for a resolved federated tenant."""
        access_scope = scope_for_email(email)
        if access_scope == TenantAccessScope.ALL_TENANTS:
            logger.info("Internal email %s is not provisioned; refusing JIT", email)
            raise AuthenticationFailed("Access denied", code="not_provisioned")

        if tenant is None:
            raise AuthenticationFailed(
                "Multiple tenants match this email domain; select a tenant.",
                code="tenant_selection_required",
            )
        if not tenant.is_federated:
            logger.info("User %s is not provisioned for tenant %s", sub, tenant.pk)
            raise AuthenticationFailed("Access denied", code="not_provisioned")

        display = " ".join(
            p for p in [(first_name or "").strip(), (last_name or "").strip()] if p
        ) or email
        user = User(
            status=UserStatus.ACTIVE,
            display_name=display,
            first_name=(first_name or "").strip(),
            last_name=(last_name or "").strip(),
            tenant_access_scope=access_scope,
            is_deleted=False,
        )
        user.set_unusable_password()
        user.save()
        identity = UserIdentity.objects.create(
            user=user,
            email=email,
            auth_provider=AuthProvider.SAP_CDC,
            auth_subject=sub,
            is_primary=True,
            is_active=True,
            is_deleted=False,
        )
        UserService._grant_federated_membership(user, tenant)
        logger.info("Federated JIT provisioned user %s for tenant %s", user.pk, tenant.pk)
        return identity

    @staticmethod
    def _ensure_login_membership(
        user: User,
        tenant: Optional[Tenant],
        candidate_tenants: Optional[Iterable[Tenant]],
    ) -> None:
        if TenantMembershipService.has_all_tenant_access(user):
            return
        if tenant is None:
            UserService._assert_membership_in_any(user, candidate_tenants or [])
            return
        if TenantMembershipService.can_access(user, tenant):
            return
        if tenant.is_federated:
            UserService._grant_federated_membership(user, tenant)
            return
        raise AuthenticationFailed("Access denied", code="membership_required")

    @staticmethod
    def _sync_profile_from_claims(
        user: User,
        identity: UserIdentity,
        *,
        email: str,
        first_name: str,
        last_name: str,
    ) -> None:
        updates = []
        if first_name and user.first_name != first_name:
            user.first_name = first_name
            updates.append("first_name")
        if last_name and user.last_name != last_name:
            user.last_name = last_name
            updates.append("last_name")
        if updates:
            updates.append("updated_at")
            user.save(update_fields=updates)

        if identity.email.lower() != email:
            identity.email = email
            identity.save(update_fields=["email", "updated_at"])

    @staticmethod
    def _touch_identity_login(identity: UserIdentity) -> None:
        identity.last_login_at = timezone.now()
        identity.save(update_fields=["last_login_at", "updated_at"])

    @staticmethod
    @transaction.atomic(using=CORE_DB_ALIAS)
    def resolve_or_provision_for_login(
        *,
        sub: str,
        email: str,
        tenant: Optional[Tenant] = None,
        candidate_tenants: Optional[Iterable[Tenant]] = None,
        first_name: str = "",
        last_name: str = "",
    ) -> User:
        """Resolve or provision an SAP CDC user, resync profile fields, and grant federated membership."""
        if tenant is not None:
            TenantService.assert_tenant_usable(tenant)

        normalized_email = UserService._normalize_login_email(email)
        if not sub:
            raise AuthenticationFailed("invalid_token")

        identity = UserService._find_identity_by_subject(sub)
        if identity is None:
            identity = UserService._claim_preprovisioned_identity(sub, normalized_email)

        if identity is None:
            identity = UserService._jit_provision_identity(
                sub=sub,
                email=normalized_email,
                tenant=tenant,
                first_name=first_name,
                last_name=last_name,
            )
        else:
            UserService._assert_identity_usable(identity)
            user = identity.user
            UserService._assert_user_usable(user)
            UserService._ensure_login_membership(user, tenant, candidate_tenants)
            UserService._sync_profile_from_claims(
                user,
                identity,
                email=normalized_email,
                first_name=first_name,
                last_name=last_name,
            )

        UserService._touch_identity_login(identity)
        return identity.user
