import uuid
from typing import Optional

from django.db.models import QuerySet, Prefetch, Sum

from api.custom_lists.models import CustomList, CustomListItem


class CustomListSelector:
    """Selector for CustomList queries."""

    @classmethod
    def get_lists_for_user(cls, owner_user_id: str, include_archived: bool = False) -> QuerySet[CustomList]:
        queryset = CustomList.objects.filter(owner_user_id=owner_user_id)
        if not include_archived:
            queryset = queryset.filter(is_archived=False)
        return queryset

    @classmethod
    def get_list_by_id(cls, list_id: uuid.UUID, owner_user_id: str) -> Optional[CustomList]:
        try:
            return CustomList.objects.get(id=list_id, owner_user_id=owner_user_id)
        except CustomList.DoesNotExist:
            return None

    @classmethod
    def get_list_with_items(cls, list_id: uuid.UUID, owner_user_id: str) -> Optional[CustomList]:
        try:
            items_prefetch = Prefetch(
                'items',
                queryset=CustomListItem.objects.order_by('rank', '-added_at')
            )
            return CustomList.objects.prefetch_related(items_prefetch).get(
                id=list_id, owner_user_id=owner_user_id
            )
        except CustomList.DoesNotExist:
            return None

    @classmethod
    def check_name_uniqueness(cls, owner_user_id: str, name: str, exclude_id: Optional[uuid.UUID] = None) -> bool:
        queryset = CustomList.objects.filter(owner_user_id=owner_user_id, name=name)
        if exclude_id:
            queryset = queryset.exclude(id=exclude_id)
        return not queryset.exists()

    @classmethod
    def is_owner(cls, list_id: uuid.UUID, user_id: str) -> bool:
        return CustomList.objects.filter(id=list_id, owner_user_id=user_id).exists()

    @classmethod
    def get_user_stats(cls, owner_user_id: str) -> dict:
        queryset = CustomList.objects.filter(owner_user_id=owner_user_id, is_archived=False)
        return {
            'active_lists': queryset.count(),
            'total_items_tracked': queryset.aggregate(total=Sum('items_count'))['total'] or 0,
        }


class CustomListItemSelector:
    """Selector for CustomListItem queries."""

    @classmethod
    def get_items_for_list(cls, custom_list_id: uuid.UUID) -> QuerySet[CustomListItem]:
        return CustomListItem.objects.filter(custom_list_id=custom_list_id).select_related('custom_list')

    @classmethod
    def get_items_with_materials(cls, custom_list_id: uuid.UUID) -> list[CustomListItem]:
        """Get items with material data attached (bulk fetched)."""
        from api.material.models import Material

        items = list(
            CustomListItem.objects.filter(custom_list_id=custom_list_id).order_by('rank', '-added_at')
        )
        if not items:
            return items

        entity_ids = [item.entity_id for item in items]
        materials = Material.objects.filter(mat_nbr__in=entity_ids)
        material_map = {m.mat_nbr: m for m in materials}

        for item in items:
            item._prefetched_material = material_map.get(item.entity_id)

        return items

    @classmethod
    def get_item_by_id(cls, item_id: uuid.UUID) -> Optional[CustomListItem]:
        try:
            return CustomListItem.objects.select_related('custom_list').get(id=item_id)
        except CustomListItem.DoesNotExist:
            return None

    @classmethod
    def get_existing_entity_ids(cls, custom_list_id: uuid.UUID, entity_ids: list[str]) -> set[str]:
        return set(
            CustomListItem.objects.filter(
                custom_list_id=custom_list_id,
                entity_id__in=entity_ids,
            ).values_list('entity_id', flat=True)
        )

    @classmethod
    def count_items(cls, custom_list_id: uuid.UUID) -> int:
        return CustomListItem.objects.filter(custom_list_id=custom_list_id).count()
