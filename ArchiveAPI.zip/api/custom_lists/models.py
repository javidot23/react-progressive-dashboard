import uuid

from django.db import models

from api.user.models import User


class CustomList(models.Model):
    """User-created custom list for organizing materials."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    owner_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="custom_lists",
        verbose_name="Owner",
    )
    name = models.CharField(max_length=120, verbose_name="List Name")
    description = models.TextField(null=True, blank=True, verbose_name="Description")
    public = models.BooleanField(default=False, verbose_name="Public")
    color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Color")
    icon = models.CharField(max_length=32, null=True, blank=True, verbose_name="Icon")
    items_count = models.PositiveIntegerField(default=0, verbose_name="Items Count")
    is_archived = models.BooleanField(default=False, verbose_name="Archived")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Updated At")

    class Meta:
        db_table = "custom_lists"
        ordering = ["-updated_at"]
        verbose_name = "Custom List"
        verbose_name_plural = "Custom Lists"
        constraints = [
            models.UniqueConstraint(
                fields=["owner_user", "name"],
                name="unique_owner_name",
            ),
        ]
        indexes = [
            models.Index(fields=["owner_user"], name="idx_custom_list_owner"),
            models.Index(fields=["public"], name="idx_custom_list_public"),
        ]

    def __str__(self):
        return f"{self.name} - {self.owner_user_id}"


class CustomListItem(models.Model):
    """Material item within a custom list, referenced by mat_nbr."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    custom_list = models.ForeignKey(
        CustomList,
        on_delete=models.CASCADE,
        related_name="items",
        verbose_name="Custom List",
    )
    entity_id = models.CharField(max_length=64, verbose_name="Material Number")
    rank = models.IntegerField(null=True, blank=True, verbose_name="Rank")
    added_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        verbose_name="Added By",
    )
    added_at = models.DateTimeField(auto_now_add=True, verbose_name="Added At")

    class Meta:
        db_table = "custom_list_items"
        ordering = ["rank", "-added_at"]
        verbose_name = "Custom List Item"
        verbose_name_plural = "Custom List Items"
        constraints = [
            models.UniqueConstraint(
                fields=["custom_list", "entity_id"],
                name="unique_list_entity",
            ),
        ]
        indexes = [
            models.Index(fields=["custom_list"], name="idx_item_list"),
            models.Index(fields=["entity_id"], name="idx_item_entity"),
        ]

    def __str__(self):
        return f"Material {self.entity_id} in {self.custom_list.name}"
