import logging
from dataclasses import dataclass
from typing import Optional

from django.db import transaction

from api.custom_lists.models import CustomList, CustomListItem
from api.custom_lists.selectors import CustomListSelector, CustomListItemSelector
from api.material.models import Material

logger = logging.getLogger(__name__)


@dataclass
class SyncItemsResult:
    added: int
    removed: int
    unchanged: int
    invalid: list[str]
    final_count: int


class CustomListService:
    """Service for CustomList operations."""

    @classmethod
    def create_list(
        cls,
        owner_user_id: str,
        name: str,
        description: Optional[str] = None,
        color: Optional[str] = None,
        icon: Optional[str] = None,
    ) -> CustomList:
        if not CustomListSelector.check_name_uniqueness(owner_user_id=owner_user_id, name=name):
            raise ValueError(f"A list with name '{name}' already exists")

        custom_list = CustomList.objects.create(
            owner_user_id=owner_user_id,
            name=name,
            description=description,
            color=color,
            icon=icon,
        )
        logger.info("Created custom list %s for user %s", custom_list.id, owner_user_id)
        return custom_list

    @classmethod
    def update_list(
        cls,
        custom_list: CustomList,
        name: Optional[str] = None,
        description: Optional[str] = None,
        color: Optional[str] = None,
        icon: Optional[str] = None,
    ) -> CustomList:
        if name and name != custom_list.name:
            if not CustomListSelector.check_name_uniqueness(
                owner_user_id=custom_list.owner_user_id,
                name=name,
                exclude_id=custom_list.id,
            ):
                raise ValueError(f"A list with name '{name}' already exists")
            custom_list.name = name

        if description is not None:
            custom_list.description = description
        if color is not None:
            custom_list.color = color
        if icon is not None:
            custom_list.icon = icon

        custom_list.save()
        logger.info("Updated custom list %s", custom_list.id)
        return custom_list

    @classmethod
    def delete_list(cls, custom_list: CustomList) -> None:
        list_id = custom_list.id
        custom_list.delete()
        logger.info("Deleted custom list %s", list_id)


class CustomListItemService:
    """Service for CustomListItem operations."""

    @classmethod
    def validate_material_ids(cls, entity_ids: list[str]) -> tuple[list[str], list[str]]:
        if not entity_ids:
            return [], []

        existing = set(
            Material.objects.filter(mat_nbr__in=entity_ids).values_list('mat_nbr', flat=True)
        )
        valid_ids = [eid for eid in entity_ids if eid in existing]
        invalid_ids = [eid for eid in entity_ids if eid not in existing]
        return valid_ids, invalid_ids

    @classmethod
    @transaction.atomic
    def sync_items(
        cls,
        custom_list: CustomList,
        entity_ids: list[str],
        added_by_id: Optional[str] = None,
    ) -> SyncItemsResult:
        """Sync list items to match provided entity_ids."""

        if not entity_ids:
            removed_count = CustomListItem.objects.filter(custom_list=custom_list).delete()[0]
            cls._sync_items_count(custom_list)
            return SyncItemsResult(added=0, removed=removed_count, unchanged=0, invalid=[], final_count=0)

        valid_ids, invalid_ids = cls.validate_material_ids(entity_ids)
        valid_ids_set = set(valid_ids)

        current_entity_ids = set(
            CustomListItem.objects.filter(custom_list=custom_list).values_list('entity_id', flat=True)
        )

        to_add = valid_ids_set - current_entity_ids
        to_remove = current_entity_ids - valid_ids_set
        unchanged = current_entity_ids & valid_ids_set

        removed_count = 0
        if to_remove:
            removed_count = CustomListItem.objects.filter(
                custom_list=custom_list,
                entity_id__in=to_remove,
            ).delete()[0]

        added_count = 0
        if to_add:
            items_to_create = [
                CustomListItem(custom_list=custom_list, entity_id=entity_id, added_by_id=added_by_id)
                for entity_id in to_add
            ]
            CustomListItem.objects.bulk_create(items_to_create)
            added_count = len(items_to_create)

        cls._sync_items_count(custom_list)

        logger.info(
            "Synced list %s: added %d, removed %d, unchanged %d, invalid %d",
            custom_list.id, added_count, removed_count, len(unchanged), len(invalid_ids)
        )

        return SyncItemsResult(
            added=added_count,
            removed=removed_count,
            unchanged=len(unchanged),
            invalid=invalid_ids,
            final_count=len(unchanged) + added_count,
        )

    @classmethod
    def _sync_items_count(cls, custom_list: CustomList) -> None:
        actual_count = CustomListItemSelector.count_items(custom_list.id)
        if custom_list.items_count != actual_count:
            custom_list.items_count = actual_count
            custom_list.save(update_fields=['items_count', 'updated_at'])
