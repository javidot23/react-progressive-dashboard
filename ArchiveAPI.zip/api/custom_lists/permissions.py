from rest_framework.permissions import IsAuthenticated


class CustomListPermission(IsAuthenticated):
    """Permission requiring ownership for all operations."""

    def has_object_permission(self, request, view, obj):
        from api.custom_lists.models import CustomList, CustomListItem

        if isinstance(obj, CustomListItem):
            custom_list = obj.custom_list
        elif isinstance(obj, CustomList):
            custom_list = obj
        else:
            return False

        return str(custom_list.owner_user_id) == str(request.user.pk)
