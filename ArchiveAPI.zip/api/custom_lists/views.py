import logging

from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, status
from rest_framework.exceptions import NotFound, ValidationError
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.audit.choices import AuditEventType
from api.audit.services import AuditService
from api.custom_lists.filters import CustomListFilter, CustomListItemFilter
from api.custom_lists.models import CustomList, CustomListItem
from api.custom_lists.permissions import CustomListPermission
from api.custom_lists.selectors import CustomListSelector, CustomListItemSelector
from api.custom_lists.serializers import (
    CustomListCreateSerializer,
    CustomListDetailSerializer,
    CustomListItemSerializer,
    CustomListSerializer,
    CustomListStatsSerializer,
    CustomListUpdateSerializer,
    SyncItemsSerializer,
    SyncItemsResultSerializer,
)
from api.custom_lists.services import CustomListService, CustomListItemService

logger = logging.getLogger(__name__)


class CustomListListCreateView(generics.ListCreateAPIView):
    """
    GET: List custom lists owned by the user.
    POST: Create a new custom list.
    """

    permission_classes = [CustomListPermission]
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = CustomListFilter
    ordering_fields = ['name', 'created_at', 'updated_at', 'items_count']
    ordering = ['-updated_at']

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CustomListCreateSerializer
        return CustomListSerializer

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return CustomList.objects.none()
        include_archived = self.request.query_params.get('is_archived') is not None
        return CustomListSelector.get_lists_for_user(
            owner_user_id=str(self.request.user.pk),
            include_archived=include_archived,
        )

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            custom_list = CustomListService.create_list(
                owner_user_id=str(request.user.pk),
                name=serializer.validated_data['name'],
                description=serializer.validated_data.get('description'),
                color=serializer.validated_data.get('color'),
                icon=serializer.validated_data.get('icon'),
            )
        except ValueError:
            raise ValidationError({'name': "Invalid data provided for creating custom list"})

        AuditService.record_from_request(
            request,
            AuditEventType.CUSTOM_LIST_CREATED,
            status=status.HTTP_201_CREATED,
            target_entity={"type": "custom_list", "id": str(custom_list.id)},
        )
        return Response(CustomListSerializer(custom_list).data, status=status.HTTP_201_CREATED)


class CustomListDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: Retrieve a custom list with items.
    PATCH: Update a custom list.
    DELETE: Delete a custom list.
    """

    permission_classes = [CustomListPermission]
    lookup_field = 'id'
    lookup_url_kwarg = 'list_id'

    def get_serializer_class(self):
        if self.request.method == 'PATCH':
            return CustomListUpdateSerializer
        return CustomListDetailSerializer

    def get_object(self):
        custom_list = CustomListSelector.get_list_with_items(
            list_id=self.kwargs.get('list_id'),
            owner_user_id=str(self.request.user.pk),
        )
        if not custom_list:
            raise NotFound("Custom list not found")
        return custom_list

    def retrieve(self, request, *args, **kwargs):
        """Retrieve custom list with items, prefetching materials efficiently."""
        from api.material.models import Material

        custom_list = self.get_object()
        items = list(custom_list.items.all())
        entity_ids = [item.entity_id for item in items]

        if entity_ids:
            materials = Material.objects.filter(mat_nbr__in=entity_ids)
            material_map = {m.mat_nbr: m for m in materials}
            for item in items:
                item._prefetched_material = material_map.get(item.entity_id)

        serializer = self.get_serializer(custom_list)
        return Response(serializer.data)

    def update(self, request, *args, **kwargs):
        custom_list = self.get_object()
        serializer = self.get_serializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)

        try:
            updated_list = CustomListService.update_list(
                custom_list=custom_list,
                name=serializer.validated_data.get('name'),
                description=serializer.validated_data.get('description'),
                color=serializer.validated_data.get('color'),
                icon=serializer.validated_data.get('icon'),
            )
        except ValueError:
            raise ValidationError({'name': "Invalid data provided for updating custom list"})

        AuditService.record_from_request(
            request,
            AuditEventType.CUSTOM_LIST_UPDATED,
            status=status.HTTP_200_OK,
            target_entity={"type": "custom_list", "id": str(updated_list.id)},
        )
        return Response(CustomListSerializer(updated_list).data)

    def destroy(self, request, *args, **kwargs):
        custom_list = self.get_object()
        list_id = custom_list.id
        CustomListService.delete_list(custom_list)
        AuditService.record_from_request(
            request,
            AuditEventType.CUSTOM_LIST_DELETED,
            status=status.HTTP_204_NO_CONTENT,
            target_entity={"type": "custom_list", "id": str(list_id)},
        )
        return Response(status=status.HTTP_204_NO_CONTENT)


class CustomListStatsView(APIView):
    """GET: Statistics for current user's custom lists."""

    permission_classes = [CustomListPermission]

    @extend_schema(responses=CustomListStatsSerializer)
    def get(self, request):
        stats = CustomListSelector.get_user_stats(owner_user_id=str(request.user.pk))
        return Response(CustomListStatsSerializer(stats).data)


class CustomListItemsListView(generics.ListAPIView):
    """GET: List items in a custom list with material details (paginated)."""

    permission_classes = [CustomListPermission]
    serializer_class = CustomListItemSerializer
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = CustomListItemFilter
    ordering_fields = ['rank', 'added_at', 'entity_id']
    ordering = ['rank', '-added_at']

    def get_custom_list(self):
        custom_list = CustomListSelector.get_list_by_id(
            list_id=self.kwargs.get('list_id'),
            owner_user_id=str(self.request.user.pk),
        )
        if not custom_list:
            raise NotFound("Custom list not found")
        return custom_list

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return CustomListItem.objects.none()
        return CustomListItemSelector.get_items_for_list(custom_list_id=self.get_custom_list().id)

    def list(self, request, *args, **kwargs):
        from api.material.models import Material

        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)

        if page is not None:
            items = list(page)
            entity_ids = [item.entity_id for item in items]

            if entity_ids:
                materials = Material.objects.filter(mat_nbr__in=entity_ids)
                material_map = {m.mat_nbr: m for m in materials}
                for item in items:
                    item._prefetched_material = material_map.get(item.entity_id)

            return self.get_paginated_response(self.get_serializer(items, many=True).data)

        items = list(queryset)
        entity_ids = [item.entity_id for item in items]

        if entity_ids:
            materials = Material.objects.filter(mat_nbr__in=entity_ids)
            material_map = {m.mat_nbr: m for m in materials}
            for item in items:
                item._prefetched_material = material_map.get(item.entity_id)

        return Response(self.get_serializer(items, many=True).data)


class CustomListItemsSyncView(APIView):
    """
    PUT: Sync list items to match provided entity_ids.
    Adds new items, removes unchecked items.
    """

    permission_classes = [CustomListPermission]

    def get_custom_list(self):
        custom_list = CustomListSelector.get_list_by_id(
            list_id=self.kwargs.get('list_id'),
            owner_user_id=str(self.request.user.pk),
        )
        if not custom_list:
            raise NotFound("Custom list not found")
        return custom_list

    @extend_schema(
        request=SyncItemsSerializer,
        responses=SyncItemsResultSerializer,
    )
    def put(self, request, *args, **kwargs):
        custom_list = self.get_custom_list()
        serializer = SyncItemsSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        entity_ids = serializer.validated_data['entity_ids']

        # Validate entity IDs before syncing
        valid_ids, invalid_ids = CustomListItemService.validate_material_ids(entity_ids)

        if invalid_ids:
            raise ValidationError(
                f"Invalid material numbers: {', '.join(invalid_ids)}",
                code="invalid_material_numbers"
            )

        result = CustomListItemService.sync_items(
            custom_list=custom_list,
            entity_ids=valid_ids,
            added_by_id=str(request.user.pk),
        )

        AuditService.record_from_request(
            request,
            AuditEventType.CUSTOM_LIST_ITEMS_SYNCED,
            status=status.HTTP_200_OK,
            target_entity={"type": "custom_list", "id": str(custom_list.id)},
            action={
                "added": result.added,
                "removed": result.removed,
                "final_count": result.final_count,
            },
        )
        return Response(SyncItemsResultSerializer(result).data)
