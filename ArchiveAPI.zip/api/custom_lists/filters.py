from django_filters.rest_framework import FilterSet, filters

from api.custom_lists.models import CustomList, CustomListItem


class CustomListFilter(FilterSet):
    """Filter set for CustomList queries."""

    is_archived = filters.BooleanFilter()
    search = filters.CharFilter(field_name='name', lookup_expr='icontains')
    created_at_after = filters.DateTimeFilter(field_name='created_at', lookup_expr='gte')
    created_at_before = filters.DateTimeFilter(field_name='created_at', lookup_expr='lte')
    updated_at_after = filters.DateTimeFilter(field_name='updated_at', lookup_expr='gte')
    updated_at_before = filters.DateTimeFilter(field_name='updated_at', lookup_expr='lte')
    items_count_min = filters.NumberFilter(field_name='items_count', lookup_expr='gte')
    items_count_max = filters.NumberFilter(field_name='items_count', lookup_expr='lte')

    class Meta:
        model = CustomList
        fields = [
            'is_archived', 'search',
            'created_at_after', 'created_at_before',
            'updated_at_after', 'updated_at_before',
            'items_count_min', 'items_count_max',
        ]


class CustomListItemFilter(FilterSet):
    """Filter set for CustomListItem queries."""

    entity_id = filters.CharFilter(lookup_expr='exact')
    entity_id_contains = filters.CharFilter(field_name='entity_id', lookup_expr='icontains')
    added_at_after = filters.DateTimeFilter(field_name='added_at', lookup_expr='gte')
    added_at_before = filters.DateTimeFilter(field_name='added_at', lookup_expr='lte')

    class Meta:
        model = CustomListItem
        fields = ['entity_id', 'entity_id_contains', 'added_at_after', 'added_at_before']
