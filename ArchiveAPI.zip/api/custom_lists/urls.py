from django.urls import path

from api.custom_lists.views import (
    CustomListDetailView,
    CustomListItemsListView,
    CustomListItemsSyncView,
    CustomListListCreateView,
    CustomListStatsView,
)

app_name = 'custom_lists'

urlpatterns = [
    path('', CustomListListCreateView.as_view(), name='list-create'),
    path('stats/', CustomListStatsView.as_view(), name='stats'),
    path('<uuid:list_id>/', CustomListDetailView.as_view(), name='detail'),
    path('<uuid:list_id>/items/', CustomListItemsListView.as_view(), name='items-list'),
    path('<uuid:list_id>/items/sync/', CustomListItemsSyncView.as_view(), name='items-sync'),
]
