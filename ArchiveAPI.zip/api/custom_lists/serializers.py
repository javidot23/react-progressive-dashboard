from rest_framework import serializers

from api.custom_lists.models import CustomList, CustomListItem


class CustomListItemSerializer(serializers.ModelSerializer):
    """Serializer for custom list items with material details."""

    added_by = serializers.SerializerMethodField()
    material = serializers.SerializerMethodField()

    class Meta:
        model = CustomListItem
        fields = ['id', 'entity_id', 'material', 'rank', 'added_by', 'added_at']
        read_only_fields = ['id', 'added_by', 'added_at']

    def get_added_by(self, obj) -> dict | None:
        if obj.added_by:
            return {
                'id': str(obj.added_by.pk),
                'first_name': obj.added_by.first_name,
                'last_name': obj.added_by.last_name,
            }
        return None

    def get_material(self, obj) -> dict | None:
        if hasattr(obj, '_prefetched_material'):
            material = obj._prefetched_material
            if material:
                return {
                    'mat_nbr': material.mat_nbr,
                    'name': material.name,
                    'ndc': material.ndc,
                    'category': material.material_group,
                    'status': material.xplant_mat_stat,
                }
            return None

        from api.material.models import Material
        try:
            material = Material.objects.filter(mat_nbr=obj.entity_id).first()
            if material:
                return {
                    'mat_nbr': material.mat_nbr,
                    'name': material.name,
                    'ndc': material.ndc,
                    'category': material.material_group,
                    'status': material.xplant_mat_stat,
                }
        except Exception:
            pass
        return None


class CustomListSerializer(serializers.ModelSerializer):
    """Serializer for custom list."""

    owner = serializers.SerializerMethodField()

    class Meta:
        model = CustomList
        fields = [
            'id', 'name', 'description', 'color', 'icon',
            'items_count', 'is_archived', 'owner', 'created_at', 'updated_at',
        ]
        read_only_fields = [
            'id', 'items_count', 'is_archived', 'owner', 'created_at', 'updated_at',
        ]

    def get_owner(self, obj) -> dict | None:
        if obj.owner_user:
            return {
                'id': str(obj.owner_user.pk),
                'first_name': obj.owner_user.first_name,
                'last_name': obj.owner_user.last_name,
            }
        return None


class CustomListDetailSerializer(CustomListSerializer):
    """Serializer for custom list detail with items."""

    items = CustomListItemSerializer(many=True, read_only=True)

    class Meta(CustomListSerializer.Meta):
        fields = CustomListSerializer.Meta.fields + ['items']


class CustomListCreateSerializer(serializers.Serializer):
    """Serializer for creating a custom list."""

    name = serializers.CharField(max_length=120)
    description = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    color = serializers.CharField(max_length=32, required=False, allow_null=True, allow_blank=True)
    icon = serializers.CharField(max_length=32, required=False, allow_null=True, allow_blank=True)


class CustomListUpdateSerializer(serializers.Serializer):
    """Serializer for updating a custom list."""

    name = serializers.CharField(max_length=120, required=False)
    description = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    color = serializers.CharField(max_length=32, required=False, allow_null=True, allow_blank=True)
    icon = serializers.CharField(max_length=32, required=False, allow_null=True, allow_blank=True)


class SyncItemsSerializer(serializers.Serializer):
    """Serializer for syncing list items."""

    entity_ids = serializers.ListField(
        child=serializers.CharField(max_length=64),
        allow_empty=True,
        max_length=10000,
    )


class SyncItemsResultSerializer(serializers.Serializer):
    """Serializer for sync items result."""

    added = serializers.IntegerField()
    removed = serializers.IntegerField()
    unchanged = serializers.IntegerField()
    invalid = serializers.ListField(child=serializers.CharField())
    final_count = serializers.IntegerField()


class CustomListStatsSerializer(serializers.Serializer):
    """Serializer for custom list statistics."""

    active_lists = serializers.IntegerField()
    total_items_tracked = serializers.IntegerField()
