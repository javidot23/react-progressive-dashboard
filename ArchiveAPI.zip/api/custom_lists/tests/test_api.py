"""
API integration tests for Custom Lists.
"""
import uuid

from api.custom_lists.services import CustomListItemService, CustomListService
from django.urls import reverse
from rest_framework import status
from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory
from api.custom_lists.models import CustomList


class CustomListAPITest(BaseAPITestCase):
    """Tests for Custom Lists API endpoints."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(
            entra_id="api_test_user",
            email="apitest@example.com"
        )
        self.vendor = TestDataFactory.create_vendor()
        self.materials = TestDataFactory.create_multiple_materials(count=10, vendor=self.vendor)
        self.client.force_authenticate(user=self.user)

    def test_list_custom_lists_empty(self):
        """Test listing custom lists when empty."""
        response = self.client.get(reverse('custom_lists:list-create'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['results'], [])

    def test_create_custom_list(self):
        """Test creating a custom list."""
        data = {
            'name': 'My Materials',
            'description': 'Important materials',
            'color': '#FF5733',
            'icon': 'star',
        }
        response = self.client.post(reverse('custom_lists:list-create'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['name'], 'My Materials')
        self.assertEqual(response.data['items_count'], 0)

    def test_create_custom_list_duplicate_name(self):
        """Test creating list with duplicate name fails."""
        CustomListService.create_list(owner_user_id=self.user.entra_id, name="Duplicate")
        response = self.client.post(reverse('custom_lists:list-create'), {'name': 'Duplicate'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_list_custom_lists_search(self):
        """Test searching custom lists by name."""
        CustomListService.create_list(owner_user_id=self.user.entra_id, name="Critical Materials")
        CustomListService.create_list(owner_user_id=self.user.entra_id, name="Important Items")
        response = self.client.get(reverse('custom_lists:list-create'), {'search': 'critical'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertIn('Critical', response.data['results'][0]['name'])

    def test_get_custom_list_detail(self):
        """Test getting custom list details with items."""
        custom_list = CustomListService.create_list(owner_user_id=self.user.entra_id, name="Test List")
        entity_ids = [m.mat_nbr for m in self.materials[:3]]
        CustomListItemService.sync_items(
            custom_list=custom_list,
            entity_ids=entity_ids,
            added_by_id=self.user.entra_id,
        )
        response = self.client.get(reverse('custom_lists:detail', kwargs={'list_id': custom_list.id}))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['name'], "Test List")
        self.assertEqual(len(response.data['items']), 3)

    def test_get_custom_list_not_found(self):
        """Test getting non-existent list returns 404."""
        fake_id = uuid.uuid4()
        response = self.client.get(reverse('custom_lists:detail', kwargs={'list_id': fake_id}))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_update_custom_list(self):
        """Test updating a custom list."""
        custom_list = CustomListService.create_list(owner_user_id=self.user.entra_id, name="Original Name")
        data = {'name': 'Updated Name', 'description': 'New description'}
        response = self.client.patch(
            reverse('custom_lists:detail', kwargs={'list_id': custom_list.id}),
            data,
            format='json',
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['name'], 'Updated Name')
        self.assertEqual(response.data['description'], 'New description')

    def test_delete_custom_list(self):
        """Test deleting a custom list permanently removes it."""
        custom_list = CustomListService.create_list(owner_user_id=self.user.entra_id, name="To Delete")
        list_id = custom_list.id
        response = self.client.delete(reverse('custom_lists:detail', kwargs={'list_id': custom_list.id}))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(CustomList.objects.filter(id=list_id).exists())

    def test_cannot_access_other_users_list(self):
        """Test that users cannot access other users' lists."""
        other_user = TestDataFactory.create_test_user(entra_id="other_user", email="other@example.com")
        other_list = CustomListService.create_list(owner_user_id=other_user.entra_id, name="Other's List")
        response = self.client.get(reverse('custom_lists:detail', kwargs={'list_id': other_list.id}))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_get_stats(self):
        """Test getting custom list statistics."""
        list1 = CustomListService.create_list(owner_user_id=self.user.entra_id, name="List 1")
        list2 = CustomListService.create_list(owner_user_id=self.user.entra_id, name="List 2")
        CustomListItemService.sync_items(
            custom_list=list1,
            entity_ids=[self.materials[0].mat_nbr, self.materials[1].mat_nbr],
            added_by_id=self.user.entra_id,
        )
        CustomListItemService.sync_items(
            custom_list=list2,
            entity_ids=[self.materials[2].mat_nbr, self.materials[3].mat_nbr, self.materials[4].mat_nbr],
            added_by_id=self.user.entra_id,
        )
        response = self.client.get(reverse('custom_lists:stats'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['active_lists'], 2)
        self.assertEqual(response.data['total_items_tracked'], 5)


class CustomListItemsAPITest(BaseAPITestCase):
    """Tests for Custom List Items API endpoints."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(entra_id="items_api_test_user", email="itemstest@example.com")
        self.vendor = TestDataFactory.create_vendor()
        self.materials = TestDataFactory.create_multiple_materials(count=10, vendor=self.vendor)
        self.custom_list = CustomListService.create_list(owner_user_id=self.user.entra_id, name="Test Materials")
        self.client.force_authenticate(user=self.user)

    def test_list_items(self):
        """Test listing items in a custom list."""
        entity_ids = [m.mat_nbr for m in self.materials[:5]]
        CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=entity_ids,
            added_by_id=self.user.entra_id,
        )
        response = self.client.get(
            reverse('custom_lists:items-list', kwargs={'list_id': self.custom_list.id}),
            {'limit': 10},
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 5)

    def test_sync_items_add_new(self):
        """Test syncing items adds new items."""
        entity_ids = [m.mat_nbr for m in self.materials[:3]]
        response = self.client.put(
            reverse('custom_lists:items-sync', kwargs={'list_id': self.custom_list.id}),
            {'entity_ids': entity_ids},
            format='json',
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['added'], 3)
        self.assertEqual(response.data['removed'], 0)
        self.assertEqual(response.data['unchanged'], 0)
        self.assertEqual(response.data['final_count'], 3)

    def test_sync_items_remove_unchecked(self):
        """Test syncing items removes unchecked items."""
        initial_ids = [m.mat_nbr for m in self.materials[:5]]
        CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=initial_ids,
            added_by_id=self.user.entra_id,
        )
        new_ids = [m.mat_nbr for m in self.materials[:2]]
        response = self.client.put(
            reverse('custom_lists:items-sync', kwargs={'list_id': self.custom_list.id}),
            {'entity_ids': new_ids},
            format='json',
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['added'], 0)
        self.assertEqual(response.data['removed'], 3)
        self.assertEqual(response.data['unchanged'], 2)
        self.assertEqual(response.data['final_count'], 2)

    def test_sync_items_add_and_remove(self):
        """Test syncing items adds and removes in one operation."""
        initial_ids = [m.mat_nbr for m in self.materials[:3]]
        CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=initial_ids,
            added_by_id=self.user.entra_id,
        )
        new_ids = [m.mat_nbr for m in self.materials[1:5]]
        response = self.client.put(
            reverse('custom_lists:items-sync', kwargs={'list_id': self.custom_list.id}),
            {'entity_ids': new_ids},
            format='json',
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['added'], 2)
        self.assertEqual(response.data['removed'], 1)
        self.assertEqual(response.data['unchanged'], 2)
        self.assertEqual(response.data['final_count'], 4)

    def test_sync_items_empty_clears_list(self):
        """Test syncing with empty list clears all items."""
        initial_ids = [m.mat_nbr for m in self.materials[:3]]
        CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=initial_ids,
            added_by_id=self.user.entra_id,
        )
        response = self.client.put(
            reverse('custom_lists:items-sync', kwargs={'list_id': self.custom_list.id}),
            {'entity_ids': []},
            format='json',
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['removed'], 3)
        self.assertEqual(response.data['final_count'], 0)

    def test_sync_items_rejects_invalid_entities(self):
        """Test syncing rejects invalid entity IDs with validation error."""
        entity_ids = [self.materials[0].mat_nbr, 'INVALID_MATERIAL', self.materials[1].mat_nbr]
        response = self.client.put(
            reverse('custom_lists:items-sync', kwargs={'list_id': self.custom_list.id}),
            {'entity_ids': entity_ids},
            format='json',
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(response.data['success'])
        self.assertEqual(response.data['code'], 'invalid_material_numbers')
        self.assertIn('INVALID_MATERIAL', response.data['error'])

    def test_cannot_sync_other_users_list(self):
        """Test that users cannot sync items on other users' lists."""
        other_user = TestDataFactory.create_test_user(entra_id="other_sync_user", email="other_sync@example.com")
        other_list = CustomListService.create_list(owner_user_id=other_user.entra_id, name="Other List")
        response = self.client.put(
            reverse('custom_lists:items-sync', kwargs={'list_id': other_list.id}),
            {'entity_ids': [self.materials[0].mat_nbr]},
            format='json',
        )
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


class CustomListPermissionsTest(BaseAPITestCase):
    """Tests for Custom Lists permissions."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(entra_id="perms_test_user", email="perms@example.com")
        self.other_user = TestDataFactory.create_test_user(entra_id="other_perms_user", email="other_perms@example.com")
        self.client.force_authenticate(user=self.user)

    def test_unauthenticated_access_denied(self):
        """Test that unauthenticated requests are denied."""
        self.client.force_authenticate(user=None)
        response = self.client.get(reverse('custom_lists:list-create'), HTTP_X_DISABLE_TEST_AUTH='1')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_cannot_modify_other_users_list(self):
        """Test that users cannot modify other users' lists."""
        other_list = CustomListService.create_list(owner_user_id=self.other_user.entra_id, name="Other User List")
        response = self.client.patch(
            reverse('custom_lists:detail', kwargs={'list_id': other_list.id}),
            {'name': 'Hacked'},
            format='json',
        )
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


class CustomListPaginationTest(BaseAPITestCase):
    """Tests for Custom Lists pagination."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(entra_id="pagination_test_user", email="pagination@example.com")
        for i in range(15):
            CustomListService.create_list(owner_user_id=self.user.entra_id, name=f"List {i}")
        self.client.force_authenticate(user=self.user)

    def test_lists_are_paginated(self):
        """Test that list results are paginated."""
        response = self.client.get(reverse('custom_lists:list-create'), {'limit': 5})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 5)
        self.assertEqual(response.data['count'], 15)
        self.assertIsNotNone(response.data['next'])


class CustomListAsFilterTest(BaseAPITestCase):
    """Tests for using custom lists as filters."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(entra_id="filter_test_user", email="filter@example.com")
        self.vendor = TestDataFactory.create_vendor()
        self.materials = TestDataFactory.create_multiple_materials(count=10, vendor=self.vendor)
        self.custom_list = CustomListService.create_list(owner_user_id=self.user.entra_id, name="Filter Test List")
        self.list_materials = self.materials[:3]
        entity_ids = [m.mat_nbr for m in self.list_materials]
        CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=entity_ids,
            added_by_id=self.user.entra_id,
        )
        self.client.force_authenticate(user=self.user)

    def test_filter_materials_by_custom_list(self):
        """Test filtering materials endpoint by custom list."""
        response = self.client.get(
            reverse('material:material-list'),
            {'custom_list': self.custom_list.id, 'limit': 100},
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 3)
        returned_mat_nbrs = {m['mat_nbr'] for m in response.data['results']}
        expected_mat_nbrs = {m.mat_nbr for m in self.list_materials}
        self.assertEqual(returned_mat_nbrs, expected_mat_nbrs)

    def test_filter_by_empty_custom_list(self):
        """Test filtering by an empty custom list returns no results."""
        empty_list = CustomListService.create_list(owner_user_id=self.user.entra_id, name="Empty List")
        response = self.client.get(
            reverse('material:material-list'),
            {'custom_list': empty_list.id, 'limit': 100},
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 0)

    def test_filter_by_nonexistent_custom_list(self):
        """Test filtering by non-existent custom list returns no results."""
        fake_uuid = uuid.uuid4()
        response = self.client.get(
            reverse('material:material-list'),
            {'custom_list': fake_uuid, 'limit': 100},
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 0)

    def test_filter_by_other_users_list(self):
        """Test filtering by another user's list returns no results."""
        other_user = TestDataFactory.create_test_user(entra_id="other_filter_user", email="other_filter@example.com")
        other_list = CustomListService.create_list(owner_user_id=other_user.entra_id, name="Other List")
        CustomListItemService.sync_items(
            custom_list=other_list,
            entity_ids=[self.materials[0].mat_nbr],
            added_by_id=other_user.entra_id,
        )
        response = self.client.get(
            reverse('material:material-list'),
            {'custom_list': other_list.id, 'limit': 100},
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 0)
