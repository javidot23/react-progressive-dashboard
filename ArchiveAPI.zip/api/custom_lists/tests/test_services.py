"""
Tests for Custom Lists services.
"""
from api.custom_lists.services import CustomListService, CustomListItemService
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory
from api.custom_lists.models import CustomList


class CustomListServiceTest(BaseTestCase):
    """Tests for CustomListService."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(entra_id="test_user_lists", email="testuser@example.com")

    def test_create_list_success(self):
        """Test creating a custom list successfully."""
        custom_list = CustomListService.create_list(
            owner_user_id=self.user.entra_id,
            name="My Materials",
            description="Test list",
        )
        self.assertIsNotNone(custom_list)
        self.assertEqual(custom_list.name, "My Materials")
        self.assertEqual(custom_list.owner_user_id, self.user.entra_id)
        self.assertEqual(custom_list.items_count, 0)
        self.assertFalse(custom_list.is_archived)

    def test_create_list_duplicate_name_fails(self):
        """Test that duplicate names within same owner fail."""
        CustomListService.create_list(owner_user_id=self.user.entra_id, name="Duplicate Name")
        with self.assertRaises(ValueError) as context:
            CustomListService.create_list(owner_user_id=self.user.entra_id, name="Duplicate Name")
        self.assertIn("already exists", str(context.exception))

    def test_update_list_success(self):
        """Test updating a custom list."""
        custom_list = CustomListService.create_list(owner_user_id=self.user.entra_id, name="Original Name")
        updated = CustomListService.update_list(
            custom_list=custom_list,
            name="New Name",
            description="Updated description",
            color="#FF0000",
        )
        self.assertEqual(updated.name, "New Name")
        self.assertEqual(updated.description, "Updated description")
        self.assertEqual(updated.color, "#FF0000")

    def test_update_list_name_to_existing_fails(self):
        """Test that updating name to existing name fails."""
        CustomListService.create_list(owner_user_id=self.user.entra_id, name="Existing Name")
        list2 = CustomListService.create_list(owner_user_id=self.user.entra_id, name="Another Name")
        with self.assertRaises(ValueError) as context:
            CustomListService.update_list(custom_list=list2, name="Existing Name")
        self.assertIn("already exists", str(context.exception))

    def test_delete_list(self):
        """Test deleting a custom list permanently removes it."""
        custom_list = CustomListService.create_list(owner_user_id=self.user.entra_id, name="To Delete")
        list_id = custom_list.id
        CustomListService.delete_list(custom_list)
        self.assertFalse(CustomList.objects.filter(id=list_id).exists())


class CustomListItemServiceTest(BaseTestCase):
    """Tests for CustomListItemService."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(entra_id="test_user_items", email="testuser@example.com")
        self.vendor = TestDataFactory.create_vendor()
        self.materials = TestDataFactory.create_multiple_materials(count=5, vendor=self.vendor)
        self.custom_list = CustomListService.create_list(owner_user_id=self.user.entra_id, name="Material List")

    def test_validate_material_ids(self):
        """Test validating material IDs."""
        valid_ids = [m.mat_nbr for m in self.materials[:3]]
        invalid_ids = ["INVALID1", "INVALID2"]
        all_ids = valid_ids + invalid_ids
        valid, invalid = CustomListItemService.validate_material_ids(entity_ids=all_ids)
        self.assertEqual(set(valid), set(valid_ids))
        self.assertEqual(set(invalid), set(invalid_ids))

    def test_sync_items_add_new(self):
        """Test sync_items adds new items."""
        entity_ids = [m.mat_nbr for m in self.materials[:3]]
        result = CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=entity_ids,
            added_by_id=self.user.entra_id,
        )
        self.assertEqual(result.added, 3)
        self.assertEqual(result.removed, 0)
        self.assertEqual(result.unchanged, 0)
        self.assertEqual(result.final_count, 3)
        self.custom_list.refresh_from_db()
        self.assertEqual(self.custom_list.items_count, 3)

    def test_sync_items_remove_unchecked(self):
        """Test sync_items removes unchecked items."""
        initial_ids = [m.mat_nbr for m in self.materials]
        CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=initial_ids,
            added_by_id=self.user.entra_id,
        )
        new_ids = [m.mat_nbr for m in self.materials[:2]]
        result = CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=new_ids,
            added_by_id=self.user.entra_id,
        )
        self.assertEqual(result.added, 0)
        self.assertEqual(result.removed, 3)
        self.assertEqual(result.unchanged, 2)
        self.assertEqual(result.final_count, 2)

    def test_sync_items_add_and_remove(self):
        """Test sync_items adds and removes in one operation."""
        initial_ids = [m.mat_nbr for m in self.materials[:3]]
        CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=initial_ids,
            added_by_id=self.user.entra_id,
        )
        new_ids = [m.mat_nbr for m in self.materials[1:5]]
        result = CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=new_ids,
            added_by_id=self.user.entra_id,
        )
        self.assertEqual(result.added, 2)
        self.assertEqual(result.removed, 1)
        self.assertEqual(result.unchanged, 2)
        self.assertEqual(result.final_count, 4)

    def test_sync_items_empty_clears_list(self):
        """Test sync_items with empty list clears all items."""
        initial_ids = [m.mat_nbr for m in self.materials[:3]]
        CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=initial_ids,
            added_by_id=self.user.entra_id,
        )
        result = CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=[],
            added_by_id=self.user.entra_id,
        )
        self.assertEqual(result.removed, 3)
        self.assertEqual(result.final_count, 0)

    def test_sync_items_skips_invalid_entities(self):
        """Test sync_items skips invalid entity IDs."""
        entity_ids = [self.materials[0].mat_nbr, 'INVALID_MATERIAL', self.materials[1].mat_nbr]
        result = CustomListItemService.sync_items(
            custom_list=self.custom_list,
            entity_ids=entity_ids,
            added_by_id=self.user.entra_id,
        )
        self.assertEqual(result.added, 2)
        self.assertIn('INVALID_MATERIAL', result.invalid)
