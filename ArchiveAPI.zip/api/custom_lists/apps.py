from django.apps import AppConfig

from config.db_scope import DBScope


class CustomListsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.custom_lists"
    db_scope = DBScope.CORE
