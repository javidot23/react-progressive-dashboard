from django.urls import path

from .views import (
    ChargebackGenerationStatusView,
    ChargebackRejectionsExportView,
    ChargebackRejectionsView,
    ChargebackSalesVsChargebacksTrendView,
    ChargebackSummaryView,
    DCOTrendView,
    RejectionReasonsView,
    RejectionVolumeView,
    SalesMissingChargebackExportView,
    SalesMissingChargebackView,
    UnvalidatedDurationView,
    ValidationTimelinessView,
)

app_name = "chargebacks"

urlpatterns = [
    path("summary/", ChargebackSummaryView.as_view(), name="summary"),
    path("sales-vs-chargebacks-trend/", ChargebackSalesVsChargebacksTrendView.as_view(),
         name="sales-vs-chargebacks-trend"),
    path("generation-status/", ChargebackGenerationStatusView.as_view(), name="generation-status"),
    path("missing/export/", SalesMissingChargebackExportView.as_view(), name="missing-export"),
    path("missing/", SalesMissingChargebackView.as_view(), name="missing"),
    path("dco-trend/", DCOTrendView.as_view(), name="dco-trend"),
    path("validation-timeliness/", ValidationTimelinessView.as_view(), name="validation-timeliness"),
    path("unvalidated-duration/", UnvalidatedDurationView.as_view(), name="unvalidated-duration"),
    path("rejection-volume/", RejectionVolumeView.as_view(), name="rejection-volume"),
    path("rejection-reasons/", RejectionReasonsView.as_view(), name="rejection-reasons"),
    path("rejections/export/", ChargebackRejectionsExportView.as_view(), name="rejections-export"),
    path("rejections/", ChargebackRejectionsView.as_view(), name="rejections"),
]
