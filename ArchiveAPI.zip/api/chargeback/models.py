from django.db import models

from api.material.models import Material


class Chargeback(models.Model):
    chbk_line_id = models.CharField(max_length=255, unique=True)
    chbk_nbr = models.CharField(max_length=255, null=True, blank=True)
    chbk_itm_nbr = models.CharField(max_length=255, null=True, blank=True)
    chbk_hdr_created_date = models.DateField(null=True, blank=True)
    chbk_hdr_changed_date = models.DateField(null=True, blank=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    invc_nbr = models.CharField(max_length=255, null=True, blank=True)
    invc_date = models.DateField(null=True, blank=True)
    abc_req_amt = models.DecimalField(max_digits=38, decimal_places=6, null=True, blank=True)
    vdr_accept_amt = models.DecimalField(max_digits=38, decimal_places=6, null=True, blank=True)
    chbk_qty = models.DecimalField(max_digits=18, decimal_places=2, null=True, blank=True)
    chbk_line_stat = models.CharField(max_length=255, null=True, blank=True)
    status = models.CharField(max_length=255, null=True, blank=True)
    reason_cd_desc = models.CharField(max_length=255, null=True, blank=True)
    last_posting_date = models.DateField(null=True, blank=True)
    dco_days = models.IntegerField(null=True, blank=True)
    dm_post_date = models.DateField(null=True, blank=True)
    settl_doc_nbr = models.CharField(max_length=255, null=True, blank=True)
    contr_nbr = models.CharField(max_length=255, null=True, blank=True)
    accept_amt_stat = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "chargebacks"
        verbose_name = "Chargeback"
        verbose_name_plural = "Chargebacks"
        indexes = [
            models.Index(fields=["chbk_hdr_created_date"]),
            models.Index(fields=["material"]),
            models.Index(fields=["invc_nbr"]),
        ]
