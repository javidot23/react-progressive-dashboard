from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers


class ChargebackSummarySerializer(serializers.Serializer):
    contract_sales_amount = serializers.DecimalField(max_digits=38, decimal_places=6, allow_null=True)
    contract_sales_qty = serializers.DecimalField(max_digits=18, decimal_places=3, allow_null=True)
    chargeback_amount = serializers.DecimalField(max_digits=38, decimal_places=6, allow_null=True)
    contract_sales_amount_last_week = serializers.DecimalField(
        max_digits=38, decimal_places=6, allow_null=True
    )
    contract_sales_qty_last_week = serializers.DecimalField(
        max_digits=18, decimal_places=3, allow_null=True
    )
    chargeback_amount_last_week = serializers.DecimalField(
        max_digits=38, decimal_places=6, allow_null=True
    )
    contract_sales_pct_change = serializers.FloatField(allow_null=True)


class ChargebackWeeklyTrendSerializer(serializers.Serializer):
    week = serializers.DateField(allow_null=True)
    contract_sales_amount = serializers.DecimalField(max_digits=38, decimal_places=6, allow_null=True)
    chargeback_amount = serializers.DecimalField(max_digits=38, decimal_places=6, allow_null=True)


class ChargebackGenerationStatusSerializer(serializers.Serializer):
    week_bucket = serializers.DateField()
    chargebacks_generated_units = serializers.DecimalField(max_digits=18, decimal_places=3, allow_null=True)
    not_generated_units = serializers.DecimalField(max_digits=18, decimal_places=3, allow_null=True)
    pct_generated = serializers.FloatField(allow_null=True)


class SalesMissingChargebackSerializer(serializers.Serializer):
    material_id = serializers.SerializerMethodField()
    material_name = serializers.SerializerMethodField()
    ndc = serializers.CharField(allow_null=True)
    invoice_date = serializers.DateField(allow_null=True)
    invoice_number = serializers.CharField(allow_null=True)
    manufacturer_contract_name = serializers.CharField(allow_null=True)
    contract_sales_and_rebill_qty = serializers.DecimalField(max_digits=18, decimal_places=3, allow_null=True)
    contract_sales_and_rebill_amount = serializers.DecimalField(max_digits=38, decimal_places=6, allow_null=True)

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_material_id(self, obj):
        return obj.material.mat_nbr if obj.material_id else None

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_material_name(self, obj):
        return obj.material.name if obj.material_id else None


class DCOTrendWeekSerializer(serializers.Serializer):
    week = serializers.DateField(allow_null=True)
    average_dco = serializers.FloatField(allow_null=True)


class DCOTrendSerializer(serializers.Serializer):
    overall_average_dco = serializers.FloatField(allow_null=True)
    trend = DCOTrendWeekSerializer(many=True)


class TimelinessBucketSerializer(serializers.Serializer):
    bucket = serializers.CharField()
    count = serializers.IntegerField()


class RejectionVolumeWeekSerializer(serializers.Serializer):
    week = serializers.DateField(allow_null=True)
    accepted = serializers.IntegerField()
    rejected = serializers.IntegerField()
    not_validated = serializers.IntegerField()


class RejectionReasonSerializer(serializers.Serializer):
    rejection_reason = serializers.SerializerMethodField()
    count = serializers.IntegerField()

    @extend_schema_field(serializers.CharField())
    def get_rejection_reason(self, obj):
        return obj["reason_cd_desc"] or "Not Provided"


class ChargebackRejectionSerializer(serializers.Serializer):
    mat_nbr = serializers.SerializerMethodField()
    material_name = serializers.SerializerMethodField()
    ndc = serializers.SerializerMethodField()
    debit_memo_date = serializers.DateField(source="dm_post_date", allow_null=True)
    debit_memo_no = serializers.CharField(source="chbk_nbr", allow_null=True)
    chargeback_validation_date = serializers.DateField(source="last_posting_date", allow_null=True)
    rejection_reason = serializers.CharField(source="reason_cd_desc", allow_null=True)
    chargeback_line_id = serializers.CharField(source="chbk_line_id")
    chargeback_qty = serializers.DecimalField(source="chbk_qty", max_digits=18, decimal_places=2, allow_null=True)
    chargeback_submitted_amt = serializers.DecimalField(source="abc_req_amt", max_digits=38, decimal_places=6,
                                                        allow_null=True)
    chargeback_validation_amt = serializers.DecimalField(source="vdr_accept_amt", max_digits=38, decimal_places=6,
                                                         allow_null=True)
    invoice_number = serializers.CharField(source="invc_nbr", allow_null=True)
    settlement_doc = serializers.CharField(source="settl_doc_nbr", allow_null=True)
    contract_number = serializers.CharField(source="contr_nbr", allow_null=True)

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_mat_nbr(self, obj):
        return obj.material.mat_nbr if obj.material_id else None

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_material_name(self, obj):
        return obj.material.name if obj.material_id else None

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_ndc(self, obj):
        return obj.material.ndc if obj.material_id else None
