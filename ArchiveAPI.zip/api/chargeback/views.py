from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics
from rest_framework.exceptions import ValidationError
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.global_filters import get_filtered_material_subquery
from .filters import ChargebackRejectionFilter, SalesMissingChargebackFilter
from .serializers import (
    ChargebackGenerationStatusSerializer,
    ChargebackRejectionSerializer,
    ChargebackSummarySerializer,
    ChargebackWeeklyTrendSerializer,
    DCOTrendSerializer,
    RejectionReasonSerializer,
    RejectionVolumeWeekSerializer,
    SalesMissingChargebackSerializer,
    TimelinessBucketSerializer,
)
from .services import ChargebackService
from ..pagination import MaxLimitOffsetPagination


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="get")
class ChargebackSummaryView(APIView):
    """KPI summary — this week's contract sales/rebills vs last week (WoW %)."""

    @extend_schema(responses=ChargebackSummarySerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ChargebackService.get_summary(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = ChargebackSummarySerializer(data)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="list")
class ChargebackSalesVsChargebacksTrendView(generics.ListAPIView):
    """Weekly contract sales vs chargeback amount trend (last 90 days)."""

    serializer_class = ChargebackWeeklyTrendSerializer
    pagination_class = None

    def list(self, request, *args, **kwargs):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ChargebackService.get_sales_vs_chargebacks_trend(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = self.get_serializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="list")
class ChargebackGenerationStatusView(generics.ListAPIView):
    """Weekly chargeback generation status (last 90 days).
    """

    serializer_class = ChargebackGenerationStatusSerializer
    pagination_class = None

    def list(self, request, *args, **kwargs):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ChargebackService.get_generation_status(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = self.get_serializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="list")
class SalesMissingChargebackView(generics.ListAPIView):
    """Paginated list of sales lines missing chargebacks."""

    serializer_class = SalesMissingChargebackSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = SalesMissingChargebackFilter
    ordering_fields = ["invoice_date", "contract_sales_and_rebill_amount", "contract_sales_and_rebill_qty"]
    ordering = ["-invoice_date"]

    def get_queryset(self):
        return ChargebackService.get_missing_chargebacks()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="get")
class DCOTrendView(APIView):
    """Monthly average DCO trend"""

    @extend_schema(responses=DCOTrendSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ChargebackService.get_dco_trend(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = DCOTrendSerializer(data)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="list")
class ValidationTimelinessView(generics.ListAPIView):
    """Validated debit memos bucketed by days to validate (last 8 months)."""

    serializer_class = TimelinessBucketSerializer
    pagination_class = None

    def list(self, request, *args, **kwargs):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ChargebackService.get_validation_timeliness(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = self.get_serializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="list")
class UnvalidatedDurationView(generics.ListAPIView):
    """Unvalidated debit memos bucketed by days waiting (last 8 months)."""

    serializer_class = TimelinessBucketSerializer
    pagination_class = None

    def list(self, request, *args, **kwargs):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ChargebackService.get_unvalidated_duration(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = self.get_serializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="list")
class RejectionVolumeView(generics.ListAPIView):
    """Weekly chargeback rejection volume (accepted / rejected / not validated), last 90 days."""

    serializer_class = RejectionVolumeWeekSerializer
    pagination_class = None

    def list(self, request, *args, **kwargs):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        queryset = ChargebackService.get_rejection_volume(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="list")
class RejectionReasonsView(generics.ListAPIView):
    """Count of rejections per reason (last 8 months)."""

    serializer_class = RejectionReasonSerializer
    pagination_class = None

    def list(self, request, *args, **kwargs):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        queryset = ChargebackService.get_rejection_reasons(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name="list")
class ChargebackRejectionsView(generics.ListAPIView):
    """Paginated list of rejected chargeback lines (last 8 months)."""

    serializer_class = ChargebackRejectionSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = ChargebackRejectionFilter
    ordering_fields = ["dm_post_date", "chbk_qty", "abc_req_amt"]
    ordering = ["-dm_post_date"]

    def get_queryset(self):
        raw_days = self.request.query_params.get("days", "90")
        try:
            days = int(raw_days)
        except (TypeError, ValueError):
            raise ValidationError({"days": "Must be an integer."})
        return ChargebackService.get_rejections(days=days)
