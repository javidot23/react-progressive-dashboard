import logging
from datetime import date, timedelta
from decimal import Decimal

from django.db.models import (
    Avg,
    Case,
    Count,
    DateField,
    DecimalField,
    DurationField,
    Exists,
    ExpressionWrapper,
    F,
    IntegerField,
    OuterRef,
    Q,
    Sum,
    Value,
    When,
)
from django.db.models.functions import Coalesce, TruncWeek

from api.billing_transaction.models import BillingTransaction
from api.chargeback.models import Chargeback
from api.csv_export import csv_cell, csv_date
from api.date_bounds import iso_week_bounds
from api.sales_missing_chargeback.models import SalesMissingChargeback

logger = logging.getLogger(__name__)

OPEN_CLOSED = ("Open", "Closed")

DURATION_BUCKETS = (
    ("4-5 days", 3, 5),
    ("6-10 days", 5, 10),
    ("11-20 days", 10, 20),
    ("21-45 days", 20, 45),
    ("46-60 days", 45, 60),
    ("61-90 days", 60, 90),
    ("91-100 days", 90, 100),
)


class ChargebackService:
    """Service class for handling chargeback operations."""

    @staticmethod
    def _bucket_count_aggregates(field):
        """
        Build conditional-aggregation kwargs that count rows per DURATION_BUCKETS
        bucket in the database, given an annotated DurationField `field`.
        """
        return {
            f"b{i}": Count(
                "id",
                filter=Q(
                    **{
                        f"{field}__gt": timedelta(days=lo),
                        f"{field}__lte": timedelta(days=hi),
                    }
                ),
            )
            for i, (_, lo, hi) in enumerate(DURATION_BUCKETS)
        }

    @staticmethod
    def _buckets_from_aggregate(agg):
        """Map the aggregate result back to the ordered [{bucket, count}] payload."""
        return [
            {"bucket": label, "count": agg.get(f"b{i}") or 0}
            for i, (label, _, _) in enumerate(DURATION_BUCKETS)
        ]

    @staticmethod
    def _apply_mat_nbr_filter(queryset, direct_mat_nbr=None, mat_nbr_subquery=None):
        """Apply material filter using the optimized mat_nbr subquery pattern."""
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        elif mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
        return queryset

    @staticmethod
    def get_summary(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        KPI summary: contract sales amount/qty and chargeback amount for this ISO week,
        plus last-week amounts and week-over-week pct change on contract sales.
        """
        this_start, this_end, last_start, last_end = iso_week_bounds()
        logger.info(
            "Retrieving chargeback summary, this_week=%s..%s last_week=%s..%s",
            this_start, this_end, last_start, last_end,
        )

        def _bt_agg(start, end):
            qs = BillingTransaction.objects.filter(
                ord_created_date__gte=start,
                ord_created_date__lte=end,
            )
            qs = ChargebackService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)
            return qs.aggregate(
                contract_sales_amount=Coalesce(
                    Sum("sales_contr_amt"), Value(0), output_field=DecimalField()
                ),
                contract_sales_qty=Coalesce(
                    Sum("sales_contr_qty"), Value(0), output_field=DecimalField()
                ),
            )

        def _cb_amount(start, end):
            qs = Chargeback.objects.filter(
                chbk_hdr_created_date__gte=start,
                chbk_hdr_created_date__lte=end,
                chbk_line_stat__in=OPEN_CLOSED,
            )
            qs = ChargebackService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)
            return qs.aggregate(
                chargeback_amount=Coalesce(
                    Sum("abc_req_amt"), Value(0), output_field=DecimalField()
                ),
            )["chargeback_amount"]

        this_bt = _bt_agg(this_start, this_end)
        last_bt = _bt_agg(last_start, last_end)
        this_cb = _cb_amount(this_start, this_end)
        last_cb = _cb_amount(last_start, last_end)

        this_sales = this_bt["contract_sales_amount"]
        last_sales = last_bt["contract_sales_amount"]
        if last_sales and last_sales != 0:
            pct_change = float((this_sales - last_sales) / last_sales * 100)
        else:
            pct_change = None

        return {
            "contract_sales_amount": this_sales,
            "contract_sales_qty": this_bt["contract_sales_qty"],
            "chargeback_amount": this_cb,
            "contract_sales_amount_last_week": last_sales,
            "contract_sales_qty_last_week": last_bt["contract_sales_qty"],
            "chargeback_amount_last_week": last_cb,
            "contract_sales_pct_change": pct_change,
        }

    @staticmethod
    def get_sales_vs_chargebacks_trend(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Weekly sales vs chargeback trend for last 90 days.
        Returns a list of {week, contract_sales_amount, chargeback_amount}.
        """
        logger.info("Retrieving sales vs chargebacks trend")
        cutoff = date.today() - timedelta(days=90)

        bt_qs = BillingTransaction.objects.filter(ord_created_date__gte=cutoff)
        bt_qs = ChargebackService._apply_mat_nbr_filter(bt_qs, direct_mat_nbr, mat_nbr_subquery)

        weekly_sales = (
            bt_qs
            .annotate(week=TruncWeek("ord_created_date"))
            .values("week")
            .annotate(contract_sales_amount=Coalesce(Sum("sales_contr_amt"), Value(0), output_field=DecimalField()))
            .order_by("week")
        )

        cb_qs = Chargeback.objects.filter(
            chbk_hdr_created_date__gte=cutoff,
            chbk_line_stat__in=OPEN_CLOSED,
        )
        cb_qs = ChargebackService._apply_mat_nbr_filter(cb_qs, direct_mat_nbr, mat_nbr_subquery)

        weekly_cb = (
            cb_qs
            .annotate(week=TruncWeek("chbk_hdr_created_date"))
            .values("week")
            .annotate(chargeback_amount=Coalesce(Sum("abc_req_amt"), Value(0), output_field=DecimalField()))
        )

        cb_lookup = {row["week"]: row["chargeback_amount"] for row in weekly_cb}

        return [
            {
                "week": row["week"],
                "contract_sales_amount": row["contract_sales_amount"],
                "chargeback_amount": cb_lookup.get(row["week"], 0),
            }
            for row in weekly_sales
        ]

    @staticmethod
    def get_dco_trend(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Weekly average DCO trend (global — no material filter).
        Window: last 90 days.
        Returns {overall_average_dco, trend: [{week, average_dco}]}.
        """
        logger.info("Retrieving DCO trend")
        cutoff = date.today() - timedelta(days=90)

        base_qs = Chargeback.objects.filter(chbk_hdr_created_date__gte=cutoff)
        base_qs = ChargebackService._apply_mat_nbr_filter(base_qs, direct_mat_nbr, mat_nbr_subquery)

        trend = (
            base_qs
            .annotate(week=TruncWeek("chbk_hdr_created_date"))
            .values("week")
            .annotate(average_dco=Avg("dco_days"))
            .order_by("week")
        )

        overall = base_qs.aggregate(overall=Avg("dco_days"))["overall"]

        return {
            "overall_average_dco": overall,
            "trend": [
                {"week": row["week"], "average_dco": row["average_dco"]}
                for row in trend
                if row["week"] is not None
            ],
        }

    @staticmethod
    def get_generation_status(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Weekly chargeback generation status for last 90 days.

        Logic :
          - Source: BillingTransaction filtered to sales_contr_qty > 0 and window.
          - LEFT JOIN to Chargeback on (invc_nbr, mat_nbr) where chbk_line_stat IN ('Open','Closed').
          - chargebacks_generated_units = SUM(qty) where a matching chargeback exists.
          - not_generated_units        = SUM(qty) where no matching chargeback exists.
          - pct_generated              = generated * 100 / (generated + not_generated), rounded to 2dp.
        """
        logger.info("Retrieving generation status")
        cutoff = date.today() - timedelta(days=90)

        has_chargeback = Exists(
            Chargeback.objects.filter(
                invc_nbr=OuterRef("invc_nbr"),
                material=OuterRef("material"),
                chbk_line_stat__in=OPEN_CLOSED,
            )
        )

        bt_qs = BillingTransaction.objects.filter(
            ord_created_date__gte=cutoff,
            sales_contr_qty__gt=0,
        )
        bt_qs = ChargebackService._apply_mat_nbr_filter(bt_qs, direct_mat_nbr, mat_nbr_subquery)

        weekly = (
            bt_qs
            .annotate(week_bucket=TruncWeek("ord_created_date"), has_cb=has_chargeback)
            .values("week_bucket")
            .annotate(
                chargebacks_generated_units=Coalesce(
                    Sum(Case(When(has_cb=True, then="sales_contr_qty"),
                             default=Value(0), output_field=DecimalField())),
                    Value(0), output_field=DecimalField(),
                ),
                not_generated_units=Coalesce(
                    Sum(Case(When(has_cb=False, then="sales_contr_qty"),
                             default=Value(0), output_field=DecimalField())),
                    Value(0), output_field=DecimalField(),
                ),
            )
            .order_by("week_bucket")
        )

        results = []
        for row in weekly:
            generated = row["chargebacks_generated_units"] or Decimal("0")
            not_generated = row["not_generated_units"] or Decimal("0")
            total = generated + not_generated
            pct = round(float(generated) * 100.0 / float(total), 2) if total else None
            results.append({
                "week_bucket": row["week_bucket"],
                "chargebacks_generated_units": generated,
                "not_generated_units": not_generated,
                "pct_generated": pct,
            })
        return results

    @staticmethod
    def get_missing_chargebacks():
        """Sales missing chargebacks. Filtering delegated to view's FilterSet."""
        logger.info("Retrieving missing chargebacks")
        return SalesMissingChargeback.objects.select_related("material").all()

    MISSING_CHARGEBACK_CSV_HEADERS = [
        "Invoice number",
        "Invoice date",
        "Product name",
        "Product Id",
        "NDC",
        "Contract sales & rebill qty",
        "Contract sales & rebill amount",
        "Manufacturer Contract",
    ]

    @classmethod
    def iter_missing_chargeback_csv_rows(cls, queryset, chunk_size=2000):
        """
        Yield CSV header then data rows for sales missing chargebacks.
        Uses queryset.iterator to keep memory bounded for large exports.
        """
        yield list(cls.MISSING_CHARGEBACK_CSV_HEADERS)
        for row in queryset.iterator(chunk_size=chunk_size):
            material = row.material if row.material_id else None
            yield [
                csv_cell(row.invoice_number),
                csv_date(row.invoice_date),
                csv_cell(material.name if material else None),
                csv_cell(material.mat_nbr if material else None),
                csv_cell(row.ndc),
                csv_cell(row.contract_sales_and_rebill_qty),
                csv_cell(row.contract_sales_and_rebill_amount),
                csv_cell(row.manufacturer_contract_name),
            ]

    @staticmethod
    def get_validation_timeliness(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Validated debit memos (last_posting_date NOT NULL) bucketed by days to validate.
        Only includes records that took more than 3 days to validate.
        Window: last 90 days.
        """
        logger.info("Retrieving validation timeliness")
        cutoff = date.today() - timedelta(days=90)
        qs = Chargeback.objects.filter(
            last_posting_date__isnull=False,
            chbk_line_stat__in=OPEN_CLOSED,
            chbk_hdr_created_date__gte=cutoff,
        )
        qs = ChargebackService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)

        days = ExpressionWrapper(
            F("last_posting_date") - F("chbk_hdr_created_date"),
            output_field=DurationField(),
        )
        agg = qs.annotate(days=days).aggregate(
            **ChargebackService._bucket_count_aggregates("days")
        )

        return ChargebackService._buckets_from_aggregate(agg)

    @staticmethod
    def get_unvalidated_duration(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Unvalidated debit memos (last_posting_date IS NULL) bucketed by days waiting.
        Only includes records unvalidated for more than 3 days.
        Window: last 90 days.
        """
        logger.info("Retrieving unvalidated duration")
        cutoff = date.today() - timedelta(days=90)
        qs = Chargeback.objects.filter(
            last_posting_date__isnull=True,
            chbk_line_stat__in=OPEN_CLOSED,
            chbk_hdr_created_date__gte=cutoff,
        )
        qs = ChargebackService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)

        today = date.today()
        days = ExpressionWrapper(
            Value(today, output_field=DateField()) - F("chbk_hdr_created_date"),
            output_field=DurationField(),
        )
        agg = qs.annotate(days=days).aggregate(
            **ChargebackService._bucket_count_aggregates("days")
        )

        return ChargebackService._buckets_from_aggregate(agg)

    @staticmethod
    def get_rejection_volume(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Weekly chargeback rejection volume (accepted / rejected / not validated).
        Window: last 90 days.
        """
        logger.info("Retrieving rejection volume")
        cutoff = date.today() - timedelta(days=90)
        qs = Chargeback.objects.filter(
            chbk_line_stat__in=OPEN_CLOSED,
            chbk_hdr_created_date__gte=cutoff,
        )
        qs = ChargebackService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)

        return (
            qs
            .annotate(week=TruncWeek("chbk_hdr_created_date"))
            .values("week")
            .annotate(
                rejected=Sum(
                    Case(
                        When(reason_cd_desc__isnull=False, then=Value(1)),
                        default=Value(0),
                        output_field=IntegerField(),
                    )
                ),
                not_validated=Sum(
                    Case(
                        When(last_posting_date__isnull=True, then=Value(1)),
                        default=Value(0),
                        output_field=IntegerField(),
                    )
                ),
                accepted=Sum(
                    Case(
                        When(
                            reason_cd_desc__isnull=True,
                            last_posting_date__isnull=False,
                            then=Value(1),
                        ),
                        default=Value(0),
                        output_field=IntegerField(),
                    )
                ),
            )
            .order_by("week")
        )

    @staticmethod
    def get_rejection_reasons(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Count of rejections per reason (last 90 days, only rejected lines).
        """
        logger.info("Retrieving rejection reasons")
        cutoff = date.today() - timedelta(days=90)
        qs = Chargeback.objects.filter(
            reason_cd_desc__isnull=False,
            chbk_line_stat__in=OPEN_CLOSED,
            chbk_hdr_created_date__gte=cutoff,
        )
        qs = ChargebackService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)

        return (
            qs
            .values("reason_cd_desc")
            .annotate(count=Count("id"))
            .order_by("-count")
        )

    @staticmethod
    def get_rejections(days=90):
        """
        Paginated list of rejected chargeback lines.
        Window: last `days` days (default 90).
        Filtering (supplier, rejection_reason) delegated to view's FilterSet.
        """
        logger.info("Retrieving rejections, days=%s", days)
        cutoff = date.today() - timedelta(days=days)
        return (
            Chargeback.objects.filter(
                reason_cd_desc__isnull=False,
                chbk_line_stat__in=OPEN_CLOSED,
                chbk_hdr_created_date__gte=cutoff,
            )
            .select_related("material")
            .order_by("-dm_post_date", "chbk_line_id")
        )

    REJECTION_CSV_HEADERS = [
        "Product name",
        "Product ID",
        "NDC",
        "Debit Memo Date",
        "Debit Memo No",
        "Chargeback Validation Date",
        "Rejection Reason",
        "Chargeback Line ID",
        "Chargeback Qty",
        "Submitted Amt",
        "Validation Amt",
        "Invoice Number",
        "Settlement Doc",
        "Contract Number",
    ]

    @classmethod
    def iter_rejection_csv_rows(cls, queryset, chunk_size=2000):
        """
        Yield CSV header then data rows for Active Rejected Chargebacks.
        Uses queryset.iterator to keep memory bounded for large exports.
        """
        yield list(cls.REJECTION_CSV_HEADERS)
        for row in queryset.iterator(chunk_size=chunk_size):
            material = row.material if row.material_id else None
            yield [
                csv_cell(material.name if material else None),
                csv_cell(material.mat_nbr if material else None),
                csv_cell(material.ndc if material else None),
                csv_date(row.dm_post_date),
                csv_cell(row.chbk_nbr),
                csv_date(row.last_posting_date),
                csv_cell(row.reason_cd_desc),
                csv_cell(row.chbk_line_id),
                csv_cell(row.chbk_qty),
                csv_cell(row.abc_req_amt),
                csv_cell(row.vdr_accept_amt),
                csv_cell(row.invc_nbr),
                csv_cell(row.settl_doc_nbr),
                csv_cell(row.contr_nbr),
            ]
