from datetime import date, timedelta

from django.urls import reverse

from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class ChargebackViewTestMixin:
    def setUp(self):
        super().setUp()
        user = TestDataFactory.create_test_user()
        self.client.force_authenticate(user=user, token="test-token")


class ChargebackSummaryViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200_with_success(self):
        response = self.client.get(reverse("chargebacks:summary"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        payload = data["data"]
        for key in (
            "contract_sales_amount",
            "chargeback_amount",
            "contract_sales_amount_last_week",
            "chargeback_amount_last_week",
            "contract_sales_pct_change",
        ):
            self.assertIn(key, payload)

    def test_supplier_filter(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(vendor=vendor, material=material, sales_contr_amt=5000.0)
        response = self.client.get(reverse("chargebacks:summary"), {"supplier_nbr": vendor.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])


class ChargebackSalesVsChargebacksTrendViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:sales-vs-chargebacks-trend"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)

    def test_with_data(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(vendor=vendor, material=material)
        response = self.client.get(
            reverse("chargebacks:sales-vs-chargebacks-trend"),
            {"supplier_nbr": vendor.vendor_nbr},
        )
        self.assertEqual(response.status_code, 200)
        self.assertGreater(len(response.json()["data"]), 0)


class ChargebackGenerationStatusViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:generation-status"))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])

    def test_with_data_returns_pct_generated(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=date.today() - timedelta(days=5),
            invc_nbr="INV-1", sales_contr_qty=10.0,
        )
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material, invc_nbr="INV-1", chbk_line_stat="Open",
        )
        response = self.client.get(
            reverse("chargebacks:generation-status"),
            {"supplier_nbr": vendor.vendor_nbr},
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()["data"]
        self.assertEqual(len(data), 1)
        self.assertIn("pct_generated", data[0])
        self.assertEqual(data[0]["pct_generated"], 100.0)


class SalesMissingChargebackViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:missing"))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])

    def test_pagination(self):
        vendor = TestDataFactory.create_vendor()
        for _ in range(5):
            TestDataFactory.create_sales_missing_chargeback(vendor=vendor)
        response = self.client.get(reverse("chargebacks:missing"), {"limit": 2, "offset": 0})
        self.assertEqual(response.status_code, 200)
        self.assertLessEqual(len(response.json()["data"]["results"]), 2)

    def test_supplier_filter(self):
        vendor_a = TestDataFactory.create_vendor()
        vendor_b = TestDataFactory.create_vendor()
        mat_a = TestDataFactory.create_material(vendor=vendor_a)
        mat_b = TestDataFactory.create_material(vendor=vendor_b)
        TestDataFactory.create_sales_missing_chargeback(vendor=vendor_a, material=mat_a)
        TestDataFactory.create_sales_missing_chargeback(vendor=vendor_b, material=mat_b)
        response = self.client.get(reverse("chargebacks:missing"), {"supplier_nbr": vendor_a.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        results = response.json()["data"]["results"]
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["material_id"], mat_a.mat_nbr)


class DCOTrendViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:dco-trend"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIn("overall_average_dco", data["data"])
        self.assertIn("trend", data["data"])


class ValidationTimelinessViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:validation-timeliness"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)

    def test_bucket_structure(self):
        vendor = TestDataFactory.create_vendor()
        today = date.today()
        TestDataFactory.create_chargeback(
            vendor=vendor,
            chbk_hdr_created_date=today - timedelta(days=10),
            last_posting_date=today - timedelta(days=6),
            chbk_line_stat="Open",
        )
        response = self.client.get(reverse("chargebacks:validation-timeliness"))
        self.assertEqual(response.status_code, 200)
        for item in response.json()["data"]:
            self.assertIn("bucket", item)
            self.assertIn("count", item)


class UnvalidatedDurationViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:unvalidated-duration"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)


class RejectionVolumeViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:rejection-volume"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)

    def test_with_data(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=date.today() - timedelta(days=10),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        response = self.client.get(reverse("chargebacks:rejection-volume"), {"supplier_nbr": vendor.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        for item in response.json()["data"]:
            self.assertIn("week", item)
            self.assertIn("rejected", item)
            self.assertIn("accepted", item)
            self.assertIn("not_validated", item)


class RejectionReasonsViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:rejection-reasons"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)

    def test_with_data(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=date.today() - timedelta(days=10),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        response = self.client.get(reverse("chargebacks:rejection-reasons"), {"supplier_nbr": vendor.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        data = response.json()["data"]
        self.assertGreater(len(data), 0)
        self.assertIn("rejection_reason", data[0])
        self.assertIn("count", data[0])


class ChargebackRejectionsViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:rejections"))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])

    def test_pagination(self):
        vendor = TestDataFactory.create_vendor()
        for _ in range(5):
            TestDataFactory.create_chargeback(
                vendor=vendor,
                chbk_hdr_created_date=date.today() - timedelta(days=10),
                chbk_line_stat="Open",
                reason_cd_desc="Drug Not Covered",
            )
        response = self.client.get(reverse("chargebacks:rejections"), {"limit": 2, "offset": 0})
        self.assertEqual(response.status_code, 200)
        self.assertLessEqual(len(response.json()["data"]["results"]), 2)

    def test_supplier_filter(self):
        vendor_a = TestDataFactory.create_vendor()
        vendor_b = TestDataFactory.create_vendor()
        recent = date.today() - timedelta(days=10)
        TestDataFactory.create_chargeback(
            vendor=vendor_a,
            chbk_hdr_created_date=recent,
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        TestDataFactory.create_chargeback(
            vendor=vendor_b,
            chbk_hdr_created_date=recent,
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        response = self.client.get(reverse("chargebacks:rejections"), {"supplier_nbr": vendor_a.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        for row in response.json()["data"]["results"]:
            self.assertEqual(row["chargeback_line_id"][:4], "CHBK")

    def test_ordering(self):
        vendor = TestDataFactory.create_vendor()
        recent = date.today() - timedelta(days=10)
        TestDataFactory.create_chargeback(
            vendor=vendor,
            chbk_hdr_created_date=recent,
            dm_post_date=recent,
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        response = self.client.get(reverse("chargebacks:rejections"), {"ordering": "-dm_post_date"})
        self.assertEqual(response.status_code, 200)
