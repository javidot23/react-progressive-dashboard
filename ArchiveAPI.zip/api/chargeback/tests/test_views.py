from datetime import date, timedelta
from unittest.mock import MagicMock, patch

from django.urls import reverse
from rest_framework import status

from api.csv_export import DEFAULT_EXPORT_MAX_ROWS
from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class ChargebackViewTestMixin:
    def setUp(self):
        super().setUp()
        user = TestDataFactory.create_test_user()
        self.client.force_authenticate(user=user, token="test-token")


class ChargebackSummaryViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200_with_success(self):
        response = self.client.get(reverse("chargebacks:summary"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        payload = data["data"]
        for key in (
            "contract_sales_amount",
            "chargeback_amount",
            "contract_sales_amount_last_week",
            "chargeback_amount_last_week",
            "contract_sales_pct_change",
        ):
            self.assertIn(key, payload)

    def test_supplier_filter(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(vendor=vendor, material=material, sales_contr_amt=5000.0)
        response = self.client.get(reverse("chargebacks:summary"), {"supplier_nbr": vendor.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])


class ChargebackSalesVsChargebacksTrendViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:sales-vs-chargebacks-trend"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)

    def test_with_data(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(vendor=vendor, material=material)
        response = self.client.get(
            reverse("chargebacks:sales-vs-chargebacks-trend"),
            {"supplier_nbr": vendor.vendor_nbr},
        )
        self.assertEqual(response.status_code, 200)
        self.assertGreater(len(response.json()["data"]), 0)


class ChargebackGenerationStatusViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:generation-status"))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])

    def test_with_data_returns_pct_generated(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=date.today() - timedelta(days=5),
            invc_nbr="INV-1", sales_contr_qty=10.0,
        )
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material, invc_nbr="INV-1", chbk_line_stat="Open",
        )
        response = self.client.get(
            reverse("chargebacks:generation-status"),
            {"supplier_nbr": vendor.vendor_nbr},
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()["data"]
        self.assertEqual(len(data), 1)
        self.assertIn("pct_generated", data[0])
        self.assertEqual(data[0]["pct_generated"], 100.0)


class SalesMissingChargebackViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:missing"))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])

    def test_pagination(self):
        vendor = TestDataFactory.create_vendor()
        for _ in range(5):
            TestDataFactory.create_sales_missing_chargeback(vendor=vendor)
        response = self.client.get(reverse("chargebacks:missing"), {"limit": 2, "offset": 0})
        self.assertEqual(response.status_code, 200)
        self.assertLessEqual(len(response.json()["data"]["results"]), 2)

    def test_supplier_filter(self):
        vendor_a = TestDataFactory.create_vendor()
        vendor_b = TestDataFactory.create_vendor()
        mat_a = TestDataFactory.create_material(vendor=vendor_a)
        mat_b = TestDataFactory.create_material(vendor=vendor_b)
        TestDataFactory.create_sales_missing_chargeback(vendor=vendor_a, material=mat_a)
        TestDataFactory.create_sales_missing_chargeback(vendor=vendor_b, material=mat_b)
        response = self.client.get(reverse("chargebacks:missing"), {"supplier_nbr": vendor_a.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        results = response.json()["data"]["results"]
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["material_id"], mat_a.mat_nbr)

    def test_export_csv_shape_and_content(self):
        material = TestDataFactory.create_material(name="Missing CB Export Mat", ndc="55566677788")
        TestDataFactory.create_sales_missing_chargeback(
            material=material,
            invoice_number="INV-CB-EXPORT-1",
            ndc="55566677788",
            manufacturer_contract_name="Should Not Appear Contract",
        )

        response = self.client.get(reverse("chargebacks:missing-export"))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response["Content-Type"], "text/csv")
        self.assertIn("attachment; filename=", response["Content-Disposition"])
        self.assertIn("contract_sales_without_chargebacks_", response["Content-Disposition"])
        self.assertEqual(response.get("X-Accel-Buffering"), "no")

        content = b"".join(response.streaming_content).decode("utf-8")
        lines = [line for line in content.splitlines() if line.strip()]
        self.assertGreaterEqual(len(lines), 2)
        self.assertIn("Invoice number", lines[0])
        self.assertIn("Product name", lines[0])
        self.assertIn("Contract sales & rebill amount", lines[0])
        self.assertIn("Manufacturer Contract", lines[0])
        matching = [line for line in lines[1:] if "INV-CB-EXPORT-1" in line]
        self.assertEqual(len(matching), 1)
        self.assertIn("Missing CB Export Mat", matching[0])
        self.assertIn("55566677788", matching[0])
        self.assertIn("Should Not Appear Contract", matching[0])

    def test_export_respects_filters_ignores_pagination_and_days(self):
        vendor_a = TestDataFactory.create_vendor()
        vendor_b = TestDataFactory.create_vendor()
        mat_a = TestDataFactory.create_material(vendor=vendor_a, name="CB Export Filter A")
        mat_b = TestDataFactory.create_material(vendor=vendor_b, name="CB Export Filter B")
        TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor_a,
            material=mat_a,
            invoice_number="INV-CB-EXPORT-FILT-A",
            invoice_date=date.today() - timedelta(days=120),
        )
        TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor_b,
            material=mat_b,
            invoice_number="INV-CB-EXPORT-FILT-B",
            invoice_date=date.today() - timedelta(days=1),
        )

        url = reverse("chargebacks:missing-export")
        filtered = self.client.get(url, {
            "supplier_nbr": vendor_a.vendor_nbr,
            "limit": 1,
            "offset": 0,
            "days": 90,
        })
        self.assertEqual(filtered.status_code, status.HTTP_200_OK)
        filtered_content = b"".join(filtered.streaming_content).decode("utf-8")
        self.assertIn("INV-CB-EXPORT-FILT-A", filtered_content)
        self.assertIn("CB Export Filter A", filtered_content)
        self.assertNotIn("INV-CB-EXPORT-FILT-B", filtered_content)

        unpaged = self.client.get(url, {"limit": 1, "offset": 0, "days": 90})
        self.assertEqual(unpaged.status_code, status.HTTP_200_OK)
        unpaged_content = b"".join(unpaged.streaming_content).decode("utf-8")
        self.assertIn("INV-CB-EXPORT-FILT-A", unpaged_content)
        self.assertIn("INV-CB-EXPORT-FILT-B", unpaged_content)

    def test_export_soft_cap(self):
        mock_qs = MagicMock()
        mock_qs.count.return_value = DEFAULT_EXPORT_MAX_ROWS + 1

        with patch(
            "api.csv_export.get_filtered_ordered_queryset",
            return_value=mock_qs,
        ):
            response = self.client.get(reverse("chargebacks:missing-export"))

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("Export exceeds the maximum", str(response.data["error"]))
        mock_qs.iterator.assert_not_called()

    def test_manufacturer_contract_name_list_returns_unique_non_empty_values(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)

        TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor,
            material=material,
            invoice_number="INV-MCN-1",
            manufacturer_contract_name="Contract A",
        )
        TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor,
            material=material,
            invoice_number="INV-MCN-2",
            manufacturer_contract_name="Contract B",
        )
        TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor,
            material=material,
            invoice_number="INV-MCN-3",
            manufacturer_contract_name="Contract A",
        )

        null_row = TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor,
            material=material,
            invoice_number="INV-MCN-4",
        )
        null_row.manufacturer_contract_name = None
        null_row.save(update_fields=["manufacturer_contract_name"])

        empty_row = TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor,
            material=material,
            invoice_number="INV-MCN-5",
        )
        empty_row.manufacturer_contract_name = ""
        empty_row.save(update_fields=["manufacturer_contract_name"])

        response = self.client.get(
            reverse("chargebacks:missing-manufacturer-contract-name-list"),
            {"limit": 10, "offset": 0},
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data["results"], list)

        names = [item["manufacturer_contract_name"] for item in response.data["results"]]

        self.assertEqual(len(names), 2)
        self.assertIn("Contract A", names)
        self.assertIn("Contract B", names)

        for item in response.data["results"]:
            self.assertIn("manufacturer_contract_name", item)
            self.assertEqual(len(item), 1)

    def test_manufacturer_contract_name_list_respects_global_material_filters(self):
        vendor_a = TestDataFactory.create_vendor()
        vendor_b = TestDataFactory.create_vendor()
        material_a = TestDataFactory.create_material(vendor=vendor_a)
        material_b = TestDataFactory.create_material(vendor=vendor_b)

        TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor_a,
            material=material_a,
            invoice_number="INV-MCN-FILT-1",
            manufacturer_contract_name="Vendor A Contract",
        )
        TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor_b,
            material=material_b,
            invoice_number="INV-MCN-FILT-2",
            manufacturer_contract_name="Vendor B Contract",
        )

        response = self.client.get(
            reverse("chargebacks:missing-manufacturer-contract-name-list"),
            {"supplier_nbr": vendor_a.vendor_nbr, "limit": 10, "offset": 0},
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        names = [item["manufacturer_contract_name"] for item in response.data["results"]]

        self.assertEqual(names, ["Vendor A Contract"])


class DCOTrendViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:dco-trend"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIn("overall_average_dco", data["data"])
        self.assertIn("trend", data["data"])


class ValidationTimelinessViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:validation-timeliness"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)

    def test_bucket_structure(self):
        vendor = TestDataFactory.create_vendor()
        today = date.today()
        TestDataFactory.create_chargeback(
            vendor=vendor,
            chbk_hdr_created_date=today - timedelta(days=10),
            last_posting_date=today - timedelta(days=6),
            chbk_line_stat="Open",
        )
        response = self.client.get(reverse("chargebacks:validation-timeliness"))
        self.assertEqual(response.status_code, 200)
        for item in response.json()["data"]:
            self.assertIn("bucket", item)
            self.assertIn("count", item)


class UnvalidatedDurationViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:unvalidated-duration"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)


class RejectionVolumeViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:rejection-volume"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)

    def test_with_data(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=date.today() - timedelta(days=10),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        response = self.client.get(reverse("chargebacks:rejection-volume"), {"supplier_nbr": vendor.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        for item in response.json()["data"]:
            self.assertIn("week", item)
            self.assertIn("rejected", item)
            self.assertIn("accepted", item)
            self.assertIn("not_validated", item)


class RejectionReasonsViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:rejection-reasons"))
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertIsInstance(data["data"], list)

    def test_with_data(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=date.today() - timedelta(days=10),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        response = self.client.get(reverse("chargebacks:rejection-reasons"), {"supplier_nbr": vendor.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        data = response.json()["data"]
        self.assertGreater(len(data), 0)
        self.assertIn("rejection_reason", data[0])
        self.assertIn("count", data[0])


class ChargebackRejectionsViewTest(ChargebackViewTestMixin, BaseAPITestCase):

    def test_returns_200(self):
        response = self.client.get(reverse("chargebacks:rejections"))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])

    def test_pagination(self):
        vendor = TestDataFactory.create_vendor()
        for _ in range(5):
            TestDataFactory.create_chargeback(
                vendor=vendor,
                chbk_hdr_created_date=date.today() - timedelta(days=10),
                chbk_line_stat="Open",
                reason_cd_desc="Drug Not Covered",
            )
        response = self.client.get(reverse("chargebacks:rejections"), {"limit": 2, "offset": 0})
        self.assertEqual(response.status_code, 200)
        self.assertLessEqual(len(response.json()["data"]["results"]), 2)

    def test_supplier_filter(self):
        vendor_a = TestDataFactory.create_vendor()
        vendor_b = TestDataFactory.create_vendor()
        recent = date.today() - timedelta(days=10)
        TestDataFactory.create_chargeback(
            vendor=vendor_a,
            chbk_hdr_created_date=recent,
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        TestDataFactory.create_chargeback(
            vendor=vendor_b,
            chbk_hdr_created_date=recent,
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        response = self.client.get(reverse("chargebacks:rejections"), {"supplier_nbr": vendor_a.vendor_nbr})
        self.assertEqual(response.status_code, 200)
        for row in response.json()["data"]["results"]:
            self.assertEqual(row["chargeback_line_id"][:4], "CHBK")

    def test_ordering(self):
        vendor = TestDataFactory.create_vendor()
        recent = date.today() - timedelta(days=10)
        TestDataFactory.create_chargeback(
            vendor=vendor,
            chbk_hdr_created_date=recent,
            dm_post_date=recent,
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        response = self.client.get(reverse("chargebacks:rejections"), {"ordering": "-dm_post_date"})
        self.assertEqual(response.status_code, 200)

    def _seed_debit_memos(self):
        vendor = TestDataFactory.create_vendor()
        recent = date.today() - timedelta(days=10)
        older = date.today() - timedelta(days=60)
        TestDataFactory.create_chargeback(
            vendor=vendor,
            chbk_hdr_created_date=recent,
            dm_post_date=recent,
            chbk_nbr="DM100001",
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        TestDataFactory.create_chargeback(
            vendor=vendor,
            chbk_hdr_created_date=older,
            dm_post_date=older,
            chbk_nbr="DM200002",
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )

    def test_debit_memo_no_filter(self):
        self._seed_debit_memos()

        response = self.client.get(reverse("chargebacks:rejections"), {"debit_memo_no": "dm100001", "limit": 10})

        self.assertEqual(response.status_code, 200)
        results = response.json()["data"]["results"]
        self.assertEqual([row["debit_memo_no"] for row in results], ["DM100001"])

    def test_debit_memo_no_contains_filter(self):
        self._seed_debit_memos()

        response = self.client.get(reverse("chargebacks:rejections"), {"debit_memo_no_contains": "2000", "limit": 10})

        self.assertEqual(response.status_code, 200)
        results = response.json()["data"]["results"]
        self.assertEqual([row["debit_memo_no"] for row in results], ["DM200002"])

    def test_debit_memo_date_range_filter(self):
        self._seed_debit_memos()

        response = self.client.get(
            reverse("chargebacks:rejections"),
            {"debit_memo_date_after": (date.today() - timedelta(days=30)).isoformat()},
        )

        self.assertEqual(response.status_code, 200)
        results = response.json()["data"]["results"]
        self.assertEqual([row["debit_memo_no"] for row in results], ["DM100001"])

    def test_export_csv_shape_and_content(self):
        material = TestDataFactory.create_material(name="Rejected CB Export Mat", ndc="11122233344")
        TestDataFactory.create_chargeback(
            material=material,
            chbk_line_id="CHBK-EXPORT-LINE-1",
            chbk_nbr="DM-EXPORT-1",
            invc_nbr="INV-REJ-EXPORT-1",
            chbk_hdr_created_date=date.today() - timedelta(days=10),
            dm_post_date=date.today() - timedelta(days=8),
            last_posting_date=date.today() - timedelta(days=5),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
            settl_doc_nbr="SET-EXPORT-1",
            contr_nbr="CTR-EXPORT-1",
        )

        response = self.client.get(reverse("chargebacks:rejections-export"))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response["Content-Type"], "text/csv")
        self.assertIn("attachment; filename=", response["Content-Disposition"])
        self.assertIn("active_rejected_chargebacks_", response["Content-Disposition"])
        self.assertEqual(response.get("X-Accel-Buffering"), "no")

        content = b"".join(response.streaming_content).decode("utf-8")
        lines = [line for line in content.splitlines() if line.strip()]
        self.assertGreaterEqual(len(lines), 2)
        header = lines[0]
        for col in (
            "Product name",
            "Product ID",
            "NDC",
            "Debit Memo Date",
            "Debit Memo No",
            "Chargeback Validation Date",
            "Rejection Reason",
            "Chargeback Line ID",
            "Chargeback Qty",
            "Submitted Amt",
            "Validation Amt",
            "Invoice Number",
            "Settlement Doc",
            "Contract Number",
        ):
            self.assertIn(col, header)

        matching = [line for line in lines[1:] if "CHBK-EXPORT-LINE-1" in line]
        self.assertEqual(len(matching), 1)
        self.assertIn("Rejected CB Export Mat", matching[0])
        self.assertIn("11122233344", matching[0])
        self.assertIn("DM-EXPORT-1", matching[0])
        self.assertIn("INV-REJ-EXPORT-1", matching[0])

    def test_export_respects_days_and_filters_ignores_pagination(self):
        vendor_a = TestDataFactory.create_vendor()
        vendor_b = TestDataFactory.create_vendor()
        mat_a = TestDataFactory.create_material(vendor=vendor_a, name="Rej Export Filter A")
        mat_b = TestDataFactory.create_material(vendor=vendor_b, name="Rej Export Filter B")
        TestDataFactory.create_chargeback(
            vendor=vendor_a,
            material=mat_a,
            chbk_line_id="CHBK-EXPORT-RECENT-A",
            chbk_hdr_created_date=date.today() - timedelta(days=10),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        TestDataFactory.create_chargeback(
            vendor=vendor_a,
            material=mat_a,
            chbk_line_id="CHBK-EXPORT-OLD-A",
            chbk_hdr_created_date=date.today() - timedelta(days=120),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        TestDataFactory.create_chargeback(
            vendor=vendor_b,
            material=mat_b,
            chbk_line_id="CHBK-EXPORT-RECENT-B",
            chbk_hdr_created_date=date.today() - timedelta(days=1),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        TestDataFactory.create_chargeback(
            vendor=vendor_a,
            material=mat_a,
            chbk_line_id="CHBK-EXPORT-RECENT-A2",
            chbk_hdr_created_date=date.today() - timedelta(days=5),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )

        url = reverse("chargebacks:rejections-export")
        filtered = self.client.get(url, {
            "supplier_nbr": vendor_a.vendor_nbr,
            "days": 90,
            "limit": 1,
            "offset": 0,
        })
        self.assertEqual(filtered.status_code, status.HTTP_200_OK)
        filtered_content = b"".join(filtered.streaming_content).decode("utf-8")
        self.assertIn("CHBK-EXPORT-RECENT-A", filtered_content)
        self.assertIn("CHBK-EXPORT-RECENT-A2", filtered_content)
        self.assertIn("Rej Export Filter A", filtered_content)
        self.assertNotIn("CHBK-EXPORT-OLD-A", filtered_content)
        self.assertNotIn("CHBK-EXPORT-RECENT-B", filtered_content)

        unpaged = self.client.get(url, {"days": 90, "limit": 1, "offset": 0})
        self.assertEqual(unpaged.status_code, status.HTTP_200_OK)
        unpaged_content = b"".join(unpaged.streaming_content).decode("utf-8")
        self.assertIn("CHBK-EXPORT-RECENT-A", unpaged_content)
        self.assertIn("CHBK-EXPORT-RECENT-B", unpaged_content)
        self.assertNotIn("CHBK-EXPORT-OLD-A", unpaged_content)

    def test_export_soft_cap(self):
        mock_qs = MagicMock()
        mock_qs.count.return_value = DEFAULT_EXPORT_MAX_ROWS + 1

        with patch(
            "api.csv_export.get_filtered_ordered_queryset",
            return_value=mock_qs,
        ):
            response = self.client.get(reverse("chargebacks:rejections-export"))

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("Export exceeds the maximum", str(response.data["error"]))
        mock_qs.iterator.assert_not_called()
