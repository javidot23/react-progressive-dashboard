from datetime import date, timedelta

from api.chargeback.services import ChargebackService
from api.date_bounds import iso_week_bounds
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class ChargebackServiceSummaryTest(BaseTestCase):

    def test_get_summary_this_week(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        today = date.today()
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=today, sales_contr_amt=1000.0
        )
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=today,
            chbk_line_stat="Open",
            abc_req_amt=500.0,
        )
        result = ChargebackService.get_summary()
        self.assertGreaterEqual(float(result["contract_sales_amount"]), 1000.0)
        self.assertGreaterEqual(float(result["chargeback_amount"]), 500.0)
        self.assertIn("contract_sales_amount_last_week", result)
        self.assertIn("contract_sales_pct_change", result)

    def test_get_summary_excludes_records_outside_this_week(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        _, _, last_start, _ = iso_week_bounds()
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=last_start - timedelta(days=1),
            sales_contr_amt=9999.0,
        )
        result = ChargebackService.get_summary()
        self.assertEqual(float(result["contract_sales_amount"]), 0.0)

    def test_get_summary_last_week_and_pct_change(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        today = date.today()
        _, _, last_start, last_end = iso_week_bounds()
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=today, sales_contr_amt=1500.0,
        )
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=last_start, sales_contr_amt=1000.0,
        )
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=last_end,
            chbk_line_stat="Closed",
            abc_req_amt=200.0,
        )
        result = ChargebackService.get_summary()
        self.assertAlmostEqual(float(result["contract_sales_amount"]), 1500.0, places=1)
        self.assertAlmostEqual(float(result["contract_sales_amount_last_week"]), 1000.0, places=1)
        self.assertAlmostEqual(float(result["chargeback_amount_last_week"]), 200.0, places=1)
        self.assertAlmostEqual(result["contract_sales_pct_change"], 50.0, places=1)

    def test_get_summary_pct_change_null_when_last_week_zero(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=date.today(), sales_contr_amt=500.0,
        )
        result = ChargebackService.get_summary()
        self.assertIsNone(result["contract_sales_pct_change"])

    def test_get_summary_material_filter(self):
        vendor_a = TestDataFactory.create_vendor()
        vendor_b = TestDataFactory.create_vendor()
        mat_a = TestDataFactory.create_material(vendor=vendor_a)
        mat_b = TestDataFactory.create_material(vendor=vendor_b)
        TestDataFactory.create_billing_transaction(vendor=vendor_a, material=mat_a, sales_contr_amt=1000.0)
        TestDataFactory.create_billing_transaction(vendor=vendor_b, material=mat_b, sales_contr_amt=2000.0)
        result = ChargebackService.get_summary(direct_mat_nbr=mat_a.mat_nbr)
        self.assertGreaterEqual(float(result["contract_sales_amount"]), 1000.0)
        self.assertLess(float(result["contract_sales_amount"]), 3000.0)


class ChargebackServiceTrendTest(BaseTestCase):

    def test_get_sales_vs_chargebacks_trend_returns_list(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        today = date.today()
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material, ord_created_date=today - timedelta(days=7)
        )
        result = ChargebackService.get_sales_vs_chargebacks_trend()
        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)
        self.assertIn("week", result[0])
        self.assertIn("contract_sales_amount", result[0])
        self.assertIn("chargeback_amount", result[0])


class ChargebackServiceDCOTrendTest(BaseTestCase):

    def test_get_dco_trend_structure(self):
        vendor = TestDataFactory.create_vendor()
        TestDataFactory.create_chargeback(vendor=vendor, dco_days=5)
        TestDataFactory.create_chargeback(vendor=vendor, dco_days=10)
        result = ChargebackService.get_dco_trend()
        self.assertIn("overall_average_dco", result)
        self.assertIn("trend", result)
        self.assertIsInstance(result["trend"], list)
        self.assertIn("week", result["trend"][0])

    def test_get_dco_trend_calculates_overall_avg(self):
        vendor = TestDataFactory.create_vendor()
        TestDataFactory.create_chargeback(vendor=vendor, dco_days=4)
        TestDataFactory.create_chargeback(vendor=vendor, dco_days=6)
        result = ChargebackService.get_dco_trend()
        self.assertIsNotNone(result["overall_average_dco"])


class ChargebackServiceGenerationStatusTest(BaseTestCase):

    def test_generated_when_matching_chargeback_exists(self):
        """Billing row with a matching Open/Closed chargeback counts as generated."""
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        today = date.today()
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=today - timedelta(days=10),
            invc_nbr="INV-MATCH-1",
            sales_contr_qty=50.0,
        )
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            invc_nbr="INV-MATCH-1",
            chbk_line_stat="Open",
        )
        result = ChargebackService.get_generation_status()
        self.assertEqual(len(result), 1)
        self.assertEqual(float(result[0]["chargebacks_generated_units"]), 50.0)
        self.assertEqual(float(result[0]["not_generated_units"]), 0.0)
        self.assertEqual(result[0]["pct_generated"], 100.0)

    def test_not_generated_when_no_chargeback(self):
        """Billing row without a matching chargeback counts as not_generated."""
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=date.today() - timedelta(days=5),
            invc_nbr="INV-NO-MATCH",
            sales_contr_qty=20.0,
        )
        result = ChargebackService.get_generation_status()
        self.assertEqual(len(result), 1)
        self.assertEqual(float(result[0]["chargebacks_generated_units"]), 0.0)
        self.assertEqual(float(result[0]["not_generated_units"]), 20.0)
        self.assertEqual(result[0]["pct_generated"], 0.0)

    def test_pct_generated_is_rounded_correctly(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        today = date.today() - timedelta(days=5)
        # 30 generated + 70 not generated => 30%
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material, ord_created_date=today,
            invc_nbr="INV-A", sales_contr_qty=30.0,
        )
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material, invc_nbr="INV-A", chbk_line_stat="Closed",
        )
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material, ord_created_date=today,
            invc_nbr="INV-B", sales_contr_qty=70.0,
        )
        result = ChargebackService.get_generation_status()
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["pct_generated"], 30.0)

    def test_chargeback_status_outside_open_closed_is_ignored(self):
        """Chargebacks not in (Open, Closed) must not flip a row to 'generated'."""
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=date.today() - timedelta(days=5),
            invc_nbr="INV-REJ",
            sales_contr_qty=10.0,
        )
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            invc_nbr="INV-REJ",
            chbk_line_stat="Rejected",
        )
        result = ChargebackService.get_generation_status()
        self.assertEqual(float(result[0]["not_generated_units"]), 10.0)
        self.assertEqual(float(result[0]["chargebacks_generated_units"]), 0.0)

    def test_excludes_non_positive_sales_qty(self):
        """sales_contr_qty <= 0 (credits/returns) must be excluded entirely."""
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=date.today() - timedelta(days=5),
            invc_nbr="INV-ZERO",
            sales_contr_qty=0,
        )
        result = ChargebackService.get_generation_status()
        self.assertEqual(result, [])

    def test_excludes_records_outside_90_day_window(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_billing_transaction(
            vendor=vendor, material=material,
            ord_created_date=date.today() - timedelta(days=120),
            invc_nbr="INV-OLD",
            sales_contr_qty=99.0,
        )
        result = ChargebackService.get_generation_status()
        self.assertEqual(result, [])

    def test_material_filter_scopes_results(self):
        vendor_a = TestDataFactory.create_vendor()
        vendor_b = TestDataFactory.create_vendor()
        mat_a = TestDataFactory.create_material(vendor=vendor_a)
        mat_b = TestDataFactory.create_material(vendor=vendor_b)
        today = date.today() - timedelta(days=5)
        TestDataFactory.create_billing_transaction(
            vendor=vendor_a, material=mat_a, ord_created_date=today,
            invc_nbr="INV-A", sales_contr_qty=11.0,
        )
        TestDataFactory.create_billing_transaction(
            vendor=vendor_b, material=mat_b, ord_created_date=today,
            invc_nbr="INV-B", sales_contr_qty=22.0,
        )
        result = ChargebackService.get_generation_status(direct_mat_nbr=mat_a.mat_nbr)
        self.assertEqual(len(result), 1)
        self.assertEqual(float(result[0]["not_generated_units"]), 11.0)


class ChargebackServiceValidationTimelinesTest(BaseTestCase):

    def test_get_validation_timeliness_bucket_counts(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        today = date.today()
        # 4-5 days bucket: 5 days to validate
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=today - timedelta(days=10),
            last_posting_date=today - timedelta(days=5),
            chbk_line_stat="Open",
        )
        # 6-10 days bucket: 8 days to validate
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=today - timedelta(days=20),
            last_posting_date=today - timedelta(days=12),
            chbk_line_stat="Open",
        )
        result = ChargebackService.get_validation_timeliness(direct_mat_nbr=material.mat_nbr)
        bucket_map = {r["bucket"]: r["count"] for r in result}
        self.assertGreaterEqual(bucket_map.get("4-5 days", 0), 1)
        self.assertGreaterEqual(bucket_map.get("6-10 days", 0), 1)

    def test_get_validation_timeliness_excludes_unvalidated(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            last_posting_date=None,
            chbk_line_stat="Open",
        )
        result = ChargebackService.get_validation_timeliness(direct_mat_nbr=material.mat_nbr)
        total = sum(r["count"] for r in result)
        self.assertEqual(total, 0)


class ChargebackServiceUnvalidatedDurationTest(BaseTestCase):

    def test_get_unvalidated_duration_bucket_counts(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        today = date.today()
        # 4-5 days bucket
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=today - timedelta(days=5),
            last_posting_date=None,
            chbk_line_stat="Open",
        )
        # 6-10 days bucket
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=today - timedelta(days=10),
            last_posting_date=None,
            chbk_line_stat="Open",
        )
        result = ChargebackService.get_unvalidated_duration(direct_mat_nbr=material.mat_nbr)
        bucket_map = {r["bucket"]: r["count"] for r in result}
        self.assertGreaterEqual(bucket_map.get("4-5 days", 0), 1)
        self.assertGreaterEqual(bucket_map.get("6-10 days", 0), 1)


class ChargebackServiceRejectionTest(BaseTestCase):

    def test_get_rejection_volume_classification(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        today = date.today()

        # Rejected
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=today - timedelta(days=10),
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
            last_posting_date=None,
        )
        # Accepted
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=today - timedelta(days=10),
            chbk_line_stat="Open",
            reason_cd_desc=None,
            last_posting_date=today - timedelta(days=5),
        )
        result = list(ChargebackService.get_rejection_volume(direct_mat_nbr=material.mat_nbr))
        self.assertGreater(len(result), 0)
        total_rejected = sum(r["rejected"] for r in result)
        total_accepted = sum(r["accepted"] for r in result)
        self.assertGreaterEqual(total_rejected, 1)
        self.assertGreaterEqual(total_accepted, 1)

    def test_get_rejection_reasons_ordering(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        recent = date.today() - timedelta(days=10)
        for _ in range(3):
            TestDataFactory.create_chargeback(
                vendor=vendor, material=material,
                chbk_hdr_created_date=recent,
                chbk_line_stat="Open",
                reason_cd_desc="Drug Not Covered",
            )
        TestDataFactory.create_chargeback(
            vendor=vendor, material=material,
            chbk_hdr_created_date=recent,
            chbk_line_stat="Open",
            reason_cd_desc="Duplicate Chargeback Received",
        )
        result = list(ChargebackService.get_rejection_reasons(direct_mat_nbr=material.mat_nbr))
        self.assertGreater(len(result), 0)
        self.assertGreaterEqual(result[0]["count"], result[-1]["count"])

    def test_get_rejections_returns_only_rejected(self):
        vendor = TestDataFactory.create_vendor()
        recent = date.today() - timedelta(days=10)
        TestDataFactory.create_chargeback(
            vendor=vendor,
            chbk_hdr_created_date=recent,
            chbk_line_stat="Open",
            reason_cd_desc="Drug Not Covered",
        )
        TestDataFactory.create_chargeback(
            vendor=vendor,
            chbk_hdr_created_date=recent,
            chbk_line_stat="Open",
            reason_cd_desc=None,
        )
        result = list(ChargebackService.get_rejections())
        for r in result:
            self.assertIsNotNone(r.reason_cd_desc)
