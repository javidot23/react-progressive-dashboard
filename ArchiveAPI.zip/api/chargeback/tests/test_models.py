from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class ChargebackModelTest(BaseTestCase):

    def test_create_chargeback(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        cb = TestDataFactory.create_chargeback(
            vendor=vendor,
            material=material,
            chbk_line_id="CHBK12345678",
            chbk_line_stat="Open",
            reason_cd_desc="Exceeded Receipt Cutoff",
        )
        self.assertEqual(cb.chbk_line_id, "CHBK12345678")
        self.assertEqual(cb.material, material)
        self.assertEqual(cb.chbk_line_stat, "Open")
        self.assertEqual(cb.reason_cd_desc, "Exceeded Receipt Cutoff")

    def test_chbk_line_id_unique(self):
        from django.db import IntegrityError
        vendor = TestDataFactory.create_vendor()
        TestDataFactory.create_chargeback(vendor=vendor, chbk_line_id="CHBKUNIQ001")
        with self.assertRaises(IntegrityError):
            TestDataFactory.create_chargeback(vendor=vendor, chbk_line_id="CHBKUNIQ001")

    def test_nullable_reason_and_posting_date(self):
        vendor = TestDataFactory.create_vendor()
        cb = TestDataFactory.create_chargeback(
            vendor=vendor,
            reason_cd_desc=None,
            last_posting_date=None,
        )
        self.assertIsNone(cb.reason_cd_desc)
        self.assertIsNone(cb.last_posting_date)
