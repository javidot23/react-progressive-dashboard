from django_filters import CharFilter, DateFilter, NumberFilter
from django_filters.rest_framework import FilterSet

from api.global_filters import GlobalFilterForRelatedMaterialMixin
from api.chargeback.models import Chargeback
from api.sales_missing_chargeback.models import SalesMissingChargeback


class ChargebackFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    class Meta:
        model = Chargeback
        fields = []


class ChargebackRejectionFilter(ChargebackFilter):
    rejection_reason = CharFilter(field_name="reason_cd_desc", lookup_expr="iexact")
    qty_min = NumberFilter(field_name="chbk_qty", lookup_expr="gte")
    qty_max = NumberFilter(field_name="chbk_qty", lookup_expr="lte")
    submitted_amt_min = NumberFilter(field_name="abc_req_amt", lookup_expr="gte")
    submitted_amt_max = NumberFilter(field_name="abc_req_amt", lookup_expr="lte")
    validation_amt_min = NumberFilter(field_name="vdr_accept_amt", lookup_expr="gte")
    validation_amt_max = NumberFilter(field_name="vdr_accept_amt", lookup_expr="lte")

    class Meta(ChargebackFilter.Meta):
        pass


class SalesMissingChargebackFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    invoice_date_after = DateFilter(field_name="invoice_date", lookup_expr="gte")
    invoice_date_before = DateFilter(field_name="invoice_date", lookup_expr="lte")
    qty_min = NumberFilter(field_name="contract_sales_and_rebill_qty", lookup_expr="gte")
    qty_max = NumberFilter(field_name="contract_sales_and_rebill_qty", lookup_expr="lte")
    amount_min = NumberFilter(field_name="contract_sales_and_rebill_amount", lookup_expr="gte")
    amount_max = NumberFilter(field_name="contract_sales_and_rebill_amount", lookup_expr="lte")

    class Meta:
        model = SalesMissingChargeback
        fields = []
