from django.db.models import Q
from django_filters import CharFilter, DateFilter, NumberFilter
from django_filters.rest_framework import FilterSet

from api.global_filters import CharInFilter, GlobalFilterForRelatedMaterialMixin
from api.chargeback.models import Chargeback
from api.sales_missing_chargeback.models import SalesMissingChargeback


class ChargebackFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    class Meta:
        model = Chargeback
        fields = []


class ChargebackRejectionFilter(ChargebackFilter):
    rejection_reason = CharInFilter(field_name="reason_cd_desc", method="filter_iexact_in")
    debit_memo_no = CharInFilter(field_name="chbk_nbr", method="filter_iexact_in")
    debit_memo_no_contains = CharFilter(field_name="chbk_nbr", lookup_expr="icontains")
    invoice_number = CharInFilter(field_name="invc_nbr", method="filter_iexact_in")
    debit_memo_date_after = DateFilter(field_name="dm_post_date", lookup_expr="gte")
    debit_memo_date_before = DateFilter(field_name="dm_post_date", lookup_expr="lte")
    qty_min = NumberFilter(field_name="chbk_qty", lookup_expr="gte")
    qty_max = NumberFilter(field_name="chbk_qty", lookup_expr="lte")
    submitted_amt_min = NumberFilter(field_name="abc_req_amt", lookup_expr="gte")
    submitted_amt_max = NumberFilter(field_name="abc_req_amt", lookup_expr="lte")
    validation_amt_min = NumberFilter(field_name="vdr_accept_amt", lookup_expr="gte")
    validation_amt_max = NumberFilter(field_name="vdr_accept_amt", lookup_expr="lte")

    class Meta(ChargebackFilter.Meta):
        pass

    def filter_iexact_in(self, queryset, name, value):
        q = Q()
        for v in value:
            q |= Q(**{f"{name}__iexact": v})
        return queryset.filter(q)


class SalesMissingChargebackFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    manufacturer_contract_name = CharInFilter(field_name="manufacturer_contract_name", method="filter_icontains_in")
    invoice_date_after = DateFilter(field_name="invoice_date", lookup_expr="gte")
    invoice_date_before = DateFilter(field_name="invoice_date", lookup_expr="lte")
    qty_min = NumberFilter(field_name="contract_sales_and_rebill_qty", lookup_expr="gte")
    qty_max = NumberFilter(field_name="contract_sales_and_rebill_qty", lookup_expr="lte")
    amount_min = NumberFilter(field_name="contract_sales_and_rebill_amount", lookup_expr="gte")
    amount_max = NumberFilter(field_name="contract_sales_and_rebill_amount", lookup_expr="lte")

    class Meta:
        model = SalesMissingChargeback
        fields = []

    def filter_icontains_in(self, queryset, name, value):
        q = Q()
        for v in value:
            q |= Q(**{f"{name}__icontains": v})
        return queryset.filter(q)


class SalesMissingChargebackManufacturerContractNameFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    manufacturer_contract_name = CharFilter(lookup_expr="icontains", field_name="manufacturer_contract_name")

    class Meta:
        model = SalesMissingChargeback
        fields = []
