from rest_framework import serializers

from api.plant.serializers import PlantSerializer, Neo4jPlantSerializer
from api.service_level.models import ServiceLevel


class ServiceLevelWeeklyAverageSerializer(serializers.Serializer):
    """
    Serializer for weekly service level averages.
    """

    this_week_average = serializers.FloatField()
    last_week_average = serializers.FloatField()


class ServiceLevelPeriodQuerySerializer(serializers.Serializer):
    """
    Serializer for service level period query parameters.
    """

    start_date = serializers.DateField(required=True)
    end_date = serializers.DateField(required=True)


class PredictedFillRateSerializer(serializers.Serializer):
    """
    Serializer for daily fill rate with Actual vs Projected classification.
    """

    date = serializers.DateField()
    data_type = serializers.CharField()
    fill_rate_pct = serializers.FloatField()
    actual_fill_rate_pct = serializers.FloatField()
    total_received_qty = serializers.IntegerField()
    predicted_additional_qty = serializers.IntegerField()
    total_order_qty = serializers.IntegerField()


class ServiceLevelSerializer(serializers.ModelSerializer):
    """
    Serializer for service level data.
    """

    class Meta:
        model = ServiceLevel
        fields = "__all__"
        read_only_fields = ("created_at", "updated_at")


class DailyServiceLevelSerializer(serializers.Serializer):
    date = serializers.DateField()
    fill_rate = serializers.FloatField()
    total_order_qty = serializers.FloatField()
    total_received_qty = serializers.FloatField()


class PlantServiceLevelSerializer(serializers.Serializer):
    plant = PlantSerializer()
    service_levels = DailyServiceLevelSerializer(many=True)


class LastTwoMonthsServiceLevelSerializer(serializers.Serializer):
    """
    Serializer for service level data for the last two months.
    """

    month = serializers.IntegerField()
    average_service_level = serializers.FloatField()
    total_order_qty = serializers.FloatField()
    total_received_qty = serializers.FloatField()


class MaterialOmitDailyCountSerializer(serializers.Serializer):
    """
    Serializer for material omit counts per day.
    """

    date = serializers.DateField()
    excess_omits_count = serializers.IntegerField()
    allowed_omits_count = serializers.IntegerField()
    no_omits_count = serializers.IntegerField()


class MaterialOmitCountSerializer(serializers.Serializer):
    """
    Serializer for material omit counts per day.
    """

    excess_omits_count = serializers.IntegerField()
    allowed_omits_count = serializers.IntegerField()
    no_omits_count = serializers.IntegerField()
    total_products_ordered = serializers.IntegerField()
    total_products_with_omits = serializers.IntegerField()
    daily_data = MaterialOmitDailyCountSerializer(many=True)


class FulfillmentMetricsSerializer(serializers.Serializer):
    """
    Serializer for fulfillment metrics.
    """
    year = serializers.IntegerField()
    month = serializers.IntegerField()
    unshipped_quantity = serializers.FloatField()
    fulfillment_percentage = serializers.FloatField()

    class Meta:
        ref_name = 'ServiceLevelFulfillmentMetrics'


class MaterialOmitMonthlyCountSerializer(serializers.Serializer):
    """
    Serializer for material omit counts per month.
    """
    month = serializers.CharField()
    month_num = serializers.IntegerField()
    excess_omits_count = serializers.IntegerField()
    allowed_omits_count = serializers.IntegerField()
    no_omits_count = serializers.IntegerField()


class MaterialOmitCountThisYearSerializer(serializers.Serializer):
    """
    Serializer for material omit counts for the current year.
    """
    excess_omits_count = serializers.IntegerField()
    allowed_omits_count = serializers.IntegerField()
    no_omits_count = serializers.IntegerField()
    total_products_ordered = serializers.IntegerField()
    total_products_with_omits = serializers.IntegerField()
    monthly_data = MaterialOmitMonthlyCountSerializer(many=True)

    class Meta:
        ref_name = 'ServiceLevelMaterialOmitCountThisYear'


class MaterialOtifSummarySerializer(serializers.Serializer):
    material_id = serializers.CharField()
    material_name = serializers.CharField()
    mat_nbr = serializers.CharField()
    ndc = serializers.CharField(allow_null=True)
    units_ordered = serializers.IntegerField()
    units_received_on_time = serializers.IntegerField()
    units_received_late = serializers.IntegerField()
    units_not_received = serializers.IntegerField()
    total_orders = serializers.IntegerField()
    inbound_fill_rate = serializers.FloatField(read_only=True)
    otif_percentage = serializers.FloatField(allow_null=True)
    days_on_hand = serializers.FloatField(allow_null=True)
    units_ordered_last_30d = serializers.IntegerField()
    units_received_last_30d = serializers.IntegerField()

    class Meta:
        ref_name = 'ServiceLevelMaterialOtifSummary'

    def to_representation(self, instance):
        data = super().to_representation(instance)
        if data.get('otif_percentage') is not None:
            data['otif_percentage'] = round(float(data['otif_percentage']), 2)
        if data.get('days_on_hand') is not None:
            data['days_on_hand'] = round(float(data['days_on_hand']), 1)
        if data.get('inbound_fill_rate') is not None:
            data['inbound_fill_rate'] = round(float(data['inbound_fill_rate']), 4)
        return data


class OtifTotalSerializer(serializers.Serializer):
    otif_percentage = serializers.FloatField()
    weekly_average_otif = serializers.FloatField()

    class Meta:
        ref_name = 'ServiceLevelOtifTotal'


class OtifWeeklyComparisonSerializer(serializers.Serializer):
    this_week_otif = serializers.FloatField()
    last_week_otif = serializers.FloatField()


class Otif30DayComparisonSerializer(serializers.Serializer):
    last_30_days_otif = serializers.FloatField()
    previous_30_days_otif = serializers.FloatField()
    kpi_value = serializers.FloatField()
    kpi_previous_value = serializers.FloatField()
    trend = serializers.DictField(required=False)


class OtifTrendsSerializer(serializers.Serializer):
    day = serializers.DateField()
    on_time_count = serializers.IntegerField()
    in_full_count = serializers.IntegerField()
    otif_percentage = serializers.FloatField()
    total_materials = serializers.IntegerField()

    class Meta:
        ref_name = 'ServiceLevelOtifTrends'


class MaterialOtifTrendsSerializer(serializers.Serializer):
    day = serializers.DateField()
    on_time_count = serializers.IntegerField()
    in_full_count = serializers.IntegerField()
    otif_percentage = serializers.FloatField()
    total_materials = serializers.IntegerField()
    # material_status = serializers.CharField()

    class Meta:
        ref_name = 'ServiceLevelMaterialOtifTrends'


class Neo4jInboundServiceLevelSerializer(serializers.Serializer):
    """
    Serializer for daily InboundServiceLevel data from Neo4j.
    """
    date = serializers.DateField()
    fill_rate = serializers.FloatField()
    total_order_qty = serializers.FloatField()
    total_received_qty = serializers.FloatField()
    in_full_units = serializers.IntegerField()
    on_time_units = serializers.IntegerField()
    on_order_qty = serializers.IntegerField()
    otif_percentage = serializers.FloatField()
    total_omit_qty = serializers.IntegerField()


class Neo4jPlantInboundServiceLevelSerializer(serializers.Serializer):
    """
    Serializer for plant-grouped InboundServiceLevel data from Neo4j.
    """
    plant = Neo4jPlantSerializer()
    service_levels = Neo4jInboundServiceLevelSerializer(many=True)
