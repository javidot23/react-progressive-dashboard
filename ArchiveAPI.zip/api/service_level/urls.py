from django.urls import path

from .views import (
    WeeklyServiceLevelAverageView,
    ServiceLevelPeriodView,
    LastTwoMonthsServiceLevelView,
    MaterialOmitCountView, MaterialOmitCountDailyView, FulfillmentMetricsView, MaterialOmitCountThisYearView,
    PlantServiceLevelPeriodView, MaterialOtifSummaryView, OtifTotalView, DailyOtifTrendsView,
    MaterialDailyOtifTrendsView, OtifWeeklyComparisonView, Otif30DayComparisonView,
    Neo4jInboundServiceLevelPeriodView, PredictedFillRatePeriodView,
)

app_name = "service_level"

urlpatterns = [
    path("", ServiceLevelPeriodView.as_view(), name="service-level-period"),
    path(
        "predicted-fill-rate/",
        PredictedFillRatePeriodView.as_view(),
        name="predicted-fill-rate",
    ),
    path(
        "weekly-analysis/",
        WeeklyServiceLevelAverageView.as_view(),
        name="weekly-service-level",
    ),
    path(
        "last-two-months/",  # TODO: Remove this as its not used anywhere
        LastTwoMonthsServiceLevelView.as_view(),
        name="last-two-months-service-level",
    ),
    path(
        "material-omit-count/",
        MaterialOmitCountView.as_view(),
        name="material-omit-count",
    ),
    path(
        "material-omit-daily-count/",
        MaterialOmitCountDailyView.as_view(),
        name="material-omit-daily-count",
    ),
    path(
        "material-omit-counts-this-year/",
        MaterialOmitCountThisYearView.as_view(),
        name="material-omit-counts-this-year",
    ),
    path(
        "fulfillment/",
        FulfillmentMetricsView.as_view(),
        name="fulfillment-metrics",
    ),
    path(
        "plants/",
        PlantServiceLevelPeriodView.as_view(),
        name="plant-service-level-period",
    ),
    path(
        "plants/from-graph/",
        Neo4jInboundServiceLevelPeriodView.as_view(),
        name="neo4j-inbound-service-level-period",
    ),
    path(
        "material-summary/",
        MaterialOtifSummaryView.as_view(),
        name="material-otif-summary",
    ),
    path(
        "otif-today/",
        OtifTotalView.as_view(),
        name='otif-total'
    ),
    path(
        "otif-week-summary/",
        OtifWeeklyComparisonView.as_view(),
        name='otif-weekly-comparison'
    ),
    path(
        "otif-30day-summary/",
        Otif30DayComparisonView.as_view(),
        name='otif-30day-comparison'
    ),
    path('otif-trends/', DailyOtifTrendsView.as_view(), name="daily-otif-trends"),
    path('otif-trends/<int:material_id>/', MaterialDailyOtifTrendsView.as_view(), name="material-daily-otif-trends"),
]
