import calendar
import logging
from collections import defaultdict
from datetime import date, timedelta

from django.db.models import Avg, Sum, Count, Q, F, Case, When, Value, FloatField
from django.db.models.functions import Cast, Coalesce, Extract, TruncWeek
from django.utils import timezone

from .models import ServiceLevel
from ..plant.models import Plant

logger = logging.getLogger(__name__)


class ServiceLevelService:
    @staticmethod
    def _apply_material_filter(queryset, direct_mat_nbr=None, mat_nbr_subquery=None):
        """Helper to apply material filters using optimized subquery pattern."""
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
        return queryset

    @staticmethod
    def _get_fill_rate_day_type(day):
        if day.isoweekday() == 7:
            return "sunday"
        if day.isoweekday() == 6:
            return "saturday"
        return "weekday"

    @staticmethod
    def get_weekly_service_level_average(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get average service level for this week vs last week across all vendors.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting weekly service level average")

        now = timezone.now()

        current_week_start = now - timedelta(days=now.weekday())
        current_week_start = current_week_start.replace(
            hour=0, minute=0, second=0, microsecond=0
        )

        last_week_start = current_week_start - timedelta(days=7)
        last_week_end = current_week_start

        this_week_qs = ServiceLevel.objects.filter(
            date__gte=current_week_start.date(), date__lte=now.date()
        )
        this_week_qs = ServiceLevelService._apply_material_filter(this_week_qs, direct_mat_nbr, mat_nbr_subquery)

        this_week_daily_avg = (
            this_week_qs
            .values("date")
            .annotate(daily_avg=Avg("fill_rate"))
            .aggregate(week_avg=Avg("daily_avg"))
        )

        last_week_qs = ServiceLevel.objects.filter(
            date__gte=last_week_start.date(), date__lt=last_week_end.date()
        )
        last_week_qs = ServiceLevelService._apply_material_filter(last_week_qs, direct_mat_nbr, mat_nbr_subquery)

        last_week_daily_avg = (
            last_week_qs
            .values("date")
            .annotate(daily_avg=Avg("fill_rate"))
            .aggregate(week_avg=Avg("daily_avg"))
        )

        this_week_avg = round(this_week_daily_avg["week_avg"] or 0.0, 3)
        last_week_avg = round(last_week_daily_avg["week_avg"] or 0.0, 3)

        logger.info(
            "Weekly averages: this_week=%.3f, last_week=%.3f",
            this_week_avg,
            last_week_avg,
        )

        return {"this_week_average": this_week_avg, "last_week_average": last_week_avg}

    @staticmethod
    def get_service_level_for_period(start_date, end_date, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get service level data for a specific period, averaged across all vendors per day.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting service levels for period: %s to %s", start_date, end_date)

        queryset = ServiceLevel.objects.filter(date__gte=start_date, date__lte=end_date)
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        daily_averages = (
            queryset
            .values("date")
            .annotate(
                avg_fill_rate=Avg("fill_rate"),
                total_order_qty=Sum("total_order_qty"),
                total_received_qty=Sum("total_received_qty"),
            )
            .order_by("date")
        )

        formatted_data = []
        for day_data in daily_averages:
            formatted_data.append(
                {
                    "date": day_data["date"],
                    "fill_rate": round(day_data["avg_fill_rate"] or 0.0, 3),
                    "total_order_qty": round(day_data["total_order_qty"] or 0.0, 2),
                    "total_received_qty": round(
                        day_data["total_received_qty"] or 0.0, 2
                    ),
                }
            )

        logger.info("Retrieved data for %s days", len(formatted_data))
        return formatted_data

    @staticmethod
    def get_predicted_fill_rate_for_period(start_date, end_date, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Daily fill rate where the most recent 7 days are projected and older days are actual.
        """
        logger.info("Getting predicted fill rate for period: %s to %s", start_date, end_date)

        PROJECTION_WINDOW_DAYS = 7

        today = timezone.now().date()
        projection_start = today - timedelta(days=PROJECTION_WINDOW_DAYS)

        actual_qs = ServiceLevel.objects.filter(
            date__gte=start_date,
            date__lte=end_date,
            date__lt=today,
            total_order_qty__isnull=False,
            total_order_qty__gt=0,
            total_received_qty__gte=0,
        )
        actual_qs = ServiceLevelService._apply_material_filter(actual_qs, direct_mat_nbr, mat_nbr_subquery)

        actual_daily = (
            actual_qs
            .values("date")
            .annotate(
                total_received_qty=Sum("total_received_qty"),
                total_order_qty=Sum("total_order_qty"),
            )
            .order_by("date")
        )

        mature_start = today - timedelta(days=21)
        mature_end = today - timedelta(days=PROJECTION_WINDOW_DAYS)
        mature_qs = ServiceLevel.objects.filter(
            date__gte=mature_start,
            date__lt=mature_end,
            total_order_qty__isnull=False,
            total_order_qty__gt=0,
            total_received_qty__gte=0,
        )
        mature_qs = ServiceLevelService._apply_material_filter(mature_qs, direct_mat_nbr, mat_nbr_subquery)

        mature_daily = (
            mature_qs
            .values("date")
            .annotate(
                total_received_qty=Sum("total_received_qty"),
                total_order_qty=Sum("total_order_qty"),
            )
        )

        mature_fill_rates_by_type = defaultdict(list)
        for mature_row in mature_daily:
            mature_day = mature_row["date"]
            mature_received = mature_row["total_received_qty"] or 0
            mature_ordered = mature_row["total_order_qty"] or 0
            if mature_ordered <= 0:
                continue

            day_type = ServiceLevelService._get_fill_rate_day_type(mature_day)
            mature_fill_rates_by_type[day_type].append(
                mature_received * 100.0 / mature_ordered
            )

        mature_avg_by_type = {
            day_type: round(sum(fill_rates) / len(fill_rates), 2)
            for day_type, fill_rates in mature_fill_rates_by_type.items()
            if fill_rates
        }

        results = []
        for row in actual_daily:
            day = row["date"]
            received = row["total_received_qty"] or 0
            ordered = row["total_order_qty"] or 0
            is_projected = day >= projection_start

            actual_fill_rate_pct = min(received * 100.0 / ordered, 100.0)
            day_type = ServiceLevelService._get_fill_rate_day_type(day)
            mature_avg_pct = mature_avg_by_type.get(day_type)
            if mature_avg_pct is None:
                continue

            if is_projected:
                days_elapsed = (today - day).days
                if days_elapsed <= 3:
                    fill_rate_pct = mature_avg_pct
                elif days_elapsed <= 5:
                    fill_rate_pct = 0.30 * actual_fill_rate_pct + 0.70 * mature_avg_pct
                else:
                    fill_rate_pct = 0.70 * actual_fill_rate_pct + 0.30 * mature_avg_pct
            else:
                fill_rate_pct = actual_fill_rate_pct

            fill_rate_pct = min(fill_rate_pct, 100.0)

            results.append({
                "date": day,
                "data_type": "projected" if is_projected else "actual",
                "fill_rate_pct": round(fill_rate_pct, 2),
                "actual_fill_rate_pct": round(actual_fill_rate_pct, 2),
                "total_received_qty": int(received),
                "predicted_additional_qty": 0,
                "total_order_qty": int(ordered),
            })
        return results

    @staticmethod
    def get_service_level_for_plants_for_period(start_date, end_date, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Per-plant daily averaged service levels for a period.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting service levels for plants for period: %s to %s", start_date, end_date)

        queryset = ServiceLevel.objects.filter(date__gte=start_date, date__lte=end_date)
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        qs = (
            queryset
            .values("plant__plant_nbr", "date")
            .annotate(
                avg_fill_rate=Avg("fill_rate"),
                total_order_qty=Sum("total_order_qty"),
                total_received_qty=Sum("total_received_qty"),
            )
            .order_by("plant__plant_nbr", "date")
        )

        if not qs:
            logger.info("No service level rows found for period")
            return []

        grouped = defaultdict(list)
        plant_nbrs = set()

        for row in qs:
            plant_nbr = row["plant__plant_nbr"]
            if plant_nbr:
                plant_nbrs.add(plant_nbr)
                grouped[plant_nbr].append({
                    "date": row["date"],
                    "fill_rate": round(row["avg_fill_rate"] or 0.0, 3),
                    "total_order_qty": round(row["total_order_qty"] or 0.0, 2),
                    "total_received_qty": round(
                        row["total_received_qty"] or 0.0, 2
                    ),
                })

        plants = {p.plant_nbr: p for p in Plant.objects.filter(plant_nbr__in=plant_nbrs)}

        result = [
            {"plant": plants[plant_nbr], "service_levels": svc_levels}
            for plant_nbr, svc_levels in grouped.items()
            if plant_nbr in plants
        ]

        logger.info("Retrieved data for %d plants with service levels", len(result))
        return result

    @staticmethod
    def get_last_two_months_service_level(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get average service level data for the last two months, grouped by month.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting service levels for last two months")

        today = timezone.now().date()

        if today.month <= 1:
            two_months_ago = today.replace(
                year=today.year - 1,
                month=today.month + 10 if today.month == 2 else 11,
                day=1,
            )
        else:
            two_months_ago = today.replace(month=today.month - 1, day=1)

        logger.info("Date range: %s to %s", two_months_ago, today)

        queryset = ServiceLevel.objects.filter(date__gte=two_months_ago, date__lte=today)
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        monthly_data = (
            queryset
            .annotate(month=Extract("date", "month"))
            .values("month")
            .annotate(
                average_service_level=Avg("fill_rate"),
                total_order_qty=Sum("total_order_qty"),
                total_received_qty=Sum("total_received_qty"),
            )
            .order_by("month")
        )

        formatted_data = []
        for month_data in monthly_data:
            formatted_data.append(
                {
                    "month": month_data["month"],
                    "average_service_level": round(
                        month_data["average_service_level"] or 0.0, 3
                    ),
                    "total_order_qty": round(month_data["total_order_qty"] or 0.0, 2),
                    "total_received_qty": round(
                        month_data["total_received_qty"] or 0.0, 2
                    ),
                }
            )

        logger.info("Found data for %s months", len(formatted_data))
        return formatted_data

    @staticmethod
    def get_material_omit_counts_for_period(start_date, end_date, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get distinct count of materials with different omit types based on the average fill_rate for the period.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info(
            "Getting material omit counts for period: %s to %s", start_date, end_date
        )

        FILL_RATE_THRESHOLD = 0.85

        queryset = ServiceLevel.objects.filter(
            date__gte=start_date, date__lte=end_date, total_order_qty__gt=0
        )
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        materials_data = (
            queryset
            .values("material_id")
            .annotate(avg_fill_rate=Avg("fill_rate"))
        )

        excess_count = materials_data.filter(
            avg_fill_rate__lt=FILL_RATE_THRESHOLD
        ).count()
        allowed_count = materials_data.filter(
            avg_fill_rate__gte=FILL_RATE_THRESHOLD, avg_fill_rate__lt=1.0
        ).count()
        no_omits_count = materials_data.filter(avg_fill_rate__gte=1.0).count()

        total_products_ordered = (
            queryset
            .values("material_id")
            .annotate(total_ordered=Sum("total_order_qty"))
            .aggregate(total_products_ordered=Sum("total_ordered"))["total_products_ordered"]
            or 0
        )

        logger.info(
            "Excess omits: %d, Allowed omits: %d, No omits: %d, Total products ordered: %d",
            excess_count,
            allowed_count,
            no_omits_count,
            total_products_ordered,
        )

        omit_counts = {
            "excess_omits_count": excess_count,
            "allowed_omits_count": allowed_count,
            "no_omits_count": no_omits_count,
            "total_products_ordered": total_products_ordered,
            "total_products_with_omits": excess_count + allowed_count,
        }

        logger.info(
            "Retrieved omit counts for period with threshold %.2f", FILL_RATE_THRESHOLD
        )
        return omit_counts

    @staticmethod
    def get_material_omit_counts_for_period_daily(start_date, end_date, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get distinct count of materials with different omit types per day for the period.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info(
            "Getting material omit counts per day for period: %s to %s", start_date, end_date
        )

        FILL_RATE_THRESHOLD = 0.85

        queryset = ServiceLevel.objects.filter(
            date__gte=start_date, date__lte=end_date, total_order_qty__gt=0
        )
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        daily_results = (
            queryset
            .values("date")
            .annotate(
                excess_omits_count=Count(
                    "material_id",
                    filter=Q(fill_rate__lt=FILL_RATE_THRESHOLD),
                    distinct=True
                ),
                allowed_omits_count=Count(
                    "material_id",
                    filter=Q(fill_rate__gte=FILL_RATE_THRESHOLD, fill_rate__lt=1.0),
                    distinct=True
                ),
                no_omits_count=Count(
                    "material_id",
                    filter=Q(fill_rate__gte=1.0),
                    distinct=True
                ),
            )
            .order_by("date")
        )

        formatted_results = []

        for result in daily_results:
            formatted_results.append({
                "date": result["date"],
                "excess_omits_count": result["excess_omits_count"],
                "allowed_omits_count": result["allowed_omits_count"],
                "no_omits_count": result["no_omits_count"]
            })

        logger.info("Retrieved omit counts for %d days", len(formatted_results))
        return formatted_results

    @staticmethod
    def get_fulfillment_metrics(start_date, end_date, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Calculates unshipped quantity and fulfillment percentage per month for a given period.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting fulfillment metrics for period: %s to %s", start_date, end_date)

        queryset = ServiceLevel.objects.filter(date__gte=start_date, date__lte=end_date)
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        monthly_metrics = (
            queryset
            .annotate(year=Extract("date", "year"),
                      month=Extract("date", "month")
                      )
            .values("year", "month")
            .annotate(
                total_ordered=Sum("total_order_qty"),
                total_shipped=Sum("total_received_qty"),
            )
            .order_by("year", "month")
        )

        results = []
        for metrics in monthly_metrics:
            total_ordered = metrics.get("total_ordered") or 0.0
            total_shipped = metrics.get("total_shipped") or 0.0

            unshipped_quantity = total_ordered - total_shipped

            if total_ordered > 0:
                fulfillment_percentage = (total_shipped / total_ordered) * 100
            else:
                fulfillment_percentage = 0.0

            results.append(
                {
                    "year": metrics["year"],
                    "month": metrics["month"],
                    "unshipped_quantity": round(unshipped_quantity, 2),
                    "fulfillment_percentage": round(fulfillment_percentage, 2),
                }
            )

        logger.info("Retrieved fulfillment metrics for %d months", len(results))
        return results

    @staticmethod
    def get_material_omit_counts_for_year_monthly(year, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get distinct count of materials with different omit types per month for the given year.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info(
            "Getting material omit counts per month for year: %s", year
        )

        FILL_RATE_THRESHOLD = 0.85

        queryset = ServiceLevel.objects.filter(
            date__year=year, total_order_qty__gt=0
        )
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        monthly_results = (
            queryset
            .annotate(month=Extract("date", "month"))
            .values("month")
            .annotate(
                excess_omits_count=Count(
                    "material_id",
                    filter=Q(fill_rate__lt=FILL_RATE_THRESHOLD),
                    distinct=True
                ),
                allowed_omits_count=Count(
                    "material_id",
                    filter=Q(fill_rate__gte=FILL_RATE_THRESHOLD, fill_rate__lt=1.0),
                    distinct=True
                ),
                no_omits_count=Count(
                    "material_id",
                    filter=Q(fill_rate__gte=1.0),
                    distinct=True
                ),
            )
            .order_by("month")
        )

        formatted_results = []
        for result in monthly_results:
            formatted_results.append({
                "month": calendar.month_name[result["month"]],
                "month_num": result["month"],
                "excess_omits_count": result["excess_omits_count"],
                "allowed_omits_count": result["allowed_omits_count"],
                "no_omits_count": result["no_omits_count"]
            })

        logger.info("Retrieved monthly omit counts for %d months", len(formatted_results))
        return formatted_results

    @staticmethod
    def get_material_otif_summary(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get OTIF summary grouped by material using service level data for the last 90 days.
        Includes 30-day ordered/received totals and days-on-hand from Material fields.
        """
        end_date = date.today()
        start_date = end_date - timedelta(days=90)
        start_30d = end_date - timedelta(days=30)

        queryset = ServiceLevel.objects.filter(
            date__range=[start_date, end_date]
        )
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        return (
            queryset.values(
                'material__id', 'material__name', 'material__mat_nbr', 'material__ndc',
                'material__saleable_qty_on_hand', 'material__forecast_qty_7day',
            ).annotate(
                material_id=F('material__id'),
                material_name=F('material__name'),
                mat_nbr=F('material__mat_nbr'),
                ndc=F('material__ndc'),
                units_ordered=Sum('total_order_qty', default=0),
                units_received_on_time=Sum('on_time_units', default=0),
                units_received_late=Sum('total_received_qty', default=0) - Sum('on_time_units', default=0),
                total_received=Sum('total_received_qty', default=0),
                total_orders=Sum('total_order_qty', default=0),
                units_ordered_last_30d=Sum(
                    'total_order_qty',
                    filter=Q(date__gte=start_30d, date__lte=end_date),
                    default=0,
                ),
                units_received_last_30d=Sum(
                    'total_received_qty',
                    filter=Q(date__gte=start_30d, date__lte=end_date),
                    default=0,
                ),
                otif_percentage=Avg('otif_percentage'),
                inbound_fill_rate=Avg('fill_rate'),
            ).annotate(
                units_not_received=F('units_ordered') - F('total_received'),
                days_on_hand=Coalesce(
                    Case(
                        When(
                            material__forecast_qty_7day__gt=0,
                            then=(
                                Cast(F('material__saleable_qty_on_hand'), FloatField()) * 7.0
                            ) / Cast(F('material__forecast_qty_7day'), FloatField()),
                        ),
                        output_field=FloatField(),
                    ),
                    Value(0.0),
                    output_field=FloatField(),
                ),
            )
        )

    @staticmethod
    def get_today_otif_percentage(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Returns the OTIF percentage for today and the average OTIF percentage for the last week.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        today = date.today()
        week_start = today - timedelta(days=7)

        today_qs = ServiceLevel.objects.filter(date=today)
        today_qs = ServiceLevelService._apply_material_filter(today_qs, direct_mat_nbr, mat_nbr_subquery)

        today_data = today_qs.aggregate(
            avg_otif=Avg('otif_percentage')
        )

        weekly_qs = ServiceLevel.objects.filter(
            date__gte=week_start,
            date__lt=today
        )
        weekly_qs = ServiceLevelService._apply_material_filter(weekly_qs, direct_mat_nbr, mat_nbr_subquery)

        weekly_data = weekly_qs.aggregate(
            avg_otif=Avg('otif_percentage')
        )

        otif_percentage_today = today_data['avg_otif'] or 0.0
        weekly_average_otif = weekly_data['avg_otif'] or 0.0

        logger.info(
            "OTIF percentage for today: %.2f%%, weekly average: %.2f%%",
            otif_percentage_today,
            weekly_average_otif
        )

        return [{
            'otif_percentage': round(otif_percentage_today, 2),
            'weekly_average_otif': round(weekly_average_otif, 2)
        }]

    @staticmethod
    def get_weekly_otif_percentage(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Returns the average OTIF percentage for this week and last week.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting weekly OTIF percentage comparison for this week vs last week")
        now = timezone.now()

        current_week_start = now - timedelta(days=now.weekday())
        current_week_start = current_week_start.replace(
            hour=0, minute=0, second=0, microsecond=0
        )

        last_week_start = current_week_start - timedelta(days=7)
        last_week_end = current_week_start

        this_week_qs = ServiceLevel.objects.filter(
            date__gte=current_week_start.date(),
            date__lte=now.date()
        )
        this_week_qs = ServiceLevelService._apply_material_filter(this_week_qs, direct_mat_nbr, mat_nbr_subquery)

        this_week_data = this_week_qs.aggregate(
            avg_otif=Avg('otif_percentage')
        )

        last_week_qs = ServiceLevel.objects.filter(
            date__gte=last_week_start.date(),
            date__lt=last_week_end.date()
        )
        last_week_qs = ServiceLevelService._apply_material_filter(last_week_qs, direct_mat_nbr, mat_nbr_subquery)

        last_week_data = last_week_qs.aggregate(
            avg_otif=Avg('otif_percentage')
        )

        this_week_otif = this_week_data['avg_otif'] or 0.0
        last_week_otif = last_week_data['avg_otif'] or 0.0

        logger.info(
            "OTIF percentage - this week: %.2f%%, last week: %.2f%%",
            this_week_otif,
            last_week_otif
        )

        return [{
            'this_week_otif': round(this_week_otif, 2),
            'last_week_otif': round(last_week_otif, 2)
        }]

    @staticmethod
    def get_30day_otif_percentage(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Returns the average OTIF percentage for last rolling 30 days vs previous 30 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting 30-day OTIF percentage comparison for last 30 days vs previous 30 days")
        now = timezone.now()
        today = now.date()

        last_30_days_start = today - timedelta(days=29)
        last_30_days_end = today

        previous_30_days_start = today - timedelta(days=59)
        previous_30_days_end = today - timedelta(days=30)

        logger.info(
            "Last 30 days: %s to %s, Previous 30 days: %s to %s",
            last_30_days_start,
            last_30_days_end,
            previous_30_days_start,
            previous_30_days_end
        )

        last_30_days_qs = ServiceLevel.objects.filter(
            date__gte=last_30_days_start,
            date__lte=last_30_days_end
        )
        last_30_days_qs = ServiceLevelService._apply_material_filter(last_30_days_qs, direct_mat_nbr, mat_nbr_subquery)

        last_30_days_data = last_30_days_qs.aggregate(
            avg_otif=Avg('otif_percentage')
        )

        previous_30_days_qs = ServiceLevel.objects.filter(
            date__gte=previous_30_days_start,
            date__lte=previous_30_days_end
        )
        previous_30_days_qs = ServiceLevelService._apply_material_filter(previous_30_days_qs, direct_mat_nbr,
                                                                         mat_nbr_subquery)

        previous_30_days_data = previous_30_days_qs.aggregate(
            avg_otif=Avg('otif_percentage')
        )

        last_30_days_otif = last_30_days_data['avg_otif'] or 0.0
        previous_30_days_otif = previous_30_days_data['avg_otif'] or 0.0

        logger.info(
            "OTIF percentage - last 30 days: %.2f%%, previous 30 days: %.2f%%",
            last_30_days_otif,
            previous_30_days_otif
        )

        last_30_days_otif_rounded = round(last_30_days_otif, 2)
        previous_30_days_otif_rounded = round(previous_30_days_otif, 2)

        return [{
            'last_30_days_otif': last_30_days_otif_rounded,
            'previous_30_days_otif': previous_30_days_otif_rounded,
            'kpi_value': last_30_days_otif_rounded,
            'kpi_previous_value': previous_30_days_otif_rounded,
        }]

    DEFAULT_TREND_DAYS = 90

    @staticmethod
    def get_otif_trend(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get OTIF trend for the last 90 days with weekly aggregation.
        """
        from datetime import timedelta
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=ServiceLevelService.DEFAULT_TREND_DAYS - 1)

        queryset = ServiceLevel.objects.filter(date__gte=start_date, date__lte=end_date)
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        queryset = queryset.annotate(bucket=TruncWeek("date"))

        return list(
            queryset.values("bucket")
            .annotate(
                on_time_count=Sum("on_time_units"),
                in_full_count=Sum("in_full_units"),
                total_materials=Count("material", distinct=True),
                otif_percentage=Avg("otif_percentage"),
            )
            .order_by("bucket")
        )

    @staticmethod
    def get_daily_otif_trends(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get daily OTIF trends for the last 30 days from ServiceLevel (already aggregated).
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        end_date = date.today()
        start_date = end_date - timedelta(days=30)

        queryset = ServiceLevel.objects.filter(date__range=[start_date, end_date])
        queryset = ServiceLevelService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        daily_trends = (
            queryset
            .values('date')
            .annotate(
                on_time_count=Sum('on_time_units'),
                in_full_count=Sum('in_full_units'),
                total_materials=Count('material', distinct=True),
                otif_percentage=Avg('otif_percentage'),
            )
            .order_by('date')
        )

        trends_dict = {item['date']: item for item in daily_trends}

        result = []
        current_date = start_date
        while current_date <= end_date:
            trend_data = trends_dict.get(current_date, {})
            otif_percentage = trend_data.get('otif_percentage', 0.0)
            result.append({
                'day': current_date,
                'on_time_count': trend_data.get('on_time_count', 0),
                'in_full_count': trend_data.get('in_full_count', 0),
                'total_materials': trend_data.get('total_materials', 0),
                'otif_percentage': round(otif_percentage or 0.0, 2),
            })
            current_date += timedelta(days=1)

        return result

    @staticmethod
    def get_material_daily_otif_trends(material_id):
        """
        Get daily OTIF trends for a specific material over the last 90 days.
        Uses pre-aggregated ServiceLevel data for better performance.
        """
        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        daily_trends = (
            ServiceLevel.objects
            .filter(
                date__range=[start_date, end_date],
                material__id=material_id
            )
            .values('date')
            .annotate(
                on_time_count=Sum('on_time_units'),
                in_full_count=Sum('in_full_units'),
                total_materials=Count('id'),
                otif_percentage=Avg('otif_percentage'),
            )
            .order_by('date')
        )

        # Create a dictionary for quick lookup
        trends_dict = {item['date']: item for item in daily_trends}

        # Generate complete date range with zero values for missing days
        result = []
        current_date = start_date

        while current_date <= end_date:
            if current_date in trends_dict:
                trend_data = trends_dict[current_date]
                result.append({
                    'day': current_date,
                    'on_time_count': trend_data['on_time_count'] or 0,
                    'in_full_count': trend_data['in_full_count'] or 0,
                    'total_materials': trend_data['total_materials'],
                    'otif_percentage': round(trend_data['otif_percentage'] or 0.0, 2),
                })
            else:
                # Add zero values for days with no data
                result.append({
                    'day': current_date,
                    'on_time_count': 0,
                    'in_full_count': 0,
                    'total_materials': 0,
                    'otif_percentage': 0.0,
                })

            current_date += timedelta(days=1)

        logger.info(
            "Retrieved daily OTIF trends for material %s: %d days",
            material_id,
            len(result)
        )
        return result

    @staticmethod
    def get_units_on_order_and_fill_rate(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get units on order and inbound fill rate for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting units on order and inbound fill rate for last 90 days")

        # Calculate date range for last 90 days
        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        # Base queryset
        queryset = ServiceLevel.objects.filter(
            date__gte=start_date,
            date__lte=end_date
        )

        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        # Combine both aggregations into a single query
        metrics = queryset.aggregate(
            total_units_on_order=Sum('on_order_qty', default=0),
            avg_fill_rate=Avg('fill_rate')
        )

        total_units_on_order = metrics['total_units_on_order'] or 0
        avg_fill_rate = metrics['avg_fill_rate'] or 0.0

        logger.info(
            "Units on order: %d, Average inbound fill rate: %.2f%%",
            total_units_on_order,
            avg_fill_rate * 100.0
        )

        return {
            'units_on_order': int(total_units_on_order),
            'inbound_fill_rate': round(avg_fill_rate * 100.0, 2) if avg_fill_rate else 0.0
        }
