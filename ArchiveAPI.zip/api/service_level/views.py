from datetime import datetime
import logging

from django.conf import settings
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import FilterSet, filters, DjangoFilterBackend
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework import status, generics
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView

from api.global_filters import get_filtered_material_subquery
from api.kpi_trends import build_kpi_trend_response
from api.neo4j_graph_api.exceptions import Neo4jConnectionError, Neo4jQueryError
from api.neo4j_graph_api.services import Neo4jGraphService
from .models import ServiceLevel
from .serializers import (
    ServiceLevelWeeklyAverageSerializer,
    ServiceLevelSerializer,
    ServiceLevelPeriodQuerySerializer,
    LastTwoMonthsServiceLevelSerializer,
    MaterialOmitCountSerializer, MaterialOmitDailyCountSerializer, FulfillmentMetricsSerializer,
    MaterialOmitCountThisYearSerializer, PlantServiceLevelSerializer, MaterialOtifSummarySerializer,
    OtifTotalSerializer, OtifTrendsSerializer, MaterialOtifTrendsSerializer, OtifWeeklyComparisonSerializer,
    Otif30DayComparisonSerializer, Neo4jPlantInboundServiceLevelSerializer, PredictedFillRateSerializer,
)
from .services import ServiceLevelService
from ..pagination import MaxLimitOffsetPagination

logger = logging.getLogger(__name__)


@extend_schema_view(
    get=extend_schema(responses=ServiceLevelWeeklyAverageSerializer),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyServiceLevelAverageView(APIView):
    """
    Returns average service level for this week vs last week across all vendors.
    Supports global filters.
    """

    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ServiceLevelService.get_weekly_service_level_average(direct_mat_nbr, mat_nbr_subquery)
        serializer = ServiceLevelWeeklyAverageSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema_view(
    get=extend_schema(
        parameters=[ServiceLevelPeriodQuerySerializer],
        responses=ServiceLevelSerializer(many=True),
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class ServiceLevelPeriodView(APIView):
    """
    Returns service level data for a specific period, averaged across all vendors per day.
    Supports global filters.
    """

    def get(self, request):
        input_serializer = ServiceLevelPeriodQuerySerializer(data=request.query_params)

        if not input_serializer.is_valid():
            return Response(input_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        start_date = input_serializer.validated_data["start_date"]
        end_date = input_serializer.validated_data["end_date"]

        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ServiceLevelService.get_service_level_for_period(start_date, end_date, direct_mat_nbr, mat_nbr_subquery)
        serializer = ServiceLevelSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema_view(
    get=extend_schema(
        parameters=[ServiceLevelPeriodQuerySerializer],
        responses=PredictedFillRateSerializer(many=True),
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class PredictedFillRatePeriodView(APIView):
    """
    Returns daily fill rate for a period; the most recent 7 days are projected and older
    days are actual. Each row carries a `data_type` ('actual' | 'projected'). Supports
    global filters.
    """

    def get(self, request):
        input_serializer = ServiceLevelPeriodQuerySerializer(data=request.query_params)

        if not input_serializer.is_valid():
            return Response(input_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        start_date = input_serializer.validated_data["start_date"]
        end_date = input_serializer.validated_data["end_date"]

        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ServiceLevelService.get_predicted_fill_rate_for_period(
            start_date, end_date, direct_mat_nbr, mat_nbr_subquery
        )
        serializer = PredictedFillRateSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema_view(
    get=extend_schema(
        parameters=[ServiceLevelPeriodQuerySerializer],
        responses=PlantServiceLevelSerializer(many=True),
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class PlantServiceLevelPeriodView(APIView):
    """
    Returns service level data for a specific period, averaged across all vendors per day.
    Supports global filters.
    """

    def get(self, request):
        input_serializer = ServiceLevelPeriodQuerySerializer(data=request.query_params)

        if not input_serializer.is_valid():
            return Response(input_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        start_date = input_serializer.validated_data["start_date"]
        end_date = input_serializer.validated_data["end_date"]

        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ServiceLevelService.get_service_level_for_plants_for_period(start_date, end_date, direct_mat_nbr,
                                                                           mat_nbr_subquery)
        serializer = PlantServiceLevelSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema_view(
    get=extend_schema(
        parameters=[ServiceLevelPeriodQuerySerializer],
        responses=Neo4jPlantInboundServiceLevelSerializer(many=True),
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class Neo4jInboundServiceLevelPeriodView(APIView):
    """
    Returns InboundServiceLevel data from Neo4j for a specific period, grouped by plant with daily service levels.
    Supports global filters.
    """

    def get(self, request):
        """Retrieve InboundServiceLevel data from Neo4j with date filtering and global filters."""
        try:
            input_serializer = ServiceLevelPeriodQuerySerializer(data=request.query_params)

            if not input_serializer.is_valid():
                return Response(input_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            start_date = input_serializer.validated_data["start_date"]
            end_date = input_serializer.validated_data["end_date"]

            # Get material filters
            direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
            mat_nbrs = None

            if direct_mat_nbr:
                mat_nbrs = [direct_mat_nbr]
            elif mat_nbr_subquery is not None:
                # Convert QuerySet to list of mat_nbr values
                mat_nbrs = list(mat_nbr_subquery)

            # Convert dates to strings for Neo4j query
            start_date_str = start_date.strftime('%Y-%m-%d')
            end_date_str = end_date.strftime('%Y-%m-%d')

            # Get data from Neo4j
            data = Neo4jGraphService.get_inbound_service_levels_for_plants_for_period(
                start_date=start_date_str,
                end_date=end_date_str,
                mat_nbrs=mat_nbrs
            )

            serializer = Neo4jPlantInboundServiceLevelSerializer(data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except (Neo4jConnectionError, Neo4jQueryError) as e:
            logger.error(f"Neo4j error in Neo4jInboundServiceLevelPeriodView: {str(e)}")
            return Response(
                {
                    "success": False,
                    "error": "Neo4j service is temporarily unavailable."
                },
                status=status.HTTP_503_SERVICE_UNAVAILABLE
            )
        except Exception as e:
            logger.error(f"Unexpected error in Neo4jInboundServiceLevelPeriodView: {str(e)}")
            return Response(
                {
                    "success": False,
                    "error": "An unexpected error occurred while retrieving service level data."
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


@extend_schema_view(
    get=extend_schema(responses=LastTwoMonthsServiceLevelSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class LastTwoMonthsServiceLevelView(APIView):
    """
    Returns average service level data for the last two months, grouped by month.
    Supports global filters.
    """

    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ServiceLevelService.get_last_two_months_service_level(direct_mat_nbr, mat_nbr_subquery)
        serializer = LastTwoMonthsServiceLevelSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema_view(
    get=extend_schema(
        parameters=[ServiceLevelPeriodQuerySerializer],
        responses=MaterialOmitCountSerializer,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialOmitCountView(APIView):
    """
    Returns distinct count of materials with Excess Omits, Allowed Omits and No Omits per day for a given period.
    Supports global filters.
    """

    def get(self, request):
        input_serializer = ServiceLevelPeriodQuerySerializer(data=request.query_params)

        if not input_serializer.is_valid():
            return Response(input_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        start_date = input_serializer.validated_data["start_date"]
        end_date = input_serializer.validated_data["end_date"]

        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)

        grouped_data = ServiceLevelService.get_material_omit_counts_for_period(
            start_date, end_date, direct_mat_nbr, mat_nbr_subquery
        )
        daily_data = ServiceLevelService.get_material_omit_counts_for_period_daily(
            start_date, end_date, direct_mat_nbr, mat_nbr_subquery)
        combined_data = {
            **grouped_data,
            "daily_data": daily_data,
        }
        serializer = MaterialOmitCountSerializer(combined_data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema_view(
    get=extend_schema(
        parameters=[ServiceLevelPeriodQuerySerializer],
        responses=MaterialOmitDailyCountSerializer(many=True),
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialOmitCountDailyView(APIView):
    """
    Returns distinct count of materials with Excess Omits, Allowed Omits and No Omits per day for a given period.
    Supports global filters.
    """

    def get(self, request):
        input_serializer = ServiceLevelPeriodQuerySerializer(data=request.query_params)

        if not input_serializer.is_valid():
            return Response(input_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        start_date = input_serializer.validated_data["start_date"]
        end_date = input_serializer.validated_data["end_date"]

        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)

        data = ServiceLevelService.get_material_omit_counts_for_period_daily(
            start_date, end_date, direct_mat_nbr, mat_nbr_subquery
        )
        serializer = MaterialOmitDailyCountSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema_view(
    get=extend_schema(responses=MaterialOmitCountThisYearSerializer),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialOmitCountThisYearView(APIView):
    """
    Returns distinct count of materials with Excess Omits, Allowed Omits and No Omits
    for the current year, with a monthly breakdown.
    Supports global filters.
    """

    def get(self, request):
        current_year = timezone.now().year
        start_of_year = timezone.datetime(current_year, 1, 1).date()
        end_of_year = timezone.datetime(current_year, 12, 31).date()

        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)

        grouped_data = ServiceLevelService.get_material_omit_counts_for_period(
            start_of_year, end_of_year, direct_mat_nbr, mat_nbr_subquery
        )
        monthly_data = ServiceLevelService.get_material_omit_counts_for_year_monthly(
            current_year, direct_mat_nbr, mat_nbr_subquery
        )
        combined_data = {
            **grouped_data,
            "monthly_data": monthly_data,
        }
        serializer = MaterialOmitCountThisYearSerializer(combined_data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema_view(
    get=extend_schema(
        parameters=[ServiceLevelPeriodQuerySerializer],
        responses=FulfillmentMetricsSerializer(many=True),
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class FulfillmentMetricsView(APIView):
    """
    Returns the total quantity ordered but not shipped and the fulfillment percentage for a given period.
    Supports global filters.
    """

    def get(self, request):
        input_serializer = ServiceLevelPeriodQuerySerializer(data=request.query_params)

        if not input_serializer.is_valid():
            return Response(input_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        start_date = input_serializer.validated_data["start_date"]
        end_date = input_serializer.validated_data["end_date"]

        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = ServiceLevelService.get_fulfillment_metrics(start_date, end_date, direct_mat_nbr, mat_nbr_subquery)
        serializer = FulfillmentMetricsSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class MaterialOtifSummaryFilter(FilterSet):
    """
    FilterSet for Material OTIF Summary.
    """
    material = filters.CharFilter(field_name="mat_nbr", lookup_expr="exact")
    units_ordered_min = filters.NumberFilter(field_name="units_ordered", lookup_expr="gte")
    units_ordered_max = filters.NumberFilter(field_name="units_ordered", lookup_expr="lte")
    units_received_on_time_min = filters.NumberFilter(field_name="units_received_on_time", lookup_expr="gte")
    units_received_on_time_max = filters.NumberFilter(field_name="units_received_on_time", lookup_expr="lte")
    units_received_late_min = filters.NumberFilter(field_name="units_received_late", lookup_expr="gte")
    units_received_late_max = filters.NumberFilter(field_name="units_received_late", lookup_expr="lte")
    units_not_received_min = filters.NumberFilter(field_name="units_not_received", lookup_expr="gte")
    units_not_received_max = filters.NumberFilter(field_name="units_not_received", lookup_expr="lte")
    total_orders_min = filters.NumberFilter(field_name="total_orders", lookup_expr="gte")
    total_orders_max = filters.NumberFilter(field_name="total_orders", lookup_expr="lte")
    inbound_fill_rate_min = filters.NumberFilter(field_name="inbound_fill_rate", lookup_expr="gte")
    inbound_fill_rate_max = filters.NumberFilter(field_name="inbound_fill_rate", lookup_expr="lte")

    class Meta:
        model = ServiceLevel
        fields = []


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialOtifSummaryView(generics.ListAPIView):
    """
    View for material OTIF summary with pagination.
    Groups purchase orders by material and returns aggregated statistics.
    """
    serializer_class = MaterialOtifSummarySerializer
    pagination_class = MaxLimitOffsetPagination
    filterset_class = MaterialOtifSummaryFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = ['units_ordered',
                       'units_received_on_time',
                       'units_received_late',
                       'units_not_received',
                       'total_orders',
                       'material_name',
                       'inbound_fill_rate',
                       'otif_percentage',
                       'days_on_hand',
                       'units_ordered_last_30d',
                       'units_received_last_30d',
                       'ndc',
                       ]
    ordering = ['-units_ordered']

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        result = ServiceLevelService.get_material_otif_summary(direct_mat_nbr, mat_nbr_subquery)
        return result


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class OtifTotalView(generics.ListAPIView):
    """
    View for OTIF total percentage using service level data.
    """
    serializer_class = OtifTotalSerializer
    pagination_class = None

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return ServiceLevelService.get_today_otif_percentage(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class OtifWeeklyComparisonView(generics.ListAPIView):
    """
    View for OTIF total percentage using service level data.
    """
    serializer_class = OtifWeeklyComparisonSerializer
    pagination_class = None

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return ServiceLevelService.get_weekly_otif_percentage(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class Otif30DayComparisonView(generics.ListAPIView):
    """
    View for OTIF total percentage comparing last rolling 30 days vs previous 30 days.
    Includes trend data for the last 90 days.
    Supports global filters.
    """
    serializer_class = Otif30DayComparisonSerializer
    pagination_class = None

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return ServiceLevelService.get_30day_otif_percentage(direct_mat_nbr, mat_nbr_subquery)

    def list(self, request, *args, **kwargs):
        response = super().list(request, *args, **kwargs)

        if not isinstance(response.data, list) or not response.data:
            return response

        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)

        rows = ServiceLevelService.get_otif_trend(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )

        bucket_to_payload = {}
        for row in rows:
            bucket = row["bucket"]
            if isinstance(bucket, datetime):
                bucket = bucket.date()
            otif_pct = round(row.get("otif_percentage") or 0.0, 2)
            bucket_to_payload[bucket] = {
                "value": otif_pct,
                "otif_percentage": otif_pct,
                "on_time_count": row.get("on_time_count") or 0,
                "in_full_count": row.get("in_full_count") or 0,
                "total_materials": row.get("total_materials") or 0,
            }

        response.data[0]["trend"] = build_kpi_trend_response(
            kpi="otif",
            unit="percent",
            bucket_to_payload=bucket_to_payload,
            default_value=0.0,
        )
        return response


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class DailyOtifTrendsView(generics.ListAPIView):
    """
    View for daily OTIF trends for the last 30 days.
    """
    serializer_class = OtifTrendsSerializer
    pagination_class = None

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return ServiceLevelService.get_daily_otif_trends(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
@extend_schema_view(get=extend_schema(operation_id='api_service_level_otif_trends_by_material_list'))
class MaterialDailyOtifTrendsView(generics.ListAPIView):
    """
    View for daily OTIF trends for given material for the last 90 days.
    """
    serializer_class = MaterialOtifTrendsSerializer
    pagination_class = None

    def get_queryset(self):
        material_id = self.kwargs.get('material_id')
        return ServiceLevelService.get_material_daily_otif_trends(material_id)
