from django.apps import AppConfig


class ServiceLevelConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.service_level"
