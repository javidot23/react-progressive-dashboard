from django.db import models

from api.material.models import Material
from api.plant.models import Plant


class ServiceLevel(models.Model):
    date = models.DateField(unique=False, blank=True, null=True)
    total_order_qty = models.IntegerField(default=0, blank=True, null=True)
    total_received_qty = models.IntegerField(default=0, blank=True, null=True)
    fill_rate = models.FloatField(default=0.0, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    otif_percentage = models.FloatField(default=0.0, blank=True, null=True)
    # total_orders = models.IntegerField(default=0, blank=True, null=True)  # Total number of orders
    # total_received_lines = models.IntegerField(default=0, blank=True, null=True)  # Total number of received lines
    on_time_units = models.IntegerField(default=0, blank=True, null=True)  # Total number of on-time units
    in_full_units = models.IntegerField(default=0, blank=True, null=True)  # Total number of in-full units
    on_order_qty = models.IntegerField(default=0, blank=True, null=True)  # Total quantity on order
    total_omit_qty = models.IntegerField(default=0, blank=True, null=True)  # Total omitted quantity

    class Meta:
        db_table = "inbound_service_level"
        verbose_name = "Service Level"
        verbose_name_plural = "Service Levels"
        indexes = [
            models.Index(fields=["date"]),
            models.Index(fields=["date", "fill_rate"]),
            models.Index(fields=["material"]),
            models.Index(fields=["date", "material"]),
            models.Index(fields=["plant"]),
            models.Index(fields=["date", "plant"]),
            models.Index(fields=["material", "plant"])
        ]
        unique_together = (("date", "material", "plant"),)
