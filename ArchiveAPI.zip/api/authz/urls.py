from django.urls import path

from . import views

app_name = "authz"

urlpatterns = [
    path("resources/", views.ResourcesView.as_view(), name="resources"),
]
