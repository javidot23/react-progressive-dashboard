import uuid

from django.db import models

from api.common.models import TimestampedModel
from api.tenant.choices import EntitlementTier

from .choices import AssignmentSource, PermissionType, ResourceType


class Resource(TimestampedModel):
    resource_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    parent_resource = models.ForeignKey(
        "self", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="children", db_column="parent_resource_uuid",
    )
    resource_code = models.CharField(max_length=100, unique=True)
    resource_name = models.CharField(max_length=255)
    resource_description = models.TextField(blank=True)
    resource_type = models.CharField(max_length=20, choices=ResourceType.choices)
    display_order = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "resource"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(resource_type__in=ResourceType.values), name="resource_type_valid"
            ),
        ]

    def __str__(self):
        return self.resource_code


class Permission(TimestampedModel):
    permission_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    resource = models.ForeignKey(
        Resource, on_delete=models.CASCADE, related_name="permissions", db_column="resource_uuid"
    )
    permission_type = models.CharField(max_length=20, choices=PermissionType.choices)
    permission_code = models.CharField(max_length=150, unique=True)
    action_code = models.CharField(max_length=100, blank=True)
    permission_name = models.CharField(max_length=255)
    permission_description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "permission"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(permission_type__in=PermissionType.values), name="permission_type_valid"
            ),
        ]

    def __str__(self):
        return self.permission_code


class EntitlementResource(TimestampedModel):
    entitlement_tier = models.CharField(max_length=20, choices=EntitlementTier.choices)
    resource = models.ForeignKey(
        Resource, on_delete=models.CASCADE, related_name="entitlement_links", db_column="resource_uuid"
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "entitlement_resource"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(entitlement_tier__in=EntitlementTier.values), name="entitlement_resource_tier_valid"
            ),
            models.UniqueConstraint(fields=["entitlement_tier", "resource"], name="entitlement_resource_unique"),
        ]

    def __str__(self):
        return f"{self.entitlement_tier} -> {self.resource_id}"


class Role(TimestampedModel):
    role_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    role_code = models.CharField(max_length=100, unique=True)
    role_name = models.CharField(max_length=255)
    role_description = models.TextField(blank=True)
    is_system_role = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "role"

    def __str__(self):
        return self.role_code


class RolePermission(TimestampedModel):
    role = models.ForeignKey(
        Role, on_delete=models.CASCADE, related_name="role_permissions", db_column="role_uuid"
    )
    permission = models.ForeignKey(
        Permission, on_delete=models.CASCADE, related_name="role_permissions", db_column="permission_uuid"
    )
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(
        "user.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+", db_column="created_by_user_uuid",
    )

    class Meta:
        db_table = "role_permission"
        constraints = [
            models.UniqueConstraint(fields=["role", "permission"], name="role_permission_unique"),
        ]

    def __str__(self):
        return f"{self.role_id} -> {self.permission_id}"


class UserRole(TimestampedModel):
    user_role_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        "tenant.Tenant", on_delete=models.CASCADE, related_name="user_roles", db_column="tenant_uuid"
    )
    user = models.ForeignKey(
        "user.User", on_delete=models.CASCADE, related_name="user_roles", db_column="user_uuid"
    )
    role = models.ForeignKey(
        Role, on_delete=models.CASCADE, related_name="user_roles", db_column="role_uuid"
    )
    assignment_source = models.CharField(
        max_length=20, choices=AssignmentSource.choices, default=AssignmentSource.DIRECT
    )
    created_by = models.ForeignKey(
        "user.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+", db_column="created_by_user_uuid",
    )
    effective_from = models.DateTimeField(null=True, blank=True)
    effective_to = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "user_role"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(assignment_source__in=AssignmentSource.values),
                name="user_role_assignment_source_valid",
            ),
            models.UniqueConstraint(fields=["tenant", "user", "role"], name="user_role_unique"),
        ]

    def __str__(self):
        return f"{self.user_id} - {self.role_id} @ {self.tenant_id}"
