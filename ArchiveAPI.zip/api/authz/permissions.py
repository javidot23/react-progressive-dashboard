"""Entitlement-based access control applied to every endpoint."""

from rest_framework.permissions import BasePermission

from api.authz.entitlements import resource_code_for_view
from api.authz.exceptions import EntitlementRequired
from api.authz.services import EntitlementResourceService
from api.tenant.exceptions import ActiveTenantRequired


class HasModuleEntitlement(BasePermission):
    """Allow a request only when the active tenant's tier unlocks the endpoint's module.

    The required resource comes from the endpoint's app (see
    ``api.authz.entitlements``) or from a ``required_resource`` attribute on the
    view. Endpoints that map to no resource are allowed through.
    """

    def has_permission(self, request, view):
        resource_code = resource_code_for_view(view)
        if resource_code is None:
            return True

        tenant = getattr(request, "tenant", None)
        if tenant is None:
            raise ActiveTenantRequired()

        granted = EntitlementResourceService.resource_codes_for_tier(tenant.entitlement_tier)
        if resource_code in granted:
            return True

        raise EntitlementRequired(
            f"The active tenant's plan does not include '{resource_code}'."
        )
