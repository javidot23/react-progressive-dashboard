from django.db import models


class ResourceType(models.TextChoices):
    MENU = "menu", "Menu"
    PAGE = "page", "Page"
    WIDGET = "widget", "Widget"


class PermissionType(models.TextChoices):
    VIEW = "view", "View"
    MANAGE = "manage", "Manage"
    APPROVE = "approve", "Approve"
    DISABLE = "disable", "Disable"
    DELETE = "delete", "Delete"


class AssignmentSource(models.TextChoices):
    DIRECT = "direct", "Direct"
    INHERITED = "inherited", "Inherited"
    SYNCED = "synced", "Synced"
    DELEGATED = "delegated", "Delegated"
    SYSTEM = "system", "System"
