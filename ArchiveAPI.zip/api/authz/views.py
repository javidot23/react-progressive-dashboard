from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from drf_spectacular.utils import extend_schema
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from api.audit.choices import AuditEventType
from api.audit.services import AuditService
from api.authz.serializers import TenantResourcesSerializer
from api.authz.services import EntitlementResourceService
from api.tenant.exceptions import ActiveTenantRequired
from api.tenant.services import TenantMembershipService, TenantService


@method_decorator(never_cache, name="dispatch")
class ResourcesView(APIView):
    """GET /api/authz/resources/ — resources unlocked by the active tenant's entitlement tier."""

    @extend_schema(responses=TenantResourcesSerializer)
    def get(self, request):
        tenant = getattr(request, "tenant", None)
        if tenant is None:
            tenant = TenantMembershipService.get_active(request.user, request.session)
        if tenant is not None:
            # Bypass the ~60s middleware row cache so entitlement_tier is live.
            tenant = TenantService.get_usable(tenant.pk, use_cache=False)
        if tenant is None:
            AuditService.record_from_request(
                request,
                AuditEventType.ACCESS_DENIED,
                reason_code="tenant_required",
                status=status.HTTP_403_FORBIDDEN,
            )
            raise ActiveTenantRequired()

        resources = EntitlementResourceService.list_resources_for_tier(tenant.entitlement_tier)
        payload = {
            "entitlement_tier": tenant.entitlement_tier,
            "resources": resources,
        }
        return Response(TenantResourcesSerializer(payload).data)
