from rest_framework import serializers

from api.authz.models import Resource, Role


class RoleUpdateSerializer(serializers.ModelSerializer):
    """Presentation fields only — role_code is not writable."""

    class Meta:
        model = Role
        fields = ["role_code", "role_name", "role_description", "is_active"]
        read_only_fields = ["role_code"]


class EntitledResourceSerializer(serializers.ModelSerializer):
    """SPA-facing resource fields for entitlement-based visibility."""

    class Meta:
        model = Resource
        fields = [
            "resource_uuid",
            "resource_code",
            "resource_name",
            "resource_type",
            "display_order",
            "parent_resource",
        ]


class TenantResourcesSerializer(serializers.Serializer):
    entitlement_tier = serializers.CharField()
    resources = EntitledResourceSerializer(many=True)
