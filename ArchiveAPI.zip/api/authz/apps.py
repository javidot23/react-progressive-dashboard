from django.apps import AppConfig

from config.db_scope import DBScope


class AuthzConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.authz'
    label = 'authz'
    db_scope = DBScope.CORE
