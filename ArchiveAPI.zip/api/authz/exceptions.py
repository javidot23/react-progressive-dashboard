"""HTTP exceptions for entitlement enforcement."""

from rest_framework.exceptions import APIException


class EntitlementRequired(APIException):
    """Raised when the active tenant's entitlement tier does not unlock an endpoint."""

    status_code = 403
    default_code = "entitlement_required"
    default_detail = "The active tenant's plan does not include this feature."
