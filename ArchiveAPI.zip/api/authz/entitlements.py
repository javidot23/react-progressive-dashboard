"""Which entitlement resource each API app requires.

An app listed in ``RESOURCE_BY_APP`` is reachable only when the active tenant's
entitlement tier grants that resource code (see ``entitlement_resource``). Apps
in ``UNGATED_APPS`` are reachable on every tier. Every app that serves API views
must appear in exactly one of the two, or the ``authz.E001`` system check fails
startup — a new app is gated deliberately rather than by omission.

A single view can require its own resource by declaring ``required_resource``,
which takes precedence over its app's entry.
"""

RESOURCE_BY_APP = {
    "issue": "module.react",
    "supply_chain_events": "module.react",
}

UNGATED_APPS = frozenset({
    "action",
    "ai_insights",
    "authz",
    "billing_transaction",
    "button_journey",
    "chargeback",
    "custom_lists",
    "customer_corp_chain",
    "data_update_history",
    "demand_forecast",
    "epcis_serial_assignment",
    "filter_ranges",
    "identity",
    "inbound_serialization_scans",
    "info",
    "issue_note",
    "material",
    "material_formulary",
    "material_formulary_change",
    "material_risk",
    "material_substitute",
    "material_value_at_risk_history",
    "order_transaction",
    "order_transaction_aggregated",
    "outbound_serialization_scans",
    "plant",
    "purchase_order",
    "quarantine_event",
    "returns_serialization_scans",
    "risk_model_description",
    "service_level",
    "tenant",
    "user",
    "user_feedback",
    "user_setting",
    "vendor",
})


def app_label_for_view(view) -> str | None:
    """The ``api.<label>`` app a view belongs to, or ``None`` for views outside ``api``."""
    view_class = view if isinstance(view, type) else type(view)
    parts = getattr(view_class, "__module__", "").split(".")
    if len(parts) > 2 and parts[0] == "api":
        return parts[1]
    return None


def resource_code_for_view(view) -> str | None:
    """The resource code an endpoint requires, or ``None`` when it is ungated."""
    declared = getattr(view, "required_resource", None)
    if declared:
        return declared
    app_label = app_label_for_view(view)
    if app_label is None:
        return None
    return RESOURCE_BY_APP.get(app_label)
