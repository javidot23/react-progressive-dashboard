import logging

from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework import status
from rest_framework.exceptions import ValidationError, NotFound
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.material_value_at_risk_history.serializers import LatestMaterialValueAtRiskSerializer
from api.material_value_at_risk_history.services import MaterialValueAtRiskHistoryService

logger = logging.getLogger(__name__)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class LatestMaterialValueAtRiskView(APIView):
    """
    View to retrieve the latest dollars at risk value for a given material.
    Returns the most recent entry based on status_date.
    """

    @extend_schema(responses=LatestMaterialValueAtRiskSerializer)
    def get(self, request, mat_nbr):
        """
        Get the latest dollars at risk value for a material.

        Args:
            request: The HTTP request
            mat_nbr: The material number (from URL parameter)

        Returns:
            Response with the latest material value at risk data
        """
        if not mat_nbr:
            raise ValidationError({"error": "Material number is required"})

        try:
            latest_entry = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(mat_nbr)
        except ValueError as e:
            logger.warning("Error getting latest dollars at risk: %s", str(e))
            raise ValidationError({"error": f"Material {mat_nbr} not found"})
        except Exception as e:
            logger.error("Unexpected error getting latest dollars at risk: %s", str(e))
            raise ValidationError({"error": "An error occurred while retrieving the data"})

        if not latest_entry:
            raise NotFound({"error": f"No value at risk history found for material {mat_nbr}"})

        serializer = LatestMaterialValueAtRiskSerializer({
            'material_nbr': latest_entry.material.mat_nbr,
            'material_name': latest_entry.material.name,
            'dollars_at_risk_30_day': latest_entry.dollars_at_risk_30_day,
            'status_date': latest_entry.status_date,
        })

        return Response(serializer.data, status=status.HTTP_200_OK)
