import logging
from typing import Optional

from django.db.models import Q

from api.material.models import Material
from api.material_value_at_risk_history.models import MaterialValueAtRiskHistory

logger = logging.getLogger(__name__)

EXCLUDED_MATERIAL_Q = Q(material__drop_ship_flg=1) | Q(material__short_date_flg=1)


class MaterialValueAtRiskHistoryService:
    """
    Service class for handling material value at risk history.
    Contains all business logic and model interaction for material value at risk history.
    """

    @classmethod
    def get_latest_dollars_at_risk(cls, mat_nbr: str) -> Optional[MaterialValueAtRiskHistory]:
        """
        Get the latest material value at risk history entry for a given material.
        Returns the entry with the most recent status_date.

        Args:
            mat_nbr: The material number

        Returns:
            MaterialValueAtRiskHistory instance with the latest status_date, or None if not found

        Raises:
            ValueError: If material does not exist
        """
        logger.info("Getting latest dollars at risk for material %s", mat_nbr)

        try:
            Material.objects.get(mat_nbr=mat_nbr)
        except Material.DoesNotExist:
            logger.warning("Material %s not found", mat_nbr)
            raise ValueError(f"Material {mat_nbr} not found")

        latest_entry = (
            MaterialValueAtRiskHistory.objects
            .select_related('material')
            .filter(material_id=mat_nbr)
            .exclude(material__xplant_mat_stat__in=['DB', 'DM'])
            .exclude(EXCLUDED_MATERIAL_Q)
            .order_by('-status_date')
            .first()
        )

        if not latest_entry:
            logger.info("No value at risk history found for material %s", mat_nbr)
            return None

        logger.info(
            "Found latest value at risk for material %s: %s (status_date: %s)",
            mat_nbr,
            latest_entry.dollars_at_risk_30_day,
            latest_entry.status_date
        )

        return latest_entry
