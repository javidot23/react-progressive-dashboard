from django.db import models
from django.utils import timezone

from api.material.models import Material


class MaterialValueAtRiskHistory(models.Model):
    """
    Model to represent material value at risk history.
    """
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
    )
    dollars_at_risk_30_day = models.FloatField(default=0.0, null=True)
    status_date = models.DateField(null=False, blank=False, default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "material_value_at_risk_history"
        verbose_name = "Material Value At Risk History"
        verbose_name_plural = "Material Value At Risk History"
        unique_together = ('material', 'status_date')
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["material", "status_date"]),
            models.Index(fields=["status_date"]),
        ]
