from django.apps import AppConfig


class MaterialValueAtRiskHistoryConfig(AppConfig):
    name = 'api.material_value_at_risk_history'
