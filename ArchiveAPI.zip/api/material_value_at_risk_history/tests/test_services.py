from datetime import timedelta

from django.utils import timezone

from api.material_value_at_risk_history.services import MaterialValueAtRiskHistoryService
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class MaterialValueAtRiskHistoryServiceTest(BaseTestCase):
    """Test cases for MaterialValueAtRiskHistoryService."""

    def setUp(self):
        """Set up test data for service tests."""
        self.material = TestDataFactory.create_material()
        self.today = timezone.now().date()

    def test_get_latest_dollars_at_risk_with_history(self):
        """Test getting latest dollars at risk for material with history."""
        # Create older entry
        older_date = self.today - timedelta(days=5)
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=older_date,
            dollars_at_risk_30_day=30000.0
        )

        # Create newer entry (should be returned)
        newer_date = self.today - timedelta(days=2)
        newer_entry = TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=newer_date,
            dollars_at_risk_30_day=50000.0
        )

        # Get latest
        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            self.material.mat_nbr
        )

        self.assertIsNotNone(latest)
        self.assertEqual(latest.id, newer_entry.id)
        self.assertEqual(latest.dollars_at_risk_30_day, 50000.0)
        self.assertEqual(latest.status_date, newer_date)

    def test_get_latest_dollars_at_risk_no_history(self):
        """Test getting latest dollars at risk for material without history."""
        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            self.material.mat_nbr
        )

        self.assertIsNone(latest)

    def test_get_latest_dollars_at_risk_material_not_found(self):
        """Test getting latest dollars at risk for non-existent material."""
        with self.assertRaises(ValueError) as context:
            MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk("NONEXISTENT")
        self.assertIn("Material NONEXISTENT not found", str(context.exception))

    def test_get_latest_dollars_at_risk_multiple_entries(self):
        """Test getting latest when material has multiple entries."""
        # Create multiple entries with different dates
        dates = [
            self.today - timedelta(days=10),
            self.today - timedelta(days=5),
            self.today - timedelta(days=1),  # Latest
            self.today - timedelta(days=3),
        ]

        for i, date_val in enumerate(dates):
            TestDataFactory.create_material_value_at_risk_history(
                material=self.material,
                status_date=date_val,
                dollars_at_risk_30_day=10000.0 * (i + 1)
            )

        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            self.material.mat_nbr
        )

        self.assertIsNotNone(latest)
        # Should return the entry with the most recent status_date
        self.assertEqual(latest.status_date, self.today - timedelta(days=1))

    def test_get_latest_dollars_at_risk_single_entry(self):
        """Test getting latest when material has only one entry."""
        entry = TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=self.today - timedelta(days=7),
            dollars_at_risk_30_day=25000.0
        )

        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            self.material.mat_nbr
        )

        self.assertIsNotNone(latest)
        self.assertEqual(latest.id, entry.id)
        self.assertEqual(latest.dollars_at_risk_30_day, 25000.0)


class MaterialValueAtRiskHistoryDiscontinuedFilterTest(BaseTestCase):
    """Tests that discontinued materials (xplant_mat_stat DB/DM) are excluded."""

    def setUp(self):
        self.today = timezone.now().date()

    def test_get_latest_excludes_discontinued_db(self):
        """Should return None for a material with xplant_mat_stat=DB even with history."""
        discontinued = TestDataFactory.create_material(xplant_mat_stat='DB')
        TestDataFactory.create_material_value_at_risk_history(
            material=discontinued,
            status_date=self.today,
            dollars_at_risk_30_day=99000.0,
        )

        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            discontinued.mat_nbr
        )
        self.assertIsNone(latest)

    def test_get_latest_excludes_discontinued_dm(self):
        """Should return None for a material with xplant_mat_stat=DM even with history."""
        discontinued = TestDataFactory.create_material(xplant_mat_stat='DM')
        TestDataFactory.create_material_value_at_risk_history(
            material=discontinued,
            status_date=self.today,
            dollars_at_risk_30_day=88000.0,
        )

        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            discontinued.mat_nbr
        )
        self.assertIsNone(latest)

    def test_get_latest_includes_active_material(self):
        """Should return data for an active material."""
        active = TestDataFactory.create_material(xplant_mat_stat='ACTIVE')
        TestDataFactory.create_material_value_at_risk_history(
            material=active,
            status_date=self.today,
            dollars_at_risk_30_day=55000.0,
        )

        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            active.mat_nbr
        )
        self.assertIsNotNone(latest)
        self.assertEqual(latest.dollars_at_risk_30_day, 55000.0)


class MaterialValueAtRiskHistoryDropShipShortDateFilterTest(BaseTestCase):
    """Tests that drop-ship and short-date flagged materials are excluded."""

    def setUp(self):
        self.today = timezone.now().date()

    def test_get_latest_excludes_drop_ship(self):
        """Should return None for a drop-ship material even with history."""
        drop_ship = TestDataFactory.create_material(drop_ship_flg=1)
        TestDataFactory.create_material_value_at_risk_history(
            material=drop_ship,
            status_date=self.today,
            dollars_at_risk_30_day=99000.0,
        )

        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            drop_ship.mat_nbr
        )
        self.assertIsNone(latest)

    def test_get_latest_excludes_short_date(self):
        """Should return None for a short-date material even with history."""
        short_date = TestDataFactory.create_material(short_date_flg=1)
        TestDataFactory.create_material_value_at_risk_history(
            material=short_date,
            status_date=self.today,
            dollars_at_risk_30_day=88000.0,
        )

        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            short_date.mat_nbr
        )
        self.assertIsNone(latest)

    def test_get_latest_includes_normal_material(self):
        """Should return data for a normal (unflagged) material."""
        normal = TestDataFactory.create_material()
        TestDataFactory.create_material_value_at_risk_history(
            material=normal,
            status_date=self.today,
            dollars_at_risk_30_day=55000.0,
        )

        latest = MaterialValueAtRiskHistoryService.get_latest_dollars_at_risk(
            normal.mat_nbr
        )
        self.assertIsNotNone(latest)
        self.assertEqual(latest.dollars_at_risk_30_day, 55000.0)
