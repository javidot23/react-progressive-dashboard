from datetime import timedelta

from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APIClient

from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class MaterialValueAtRiskHistoryIntegrationTest(BaseAPITestCase):
    """Integration tests for MaterialValueAtRiskHistory views."""

    def setUp(self):
        """Set up test data for integration tests."""
        self.client = APIClient()
        self.material = TestDataFactory.create_material(
            mat_nbr="TEST-MAT-001",
            name="Test Material"
        )
        self.today = timezone.now().date()

    def test_get_latest_material_value_at_risk_success(self):
        """Test successful retrieval of latest material value at risk."""
        # Create history entries
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=self.today - timedelta(days=5),
            dollars_at_risk_30_day=30000.0
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=self.today - timedelta(days=2),
            dollars_at_risk_30_day=50000.0
        )

        url = reverse(
            'material_value_at_risk_history:latest-material-value-at-risk',
            kwargs={'mat_nbr': self.material.mat_nbr}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['material_nbr'], self.material.mat_nbr)
        self.assertEqual(response.data['material_name'], self.material.name)
        self.assertEqual(response.data['dollars_at_risk_30_day'], 50000.0)
        self.assertEqual(
            response.data['status_date'],
            (self.today - timedelta(days=2)).isoformat()
        )

    def test_get_latest_material_value_at_risk_not_found(self):
        """Test getting latest value for material without history."""
        url = reverse(
            'material_value_at_risk_history:latest-material-value-at-risk',
            kwargs={'mat_nbr': self.material.mat_nbr}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertIn('error', response.data)
        self.assertIn('No value at risk history found', response.data['error'])

    def test_get_latest_material_value_at_risk_invalid_material(self):
        """Test getting latest value for non-existent material."""
        url = reverse(
            'material_value_at_risk_history:latest-material-value-at-risk',
            kwargs={'mat_nbr': 'INVALID-MAT-999'}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('error', response.data)
        self.assertIn('Material INVALID-MAT-999 not found', response.data['error'])

    def test_get_latest_material_value_at_risk_single_entry(self):
        """Test getting latest value when material has only one entry."""
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=self.today - timedelta(days=7),
            dollars_at_risk_30_day=25000.0
        )

        url = reverse(
            'material_value_at_risk_history:latest-material-value-at-risk',
            kwargs={'mat_nbr': self.material.mat_nbr}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['dollars_at_risk_30_day'], 25000.0)
        self.assertEqual(
            response.data['status_date'],
            (self.today - timedelta(days=7)).isoformat()
        )

    def test_get_latest_material_value_at_risk_response_structure(self):
        """Test that response has the correct structure."""
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=self.today,
            dollars_at_risk_30_day=75000.0
        )

        url = reverse(
            'material_value_at_risk_history:latest-material-value-at-risk',
            kwargs={'mat_nbr': self.material.mat_nbr}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('material_nbr', response.data)
        self.assertIn('material_name', response.data)
        self.assertIn('dollars_at_risk_30_day', response.data)
        self.assertIn('status_date', response.data)

    def test_get_latest_excludes_discontinued_db(self):
        """API should return 404 for discontinued (DB) material even with history."""
        discontinued = TestDataFactory.create_material(xplant_mat_stat='DB')
        TestDataFactory.create_material_value_at_risk_history(
            material=discontinued,
            status_date=self.today,
            dollars_at_risk_30_day=50000.0,
        )

        url = reverse(
            'material_value_at_risk_history:latest-material-value-at-risk',
            kwargs={'mat_nbr': discontinued.mat_nbr}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_get_latest_excludes_discontinued_dm(self):
        """API should return 404 for discontinued (DM) material even with history."""
        discontinued = TestDataFactory.create_material(xplant_mat_stat='DM')
        TestDataFactory.create_material_value_at_risk_history(
            material=discontinued,
            status_date=self.today,
            dollars_at_risk_30_day=50000.0,
        )

        url = reverse(
            'material_value_at_risk_history:latest-material-value-at-risk',
            kwargs={'mat_nbr': discontinued.mat_nbr}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_get_latest_excludes_drop_ship(self):
        """API should return 404 for drop-ship material even with history."""
        drop_ship = TestDataFactory.create_material(drop_ship_flg=1)
        TestDataFactory.create_material_value_at_risk_history(
            material=drop_ship,
            status_date=self.today,
            dollars_at_risk_30_day=50000.0,
        )

        url = reverse(
            'material_value_at_risk_history:latest-material-value-at-risk',
            kwargs={'mat_nbr': drop_ship.mat_nbr}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_get_latest_excludes_short_date(self):
        """API should return 404 for short-date material even with history."""
        short_date = TestDataFactory.create_material(short_date_flg=1)
        TestDataFactory.create_material_value_at_risk_history(
            material=short_date,
            status_date=self.today,
            dollars_at_risk_30_day=50000.0,
        )

        url = reverse(
            'material_value_at_risk_history:latest-material-value-at-risk',
            kwargs={'mat_nbr': short_date.mat_nbr}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
