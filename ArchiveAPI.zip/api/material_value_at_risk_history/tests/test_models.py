from datetime import timedelta

from django.db import IntegrityError
from django.utils import timezone

from api.material_value_at_risk_history.models import MaterialValueAtRiskHistory
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class MaterialValueAtRiskHistoryModelTest(BaseTestCase):
    """Test cases for MaterialValueAtRiskHistory model."""

    def setUp(self):
        """Set up test data for material value at risk history model tests."""
        self.material = TestDataFactory.create_material()
        self.status_date = timezone.now().date()

    def test_material_value_at_risk_history_creation(self):
        """Test basic material value at risk history record creation."""
        history = TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=self.status_date,
            dollars_at_risk_30_day=50000.0
        )

        self.assertEqual(history.material, self.material)
        self.assertEqual(history.status_date, self.status_date)
        self.assertEqual(history.dollars_at_risk_30_day, 50000.0)
        self.assertIsNotNone(history.created_at)
        self.assertIsNotNone(history.updated_at)

    def test_unique_together_constraint(self):
        """Test that a material value at risk history record is unique for a given material and status_date."""
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=self.status_date
        )
        with self.assertRaises(IntegrityError):
            TestDataFactory.create_material_value_at_risk_history(
                material=self.material,
                status_date=self.status_date
            )

    def test_material_cascade_delete(self):
        """Test that deleting a material deletes its associated material value at risk history records."""
        history = TestDataFactory.create_material_value_at_risk_history(material=self.material)
        history_pk = history.pk
        self.material.delete()
        with self.assertRaises(MaterialValueAtRiskHistory.DoesNotExist):
            MaterialValueAtRiskHistory.objects.get(pk=history_pk)

    def test_different_materials_same_date(self):
        """Test that different materials can have records with the same status_date."""
        material2 = TestDataFactory.create_material()
        history1 = TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=self.status_date
        )
        history2 = TestDataFactory.create_material_value_at_risk_history(
            material=material2,
            status_date=self.status_date
        )

        self.assertIsNotNone(history1)
        self.assertIsNotNone(history2)
        self.assertEqual(history1.status_date, history2.status_date)
        self.assertNotEqual(history1.material, history2.material)

    def test_same_material_different_dates(self):
        """Test that the same material can have records with different status_dates."""
        date1 = self.status_date
        date2 = self.status_date - timedelta(days=1)

        history1 = TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=date1
        )
        history2 = TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=date2
        )

        self.assertIsNotNone(history1)
        self.assertIsNotNone(history2)
        self.assertEqual(history1.material, history2.material)
        self.assertNotEqual(history1.status_date, history2.status_date)
