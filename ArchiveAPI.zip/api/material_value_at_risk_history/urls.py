from django.urls import path

from api.material_value_at_risk_history.views import LatestMaterialValueAtRiskView

app_name = 'material_value_at_risk_history'

urlpatterns = [
    path('<str:mat_nbr>/latest/', LatestMaterialValueAtRiskView.as_view(), name='latest-material-value-at-risk'),
]
