from rest_framework import serializers

from api.material_value_at_risk_history.models import MaterialValueAtRiskHistory


class MaterialValueAtRiskHistorySerializer(serializers.ModelSerializer):
    """
    Serializer for material value at risk history.
    """
    material_nbr = serializers.CharField(source='material.mat_nbr', read_only=True)
    material_name = serializers.CharField(source='material.name', read_only=True)

    class Meta:
        model = MaterialValueAtRiskHistory
        fields = [
            'material_nbr',
            'material_name',
            'dollars_at_risk_30_day',
            'status_date',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ('created_at', 'updated_at')


class LatestMaterialValueAtRiskSerializer(serializers.Serializer):
    """
    Serializer for the latest material value at risk response.
    """
    material_nbr = serializers.CharField()
    material_name = serializers.CharField(required=False, allow_null=True)
    dollars_at_risk_30_day = serializers.FloatField(required=False, allow_null=True)
    status_date = serializers.DateField(required=False, allow_null=True)
