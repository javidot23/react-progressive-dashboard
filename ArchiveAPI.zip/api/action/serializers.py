from django.contrib.auth import get_user_model
from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from api.action.models import Action
from api.issue.models import Issue
from api.potential_action.serializers import PotentialActionSerializer


class ActionCreateSerializer(serializers.Serializer):
    """
    Serializer for creating new actions.
    Handles input validation at schema level only.
    """
    issue_nbr = serializers.CharField(max_length=255, help_text="Issue number")
    mat_nbr = serializers.CharField(
        max_length=255,
        required=False,
        allow_null=True,
        help_text="Single material to act on (back-compat; prefer mat_nbrs)"
    )
    mat_nbrs = serializers.ListField(
        child=serializers.CharField(max_length=255),
        required=False,
        allow_empty=False,
        help_text=(
            "Materials to act on. Omit to act on ALL materials of the issue's grain; "
            "provide a subset to act on only those."
        ),
    )
    potential_action_nbr = serializers.CharField(
        max_length=255,
        required=False,
        allow_null=True,
        help_text="Potential action number"
    )
    action = serializers.CharField(
        max_length=255,
        required=False,
        allow_null=True,
        help_text="Manual action (must be 'no_action' if no potential action provided)"
    )
    substituted_material_nbr = serializers.CharField(
        max_length=255,
        required=False,
        allow_null=True,
        help_text="Substituted material number"
    )
    material_risk_rating = serializers.FloatField(
        required=False,
        allow_null=True,
        help_text="Material risk rating (0.0-1.0)"
    )
    material_driving_risk = serializers.CharField(
        max_length=255,
        required=False,
        allow_null=True,
        allow_blank=True,
        help_text="Material driving risk category"
    )
    material_dollars_at_risk = serializers.FloatField(
        required=False,
        allow_null=True,
        help_text="Material dollars at risk value"
    )

    def validate(self, data):
        """
        Validate the action creation data at schema level.
        Business logic validation is handled in the service layer.
        """
        # If no potential action is provided, action must be "no_action"
        if not data.get('potential_action_nbr') and data.get('action') != "no_action":
            raise serializers.ValidationError({
                'action': "Action must be 'no_action' when no potential action is provided"
            })

        return data

    def get_material_context(self):
        """
        Build material_context JSON object from validated data.
        Only includes keys that were provided in the request.
        """
        material_keys = ['material_risk_rating', 'material_driving_risk', 'material_dollars_at_risk']
        return {
            key: self.validated_data[key]
            for key in material_keys
            if key in self.validated_data and self.validated_data[key] is not None
        }


class DecisionFeedbackSerializer(serializers.Serializer):
    """
    Serializer for updating decision feedback on an existing action.
    Supports partial updates - only provided fields are updated.
    """
    time_to_complete = serializers.CharField(
        max_length=255,
        required=False,
        allow_null=True,
        allow_blank=True,
        help_text="Time taken to complete the action (e.g., '< 1 hour', '1-2 hours', '2+ hours')"
    )
    decision_rationale = serializers.CharField(
        max_length=1000,
        required=False,
        allow_null=True,
        allow_blank=True,
        help_text="Rationale for the decision taken"
    )

    def validate(self, data):
        """
        Ensure at least one field is provided for update.
        """
        if not any(key in data for key in ['time_to_complete', 'decision_rationale']):
            raise serializers.ValidationError(
                "At least one of 'time_to_complete' or 'decision_rationale' must be provided"
            )
        return data

    def get_decision_feedback_update(self):
        """
        Build decision_feedback update dict from validated data.
        Only includes keys that were provided in the request.
        """
        update = {}
        if 'time_to_complete' in self.validated_data:
            update['time_to_complete'] = self.validated_data['time_to_complete']
        if 'decision_rationale' in self.validated_data:
            update['decision_rationale'] = self.validated_data['decision_rationale']
        return update


class ActionUserSerializer(serializers.Serializer):
    id = serializers.CharField()
    first_name = serializers.CharField()
    last_name = serializers.CharField()


class SubstitutedMaterialSerializer(serializers.Serializer):
    mat_nbr = serializers.CharField()
    name = serializers.CharField()
    vendor_name = serializers.CharField(allow_null=True)


class ActionSerializer(serializers.ModelSerializer):
    """
    Serializer for displaying action details.
    Handles response formatting only.
    """
    user = serializers.SerializerMethodField()
    potential_action = PotentialActionSerializer(read_only=True)
    substituted_material = serializers.SerializerMethodField()
    issue_nbr = serializers.CharField(source='issue.issue_nbr', read_only=True)
    material_number = serializers.SerializerMethodField()
    material_name = serializers.SerializerMethodField()
    vendor_name = serializers.SerializerMethodField()
    material_context = serializers.JSONField(read_only=True)
    decision_feedback = serializers.JSONField(read_only=True)
    user_info = serializers.JSONField(read_only=True)

    class Meta:
        model = Action
        fields = [
            'id',
            'issue_nbr',
            'user_id',
            'user',
            'created_at',
            'updated_at',
            'potential_action',
            'action',
            'substituted_material',
            'material_number',
            'material_name',
            'vendor_name',
            'material_context',
            'decision_feedback',
            'user_info',
        ]
        read_only_fields = ("created_at", "updated_at", "id")

    @staticmethod
    def _resolved_material(obj):
        """Material the action was taken on (falls back to issue anchor material)."""
        return obj.material or getattr(obj.issue, 'material', None)

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_material_number(self, obj):
        material = self._resolved_material(obj)
        return material.mat_nbr if material else None

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_material_name(self, obj):
        material = self._resolved_material(obj)
        return material.name if material else None

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_vendor_name(self, obj):
        material = self._resolved_material(obj)
        if material and material.vendor:
            return material.vendor.name
        return None

    @extend_schema_field(SubstitutedMaterialSerializer(allow_null=True))
    def get_substituted_material(self, obj):
        """Get substituted material details if available."""
        if obj.substituted_material:
            return {
                'mat_nbr': obj.substituted_material.mat_nbr,
                'name': obj.substituted_material.name,
                'vendor_name': obj.substituted_material.vendor.name if obj.substituted_material.vendor else None,
            }
        return None

    @extend_schema_field(ActionUserSerializer(allow_null=True))
    def get_user(self, obj):
        """Get user details with caching support."""
        if not obj.user_id:
            return None

        # Get user cache from context first
        user_cache = self.context.get('user_cache')

        if user_cache is not None:
            return user_cache.get(obj.user_id)

        # Fallback to individual query if no cache
        try:
            user = get_user_model().objects.only(
                "user_uuid", "first_name", "last_name"
            ).get(user_uuid=obj.user_id)
            return {
                "id": str(user.pk),
                "first_name": user.first_name,
                "last_name": user.last_name,
            }
        except get_user_model().DoesNotExist:
            return None


class ActionListSerializer(ActionSerializer):
    """
    Serializer for listing actions with additional fields for filtering.
    """
    action_type = serializers.CharField(source='potential_action.action_type', read_only=True)
    recommendation = serializers.CharField(source='potential_action.recommendation', read_only=True)
    module = serializers.CharField(source='potential_action.module', read_only=True)
    status = serializers.CharField(source='potential_action.status', read_only=True)

    class Meta(ActionSerializer.Meta):
        fields = ActionSerializer.Meta.fields + [
            'action_type',
            'recommendation',
            'module',
            'status',
        ]


class ActionHistoryIssueSerializer(serializers.ModelSerializer):
    """
    Compact issue representation for material action history responses.
    """
    material_number = serializers.CharField(source='material.mat_nbr', read_only=True)
    material_name = serializers.CharField(source='material.name', read_only=True)

    class Meta:
        model = Issue
        fields = [
            'id',
            'issue_nbr',
            'status',
            'start_date',
            'created_at',
            'updated_at',
            'material_number',
            'material_name',
        ]


class MaterialActionHistorySerializer(ActionSerializer):
    """
    Action representation for material-level history, including the issue.
    """
    issue = ActionHistoryIssueSerializer(read_only=True)

    class Meta(ActionSerializer.Meta):
        fields = ActionSerializer.Meta.fields + ['issue']
