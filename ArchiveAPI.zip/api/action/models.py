from django.db import models
from api.issue.models import Issue
from api.material.models import Material
from api.potential_action.models import PotentialAction


class Action(models.Model):
    issue = models.ForeignKey(
        Issue,
        to_field="issue_nbr",
        db_column="issue_nbr",
        on_delete=models.CASCADE,
        related_name="actions",
        verbose_name="Issue",
    )
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        related_name="actions",
        verbose_name="Material",
        null=True,
        blank=True,
        default=None,
    )
    potential_action = models.ForeignKey(
        PotentialAction,
        to_field="paction_nbr",
        db_column="paction_nbr",
        on_delete=models.CASCADE,
        related_name="actions",
        verbose_name="Potential Action",
        null=True,
        blank=True,
    )
    user_id = models.CharField(max_length=255, verbose_name="User ID")
    action = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        verbose_name="Action",
        help_text="Custom action taken by user (if different from potential action)",
    )
    substituted_material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="substituted_mat_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        verbose_name="Substituted Material",
    )
    material_context = models.JSONField(
        default=dict,
        blank=True,
        verbose_name="Material Context",
        help_text="Stores material risk data: material_risk_rating, material_driving_risk, material_dollars_at_risk",
    )
    decision_feedback = models.JSONField(
        default=dict,
        blank=True,
        verbose_name="Decision Feedback",
        help_text="Stores user decision feedback: time_to_complete, decision_rationale",
    )
    user_info = models.JSONField(
        default=dict,
        blank=True,
        verbose_name="User Info",
        help_text="Stores user identity from auth token: first_name, last_name, email, role",
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Updated At")

    class Meta:
        db_table = "actions"
        verbose_name = "Action"
        verbose_name_plural = "Actions"
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["issue", "potential_action"]),
            models.Index(fields=["material"]),
            models.Index(fields=["user_id"]),
            models.Index(fields=["created_at"]),
            models.Index(fields=["updated_at"]),
        ]

    def save(self, *args, **kwargs):
        if self.issue_id and self.material_id is None:
            self.material = self.issue.material
        super().save(*args, **kwargs)
