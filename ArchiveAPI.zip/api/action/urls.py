from django.urls import path

from api.action.views import (
    ActionCreateView,
    ActionListView,
    ActionDetailView,
    ActionExportView,
    DecisionFeedbackView,
    MaterialActionHistoryView,
)

app_name = 'action'

urlpatterns = [
    path('', ActionListView.as_view(), name='action-list'),
    path('create/', ActionCreateView.as_view(), name='action-create'),
    path('export/', ActionExportView.as_view(), name='action-export'),
    path('material/<str:mat_nbr>/', MaterialActionHistoryView.as_view(), name='material-action-history'),
    path('<int:id>/', ActionDetailView.as_view(), name='action-detail'),
    path('<int:action_id>/decision-feedback/', DecisionFeedbackView.as_view(), name='action-decision-feedback'),
]
