import csv
import logging
from datetime import datetime

from django.http import HttpResponse
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, status
from rest_framework.exceptions import PermissionDenied, ValidationError, NotFound
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import extend_schema

from api.action.filters import ActionFilter
from api.action.models import Action
from api.action.serializers import (
    ActionCreateSerializer,
    ActionListSerializer,
    ActionSerializer,
    DecisionFeedbackSerializer,
    MaterialActionHistorySerializer,
)
from api.action.services import ActionService
from api.audit.choices import AuditEventType
from api.audit.services import AuditService

logger = logging.getLogger(__name__)


class ActionCreateView(generics.CreateAPIView):
    """
    Create a new action for a given issue.
    Handles both potential actions and manual actions.
    """
    serializer_class = ActionCreateSerializer

    def _extract_user_info(self, request):
        """
        Extract user info from the authenticated user/token claims.
        Returns a dict with first_name, last_name, email, and role (if available).
        """
        user = request.user
        user_info = {}

        if hasattr(user, 'first_name') and user.first_name:
            user_info['first_name'] = user.first_name
        if hasattr(user, 'last_name') and user.last_name:
            user_info['last_name'] = user.last_name
        if hasattr(user, 'email') and user.email:
            user_info['email'] = user.email

        claims = getattr(user, '_entra_claims', None) or getattr(user, '_sap_cdc_claims', None)
        if claims:
            roles = claims.get('roles')
            if roles and isinstance(roles, (list, tuple)) and len(roles) > 0:
                user_info['role'] = roles[0]
            elif claims.get('scp'):
                user_info['role'] = claims.get('scp')

        return user_info

    def create(self, request, *args, **kwargs):
        """
        Create a new action using the service layer.
        """
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user_id = str(getattr(request.user, 'pk', '') or '') or None

        if not user_id:
            logger.warning("No user ID found in request")
            raise PermissionDenied

        try:
            # Extract material context from serializer
            material_context = serializer.get_material_context()

            # Extract user info from auth context (NOT from request body)
            user_info = self._extract_user_info(request)

            mat_nbrs = serializer.validated_data.get('mat_nbrs')
            if not mat_nbrs and serializer.validated_data.get('mat_nbr'):
                mat_nbrs = [serializer.validated_data['mat_nbr']]

            result = ActionService.create_actions_for_issue(
                issue_nbr=serializer.validated_data['issue_nbr'],
                user_id=user_id,
                mat_nbrs=mat_nbrs,
                potential_action_nbr=serializer.validated_data.get('potential_action_nbr'),
                action=serializer.validated_data.get('action'),
                substituted_material_nbr=serializer.validated_data.get('substituted_material_nbr'),
                material_context=material_context,
                user_info=user_info,
            )

            created_actions = result['created']
            user_cache = ActionService.get_user_cache_for_actions(created_actions)
            response_serializer = ActionSerializer(
                created_actions, many=True, context={'user_cache': user_cache}
            )
            if created_actions:
                AuditService.record_from_request(
                    request,
                    AuditEventType.ACTION_CREATED,
                    status=status.HTTP_201_CREATED,
                    target_entity={
                        "type": "issue",
                        "id": serializer.validated_data["issue_nbr"],
                    },
                    action={
                        "action_ids": [a.id for a in created_actions],
                        "count": len(created_actions),
                    },
                )
            return Response(
                {'created': response_serializer.data, 'skipped': result['skipped']},
                status=status.HTTP_201_CREATED,
            )

        except ValueError as e:
            logger.warning("Validation error creating action: %s", str(e))
            raise ValidationError(
                {"error": "Invalid request while creating action."},
                code="invalid_request"
            )
        except Exception as e:
            logger.error("Unexpected error creating action: %s", str(e))
            raise ValidationError(
                {"error": "An unexpected error occurred while creating the action."},
                code="server_error"
            )


class ActionListView(generics.ListAPIView):
    """
    List all actions with comprehensive filtering and ordering.
    """
    serializer_class = ActionListSerializer
    filterset_class = ActionFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = [
        'created_at',
        'updated_at',
        'issue__issue_nbr',
        'material__mat_nbr',
        'material__name',
        'material__risk_rating',
        'material__dollars_at_risk',
        'potential_action__action_type',
        'potential_action__recommendation',
        'potential_action__module',
        'potential_action__status',
        'user_id',
    ]
    ordering = ['-created_at']

    def get_queryset(self):
        """Get optimized queryset for actions."""
        if getattr(self, "swagger_fake_view", False):
            return Action.objects.none()
        user_id = str(getattr(self.request.user, 'pk', '') or '') or None
        if not user_id:
            logger.warning("Unauthorized access attempt to ActionListView")
            raise PermissionDenied
        return ActionService.get_actions_queryset(user_id)

    def list(self, request, *args, **kwargs):
        """
        List actions with user caching to avoid N+1 queries.
        """
        # Get filtered queryset
        queryset = self.filter_queryset(self.get_queryset())

        # Log query execution
        logger.info(
            "Listing actions with filters: %s, ordering: %s",
            request.query_params,
            request.query_params.get('ordering', self.ordering)
        )

        # Paginate if needed
        page = self.paginate_queryset(queryset)
        if page is not None:
            user_cache = ActionService.get_user_cache_for_actions(page)
            serializer = self.get_serializer(page, many=True, context={'user_cache': user_cache})
            return self.get_paginated_response(serializer.data)

        # No pagination
        user_cache = ActionService.get_user_cache_for_actions(queryset)
        serializer = self.get_serializer(queryset, many=True, context={'user_cache': user_cache})
        return Response(serializer.data)


class ActionExportView(APIView):
    """
    Export actions as CSV with streaming for large datasets.
    """

    @extend_schema(responses={(200, 'text/csv'): OpenApiTypes.BINARY})
    def get(self, request):
        """
        Export actions to CSV format with filtering support.
        Requires date range parameters with max 1 month range.
        """
        logger.info("Starting CSV export with filters: %s", request.query_params)

        user_id = str(getattr(request.user, 'pk', '') or '') or None
        if not user_id:
            logger.warning("Unauthorized access attempt to ActionExportView")
            raise PermissionDenied

        # Validate date range parameters
        created_at_after = request.query_params.get('created_at_after')
        created_at_before = request.query_params.get('created_at_before')

        if not created_at_after or not created_at_before:
            raise ValidationError({
                'error': 'Both created_at_after and created_at_before parameters are required'
            })

        try:
            date_after = datetime.fromisoformat(created_at_after.replace('Z', '+00:00'))
            date_before = datetime.fromisoformat(created_at_before.replace('Z', '+00:00'))
        except (ValueError, AttributeError):
            raise ValidationError({
                'error': 'Invalid date format. Use ISO format (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)'
            })

        # Validate date range is not more than 1 month (31 days)
        date_difference = date_before - date_after
        if date_difference.days > 31:
            raise ValidationError({
                'error': 'Date range cannot exceed 31 days. Please select a shorter timeframe.'
            })

        if date_difference.days < 0:
            raise ValidationError({
                'error': 'created_at_before must be after created_at_after'
            })

        # Get filtered queryset using the same filters as list view
        queryset = ActionService.get_actions_queryset(user_id)

        # Apply filters
        filterset = ActionFilter(request.query_params, queryset=queryset)
        filtered_queryset = filterset.qs

        # Apply ordering
        ordering = request.query_params.get('ordering', '-created_at')
        if ordering:
            filtered_queryset = filtered_queryset.order_by(ordering)

        # Generate CSV filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"actions_export_{timestamp}.csv"

        # Create streaming response
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename="{filename}"'

        # Write CSV header
        writer = csv.writer(response)
        writer.writerow([
            'Action ID',
            'Issue Number',
            'User ID',
            'Created At',
            'Potential Action Number',
            'Action Type',
            'Recommendation',
            'Module',
            'Status',
            'Manual Action',
            'Material Number',
            'Material Name',
            'Vendor Name',
            'Substituted Material Number',
            'Substituted Material Name',
            'Substituted Vendor Name',
        ])

        # Stream data in chunks to avoid memory issues
        chunk_size = 1000
        total_count = 0

        for action in filtered_queryset.iterator(chunk_size=chunk_size):
            writer.writerow([
                action.id,
                action.issue.issue_nbr,
                action.user_id,
                action.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                action.potential_action.paction_nbr if action.potential_action else '',
                action.potential_action.action_type if action.potential_action else '',
                action.potential_action.recommendation if action.potential_action else '',
                action.potential_action.module if action.potential_action else '',
                action.potential_action.status if action.potential_action else '',
                action.action or '',
                (
                    action.material.mat_nbr if action.material
                    else (action.issue.material.mat_nbr if action.issue.material else '')
                ),
                (
                    action.material.name if action.material
                    else (action.issue.material.name if action.issue.material else '')
                ) or '',
                (
                    action.material.vendor.name
                    if action.material and action.material.vendor
                    else (
                        action.issue.material.vendor.name
                        if action.issue.material and action.issue.material.vendor
                        else ''
                    )
                ),
                action.substituted_material.mat_nbr if action.substituted_material else '',
                action.substituted_material.name if action.substituted_material else '',
                action.substituted_material.vendor.name if action.substituted_material else '',
            ])
            total_count += 1

        logger.info("Successfully exported %s actions to CSV", total_count)
        return response


class MaterialActionHistoryView(generics.ListAPIView):
    """
    List all actions taken for a material across users.
    """
    serializer_class = MaterialActionHistorySerializer

    def get_queryset(self):
        return ActionService.get_material_action_history(self.kwargs['mat_nbr'])

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            user_cache = ActionService.get_user_cache_for_actions(page)
            serializer = self.get_serializer(
                page,
                many=True,
                context={'user_cache': user_cache}
            )
            return self.get_paginated_response(serializer.data)

        user_cache = ActionService.get_user_cache_for_actions(queryset)
        serializer = self.get_serializer(
            queryset,
            many=True,
            context={'user_cache': user_cache}
        )
        return Response(serializer.data)


class ActionDetailView(generics.RetrieveDestroyAPIView):
    """
    Retrieve or delete an action by ID.

    Delete removes the full decision group (all material-level rows for the same
    issue, potential action, and user), not just the requested row.
    """
    serializer_class = ActionSerializer
    lookup_field = 'id'

    def get_queryset(self):
        """Get optimized queryset for single action."""
        user_id = str(getattr(self.request.user, 'pk', '') or '') or None
        if not user_id:
            logger.warning("Unauthorized access attempt to ActionListView")
            raise PermissionDenied
        return ActionService.get_actions_queryset(user_id)

    def retrieve(self, request, *args, **kwargs):
        """
        Retrieve action with user caching.
        """
        action = self.get_object()
        user_cache = ActionService.get_user_cache_for_actions([action])
        serializer = self.get_serializer(action, context={'user_cache': user_cache})
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        try:
            result = ActionService.delete_action_by_id(
                action_id=self.kwargs.get(self.lookup_field),
                user_id=str(request.user.pk),
            )
            deleted_actions = result['deleted']
            user_cache = ActionService.get_user_cache_for_actions(deleted_actions)
            serializer = self.get_serializer(
                deleted_actions,
                many=True,
                context={'user_cache': user_cache},
            )
            AuditService.record_from_request(
                request,
                AuditEventType.ACTION_DELETED,
                status=status.HTTP_200_OK,
                target_entity={
                    "type": "action",
                    "id": str(self.kwargs.get(self.lookup_field)),
                },
                action={
                    "action_ids": [a.id for a in deleted_actions],
                    "count": result["count"],
                },
            )
            return Response(
                {'deleted': serializer.data, 'count': result['count']},
            )
        except PermissionError as exc:
            logger.warning("Permission error deleting action: %s", str(exc))
            raise PermissionDenied("You do not have permission to delete this action.") from exc
        except ValueError as e:
            logger.warning("Validation error deleting action: %s", str(e))
            raise ValidationError(
                {"error": "Action not found"},
                code="invalid_request"
            )
        except Exception as e:
            logger.error("Unexpected error deleting action: %s", str(e))
            raise ValidationError(
                {"error": "An unexpected error occurred while deleting the action."},
                code="server_error"
            )


class DecisionFeedbackView(APIView):
    """
    Update decision feedback on an existing action.
    PATCH /action/<action_id>/decision-feedback/

    Accepts:
        - time_to_complete: string (e.g., "< 1 hour", "1-2 hours", "2+ hours")
        - decision_rationale: string (e.g., "This aligns with our standard business process")

    Supports partial updates - only provided fields are updated.
    Merges with existing decision_feedback without overwriting other keys.
    """

    @extend_schema(
        request=DecisionFeedbackSerializer,
        responses=ActionSerializer,
    )
    def patch(self, request, action_id):
        """
        Update decision feedback for the specified action.
        """
        user_id = str(getattr(request.user, 'pk', '') or '') or None

        if not user_id:
            logger.warning("No user ID found in request for decision feedback update")
            raise PermissionDenied

        serializer = DecisionFeedbackSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            feedback_update = serializer.get_decision_feedback_update()

            action = ActionService.update_decision_feedback(
                action_id=action_id,
                feedback_update=feedback_update,
                user_id=user_id
            )

            AuditService.record_from_request(
                request,
                AuditEventType.ACTION_UPDATED,
                status=status.HTTP_200_OK,
                target_entity={"type": "action", "id": str(action.id)},
                metadata={"via": "decision_feedback"},
            )
            response_serializer = ActionSerializer(action)
            return Response(response_serializer.data, status=status.HTTP_200_OK)

        except ValueError as e:
            logger.warning("Validation error updating decision feedback: %s", str(e))
            raise NotFound({"error": "Action not found."})
        except PermissionError as e:
            logger.warning("Permission error updating decision feedback: %s", str(e))
            raise PermissionDenied("You do not have permission to update this action.")
        except Exception as e:
            logger.error("Unexpected error updating decision feedback: %s", str(e))
            raise ValidationError(
                {"error": "An unexpected error occurred while updating the decision feedback."},
                code="server_error"
            )
