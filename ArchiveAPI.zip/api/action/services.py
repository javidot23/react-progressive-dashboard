import logging
from typing import Optional, Dict, Any, List

from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import QuerySet

from api.action.models import Action
from api.issue.models import Issue
from api.material.models import Material
from api.potential_action.models import PotentialAction

logger = logging.getLogger(__name__)


class ActionService:
    """
    Service class for handling actions in the supply chain.
    Contains all business logic, validation, and model interaction for actions.
    """

    @classmethod
    def create_action(
        cls,
        issue_nbr: str,
        mat_nbr: str,
        user_id: str,
        potential_action_nbr: Optional[str] = None,
        action: Optional[str] = None,
        substituted_material_nbr: Optional[str] = None,
        material_context: Optional[Dict[str, Any]] = None,
        user_info: Optional[Dict[str, Any]] = None
    ) -> Action:
        """
        Create a new action for a given issue.

        Args:
            issue_nbr: The issue number
            mat_nbr: The material number
            user_id: The user ID taking the action
            potential_action_nbr: Optional potential action number
            action: Optional manual action (must be "no_action" if no potential action)
            substituted_material_nbr: Optional substituted material number
            material_context: Optional dict with material risk data
                (material_risk_rating, material_driving_risk, material_dollars_at_risk)
            user_info: Optional dict with user identity from auth token
                (first_name, last_name, email, role)

        Returns:
            The created Action instance

        Raises:
            ValueError: If validation fails
            Action.DoesNotExist: If related objects don't exist
        """
        logger.info(
            "Creating action for issue %s by user %s",
            issue_nbr, user_id
        )

        try:
            issue = Issue.objects.select_related(
                'material',
                'material__vendor'
            ).get(issue_nbr=issue_nbr, material=mat_nbr)
        except Issue.DoesNotExist:
            logger.warning("Issue %s not found", issue_nbr)
            raise ValueError(f"Issue {issue_nbr} not found")

        # Validate potential action if provided
        potential_action = None
        if potential_action_nbr:
            try:
                potential_action = PotentialAction.objects.get(
                    paction_nbr=potential_action_nbr,
                    issue_nbr=issue_nbr,
                )
            except PotentialAction.DoesNotExist:
                logger.warning(
                    "Potential action %s not found for issue %s",
                    potential_action_nbr, issue_nbr
                )
                raise ValueError(
                    f"Potential action {potential_action_nbr} not found for issue {issue_nbr}"
                )

        # Validate substituted material if provided
        substituted_material = None
        if substituted_material_nbr:
            try:
                substituted_material = Material.objects.select_related(
                    'vendor'
                ).get(mat_nbr=substituted_material_nbr)
            except Material.DoesNotExist:
                logger.warning("Substituted material %s not found", substituted_material_nbr)
                raise ValueError(f"Substituted material {substituted_material_nbr} not found")

            # Validate that substituted material is different from issue material
            if substituted_material.mat_nbr == issue.material.mat_nbr:
                logger.warning(
                    "Substituted material %s is same as issue material",
                    substituted_material_nbr
                )
                raise ValueError(
                    "Substituted material must be different from the issue material"
                )

        # Validate action field
        if not potential_action and action != "no_action":
            logger.warning(
                "Action must be 'no_action' when no potential action provided. Got: %s",
                action
            )
            raise ValueError("Action must be 'no_action' when no potential action is provided")

        if potential_action:
            existing_action = Action.objects.filter(
                issue=issue,
                potential_action=potential_action
            ).first()

            if existing_action:
                logger.warning(
                    "Potential action %s already taken for issue %s",
                    potential_action_nbr, issue_nbr
                )
                raise ValueError(
                    f"Potential action {potential_action_nbr} has already been taken for this issue"
                )

        if (
            potential_action
            and potential_action.recommendation_type_nbr == "31"
            and not substituted_material
        ):
            logger.warning(
                "Substituted material required for potential action %s",
                potential_action_nbr
            )
            raise ValueError(
                "Substituted material is required for 'Substitute with alternate product' recommendations"
            )

        try:
            with transaction.atomic():
                action_obj = Action.objects.create(
                    issue=issue,
                    user_id=user_id,
                    potential_action=potential_action,
                    action=action,
                    substituted_material=substituted_material,
                    material_context=material_context or {},
                    user_info=user_info or {}
                )

                logger.info(
                    "Successfully created action %s for issue %s by user %s",
                    action_obj.id, issue_nbr, user_id
                )

                return action_obj

        except Exception as e:
            logger.error(
                "Failed to create action for issue %s by user %s: %s",
                issue_nbr, user_id, str(e)
            )
            raise

    @classmethod
    def create_actions_for_issue(
        cls,
        issue_nbr: str,
        user_id: str,
        mat_nbrs: Optional[List[str]] = None,
        potential_action_nbr: Optional[str] = None,
        action: Optional[str] = None,
        substituted_material_nbr: Optional[str] = None,
        material_context: Optional[Dict[str, Any]] = None,
        user_info: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Take an action on an issue, fanning out to one Action per material.

        The issue is identified by ``issue_nbr`` (unique). Targets are resolved from
        the issue's grain (``materials_for_issue``); when ``mat_nbrs`` is given the
        targets are restricted to that subset (which must be part of the grain).
        Materials that already have this (issue, potential_action) action are skipped.

        Returns ``{"created": [Action, ...], "skipped": int}``.

        Raises ValueError on validation failure (the view maps these to HTTP 422).
        """
        from api.issue.granularity import materials_for_issue

        logger.info("Creating actions for issue %s by user %s", issue_nbr, user_id)

        try:
            issue = Issue.objects.select_related('material', 'material__vendor').get(
                issue_nbr=issue_nbr
            )
        except Issue.DoesNotExist:
            logger.warning("Issue %s not found", issue_nbr)
            raise ValueError(f"Issue {issue_nbr} not found")

        target_qs = materials_for_issue(issue)
        if mat_nbrs:
            target_qs = target_qs.filter(mat_nbr__in=mat_nbrs)
        materials = list(target_qs.select_related('vendor'))

        if mat_nbrs:
            found = {m.mat_nbr for m in materials}
            missing = [nbr for nbr in mat_nbrs if nbr not in found]
            if missing:
                raise ValueError(
                    f"Materials not part of this issue's grain: {', '.join(missing)}"
                )

        if not materials:
            raise ValueError(
                "No materials could be resolved for this issue's granularity"
            )

        potential_action = None
        if potential_action_nbr:
            try:
                potential_action = PotentialAction.objects.get(
                    paction_nbr=potential_action_nbr,
                    issue_nbr=issue_nbr,
                )
            except PotentialAction.DoesNotExist:
                raise ValueError(
                    f"Potential action {potential_action_nbr} not found for issue {issue_nbr}"
                )

        if not potential_action and action != "no_action":
            raise ValueError("Action must be 'no_action' when no potential action is provided")

        if potential_action and not action:
            action = potential_action.recommendation

        substituted_material = None
        if substituted_material_nbr:
            if len(materials) != 1:
                raise ValueError(
                    "Substituted material can only be set when acting on a single material"
                )
            try:
                substituted_material = Material.objects.select_related('vendor').get(
                    mat_nbr=substituted_material_nbr
                )
            except Material.DoesNotExist:
                raise ValueError(f"Substituted material {substituted_material_nbr} not found")
            if substituted_material.mat_nbr == materials[0].mat_nbr:
                raise ValueError("Substituted material must be different from the issue material")

        if (
            potential_action
            and potential_action.recommendation_type_nbr == "31"
            and not substituted_material
        ):
            raise ValueError(
                "Substituted material is required for 'Substitute with alternate product' recommendations"
            )

        existing_filter = {'issue': issue, 'material__in': materials}
        if potential_action:
            existing_filter['potential_action'] = potential_action
        else:
            existing_filter['potential_action__isnull'] = True
            existing_filter['action'] = action
        already_actioned = set(
            Action.objects.filter(**existing_filter).values_list('material_id', flat=True)
        )

        to_create = [
            Action(
                issue=issue,
                material=material,
                user_id=user_id,
                potential_action=potential_action,
                action=action,
                substituted_material=substituted_material,
                material_context=material_context or {},
                user_info=user_info or {},
            )
            for material in materials
            if material.mat_nbr not in already_actioned
        ]

        with transaction.atomic():
            created = Action.objects.bulk_create(to_create)
        skipped = len(materials) - len(created)

        logger.info(
            "Issue %s: created %s action(s), skipped %s by user %s",
            issue_nbr, len(created), skipped, user_id
        )
        return {"created": created, "skipped": skipped}

    @classmethod
    def get_actions_queryset(cls, user_id: str) -> QuerySet:
        """
        Get optimized queryset for actions with all related data.

        Returns:
            Optimized QuerySet with select_related and prefetch_related
        """
        return (Action.objects.select_related(
            'issue',
            'issue__material',
            'issue__material__vendor',
            'material',
            'material__vendor',
            'potential_action',
            'substituted_material',
            'substituted_material__vendor'
        ).filter(user_id=user_id).order_by('-created_at'))

    @classmethod
    def get_actions_by_issue(cls, issue_nbr: str, user_id: str) -> QuerySet:
        """
        Retrieve all actions associated with a specific issue.

        Args:
            issue_nbr: The issue number
            user_id: The user ID

        Returns:
            QuerySet of actions for the issue
        """
        logger.info("Getting actions for issue %s", issue_nbr)
        return cls.get_actions_queryset(user_id).filter(issue__issue_nbr=issue_nbr)

    @classmethod
    def get_actions_by_user(cls, user_id: str) -> QuerySet:
        """
        Retrieve all actions associated with a specific user.

        Args:
            user_id: The user ID

        Returns:
            QuerySet of actions by the user
        """
        logger.info("Getting actions for user %s", user_id)
        return cls.get_actions_queryset(user_id)

    @staticmethod
    def _sibling_actions_for_delete(anchor: Action) -> QuerySet:
        """Actions in the same decision group as ``anchor`` (issue + potential_action + user)."""
        qs = Action.objects.filter(issue_id=anchor.issue_id, user_id=anchor.user_id)
        if anchor.potential_action_id:
            qs = qs.filter(potential_action_id=anchor.potential_action_id)
        else:
            qs = qs.filter(potential_action__isnull=True, action=anchor.action)
        return qs.select_related(
            'issue',
            'issue__material',
            'issue__material__vendor',
            'potential_action',
            'material',
            'material__vendor',
            'substituted_material',
            'substituted_material__vendor',
        )

    @classmethod
    def delete_action_by_id(cls, action_id: int, user_id: str) -> Dict[str, Any]:
        """Delete an action and all sibling material-level rows for the same decision.

        Siblings share the same issue, potential action (or manual action text when
        no potential action), and user. Returns ``{"deleted": [Action, ...], "count": int}``.
        """
        if not user_id:
            raise PermissionError("User not authenticated")

        try:
            anchor = Action.objects.get(id=action_id)
        except Action.DoesNotExist as exc:
            raise ValueError("Action not found") from exc

        if anchor.user_id != user_id:
            raise PermissionError("You can only delete actions you have taken")

        siblings = list(cls._sibling_actions_for_delete(anchor))
        with transaction.atomic():
            Action.objects.filter(id__in=[a.id for a in siblings]).delete()

        logger.info(
            "Deleted %s action(s) for issue %s by user %s",
            len(siblings), anchor.issue_id, user_id,
        )
        return {"deleted": siblings, "count": len(siblings)}

    @classmethod
    def update_decision_feedback(
        cls,
        action_id: int,
        feedback_update: Dict[str, Any],
        user_id: str
    ) -> Action:
        """
        Update decision feedback on an existing action.
        Merges the provided feedback with existing decision_feedback JSON field.

        Args:
            action_id: The action ID to update
            feedback_update: Dict with feedback fields to update
                (time_to_complete, decision_rationale)
            user_id: The user ID performing the update (for permission check)

        Returns:
            The updated Action instance

        Raises:
            ValueError: If action not found
            PermissionError: If user doesn't own the action
        """
        if not user_id:
            raise PermissionError("User not authenticated")

        try:
            action = Action.objects.select_related(
                'issue',
                'issue__material',
                'issue__material__vendor',
                'material',
                'material__vendor',
                'potential_action',
                'substituted_material',
                'substituted_material__vendor'
            ).get(id=action_id)
        except Action.DoesNotExist as exc:
            raise ValueError("Action not found") from exc

        # Verify user owns this action
        if action.user_id != user_id:
            raise PermissionError("You can only update feedback for actions you have taken")

        # Merge feedback update with existing decision_feedback
        existing_feedback = action.decision_feedback or {}
        existing_feedback.update(feedback_update)
        action.decision_feedback = existing_feedback
        action.save(update_fields=['decision_feedback', 'updated_at'])

        logger.info(
            "Updated decision feedback for action %s by user %s",
            action_id, user_id
        )

        return action

    @classmethod
    def get_actions_for_material(cls, material_nbr: str, user_id: str) -> QuerySet:
        """
        Retrieve all actions associated with a specific material.

        Args:
            material_nbr: The material number
            user_id: The user ID

        Returns:
            QuerySet of actions for the material
        """
        logger.info("Getting actions for material %s", material_nbr)
        return cls.get_actions_queryset(user_id).filter(material__mat_nbr=material_nbr)

    @classmethod
    def get_material_action_history(cls, mat_nbr: str) -> QuerySet:
        """
        Retrieve all actions taken for a material, regardless of action owner.

        This powers material-level history views, so it intentionally does
        not use the current-user scoped action queryset.
        """
        logger.info("Getting action history for material %s", mat_nbr)
        return (
            Action.objects.select_related(
                'issue',
                'issue__material',
                'issue__material__vendor',
                'material',
                'material__vendor',
                'potential_action',
                'substituted_material',
                'substituted_material__vendor',
            )
            .filter(material__mat_nbr=mat_nbr)
            .order_by('-created_at')
        )

    @classmethod
    def get_user_cache_for_actions(cls, actions: List[Action]) -> Dict[str, Dict[str, Any]]:
        """
        Get user cache for a list of actions to avoid N+1 queries.

        Args:
            actions: List of Action instances

        Returns:
            Dictionary mapping user_id to user data
        """
        all_user_ids = set()
        for action in actions:
            if action.user_id:
                all_user_ids.add(action.user_id)

        if all_user_ids:
            users = get_user_model().objects.only(
                "user_uuid", "first_name", "last_name"
            ).filter(user_uuid__in=all_user_ids)
            user_cache = {
                str(user.pk): {
                    "id": str(user.pk),
                    "first_name": user.first_name,
                    "last_name": user.last_name,
                }
                for user in users
            }
        else:
            user_cache = {}

        logger.info("Built user cache for %s users", len(user_cache))
        return user_cache

    @classmethod
    def export_actions_to_csv_data(cls, queryset: QuerySet) -> List[Dict[str, Any]]:
        """
        Convert actions queryset to CSV-ready data.

        Args:
            queryset: Filtered actions queryset

        Returns:
            List of dictionaries with CSV data
        """
        logger.info("Exporting %s actions to CSV format", queryset.count())

        csv_data = []
        for action in queryset.iterator():
            csv_data.append({
                'action_id': action.id,
                'issue_nbr': action.issue.issue_nbr,
                'user_id': action.user_id,
                'created_at': action.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'potential_action_number': action.potential_action.paction_nbr if action.potential_action else '',
                'action_type': action.potential_action.action_type if action.potential_action else '',
                'recommendation': action.potential_action.recommendation if action.potential_action else '',
                'module': action.potential_action.module if action.potential_action else '',
                'status': action.potential_action.status if action.potential_action else '',
                'manual_action': action.action or '',
                'material_number': (
                    action.material.mat_nbr if action.material
                    else (action.issue.material.mat_nbr if action.issue.material else '')
                ),
                'material_name': (
                    action.material.name if action.material
                    else (action.issue.material.name if action.issue.material else '')
                ) or '',
                'vendor_name': (
                    action.material.vendor.name if action.material and action.material.vendor
                    else (
                        action.issue.material.vendor.name
                        if action.issue.material and action.issue.material.vendor
                        else ''
                    )
                ),
                'substituted_material_number':
                    action.substituted_material.mat_nbr if action.substituted_material else '',
                'substituted_material_name':
                    action.substituted_material.name if action.substituted_material else '',
                'substituted_vendor_name':
                    action.substituted_material.vendor.name if action.substituted_material else '',
            })

        logger.info("Successfully exported %s actions to CSV format", len(csv_data))
        return csv_data
