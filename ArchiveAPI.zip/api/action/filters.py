from django.db.models import Q
from django_filters.rest_framework import FilterSet, filters

from api.action.models import Action


class ActionFilter(FilterSet):
    """
    Comprehensive filter set for actions with support for global filters through action material.
    Provides filtering capabilities for all major action attributes.
    Note: Material filters use the action's ``material`` FK (the material the action was taken on).
    For global filters, use the format: material__<field_name>
    """
    id = filters.NumberFilter(field_name='id', lookup_expr='exact')
    # Issue filtering
    issue_nbr = filters.CharFilter(field_name='issue__issue_nbr', lookup_expr='exact')

    # Potential action filtering
    potential_action_nbr = filters.CharFilter(field_name='potential_action__paction_nbr', lookup_expr='exact')

    # Action type filtering
    action_type = filters.CharFilter(field_name='potential_action__action_type', lookup_expr='exact')
    action_type_contains = filters.CharFilter(field_name='potential_action__action_type', lookup_expr='icontains')

    # Module filtering
    module = filters.CharFilter(field_name='potential_action__module', lookup_expr='exact')
    module_contains = filters.CharFilter(field_name='potential_action__module', lookup_expr='icontains')

    # Recommendation filtering
    recommendation = filters.CharFilter(field_name='potential_action__recommendation', lookup_expr='exact')
    recommendation_contains = filters.CharFilter(field_name='potential_action__recommendation', lookup_expr='icontains')

    # Status filtering
    status = filters.CharFilter(field_name='potential_action__status', lookup_expr='exact')
    status_contains = filters.CharFilter(field_name='potential_action__status', lookup_expr='icontains')

    # Manual action filtering
    manual_action = filters.CharFilter(field_name='action', lookup_expr='exact')
    manual_action_contains = filters.CharFilter(field_name='action', lookup_expr='icontains')

    # Material filtering
    material_nbr = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='exact')
    material_number = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='icontains')
    material_name = filters.CharFilter(field_name='material__name', lookup_expr='icontains')

    # Vendor filtering
    vendor_name = filters.CharFilter(field_name='material__vendor__name', lookup_expr='icontains')
    vendor_nbr = filters.CharFilter(field_name='material__vendor__vendor_nbr', lookup_expr='exact')

    # Global filters - Material fields on the action's material
    material__product_family = filters.CharFilter(lookup_expr='icontains')
    material__hic3_therapy_class = filters.CharFilter(lookup_expr='icontains')
    material__buyer_name = filters.CharFilter(lookup_expr='icontains')
    material__buyer_cd = filters.CharFilter(lookup_expr='exact')
    material__cat_mgr_name = filters.CharFilter(lookup_expr='icontains')
    material__cat_mgr_nbr = filters.CharFilter(lookup_expr='exact')
    material__fdb_gcn_seq_nbr = filters.CharFilter(lookup_expr='icontains')
    material__materialformulary__parent_program = filters.CharFilter(lookup_expr='icontains')

    # Substituted material filtering
    substituted_material_nbr = filters.CharFilter(field_name='substituted_material__mat_nbr', lookup_expr='exact')
    substituted_material_number = filters.CharFilter(field_name='substituted_material__mat_nbr',
                                                     lookup_expr='icontains')
    substituted_material_name = filters.CharFilter(field_name='substituted_material__name', lookup_expr='icontains')

    # Date range filtering
    created_at_after = filters.DateTimeFilter(field_name='created_at', lookup_expr='gte')
    created_at_before = filters.DateTimeFilter(field_name='created_at', lookup_expr='lte')
    created_at_date = filters.DateFilter(field_name='created_at__date', lookup_expr='exact')

    updated_at_after = filters.DateTimeFilter(field_name='updated_at', lookup_expr='gte')
    updated_at_before = filters.DateTimeFilter(field_name='updated_at', lookup_expr='lte')
    updated_at_date = filters.DateFilter(field_name='updated_at__date', lookup_expr='exact')

    # Risk rating filtering
    risk_rating = filters.NumberFilter(field_name='material__risk_rating')
    risk_rating_min = filters.NumberFilter(field_name='material__risk_rating', lookup_expr='gte')
    risk_rating_max = filters.NumberFilter(field_name='material__risk_rating', lookup_expr='lte')

    # Dollars at risk filtering
    dollars_at_risk = filters.NumberFilter(field_name='material__dollars_at_risk')
    dollars_at_risk_min = filters.NumberFilter(field_name='material__dollars_at_risk', lookup_expr='gte')
    dollars_at_risk_max = filters.NumberFilter(field_name='material__dollars_at_risk', lookup_expr='lte')

    # Driving risk filtering
    driving_risk = filters.CharFilter(field_name='material__driving_risk', lookup_expr='icontains')

    # Material group filtering
    material_group = filters.CharFilter(field_name='material__material_group', lookup_expr='exact')

    # Issue status filtering
    issue_status = filters.CharFilter(field_name='issue__status', lookup_expr='exact')

    # Issue date filtering
    issue_start_date_after = filters.DateFilter(field_name='issue__start_date', lookup_expr='gte')
    issue_start_date_before = filters.DateFilter(field_name='issue__start_date', lookup_expr='lte')
    issue_start_date = filters.DateFilter(field_name='issue__start_date', lookup_expr='exact')

    # Boolean filters for special cases
    has_potential_action = filters.BooleanFilter(method='filter_has_potential_action')
    has_substituted_material = filters.BooleanFilter(method='filter_has_substituted_material')
    has_manual_action = filters.BooleanFilter(method='filter_has_manual_action')

    def filter_has_potential_action(self, queryset, name, value):
        """Filter actions that have or don't have potential actions."""
        if value:
            return queryset.filter(potential_action__isnull=False)
        else:
            return queryset.filter(potential_action__isnull=True)

    def filter_has_substituted_material(self, queryset, name, value):
        """Filter actions that have or don't have substituted materials."""
        if value:
            return queryset.filter(substituted_material__isnull=False)
        else:
            return queryset.filter(substituted_material__isnull=True)

    def filter_has_manual_action(self, queryset, name, value):
        """Filter actions that have or don't have manual actions."""
        if value:
            return queryset.filter(action__isnull=False).exclude(action='')
        else:
            return queryset.filter(Q(action__isnull=True) | Q(action=''))

    class Meta:
        model = Action
        fields = [
            'user_id',
            'issue_nbr',
            'potential_action_nbr',
            'action_type',
            'module',
            'recommendation',
            'status',
            'manual_action',
            'material_nbr',
            'vendor_name',
            'substituted_material_nbr',
            'created_at_after',
            'created_at_before',
            'updated_at_after',
            'updated_at_before',
            'risk_rating_min',
            'risk_rating_max',
            'dollars_at_risk_min',
            'dollars_at_risk_max',
            'material_group',
            'issue_status',
            'has_potential_action',
            'has_substituted_material',
            'has_manual_action',
        ]
