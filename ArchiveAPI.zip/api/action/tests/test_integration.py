from datetime import date, timedelta

from django.urls import reverse
from rest_framework import status

from api.action.models import Action
from api.issue.models import Issue
from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class ActionViewIntegrationTest(BaseAPITestCase):
    """Integration tests for Action views"""

    @classmethod
    def setUpTestData(cls):
        cls.user = TestDataFactory.create_test_user(
            entra_id="test_user_123",
            email="testuser@example.com",
            first_name="Test",
            last_name="User"
        )
        cls.vendor = TestDataFactory.create_vendor(
            name="Test Vendor",
            country="US",
            risk_rating=0.8
        )
        cls.material = TestDataFactory.create_material(
            name="Test Material",
            vendor=cls.vendor,
            risk_rating=0.9
        )
        cls.issue = TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=cls.material,
            status=Issue.IssueStatus.OPEN
        )
        cls.substituted_material = TestDataFactory.create_material(
            name="Substitute Material",
            vendor=cls.vendor
        )

    def setUp(self):
        self.client.force_authenticate(user=self.user)

    def test_create_action_full_workflow(self):
        """Test complete workflow for creating an action."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'potential_action_nbr': potential_action.paction_nbr
        }

        response = self.client.post(reverse('action:action-create'), data, format='json')

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        created = response.data['created'][0]
        self.assertEqual(created['issue_nbr'], self.issue.issue_nbr)
        self.assertEqual(created['user_id'], self.user.entra_id)
        self.assertIsNotNone(created['potential_action'])

        # Verify database record
        action = Action.objects.get(id=created['id'])
        self.assertEqual(action.issue, self.issue)
        self.assertEqual(action.potential_action, potential_action)

    def test_create_action_with_substitution_full_workflow(self):
        """Test creating action with material substitution."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Substitute with alternate product",
            recommendation_type_nbr="31"
        )

        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'potential_action_nbr': potential_action.paction_nbr,
            'substituted_material_nbr': self.substituted_material.mat_nbr
        }

        response = self.client.post(reverse('action:action-create'), data, format='json')

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        created = response.data['created'][0]
        self.assertIsNotNone(created['substituted_material'])
        self.assertEqual(
            created['substituted_material']['mat_nbr'],
            self.substituted_material.mat_nbr
        )

        # Verify database relationships
        action = Action.objects.get(id=created['id'])
        self.assertEqual(action.substituted_material, self.substituted_material)

    def test_create_action_no_action_workflow(self):
        """Test creating action with no_action."""
        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'action': 'no_action'
        }

        response = self.client.post(reverse('action:action-create'), data, format='json')

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        created = response.data['created'][0]
        self.assertEqual(created['action'], 'no_action')
        self.assertIsNone(created['potential_action'])

    def test_list_actions_returns_per_action_material_for_gcn_issue(self):
        """Each fan-out action row exposes the material it was taken on."""
        vendor = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(vendor=vendor, fdb_gcn_seq_nbr="GCN-LIST")
        m2 = TestDataFactory.create_material(vendor=vendor, fdb_gcn_seq_nbr="GCN-LIST")
        issue = TestDataFactory.create_issue(issue_nbr="GCN-LIST-ISS", fdb_gcn_seq_nbr="GCN-LIST")
        potential_action = TestDataFactory.create_potential_action(
            issue=issue,
            recommendation="Switch Manufacturer",
        )

        create_response = self.client.post(
            reverse('action:action-create'),
            {
                'issue_nbr': issue.issue_nbr,
                'potential_action_nbr': potential_action.paction_nbr,
            },
            format='json',
        )
        self.assertEqual(create_response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(len(create_response.data['created']), 2)

        list_response = self.client.get(
            reverse('action:action-list'),
            {'limit': 50, 'issue_nbr': issue.issue_nbr},
        )
        self.assertEqual(list_response.status_code, status.HTTP_200_OK)
        self.assertEqual(list_response.data['count'], 2)

        material_numbers = {
            item['material_number']
            for item in list_response.data['results']
        }
        self.assertEqual(material_numbers, {m1.mat_nbr, m2.mat_nbr})

    def test_list_actions_with_filters(self):
        """Test listing actions with various filters."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer",
            action_type="Tactical"
        )
        TestDataFactory.create_action(
            issue=self.issue,
            user=self.user,
            potential_action=potential_action
        )

        # Filter by action type
        response = self.client.get(
            reverse('action:action-list'), {'action_type': 'Tactical'}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(response.data['count'], 0)

        # Filter by material
        response = self.client.get(
            reverse('action:action-list'), {'material_nbr': self.material.mat_nbr}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(response.data['count'], 0)

    def test_action_detail_full_workflow(self):
        """Test retrieving action detail."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user,
            potential_action=potential_action
        )

        response = self.client.get(reverse('action:action-detail', args=[action.id]))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['id'], action.id)
        self.assertEqual(response.data['issue_nbr'], self.issue.issue_nbr)
        self.assertEqual(response.data['user_id'], self.user.entra_id)
        self.assertIsNotNone(response.data['user'])
        self.assertEqual(response.data['user']['first_name'], 'Test')
        self.assertEqual(response.data['user']['last_name'], 'User')

    def test_action_export_full_workflow(self):
        """Test exporting actions to CSV."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )
        TestDataFactory.create_action(
            issue=self.issue,
            user=self.user,
            potential_action=potential_action
        )
        created_at_after = date.today() - timedelta(days=7)
        created_at_before = date.today() + timedelta(days=1)

        response = self.client.get(
            reverse('action:action-export'),
            {
                'created_at_after': created_at_after.isoformat(),
                'created_at_before': created_at_before.isoformat()
            }
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response['Content-Type'], 'text/csv')
        self.assertIn('attachment; filename=', response['Content-Disposition'])

        content = response.content.decode('utf-8')
        self.assertIn('Action ID', content)
        self.assertIn('Issue Number', content)
        self.assertIn(self.issue.issue_nbr, content)

    def test_test_action_export_full_workflow_invalid_time_range(self):
        """Test exporting actions with invalid time range."""
        created_at_after = date.today() + timedelta(days=1)
        created_at_before = date.today() - timedelta(days=7)

        response = self.client.get(
            reverse('action:action-export'),
            {
                'created_at_after': created_at_after.isoformat(),
                'created_at_before': created_at_before.isoformat()
            }
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('created_at_before must be after created_at_afte', str(response.data['error']))

    def test_test_action_export_full_workflow_too_large_time_range(self):
        """Test exporting actions with too large time range."""
        created_at_after = date.today() - timedelta(days=366)
        created_at_before = date.today()

        response = self.client.get(
            reverse('action:action-export'),
            {
                'created_at_after': created_at_after.isoformat(),
                'created_at_before': created_at_before.isoformat()
            }
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('Date range cannot exceed 31 days. Please select a shorter timeframe',
                      str(response.data['error']))

    def test_database_constraints_cascade_delete(self):
        """Test database constraints and cascade deletion."""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )
        action_id = action.id

        # Delete issue - should cascade to action
        issue_id = self.issue.id
        self.issue.delete()

        # Verify issue and action are deleted
        self.assertFalse(Issue.objects.filter(id=issue_id).exists())
        self.assertFalse(Action.objects.filter(id=action_id).exists())

    def test_delete_action_by_id_requires_taker(self):
        """Test that only the user who took the action can delete it."""
        issue = TestDataFactory.create_issue(
            issue_nbr="DELETE-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )
        other_user = TestDataFactory.create_test_user(entra_id="other_user", email="other@example.com")
        action = Action.objects.create(issue=issue, user_id=other_user.entra_id)

        url = reverse('action:action-detail', kwargs={'id': action.id})
        response = self.client.delete(url)

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertTrue(Action.objects.filter(id=action.id).exists())

    def test_delete_action_by_id_allows_taker(self):
        """Test that the user who took the action can delete it."""
        issue = TestDataFactory.create_issue(
            issue_nbr="DELETE-002",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )
        action = Action.objects.create(issue=issue, user_id=self.user.entra_id)

        url = reverse('action:action-detail', kwargs={'id': action.id})
        response = self.client.delete(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('deleted', response.data)
        self.assertEqual(response.data['count'], 1)
        self.assertEqual(len(response.data['deleted']), 1)
        self.assertFalse(Action.objects.filter(id=action.id).exists())
        self.assertTrue(Issue.objects.filter(id=issue.id).exists())

    def test_delete_action_fanout_removes_all_siblings(self):
        """DELETE removes all material-level rows for the same potential action."""
        vendor = TestDataFactory.create_vendor()
        TestDataFactory.create_material(vendor=vendor, fdb_gcn_seq_nbr="GCN-DEL")
        TestDataFactory.create_material(vendor=vendor, fdb_gcn_seq_nbr="GCN-DEL")
        TestDataFactory.create_material(vendor=vendor, fdb_gcn_seq_nbr="GCN-DEL")
        issue = TestDataFactory.create_issue(issue_nbr="GCN-DEL-ISS", fdb_gcn_seq_nbr="GCN-DEL")
        potential_action = TestDataFactory.create_potential_action(
            issue=issue,
            recommendation="Switch Manufacturer",
        )

        create_response = self.client.post(
            reverse('action:action-create'),
            {
                'issue_nbr': issue.issue_nbr,
                'potential_action_nbr': potential_action.paction_nbr,
            },
            format='json',
        )
        self.assertEqual(create_response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(len(create_response.data['created']), 3)

        anchor_id = create_response.data['created'][0]['id']
        delete_response = self.client.delete(
            reverse('action:action-detail', kwargs={'id': anchor_id}),
        )

        self.assertEqual(delete_response.status_code, status.HTTP_200_OK)
        self.assertEqual(delete_response.data['count'], 3)
        self.assertEqual(len(delete_response.data['deleted']), 3)
        self.assertEqual(
            Action.objects.filter(issue=issue, potential_action=potential_action).count(),
            0,
        )

    def test_delete_action_by_id_not_found(self):
        """Test deleting a non-existent action returns 404."""
        url = reverse('action:action-detail', kwargs={'id': 99999})
        response = self.client.delete(url)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('Action not found', str(response.data['error']))

    def test_delete_action_by_id_not_authenticated(self):
        """Test deleting a non-existent action returns 404."""
        url = reverse('action:action-detail', kwargs={'id': 99999})
        response = self.client.delete(url)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('Action not found', str(response.data['error']))

    def test_concurrent_action_creation_duplicate_prevention(self):
        """A repeated action on the same material is skipped (not duplicated)."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'potential_action_nbr': potential_action.paction_nbr
        }

        # Create first action
        response1 = self.client.post(reverse('action:action-create'), data, format='json')
        self.assertEqual(response1.status_code, status.HTTP_201_CREATED)
        self.assertEqual(len(response1.data['created']), 1)

        # Repeat: the already-actioned material is skipped, nothing new created.
        response2 = self.client.post(reverse('action:action-create'), data, format='json')
        self.assertEqual(response2.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response2.data['created'], [])
        self.assertEqual(response2.data['skipped'], 1)
        self.assertEqual(
            Action.objects.filter(issue=self.issue, potential_action=potential_action).count(),
            1,
        )

    def test_action_with_related_data_integrity(self):
        """Test that related data (vendor, material) maintains integrity."""
        vendor2 = TestDataFactory.create_vendor(name="Vendor 2")
        material2 = TestDataFactory.create_material(
            name="Material 2",
            vendor=vendor2
        )

        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Substitute with alternate product",
            recommendation_type_nbr="31"
        )

        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user,
            potential_action=potential_action,
            substituted_material=material2
        )

        # Verify relationships through API
        response = self.client.get(
            reverse('action:action-detail', args=[action.id])
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['vendor_name'], self.vendor.name)
        self.assertEqual(
            response.data['substituted_material']['vendor_name'],
            vendor2.name
        )

    def test_action_filtering_by_multiple_criteria(self):
        """Test complex filtering scenarios."""
        # Create actions with different attributes
        pa1 = TestDataFactory.create_potential_action(
            issue=self.issue,
            action_type="Tactical",
            module="React"
        )
        action1 = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user,
            potential_action=pa1
        )

        issue2 = TestDataFactory.create_issue(material=self.material)
        pa2 = TestDataFactory.create_potential_action(
            issue=issue2,
            action_type="Strategic",
            module="Manage"
        )
        action2 = TestDataFactory.create_action(
            issue=issue2,
            user=self.user,
            potential_action=pa2
        )

        # Filter by multiple criteria
        response = self.client.get(
            reverse('action:action-list'),
            {
                'action_type': 'Tactical',
                'module': 'React'
            }
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        action_ids = [a['id'] for a in response.data['results']]
        self.assertIn(action1.id, action_ids)
        self.assertNotIn(action2.id, action_ids)

    def test_action_user_cache_performance(self):
        """Test that user cache optimization works correctly."""
        # Only test with the authenticated user's actions since filtering is by user
        TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        issue2 = TestDataFactory.create_issue(material=self.material)
        TestDataFactory.create_action(
            issue=issue2,
            user=self.user
        )

        response = self.client.get(reverse('action:action-list'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        users_in_response = [
            a['user'] for a in response.data['results']
            if a['user'] is not None
        ]
        user_ids = [u['id'] for u in users_in_response]

        self.assertIn(self.user.entra_id, user_ids)
        self.assertTrue(all(uid == self.user.entra_id for uid in user_ids))

    def test_material_action_history_returns_action_issue_and_potential_action(self):
        """Test material action history response includes action, issue, and potential action details."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Substitute with alternate product",
            recommendation_type_nbr="31"
        )
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user,
            potential_action=potential_action,
            substituted_material=self.substituted_material,
            material_context={'material_risk_rating': 0.9},
            decision_feedback={'time_to_complete': '< 1 hour'}
        )

        response = self.client.get(
            reverse('action:material-action-history', args=[self.material.mat_nbr])
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        self.assertEqual(len(response.data['results']), 1)
        result = response.data['results'][0]
        self.assertEqual(result['id'], action.id)
        self.assertEqual(result['issue']['issue_nbr'], self.issue.issue_nbr)
        self.assertEqual(result['issue']['material_number'], self.material.mat_nbr)
        self.assertEqual(result['potential_action']['paction_nbr'], potential_action.paction_nbr)
        self.assertEqual(result['substituted_material']['mat_nbr'], self.substituted_material.mat_nbr)
        self.assertEqual(result['decision_feedback']['time_to_complete'], '< 1 hour')
        self.assertEqual(result['material_context']['material_risk_rating'], 0.9)
        self.assertEqual(result['user']['id'], self.user.entra_id)

    def test_material_action_history_includes_actions_from_multiple_users(self):
        """Test material action history is shared history, not a current-user action log."""
        other_user = TestDataFactory.create_test_user(
            entra_id="material_history_other_user",
            email="material-history-other@example.com",
            first_name="Other",
            last_name="User"
        )
        user_action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )
        other_user_action = TestDataFactory.create_action(
            issue=self.issue,
            user=other_user
        )

        response = self.client.get(
            reverse('action:material-action-history', args=[self.material.mat_nbr]),
            {'limit': 10, 'offset': 0}
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 2)
        action_ids = {item['id'] for item in response.data['results']}
        self.assertIn(user_action.id, action_ids)
        self.assertIn(other_user_action.id, action_ids)

    def test_material_action_history_excludes_other_materials(self):
        """Test material action history only returns actions for the requested material."""
        other_material = TestDataFactory.create_material(vendor=self.vendor)
        other_issue = TestDataFactory.create_issue(material=other_material)
        included_action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )
        excluded_action = TestDataFactory.create_action(
            issue=other_issue,
            user=self.user
        )

        response = self.client.get(
            reverse('action:material-action-history', args=[self.material.mat_nbr]),
            {'limit': 10, 'offset': 0}
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        action_ids = {item['id'] for item in response.data['results']}
        self.assertIn(included_action.id, action_ids)
        self.assertNotIn(excluded_action.id, action_ids)

    def test_material_action_history_unknown_material_returns_empty_list(self):
        """Test unknown materials return an empty history."""
        response = self.client.get(
            reverse('action:material-action-history', args=['UNKNOWN-MATERIAL'])
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 0)
        self.assertEqual(response.data['results'], [])

    def test_material_action_history_requires_authentication(self):
        """Test material action history uses the global authenticated API policy."""
        self.client.force_authenticate(user=None)

        response = self.client.get(
            reverse('action:material-action-history', args=[self.material.mat_nbr]),
            HTTP_X_DISABLE_TEST_AUTH='1'
        )

        self.assertIn(
            response.status_code,
            [status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN]
        )

    def test_invalid_data_validation(self):
        """Test validation for invalid input data."""
        # Missing required field
        response = self.client.post(reverse('action:action-create'), {}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('issue_nbr', str(response.data))

        # Invalid issue
        data = {
            'issue_nbr': 'INVALID-999',
            'mat_nbr': self.material.mat_nbr,
            'action': 'no_action'
        }
        response = self.client.post(reverse('action:action-create'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        # Invalid action without potential_action
        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'action': 'invalid_action'
        }
        response = self.client.post(reverse('action:action-create'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_action_ordering(self):
        """Test that actions are properly ordered by created_at."""
        # Create actions at different times
        TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        issue2 = TestDataFactory.create_issue(material=self.material)
        TestDataFactory.create_action(
            issue=issue2,
            user=self.user
        )

        response = self.client.get(reverse('action:action-list'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']

        # Verify ordering (most recent first)
        if len(results) >= 2:
            self.assertGreaterEqual(
                results[0]['created_at'],
                results[-1]['created_at']
            )

    def test_create_action_with_material_context(self):
        """Test creating action with material context fields."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'potential_action_nbr': potential_action.paction_nbr,
            'material_risk_rating': 0.937,
            'material_driving_risk': 'Operational',
            'material_dollars_at_risk': 93.7
        }

        response = self.client.post(reverse('action:action-create'), data, format='json')

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        created = response.data['created'][0]

        # Verify material_context is stored correctly
        action = Action.objects.get(id=created['id'])
        self.assertEqual(action.material_context.get('material_risk_rating'), 0.937)
        self.assertEqual(action.material_context.get('material_driving_risk'), 'Operational')
        self.assertEqual(action.material_context.get('material_dollars_at_risk'), 93.7)

        # Verify response includes material_context
        self.assertIn('material_context', created)
        self.assertEqual(created['material_context']['material_risk_rating'], 0.937)

    def test_create_action_with_partial_material_context(self):
        """Test creating action with only some material context fields."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'potential_action_nbr': potential_action.paction_nbr,
            'material_risk_rating': 0.5,
            # material_driving_risk and material_dollars_at_risk not provided
        }

        response = self.client.post(reverse('action:action-create'), data, format='json')

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Verify only provided field is stored
        action = Action.objects.get(id=response.data['created'][0]['id'])
        self.assertEqual(action.material_context.get('material_risk_rating'), 0.5)
        self.assertNotIn('material_driving_risk', action.material_context)
        self.assertNotIn('material_dollars_at_risk', action.material_context)

    def test_create_action_without_material_context(self):
        """Test creating action without material context fields (should still work)."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'potential_action_nbr': potential_action.paction_nbr
        }

        response = self.client.post(reverse('action:action-create'), data, format='json')

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Verify material_context is empty dict
        action = Action.objects.get(id=response.data['created'][0]['id'])
        self.assertEqual(action.material_context, {})

    def test_create_action_sets_user_info_from_auth(self):
        """Test that user_info is set from auth context, not request body."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'potential_action_nbr': potential_action.paction_nbr
        }

        response = self.client.post(reverse('action:action-create'), data, format='json')

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Verify user_info is populated from authenticated user
        action = Action.objects.get(id=response.data['created'][0]['id'])
        self.assertIn('first_name', action.user_info)
        self.assertEqual(action.user_info['first_name'], self.user.first_name)
        self.assertEqual(action.user_info['last_name'], self.user.last_name)
        self.assertEqual(action.user_info['email'], self.user.email)

    def test_create_action_user_info_not_from_request_body(self):
        """Test that user_info fields in request body are ignored."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        # Try to inject user_info via request body (should be ignored)
        data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'potential_action_nbr': potential_action.paction_nbr,
            'user_info': {
                'first_name': 'Hacker',
                'last_name': 'Attempt',
                'email': 'hacker@evil.com',
                'role': 'admin'
            }
        }

        response = self.client.post(reverse('action:action-create'), data, format='json')

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Verify user_info is from auth, not from request body
        action = Action.objects.get(id=response.data['created'][0]['id'])
        self.assertNotEqual(action.user_info.get('first_name'), 'Hacker')
        self.assertEqual(action.user_info.get('first_name'), self.user.first_name)

    def test_decision_feedback_update(self):
        """Test updating decision feedback via PATCH endpoint."""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        data = {
            'time_to_complete': '1-2 hours',
            'decision_rationale': 'This aligns with our standard business process'
        }

        response = self.client.patch(
            reverse('action:action-decision-feedback', args=[action.id]),
            data,
            format='json'
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Verify decision_feedback is stored correctly
        action.refresh_from_db()
        self.assertEqual(action.decision_feedback['time_to_complete'], '1-2 hours')
        self.assertEqual(
            action.decision_feedback['decision_rationale'],
            'This aligns with our standard business process'
        )

    def test_decision_feedback_partial_update(self):
        """Test that partial updates merge correctly without overwriting."""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        # First update - set time_to_complete
        data1 = {'time_to_complete': '< 1 hour'}
        response1 = self.client.patch(
            reverse('action:action-decision-feedback', args=[action.id]),
            data1,
            format='json'
        )
        self.assertEqual(response1.status_code, status.HTTP_200_OK)

        # Second update - set decision_rationale only
        data2 = {'decision_rationale': 'Best mitigates the identified risk'}
        response2 = self.client.patch(
            reverse('action:action-decision-feedback', args=[action.id]),
            data2,
            format='json'
        )
        self.assertEqual(response2.status_code, status.HTTP_200_OK)

        # Verify both fields are preserved
        action.refresh_from_db()
        self.assertEqual(action.decision_feedback['time_to_complete'], '< 1 hour')
        self.assertEqual(
            action.decision_feedback['decision_rationale'],
            'Best mitigates the identified risk'
        )

    def test_decision_feedback_update_overwrites_same_key(self):
        """Test that updating the same key overwrites the previous value."""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        # First update
        data1 = {'time_to_complete': '< 1 hour'}
        self.client.patch(
            reverse('action:action-decision-feedback', args=[action.id]),
            data1,
            format='json'
        )

        # Update same key with new value
        data2 = {'time_to_complete': '2+ hours'}
        self.client.patch(
            reverse('action:action-decision-feedback', args=[action.id]),
            data2,
            format='json'
        )

        action.refresh_from_db()
        self.assertEqual(action.decision_feedback['time_to_complete'], '2+ hours')

    def test_decision_feedback_requires_at_least_one_field(self):
        """Test that at least one field must be provided for decision feedback."""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        data = {}  # Empty payload

        response = self.client.patch(
            reverse('action:action-decision-feedback', args=[action.id]),
            data,
            format='json'
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_decision_feedback_requires_action_owner(self):
        """Test that only the action owner can update decision feedback."""
        other_user = TestDataFactory.create_test_user(
            entra_id="other_user_456",
            email="other@example.com"
        )
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=other_user  # Action owned by different user
        )

        data = {'time_to_complete': '1-2 hours'}

        response = self.client.patch(
            reverse('action:action-decision-feedback', args=[action.id]),
            data,
            format='json'
        )

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_decision_feedback_action_not_found(self):
        """Test decision feedback update for non-existent action."""
        data = {'time_to_complete': '1-2 hours'}

        response = self.client.patch(
            reverse('action:action-decision-feedback', args=[99999]),
            data,
            format='json'
        )

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_action_response_includes_all_json_fields(self):
        """Test that action response includes material_context, decision_feedback, user_info."""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        # Create action with material context
        create_data = {
            'issue_nbr': self.issue.issue_nbr,
            'mat_nbr': self.material.mat_nbr,
            'potential_action_nbr': potential_action.paction_nbr,
            'material_risk_rating': 0.8,
            'material_driving_risk': 'Supply',
            'material_dollars_at_risk': 1000.0
        }

        create_response = self.client.post(
            reverse('action:action-create'),
            create_data,
            format='json'
        )
        action_id = create_response.data['created'][0]['id']

        # Add decision feedback
        feedback_data = {
            'time_to_complete': '< 1 hour',
            'decision_rationale': 'Quick fix needed'
        }
        self.client.patch(
            reverse('action:action-decision-feedback', args=[action_id]),
            feedback_data,
            format='json'
        )

        # Get action detail
        response = self.client.get(reverse('action:action-detail', args=[action_id]))

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Verify all JSON fields are in response
        self.assertIn('material_context', response.data)
        self.assertIn('decision_feedback', response.data)
        self.assertIn('user_info', response.data)

        # Verify content
        self.assertEqual(response.data['material_context']['material_risk_rating'], 0.8)
        self.assertEqual(response.data['decision_feedback']['time_to_complete'], '< 1 hour')
        self.assertIn('first_name', response.data['user_info'])
