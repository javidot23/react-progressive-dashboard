from api.action.models import Action
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class ActionModelTest(BaseTestCase):
    def setUp(self):
        vendor = TestDataFactory.create_vendor(name="Test Vendor for Action")
        material = TestDataFactory.create_material(
            name="Test Material for Action",
            vendor=vendor
        )

        self.issue = TestDataFactory.create_issue(material=material)
        self.user = TestDataFactory.create_test_user()

        self.action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

    def test_action_creation(self):
        """Test basic action creation"""
        self.assertEqual(self.action.issue, self.issue)
        self.assertEqual(self.action.user_id, self.user.entra_id)

    def test_action_cascade_delete(self):
        """Test that deleting an issue deletes its actions"""
        self.issue.delete()
        with self.assertRaises(Action.DoesNotExist):
            Action.objects.get(id=self.action.id)

    def test_action_user_relationship(self):
        """Test the relationship between action and user
        User is referenced by entra_id and its on another database
        """
        self.assertEqual(self.action.user_id, self.user.entra_id)
        self.assertIn(self.action, Action.objects.filter(user_id=self.user.entra_id))

    def test_action_issue_relationship(self):
        """Test the relationship between action and issue"""
        self.assertEqual(self.action.issue, self.issue)
        self.assertIn(self.action, self.issue.actions.all())

    def test_action_unique_together(self):
        """Test that the unique constraint on issue and action_type works"""
        with self.assertRaises(Exception):
            Action.objects.create(
                issue=self.issue,
                user=self.user
            )
