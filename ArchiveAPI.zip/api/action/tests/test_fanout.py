from api.action.models import Action
from api.action.services import ActionService
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class CreateActionsForIssueTest(BaseTestCase):
    """ActionService.create_actions_for_issue — fan-out to one Action per material."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user()
        self.vendor = TestDataFactory.create_vendor()
        self.m1 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")
        self.m2 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")
        self.m3 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")

    def _gcn_issue(self, issue_nbr="GCN-ISS"):
        issue = TestDataFactory.create_issue(issue_nbr=issue_nbr, fdb_gcn_seq_nbr="GCN-1")
        pa = TestDataFactory.create_potential_action(issue=issue, recommendation="Switch Manufacturer")
        return issue, pa

    def test_fan_out_to_all_grain_materials_by_default(self):
        issue, pa = self._gcn_issue()
        result = ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=pa.paction_nbr,
        )
        self.assertEqual(len(result["created"]), 3)
        self.assertEqual(result["skipped"], 0)
        self.assertEqual(
            set(Action.objects.values_list("material_id", flat=True)),
            {self.m1.mat_nbr, self.m2.mat_nbr, self.m3.mat_nbr},
        )

    def test_subset_mat_nbrs(self):
        issue, pa = self._gcn_issue()
        result = ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            mat_nbrs=[self.m1.mat_nbr, self.m2.mat_nbr],
            potential_action_nbr=pa.paction_nbr,
        )
        self.assertEqual(len(result["created"]), 2)
        self.assertEqual(
            set(Action.objects.values_list("material_id", flat=True)),
            {self.m1.mat_nbr, self.m2.mat_nbr},
        )

    def test_skips_already_actioned_materials(self):
        issue, pa = self._gcn_issue()
        ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            mat_nbrs=[self.m1.mat_nbr],
            potential_action_nbr=pa.paction_nbr,
        )
        # Re-run for all: m1 skipped, m2 + m3 created.
        result = ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=pa.paction_nbr,
        )
        self.assertEqual(len(result["created"]), 2)
        self.assertEqual(result["skipped"], 1)
        self.assertEqual(Action.objects.count(), 3)

    def test_mat_nbrs_outside_grain_rejected(self):
        issue, pa = self._gcn_issue()
        other = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-OTHER")
        with self.assertRaises(ValueError):
            ActionService.create_actions_for_issue(
                issue_nbr=issue.issue_nbr,
                user_id=self.user.entra_id,
                mat_nbrs=[other.mat_nbr],
                potential_action_nbr=pa.paction_nbr,
            )

    def test_fei_issue_raises(self):
        issue = TestDataFactory.create_issue(issue_nbr="FEI-ISS", fei_number="FEI-1")
        pa = TestDataFactory.create_potential_action(issue=issue, recommendation="Switch Manufacturer")
        with self.assertRaises(ValueError):
            ActionService.create_actions_for_issue(
                issue_nbr=issue.issue_nbr,
                user_id=self.user.entra_id,
                potential_action_nbr=pa.paction_nbr,
            )

    def test_substitution_rejected_for_multi_material(self):
        issue, pa = self._gcn_issue()
        sub = TestDataFactory.create_material(vendor=self.vendor)
        with self.assertRaises(ValueError):
            ActionService.create_actions_for_issue(
                issue_nbr=issue.issue_nbr,
                user_id=self.user.entra_id,
                potential_action_nbr=pa.paction_nbr,
                substituted_material_nbr=sub.mat_nbr,
            )

    def test_substitution_allowed_for_single_material(self):
        issue, pa = self._gcn_issue()
        sub = TestDataFactory.create_material(vendor=self.vendor)
        result = ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            mat_nbrs=[self.m1.mat_nbr],
            potential_action_nbr=pa.paction_nbr,
            substituted_material_nbr=sub.mat_nbr,
        )
        self.assertEqual(len(result["created"]), 1)
        self.assertEqual(result["created"][0].substituted_material_id, sub.mat_nbr)

    def test_material_grain_single_action(self):
        material_issue = TestDataFactory.create_issue(issue_nbr="MAT-ISS", material=self.m1)
        pa = TestDataFactory.create_potential_action(
            issue=material_issue, recommendation="Switch Manufacturer"
        )
        result = ActionService.create_actions_for_issue(
            issue_nbr=material_issue.issue_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=pa.paction_nbr,
        )
        self.assertEqual(len(result["created"]), 1)
        self.assertEqual(result["created"][0].material_id, self.m1.mat_nbr)


class DeleteActionGroupTest(BaseTestCase):
    """ActionService.delete_action_by_id — grouped delete for fan-out actions."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user()
        self.vendor = TestDataFactory.create_vendor()
        self.m1 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")
        self.m2 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")
        self.m3 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")

    def _gcn_issue(self, issue_nbr="GCN-ISS"):
        issue = TestDataFactory.create_issue(issue_nbr=issue_nbr, fdb_gcn_seq_nbr="GCN-1")
        pa = TestDataFactory.create_potential_action(issue=issue, recommendation="Switch Manufacturer")
        return issue, pa

    def test_delete_removes_all_siblings_for_potential_action(self):
        issue, pa = self._gcn_issue()
        created = ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=pa.paction_nbr,
        )
        anchor = created["created"][0]
        result = ActionService.delete_action_by_id(anchor.id, self.user.entra_id)

        self.assertEqual(result["count"], 3)
        self.assertEqual(len(result["deleted"]), 3)
        self.assertEqual(Action.objects.filter(issue=issue, potential_action=pa).count(), 0)

    def test_delete_partial_batches_removes_all_user_actions_for_pa(self):
        issue, pa = self._gcn_issue()
        ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            mat_nbrs=[self.m1.mat_nbr],
            potential_action_nbr=pa.paction_nbr,
        )
        batch2 = ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=pa.paction_nbr,
        )
        anchor = batch2["created"][0]
        result = ActionService.delete_action_by_id(anchor.id, self.user.entra_id)

        self.assertEqual(result["count"], 3)
        self.assertEqual(Action.objects.filter(issue=issue, potential_action=pa).count(), 0)

    def test_delete_does_not_remove_other_potential_action(self):
        issue = TestDataFactory.create_issue(issue_nbr="GCN-ISS-2", fdb_gcn_seq_nbr="GCN-1")
        pa1 = TestDataFactory.create_potential_action(
            issue=issue, recommendation="Switch Manufacturer"
        )
        pa2 = TestDataFactory.create_potential_action(
            issue=issue, recommendation="Increase Safety Stock"
        )
        group1 = ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=pa1.paction_nbr,
        )
        ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=pa2.paction_nbr,
        )
        anchor = group1["created"][0]
        result = ActionService.delete_action_by_id(anchor.id, self.user.entra_id)

        self.assertEqual(result["count"], 3)
        self.assertEqual(Action.objects.filter(issue=issue, potential_action=pa1).count(), 0)
        self.assertEqual(Action.objects.filter(issue=issue, potential_action=pa2).count(), 3)

    def test_delete_no_action_groups_by_action_field(self):
        issue, _ = self._gcn_issue()
        created = ActionService.create_actions_for_issue(
            issue_nbr=issue.issue_nbr,
            user_id=self.user.entra_id,
            action="no_action",
        )
        anchor = created["created"][0]
        result = ActionService.delete_action_by_id(anchor.id, self.user.entra_id)

        self.assertEqual(result["count"], 3)
        self.assertEqual(Action.objects.filter(issue=issue, action="no_action").count(), 0)
