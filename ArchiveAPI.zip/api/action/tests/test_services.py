from api.action.models import Action
from api.action.services import ActionService
from api.issue.models import Issue
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class ActionServiceTest(BaseTestCase):
    def setUp(self):
        self.user = TestDataFactory.create_test_user(
            entra_id="test_user_123",
            email="testuser@example.com"
        )
        self.vendor = TestDataFactory.create_vendor(
            name="Test Vendor",
            country="US",
            risk_rating=0.8
        )
        self.material = TestDataFactory.create_material(
            name="Test Material",
            vendor=self.vendor,
            risk_rating=0.9
        )
        self.issue = TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )

    def test_create_action_with_potential_action(self):
        """Test creating action with potential action"""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        action = ActionService.create_action(
            issue_nbr=self.issue.issue_nbr,
            mat_nbr=self.material.mat_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=potential_action.paction_nbr
        )

        self.assertIsNotNone(action)
        self.assertEqual(action.issue, self.issue)
        self.assertEqual(action.user_id, self.user.entra_id)
        self.assertEqual(action.potential_action, potential_action)

    def test_create_action_with_substituted_material(self):
        """Test creating action with substituted material"""
        substituted_material = TestDataFactory.create_material(
            name="Substitute Material",
            vendor=self.vendor
        )
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Substitute with alternate product",
            recommendation_type_nbr="31"
        )

        action = ActionService.create_action(
            issue_nbr=self.issue.issue_nbr,
            mat_nbr=self.issue.material.mat_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=potential_action.paction_nbr,
            substituted_material_nbr=substituted_material.mat_nbr
        )

        self.assertIsNotNone(action)
        self.assertEqual(action.substituted_material, substituted_material)

    def test_create_action_no_action(self):
        """Test creating action with no_action"""
        action = ActionService.create_action(
            issue_nbr=self.issue.issue_nbr,
            mat_nbr=self.material.mat_nbr,
            user_id=self.user.entra_id,
            action="no_action"
        )

        self.assertIsNotNone(action)
        self.assertEqual(action.action, "no_action")
        self.assertIsNone(action.potential_action)

    def test_create_action_invalid_issue(self):
        """Test creating action with invalid issue"""
        with self.assertRaises(ValueError) as context:
            ActionService.create_action(
                issue_nbr="INVALID-999",
                mat_nbr=self.material.mat_nbr,
                user_id=self.user.entra_id,
                action="no_action"
            )
        self.assertIn("Issue INVALID-999 not found", str(context.exception))

    def test_create_action_invalid_potential_action(self):
        """Test creating action with invalid potential action"""
        with self.assertRaises(ValueError) as context:
            ActionService.create_action(
                issue_nbr=self.issue.issue_nbr,
                mat_nbr=self.material.mat_nbr,
                user_id=self.user.entra_id,
                potential_action_nbr="INVALID-PA"
            )
        self.assertIn("Potential action INVALID-PA not found", str(context.exception))

    def test_create_action_invalid_substituted_material(self):
        """Test creating action with invalid substituted material"""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Substitute with alternate product",
            recommendation_type_nbr="31"
        )

        with self.assertRaises(ValueError) as context:
            ActionService.create_action(
                issue_nbr=self.issue.issue_nbr,
                mat_nbr=self.material.mat_nbr,
                user_id=self.user.entra_id,
                potential_action_nbr=potential_action.paction_nbr,
                substituted_material_nbr="INVALID-MAT"
            )
        self.assertIn("Substituted material INVALID-MAT not found", str(context.exception))

    def test_create_action_same_material_substitution(self):
        """Test creating action with same material as substitution"""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Substitute with alternate product"
        )

        with self.assertRaises(ValueError) as context:
            ActionService.create_action(
                issue_nbr=self.issue.issue_nbr,
                mat_nbr=self.material.mat_nbr,
                user_id=self.user.entra_id,
                potential_action_nbr=potential_action.paction_nbr,
                substituted_material_nbr=self.material.mat_nbr
            )
        self.assertIn("Substituted material must be different", str(context.exception))

    def test_create_action_duplicate_potential_action(self):
        """Test creating duplicate action with same potential action"""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )

        # Create first action
        ActionService.create_action(
            issue_nbr=self.issue.issue_nbr,
            mat_nbr=self.material.mat_nbr,
            user_id=self.user.entra_id,
            potential_action_nbr=potential_action.paction_nbr
        )

        # Try to create duplicate
        with self.assertRaises(ValueError) as context:
            ActionService.create_action(
                issue_nbr=self.issue.issue_nbr,
                mat_nbr=self.material.mat_nbr,
                user_id=self.user.entra_id,
                potential_action_nbr=potential_action.paction_nbr
            )
        self.assertIn("has already been taken", str(context.exception))

    def test_create_action_invalid_action_without_potential_action(self):
        """Test creating action with invalid action field when no potential action"""
        with self.assertRaises(ValueError) as context:
            ActionService.create_action(
                issue_nbr=self.issue.issue_nbr,
                mat_nbr=self.material.mat_nbr,
                user_id=self.user.entra_id,
                action="some_action"
            )
        self.assertIn("Action must be 'no_action'", str(context.exception))

    def test_create_action_substitute_without_material(self):
        """Test creating substitute action without substituted material"""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Substitute with alternate product",
            recommendation_type_nbr="31"
        )

        with self.assertRaises(ValueError) as context:
            ActionService.create_action(
                issue_nbr=self.issue.issue_nbr,
                mat_nbr=self.material.mat_nbr,
                user_id=self.user.entra_id,
                potential_action_nbr=potential_action.paction_nbr
            )
        self.assertIn("Substituted material is required", str(context.exception))

    def test_get_actions_queryset(self):
        """Test getting actions queryset"""
        TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        queryset = ActionService.get_actions_queryset(self.user.entra_id)

        self.assertGreater(queryset.count(), 0)

    def test_get_actions_by_issue(self):
        """Test getting actions by issue"""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        actions = ActionService.get_actions_by_issue(self.issue.issue_nbr, self.user.entra_id)

        self.assertGreater(len(actions), 0)
        self.assertIn(action, actions)

    def test_get_actions_by_user(self):
        """Test getting actions by user"""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        actions = ActionService.get_actions_by_user(self.user.entra_id)

        self.assertGreater(len(actions), 0)
        self.assertIn(action, actions)

    def test_get_actions_for_material(self):
        """Test getting actions for material"""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        actions = ActionService.get_actions_for_material(self.material.mat_nbr, self.user.entra_id)

        self.assertGreater(len(actions), 0)
        self.assertIn(action, actions)

    def test_get_material_action_history_returns_all_users_for_material(self):
        """Test material action history is not scoped to the requesting user."""
        other_user = TestDataFactory.create_test_user(
            entra_id="material_history_user",
            email="history@example.com"
        )
        user_action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )
        other_user_action = TestDataFactory.create_action(
            issue=self.issue,
            user=other_user
        )

        actions = list(ActionService.get_material_action_history(self.material.mat_nbr))

        self.assertIn(user_action, actions)
        self.assertIn(other_user_action, actions)

    def test_get_material_action_history_excludes_other_materials(self):
        """Test material action history only returns actions for the requested material."""
        other_material = TestDataFactory.create_material(vendor=self.vendor)
        other_issue = TestDataFactory.create_issue(material=other_material)
        included_action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )
        excluded_action = TestDataFactory.create_action(
            issue=other_issue,
            user=self.user
        )

        actions = list(ActionService.get_material_action_history(self.material.mat_nbr))

        self.assertIn(included_action, actions)
        self.assertNotIn(excluded_action, actions)

    def test_get_material_action_history_orders_newest_first(self):
        """Test material action history follows existing newest-first action ordering."""
        TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )
        TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        actions = list(ActionService.get_material_action_history(self.material.mat_nbr))

        self.assertGreaterEqual(actions[0].created_at, actions[-1].created_at)

    def test_get_user_cache_for_actions(self):
        """Test getting user cache for actions"""
        action1 = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )
        user2 = TestDataFactory.create_test_user(
            entra_id="test_user_456",
            email="testuser2@example.com"
        )
        action2 = TestDataFactory.create_action(
            issue=self.issue,
            user=user2
        )

        actions = [action1, action2]
        user_cache = ActionService.get_user_cache_for_actions(actions)

        self.assertIsInstance(user_cache, dict)
        self.assertIn(self.user.entra_id, user_cache)
        self.assertIn(user2.entra_id, user_cache)
        self.assertEqual(user_cache[self.user.entra_id]["first_name"], self.user.first_name)

    def test_export_actions_to_csv_data(self):
        """Test exporting actions to CSV format"""
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Switch Manufacturer"
        )
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user,
            potential_action=potential_action
        )

        queryset = Action.objects.filter(id=action.id)
        csv_data = ActionService.export_actions_to_csv_data(queryset)

        self.assertGreater(len(csv_data), 0)
        self.assertEqual(csv_data[0]['action_id'], action.id)
        self.assertEqual(csv_data[0]['issue_nbr'], self.issue.issue_nbr)
        self.assertEqual(csv_data[0]['user_id'], self.user.entra_id)
        self.assertEqual(csv_data[0]['material_number'], self.material.mat_nbr)

    def test_export_actions_with_substituted_material_to_csv(self):
        """Test exporting actions with substituted material to CSV"""
        substituted_material = TestDataFactory.create_material(
            name="Substitute Material",
            vendor=self.vendor
        )
        potential_action = TestDataFactory.create_potential_action(
            issue=self.issue,
            recommendation="Substitute with alternate product"
        )
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user,
            potential_action=potential_action,
            substituted_material=substituted_material
        )

        queryset = Action.objects.filter(id=action.id)
        csv_data = ActionService.export_actions_to_csv_data(queryset)

        self.assertEqual(csv_data[0]['substituted_material_number'], substituted_material.mat_nbr)
        self.assertEqual(csv_data[0]['substituted_material_name'], substituted_material.name)

    def test_create_action_with_material_context(self):
        """Test creating action with material context"""
        material_context = {
            'material_risk_rating': 0.937,
            'material_driving_risk': 'Operational',
            'material_dollars_at_risk': 93.7
        }

        action = ActionService.create_action(
            issue_nbr=self.issue.issue_nbr,
            mat_nbr=self.material.mat_nbr,
            user_id=self.user.entra_id,
            action="no_action",
            material_context=material_context
        )

        self.assertIsNotNone(action)
        self.assertEqual(action.material_context, material_context)
        self.assertEqual(action.material_context['material_risk_rating'], 0.937)
        self.assertEqual(action.material_context['material_driving_risk'], 'Operational')
        self.assertEqual(action.material_context['material_dollars_at_risk'], 93.7)

    def test_create_action_with_user_info(self):
        """Test creating action with user info"""
        user_info = {
            'first_name': 'Test',
            'last_name': 'User',
            'email': 'test@example.com',
            'role': 'analyst'
        }

        action = ActionService.create_action(
            issue_nbr=self.issue.issue_nbr,
            mat_nbr=self.material.mat_nbr,
            user_id=self.user.entra_id,
            action="no_action",
            user_info=user_info
        )

        self.assertIsNotNone(action)
        self.assertEqual(action.user_info, user_info)
        self.assertEqual(action.user_info['first_name'], 'Test')
        self.assertEqual(action.user_info['role'], 'analyst')

    def test_create_action_with_empty_material_context(self):
        """Test creating action with empty material context"""
        action = ActionService.create_action(
            issue_nbr=self.issue.issue_nbr,
            mat_nbr=self.material.mat_nbr,
            user_id=self.user.entra_id,
            action="no_action",
            material_context={}
        )

        self.assertIsNotNone(action)
        self.assertEqual(action.material_context, {})

    def test_create_action_without_optional_json_fields(self):
        """Test creating action without material_context and user_info"""
        action = ActionService.create_action(
            issue_nbr=self.issue.issue_nbr,
            mat_nbr=self.material.mat_nbr,
            user_id=self.user.entra_id,
            action="no_action"
        )

        self.assertIsNotNone(action)
        self.assertEqual(action.material_context, {})
        self.assertEqual(action.user_info, {})

    def test_update_decision_feedback(self):
        """Test updating decision feedback on an action"""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        feedback_update = {
            'time_to_complete': '1-2 hours',
            'decision_rationale': 'This aligns with our standard business process'
        }

        updated_action = ActionService.update_decision_feedback(
            action_id=action.id,
            feedback_update=feedback_update,
            user_id=self.user.entra_id
        )

        self.assertIsNotNone(updated_action)
        self.assertEqual(updated_action.decision_feedback['time_to_complete'], '1-2 hours')
        self.assertEqual(
            updated_action.decision_feedback['decision_rationale'],
            'This aligns with our standard business process'
        )

    def test_update_decision_feedback_merges_with_existing(self):
        """Test that decision feedback update merges with existing values"""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        # First update
        ActionService.update_decision_feedback(
            action_id=action.id,
            feedback_update={'time_to_complete': '< 1 hour'},
            user_id=self.user.entra_id
        )

        # Second update - should merge, not replace
        updated_action = ActionService.update_decision_feedback(
            action_id=action.id,
            feedback_update={'decision_rationale': 'Best mitigates risk'},
            user_id=self.user.entra_id
        )

        # Both values should be present
        self.assertEqual(updated_action.decision_feedback['time_to_complete'], '< 1 hour')
        self.assertEqual(updated_action.decision_feedback['decision_rationale'], 'Best mitigates risk')

    def test_update_decision_feedback_not_found(self):
        """Test updating decision feedback for non-existent action"""
        with self.assertRaises(ValueError) as context:
            ActionService.update_decision_feedback(
                action_id=99999,
                feedback_update={'time_to_complete': '1-2 hours'},
                user_id=self.user.entra_id
            )
        self.assertIn("Action not found", str(context.exception))

    def test_update_decision_feedback_wrong_user(self):
        """Test updating decision feedback by non-owner"""
        other_user = TestDataFactory.create_test_user(
            entra_id="other_user_789",
            email="other@example.com"
        )
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=other_user
        )

        with self.assertRaises(PermissionError) as context:
            ActionService.update_decision_feedback(
                action_id=action.id,
                feedback_update={'time_to_complete': '1-2 hours'},
                user_id=self.user.entra_id  # Different user
            )
        self.assertIn("only update feedback for actions you have taken", str(context.exception))

    def test_update_decision_feedback_unauthenticated(self):
        """Test updating decision feedback without authentication"""
        action = TestDataFactory.create_action(
            issue=self.issue,
            user=self.user
        )

        with self.assertRaises(PermissionError) as context:
            ActionService.update_decision_feedback(
                action_id=action.id,
                feedback_update={'time_to_complete': '1-2 hours'},
                user_id=None
            )
        self.assertIn("User not authenticated", str(context.exception))
