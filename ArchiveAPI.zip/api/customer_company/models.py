from django.db import models

from api.customer_corp_chain.models import CustomerCorpChain


class CustomerCompany(models.Model):
    cust_company_nbr = models.CharField(max_length=255, unique=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    cust_corp_chain_nbr = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.CASCADE,
        null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "customer_companies"
        verbose_name = "Customer Company"
        verbose_name_plural = "Customer Companies"
        indexes = [
            models.Index(fields=["cust_company_nbr"]),
            models.Index(fields=["cust_corp_chain_nbr"]),
        ]
