from django.apps import AppConfig


class CustomerCompanyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.customer_company'
