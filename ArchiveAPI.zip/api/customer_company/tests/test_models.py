from django.db import IntegrityError
from tests.BaseTestCase import BaseTestCase

from tests.TestDataFactory import TestDataFactory


class CustomerCompanyModelTest(BaseTestCase):
    def setUp(self):
        self.customer_company = TestDataFactory.create_customer_company(
            cust_company_nbr="CC001",
            name="Test Company",
        )

    def test_customer_company_creation(self):
        """Test basic customer company creation"""
        self.assertEqual(self.customer_company.name, "Test Company")
        self.assertEqual(self.customer_company.cust_company_nbr, "CC001")

    def test_unique_company_code_constraint(self):
        """Test that company nbr must be unique"""
        TestDataFactory.create_customer_company(
            name="Another Company",
            cust_company_nbr="TC002"
        )

        with self.assertRaises(IntegrityError):
            TestDataFactory.create_customer_company(
                name="Duplicate Company",
                cust_company_nbr="TC002"
            )
