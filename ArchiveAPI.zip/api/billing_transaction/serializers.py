from rest_framework import serializers


class SalesHistorySerializer(serializers.Serializer):
    """Flat line-level fields for the Sales History table."""

    material_number = serializers.CharField(allow_null=True)
    material_name = serializers.CharField(allow_null=True)
    ndc = serializers.CharField(allow_null=True)
    invoice_date = serializers.DateField(allow_null=True)
    invoice_number = serializers.CharField(allow_null=True)
    sales_quantity = serializers.DecimalField(max_digits=18, decimal_places=3, allow_null=True)
    sales_amount = serializers.DecimalField(max_digits=38, decimal_places=6, allow_null=True)
    contract_type = serializers.CharField(allow_null=True)

    class Meta:
        ref_name = "BillingTransactionSalesHistory"
