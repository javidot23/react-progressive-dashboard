from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework import generics
from rest_framework.filters import OrderingFilter

from api.csv_export import CsvExportView
from api.global_filters import get_filtered_material_subquery
from api.pagination import MaxLimitOffsetPagination

from .filters import SalesHistoryFilter
from .serializers import SalesHistorySerializer
from .services import BillingTransactionService

SALES_HISTORY_ORDERING_FIELDS = [
    "material_number",
    "material_name",
    "ndc",
    "invoice_date",
    "invoice_number",
    "sales_quantity",
    "sales_amount",
    "contract_type",
]
SALES_HISTORY_DEFAULT_ORDERING = ["-invoice_date", "invoice_number", "material_number"]


def get_sales_history_base_queryset(request):
    """Base Sales History queryset with global material filters applied."""
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
    return BillingTransactionService.list_sales_history(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="list")
@extend_schema_view(get=extend_schema(operation_id="api_billing_transaction_sales_history_list"))
class SalesHistoryView(generics.ListAPIView):
    """
    Sales History list for the last 90 days (invc_date).
    Excludes credits/returns (sales_contr_qty <= 0).
    Supports global filters, ordering, and pagination.
    """
    serializer_class = SalesHistorySerializer
    filterset_class = SalesHistoryFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = SALES_HISTORY_ORDERING_FIELDS
    ordering = SALES_HISTORY_DEFAULT_ORDERING
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        return get_sales_history_base_queryset(self.request)


class SalesHistoryExportView(CsvExportView):
    """
    Stream Sales History as CSV for all rows matching the current filters.
    Reuses the list queryset/filters/ordering; ignores limit/offset.
    """

    filename_prefix = "sales_history"
    filterset_class = SalesHistoryFilter
    ordering_fields = SALES_HISTORY_ORDERING_FIELDS
    default_ordering = SALES_HISTORY_DEFAULT_ORDERING
    export_identity_fields = ["id"]

    @extend_schema(
        operation_id="api_billing_transaction_sales_history_export",
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_base_queryset(self, request):
        return get_sales_history_base_queryset(request)

    def iter_csv_rows(self, queryset):
        return BillingTransactionService.iter_sales_history_csv_rows(queryset)
