from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework import generics
from rest_framework.filters import OrderingFilter

from api.global_filters import get_filtered_material_subquery
from api.pagination import MaxLimitOffsetPagination

from .filters import SalesHistoryFilter
from .serializers import SalesHistorySerializer
from .services import BillingTransactionService


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="list")
@extend_schema_view(get=extend_schema(operation_id="api_billing_transaction_sales_history_list"))
class SalesHistoryView(generics.ListAPIView):
    """
    Sales History list for the last 90 days (invc_date).
    Excludes credits/returns (sales_contr_qty <= 0).
    Supports global filters, ordering, and pagination.
    """
    serializer_class = SalesHistorySerializer
    filterset_class = SalesHistoryFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = [
        "material_number",
        "material_name",
        "ndc",
        "invoice_date",
        "invoice_number",
        "sales_quantity",
        "sales_amount",
        "contract_type",
    ]
    ordering = ["-invoice_date", "invoice_number", "material_number"]
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return BillingTransactionService.list_sales_history(direct_mat_nbr, mat_nbr_subquery)
