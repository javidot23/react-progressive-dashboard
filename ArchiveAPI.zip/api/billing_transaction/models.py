from django.db import models

from api.material.models import Material


class BillingTransaction(models.Model):
    ord_nbr = models.CharField(max_length=255)
    ord_line_nbr = models.CharField(max_length=255)
    ord_created_date = models.DateField(null=True, blank=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    invc_nbr = models.CharField(max_length=255, null=True, blank=True)
    invc_date = models.DateField(null=True, blank=True)
    sales_contr_amt = models.DecimalField(max_digits=38, decimal_places=6, null=True, blank=True)
    sales_contr_qty = models.DecimalField(max_digits=18, decimal_places=3, null=True, blank=True)
    sales_less_cred_qty = models.BigIntegerField(null=True, blank=True)
    ship_plant = models.CharField(max_length=255, null=True, blank=True)
    sales_group = models.CharField(max_length=255, null=True, blank=True)
    hist_gpo_rpt_id_key = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "billing_transactions"
        verbose_name = "Billing Transaction"
        verbose_name_plural = "Billing Transactions"
        unique_together = [("ord_nbr", "ord_line_nbr", "invc_nbr")]
        indexes = [
            models.Index(fields=["ord_nbr"]),
            models.Index(fields=["ord_created_date"]),
            models.Index(fields=["invc_date"]),
            models.Index(fields=["material"]),
            models.Index(fields=["invc_nbr", "material"]),
        ]
