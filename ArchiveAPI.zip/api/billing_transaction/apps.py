from django.apps import AppConfig


class BillingTransactionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.billing_transaction"
