from datetime import date

from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class BillingTransactionModelTest(BaseTestCase):

    def test_create_billing_transaction(self):
        vendor = TestDataFactory.create_vendor()
        bt = TestDataFactory.create_billing_transaction(
            vendor=vendor,
            ord_nbr="ORD1234567",
            ord_line_nbr="001",
            ord_created_date=date(2025, 1, 15),
            sales_contr_amt=1000.0,
            sales_contr_qty=10.0,
        )
        self.assertEqual(bt.ord_nbr, "ORD1234567")
        self.assertEqual(bt.ord_line_nbr, "001")
        self.assertEqual(bt.ord_created_date, date(2025, 1, 15))
        self.assertEqual(bt.material.vendor, vendor)

    def test_unique_together_ord_nbr_ord_line_nbr(self):
        from django.db import IntegrityError
        vendor = TestDataFactory.create_vendor()
        TestDataFactory.create_billing_transaction(
            vendor=vendor, ord_nbr="ORD9999999", ord_line_nbr="001", invc_nbr="INV1234567"
        )
        with self.assertRaises(IntegrityError):
            TestDataFactory.create_billing_transaction(
                vendor=vendor, ord_nbr="ORD9999999", ord_line_nbr="001", invc_nbr="INV1234567"
            )
