from datetime import date, timedelta
from decimal import Decimal

from api.billing_transaction.models import BillingTransaction
from api.billing_transaction.services import BillingTransactionService
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class BillingTransactionServiceTest(BaseTestCase):
    def test_list_sales_history_returns_annotated_fields(self):
        BillingTransaction.objects.all().delete()
        today = date.today()
        material = TestDataFactory.create_material(name="Sales Mat", ndc="11122233344")

        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-SH-001",
            invc_date=today - timedelta(days=5),
            sales_contr_qty=Decimal("12.500"),
            sales_contr_amt=Decimal("250.125000"),
        )

        result = list(BillingTransactionService.list_sales_history())

        self.assertEqual(len(result), 1)
        row = result[0]
        self.assertEqual(row.material_number, material.mat_nbr)
        self.assertEqual(row.material_name, "Sales Mat")
        self.assertEqual(row.ndc, "11122233344")
        self.assertEqual(row.invoice_date, today - timedelta(days=5))
        self.assertEqual(row.invoice_number, "INV-SH-001")
        self.assertEqual(row.sales_quantity, Decimal("12.500"))
        self.assertEqual(row.sales_amount, Decimal("250.125000"))

    def test_list_sales_history_excludes_out_of_window_and_null_invc_date(self):
        BillingTransaction.objects.all().delete()
        today = date.today()
        material = TestDataFactory.create_material()

        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-IN",
            invc_date=today - timedelta(days=10),
            sales_contr_qty=Decimal("5.0"),
        )
        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-OUT",
            invc_date=today - timedelta(days=100),
            sales_contr_qty=Decimal("5.0"),
        )
        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-NULL",
            invc_date=None,
            sales_contr_qty=Decimal("5.0"),
        )

        result = list(BillingTransactionService.list_sales_history())

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].invoice_number, "INV-IN")

    def test_list_sales_history_excludes_credits(self):
        BillingTransaction.objects.all().delete()
        today = date.today()
        material = TestDataFactory.create_material()

        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-POS",
            invc_date=today - timedelta(days=3),
            sales_contr_qty=Decimal("10.0"),
        )
        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-ZERO",
            invc_date=today - timedelta(days=3),
            sales_contr_qty=Decimal("0"),
        )
        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-NEG",
            invc_date=today - timedelta(days=3),
            sales_contr_qty=Decimal("-5.0"),
        )

        result = list(BillingTransactionService.list_sales_history())

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].invoice_number, "INV-POS")

    def test_list_sales_history_filters_by_material(self):
        BillingTransaction.objects.all().delete()
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        TestDataFactory.create_billing_transaction(
            material=material1,
            invc_nbr="INV-M1",
            invc_date=today - timedelta(days=2),
            sales_contr_qty=Decimal("1.0"),
        )
        TestDataFactory.create_billing_transaction(
            material=material2,
            invc_nbr="INV-M2",
            invc_date=today - timedelta(days=2),
            sales_contr_qty=Decimal("1.0"),
        )

        result = list(
            BillingTransactionService.list_sales_history(direct_mat_nbr=material1.mat_nbr)
        )

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].invoice_number, "INV-M1")
