from datetime import date, timedelta
from decimal import Decimal

from django.urls.base import reverse

from api.billing_transaction.models import BillingTransaction
from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class SalesHistoryIntegrationTest(BaseAPITestCase):
    def setUp(self):
        super().setUp()
        user = TestDataFactory.create_test_user()
        self.client.force_authenticate(user=user, token="test-token")
        BillingTransaction.objects.all().delete()

    def test_sales_history_view_list_shape_and_pagination(self):
        today = date.today()
        material = TestDataFactory.create_material(name="Hist Mat", ndc="55566677788")

        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-VIEW-1",
            invc_date=today - timedelta(days=7),
            sales_contr_qty=Decimal("20.000"),
            sales_contr_amt=Decimal("400.000000"),
            sales_group="WAG",
        )
        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-VIEW-2",
            invc_date=today - timedelta(days=7),
            sales_contr_qty=Decimal("20.000"),
            sales_contr_amt=Decimal("400.000000"),
            sales_group="3rd Party",
        )

        url = reverse("billing-transaction:sales-history")
        response = self.client.get(url, {"limit": 10, "offset": 0})

        self.assertEqual(response.status_code, 200)
        self.assertIn("results", response.data)
        self.assertIn("count", response.data)
        self.assertGreaterEqual(response.data["count"], 1)

        required_fields = [
            "material_number",
            "material_name",
            "ndc",
            "invoice_date",
            "invoice_number",
            "sales_quantity",
            "sales_amount",
            "contract_type",
        ]
        matching = [r for r in response.data["results"] if r["invoice_number"] == "INV-VIEW-1"]
        self.assertEqual(len(matching), 1)
        row = matching[0]
        for field in required_fields:
            self.assertIn(field, row)
        self.assertEqual(row["material_name"], "Hist Mat")
        self.assertEqual(row["ndc"], "55566677788")
        self.assertEqual(row["material_number"], material.mat_nbr)
        self.assertEqual(Decimal(str(row["sales_quantity"])), Decimal("20.000"))
        self.assertEqual(Decimal(str(row["sales_amount"])), Decimal("400.000000"))
        self.assertEqual(row["contract_type"], "WAG")

    def test_sales_history_view_excludes_credits_and_old_rows(self):
        today = date.today()
        material = TestDataFactory.create_material()

        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-KEEP",
            invc_date=today - timedelta(days=1),
            sales_contr_qty=Decimal("8.0"),
        )
        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-CREDIT",
            invc_date=today - timedelta(days=1),
            sales_contr_qty=Decimal("0"),
        )
        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-OLD",
            invc_date=today - timedelta(days=120),
            sales_contr_qty=Decimal("8.0"),
        )

        url = reverse("billing-transaction:sales-history")
        response = self.client.get(url, {"limit": 50, "offset": 0})

        self.assertEqual(response.status_code, 200)
        invoice_numbers = {r["invoice_number"] for r in response.data["results"]}
        self.assertIn("INV-KEEP", invoice_numbers)
        self.assertNotIn("INV-CREDIT", invoice_numbers)
        self.assertNotIn("INV-OLD", invoice_numbers)

    def test_sales_history_view_ordering(self):
        today = date.today()
        material = TestDataFactory.create_material()

        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-AMT-LOW",
            invc_date=today - timedelta(days=4),
            sales_contr_qty=Decimal("1.0"),
            sales_contr_amt=Decimal("10.000000"),
        )
        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-AMT-HIGH",
            invc_date=today - timedelta(days=4),
            sales_contr_qty=Decimal("1.0"),
            sales_contr_amt=Decimal("90.000000"),
        )

        url = reverse("billing-transaction:sales-history")
        response = self.client.get(url, {
            "material_id": material.id,
            "ordering": "-sales_amount",
            "limit": 10,
            "offset": 0,
        })

        self.assertEqual(response.status_code, 200)
        results = response.data["results"]
        self.assertGreaterEqual(len(results), 2)
        self.assertEqual(results[0]["invoice_number"], "INV-AMT-HIGH")
        self.assertEqual(results[1]["invoice_number"], "INV-AMT-LOW")

    def test_sales_history_view_invoice_number_filter(self):
        today = date.today()
        material = TestDataFactory.create_material()

        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-FILTER-A",
            invc_date=today - timedelta(days=2),
            sales_contr_qty=Decimal("3.0"),
        )
        TestDataFactory.create_billing_transaction(
            material=material,
            invc_nbr="INV-FILTER-B",
            invc_date=today - timedelta(days=2),
            sales_contr_qty=Decimal("3.0"),
        )

        url = reverse("billing-transaction:sales-history")
        response = self.client.get(url, {
            "invoice_number": "INV-FILTER-A",
            "limit": 10,
            "offset": 0,
        })

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data["results"]), 1)
        self.assertEqual(response.data["results"][0]["invoice_number"], "INV-FILTER-A")

    def test_sales_history_multiple_ndc_filter(self):
        today = date.today()
        mat_a = TestDataFactory.create_material(ndc="11111111111")
        mat_b = TestDataFactory.create_material(ndc="22222222222")
        mat_c = TestDataFactory.create_material(ndc="33333333333")
        for material, invc in (
            (mat_a, "INV-NDC-A"),
            (mat_b, "INV-NDC-B"),
            (mat_c, "INV-NDC-C"),
        ):
            TestDataFactory.create_billing_transaction(
                material=material,
                invc_nbr=invc,
                invc_date=today - timedelta(days=1),
                sales_contr_qty=Decimal("5.0"),
            )

        url = reverse("billing-transaction:sales-history")
        response = self.client.get(url, {
            "ndc": "11111111111,22222222222",
            "limit": 20,
            "offset": 0,
        })

        self.assertEqual(response.status_code, 200)
        ndcs = {r["ndc"] for r in response.data["results"]}
        self.assertEqual(ndcs, {"11111111111", "22222222222"})
        self.assertNotIn("33333333333", ndcs)
