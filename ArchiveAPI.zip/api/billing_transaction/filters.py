from django_filters import CharFilter, NumberFilter
from django_filters.rest_framework import FilterSet

from api.billing_transaction.models import BillingTransaction
from api.global_filters import GlobalFilterForRelatedMaterialMixin


class SalesHistoryFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """FilterSet for Sales History list (BillingTransaction)."""

    invoice_number = CharFilter(field_name="invc_nbr", lookup_expr="iexact")
    material_id = CharFilter(field_name="material__id", lookup_expr="iexact")
    contract_type = CharFilter(field_name="sales_group", lookup_expr="iexact")
    sales_quantity_min = NumberFilter(field_name="sales_quantity", lookup_expr="gte")
    sales_quantity_max = NumberFilter(field_name="sales_quantity", lookup_expr="lte")
    sales_amount_min = NumberFilter(field_name="sales_amount", lookup_expr="gte")
    sales_amount_max = NumberFilter(field_name="sales_amount", lookup_expr="lte")

    class Meta:
        model = BillingTransaction
        fields = []
