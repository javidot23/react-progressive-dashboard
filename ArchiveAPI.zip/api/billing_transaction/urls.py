from django.urls import path

from .views import SalesHistoryExportView, SalesHistoryView

app_name = "billing-transaction"

urlpatterns = [
    path("sales-history/export/", SalesHistoryExportView.as_view(), name="sales-history-export"),
    path("sales-history/", SalesHistoryView.as_view(), name="sales-history"),
]
