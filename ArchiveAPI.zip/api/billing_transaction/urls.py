from django.urls import path

from .views import SalesHistoryView

app_name = "billing-transaction"

urlpatterns = [
    path("sales-history/", SalesHistoryView.as_view(), name="sales-history"),
]
