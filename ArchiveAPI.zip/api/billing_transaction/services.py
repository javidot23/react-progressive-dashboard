import logging
from datetime import date, timedelta

from django.db.models import F

from api.billing_transaction.models import BillingTransaction

logger = logging.getLogger(__name__)


class BillingTransactionService:
    """Service class for Billing Transaction related operations."""

    @staticmethod
    def list_sales_history(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        List sales history lines for the last 90 days.

        Uses invc_date within the last 90 days (non-null) and excludes credits/returns
        (sales_contr_qty <= 0), matching chargeback generation-status conventions.
        """
        logger.info("Retrieving sales history for last 90 days by invc_date")

        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        queryset = BillingTransaction.objects.filter(
            invc_date__range=[start_date, end_date],
            invc_date__isnull=False,
            sales_contr_qty__gt=0,
        )
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        return (
            queryset
            .select_related("material")
            .annotate(
                material_number=F("material__mat_nbr"),
                material_name=F("material__name"),
                ndc=F("material__ndc"),
                invoice_date=F("invc_date"),
                invoice_number=F("invc_nbr"),
                sales_quantity=F("sales_contr_qty"),
                sales_amount=F("sales_contr_amt"),
                contract_type=F("sales_group"),
            )
            .order_by("-invoice_date", "invoice_number", "material_number")
        )
