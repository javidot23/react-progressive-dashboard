from django.apps import AppConfig

from config.db_scope import DBScope


class UserSettingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.user_setting'
    db_scope = DBScope.CORE
