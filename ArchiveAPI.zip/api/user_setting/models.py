from django.db import models

from api.user.models import User


class UserSetting(models.Model):
    """
    Model to store user settings.
    """
    user_id = models.OneToOneField(User, on_delete=models.CASCADE, related_name="settings")
    is_dark_mode = models.BooleanField(default=False)
    is_email_notifications_enabled = models.BooleanField(default=True)
    is_push_notifications_enabled = models.BooleanField(default=True)
    inbound_service_level_target = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        default=90
    )
    products_omit_goal = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        default=85
    )
    risk_threshold = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        null=True,
        blank=True,
        default=80,
        help_text="User-defined threshold for Value at Risk display in UI. Does not affect API calculations."
    )
    days_on_hand = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        default=95,
        help_text="User-defined goal for Days On Hand in UI."
    )

    class Meta:
        db_table = "user_settings"
        app_label = "user_setting"
        verbose_name = "User Setting"
        verbose_name_plural = "User Settings"
        indexes = [
            models.Index(fields=["user_id"]),
        ]
