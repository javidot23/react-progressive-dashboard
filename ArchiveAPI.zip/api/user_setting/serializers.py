from decimal import Decimal, InvalidOperation

from rest_framework import serializers

from .models import UserSetting


class UserSettingSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserSetting
        fields = (
            "inbound_service_level_target",
            "products_omit_goal",
            "risk_threshold",
            "days_on_hand",
        )

    def validate_inbound_service_level_target(self, value: Decimal | None) -> Decimal | None:
        if value is None:
            return None
        return self._validate_percentage(value, "inbound_service_level_target")

    def validate_products_omit_goal(self, value: Decimal | None) -> Decimal | None:
        if value is None:
            return None
        return self._validate_percentage(value, "products_omit_goal")

    def validate_risk_threshold(self, value: Decimal | None) -> Decimal | None:
        if value is None:
            return None
        try:
            decimal_value = Decimal(value)
        except (InvalidOperation, TypeError):
            raise serializers.ValidationError("Enter a valid number")

        if decimal_value < 0:
            raise serializers.ValidationError("Value must be non-negative")

        return decimal_value

    def validate_days_on_hand(self, value: Decimal | None) -> Decimal | None:
        if value is None:
            return None
        return self._validate_percentage(value, "days_on_hand")

    def _validate_percentage(self, value: Decimal, field_name: str) -> Decimal:
        try:
            decimal_value = Decimal(value)
        except (InvalidOperation, TypeError):
            raise serializers.ValidationError("Enter a valid number")

        if decimal_value < 0 or decimal_value > 100:
            raise serializers.ValidationError("Value must be between 0 and 100")

        return decimal_value
