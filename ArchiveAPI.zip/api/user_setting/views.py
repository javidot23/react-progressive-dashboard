import logging

from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.decorators.vary import vary_on_headers
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema, extend_schema_view

from api.audit.choices import AuditEventType
from api.audit.services import AuditService

from .models import UserSetting
from .serializers import UserSettingSerializer

logger = logging.getLogger(__name__)


@method_decorator(never_cache, name='dispatch')
@method_decorator(vary_on_headers('Authorization'), name='dispatch')
@extend_schema_view(
    get=extend_schema(responses=UserSettingSerializer),
    put=extend_schema(
        request=UserSettingSerializer,
        responses=UserSettingSerializer,
    ),
    patch=extend_schema(
        request=UserSettingSerializer,
        responses=UserSettingSerializer,
    ),
)
class MyUserSettingView(APIView):
    """Retrieve and update the authenticated user's settings."""

    @staticmethod
    def _get_cache_key(user):
        """Generate cache key for user settings."""
        return f"user_settings:{user.pk}"

    @staticmethod
    def _invalidate_user_settings_cache(user):
        """Invalidate cached user settings."""
        cache_key = MyUserSettingView._get_cache_key(user)
        cache.delete(cache_key)
        logger.debug("Invalidated user settings cache for user: %s", user.pk)

    def get(self, request):
        user = request.user
        cache_key = self._get_cache_key(user)

        # Check cache first
        cached_settings = cache.get(cache_key)
        if cached_settings:
            logger.debug("Cache hit for user settings: %s", user.pk)
            return Response(cached_settings, status=status.HTTP_200_OK)

        # Cache miss - fetch from database
        settings_obj, _ = UserSetting.objects.get_or_create(user_id=user)
        serializer = UserSettingSerializer(settings_obj)
        settings_data = serializer.data

        # Cache for 15 minutes (same as user profile)
        cache.set(cache_key, settings_data, timeout=900)
        logger.debug("Cached user settings for user: %s", user.pk)

        return Response(settings_data, status=status.HTTP_200_OK)

    def put(self, request):
        user = request.user
        settings_obj, _ = UserSetting.objects.get_or_create(user_id=user)
        serializer = UserSettingSerializer(instance=settings_obj, data=request.data)
        if serializer.is_valid():
            serializer.save()
            # Invalidate cache after update
            self._invalidate_user_settings_cache(user)
            AuditService.record_from_request(
                request,
                AuditEventType.USER_SETTING_UPDATED,
                status=status.HTTP_200_OK,
                target_entity={"type": "user_setting", "id": str(settings_obj.pk)},
            )
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response({"errors": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request):
        user = request.user
        settings_obj, _ = UserSetting.objects.get_or_create(user_id=user)
        serializer = UserSettingSerializer(instance=settings_obj, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            # Invalidate cache after update
            self._invalidate_user_settings_cache(user)
            AuditService.record_from_request(
                request,
                AuditEventType.USER_SETTING_UPDATED,
                status=status.HTTP_200_OK,
                target_entity={"type": "user_setting", "id": str(settings_obj.pk)},
            )
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response({"errors": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
