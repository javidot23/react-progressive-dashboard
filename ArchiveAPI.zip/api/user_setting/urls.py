from django.urls import path

from .views import MyUserSettingView

app_name = "user_setting"

urlpatterns = [
    path("me/", MyUserSettingView.as_view(), name="my-settings"),
]
