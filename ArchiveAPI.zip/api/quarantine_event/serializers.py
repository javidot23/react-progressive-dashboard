from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers


class QuarantineEventSGTINSerializer(serializers.Serializer):
    material_id = serializers.SerializerMethodField()
    material_name = serializers.SerializerMethodField()
    ndc = serializers.SerializerMethodField()
    sgtin = serializers.SerializerMethodField()
    lead_time = serializers.IntegerField()
    original_created_date = serializers.DateField()

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_material_id(self, obj):
        return obj.material.mat_nbr if obj.material_id else None

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_material_name(self, obj):
        return obj.material.name if obj.material_id else None

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_ndc(self, obj):
        return obj.material.ndc if obj.material_id else None

    @extend_schema_field(serializers.CharField())
    def get_sgtin(self, obj):
        return f"{obj.gtin}{obj.serial_nbr}"


class QuarantineMovementSummarySerializer(serializers.Serializer):
    date = serializers.DateField()
    entered_quarantine = serializers.IntegerField()
    entered_quarantine_qty = serializers.IntegerField(allow_null=True)
    entered_quarantine_amt = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    current_quarantine = serializers.IntegerField()
    current_quarantine_qty = serializers.IntegerField(allow_null=True)
    current_quarantine_amt = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    returned_sgtins = serializers.IntegerField()
    returned_sgtins_qty = serializers.IntegerField(allow_null=True)
    returned_sgtins_amt = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    inventory_sgtins = serializers.IntegerField()
    inventory_sgtins_qty = serializers.IntegerField(allow_null=True)
    inventory_sgtins_amt = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)


class QuarantineDailySerializer(serializers.Serializer):
    event_date = serializers.DateField()
    entered_quarantine = serializers.IntegerField()
    current_quarantine = serializers.IntegerField()
    returned_sgtins = serializers.IntegerField()
    inventory_sgtins = serializers.IntegerField()
    cumulative_entered = serializers.IntegerField()
    cumulative_returned = serializers.IntegerField()
    cumulative_to_inventory = serializers.IntegerField()


class QuarantineTimelineSerializer(serializers.Serializer):
    summary = QuarantineMovementSummarySerializer()
    daily = QuarantineDailySerializer(many=True)


class QuarantineDetailSGTINSerializer(serializers.Serializer):
    process_date = serializers.DateField(source="original_created_date")
    sgtin = serializers.SerializerMethodField()

    @extend_schema_field(serializers.CharField())
    def get_sgtin(self, obj):
        return f"{obj.gtin}{obj.serial_nbr}"


class QuarantineMovementDetailSerializer(serializers.Serializer):
    date = serializers.DateField()
    entered = QuarantineDetailSGTINSerializer(many=True)
    current = QuarantineDetailSGTINSerializer(many=True)
    returned = QuarantineDetailSGTINSerializer(many=True)
    inventory = QuarantineDetailSGTINSerializer(many=True)


class QuarantineByMaterialSerializer(serializers.Serializer):
    material_id = serializers.SerializerMethodField()
    material_name = serializers.SerializerMethodField()
    entered_quarantine = serializers.IntegerField()
    entered_quarantine_amt = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    percentage = serializers.FloatField()
    current_quarantine = serializers.IntegerField()
    returned_sgtins = serializers.IntegerField()
    inventory_sgtins = serializers.IntegerField()

    @extend_schema_field(serializers.CharField())
    def get_material_id(self, obj):
        return obj["material__mat_nbr"]

    @extend_schema_field(serializers.CharField())
    def get_material_name(self, obj):
        return obj["material__name"]


class QuarantineByPlantSerializer(serializers.Serializer):
    plant_nbr = serializers.SerializerMethodField()
    distribution_center = serializers.SerializerMethodField()
    entered_quarantine = serializers.IntegerField()
    entered_quarantine_amt = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    percentage = serializers.FloatField()
    current_quarantine = serializers.IntegerField()
    returned_sgtins = serializers.IntegerField()
    inventory_sgtins = serializers.IntegerField()

    @extend_schema_field(serializers.CharField())
    def get_plant_nbr(self, obj):
        return obj["plant__plant_nbr"]

    @extend_schema_field(serializers.CharField())
    def get_distribution_center(self, obj):
        return obj["plant__name"]
