from django.urls import path

from .views import (
    QuarantineByMaterialView,
    QuarantineByPlantView,
    QuarantineMovementDetailView,
    QuarantineMovementTimelineView,
    QuarantineSGTINListView,
)

app_name = "quarantine"

urlpatterns = [
    path("sgtins/", QuarantineSGTINListView.as_view(), name="sgtin-list"),
    path("movement-timeline/", QuarantineMovementTimelineView.as_view(), name="movement-timeline"),
    path("movement-detail/", QuarantineMovementDetailView.as_view(), name="movement-detail"),
    path("by-material/", QuarantineByMaterialView.as_view(), name="by-material"),
    path("by-plant/", QuarantineByPlantView.as_view(), name="by-plant"),
]
