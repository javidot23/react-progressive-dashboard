from django.db import models

from api.material.models import Material
from api.plant.models import Plant


class QuarantineEvent(models.Model):
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
    )
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.DO_NOTHING,
    )
    gtin = models.CharField(max_length=255)
    serial_nbr = models.CharField(max_length=255)
    quarantine_action = models.CharField(max_length=255)
    status_code = models.CharField(max_length=255)
    original_created_date = models.DateField()
    lead_time = models.IntegerField()
    total_zwac_amt = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True)
    total_units = models.IntegerField(null=True, blank=True, default=0, db_column="total_units")
    sum_po_qty = models.IntegerField(null=True, blank=True, default=0, db_column="sum_po_qty")
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    class Meta:
        db_table = "quarantine_events"
        verbose_name = "Quarantine Event"
        verbose_name_plural = "Quarantine Events"
        unique_together = [("gtin", "serial_nbr")]
        indexes = [
            models.Index(fields=["material"]),
            models.Index(fields=["plant"]),
            models.Index(fields=["original_created_date"]),
            models.Index(fields=["quarantine_action"]),
            models.Index(fields=["status_code"]),
        ]
