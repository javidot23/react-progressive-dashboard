from django.apps import AppConfig


class QuarantineEventConfig(AppConfig):
    name = 'api.quarantine_event'
