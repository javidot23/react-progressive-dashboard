from datetime import date

from django.conf import settings
from django.utils.dateparse import parse_date
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics
from rest_framework.exceptions import ValidationError
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.global_filters import get_filtered_material_subquery
from api.quarantine_event.filters import QuarantineEventFilter
from api.quarantine_event.serializers import (
    QuarantineByMaterialSerializer,
    QuarantineByPlantSerializer,
    QuarantineEventSGTINSerializer,
    QuarantineMovementDetailSerializer,
    QuarantineTimelineSerializer,
)
from api.quarantine_event.services import QuarantineEventService
from api.pagination import MaxLimitOffsetPagination

_VALID_TABS = {"entered", "current", "returned", "inventory"}


def _parse_days(request, default=7):
    raw = request.query_params.get("days", str(default))
    try:
        return int(raw)
    except (TypeError, ValueError):
        raise ValidationError({"days": "Must be an integer."})


def _parse_date_param(request):
    raw = request.query_params.get("date")
    if not raw:
        return date.today()
    parsed = parse_date(raw)
    if not parsed:
        raise ValidationError({"date": "Invalid date format. Use YYYY-MM-DD."})
    return parsed


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="list")
class QuarantineSGTINListView(generics.ListAPIView):
    """Tabbed SGTIN movements table — entered / current / returned / inventory."""

    serializer_class = QuarantineEventSGTINSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = QuarantineEventFilter
    ordering_fields = ["original_created_date", "lead_time", "material__mat_nbr"]
    ordering = ["-original_created_date"]

    def get_queryset(self):
        tab = self.request.query_params.get("tab", "entered")
        if tab not in _VALID_TABS:
            raise ValidationError({"tab": f"Must be one of: {', '.join(sorted(_VALID_TABS))}."})
        days = _parse_days(self.request)
        return QuarantineEventService.list_sgtins(tab=tab, days=days)


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="get")
class QuarantineMovementTimelineView(APIView):
    """Summary counts for a reference date + daily breakdown for the last `days` days."""

    @extend_schema(responses=QuarantineTimelineSerializer)
    def get(self, request):
        reference_date = _parse_date_param(request)
        days = _parse_days(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = QuarantineEventService.get_movement_timeline(
            reference_date=reference_date,
            days=days,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = QuarantineTimelineSerializer(data)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="get")
class QuarantineMovementDetailView(APIView):
    """Individual SGTINs for a specific date grouped by movement type (chart bar click)."""

    @extend_schema(responses=QuarantineMovementDetailSerializer)
    def get(self, request):
        raw_date = request.query_params.get("date")
        if not raw_date:
            raise ValidationError({"date": "This parameter is required."})
        reference_date = parse_date(raw_date)
        if not reference_date:
            raise ValidationError({"date": "Invalid date format. Use YYYY-MM-DD."})

        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = QuarantineEventService.get_movement_detail(
            reference_date=reference_date,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        serializer = QuarantineMovementDetailSerializer(data)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="list")
class QuarantineByMaterialView(generics.ListAPIView):
    """Per-material % inventory resolution rate for a specific date."""

    serializer_class = QuarantineByMaterialSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        days = _parse_days(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return QuarantineEventService.list_by_material(
            days=days,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="list")
class QuarantineByPlantView(generics.ListAPIView):
    """Per-DC % inventory resolution rate for a specific date."""

    serializer_class = QuarantineByPlantSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        days = _parse_days(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return QuarantineEventService.list_by_plant(
            days=days,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
