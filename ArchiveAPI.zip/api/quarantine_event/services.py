import logging
from datetime import date, timedelta

from django.db.models import Case, Count, DecimalField, ExpressionWrapper, F, FloatField, IntegerField, Sum, Value, When
from django.db.models.functions import Coalesce

from api.quarantine_event.models import QuarantineEvent

logger = logging.getLogger(__name__)

IN_QUARANTINE = "In Quarantine"
RETURN_TO_SUPPLIER = "Return to Supplier"
RELEASE_TO_INVENTORY = "Release to Inventory"


class QuarantineEventService:

    @staticmethod
    def _apply_mat_nbr_filter(queryset, direct_mat_nbr=None, mat_nbr_subquery=None):
        if direct_mat_nbr:
            return queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            return queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
        return queryset

    @staticmethod
    def list_sgtins(tab, days=7):
        """
        Base queryset for the SGTIN movements tabbed table.
        Global material filters are applied by the view's FilterSet.
        tab: 'entered' | 'current' | 'returned' | 'inventory'
        days: lookback window for the 'entered' tab (default 7).
        """
        logger.info("Listing SGTINs, tab=%s, days=%s", tab, days)
        qs = QuarantineEvent.objects.select_related("material", "plant")

        if tab == "entered":
            qs = qs.filter(original_created_date__gte=date.today() - timedelta(days=days))
        elif tab == "current":
            qs = qs.filter(quarantine_action=IN_QUARANTINE)
        elif tab == "returned":
            qs = qs.filter(quarantine_action=RETURN_TO_SUPPLIER)
        elif tab == "inventory":
            qs = qs.filter(quarantine_action=RELEASE_TO_INVENTORY)

        return qs

    @staticmethod
    def get_movement_timeline(reference_date=None, days=7, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Summary counts for reference_date and daily breakdown for the last `days` days.
        reference_date defaults to today.
        """
        if reference_date is None:
            reference_date = date.today()

        logger.info("Getting movement timeline, date=%s, days=%s", reference_date, days)

        cutoff = reference_date - timedelta(days=days - 1)

        qs = QuarantineEvent.objects.filter(
            original_created_date__gte=cutoff,
            original_created_date__lte=reference_date,
        )
        qs = QuarantineEventService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)

        summary = qs.filter(original_created_date=reference_date).aggregate(
            entered_quarantine=Count("id"),
            entered_quarantine_qty=Coalesce(Sum("total_units"), Value(0), output_field=IntegerField()),
            entered_quarantine_amt=Coalesce(Sum("total_zwac_amt"), Value(0), output_field=DecimalField()),
            current_quarantine=Count(
                Case(When(quarantine_action=IN_QUARANTINE, then=1), output_field=IntegerField())
            ),
            current_quarantine_qty=Coalesce(
                Sum(Case(When(quarantine_action=IN_QUARANTINE, then=F("total_units")), output_field=IntegerField())),
                Value(0), output_field=IntegerField(),
            ),
            current_quarantine_amt=Coalesce(
                Sum(Case(When(
                    quarantine_action=IN_QUARANTINE,
                    then=F("total_zwac_amt")),
                    output_field=DecimalField())),
                Value(0), output_field=DecimalField(),
            ),
            returned_sgtins=Count(
                Case(When(quarantine_action=RETURN_TO_SUPPLIER, then=1), output_field=IntegerField())
            ),
            returned_sgtins_qty=Coalesce(
                Sum(Case(When(quarantine_action=RETURN_TO_SUPPLIER, then=F("total_units")),
                         output_field=IntegerField())),
                Value(0), output_field=IntegerField(),
            ),
            returned_sgtins_amt=Coalesce(
                Sum(Case(When(quarantine_action=RETURN_TO_SUPPLIER, then=F("total_zwac_amt")),
                         output_field=DecimalField())),
                Value(0), output_field=DecimalField(),
            ),
            inventory_sgtins=Count(
                Case(When(quarantine_action=RELEASE_TO_INVENTORY, then=1), output_field=IntegerField())
            ),
            inventory_sgtins_qty=Coalesce(
                Sum(Case(When(quarantine_action=RELEASE_TO_INVENTORY, then=F("total_units")),
                         output_field=IntegerField())),
                Value(0), output_field=IntegerField(),
            ),
            inventory_sgtins_amt=Coalesce(
                Sum(Case(When(quarantine_action=RELEASE_TO_INVENTORY, then=F("total_zwac_amt")),
                         output_field=DecimalField())),
                Value(0), output_field=DecimalField(),
            ),
        )
        summary["date"] = reference_date

        daily_rows = (
            qs
            .values("original_created_date")
            .annotate(
                entered_quarantine=Count("id"),
                current_quarantine=Count(
                    Case(When(quarantine_action=IN_QUARANTINE, then=1), output_field=IntegerField())
                ),
                returned_sgtins=Count(
                    Case(When(quarantine_action=RETURN_TO_SUPPLIER, then=1), output_field=IntegerField())
                ),
                inventory_sgtins=Count(
                    Case(When(quarantine_action=RELEASE_TO_INVENTORY, then=1), output_field=IntegerField())
                ),
            )
            .order_by("original_created_date")
        )

        # Cumulative sums computed in Python to avoid window function complexity
        daily = []
        cum_entered = cum_returned = cum_inventory = 0
        for row in daily_rows:
            cum_entered += row["entered_quarantine"]
            cum_returned += row["returned_sgtins"]
            cum_inventory += row["inventory_sgtins"]
            daily.append({
                "event_date": row["original_created_date"],
                "entered_quarantine": row["entered_quarantine"],
                "current_quarantine": row["current_quarantine"],
                "returned_sgtins": row["returned_sgtins"],
                "inventory_sgtins": row["inventory_sgtins"],
                "cumulative_entered": cum_entered,
                "cumulative_returned": cum_returned,
                "cumulative_to_inventory": cum_inventory,
            })

        return {"summary": summary, "daily": daily}

    @staticmethod
    def get_movement_detail(reference_date, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        All individual SGTINs for a specific date, grouped by movement type.
        """
        logger.info("Getting movement detail, date=%s", reference_date)
        qs = QuarantineEvent.objects.filter(original_created_date=reference_date)
        qs = QuarantineEventService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)

        all_events = list(qs)
        return {
            "date": reference_date,
            "entered": all_events,
            "current": [e for e in all_events if e.quarantine_action == IN_QUARANTINE],
            "returned": [e for e in all_events if e.quarantine_action == RETURN_TO_SUPPLIER],
            "inventory": [e for e in all_events if e.quarantine_action == RELEASE_TO_INVENTORY],
        }

    @staticmethod
    def list_by_material(days=7, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Per-material % inventory resolution rate for the last `days` days.
        percentage = COUNT(Release to Inventory) / COUNT(*) × 100
        """
        cutoff = date.today() - timedelta(days=days - 1)
        logger.info("Listing by material, days=%s, cutoff=%s", days, cutoff)

        qs = QuarantineEvent.objects.filter(original_created_date__gte=cutoff)
        qs = QuarantineEventService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)

        return (
            qs
            .values("material__mat_nbr", "material__name")
            .annotate(
                entered_quarantine=Count("id"),
                entered_quarantine_amt=Coalesce(Sum("total_zwac_amt"), Value(0), output_field=DecimalField()),
                current_quarantine=Count(
                    Case(When(quarantine_action=IN_QUARANTINE, then=1), output_field=IntegerField())
                ),
                returned_sgtins=Count(
                    Case(When(quarantine_action=RETURN_TO_SUPPLIER, then=1), output_field=IntegerField())
                ),
                inventory_sgtins=Count(
                    Case(When(quarantine_action=RELEASE_TO_INVENTORY, then=1), output_field=IntegerField())
                ),
            )
            .annotate(
                percentage=ExpressionWrapper(
                    100.0 * F("inventory_sgtins") / F("entered_quarantine"),
                    output_field=FloatField(),
                )
            )
            .order_by("-percentage")
        )

    @staticmethod
    def list_by_plant(days=7, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Per-DC % inventory resolution rate for the last `days` days.
        percentage = COUNT(Release to Inventory) / COUNT(*) × 100
        """
        cutoff = date.today() - timedelta(days=days - 1)
        logger.info("Listing by plant, days=%s, cutoff=%s", days, cutoff)

        qs = QuarantineEvent.objects.filter(original_created_date__gte=cutoff)
        qs = QuarantineEventService._apply_mat_nbr_filter(qs, direct_mat_nbr, mat_nbr_subquery)

        return (
            qs
            .values("plant__plant_nbr", "plant__name")
            .annotate(
                entered_quarantine=Count("id"),
                entered_quarantine_amt=Coalesce(Sum("total_zwac_amt"), Value(0), output_field=DecimalField()),
                current_quarantine=Count(
                    Case(When(quarantine_action=IN_QUARANTINE, then=1), output_field=IntegerField())
                ),
                returned_sgtins=Count(
                    Case(When(quarantine_action=RETURN_TO_SUPPLIER, then=1), output_field=IntegerField())
                ),
                inventory_sgtins=Count(
                    Case(When(quarantine_action=RELEASE_TO_INVENTORY, then=1), output_field=IntegerField())
                ),
            )
            .annotate(
                percentage=ExpressionWrapper(
                    100.0 * F("inventory_sgtins") / F("entered_quarantine"),
                    output_field=FloatField(),
                )
            )
            .order_by("-percentage")
        )
