from django_filters import CharFilter, DateFilter, NumberFilter
from django_filters.rest_framework import FilterSet

from api.global_filters import GlobalFilterForRelatedMaterialMixin
from api.quarantine_event.models import QuarantineEvent


class QuarantineEventFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    plant_nbr = CharFilter(field_name="plant__plant_nbr", lookup_expr="iexact")
    quarantine_action = CharFilter(field_name="quarantine_action", lookup_expr="iexact")
    status_code = CharFilter(field_name="status_code", lookup_expr="iexact")
    date_from = DateFilter(field_name="original_created_date", lookup_expr="gte")
    date_to = DateFilter(field_name="original_created_date", lookup_expr="lte")
    lead_time_min = NumberFilter(field_name="lead_time", lookup_expr="gte")
    lead_time_max = NumberFilter(field_name="lead_time", lookup_expr="lte")

    class Meta:
        model = QuarantineEvent
        fields = []
