from tests.BaseTestCase import BaseTestCase

from tests.TestDataFactory import TestDataFactory


class PlantModelTest(BaseTestCase):
    def setUp(self):
        """Set up test data for plant model tests."""
        self.plant_nbr = "P1234"
        self.name = "Test Plant"
        self.default_lead_time = 10.5
        self.city = "Test City"
        self.state = "TS"
        self.postal_code = "12345"
        self.longitude = -120.123456
        self.latitude = 35.123456
        self.coverage_zip_codes = ["12345", "67890"]

    def test_plant_creation(self):
        """Test basic plant creation."""
        plant = TestDataFactory.create_plant(
            plant_nbr=self.plant_nbr,
            name=self.name,
            default_lead_time=self.default_lead_time,
            city=self.city,
            state=self.state,
            postal_code=self.postal_code,
            longitude=self.longitude,
            latitude=self.latitude,
            coverage_zip_codes=self.coverage_zip_codes,
        )
        self.assertEqual(plant.plant_nbr, self.plant_nbr)
        self.assertEqual(plant.name, self.name)
        self.assertEqual(plant.default_lead_time, self.default_lead_time)
        self.assertEqual(plant.city, self.city)
        self.assertEqual(plant.state, self.state)
        self.assertEqual(plant.postal_code, self.postal_code)
        self.assertEqual(plant.longitude, self.longitude)
        self.assertEqual(plant.latitude, self.latitude)
        self.assertEqual(plant.coverage_zip_codes, self.coverage_zip_codes)
        self.assertIsNotNone(plant.created_at)
        self.assertIsNotNone(plant.updated_at)
