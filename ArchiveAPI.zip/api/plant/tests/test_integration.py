from django.urls import reverse
from rest_framework import status

from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class PlantIntegrationTest(BaseAPITestCase):
    def setUp(self):
        """Set up test data for plant integration tests."""
        self.plant1 = TestDataFactory.create_plant(plant_nbr="P001", name="Plant One")
        self.plant2 = TestDataFactory.create_plant(plant_nbr="P002", name="Plant Two")
        self.url = reverse("plant:list")

    def test_plant_list_view(self):
        """Test the plant list endpoint."""
        response = self.client.get(self.url, {"limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        results = response.data.get("results")
        self.assertEqual(len(results), 2)

        # Verify that the created plant data is in the response
        plant_nbrs = [item["plant_nbr"] for item in results]
        self.assertIn(self.plant1.plant_nbr, plant_nbrs)
        self.assertIn(self.plant2.plant_nbr, plant_nbrs)
        self.assertIn(self.plant1.name, [item["name"] for item in results])
        self.assertIn(self.plant2.name, [item["name"] for item in results])
        self.assertIn(self.plant1.default_lead_time, [item["default_lead_time"] for item in results])

    def test_plant_list_view_with_filters(self):
        """Test the plant list endpoint with filters."""
        response = self.client.get(self.url, {"name": "Plant One"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        results = response.data.get("results")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["plant_nbr"], self.plant1.plant_nbr)
        self.assertEqual(results[0]["name"], self.plant1.name)
        self.assertEqual(results[0]["default_lead_time"], self.plant1.default_lead_time)
        self.assertEqual(results[0]["city"], self.plant1.city)
        self.assertEqual(results[0]["state"], self.plant1.state)
        self.assertEqual(results[0]["postal_code"], self.plant1.postal_code)
        self.assertEqual(results[0]["longitude"], self.plant1.longitude)
        self.assertEqual(results[0]["latitude"], self.plant1.latitude)
        self.assertEqual(results[0]["coverage_zip_codes"], self.plant1.coverage_zip_codes)

    def test_plant_list_view_with_ordering(self):
        """Test the plant list endpoint with ordering."""
        response = self.client.get(self.url, {"ordering": "name", "limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        results = response.data.get("results")
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["name"], "Plant One")
        self.assertEqual(results[1]["name"], "Plant Two")

        response = self.client.get(self.url, {"ordering": "-name", "limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        results = response.data.get("results")
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["name"], "Plant Two")
        self.assertEqual(results[1]["name"], "Plant One")

    def test_plant_list_view_with_pagination(self):
        """Test the plant list endpoint with pagination."""
        response = self.client.get(self.url, {"limit": 1, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        results = response.data.get("results")
        self.assertEqual(len(results), 1)
        self.assertEqual(response.data.get("count"), 2)

        response = self.client.get(self.url, {"limit": 1, "offset": 1})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        results = response.data.get("results")
        self.assertEqual(len(results), 1)
        self.assertEqual(response.data.get("count"), 2)
