from tests.BaseTestCase import BaseTestCase

from api.plant.models import Plant
from api.plant.service import PlantService
from tests.TestDataFactory import TestDataFactory


class PlantServiceTest(BaseTestCase):
    def setUp(self):
        """Set up test data for plant service tests."""
        self.plant1 = TestDataFactory.create_plant(plant_nbr="P001", name="Plant One")
        self.plant2 = TestDataFactory.create_plant(plant_nbr="P002", name="Plant Two")

    def test_get_all_plants(self):
        """Test retrieving all plants."""
        plants = PlantService.get_all_plants()
        self.assertEqual(plants.count(), 2)
        self.assertIn(self.plant1, plants)
        self.assertIn(self.plant2, plants)

    def test_get_plant_by_id(self):
        """Test retrieving a single plant by its ID."""
        found_plant = PlantService.get_plant_by_id(self.plant1.id)
        self.assertEqual(found_plant, self.plant1)

    def test_get_plant_by_id_not_found(self):
        """Test retrieving a non-existent plant returns None."""
        # Get the last created ID and add 1 to ensure it doesn't exist
        non_existent_id = Plant.objects.latest("id").id + 1
        found_plant = PlantService.get_plant_by_id(non_existent_id)
        self.assertIsNone(found_plant)
