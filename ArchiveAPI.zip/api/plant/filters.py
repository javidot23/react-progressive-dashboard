from django_filters.rest_framework import FilterSet, filters


class PlantFilter(FilterSet):
    """Filter for plants."""
    plant_nbr = filters.CharFilter(lookup_expr='icontains')
    name = filters.CharFilter(lookup_expr='icontains')
    city = filters.CharFilter(lookup_expr='icontains')
    state = filters.CharFilter(lookup_expr='icontains')
    postal_code = filters.CharFilter(lookup_expr='icontains')
    coverage_zip_code = filters.CharFilter(lookup_expr='icontains', field_name='coverage_zip_codes')
    default_lead_time = filters.NumberFilter(lookup_expr='icontains')
    default_lead_time_min = filters.NumberFilter(field_name='default_lead_time', lookup_expr='gte')
    default_lead_time_max = filters.NumberFilter(field_name='default_lead_time', lookup_expr='lte')
