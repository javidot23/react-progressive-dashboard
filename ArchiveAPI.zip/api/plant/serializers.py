from rest_framework import serializers

from api.plant.models import Plant


class PlantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Plant
        fields = "__all__"


class Neo4jPlantSerializer(serializers.Serializer):
    """Serializer for Neo4j plant nodes."""
    node_id = serializers.IntegerField(source='id', read_only=True)
    labels = serializers.ListField(child=serializers.CharField(), read_only=True)
    id = serializers.CharField(source='properties.id', required=False, allow_null=True)
    name = serializers.CharField(source='properties.name', required=False, allow_null=True)
    city = serializers.CharField(source='properties.city', required=False, allow_null=True)
    state = serializers.CharField(source='properties.state', required=False, allow_null=True)
    postal_code = serializers.CharField(source='properties.postal_code', required=False, allow_null=True)
    longitude = serializers.FloatField(source='properties.longitude', required=False, allow_null=True)
    latitude = serializers.FloatField(source='properties.latitude', required=False, allow_null=True)
    properties = serializers.DictField(required=False, read_only=True)
