from django.urls import path

from .views import Neo4jPlantListView, PlantListView

app_name = "plant"

urlpatterns = [
    path("", PlantListView.as_view(), name="list"),
    path("from-graph/", Neo4jPlantListView.as_view(), name="neo4j-list"),
]
