import logging

from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, status
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.neo4j_graph_api.exceptions import Neo4jConnectionError, Neo4jQueryError
from api.neo4j_graph_api.services import Neo4jGraphService
from api.pagination import MaxLimitOffsetPagination
from api.plant.filters import PlantFilter
from api.plant.serializers import Neo4jPlantSerializer, PlantSerializer
from api.plant.service import PlantService

logger = logging.getLogger(__name__)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class PlantListView(generics.ListAPIView):
    """
    API view to retrieve a list of all plants.
    """
    serializer_class = PlantSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = PlantFilter
    ordering_fields = [
        'name', 'city', 'state', 'postal_code', 'default_lead_time',
    ]
    ordering = ['-name']

    def get_queryset(self):
        return PlantService.get_all_plants()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class Neo4jPlantListView(APIView):
    """
    API view to retrieve a list of plants from Neo4j graph database.

    Supports:
    - Pagination via limit/offset query parameters
    - Filtering via plant_ids query parameter (comma-separated)
    - Ordering via ordering query parameter (e.g., ?ordering=name or ?ordering=-name)
    """
    pagination_class = MaxLimitOffsetPagination

    @extend_schema(responses=Neo4jPlantSerializer(many=True))
    def get(self, request):
        """Retrieve plants from Neo4j with optional filtering, ordering, and pagination."""
        try:
            plant_ids_param = request.query_params.get('plant_ids', '')
            plant_ids = [pid.strip() for pid in plant_ids_param.split(',') if pid.strip()] if plant_ids_param else None

            plants = Neo4jGraphService.get_plants(plant_ids=plant_ids)

            ordering = request.query_params.get('ordering', '')
            if ordering:
                reverse = ordering.startswith('-')
                field = ordering.lstrip('-')

                def get_sort_key(plant):
                    props = plant.get('properties', {})
                    value = props.get(field)
                    return (value is not None, value) if not reverse else (value is not None, value)

                plants = sorted(plants, key=get_sort_key, reverse=reverse)

            paginator = self.pagination_class()
            page = paginator.paginate_queryset(plants, request)
            serializer = Neo4jPlantSerializer(page, many=True)
            return paginator.get_paginated_response(serializer.data)

        except (Neo4jConnectionError, Neo4jQueryError) as e:
            logger.error(f"Neo4j error in Neo4jPlantListView: {str(e)}")
            return Response(
                {
                    "success": False,
                    "error": "Neo4j service is temporarily unavailable."
                },
                status=status.HTTP_503_SERVICE_UNAVAILABLE
            )
        except Exception as e:
            logger.error(f"Unexpected error in Neo4jPlantListView: {str(e)}")
            return Response(
                {
                    "success": False,
                    "error": "An unexpected error occurred while retrieving plants."
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
