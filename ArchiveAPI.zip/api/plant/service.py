from api.neo4j_graph_api.services import Neo4jGraphService
from api.plant.models import Plant


class PlantService:
    """
    Service class for Plant operations.
    """

    @staticmethod
    def get_all_plants():
        """
        Retrieve all plants.
        :return: QuerySet of all Plant objects.
        """
        return Plant.objects.all()

    @staticmethod
    def get_plant_by_id(plant_nbr):
        """
        Retrieve a plant by its ID.
        :param plant_nbr: ID of the plant to retrieve.
        :return: Plant object or None if not found.
        """
        try:
            return Plant.objects.get(id=plant_nbr)
        except Plant.DoesNotExist:
            return None

    @staticmethod
    def get_plants_from_neo4j(plant_ids=None, filters=None):
        """
        Retrieve plants from Neo4j graph database.

        Args:
            plant_ids: Optional list of plant IDs to filter by
            filters: Optional dictionary of additional filters

        Returns:
            List[Dict[str, Any]]: List of plant nodes with their properties
        """
        return Neo4jGraphService.get_plants(plant_ids=plant_ids, filters=filters)
