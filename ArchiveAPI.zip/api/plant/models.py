from django.contrib.postgres.fields import ArrayField
from django.db import models


class Plant(models.Model):
    plant_nbr = models.CharField(
        max_length=255,
        unique=True
    )  # Id from datababricks
    name = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=255, blank=True, null=True)
    state = models.CharField(max_length=255, blank=True, null=True)
    postal_code = models.CharField(max_length=255, blank=True, null=True)
    longitude = models.FloatField(blank=True, null=True)
    latitude = models.FloatField(blank=True, null=True)
    default_lead_time = models.FloatField(default=0.0, blank=True, null=True)
    coverage_zip_codes = ArrayField(
        models.CharField(max_length=255),
        default=list,
        blank=True,
        null=True
    )
    lic_num = models.CharField(max_length=255, blank=True, null=True)
    hin_num = models.CharField(max_length=255, blank=True, null=True)
    plant_gln = models.CharField(max_length=255, blank=True, null=True)
    region_key = models.CharField(max_length=255, blank=True, null=True)
    region_description = models.CharField(max_length=255, blank=True, null=True)
    active_status = models.CharField(max_length=255, blank=True, null=True)
    active_from = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "plants"
        verbose_name = "Plant"
        verbose_name_plural = "Plants"
        indexes = [
            models.Index(fields=["plant_nbr"]),
            models.Index(fields=["id"]),
        ]
