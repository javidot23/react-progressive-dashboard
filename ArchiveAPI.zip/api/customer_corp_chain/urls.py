from django.urls import path

from .views import CustomerCorpChainListView

app_name = 'customer_corp_chain'

urlpatterns = [
    path('', CustomerCorpChainListView.as_view(), name='list'),
]
