from rest_framework import serializers

from api.customer_corp_chain.models import CustomerCorpChain


class CustomerCorpChainSerializer(serializers.ModelSerializer):

    class Meta:
        model = CustomerCorpChain
        fields = [
            'id',
            'cust_corp_chain_nbr',
            'name',
            'created_at',
            'updated_at',
        ]
