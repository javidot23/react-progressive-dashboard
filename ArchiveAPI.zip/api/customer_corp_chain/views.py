from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics
from rest_framework.filters import OrderingFilter

from api.customer_corp_chain.filters import CustomerCorpChainFilter
from api.customer_corp_chain.models import CustomerCorpChain
from api.customer_corp_chain.serializers import CustomerCorpChainSerializer
from api.customer_corp_chain.services import CustomerCorpChainService
from api.global_filters import get_filtered_material_subquery
from api.order_transaction.models import OrderTransaction


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class CustomerCorpChainListView(generics.ListAPIView):
    """List customer corp chains. Supports global filters for contextual dropdowns."""
    serializer_class = CustomerCorpChainSerializer
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = CustomerCorpChainFilter
    ordering_fields = ['name', 'created_at', 'updated_at']
    ordering = ['name']

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return CustomerCorpChain.objects.none()
        qs = CustomerCorpChainService.list_all_customer_corp_chains()
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        if direct_mat_nbr is None and mat_nbr_subquery is None:
            return qs
        if direct_mat_nbr:
            order_filter = {"material__mat_nbr": direct_mat_nbr}
        else:
            order_filter = {"material__mat_nbr__in": mat_nbr_subquery}
        corp_chain_nbrs = (
            OrderTransaction.objects.filter(**order_filter)
            .exclude(cust_corp_chain_nbr__isnull=True)
            .values_list("cust_corp_chain_nbr", flat=True)
            .distinct()
        )
        corp_chain_nbrs = list(corp_chain_nbrs)
        if not corp_chain_nbrs:
            return qs.none()
        return qs.filter(cust_corp_chain_nbr__in=corp_chain_nbrs)
