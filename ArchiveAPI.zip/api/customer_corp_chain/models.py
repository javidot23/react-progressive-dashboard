from django.db import models


class CustomerCorpChain(models.Model):
    cust_corp_chain_nbr = models.CharField(max_length=255, unique=True)  # Customer Corporate Chain number from DBX
    name = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "customer_corp_chains"
        verbose_name = "Customer Corporate Chain"
        verbose_name_plural = "Customer Corporate Chains"
        indexes = [
            models.Index(fields=["cust_corp_chain_nbr"])
        ]
