from django.apps import AppConfig


class CustomerCorpChainConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.customer_corp_chain'
