import django_filters
from django.db import models

from .models import CustomerCorpChain


class CustomerCorpChainFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='icontains')
    cust_corp_chain_nbr = django_filters.CharFilter(lookup_expr='iexact')
    search = django_filters.CharFilter(method='filter_search')

    def filter_search(self, queryset, name, value):
        if value:
            return queryset.filter(
                models.Q(cust_corp_chain_nbr__icontains=value) |
                models.Q(name__icontains=value)
            )
        return queryset

    class Meta:
        model = CustomerCorpChain
        fields = ['name', 'cust_corp_chain_nbr']
