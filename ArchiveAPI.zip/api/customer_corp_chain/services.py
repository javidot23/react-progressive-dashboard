import logging

from api.customer_corp_chain.models import CustomerCorpChain

logger = logging.getLogger(__name__)


class CustomerCorpChainService:
    @staticmethod
    def get_customer_corp_chain_by_nbr(cust_corp_chain_nbr: str) -> CustomerCorpChain:
        """
        Retrieve a CustomerCorpChain instance by its corporate chain number.

        :param cust_corp_chain_nbr: The corporate chain number to search for.
        :return: CustomerCorpChain instance if found, else None.
        """
        logger.info("Retrieving customer corporate chain by number: %s", cust_corp_chain_nbr)
        try:
            result = CustomerCorpChain.objects.get(cust_corp_chain_nbr=cust_corp_chain_nbr)
            logger.info("Successfully retrieved customer corporate chain: %s", cust_corp_chain_nbr)
            return result
        except CustomerCorpChain.DoesNotExist:
            logger.info("Customer corporate chain not found: %s", cust_corp_chain_nbr)
            return None

    @staticmethod
    def list_all_customer_corp_chains():
        """
        Retrieve all CustomerCorpChain instances.

        :return: QuerySet of all CustomerCorpChain instances.
        """
        logger.info("Retrieving all customer corporate chains")
        queryset = CustomerCorpChain.objects.all()
        logger.info("Retrieved %s customer corporate chains", queryset.count())
        return queryset
