from django.db import models

from api.customer_location.models import CustomerLocation


class Customer(models.Model):
    # Level 1 Customer
    cust_nbr = models.CharField(max_length=255, unique=True)  # Customer number from DBX
    name = models.CharField(max_length=255, blank=True, null=True)
    state = models.CharField(max_length=255, blank=True, null=True)
    cust_location_nbr = models.ForeignKey(
        CustomerLocation,
        to_field="cust_location_nbr",
        db_column="cust_location_nbr",
        on_delete=models.CASCADE,
        null=True
    )
    customer_gln = models.CharField(max_length=255, blank=True, null=True)
    special_stock_partner = models.CharField(max_length=255, blank=True, null=True)
    primary_businessunit = models.CharField(max_length=255, blank=True, null=True)
    primary_businessunit_desc = models.CharField(max_length=255, blank=True, null=True)
    customer_340b_indicator = models.BooleanField(
        default=False,
        db_column='customer_340b_indicator'
    )
    cust_hrsa_nbr = models.CharField(max_length=255, blank=True, null=True)
    dea_num = models.CharField(max_length=255, blank=True, null=True)
    sales_district = models.CharField(max_length=255, blank=True, null=True)
    plant_name = models.CharField(max_length=255, blank=True, null=True)
    industry = models.CharField(max_length=255, blank=True, null=True)
    industry_name = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "customers"
        verbose_name = "Customer"
        verbose_name_plural = "Customers"
        indexes = [
            models.Index(fields=["cust_nbr"]),
            models.Index(fields=["cust_location_nbr"]),
        ]
