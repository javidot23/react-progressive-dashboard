from contextlib import contextmanager
from unittest.mock import MagicMock, patch

from rest_framework import status

from api.csv_export_keyset import HEADER_HAS_MORE, HEADER_NEXT_CURSOR, HEADER_TRUNCATED


def paged_export_queryset(*order_by):
    """MagicMock queryset that survives CsvExportView keyset paging without COUNT."""
    qs = MagicMock()
    qs.query.order_by = order_by or ("id",)
    qs.order_by.return_value = qs
    qs.filter.return_value = qs
    qs.__getitem__.return_value = qs
    qs.iterator.return_value = iter([])
    qs.values_list.return_value = []
    qs.select_related.return_value = qs
    return qs


@contextmanager
def patched_export_peek(has_more=True, last_values=(1,), row_count=1):
    with patch("api.csv_export.peek_page", return_value=(has_more, last_values, row_count)):
        yield


def assert_paged_export_has_more(test_case, response):
    test_case.assertEqual(response.status_code, status.HTTP_200_OK)
    test_case.assertEqual(response[HEADER_HAS_MORE], "true")
    test_case.assertEqual(response.get(HEADER_TRUNCATED), "false")
    test_case.assertTrue(response.get(HEADER_NEXT_CURSOR))
    b"".join(response.streaming_content)
