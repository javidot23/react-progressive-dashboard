import json
from unittest.mock import Mock

from tests.BaseTestCase import BaseTestCase

from api.success_json_response import SuccessJsonResponse


class TestSuccessJsonResponse(BaseTestCase):
    def setUp(self):
        self.renderer = SuccessJsonResponse()

    def test_render_success_response_wraps_data(self):
        """Test that successful responses are wrapped with success=True"""
        data = {"message": "test"}
        renderer_context = {
            "response": Mock(exception=False)
        }

        result = self.renderer.render(data, renderer_context=renderer_context)
        parsed_result = json.loads(result)

        self.assertEqual(parsed_result["success"], True)
        self.assertEqual(parsed_result["data"], data)

    def test_render_exception_response_unchanged(self):
        """Test that exception responses are not wrapped"""
        error_data = {"error": "Something went wrong"}
        renderer_context = {
            "response": Mock(exception=True)
        }

        result = self.renderer.render(error_data, renderer_context=renderer_context)
        parsed_result = json.loads(result)

        self.assertEqual(parsed_result, error_data)
        self.assertNotIn("success", parsed_result)

    def test_render_with_none_data(self):
        """Test rendering with None data"""
        renderer_context = {
            "response": Mock(exception=False)
        }

        result = self.renderer.render(None, renderer_context=renderer_context)
        parsed_result = json.loads(result)

        self.assertEqual(parsed_result["success"], True)
        self.assertIsNone(parsed_result["data"])

    def test_render_with_empty_list(self):
        """Test rendering with empty list"""
        data = []
        renderer_context = {
            "response": Mock(exception=False)
        }

        result = self.renderer.render(data, renderer_context=renderer_context)
        parsed_result = json.loads(result)
        self.assertEqual(parsed_result["success"], True)
        self.assertEqual(parsed_result["data"], [])
