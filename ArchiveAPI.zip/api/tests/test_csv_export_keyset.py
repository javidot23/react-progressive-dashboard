from datetime import date, datetime, timedelta
from decimal import Decimal
from unittest.mock import patch
from uuid import UUID

from django.db.models import Q
from django.test import SimpleTestCase
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from api.csv_export_keyset import (
    canonical_ordering,
    decode_cursor_value,
    encode_cursor_value,
    filter_fingerprint,
    parse_ordering,
    peek_page,
    sanitize_export_stem,
    seek_q,
    sign_cursor,
    unsign_cursor,
)


class CanonicalOrderingTests(SimpleTestCase):
    def test_appends_missing_identity(self):
        self.assertEqual(
            canonical_ordering(["-invoice_date"], ["id"]),
            ["-invoice_date", "id"],
        )

    def test_does_not_duplicate_identity(self):
        self.assertEqual(
            canonical_ordering(["-id", "invoice_date"], ["id"]),
            ["-id", "invoice_date"],
        )


class SeekQTests(SimpleTestCase):
    def test_single_field_asc(self):
        q = seek_q(["id"], (10,))
        self.assertEqual(q, Q(id__gt=10) | Q(id__isnull=True))

    def test_single_field_desc(self):
        q = seek_q(["-id"], (10,))
        self.assertEqual(q, Q(id__lt=10))

    def test_mixed_direction(self):
        q = seek_q(["-invoice_date", "id"], (date(2026, 1, 15), 9))
        expected = (
            Q(invoice_date__lt=date(2026, 1, 15))
            | (
                Q(invoice_date=date(2026, 1, 15))
                & (Q(id__gt=9) | Q(id__isnull=True))
            )
        )
        self.assertEqual(q, expected)

    def test_three_fields(self):
        q = seek_q(["a", "-b", "c"], (1, 2, 3))
        expected = (
            (Q(a__gt=1) | Q(a__isnull=True))
            | (Q(a=1) & Q(b__lt=2))
            | (Q(a=1) & Q(b=2) & (Q(c__gt=3) | Q(c__isnull=True)))
        )
        self.assertEqual(q, expected)

    def test_null_sort_key_asc_has_no_after_branch(self):
        q = seek_q(["invoice_date", "id"], (None, 4))
        never = Q(invoice_date__isnull=True) & Q(invoice_date__isnull=False)
        expected = never | (Q(invoice_date__isnull=True) & (Q(id__gt=4) | Q(id__isnull=True)))
        self.assertEqual(q, expected)

    def test_null_sort_key_desc_continues_into_non_nulls(self):
        q = seek_q(["-invoice_date", "id"], (None, 4))
        expected = (
            Q(invoice_date__isnull=False)
            | (Q(invoice_date__isnull=True) & (Q(id__gt=4) | Q(id__isnull=True)))
        )
        self.assertEqual(q, expected)

    def test_empty_ordering_raises(self):
        with self.assertRaises(ValidationError):
            seek_q([], ())

    def test_length_mismatch_raises(self):
        with self.assertRaises(ValidationError):
            seek_q(["id"], (1, 2))

    def test_parse_ordering_skips_blanks(self):
        self.assertEqual(parse_ordering(["-a", "", "b"]), [("a", True), ("b", False)])


class CursorSigningTests(SimpleTestCase):
    def setUp(self):
        self.ordering = ["-invoice_date", "id"]
        self.values = (date(2026, 8, 1), 42)
        self.filter_fp = "abc"
        self.tenant_id = "tenant-1"

    def test_round_trip(self):
        token = sign_cursor(
            ordering=self.ordering,
            values=self.values,
            filter_fp=self.filter_fp,
            tenant_id=self.tenant_id,
            pages_completed=1,
        )
        values, pages = unsign_cursor(
            token,
            ordering=self.ordering,
            filter_fp=self.filter_fp,
            tenant_id=self.tenant_id,
        )
        self.assertEqual(values, self.values)
        self.assertEqual(pages, 1)

    def test_expired_cursor_raises(self):
        token = sign_cursor(
            ordering=self.ordering,
            values=self.values,
            filter_fp=self.filter_fp,
            tenant_id=self.tenant_id,
            pages_completed=1,
        )
        later = timezone.now() + timedelta(hours=3)
        with patch("django.core.signing.time.time", return_value=later.timestamp()):
            with self.assertRaises(ValidationError) as ctx:
                unsign_cursor(
                    token,
                    ordering=self.ordering,
                    filter_fp=self.filter_fp,
                    tenant_id=self.tenant_id,
                )
        self.assertIn("invalid or expired", str(ctx.exception.detail))

    def test_filter_mismatch(self):
        token = sign_cursor(
            ordering=self.ordering,
            values=self.values,
            filter_fp=self.filter_fp,
            tenant_id=self.tenant_id,
            pages_completed=1,
        )
        with self.assertRaises(ValidationError) as ctx:
            unsign_cursor(
                token,
                ordering=self.ordering,
                filter_fp="other",
                tenant_id=self.tenant_id,
            )
        self.assertIn("filters", str(ctx.exception.detail))

    def test_tenant_mismatch(self):
        token = sign_cursor(
            ordering=self.ordering,
            values=self.values,
            filter_fp=self.filter_fp,
            tenant_id=self.tenant_id,
            pages_completed=1,
        )
        with self.assertRaises(ValidationError) as ctx:
            unsign_cursor(
                token,
                ordering=self.ordering,
                filter_fp=self.filter_fp,
                tenant_id="other",
            )
        self.assertIn("tenant", str(ctx.exception.detail))

    def test_tampered_payload(self):
        token = sign_cursor(
            ordering=self.ordering,
            values=self.values,
            filter_fp=self.filter_fp,
            tenant_id=self.tenant_id,
            pages_completed=1,
        )
        with self.assertRaises(ValidationError):
            unsign_cursor(
                token + "x",
                ordering=self.ordering,
                filter_fp=self.filter_fp,
                tenant_id=self.tenant_id,
            )

    def test_empty_token_returns_none(self):
        self.assertIsNone(unsign_cursor(
            "",
            ordering=self.ordering,
            filter_fp=self.filter_fp,
            tenant_id=self.tenant_id,
        ))


class CursorValueCodecTests(SimpleTestCase):
    def test_round_trips_types(self):
        samples = [
            None,
            12,
            "abc",
            True,
            date(2026, 1, 2),
            datetime(2026, 1, 2, 3, 4, 5),
            Decimal("1.50"),
            UUID("00000000-0000-4000-8000-000000000001"),
        ]
        for sample in samples:
            self.assertEqual(decode_cursor_value(encode_cursor_value(sample)), sample)


class FilterFingerprintTests(SimpleTestCase):
    def test_ignores_paging_params(self):
        params = {
            "search": "a",
            "export_cursor": "x",
            "export_stem": "stem",
            "export_part": "2",
        }
        self.assertEqual(filter_fingerprint(params), filter_fingerprint({"search": "a"}))


class PeekPageTests(SimpleTestCase):
    def test_detects_has_more_and_trims(self):
        class FakeQueryset:
            def __init__(self, rows):
                self.rows = rows

            def values_list(self, *fields):
                return self

            def __getitem__(self, slc):
                return self.rows[slc]

        has_more, last, count = peek_page(FakeQueryset([(1,), (2,), (3,)]), ["id"], 2)
        self.assertTrue(has_more)
        self.assertEqual(last, (2,))
        self.assertEqual(count, 2)

    def test_short_page(self):
        class FakeQueryset:
            def values_list(self, *fields):
                return self

            def __getitem__(self, slc):
                return [(1,)][slc]

        has_more, last, count = peek_page(FakeQueryset(), ["id"], 2)
        self.assertFalse(has_more)
        self.assertEqual(last, (1,))
        self.assertEqual(count, 1)


class StemTests(SimpleTestCase):
    def test_accepts_valid_stem(self):
        self.assertEqual(
            sanitize_export_stem("sales_history_20260101_120000", "x"),
            "sales_history_20260101_120000",
        )

    def test_rejects_invalid_stem(self):
        stem = sanitize_export_stem("../evil", "sales_history")
        self.assertTrue(stem.startswith("sales_history_"))
