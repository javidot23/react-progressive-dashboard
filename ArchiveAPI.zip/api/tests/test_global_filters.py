from datetime import date, timedelta

from django.urls import reverse
from django.utils import timezone
from django_filters.rest_framework import FilterSet
from rest_framework import status
from rest_framework.request import Request
from rest_framework.test import APIClient, APIRequestFactory

from api.global_filters import (
    GLOBAL_MATERIAL_FILTERS,
    GLOBAL_RELATED_MATERIAL_FILTERS,
    GlobalFilterForRelatedMaterialMixin,
    GlobalFilterMixin,
    apply_global_filters,
    extract_global_filter_params,
    get_corp_chain_material_ids,
    get_material_option_queryset,
    CorpChainFilter,
    DirectCorpChainFilter,
)
from api.issue.models import Issue
from api.material.models import Material
from api.order_transaction.models import OrderTransaction
from tests.BaseTestCase import BaseAPITestCase, BaseTestCase, MVAPITestCase
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


DEMAND_FORECAST_MATERIAL_PLANT_MV = ["demand_forecast_material_plant_mv"]
CORP_CHAIN_MATERIALS_MV = ["corp_chain_materials_90d_mv"]


def refresh_global_filter_mvs(view_names):
    MaterializedViewTestHelper.refresh_materialized_views(view_names)


# =============================================================================
# UNIT TESTS - Core Global Filter Functionality
# =============================================================================


class GlobalFilterMixinUnitTest(BaseTestCase):
    """Unit tests for GlobalFilterMixin."""

    def test_adds_all_expected_filters(self):
        """Test that GlobalFilterMixin adds all expected filters."""

        class TestFilter(GlobalFilterMixin, FilterSet):
            class Meta:
                model = Material
                fields = []

        filter_instance = TestFilter()

        expected_filters = [
            'supplier', 'supplier_nbr', 'supplier_name',
            'product_family', 'product_category',
            'hic3_therapy_class', 'therapeutic_class',
            'xplant_mat_stat',
            'buyer_name', 'buyer_cd', 'buyer',
            'cat_mgr_name', 'cat_mgr_nbr', 'category_manager',
            'material', 'material_id', 'material_name',
            'fdb_gcn_seq_nbr', 'gcn',
            'materialformulary__parent_program', 'formulary', 'parent_program',
            'cust_corp_chain',
            'injectable',
            'who_essential',
            'fee_for_service',
        ]

        for filter_name in expected_filters:
            self.assertIn(filter_name, filter_instance.filters,
                          f"Expected filter '{filter_name}' not found")

    def test_does_not_override_existing_filters(self):
        """Test that GlobalFilterMixin doesn't override explicitly defined filters."""
        from django_filters import CharFilter

        class TestFilter(GlobalFilterMixin, FilterSet):
            material = CharFilter(field_name='custom_field')

            class Meta:
                model = Material
                fields = []

        filter_instance = TestFilter()
        # Verify the filter exists and uses the custom field_name
        self.assertIn('material', filter_instance.filters)
        self.assertEqual(filter_instance.filters['material'].field_name, 'custom_field')


class GlobalFilterForRelatedMaterialMixinUnitTest(BaseTestCase):
    """Unit tests for GlobalFilterForRelatedMaterialMixin."""

    def test_adds_all_expected_filters(self):
        """Test that GlobalFilterForRelatedMaterialMixin adds all expected filters."""

        class TestFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
            class Meta:
                model = OrderTransaction
                fields = []

        filter_instance = TestFilter()

        expected_filters = [
            'supplier', 'supplier_nbr', 'supplier_name',
            'material__product_family', 'product_category',
            'material__hic3_therapy_class', 'therapeutic_class',
            'material__xplant_mat_stat',
            'material__buyer_name', 'material__buyer_cd', 'buyer',
            'material__cat_mgr_name', 'material__cat_mgr_nbr', 'category_manager',
            'material', 'material_id', 'material_name',
            'material__fdb_gcn_seq_nbr', 'gcn',
            'material__materialformulary__parent_program', 'formulary', 'parent_program',
            'cust_corp_chain',
            'injectable',
            'who_essential',
            'fee_for_service',
        ]

        for filter_name in expected_filters:
            self.assertIn(filter_name, filter_instance.filters,
                          f"Expected filter '{filter_name}' not found")


class GetCorpChainMaterialIdsUnitTest(BaseTestCase):
    """Unit tests for get_corp_chain_material_ids function."""

    def test_returns_none_for_empty_corp_chain(self):
        """Test that empty corp chain returns None."""
        result = get_corp_chain_material_ids(None)
        self.assertIsNone(result)

        result = get_corp_chain_material_ids('')
        self.assertIsNone(result)

    def test_returns_none_for_nonexistent_corp_chain(self):
        """Test that non-existent corp chain returns None."""
        result = get_corp_chain_material_ids('NONEXISTENT_CORP_CHAIN_123')
        self.assertIsNone(result)


class CorpChainFilterUnitTest(BaseTestCase):
    """Unit tests for CorpChainFilter class."""

    def test_filter_returns_full_queryset_when_value_empty(self):
        """Test that empty value returns full queryset."""
        filter_instance = CorpChainFilter(field_name='mat_nbr')
        queryset = Material.objects.all()

        result = filter_instance.filter(queryset, None)
        self.assertEqual(result.query.__str__(), queryset.query.__str__())

        result = filter_instance.filter(queryset, '')
        self.assertEqual(result.query.__str__(), queryset.query.__str__())

    def test_filter_returns_none_queryset_for_nonexistent_corp_chain(self):
        """Test that non-existent corp chain returns empty queryset."""
        filter_instance = CorpChainFilter(field_name='mat_nbr')
        queryset = Material.objects.all()

        result = filter_instance.filter(queryset, 'NONEXISTENT_CORP_CHAIN')
        self.assertEqual(result.count(), 0)


class DirectCorpChainFilterUnitTest(BaseTestCase):
    """Unit tests for DirectCorpChainFilter class."""

    def setUp(self):
        self.corp_chain = TestDataFactory.create_customer_corp_chain(
            cust_corp_chain_nbr="TESTCHAIN001",
            name="Test Chain 1"
        )
        self.corp_chain2 = TestDataFactory.create_customer_corp_chain(
            cust_corp_chain_nbr="TESTCHAIN002",
            name="Test Chain 2"
        )
        self.vendor = TestDataFactory.create_vendor(name="Test Vendor", vendor_nbr="VEN001")
        self.material = TestDataFactory.create_material(
            name="Test Material", mat_nbr="MAT001", vendor=self.vendor
        )
        self.plant = TestDataFactory.create_plant(plant_nbr="P001")

        with MaterializedViewTestHelper.defer_auto_refresh():
            self.order1 = TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today(),
                cust_corp_chain_nbr=self.corp_chain
            )
            self.order2 = TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today(),
                cust_corp_chain_nbr=self.corp_chain2
            )

    def test_filter_returns_full_queryset_when_value_empty(self):
        """Test that empty value returns full queryset."""
        filter_instance = DirectCorpChainFilter(field_name='cust_corp_chain_nbr')
        queryset = OrderTransaction.objects.all()

        result = filter_instance.filter(queryset, None)
        self.assertEqual(result.count(), queryset.count())

        result = filter_instance.filter(queryset, '')
        self.assertEqual(result.count(), queryset.count())

    def test_filter_filters_by_direct_fk(self):
        """Test that filter correctly filters by direct FK to corp chain."""
        filter_instance = DirectCorpChainFilter(field_name='cust_corp_chain_nbr')
        queryset = OrderTransaction.objects.all()

        result = filter_instance.filter(queryset, 'TESTCHAIN001')
        self.assertEqual(result.count(), 1)
        self.assertEqual(result.first().cust_corp_chain_nbr.cust_corp_chain_nbr, 'TESTCHAIN001')

        result = filter_instance.filter(queryset, 'TESTCHAIN002')
        self.assertEqual(result.count(), 1)
        self.assertEqual(result.first().cust_corp_chain_nbr.cust_corp_chain_nbr, 'TESTCHAIN002')

    def test_filter_returns_empty_for_nonexistent_corp_chain(self):
        """Test that non-existent corp chain returns empty queryset."""
        filter_instance = DirectCorpChainFilter(field_name='cust_corp_chain_nbr')
        queryset = OrderTransaction.objects.all()

        result = filter_instance.filter(queryset, 'NONEXISTENT_CHAIN')
        self.assertEqual(result.count(), 0)


class ApplyGlobalFiltersUnitTest(BaseTestCase):
    """Unit tests for apply_global_filters function."""

    def setUp(self):
        self.vendor1 = TestDataFactory.create_vendor(name="Test Vendor 1", vendor_nbr="1234567890")
        self.vendor2 = TestDataFactory.create_vendor(name="Test Vendor 2", vendor_nbr="0987654321")
        self.material1 = TestDataFactory.create_material(
            name="Test Material 1", mat_nbr="MAT001", vendor=self.vendor1,
            product_family="Antibiotics", hic3_therapy_class="ANTIBIOTICS",
            buyer_name="John Buyer", buyer_cd="B001", cat_mgr_name="Jane Manager",
            cat_mgr_nbr="M001", fdb_gcn_seq_nbr="123456"
        )
        self.material2 = TestDataFactory.create_material(
            name="Test Material 2", mat_nbr="MAT002", vendor=self.vendor2,
            product_family="Cardiovascular", hic3_therapy_class="CARDIOVASCULAR",
            buyer_name="Jane Buyer", buyer_cd="B002", cat_mgr_name="John Manager",
            cat_mgr_nbr="M002", fdb_gcn_seq_nbr="654321"
        )
        self.factory = APIRequestFactory()

    def test_filter_by_supplier_id(self):
        """Test filtering by supplier ID."""
        django_request = self.factory.get('/', {'supplier': self.vendor1.id})
        request = Request(django_request)
        queryset = Material.objects.all()
        filtered_qs = apply_global_filters(queryset, request)
        self.assertEqual(filtered_qs.count(), 1)
        self.assertEqual(filtered_qs.first(), self.material1)

    def test_filter_by_multiple_criteria(self):
        """Test filtering by multiple criteria at once."""
        django_request = self.factory.get('/', {
            'supplier_name': 'Vendor 1',
            'product_family': 'Antibiotics',
            'buyer_name': 'John'
        })
        request = Request(django_request)
        queryset = Material.objects.all()
        filtered_qs = apply_global_filters(queryset, request)
        self.assertEqual(filtered_qs.count(), 1)
        self.assertEqual(filtered_qs.first(), self.material1)

    def test_no_filters_returns_all(self):
        """Test that no filters returns all objects."""
        django_request = self.factory.get('/', {})
        request = Request(django_request)
        queryset = Material.objects.all()
        filtered_qs = apply_global_filters(queryset, request)
        self.assertEqual(filtered_qs.count(), 2)


class ExtractGlobalFilterParamsUnitTest(BaseTestCase):
    """Unit tests for extract_global_filter_params function."""

    def setUp(self):
        self.factory = APIRequestFactory()

    def test_extract_clean_params(self):
        """Test extracting clean parameter names."""
        django_request = self.factory.get('/', {
            'supplier': '123',
            'product_family': 'Diabetes',
            'product_category': 'Diabetic Agents',
            'buyer': 'John',
            'material': '456'
        })
        request = Request(django_request)
        filters = extract_global_filter_params(request)

        self.assertEqual(filters['material__vendor__id__in'], ['123'])
        self.assertEqual(filters['material__product_family__icontains'], 'Diabetes')
        self.assertEqual(filters['material__material_group__icontains'], 'Diabetic Agents')
        self.assertEqual(filters['material__buyer_name__icontains'], 'John')
        self.assertEqual(filters['material__mat_nbr__in'], ['456'])

    def test_backward_compatible_params(self):
        """Test extracting old Django-style parameter names."""
        django_request = self.factory.get('/', {
            'material__vendor__name': 'Test Vendor',
            'material__product_family': 'Cardiovascular'
        })
        request = Request(django_request)
        filters = extract_global_filter_params(request)

        self.assertEqual(filters['material__vendor__name__icontains'], 'Test Vendor')
        self.assertEqual(filters['material__product_family__icontains'], 'Cardiovascular')

    def test_empty_params(self):
        """Test extracting with no parameters."""
        django_request = self.factory.get('/', {})
        request = Request(django_request)
        filters = extract_global_filter_params(request)
        self.assertEqual(filters, {})

    def test_extract_multi_select_params(self):
        """Test that comma-separated values produce __in keys with lists."""
        django_request = self.factory.get('/', {
            'supplier': '123,456',
            'supplier_nbr': 'SUP001,SUP002',
            'material': 'MAT001,MAT002,MAT003',
            'material_id': '10,20',
            'buyer_cd': 'BUY001,BUY002',
            'cat_mgr_nbr': 'MGR001,MGR002',
            'xplant_mat_stat': 'A,B',
        })
        request = Request(django_request)
        filters = extract_global_filter_params(request)

        self.assertEqual(filters['material__vendor__id__in'], ['123', '456'])
        self.assertEqual(filters['material__vendor__vendor_nbr__in'], ['SUP001', 'SUP002'])
        self.assertEqual(filters['material__mat_nbr__in'], ['MAT001', 'MAT002', 'MAT003'])
        self.assertEqual(filters['material__id__in'], ['10', '20'])
        self.assertEqual(filters['material__buyer_cd__in'], ['BUY001', 'BUY002'])
        self.assertEqual(filters['material__cat_mgr_nbr__in'], ['MGR001', 'MGR002'])
        self.assertEqual(filters['material__xplant_mat_stat__in'], ['A', 'B'])

    def test_extract_single_value_still_returns_list(self):
        """Test that a single value for multi-select params still returns a one-item list."""
        django_request = self.factory.get('/', {
            'supplier': '123',
            'xplant_mat_stat': 'Active',
        })
        request = Request(django_request)
        filters = extract_global_filter_params(request)

        self.assertEqual(filters['material__vendor__id__in'], ['123'])
        self.assertEqual(filters['material__xplant_mat_stat__in'], ['Active'])


class GetMaterialOptionQuerysetUnitTest(BaseTestCase):
    """Unit tests for get_material_option_queryset (contextual filter dropdown helper)."""

    def setUp(self):
        self.factory = APIRequestFactory()
        self.vendor1 = TestDataFactory.create_vendor(name="V1", vendor_nbr="V001")
        self.vendor2 = TestDataFactory.create_vendor(name="V2", vendor_nbr="V002")
        TestDataFactory.create_material(
            mat_nbr="M001", vendor=self.vendor1, material_group="GroupA",
            hic3_therapy_class="TherapyA", buyer_name="Buyer1", buyer_cd="B1",
            cat_mgr_name="Mgr1", cat_mgr_nbr="N1", fdb_gcn_seq_nbr="G1",
            xplant_mat_stat="Active",
        )
        TestDataFactory.create_material(
            mat_nbr="M002", vendor=self.vendor2, material_group="GroupB",
            hic3_therapy_class="TherapyB", buyer_name="Buyer2", buyer_cd="B2",
            cat_mgr_name="Mgr2", cat_mgr_nbr="N2", fdb_gcn_seq_nbr="G2",
            xplant_mat_stat="Inactive",
        )

    def test_no_params_returns_all_options(self):
        """Test that no global filter params returns all distinct options."""
        request = Request(self.factory.get("/", {}))
        qs = get_material_option_queryset(request, ["material_group"], "material_group")
        groups = list(qs)
        self.assertEqual(len(groups), 2)
        self.assertEqual({g["material_group"] for g in groups}, {"GroupA", "GroupB"})

    def test_supplier_param_narrows_options(self):
        """Test that supplier param narrows to options for that vendor only."""
        request = Request(self.factory.get("/", {"supplier": str(self.vendor1.id)}))
        qs = get_material_option_queryset(request, ["material_group"], "material_group")
        groups = list(qs)
        self.assertEqual(len(groups), 1)
        self.assertEqual(groups[0]["material_group"], "GroupA")


class GlobalFiltersConstantsUnitTest(BaseTestCase):
    """Unit tests for global filter constants."""

    def test_global_material_filters_structure(self):
        """Test GLOBAL_MATERIAL_FILTERS has correct structure."""
        self.assertIsInstance(GLOBAL_MATERIAL_FILTERS, dict)
        self.assertGreater(len(GLOBAL_MATERIAL_FILTERS), 0)

        for key, value in GLOBAL_MATERIAL_FILTERS.items():
            self.assertTrue(hasattr(value, 'filter'),
                            f"Filter '{key}' doesn't have filter method")

    def test_global_related_material_filters_structure(self):
        """Test GLOBAL_RELATED_MATERIAL_FILTERS has correct structure."""
        self.assertIsInstance(GLOBAL_RELATED_MATERIAL_FILTERS, dict)
        self.assertGreater(len(GLOBAL_RELATED_MATERIAL_FILTERS), 0)


# =============================================================================
# INTEGRATION TESTS - Material Module
# =============================================================================


class MaterialGlobalFiltersIntegrationTest(BaseAPITestCase):
    """Integration tests for global filters in material views."""

    def setUp(self):
        # Create and authenticate test user
        self.user = TestDataFactory.create_test_user(
            entra_id="test_material_filters",
            email="test@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.vendor1 = TestDataFactory.create_vendor(name="Pfizer Inc", vendor_nbr="VEN001")
        self.vendor2 = TestDataFactory.create_vendor(name="Merck & Co", vendor_nbr="VEN002")

        self.material1 = TestDataFactory.create_material(
            name="Aspirin 100mg", mat_nbr="MAT001", vendor=self.vendor1,
            product_family="Pain Relief", material_group="Analgesics",
            hic3_therapy_class="ANALGESICS",
            xplant_mat_stat="Active",
            buyer_name="Alice Smith", buyer_cd="BUY001",
            cat_mgr_name="Bob Wilson", cat_mgr_nbr="MGR001",
            fdb_gcn_seq_nbr="GCN12345"
        )

        self.material2 = TestDataFactory.create_material(
            name="Metformin 500mg", mat_nbr="MAT002", vendor=self.vendor2,
            product_family="Diabetes", material_group="Diabetic Agents",
            hic3_therapy_class="DIABETES",
            xplant_mat_stat="Inactive",
            buyer_name="Charlie Davis", buyer_cd="BUY002",
            cat_mgr_name="Dana Lee", cat_mgr_nbr="MGR002",
            fdb_gcn_seq_nbr="GCN54321"
        )

    def test_material_filter_by_supplier(self):
        """Test filtering materials by supplier."""
        url = reverse('material:material-list')
        response = self.client.get(url, {'supplier': self.vendor1.id, 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - correct material is included
        self.assertEqual(response.data['results'][0]['mat_nbr'], 'MAT001')
        # Negative assertion - wrong material is excluded
        mat_nbrs = [item['mat_nbr'] for item in response.data['results']]
        self.assertNotIn('MAT002', mat_nbrs)

    def test_material_filter_by_product_category(self):
        """Test filtering materials by product category (material_group field)."""
        url = reverse('material:material-list')
        response = self.client.get(url, {'product_category': 'Diabetic', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - Diabetic Agents material is included
        self.assertEqual(response.data['results'][0]['mat_nbr'], 'MAT002')
        self.assertIn('Diabetic', response.data['results'][0]['material_group'])
        # Negative assertion - Analgesics material is excluded
        mat_nbrs = [item['mat_nbr'] for item in response.data['results']]
        self.assertNotIn('MAT001', mat_nbrs)

    def test_material_filter_by_buyer(self):
        """Test filtering materials by buyer."""
        url = reverse('material:material-list')
        response = self.client.get(url, {'buyer': 'Alice', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - Alice's material is included
        self.assertEqual(response.data['results'][0]['buyer_name'], 'Alice Smith')
        # Negative assertion - Charlie's material is excluded
        buyer_names = [item['buyer_name'] for item in response.data['results']]
        self.assertNotIn('Charlie Davis', buyer_names)

    def test_material_filter_by_xplant_mat_stat(self):
        """Test filtering materials by xplant mat stat."""
        url = reverse('material:material-list')
        response = self.client.get(url, {'xplant_mat_stat': 'Active', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - Active material is included
        self.assertEqual(response.data['results'][0]['mat_nbr'], 'MAT001')
        self.assertEqual(response.data['results'][0]['xplant_mat_stat'], 'Active')
        # Negative assertion - Inactive material is excluded
        mat_nbrs = [item['mat_nbr'] for item in response.data['results']]
        self.assertNotIn('MAT002', mat_nbrs)

    def test_material_multiple_filters(self):
        """Test filtering materials by multiple criteria."""
        url = reverse('material:material-list')
        response = self.client.get(url, {
            'supplier_name': 'Pfizer',
            'therapeutic_class': 'ANALGESICS',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - matching material is included
        result = response.data['results'][0]
        self.assertEqual(result['mat_nbr'], 'MAT001')
        self.assertEqual(result['hic3_therapy_class'], 'ANALGESICS')
        # Negative assertion - non-matching materials are excluded
        mat_nbrs = [item['mat_nbr'] for item in response.data['results']]
        self.assertNotIn('MAT002', mat_nbrs)  # Different supplier and therapeutic class


# =============================================================================
# INTEGRATION TESTS - Order Transaction Module
# =============================================================================


class OrderTransactionGlobalFiltersIntegrationTest(MVAPITestCase):
    """Integration tests for global filters in order transaction views."""

    def setUp(self):
        # Create and authenticate test user
        self.client = APIClient()
        self.user = TestDataFactory.create_test_user(
            entra_id="test_order_filters",
            email="test@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.vendor1 = TestDataFactory.create_vendor(name="Johnson & Johnson", vendor_nbr="VEN001")
        self.vendor2 = TestDataFactory.create_vendor(name="Novartis", vendor_nbr="VEN002")

        self.material1 = TestDataFactory.create_material(
            name="Tylenol 500mg", mat_nbr="MAT001", vendor=self.vendor1,
            product_family="Pain Relief", hic3_therapy_class="ANALGESICS",
            buyer_name="Emily White", buyer_cd="BUY001",
            cat_mgr_name="Frank Green", cat_mgr_nbr="MGR001",
            fdb_gcn_seq_nbr="GCN111"
        )

        self.material2 = TestDataFactory.create_material(
            name="Lipitor 20mg", mat_nbr="MAT002", vendor=self.vendor2,
            product_family="Cardiovascular", hic3_therapy_class="CARDIOVASCULAR",
            buyer_name="George Black", buyer_cd="BUY002",
            cat_mgr_name="Helen Gray", cat_mgr_nbr="MGR002",
            fdb_gcn_seq_nbr="GCN222"
        )

        self.plant = TestDataFactory.create_plant(plant_nbr="P001")

        with MaterializedViewTestHelper.defer_auto_refresh():
            self.order1 = TestDataFactory.create_order_transaction(
                material=self.material1, plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10)
            )

            self.order2 = TestDataFactory.create_order_transaction(
                material=self.material2, plant=self.plant,
                ord_created_date=date.today() - timedelta(days=15)
            )

    def test_order_filter_by_supplier(self):
        """Test filtering orders by supplier."""
        url = reverse('order-transaction:order-transaction-list')
        response = self.client.get(url, {'supplier': self.vendor1.id, 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - order with Johnson & Johnson is included
        result = response.data['results'][0]
        self.assertEqual(result['supplier']['name'], 'Johnson & Johnson')
        # Negative assertion - order with Novartis is excluded
        vendor_names = [item['supplier']['name'] for item in response.data['results']]
        self.assertNotIn('Novartis', vendor_names)

    def test_order_filter_by_therapeutic_class(self):
        """Test filtering orders by therapeutic class."""
        url = reverse('order-transaction:order-transaction-list')
        response = self.client.get(url, {'therapeutic_class': 'CARDIOVASCULAR', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - Lipitor (CARDIOVASCULAR) material is included
        result = response.data['results'][0]
        self.assertIn('Lipitor', result['material']['name'])
        # Negative assertion - Tylenol (ANALGESICS) is excluded
        material_names = [item['material']['name'] for item in response.data['results']]
        self.assertNotIn('Tylenol', [name for name in material_names if 'Tylenol' in name])

    def test_order_filter_by_material_name(self):
        """Test filtering orders by material name."""
        url = reverse('order-transaction:order-transaction-list')
        response = self.client.get(url, {'material_name': 'Tylenol', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - Tylenol is included
        result = response.data['results'][0]
        self.assertIn('Tylenol', result['material']['name'])
        # Negative assertion - Lipitor is excluded
        material_names = [item['material']['name'] for item in response.data['results']]
        self.assertNotIn('Lipitor 20mg', material_names)

    def test_order_multiple_filters(self):
        """Test filtering orders by multiple criteria."""
        url = reverse('order-transaction:order-transaction-list')
        response = self.client.get(url, {
            'supplier_name': 'Johnson',
            'buyer': 'Emily',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - order matching both filters is included
        result = response.data['results'][0]
        self.assertIn('Johnson', result['supplier']['name'])
        # Negative assertion - order not matching both filters is excluded
        self.assertEqual(len(response.data['results']), 1)


# =============================================================================
# INTEGRATION TESTS - Issue Module
# =============================================================================


class IssueGlobalFiltersIntegrationTest(BaseAPITestCase):
    """Integration tests for global filters in issue views."""

    def setUp(self):
        # Create and authenticate test user
        self.user = TestDataFactory.create_test_user(
            entra_id="test_issue_filters",
            email="test@example.com"
        )
        self.client.force_authenticate(user=self.user)

        Issue.objects.all().delete()

        self.vendor1 = TestDataFactory.create_vendor(name="GSK", vendor_nbr="VEN001")
        self.vendor2 = TestDataFactory.create_vendor(name="Sanofi", vendor_nbr="VEN002")

        self.material1 = TestDataFactory.create_material(
            name="Amoxicillin 500mg", mat_nbr="MAT001", vendor=self.vendor1,
            product_family="Antibiotics", material_group="Anti-Infectives",
            hic3_therapy_class="ANTIBIOTICS",
            buyer_name="Ian Brown", buyer_cd="BUY001",
            cat_mgr_name="Julia White", cat_mgr_nbr="MGR001",
            fdb_gcn_seq_nbr="GCN333"
        )

        self.material2 = TestDataFactory.create_material(
            name="Lantus 100units/ml", mat_nbr="MAT002", vendor=self.vendor2,
            product_family="Diabetes", material_group="Diabetic Agents",
            hic3_therapy_class="DIABETES",
            buyer_name="Kevin Green", buyer_cd="BUY002",
            cat_mgr_name="Laura Blue", cat_mgr_nbr="MGR002",
            fdb_gcn_seq_nbr="GCN444"
        )

        self.issue1 = TestDataFactory.create_issue(
            issue_nbr="ISS-001", material=self.material1,
            status=Issue.IssueStatus.OPEN, start_date=date.today()
        )

        self.issue2 = TestDataFactory.create_issue(
            issue_nbr="ISS-002", material=self.material2,
            status=Issue.IssueStatus.OPEN, start_date=date.today()
        )

    def test_issue_filter_by_supplier(self):
        """Test filtering issues by supplier."""
        url = reverse('issue:issues-with-material-and-actions')
        response = self.client.get(url, {'supplier': self.vendor1.id, 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - GSK issue is included
        self.assertEqual(response.data['results'][0]['issue_nbr'], 'ISS-001')
        # Negative assertion - Sanofi issue is excluded
        issue_nbrs = [item['issue_nbr'] for item in response.data['results']]
        self.assertNotIn('ISS-002', issue_nbrs)

    def test_issue_filter_by_product_category(self):
        """Test filtering issues by product category (material_group field)."""
        url = reverse('issue:issues-with-material-and-actions')
        response = self.client.get(url, {'product_category': 'Diabetic', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - Diabetic Agents issue is included
        self.assertEqual(response.data['results'][0]['issue_nbr'], 'ISS-002')
        result = response.data['results'][0]
        self.assertIn('Diabetic', result['material']['material_group'])
        # Negative assertion - Anti-Infectives issue is excluded
        issue_nbrs = [item['issue_nbr'] for item in response.data['results']]
        self.assertNotIn('ISS-001', issue_nbrs)

    def test_issue_filter_by_category_manager(self):
        """Test filtering issues by category manager."""
        url = reverse('issue:issues-with-material-and-actions')
        response = self.client.get(url, {'category_manager': 'Julia', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - Julia's issue is included
        result = response.data['results'][0]
        self.assertEqual(result['material']['cat_mgr_name'], 'Julia White')
        # Negative assertion - Laura's issue is excluded
        cat_mgr_names = [item['material']['cat_mgr_name'] for item in response.data['results']]
        self.assertNotIn('Laura Blue', cat_mgr_names)

    def test_issue_multiple_filters(self):
        """Test filtering issues by multiple criteria."""
        url = reverse('issue:issues-with-material-and-actions')
        response = self.client.get(url, {
            'supplier_name': 'GSK',
            'therapeutic_class': 'ANTIBIOTICS',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - GSK ANTIBIOTICS issue is included
        result = response.data['results'][0]
        self.assertEqual(result['issue_nbr'], 'ISS-001')
        self.assertEqual(result['material']['hic3_therapy_class'], 'ANTIBIOTICS')
        # Negative assertion - Sanofi DIABETES issue is excluded
        issue_nbrs = [item['issue_nbr'] for item in response.data['results']]
        self.assertNotIn('ISS-002', issue_nbrs)


# =============================================================================
# INTEGRATION TESTS - Demand Forecast Module
# =============================================================================


class DemandForecastGlobalFiltersIntegrationTest(MVAPITestCase):
    """Integration tests for global filters in demand forecast views."""

    @classmethod
    def setUpTestData(cls):
        MaterializedViewTestHelper.create_materialized_views()

        cls.user = TestDataFactory.create_test_user(
            entra_id="test_demand_filters",
            email="test@example.com"
        )

        cls.today = timezone.now().date()

        cls.vendor1 = TestDataFactory.create_vendor(name="AstraZeneca", vendor_nbr="VEN001")
        cls.vendor2 = TestDataFactory.create_vendor(name="Bayer", vendor_nbr="VEN002")

        cls.plant1 = TestDataFactory.create_plant(plant_nbr="DC001")
        cls.plant2 = TestDataFactory.create_plant(plant_nbr="DC002")

        cls.material1 = TestDataFactory.create_material(
            name="Nexium 40mg", mat_nbr="MAT001", vendor=cls.vendor1,
            product_family="Gastrointestinal", material_group="GI Agents",
            hic3_therapy_class="GASTROINTESTINAL",
            buyer_name="Mike Red", buyer_cd="BUY001",
            cat_mgr_name="Nina Yellow", cat_mgr_nbr="MGR001",
            fdb_gcn_seq_nbr="GCN555"
        )

        cls.material2 = TestDataFactory.create_material(
            name="Aspirin 81mg", mat_nbr="MAT002", vendor=cls.vendor2,
            product_family="Cardiovascular", material_group="Cardiovascular Agents",
            hic3_therapy_class="CARDIOVASCULAR",
            buyer_name="Oscar Purple", buyer_cd="BUY002",
            cat_mgr_name="Paula Orange", cat_mgr_nbr="MGR002",
            fdb_gcn_seq_nbr="GCN666"
        )

        TestDataFactory.create_update_demand_forecast(
            material=cls.material1, plant=cls.plant1,
            demand_date=cls.today, saleable_qty_on_hand=50,
            forecast_qty_7day=100
        )

        TestDataFactory.create_update_demand_forecast(
            material=cls.material2, plant=cls.plant2,
            demand_date=cls.today, saleable_qty_on_hand=300,
            forecast_qty_7day=150
        )
        refresh_global_filter_mvs(DEMAND_FORECAST_MATERIAL_PLANT_MV)

    def setUp(self):
        self.client.force_authenticate(user=self.user)

    def test_demand_filter_by_supplier(self):
        """Test filtering low inventory by supplier."""
        url = reverse('demand_forecast:materials-low-inventory')
        response = self.client.get(url, {
            'threshold': 100,
            'supplier_name': 'AstraZeneca',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        # Positive assertion - AstraZeneca material is included
        self.assertEqual(results[0]['mat_nbr'], 'MAT001')
        # Negative assertion - Bayer material is excluded
        mat_nbrs = [item['mat_nbr'] for item in results]
        self.assertNotIn('MAT002', mat_nbrs)

    def test_demand_filter_by_therapeutic_class(self):
        """Test filtering low inventory by therapeutic class."""
        url = reverse('demand_forecast:materials-low-inventory')
        response = self.client.get(url, {
            'threshold': 100,
            'therapeutic_class': 'GASTROINTESTINAL',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        # Positive assertion - GASTROINTESTINAL material is included
        self.assertEqual(results[0]['mat_nbr'], 'MAT001')
        # Negative assertion - CARDIOVASCULAR material is excluded
        mat_nbrs = [item['mat_nbr'] for item in results]
        self.assertNotIn('MAT002', mat_nbrs)

    def test_demand_filter_by_buyer(self):
        """Test filtering low inventory by buyer."""
        url = reverse('demand_forecast:materials-low-inventory')
        response = self.client.get(url, {
            'threshold': 100,
            'buyer': 'Mike',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        # Positive assertion - Mike's material is included
        self.assertEqual(results[0]['mat_nbr'], 'MAT001')
        # Negative assertion - Oscar's material is excluded
        mat_nbrs = [item['mat_nbr'] for item in results]
        self.assertNotIn('MAT002', mat_nbrs)

    def test_demand_multiple_filters(self):
        """Test filtering low inventory by multiple criteria."""
        url = reverse('demand_forecast:materials-low-inventory')
        response = self.client.get(url, {
            'threshold': 100,
            'supplier_name': 'AstraZeneca',
            'product_category': 'GI Agents',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        # Positive assertion - AstraZeneca + GI Agents material is included
        self.assertEqual(results[0]['mat_nbr'], 'MAT001')
        # Negative assertion - Bayer + Cardiovascular material is excluded
        mat_nbrs = [item['mat_nbr'] for item in results]
        self.assertNotIn('MAT002', mat_nbrs)


# =============================================================================
# INTEGRATION TESTS - Purchase Order Module
# =============================================================================


class PurchaseOrderGlobalFiltersIntegrationTest(BaseAPITestCase):
    """Integration tests for global filters in purchase order views."""

    def setUp(self):
        # Create and authenticate test user
        self.user = TestDataFactory.create_test_user(
            entra_id="test_po_filters",
            email="test@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.vendor1 = TestDataFactory.create_vendor(name="Roche", vendor_nbr="VEN001")
        self.vendor2 = TestDataFactory.create_vendor(name="Eli Lilly", vendor_nbr="VEN002")

        self.material1 = TestDataFactory.create_material(
            name="Herceptin 150mg", mat_nbr="MAT001", vendor=self.vendor1,
            product_family="Oncology", hic3_therapy_class="ONCOLOGY",
            buyer_name="Quinn Roberts", buyer_cd="BUY001",
            cat_mgr_name="Rachel Stone", cat_mgr_nbr="MGR001",
            fdb_gcn_seq_nbr="GCN777"
        )

        self.material2 = TestDataFactory.create_material(
            name="Humalog 100units/ml", mat_nbr="MAT002", vendor=self.vendor2,
            product_family="Diabetes", hic3_therapy_class="DIABETES",
            buyer_name="Sam Taylor", buyer_cd="BUY002",
            cat_mgr_name="Tina Victor", cat_mgr_nbr="MGR002",
            fdb_gcn_seq_nbr="GCN888"
        )

        self.plant = TestDataFactory.create_plant(plant_nbr="P001")

        self.po1 = TestDataFactory.create_purchase_order(
            material=self.material1, plant=self.plant,
            ordered_date=date.today() - timedelta(days=10)
        )

        self.po2 = TestDataFactory.create_purchase_order(
            material=self.material2, plant=self.plant,
            ordered_date=date.today() - timedelta(days=15)
        )

    def test_po_filter_by_supplier(self):
        """Test filtering purchase orders by supplier."""
        url = reverse('purchase-order:purchase-order-list')
        response = self.client.get(url, {'supplier': self.vendor1.id, 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify only Roche POs are in results
        if response.data['count'] > 0:
            # Note: Need to check the actual material_id since list serializer only shows basic material info
            material_ids = [item['material']['id'] for item in response.data['results']]
            self.assertIn(self.material1.id, material_ids)
            self.assertNotIn(self.material2.id, material_ids)

    def test_po_filter_by_therapeutic_class(self):
        """Test filtering purchase orders by therapeutic class."""
        url = reverse('purchase-order:purchase-order-list')
        response = self.client.get(url, {'therapeutic_class': 'ONCOLOGY', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify only ONCOLOGY POs are in results
        if response.data['count'] > 0:
            material_ids = [item['material']['id'] for item in response.data['results']]
            self.assertIn(self.material1.id, material_ids)
            self.assertNotIn(self.material2.id, material_ids)

    def test_po_filter_by_buyer(self):
        """Test filtering purchase orders by buyer."""
        url = reverse('purchase-order:purchase-order-list')
        response = self.client.get(url, {'buyer': 'Quinn', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify only Quinn's POs are in results
        if response.data['count'] > 0:
            material_ids = [item['material']['id'] for item in response.data['results']]
            self.assertIn(self.material1.id, material_ids)
            self.assertNotIn(self.material2.id, material_ids)

    def test_po_multiple_filters(self):
        """Test filtering purchase orders by multiple criteria."""
        url = reverse('purchase-order:purchase-order-list')
        response = self.client.get(url, {
            'supplier_name': 'Roche',
            'product_category': 'Oncology',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify only Roche + Oncology POs are in results
        if response.data['count'] > 0:
            material_ids = [item['material']['id'] for item in response.data['results']]
            self.assertIn(self.material1.id, material_ids)
            self.assertNotIn(self.material2.id, material_ids)


# =============================================================================
# INTEGRATION TESTS - Service Level Module
# =============================================================================


class ServiceLevelGlobalFiltersIntegrationTest(BaseAPITestCase):
    """Integration tests for global filters in service level views."""

    def setUp(self):
        # Create and authenticate test user
        self.user = TestDataFactory.create_test_user(
            entra_id="test_service_level_filters",
            email="test@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.vendor1 = TestDataFactory.create_vendor(name="Abbott", vendor_nbr="VEN001")
        self.vendor2 = TestDataFactory.create_vendor(name="Takeda", vendor_nbr="VEN002")

        self.material1 = TestDataFactory.create_material(
            name="Humira 40mg", mat_nbr="MAT001", vendor=self.vendor1,
            product_family="Immunology", hic3_therapy_class="IMMUNOLOGY",
            buyer_name="Uma White", buyer_cd="BUY001",
            cat_mgr_name="Victor Young", cat_mgr_nbr="MGR001",
            fdb_gcn_seq_nbr="GCN999"
        )

        self.material2 = TestDataFactory.create_material(
            name="Entyvio 300mg", mat_nbr="MAT002", vendor=self.vendor2,
            product_family="Gastrointestinal", hic3_therapy_class="GASTROINTESTINAL",
            buyer_name="Wendy Zinc", buyer_cd="BUY002",
            cat_mgr_name="Xavier Adams", cat_mgr_nbr="MGR002",
            fdb_gcn_seq_nbr="GCN000"
        )

        # Create service level data
        TestDataFactory.create_service_level(
            material=self.material1,
            record_date=date.today() - timedelta(days=5)
        )

        TestDataFactory.create_service_level(
            material=self.material2,
            record_date=date.today() - timedelta(days=5)
        )

    def test_service_level_filter_by_supplier(self):
        """Test filtering service level by supplier."""
        url = reverse('service_level:weekly-service-level')
        response = self.client.get(url, {'supplier_name': 'Abbott', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify aggregated data structure is returned with filter applied
        self.assertIn('this_week_average', response.data)
        self.assertIn('last_week_average', response.data)
        # The values should be numeric (filters are applied)
        self.assertIsInstance(response.data['this_week_average'], (int, float))
        self.assertIsInstance(response.data['last_week_average'], (int, float))

    def test_service_level_filter_by_therapeutic_class(self):
        """Test filtering service level by therapeutic class."""
        url = reverse('service_level:weekly-service-level')
        response = self.client.get(url, {'therapeutic_class': 'IMMUNOLOGY', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify aggregated data structure is returned with filter applied
        self.assertIn('this_week_average', response.data)
        self.assertIn('last_week_average', response.data)
        self.assertIsInstance(response.data['this_week_average'], (int, float))
        self.assertIsInstance(response.data['last_week_average'], (int, float))

    def test_service_level_filter_by_category_manager(self):
        """Test filtering service level by category manager."""
        url = reverse('service_level:weekly-service-level')
        response = self.client.get(url, {'category_manager': 'Victor', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify aggregated data structure is returned with filter applied
        self.assertIn('this_week_average', response.data)
        self.assertIn('last_week_average', response.data)
        self.assertIsInstance(response.data['this_week_average'], (int, float))
        self.assertIsInstance(response.data['last_week_average'], (int, float))

    def test_service_level_multiple_filters(self):
        """Test filtering service level by multiple criteria."""
        url = reverse('service_level:weekly-service-level')
        response = self.client.get(url, {
            'supplier_name': 'Takeda',
            'buyer': 'Wendy',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify aggregated data structure is returned with filters applied
        self.assertIn('this_week_average', response.data)
        self.assertIn('last_week_average', response.data)
        self.assertIsInstance(response.data['this_week_average'], (int, float))
        self.assertIsInstance(response.data['last_week_average'], (int, float))


# =============================================================================
# INTEGRATION TESTS - Material Substitute Module
# =============================================================================


class MaterialSubstituteGlobalFiltersIntegrationTest(BaseAPITestCase):
    """Integration tests for global filters in material substitute views."""

    def setUp(self):
        # Create and authenticate test user
        self.user = TestDataFactory.create_test_user(
            entra_id="test_substitute_filters",
            email="test@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.vendor = TestDataFactory.create_vendor(name="Teva", vendor_nbr="VEN001")

        self.original_material = TestDataFactory.create_material(
            name="Original Drug 100mg", mat_nbr="MAT000", vendor=self.vendor
        )

        self.substitute1 = TestDataFactory.create_material(
            name="Substitute A 100mg", mat_nbr="MAT001", vendor=self.vendor,
            product_family="Generic", hic3_therapy_class="GENERIC",
            buyer_name="Amy Baker", buyer_cd="BUY001",
            cat_mgr_name="Ben Carter", cat_mgr_nbr="MGR001",
            fdb_gcn_seq_nbr="GCN111"
        )

        self.substitute2 = TestDataFactory.create_material(
            name="Substitute B 100mg", mat_nbr="MAT002", vendor=self.vendor,
            product_family="Generic", hic3_therapy_class="GENERIC",
            buyer_name="Cathy Davis", buyer_cd="BUY002",
            cat_mgr_name="Dave Evans", cat_mgr_nbr="MGR002",
            fdb_gcn_seq_nbr="GCN222"
        )

    def test_substitute_filter_by_buyer(self):
        """Test filtering material substitutes by buyer."""
        url = reverse('material-substitute:list',
                      kwargs={'material_id': self.original_material.id})
        response = self.client.get(url, {'buyer': 'Amy', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify only Amy's materials are in results
        if response.data['count'] > 0:
            for item in response.data['results']:
                self.assertIn('Amy', item['buyer_name'])
        # Negative assertion - Cathy's material is excluded
        buyer_names = [item['buyer_name'] for item in response.data['results']]
        self.assertNotIn('Cathy Davis', buyer_names)

    def test_substitute_filter_by_gcn(self):
        """Test filtering material substitutes by GCN."""
        url = reverse('material-substitute:list',
                      kwargs={'material_id': self.original_material.id})
        response = self.client.get(url, {'gcn': 'GCN222', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify only GCN222 materials are in results
        if response.data['count'] > 0:
            for item in response.data['results']:
                self.assertEqual(item['fdb_gcn_seq_nbr'], 'GCN222')
        # Negative assertion - GCN111 material is excluded
        gcn_numbers = [item['fdb_gcn_seq_nbr'] for item in response.data['results']]
        self.assertNotIn('GCN111', gcn_numbers)

    def test_substitute_filter_by_category_manager(self):
        """Test filtering material substitutes by category manager."""
        url = reverse('material-substitute:list',
                      kwargs={'material_id': self.original_material.id})
        response = self.client.get(url, {'category_manager': 'Ben', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify only Ben's materials are in results
        if response.data['count'] > 0:
            for item in response.data['results']:
                self.assertIn('Ben', item['cat_mgr_name'])
        # Negative assertion - Dave's material is excluded
        cat_mgr_names = [item['cat_mgr_name'] for item in response.data['results']]
        self.assertNotIn('Dave Evans', cat_mgr_names)

    def test_substitute_multiple_filters(self):
        """Test filtering material substitutes by multiple criteria."""
        url = reverse('material-substitute:list',
                      kwargs={'material_id': self.original_material.id})
        response = self.client.get(url, {
            'product_category': 'Generic',
            'buyer': 'Cathy',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Verify only Generic AND Cathy's materials are in results
        if response.data['count'] > 0:
            for item in response.data['results']:
                self.assertEqual(item['product_family'], 'Generic')
                self.assertIn('Cathy', item['buyer_name'])
        # Negative assertion - Amy's material is excluded
        buyer_names = [item['buyer_name'] for item in response.data['results']]
        self.assertNotIn('Amy Baker', buyer_names)


class CrossModuleGlobalFiltersTest(BaseAPITestCase):
    """Tests that verify global filters work consistently across all modules."""

    def setUp(self):
        # Create and authenticate test user
        self.user = TestDataFactory.create_test_user(
            entra_id="test_cross_module_filters",
            email="test@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.vendor = TestDataFactory.create_vendor(name="Universal Pharma", vendor_nbr="VEN999")
        self.material = TestDataFactory.create_material(
            name="Test Drug 100mg", mat_nbr="MAT999", vendor=self.vendor,
            product_family="Test Category", hic3_therapy_class="TEST",
            buyer_name="Test Buyer", buyer_cd="BUY999",
            cat_mgr_name="Test Manager", cat_mgr_nbr="MGR999",
            fdb_gcn_seq_nbr="GCN999"
        )

    def test_supplier_filter_consistency(self):
        """Test that supplier filter works consistently across modules."""
        # Test material endpoint
        url = reverse('material:material-list')
        response = self.client.get(url, {'supplier_name': 'Universal', 'limit': 10})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(response.data['count'], 0)

    def test_gcn_filter_consistency(self):
        """Test that GCN filter works consistently."""
        url = reverse('material:material-list')
        response = self.client.get(url, {'gcn': 'GCN999', 'limit': 10})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)

    def test_case_insensitive_filters(self):
        """Test that filters are case insensitive across all modules."""
        url = reverse('material:material-list')

        # Test lowercase
        response1 = self.client.get(url, {'supplier_name': 'universal', 'limit': 10})
        self.assertEqual(response1.status_code, status.HTTP_200_OK)

        # Test uppercase
        response2 = self.client.get(url, {'supplier_name': 'UNIVERSAL', 'limit': 10})
        self.assertEqual(response2.status_code, status.HTTP_200_OK)

        # Test mixed case
        response3 = self.client.get(url, {'supplier_name': 'UnIvErSaL', 'limit': 10})
        self.assertEqual(response3.status_code, status.HTTP_200_OK)

        self.assertEqual(response1.data['count'], response2.data['count'])
        self.assertEqual(response2.data['count'], response3.data['count'])

    def test_partial_match_filters(self):
        """Test that text filters support partial matching."""
        url = reverse('material:material-list')

        # Partial match should work
        response = self.client.get(url, {'material_name': 'Test Drug', 'limit': 10})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(response.data['count'], 0)


# =============================================================================
# EDGE CASES AND ERROR HANDLING
# =============================================================================


class GlobalFiltersEdgeCasesTest(BaseAPITestCase):
    """Tests for edge cases and error handling in global filters."""

    def setUp(self):
        # Create and authenticate test user
        self.user = TestDataFactory.create_test_user(
            entra_id="test_edge_cases",
            email="test@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.vendor = TestDataFactory.create_vendor(name="Edge Case Vendor", vendor_nbr="VEN000")
        self.material = TestDataFactory.create_material(
            name="Edge Case Material", mat_nbr="MAT000", vendor=self.vendor
        )

    def test_no_results_filter(self):
        """Test filtering with criteria that return no results."""
        url = reverse('material:material-list')
        response = self.client.get(url, {
            'supplier_name': 'NonExistent Vendor XYZ123',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 0)
        self.assertEqual(len(response.data['results']), 0)

    def test_empty_filter_values(self):
        """Test filtering with empty filter values."""
        url = reverse('material:material-list')
        response = self.client.get(url, {'supplier_name': '', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Should return all results when filter value is empty

    def test_special_characters_in_filters(self):
        """Test filtering with special characters."""
        url = reverse('material:material-list')
        response = self.client.get(url, {
            'supplier_name': "Vendor & Co. (Special)",
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_filters_with_pagination(self):
        """Test that filters work correctly with pagination."""
        url = reverse('material:material-list')
        response = self.client.get(url, {
            'supplier_name': 'Edge',
            'limit': 1,
            'offset': 0
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('count', response.data)
        self.assertIn('results', response.data)

    def test_filters_with_ordering(self):
        """Test that filters work correctly with ordering."""
        url = reverse('material:material-list')
        response = self.client.get(url, {
            'supplier_name': 'Edge',
            'ordering': 'mat_nbr',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)


# =============================================================================
# INTEGRATION TESTS - Corp Chain Global Filter
# =============================================================================


class CorpChainGlobalFiltersIntegrationTest(MVAPITestCase):
    """Integration tests for cust_corp_chain global filter."""

    @classmethod
    def setUpTestData(cls):
        MaterializedViewTestHelper.create_materialized_views()

        cls.user = TestDataFactory.create_test_user(
            entra_id="test_corp_chain_filters",
            email="test@example.com"
        )

        # Create vendors
        cls.vendor1 = TestDataFactory.create_vendor(name="Corp Chain Vendor 1", vendor_nbr="CCVEN001")
        cls.vendor2 = TestDataFactory.create_vendor(name="Corp Chain Vendor 2", vendor_nbr="CCVEN002")

        # Create materials
        cls.material1 = TestDataFactory.create_material(
            name="Corp Chain Material 1", mat_nbr="CCMAT001", vendor=cls.vendor1,
            product_family="Category A", hic3_therapy_class="CLASS_A",
            buyer_name="Corp Buyer 1", buyer_cd="CCBUY001",
            cat_mgr_name="Corp Manager 1", cat_mgr_nbr="CCMGR001",
            fdb_gcn_seq_nbr="CCGCN001"
        )

        cls.material2 = TestDataFactory.create_material(
            name="Corp Chain Material 2", mat_nbr="CCMAT002", vendor=cls.vendor2,
            product_family="Category B", hic3_therapy_class="CLASS_B",
            buyer_name="Corp Buyer 2", buyer_cd="CCBUY002",
            cat_mgr_name="Corp Manager 2", cat_mgr_nbr="CCMGR002",
            fdb_gcn_seq_nbr="CCGCN002"
        )

        cls.material3 = TestDataFactory.create_material(
            name="Corp Chain Material 3", mat_nbr="CCMAT003", vendor=cls.vendor1,
            product_family="Category A", hic3_therapy_class="CLASS_A",
            buyer_name="Corp Buyer 1", buyer_cd="CCBUY001",
            cat_mgr_name="Corp Manager 1", cat_mgr_nbr="CCMGR001",
            fdb_gcn_seq_nbr="CCGCN003"
        )

        # Create corp chains
        cls.corp_chain1 = TestDataFactory.create_customer_corp_chain(
            cust_corp_chain_nbr="CORPCHAIN001",
            name="Test Corp Chain 1"
        )
        cls.corp_chain2 = TestDataFactory.create_customer_corp_chain(
            cust_corp_chain_nbr="CORPCHAIN002",
            name="Test Corp Chain 2"
        )

        cls.plant = TestDataFactory.create_plant(plant_nbr="CCP001")

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create order transactions linking corp chains to materials
            # Corp Chain 1 orders Material 1 and Material 3
            cls.order1 = TestDataFactory.create_order_transaction(
                material=cls.material1, plant=cls.plant,
                ord_created_date=date.today() - timedelta(days=10),
                cust_corp_chain_nbr=cls.corp_chain1
            )
            cls.order2 = TestDataFactory.create_order_transaction(
                material=cls.material3, plant=cls.plant,
                ord_created_date=date.today() - timedelta(days=15),
                cust_corp_chain_nbr=cls.corp_chain1
            )

            # Corp Chain 2 orders Material 2
            cls.order3 = TestDataFactory.create_order_transaction(
                material=cls.material2, plant=cls.plant,
                ord_created_date=date.today() - timedelta(days=5),
                cust_corp_chain_nbr=cls.corp_chain2
            )

        refresh_global_filter_mvs(CORP_CHAIN_MATERIALS_MV)

    def setUp(self):
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

    def test_material_filter_by_corp_chain(self):
        """Test filtering materials by corp chain."""
        url = reverse('material:material-list')
        response = self.client.get(url, {'cust_corp_chain': 'CORPCHAIN001', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 2)
        # Positive assertion - Materials ordered by CORPCHAIN001 are included
        mat_nbrs = [item['mat_nbr'] for item in response.data['results']]
        self.assertIn('CCMAT001', mat_nbrs)
        self.assertIn('CCMAT003', mat_nbrs)
        # Negative assertion - Material ordered by CORPCHAIN002 is excluded
        self.assertNotIn('CCMAT002', mat_nbrs)

    def test_material_filter_by_corp_chain_second_chain(self):
        """Test filtering materials by second corp chain."""
        url = reverse('material:material-list')
        response = self.client.get(url, {'cust_corp_chain': 'CORPCHAIN002', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        # Positive assertion - Material ordered by CORPCHAIN002 is included
        self.assertEqual(response.data['results'][0]['mat_nbr'], 'CCMAT002')

    def test_corp_chain_filter_combined_with_supplier(self):
        """Test corp chain filter combined with supplier filter (intersection)."""
        url = reverse('material:material-list')
        response = self.client.get(url, {
            'cust_corp_chain': 'CORPCHAIN001',
            'supplier': self.vendor1.id,
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # CORPCHAIN001 ordered CCMAT001 and CCMAT003, both from vendor1
        self.assertEqual(response.data['count'], 2)
        mat_nbrs = [item['mat_nbr'] for item in response.data['results']]
        self.assertIn('CCMAT001', mat_nbrs)
        self.assertIn('CCMAT003', mat_nbrs)

    def test_corp_chain_filter_combined_with_product_family(self):
        """Test corp chain filter combined with product family filter."""
        url = reverse('material:material-list')
        response = self.client.get(url, {
            'cust_corp_chain': 'CORPCHAIN001',
            'product_family': 'Category A',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Both materials from CORPCHAIN001 are in Category A
        self.assertEqual(response.data['count'], 2)

    def test_corp_chain_filter_returns_empty_for_nonexistent_chain(self):
        """Test that non-existent corp chain returns empty results."""
        url = reverse('material:material-list')
        response = self.client.get(url, {'cust_corp_chain': 'NONEXISTENT_CHAIN', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 0)

    def test_order_transaction_filter_by_corp_chain(self):
        """Test filtering order transactions by corp chain using direct FK filtering.

        This test verifies that OrderTransaction uses DirectCorpChainFilter to filter
        directly on the cust_corp_chain_nbr FK field, rather than filtering through
        materials. This ensures transactions are filtered by the actual customer that
        placed the order, not just by materials that customer has ordered.
        """
        url = reverse('order-transaction:order-transaction-list')
        response = self.client.get(url, {'cust_corp_chain': 'CORPCHAIN001', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 2)
        mat_nbrs = [item['material']['mat_nbr'] for item in response.data['results']]
        self.assertIn('CCMAT001', mat_nbrs)
        self.assertIn('CCMAT003', mat_nbrs)
        self.assertNotIn('CCMAT002', mat_nbrs)

    def test_corp_chain_filter_with_multiple_filters(self):
        """Test corp chain combined with multiple other filters."""
        url = reverse('material:material-list')
        response = self.client.get(url, {
            'cust_corp_chain': 'CORPCHAIN001',
            'supplier_name': 'Corp Chain Vendor 1',
            'therapeutic_class': 'CLASS_A',
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Both CCMAT001 and CCMAT003 match all criteria
        self.assertEqual(response.data['count'], 2)


class CorpChainFilterEdgeCasesTest(MVAPITestCase):
    """Edge case tests for corp chain filter."""

    def setUp(self):
        self.client = APIClient()
        self.user = TestDataFactory.create_test_user(
            entra_id="test_corp_chain_edge",
            email="test@example.com"
        )
        self.client.force_authenticate(user=self.user)

    def test_corp_chain_filter_with_empty_value(self):
        """Test that empty corp chain filter returns all results."""
        # Create a material for testing
        vendor = TestDataFactory.create_vendor(name="Edge Vendor", vendor_nbr="EDGEVEN001")
        TestDataFactory.create_material(
            name="Edge Material", mat_nbr="EDGEMAT001", vendor=vendor
        )

        url = reverse('material:material-list')
        response = self.client.get(url, {'cust_corp_chain': '', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Empty filter should not restrict results
        self.assertGreater(response.data['count'], 0)

    def test_corp_chain_filter_no_orders_in_90_days(self):
        """Test corp chain with no orders in last 90 days returns empty."""
        # Create corp chain but no orders
        TestDataFactory.create_customer_corp_chain(
            cust_corp_chain_nbr="CORPCHAIN_NO_ORDERS",
            name="Corp Chain No Orders"
        )

        url = reverse('material:material-list')
        response = self.client.get(url, {'cust_corp_chain': 'CORPCHAIN_NO_ORDERS', 'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 0)


class ContextualFilterDropdownsIntegrationTest(BaseAPITestCase):
    """Integration tests for filter dropdown endpoints that accept global filter params."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(
            entra_id="test_contextual_dropdowns",
            email="test@example.com",
        )
        self.client.force_authenticate(user=self.user)
        self.vendor1 = TestDataFactory.create_vendor(name="Context Vendor A", vendor_nbr="CV001")
        self.vendor2 = TestDataFactory.create_vendor(name="Context Vendor B", vendor_nbr="CV002")
        self.mat1 = TestDataFactory.create_material(
            name="Context Mat 1", mat_nbr="CMAT001", vendor=self.vendor1,
            material_group="Cardio", hic3_therapy_class="CARDIO",
            buyer_name="Buyer One", buyer_cd="CB1",
            cat_mgr_name="Cat Mgr One", cat_mgr_nbr="CM1",
            fdb_gcn_seq_nbr="CGCN1", xplant_mat_stat="Active",
        )
        self.mat2 = TestDataFactory.create_material(
            name="Context Mat 2", mat_nbr="CMAT002", vendor=self.vendor2,
            material_group="Diabetes", hic3_therapy_class="DIABETES",
            buyer_name="Buyer Two", buyer_cd="CB2",
            cat_mgr_name="Cat Mgr Two", cat_mgr_nbr="CM2",
            fdb_gcn_seq_nbr="CGCN2", xplant_mat_stat="Inactive",
        )

    def _results(self, response):
        """Paginated list endpoints return response.data['results']; some return list directly."""
        if isinstance(response.data, list):
            return response.data
        return response.data.get("results", [])

    def test_material_group_list_narrowed_by_supplier(self):
        """GET /material/group/?supplier=X returns only groups for that vendor's materials."""
        url = reverse("material:material-group-list")
        response = self.client.get(url, {"supplier": str(self.vendor1.id)})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        groups = [r["material_group"] for r in self._results(response)]
        self.assertIn("Cardio", groups)
        self.assertNotIn("Diabetes", groups)

    def test_material_group_list_no_params_returns_all(self):
        """GET /material/group/ with no params returns all groups (regression)."""
        url = reverse("material:material-group-list")
        response = self.client.get(url, {"limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        groups = [r["material_group"] for r in self._results(response)]
        self.assertIn("Cardio", groups)
        self.assertIn("Diabetes", groups)

    def test_therapy_class_list_narrowed_by_supplier(self):
        """GET /material/therapy-class/?supplier=X returns only therapy classes for that vendor."""
        url = reverse("material:therapy-class-list")
        response = self.client.get(url, {"supplier": str(self.vendor2.id)})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        classes = [r["hic3_therapy_class"] for r in self._results(response)]
        self.assertIn("DIABETES", classes)
        self.assertNotIn("CARDIO", classes)

    def test_gcn_list_narrowed_by_product_category(self):
        """GET /material/gcn/?product_category=Cardio returns only GCNs in that category."""
        url = reverse("material:gcn-list")
        response = self.client.get(url, {"product_category": "Cardio"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        gcns = [r["fdb_gcn_seq_nbr"] for r in self._results(response)]
        self.assertIn("CGCN1", gcns)
        self.assertNotIn("CGCN2", gcns)

    def test_vendor_list_narrowed_by_product_category(self):
        """GET /vendor/?product_category=X returns only vendors that have materials in that category."""
        url = reverse("vendor:list")
        response = self.client.get(url, {"product_category": "Diabetes"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        vendor_ids = [v["id"] for v in self._results(response)]
        self.assertIn(self.vendor2.id, vendor_ids)
        self.assertNotIn(self.vendor1.id, vendor_ids)

    def test_vendor_list_no_params_returns_all(self):
        """GET /vendor/ with no global filter params returns all vendors (regression)."""
        url = reverse("vendor:list")
        response = self.client.get(url, {"limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(
            len(self._results(response)), 2,
            "Vendor list should include at least both test vendors when no filters applied",
        )

    def test_formulary_unique_list_narrowed_by_supplier(self):
        """GET /material-formulary/unique/?supplier=X returns only formularies for that vendor's materials."""
        from api.material_formulary.models import MaterialFormulary
        MaterialFormulary.objects.create(parent_program="Program Alpha", material=self.mat1)
        MaterialFormulary.objects.create(parent_program="Program Beta", material=self.mat2)
        url = reverse("material_formulary:unique-list")
        response = self.client.get(url, {"supplier": str(self.vendor1.id)})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Serializer exposes parent_program as "name"
        names = [r.get("name", r.get("parent_program")) for r in response.data]
        self.assertIn("Program Alpha", names)
        self.assertNotIn("Program Beta", names)

    def test_customer_corp_chain_list_narrowed_by_supplier(self):
        """GET /customer-corp-chain/?supplier=X returns only corp chains with orders for that vendor's materials."""
        corp1 = TestDataFactory.create_customer_corp_chain(
            cust_corp_chain_nbr="CTX_CC1", name="Context Corp 1",
        )
        corp2 = TestDataFactory.create_customer_corp_chain(
            cust_corp_chain_nbr="CTX_CC2", name="Context Corp 2",
        )
        plant = TestDataFactory.create_plant(plant_nbr="P001")
        OrderTransaction.objects.create(
            sales_doc_nbr="S1", sales_doc_itm_nbr="1",
            material=self.mat1, total_order_qty=10, ord_created_date=timezone.now().date(),
            plant=plant, cust_corp_chain_nbr=corp1,
        )
        OrderTransaction.objects.create(
            sales_doc_nbr="S2", sales_doc_itm_nbr="2",
            material=self.mat2, total_order_qty=20, ord_created_date=timezone.now().date(),
            plant=plant, cust_corp_chain_nbr=corp2,
        )
        url = reverse("customer_corp_chain:list")
        response = self.client.get(url, {"supplier": str(self.vendor1.id)})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        corp_nbrs = [c["cust_corp_chain_nbr"] for c in self._results(response)]
        self.assertIn("CTX_CC1", corp_nbrs)
        self.assertNotIn("CTX_CC2", corp_nbrs)


# =============================================================================
# INTEGRATION TESTS - Supplier Parent Global Filter
# =============================================================================


class VendorParentListEndpointTest(BaseAPITestCase):
    """Integration tests for the vendor parents list endpoint."""

    def setUp(self):
        super().setUp()
        self.user = TestDataFactory.create_test_user(
            entra_id="test_parent_endpoint",
            email="test@example.com",
        )
        self.client.force_authenticate(user=self.user)

        self.vendor1 = TestDataFactory.create_vendor(
            name="Child Vendor A", vendor_nbr="CVA001",
            vendor_parent_id="PARENT001", vendor_parent_name="Parent Corp Alpha",
        )
        self.vendor2 = TestDataFactory.create_vendor(
            name="Child Vendor B", vendor_nbr="CVB001",
            vendor_parent_id="PARENT001", vendor_parent_name="Parent Corp Alpha",
        )
        self.vendor3 = TestDataFactory.create_vendor(
            name="Child Vendor C", vendor_nbr="CVC001",
            vendor_parent_id="PARENT002", vendor_parent_name="Parent Corp Beta",
        )
        self.vendor_no_parent = TestDataFactory.create_vendor(
            name="Orphan Vendor", vendor_nbr="ORPH001",
        )

    def test_parents_endpoint_returns_distinct_parents(self):
        """GET /vendor/parents/ returns distinct parent vendors."""
        url = reverse("vendor:parent_list")
        response = self.client.get(url, {"limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        parent_ids = [r["vendor_parent_id"] for r in response.data["results"]]
        self.assertIn("PARENT001", parent_ids)
        self.assertIn("PARENT002", parent_ids)
        # Should be distinct — PARENT001 appears only once even though two vendors share it
        self.assertEqual(parent_ids.count("PARENT001"), 1)

    def test_parents_endpoint_excludes_null_parents(self):
        """Vendors without vendor_parent_id are excluded."""
        url = reverse("vendor:parent_list")
        response = self.client.get(url, {"limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        parent_ids = [r["vendor_parent_id"] for r in response.data["results"]]
        self.assertTrue(all(pid for pid in parent_ids))

    def test_parents_endpoint_search_by_name(self):
        """Search by parent name filters results."""
        url = reverse("vendor:parent_list")
        response = self.client.get(url, {"search": "Alpha", "limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        parent_ids = [r["vendor_parent_id"] for r in response.data["results"]]
        self.assertIn("PARENT001", parent_ids)
        self.assertNotIn("PARENT002", parent_ids)

    def test_parents_endpoint_search_by_id(self):
        """Search by parent id filters results."""
        url = reverse("vendor:parent_list")
        response = self.client.get(url, {"search": "PARENT002", "limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        parent_ids = [r["vendor_parent_id"] for r in response.data["results"]]
        self.assertIn("PARENT002", parent_ids)
        self.assertNotIn("PARENT001", parent_ids)

    def test_parents_endpoint_search_no_results(self):
        """Search with non-matching term returns empty."""
        url = reverse("vendor:parent_list")
        response = self.client.get(url, {"search": "NonExistent", "limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["results"]), 0)

    def test_parents_endpoint_is_paginated(self):
        """Response has pagination fields."""
        url = reverse("vendor:parent_list")
        response = self.client.get(url, {"limit": 1})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("count", response.data)
        self.assertIn("results", response.data)
        self.assertEqual(len(response.data["results"]), 1)


class SupplierParentGlobalFilterTest(BaseAPITestCase):
    """Integration tests for supplier_parent as a global filter parameter."""

    def setUp(self):
        self.user = TestDataFactory.create_test_user(
            entra_id="test_supplier_parent_filter",
            email="test@example.com",
        )
        self.client.force_authenticate(user=self.user)

        self.vendor_alpha = TestDataFactory.create_vendor(
            name="Alpha Child 1", vendor_nbr="AC001",
            vendor_parent_id="PARENT_A", vendor_parent_name="Parent A Corp",
        )
        self.vendor_alpha2 = TestDataFactory.create_vendor(
            name="Alpha Child 2", vendor_nbr="AC002",
            vendor_parent_id="PARENT_A", vendor_parent_name="Parent A Corp",
        )
        self.vendor_beta = TestDataFactory.create_vendor(
            name="Beta Child 1", vendor_nbr="BC001",
            vendor_parent_id="PARENT_B", vendor_parent_name="Parent B Corp",
        )

        self.material_a1 = TestDataFactory.create_material(
            name="Material Alpha 1", mat_nbr="MATALPHA1", vendor=self.vendor_alpha,
            product_family="Oncology",
        )
        self.material_a2 = TestDataFactory.create_material(
            name="Material Alpha 2", mat_nbr="MATALPHA2", vendor=self.vendor_alpha2,
            product_family="Oncology",
        )
        self.material_b1 = TestDataFactory.create_material(
            name="Material Beta 1", mat_nbr="MATBETA1", vendor=self.vendor_beta,
            product_family="Diabetes",
        )

    def test_material_filter_by_supplier_parent(self):
        """Materials filtered by supplier_parent show only those with matching vendor_parent_id."""
        url = reverse("material:material-list")
        response = self.client.get(url, {"supplier_parent": "PARENT_A", "limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mat_nbrs = [m["mat_nbr"] for m in response.data["results"]]
        self.assertIn("MATALPHA1", mat_nbrs)
        self.assertIn("MATALPHA2", mat_nbrs)
        self.assertNotIn("MATBETA1", mat_nbrs)

    def test_material_filter_by_supplier_parent_multi(self):
        """Multiple supplier_parent IDs (comma-separated) work."""
        url = reverse("material:material-list")
        response = self.client.get(url, {"supplier_parent": "PARENT_A,PARENT_B", "limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mat_nbrs = [m["mat_nbr"] for m in response.data["results"]]
        self.assertIn("MATALPHA1", mat_nbrs)
        self.assertIn("MATBETA1", mat_nbrs)

    def test_material_filter_by_supplier_parent_nonexistent(self):
        """Non-existent supplier_parent returns empty results."""
        url = reverse("material:material-list")
        response = self.client.get(url, {"supplier_parent": "NONEXISTENT", "limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 0)

    def test_vendor_list_filter_by_supplier_parent(self):
        """Vendor list filtered by supplier_parent returns only child vendors."""
        url = reverse("vendor:list")
        response = self.client.get(url, {"supplier_parent": "PARENT_A", "limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        vendor_nbrs = [v["vendor_nbr"] for v in response.data["results"]]
        self.assertIn("AC001", vendor_nbrs)
        self.assertIn("AC002", vendor_nbrs)
        self.assertNotIn("BC001", vendor_nbrs)

    def test_supplier_parent_combined_with_other_filters(self):
        """supplier_parent works correctly when combined with other global filters."""
        url = reverse("material:material-list")
        response = self.client.get(url, {
            "supplier_parent": "PARENT_A",
            "product_family": "Oncology",
            "limit": 50,
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mat_nbrs = [m["mat_nbr"] for m in response.data["results"]]
        self.assertIn("MATALPHA1", mat_nbrs)
        self.assertIn("MATALPHA2", mat_nbrs)
        self.assertNotIn("MATBETA1", mat_nbrs)

    def test_supplier_parent_combined_with_supplier_filter(self):
        """supplier_parent intersects correctly with supplier filter."""
        url = reverse("material:material-list")
        response = self.client.get(url, {
            "supplier_parent": "PARENT_A",
            "supplier": str(self.vendor_alpha.id),
            "limit": 50,
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mat_nbrs = [m["mat_nbr"] for m in response.data["results"]]
        self.assertIn("MATALPHA1", mat_nbrs)
        self.assertNotIn("MATALPHA2", mat_nbrs)
        self.assertNotIn("MATBETA1", mat_nbrs)

    def test_supplier_parent_in_mixin_filters(self):
        """supplier_parent is available in GlobalFilterMixin."""
        from api.global_filters import GlobalFilterMixin
        from django_filters import FilterSet as DFFilterSet

        class TestFilter(GlobalFilterMixin, DFFilterSet):
            class Meta:
                model = Material
                fields = []

        f = TestFilter()
        self.assertIn("supplier_parent", f.filters)

    def test_supplier_parent_in_related_mixin_filters(self):
        """supplier_parent is available in GlobalFilterForRelatedMaterialMixin."""
        from api.global_filters import GlobalFilterForRelatedMaterialMixin
        from django_filters import FilterSet as DFFilterSet

        class TestFilter(GlobalFilterForRelatedMaterialMixin, DFFilterSet):
            class Meta:
                model = OrderTransaction
                fields = []

        f = TestFilter()
        self.assertIn("supplier_parent", f.filters)
