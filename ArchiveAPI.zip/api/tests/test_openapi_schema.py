from django.conf import settings
from django.test import SimpleTestCase
from drf_spectacular.generators import SchemaGenerator


def _resolve_schema(schema, schema_or_ref):
    if "$ref" in schema_or_ref:
        ref = schema_or_ref["$ref"].rsplit("/", 1)[-1]
        return schema["components"]["schemas"][ref]
    return schema_or_ref


def _api_path(suffix: str) -> str:
    """Build an OpenAPI path using the configured API_PATH_PREFIX."""
    suffix = suffix.lstrip("/")
    prefix = (settings.API_PATH_PREFIX or "").strip("/")
    if prefix:
        return f"/{prefix}/{suffix}"
    return f"/{suffix}"


class TestOpenAPISchemaEnvelopes(SimpleTestCase):
    def setUp(self):
        self.schema = SchemaGenerator().get_schema(request=None, public=True)
        self.tenants_path = _api_path("tenants/")

    def test_success_response_includes_envelope(self):
        operation = self.schema["paths"][self.tenants_path]["get"]
        schema_200 = _resolve_schema(
            self.schema,
            operation["responses"]["200"]["content"]["application/json"]["schema"],
        )
        self.assertEqual(schema_200["properties"]["success"]["enum"], [True])
        self.assertIn("data", schema_200["properties"])

    def test_error_response_matches_formatter(self):
        operation = self.schema["paths"][self.tenants_path]["get"]
        schema_401 = _resolve_schema(
            self.schema,
            operation["responses"]["401"]["content"]["application/json"]["schema"],
        )
        self.assertIn("success", schema_401["properties"])
        self.assertIn("type", schema_401["properties"])
        self.assertIn("code", schema_401["properties"])
        self.assertIn("error", schema_401["properties"])
        self.assertNotIn("errors", schema_401["properties"])
