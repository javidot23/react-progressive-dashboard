from datetime import date
from unittest.mock import MagicMock

from django.test import SimpleTestCase, TestCase
from rest_framework.exceptions import ValidationError

from api.csv_export import (
    DEFAULT_EXPORT_MAX_ROWS,
    apply_ordering,
    csv_bool,
    csv_cell,
    csv_date,
    csv_percentage,
    csv_rounded,
    enforce_export_row_cap,
    enforce_export_row_cap_count,
    get_filtered_ordered_queryset,
    streaming_csv_response,
    wrap_csv_rows_with_tenant,
)
from api.tenant.exceptions import ActiveTenantRequired
from config.tenant_db import get_active_tenant_db, set_active_tenant_db
from tests.BaseTestCase import bind_test_tenant_db


class CsvFormatterTests(SimpleTestCase):
    def test_csv_cell_none_is_empty(self):
        self.assertEqual(csv_cell(None), "")
        self.assertEqual(csv_cell("abc"), "abc")
        self.assertEqual(csv_cell(12), 12)

    def test_csv_bool(self):
        self.assertEqual(csv_bool(None), "")
        self.assertEqual(csv_bool(True), "true")
        self.assertEqual(csv_bool(False), "false")

    def test_csv_date(self):
        self.assertEqual(csv_date(None), "")
        self.assertEqual(csv_date(date(2026, 8, 13)), "2026-08-13")
        self.assertEqual(csv_date("2026-08-13"), "2026-08-13")

    def test_csv_rounded(self):
        self.assertEqual(csv_rounded(None), "")
        self.assertEqual(csv_rounded(83.333333), 83.3333)
        self.assertEqual(csv_rounded(12.3456, 1), 12.3)

    def test_csv_percentage(self):
        self.assertEqual(csv_percentage(None), "")
        self.assertEqual(csv_percentage(80.0), 80.0)
        self.assertEqual(csv_percentage(83.333333), 83.3333)


class ApplyOrderingTests(SimpleTestCase):
    def setUp(self):
        self.queryset = MagicMock()
        self.queryset.order_by.return_value = "ordered"
        self.request = MagicMock()
        self.allowed = ["po_number", "po_due_date", "material_name"]
        self.default = ["-po_due_date", "po_number"]

    def test_uses_allowed_ordering_fields(self):
        self.request.query_params.get.return_value = "material_name,-po_due_date"
        result = apply_ordering(self.queryset, self.request, self.allowed, self.default)
        self.queryset.order_by.assert_called_once_with("material_name", "-po_due_date")
        self.assertEqual(result, "ordered")

    def test_ignores_disallowed_fields_and_falls_back(self):
        self.request.query_params.get.return_value = "not_a_field"
        apply_ordering(self.queryset, self.request, self.allowed, self.default)
        self.queryset.order_by.assert_called_once_with(*self.default)

    def test_empty_or_missing_ordering_uses_default(self):
        self.request.query_params.get.return_value = ""
        apply_ordering(self.queryset, self.request, self.allowed, self.default)
        self.queryset.order_by.assert_called_with(*self.default)

        self.queryset.order_by.reset_mock()
        self.request.query_params.get.return_value = None
        apply_ordering(self.queryset, self.request, self.allowed, self.default)
        self.queryset.order_by.assert_called_with(*self.default)

    def test_skips_blank_segments_and_keeps_valid_ones(self):
        self.request.query_params.get.return_value = ",po_number, ,secret"
        apply_ordering(self.queryset, self.request, self.allowed, self.default)
        self.queryset.order_by.assert_called_once_with("po_number")

    def test_maps_public_ordering_fields_and_preserves_direction(self):
        self.request.query_params.get.return_value = "material_name,-po_number"
        apply_ordering(
            self.queryset,
            self.request,
            self.allowed,
            self.default,
            field_map={
                "material_name": "material__name",
                "po_number": "purchase_order_number",
            },
        )
        self.queryset.order_by.assert_called_once_with(
            "material__name", "-purchase_order_number"
        )

    def test_strict_ordering_rejects_disallowed_fields(self):
        self.request.query_params.get.return_value = "material_name,secret"

        with self.assertRaises(ValidationError) as ctx:
            apply_ordering(
                self.queryset,
                self.request,
                self.allowed,
                self.default,
                strict=True,
            )

        self.assertIn("Invalid ordering", str(ctx.exception.detail))
        self.queryset.order_by.assert_not_called()


class FilteredOrderedQuerysetTests(SimpleTestCase):
    def test_applies_filterset_then_ordering(self):
        request = MagicMock()
        request.query_params.get.return_value = "name"
        base_qs = MagicMock()
        filtered_qs = MagicMock()
        ordered_qs = MagicMock()
        filtered_qs.order_by.return_value = ordered_qs

        filterset = MagicMock()
        filterset.qs = filtered_qs
        filterset_class = MagicMock(return_value=filterset)

        result = get_filtered_ordered_queryset(
            request,
            base_qs,
            filterset_class,
            ["name"],
            ["-name"],
        )

        filterset_class.assert_called_once_with(request.query_params, queryset=base_qs)
        filtered_qs.order_by.assert_called_once_with("name")
        self.assertEqual(result, ordered_qs)

    def test_skips_filterset_when_none(self):
        request = MagicMock()
        request.query_params.get.return_value = None
        base_qs = MagicMock()
        base_qs.order_by.return_value = "default-ordered"

        result = get_filtered_ordered_queryset(
            request, base_qs, None, ["name"], ["-name"]
        )
        base_qs.order_by.assert_called_once_with("-name")
        self.assertEqual(result, "default-ordered")


class EnforceExportRowCapTests(SimpleTestCase):
    def test_returns_count_when_under_cap(self):
        queryset = MagicMock()
        queryset.count.return_value = 10
        self.assertEqual(enforce_export_row_cap(queryset, max_rows=100), 10)

    def test_raises_when_over_cap(self):
        queryset = MagicMock()
        queryset.count.return_value = DEFAULT_EXPORT_MAX_ROWS + 1
        with self.assertRaises(ValidationError) as ctx:
            enforce_export_row_cap(queryset)
        self.assertIn("Export exceeds the maximum", str(ctx.exception.detail))


class EnforceExportRowCapCountTests(SimpleTestCase):
    def test_returns_count_when_under_cap(self):
        self.assertEqual(enforce_export_row_cap_count(10, max_rows=100), 10)

    def test_raises_when_over_cap(self):
        with self.assertRaises(ValidationError) as ctx:
            enforce_export_row_cap_count(DEFAULT_EXPORT_MAX_ROWS + 1)
        self.assertIn("Export exceeds the maximum", str(ctx.exception.detail))


class StreamingCsvResponseTests(SimpleTestCase):
    def test_sets_csv_download_headers(self):
        response = streaming_csv_response([["A", "B"], ["1", "2"]], "otif_exceptions")
        self.assertEqual(response["Content-Type"], "text/csv")
        self.assertIn("attachment; filename=", response["Content-Disposition"])
        self.assertIn("otif_exceptions_", response["Content-Disposition"])
        self.assertEqual(response["X-Accel-Buffering"], "no")
        content = b"".join(response.streaming_content).decode("utf-8")
        self.assertIn("A,B", content)
        self.assertIn("1,2", content)


class WrapCsvRowsWithTenantTests(TestCase):
    databases = "__all__"

    def setUp(self):
        self.tenant = bind_test_tenant_db()

    def _rows_requiring_tenant(self):
        get_active_tenant_db()
        yield ["header"]
        get_active_tenant_db()
        yield ["data"]

    def test_wrapped_rows_work_after_tenant_cleared(self):
        rows = wrap_csv_rows_with_tenant(self.tenant, self._rows_requiring_tenant())
        set_active_tenant_db(None)
        self.assertEqual(list(rows), [["header"], ["data"]])

    def test_unwrapped_rows_fail_after_tenant_cleared(self):
        rows = self._rows_requiring_tenant()
        set_active_tenant_db(None)
        with self.assertRaises(ActiveTenantRequired):
            next(rows)
