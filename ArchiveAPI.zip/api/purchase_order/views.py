from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import FilterSet, filters, DjangoFilterBackend
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework import generics, status
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView

from api.global_filters import get_filtered_material_subquery
from api.service_level.services import ServiceLevelService
from .filters import PurchaseOrderFilter, OtifExceptionFilter, MaterialPurchaseOrderLineFilter
from .models import PurchaseOrder
from .serializers import PurchaseOrderWithMaterialsAndPlantsSerializer, \
    MaterialOtifTrendsSerializer, OtifTotalSerializer, MaterialOtifSummarySerializer, WeeklyOtifTrendsSerializer, \
    OtifTrendsSerializer, PurchaseOrderListSerializer, LinePerformanceAndServiceLevelSerializer, \
    WeeklyOtifLineCountsSerializer, MaterialPurchaseOrderSnapshotSerializer, OtifExceptionSerializer, \
    MaterialPurchaseOrderLineSerializer
from .services import PurchaseOrderService
from ..pagination import MaxLimitOffsetPagination


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class PurchaseOrderListView(generics.ListAPIView):
    """
    List view for PurchaseOrder with filtering and pagination.
    """
    # queryset = PurchaseOrderService.list_latest_purchase_orders_with_materials_and_plants()
    serializer_class = PurchaseOrderListSerializer
    filterset_class = PurchaseOrderFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = [
        'id', 'po_number', 'po_line_number', 'original_order_qty', 'received_qty',
        'units_received_on_time', 'units_received_late', 'units_not_received',
        'anticipated_date', 'ordered_date', 'material__name', 'material__mat_nbr'
    ]
    ordering = ['-ordered_date']
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        return PurchaseOrderService.list_latest_purchase_orders_with_materials_and_plants()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
@extend_schema_view(get=extend_schema(operation_id='api_purchase_order_history_list'))
class PurchaseOrderHistoryView(generics.ListAPIView):
    """
    Retrieve view for a specific PurchaseOrder by ID.
    """
    serializer_class = PurchaseOrderWithMaterialsAndPlantsSerializer
    pagination_class = None

    def get_queryset(self):
        po_number = self.kwargs.get('po_number')
        return PurchaseOrderService.get_purchase_order_by_id(po_number)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialPurchaseOrderSnapshotsView(generics.ListAPIView):
    """Return the latest snapshot per PO line for a given material (last 90 days)."""
    serializer_class = MaterialPurchaseOrderSnapshotSerializer
    pagination_class = None

    def get_queryset(self):
        material_id = self.kwargs.get('material_id')
        return PurchaseOrderService.get_latest_purchase_orders_by_material(material_id)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class DailyOtifTrendsView(generics.ListAPIView):
    """
    View for daily OTIF trends for the last 30 days.
    Does not support global filters - shows overall performance.
    """
    serializer_class = OtifTrendsSerializer
    pagination_class = None

    def get_queryset(self):
        return PurchaseOrderService.get_daily_otif_trends()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
@extend_schema_view(get=extend_schema(operation_id='api_purchase_order_otif_trends_by_material_list'))
class MaterialDailyOtifTrendsView(generics.ListAPIView):
    """
    View for daily OTIF trends for given material for the last 90 days.
    """
    serializer_class = MaterialOtifTrendsSerializer
    pagination_class = None

    def get_queryset(self):
        material_id = self.kwargs.get('material_id')
        return PurchaseOrderService.get_material_daily_otif_trends(material_id)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class OtifTotalView(generics.ListAPIView):
    """
    View for OTIF total percentage.
    Supports global filters.
    """
    serializer_class = OtifTotalSerializer
    pagination_class = None

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return PurchaseOrderService.get_today_otif_percentage(direct_mat_nbr, mat_nbr_subquery)


class MaterialOtifSummaryFilter(FilterSet):
    """
    FilterSet for Material OTIF Summary.
    """
    material = filters.CharFilter(field_name="mat_nbr", lookup_expr="exact")
    units_ordered_min = filters.NumberFilter(field_name="units_ordered", lookup_expr="gte")
    units_ordered_max = filters.NumberFilter(field_name="units_ordered", lookup_expr="lte")
    units_received_on_time_min = filters.NumberFilter(field_name="units_received_on_time", lookup_expr="gte")
    units_received_on_time_max = filters.NumberFilter(field_name="units_received_on_time", lookup_expr="lte")
    units_received_late_min = filters.NumberFilter(field_name="units_received_late", lookup_expr="gte")
    units_received_late_max = filters.NumberFilter(field_name="units_received_late", lookup_expr="lte")
    units_not_received_min = filters.NumberFilter(field_name="units_not_received", lookup_expr="gte")
    units_not_received_max = filters.NumberFilter(field_name="units_not_received", lookup_expr="lte")
    total_orders_min = filters.NumberFilter(field_name="total_orders", lookup_expr="gte")
    total_orders_max = filters.NumberFilter(field_name="total_orders", lookup_expr="lte")

    class Meta:
        model = PurchaseOrder
        fields = []


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialOtifSummaryView(generics.ListAPIView):
    """
    View for material OTIF summary with pagination.
    Groups purchase orders by material and returns aggregated statistics.
    Supports global filters.
    """
    serializer_class = MaterialOtifSummarySerializer
    pagination_class = MaxLimitOffsetPagination
    filterset_class = MaterialOtifSummaryFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = ['units_ordered', 'units_received_on_time', 'units_received_late', 'units_not_received',
                       'total_orders']
    ordering = ['-units_ordered']

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return PurchaseOrderService.get_material_otif_summary(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class WeeklyOtifTrendsView(generics.ListAPIView):
    """
    View for weekly OTIF trends for the last 90 days.
    Supports global filters.
    """
    serializer_class = WeeklyOtifTrendsSerializer
    pagination_class = None

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return PurchaseOrderService.get_weekly_otif_trends(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class WeeklyOtifLineCountsView(generics.ListAPIView):
    """
    View for weekly OTIF line counts for the last 90 days, grouped by anticipated_date week.
    Uses the latest snapshot per order (by as_of_date) from the materialized view.
    Returns counts for OTIF, OT-but-not-IF, IF-but-not-OT, and NOT-OT-or-IF lines,
    along with OTIF percentage per week.
    Supports global filters.
    """
    serializer_class = WeeklyOtifLineCountsSerializer
    pagination_class = None

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return PurchaseOrderService.get_weekly_otif_line_counts(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
@extend_schema_view(get=extend_schema(operation_id='api_purchase_order_otif_exceptions_list'))
class OtifExceptionsView(generics.ListAPIView):
    """
    Line-level OTIF Exceptions drill-through for the last 90 days (anticipated_date).
    Returns non-perfect lines only (on time or in full is false). Perfect orders are excluded.
    received_date is completion_date and may be null when the line is not closed.
    Supports global filters, category/year/week drill-through filters, ordering, and pagination.
    """
    serializer_class = OtifExceptionSerializer
    filterset_class = OtifExceptionFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = [
        'po_number', 'po_line_number', 'material_name', 'material_number', 'ndc',
        'otif_percent', 'in_full', 'on_time', 'plant_nbr', 'plant_name', 'plant_state',
        'po_due_date', 'received_date', 'units_ordered', 'units_not_received',
        'units_received_late', 'material_status',
    ]
    ordering = ['-po_due_date', 'po_number', 'po_line_number']
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return PurchaseOrderService.list_otif_exceptions(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
@extend_schema_view(get=extend_schema(operation_id='api_purchase_order_material_lines_list'))
class MaterialPurchaseOrderLinesView(generics.ListAPIView):
    """
    All-materials PO line drill-through (PurchaseOrderLatest90dMV).
    Flat table for low-performance "see all purchase orders by material".
    Supports global material filters, ordering, and pagination.
    """
    serializer_class = MaterialPurchaseOrderLineSerializer
    filterset_class = MaterialPurchaseOrderLineFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = [
        'ordered_date', 'po_number', 'anticipated_date', 'units_ordered',
        'units_received_on_time', 'units_not_received', 'units_received_late',
        'inbound_fill_rate', 'material_status', 'material_name', 'material_number', 'ndc',
    ]
    ordering = ['-ordered_date', 'po_number', 'po_line_number']
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV
            return PurchaseOrderLatest90dMV.objects.none()
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return PurchaseOrderService.list_material_purchase_order_lines(
            direct_mat_nbr, mat_nbr_subquery
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class LinePerformanceAndServiceLevelView(APIView):
    """
    View that returns:
    - Percentage of lines "on time" and percentage of lines "in full" from purchase orders (last 90 days)
    - Units on order and inbound fill rate from service level (last 90 days)
    Supports global filters.
    """

    @extend_schema(responses=LinePerformanceAndServiceLevelSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)

        # Get line performance percentages from purchase orders
        line_performance = PurchaseOrderService.get_line_performance_percentages(direct_mat_nbr, mat_nbr_subquery)

        # Get units on order and fill rate from service level
        service_level_metrics = ServiceLevelService.get_units_on_order_and_fill_rate(direct_mat_nbr, mat_nbr_subquery)

        # Combine the results
        combined_data = {
            **line_performance,
            **service_level_metrics
        }

        serializer = LinePerformanceAndServiceLevelSerializer(combined_data)
        return Response(serializer.data, status=status.HTTP_200_OK)
