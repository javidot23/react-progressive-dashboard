from django.db.models import Q
from django_filters.rest_framework import FilterSet, filters

from api.global_filters import CharInFilter, GlobalFilterForRelatedMaterialMixin
from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV
from api.purchase_order.models import PurchaseOrder


class PurchaseOrderFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """
    FilterSet for PurchaseOrder model with global filters support.
    Includes global filters: supplier, product_family, therapeutic_class, buyer,
    category_manager, material, gcn, and formulary.
    """
    plant_nbr = filters.CharFilter(field_name="plant__id", lookup_expr="iexact")
    material_id = filters.CharFilter(field_name="material__id", lookup_expr="iexact")
    buffered_late_flag = filters.BooleanFilter(field_name="buffered_late_flag")
    buffered_ot_flag = filters.BooleanFilter(field_name="buffered_ot_flag")

    # Date range filters
    anticipated_date = filters.DateFilter(field_name='anticipated_date')
    anticipated_date_from = filters.DateFilter(field_name='anticipated_date', lookup_expr='gte')
    anticipated_date_to = filters.DateFilter(field_name='anticipated_date', lookup_expr='lte')
    ordered_date = filters.DateFilter(field_name='ordered_date')
    ordered_date_from = filters.DateFilter(field_name='ordered_date', lookup_expr='gte')
    ordered_date_to = filters.DateFilter(field_name='ordered_date', lookup_expr='lte')

    # Numeric range filters
    original_order_qty_min = filters.NumberFilter(field_name='original_order_qty', lookup_expr='gte')
    original_order_qty_max = filters.NumberFilter(field_name='original_order_qty', lookup_expr='lte')
    received_qty_min = filters.NumberFilter(field_name='received_qty', lookup_expr='gte')
    received_qty_max = filters.NumberFilter(field_name='received_qty', lookup_expr='lte')
    units_received_on_time_min = filters.NumberFilter(field_name='units_received_on_time', lookup_expr='gte')
    units_received_on_time_max = filters.NumberFilter(field_name='units_received_on_time', lookup_expr='lte')
    units_received_late_min = filters.NumberFilter(field_name='units_received_late', lookup_expr='gte')
    units_received_late_max = filters.NumberFilter(field_name='units_received_late', lookup_expr='lte')
    units_not_received_min = filters.NumberFilter(field_name='units_not_received', lookup_expr='gte')
    units_not_received_max = filters.NumberFilter(field_name='units_not_received', lookup_expr='lte')

    class Meta:
        model = PurchaseOrder
        fields = ['plant']


class OtifExceptionFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """
    FilterSet for OTIF Exceptions list (PurchaseOrderLatest90dMV).
    Category choices match the non-perfect WeeklyOtifLineCounts buckets.
    """
    CATEGORY_CHOICES = (
        ("ot_but_not_if", "On time but not in full"),
        ("if_but_not_ot", "In full but not on time"),
        ("not_ot_or_if", "Neither on time nor in full"),
    )

    category = filters.ChoiceFilter(choices=CATEGORY_CHOICES, method="filter_category")
    year = filters.NumberFilter(field_name="year")
    week = filters.NumberFilter(field_name="week")

    in_full = filters.BooleanFilter(field_name="if_flag")
    on_time = filters.BooleanFilter(field_name="buffered_ot_flag")
    buffered_otif_flag = filters.BooleanFilter(field_name="buffered_otif_flag")
    buffered_late_flag = filters.BooleanFilter(field_name="buffered_late_flag")

    plant_nbr = filters.CharFilter(field_name="plant_id", lookup_expr="iexact")
    plant_name = filters.CharFilter(field_name="plant__name", lookup_expr="icontains")
    po_number = filters.CharFilter(field_name="po_number", lookup_expr="iexact")
    material_id = filters.CharFilter(field_name="material__id", lookup_expr="iexact")
    material_status = CharInFilter(lookup_expr="in", field_name="material_status")

    units_ordered_min = filters.NumberFilter(field_name="units_ordered", lookup_expr="gte")
    units_ordered_max = filters.NumberFilter(field_name="units_ordered", lookup_expr="lte")
    units_not_received_min = filters.NumberFilter(field_name="units_not_received", lookup_expr="gte")
    units_not_received_max = filters.NumberFilter(field_name="units_not_received", lookup_expr="lte")
    units_received_late_min = filters.NumberFilter(field_name="units_received_late", lookup_expr="gte")
    units_received_late_max = filters.NumberFilter(field_name="units_received_late", lookup_expr="lte")

    class Meta:
        model = PurchaseOrderLatest90dMV
        fields = []

    def filter_category(self, queryset, name, value):
        category_filters = {
            "ot_but_not_if": Q(buffered_ot_flag=True, if_flag=False),
            "if_but_not_ot": Q(if_flag=True, buffered_ot_flag=False),
            "not_ot_or_if": Q(buffered_ot_flag=False, if_flag=False),
        }
        q = category_filters.get(value)
        if q is None:
            return queryset
        return queryset.filter(q)


class MaterialPurchaseOrderLineFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """Filters for all-materials PO line drill-through (PurchaseOrderLatest90dMV)."""

    po_number = CharInFilter(lookup_expr="in", field_name="po_number")
    po_number_or_line_number = filters.CharFilter(method="filter_po_number_or_line_number")
    material_status = CharInFilter(lookup_expr="in", field_name="material_status")

    units_ordered_min = filters.NumberFilter(field_name="units_ordered", lookup_expr="gte")
    units_ordered_max = filters.NumberFilter(field_name="units_ordered", lookup_expr="lte")
    units_not_received_min = filters.NumberFilter(field_name="units_not_received", lookup_expr="gte")
    units_not_received_max = filters.NumberFilter(field_name="units_not_received", lookup_expr="lte")
    units_received_on_time_min = filters.NumberFilter(field_name="units_received_on_time", lookup_expr="gte")
    units_received_on_time_max = filters.NumberFilter(field_name="units_received_on_time", lookup_expr="lte")
    units_received_late_min = filters.NumberFilter(field_name="units_received_late", lookup_expr="gte")
    units_received_late_max = filters.NumberFilter(field_name="units_received_late", lookup_expr="lte")
    inbound_fill_rate_min = filters.NumberFilter(field_name="inbound_fill_rate", lookup_expr="gte")
    inbound_fill_rate_max = filters.NumberFilter(field_name="inbound_fill_rate", lookup_expr="lte")
    ordered_date_from = filters.DateFilter(field_name="ordered_date", lookup_expr="gte")
    ordered_date_to = filters.DateFilter(field_name="ordered_date", lookup_expr="lte")
    anticipated_date_from = filters.DateFilter(field_name="anticipated_date", lookup_expr="gte")
    anticipated_date_to = filters.DateFilter(field_name="anticipated_date", lookup_expr="lte")

    class Meta:
        model = PurchaseOrderLatest90dMV
        fields = []

    def filter_po_number_or_line_number(self, queryset, name, value):
        """Match comma-separated values against po_number OR po_line_number."""
        if not value:
            return queryset
        values = [v.strip() for v in value.split(',') if v.strip()]
        if not values:
            return queryset
        return queryset.filter(Q(po_number__in=values) | Q(po_line_number__in=values))
