from tests.BaseTestCase import BaseTestCase
from django.utils import timezone

from api.purchase_order.models import PurchaseOrder
from tests.TestDataFactory import TestDataFactory


class PurchaseOrderModelTest(BaseTestCase):
    def setUp(self):
        """Set up test data for purchase order model tests."""
        self.material = TestDataFactory.create_material()
        self.plant = TestDataFactory.create_plant()
        self.po_number = "PO98765"
        self.ordered_date = timezone.now().date()
        self.original_order_qty = 150

    def test_purchase_order_creation(self):
        """Test basic purchase order creation."""
        po = TestDataFactory.create_purchase_order(
            po_number=self.po_number,
            material=self.material,
            original_order_qty=self.original_order_qty,
            ordered_date=self.ordered_date,
            as_of_date=self.ordered_date,
            received_qty=50,
            buffered_late_flag=True,
            expected_delivery_days=5,
            plant=self.plant,
        )

        self.assertEqual(po.po_number, self.po_number)
        self.assertEqual(po.material, self.material)
        self.assertEqual(po.original_order_qty, self.original_order_qty)
        self.assertEqual(po.ordered_date, self.ordered_date)
        self.assertEqual(po.as_of_date, self.ordered_date)
        self.assertEqual(po.received_qty, 50)
        self.assertTrue(po.buffered_late_flag)
        self.assertEqual(po.expected_delivery_days, 5)
        self.assertIsNotNone(po.created_at)
        self.assertIsNotNone(po.updated_at)
        self.assertEqual(po.plant, self.plant)

    def test_material_cascade_delete(self):
        """Test that deleting a material deletes its purchase orders."""
        po = TestDataFactory.create_purchase_order(material=self.material)
        po_id = po.id
        self.material.delete()
        with self.assertRaises(PurchaseOrder.DoesNotExist):
            PurchaseOrder.objects.get(id=po_id)
