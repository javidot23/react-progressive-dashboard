from datetime import date, timedelta

from api.purchase_order.models import PurchaseOrder
from api.purchase_order.services import PurchaseOrderService
from tests.BaseTestCase import MVTestCase
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


PURCHASE_ORDER_LATEST_MV = ["purchase_order_latest_90d_mv"]


def refresh_purchase_order_mvs():
    MaterializedViewTestHelper.refresh_materialized_views(PURCHASE_ORDER_LATEST_MV)


class PurchaseOrderServiceTest(MVTestCase):
    @classmethod
    def setUpTestData(cls):
        """Set up test data for OTIF trends tests."""
        MaterializedViewTestHelper.create_materialized_views()

        cls.material1 = TestDataFactory.create_material()
        cls.material2 = TestDataFactory.create_material()
        cls.plant = TestDataFactory.create_plant(name="Test Plant")

        # Create test data for different days
        today = date.today()
        yesterday = today - timedelta(days=1)

        # Today's data - mixed results
        cls.purchase_order = TestDataFactory.create_purchase_order(
            po_number="PO001",
            material=cls.material1,
            as_of_date=today,
            buffered_ot_flag=True,
            if_flag=True,
            buffered_otif_flag=True,
            plant=cls.plant,
            received_qty=50,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO002",
            material=cls.material2,
            as_of_date=today,
            buffered_ot_flag=False,
            if_flag=True,
            buffered_otif_flag=False,
            plant=cls.plant,
            received_qty=50,
        )

        # Yesterday's data - all on time
        TestDataFactory.create_purchase_order(
            po_number="PO003",
            material=cls.material1,
            as_of_date=yesterday,
            buffered_ot_flag=True,
            if_flag=True,
            buffered_otif_flag=True,
            plant=cls.plant,
            received_qty=50
        )

        # Two days ago - no data (will test zero values)

        # Data outside 30 day range (should be excluded)
        old_date = today - timedelta(days=35)
        TestDataFactory.create_purchase_order(
            po_number="PO004",
            material=cls.material1,
            as_of_date=old_date,
            buffered_ot_flag=True,
            if_flag=True,
            buffered_otif_flag=True,
            plant=cls.plant,
            received_qty=50
        )
        refresh_purchase_order_mvs()

    def test_list_purchase_orders_with_materials_and_plants(self):
        """
        Test listing purchase orders with annotations for received quantities.
        """
        material = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant(name="Test Plant")
        TestDataFactory.create_purchase_order(
            po_number="PO12345",
            material=material,
            original_order_qty=100,
            ordered_date="2023-10-01",
            as_of_date="2023-10-01",
            received_qty=50,
            buffered_late_flag=True,
            expected_delivery_days=7,
            plant=plant,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            damaged_flag=True,
        )

        purchase_orders = PurchaseOrderService.list_latest_purchase_orders_with_materials_and_plants()

        order_po12345 = next((po for po in purchase_orders if po.po_number == "PO12345"), None)
        self.assertIsNotNone(order_po12345)

        self.assertTrue(hasattr(order_po12345, 'units_received_on_time'))
        self.assertTrue(hasattr(order_po12345, 'units_received_late'))
        self.assertTrue(hasattr(order_po12345, 'units_not_received'))
        self.assertEqual(order_po12345.units_received_on_time, 50)
        self.assertEqual(order_po12345.units_received_late, 50)
        self.assertEqual(order_po12345.units_not_received, 50)

    def test_get_purchase_order_by_id(self):
        """
        Test retrieving a specific purchase order by its ID.
        """
        po_number = self.purchase_order.po_number
        purchase_order = PurchaseOrderService.get_purchase_order_by_id(po_number)
        self.assertEqual(len(purchase_order), 1)
        self.assertEqual(purchase_order[0].po_number, po_number)
        self.assertEqual(purchase_order[0].material, self.material1)
        self.assertEqual(purchase_order[0].plant, self.plant)

    def test_get_daily_otif_trends_returns_30_days(self):
        """Test that the service returns exactly 30 days of data."""
        trends = PurchaseOrderService.get_daily_otif_trends()
        self.assertEqual(len(trends), 31)

    def test_get_daily_otif_trends_includes_all_dates(self):
        """Test that all dates in the range are included, even with no data."""
        trends = PurchaseOrderService.get_daily_otif_trends()

        # Check that we have consecutive dates
        expected_start = date.today() - timedelta(days=30)
        expected_end = date.today()

        trend_dates = [trend['day'] for trend in trends]

        current_date = expected_start
        while current_date <= expected_end:
            self.assertIn(current_date, trend_dates)
            current_date += timedelta(days=1)

    def test_get_daily_otif_trends_correct_counts(self):
        """Test that counts are calculated correctly for days with data."""
        trends = PurchaseOrderService.get_daily_otif_trends()

        today = date.today()
        today_trend = next((t for t in trends if t['day'] == today), None)
        self.assertIsNotNone(today_trend)

        self.assertEqual(today_trend['on_time_count'], 1)
        self.assertEqual(today_trend['in_full_count'], 2)
        self.assertEqual(today_trend['otif_count'], 1)
        self.assertEqual(today_trend['total_materials'], 2)

        # Find yesterday's data
        yesterday = today - timedelta(days=1)
        yesterday_trend = next((t for t in trends if t['day'] == yesterday), None)
        self.assertIsNotNone(yesterday_trend)

        self.assertEqual(yesterday_trend['on_time_count'], 1)
        self.assertEqual(yesterday_trend['in_full_count'], 1)
        self.assertEqual(yesterday_trend['otif_count'], 1)
        self.assertEqual(yesterday_trend['total_materials'], 1)

    def test_get_daily_otif_trends_zero_values_for_missing_days(self):
        """Test that days with no data return zero values."""
        trends = PurchaseOrderService.get_daily_otif_trends()

        # Find two days ago (should have no data)
        two_days_ago = date.today() - timedelta(days=2)
        two_days_ago_trend = next((t for t in trends if t['day'] == two_days_ago), None)
        self.assertIsNotNone(two_days_ago_trend)

        # Should have all zeros
        self.assertEqual(two_days_ago_trend['on_time_count'], 0)
        self.assertEqual(two_days_ago_trend['in_full_count'], 0)
        self.assertEqual(two_days_ago_trend['otif_count'], 0)
        self.assertEqual(two_days_ago_trend['total_materials'], 0)

    def test_get_daily_otif_trends_excludes_old_data(self):
        """Test that data outside the 30-day range is excluded."""
        trends = PurchaseOrderService.get_daily_otif_trends()

        old_date = date.today() - timedelta(days=35)
        old_trend = next((t for t in trends if t['day'] == old_date), None)
        self.assertIsNone(old_trend)

    def test_get_daily_otif_trends_returns_list_of_dicts(self):
        """Test that the service returns the correct data structure."""
        trends = PurchaseOrderService.get_daily_otif_trends()

        self.assertIsInstance(trends, list)
        self.assertGreater(len(trends), 0)

        # Check structure of first item
        trend = trends[0]
        self.assertIsInstance(trend, dict)
        self.assertIn('day', trend)
        self.assertIn('on_time_count', trend)
        self.assertIn('in_full_count', trend)
        self.assertIn('otif_count', trend)
        self.assertIn('total_materials', trend)

        # Check data types
        self.assertIsInstance(trend['day'], date)
        self.assertIsInstance(trend['on_time_count'], int)
        self.assertIsInstance(trend['in_full_count'], int)
        self.assertIsInstance(trend['otif_count'], int)
        self.assertIsInstance(trend['total_materials'], int)

    def test_get_daily_otif_trends_chronological_order(self):
        """Test that trends are returned in chronological order."""
        trends = PurchaseOrderService.get_daily_otif_trends()

        dates = [trend['day'] for trend in trends]
        self.assertEqual(dates, sorted(dates))

    def test_get_line_performance_percentages(self):
        """Test getting line performance percentages for last 90 days."""
        # Delete existing data and create new test data
        PurchaseOrder.objects.all().delete()
        today = date.today()

        # Create purchase orders within last 90 days with different line numbers
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        # Create PO with multiple lines - line 1 is on-time and in-full
        TestDataFactory.create_purchase_order(
            po_number="PO-TEST-001",
            material=material1,
            as_of_date=today - timedelta(days=10),
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        # Same PO, different line - line 2 is not on-time but is in-full
        TestDataFactory.create_purchase_order(
            po_number="PO-TEST-001",
            material=material2,
            as_of_date=today - timedelta(days=10),
            buffered_ot_flag=False,
            if_flag=True,
            plant=plant,
            po_line_number="002"
        )

        # Another PO - line 3 is on-time but not in-full
        TestDataFactory.create_purchase_order(
            po_number="PO-TEST-002",
            material=material1,
            as_of_date=today - timedelta(days=5),
            buffered_ot_flag=True,
            if_flag=False,
            plant=plant,
            po_line_number="001"
        )

        # Create historical snapshots (should use latest)
        TestDataFactory.create_purchase_order(
            po_number="PO-TEST-001",
            material=material1,
            as_of_date=today - timedelta(days=15),  # Older snapshot
            buffered_ot_flag=False,  # Older state - should be ignored
            if_flag=False,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_line_performance_percentages()

        self.assertIn('on_time_percentage', result)
        self.assertIn('in_full_percentage', result)
        self.assertIsInstance(result['on_time_percentage'], float)
        self.assertIsInstance(result['in_full_percentage'], float)

        # Should have 3 lines total (using latest snapshots)
        # Line 1: on-time=True, in-full=True
        # Line 2: on-time=False, in-full=True
        # Line 3: on-time=True, in-full=False
        # So: on_time = 2/3 = 66.67%, in_full = 2/3 = 66.67%
        self.assertEqual(result['on_time_percentage'], 66.67)
        self.assertEqual(result['in_full_percentage'], 66.67)

    def test_get_line_performance_percentages_uses_latest_snapshot(self):
        """Test that the method uses the latest snapshot per line."""
        PurchaseOrder.objects.all().delete()

        today = date.today()
        material = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        # Create older snapshot - not on-time
        TestDataFactory.create_purchase_order(
            po_number="PO-HIST-001",
            material=material,
            as_of_date=today - timedelta(days=50),
            buffered_ot_flag=False,
            if_flag=False,
            plant=plant,
            po_line_number="001"
        )

        # Create newer snapshot - is on-time and in-full (should be used)
        TestDataFactory.create_purchase_order(
            po_number="PO-HIST-001",
            material=material,
            as_of_date=today - timedelta(days=10),
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_line_performance_percentages()

        # Should use latest snapshot, so 100% on-time and in-full
        self.assertEqual(result['on_time_percentage'], 100.0)
        self.assertEqual(result['in_full_percentage'], 100.0)

    def test_get_line_performance_percentages_no_data(self):
        PurchaseOrder.objects.all().delete()
        """Test that method returns zeros when no data exists."""
        # Clear any existing data by creating data outside 90-day window
        old_date = date.today() - timedelta(days=100)
        material = TestDataFactory.create_material()
        TestDataFactory.create_purchase_order(
            po_number="PO-OLD",
            material=material,
            as_of_date=old_date
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_line_performance_percentages()

        self.assertEqual(result['on_time_percentage'], 0.0)
        self.assertEqual(result['in_full_percentage'], 0.0)

    def test_get_line_performance_percentages_with_filter_params(self):
        """Test that filter parameters are applied correctly."""
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        # Create PO for material1
        TestDataFactory.create_purchase_order(
            po_number="PO-FILTER-001",
            material=material1,
            as_of_date=today - timedelta(days=10),
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        # Create PO for material2
        TestDataFactory.create_purchase_order(
            po_number="PO-FILTER-002",
            material=material2,
            as_of_date=today - timedelta(days=10),
            buffered_ot_flag=False,
            if_flag=False,
            plant=plant,
            po_line_number="001"
        )

        # Filter by material1 only using new signature
        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_line_performance_percentages(
            direct_mat_nbr=material1.mat_nbr
        )

        # Should only have material1, so 100% on-time and in-full
        self.assertEqual(result['on_time_percentage'], 100.0)
        self.assertEqual(result['in_full_percentage'], 100.0)

    def test_get_weekly_otif_line_counts_returns_correct_structure(self):
        """Test that the service returns the correct data structure."""
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        # Create test data with anticipated_date in the same week
        anticipated_date = today - timedelta(days=10)
        TestDataFactory.create_purchase_order(
            po_number="PO-WEEKLY-001",
            material=material,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=today - timedelta(days=10),
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_weekly_otif_line_counts()

        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)

        # Check structure of first item
        week_data = result[0]
        self.assertIsInstance(week_data, dict)
        self.assertIn('year', week_data)
        self.assertIn('week', week_data)
        self.assertIn('otif_count', week_data)
        self.assertIn('ot_but_not_if_count', week_data)
        self.assertIn('if_but_not_ot_count', week_data)
        self.assertIn('not_ot_or_if_count', week_data)
        self.assertIn('total_lines', week_data)
        self.assertIn('otif_percentage', week_data)

        # Check data types
        self.assertIsInstance(week_data['year'], int)
        self.assertIsInstance(week_data['week'], int)
        self.assertIsInstance(week_data['otif_count'], int)
        self.assertIsInstance(week_data['ot_but_not_if_count'], int)
        self.assertIsInstance(week_data['if_but_not_ot_count'], int)
        self.assertIsInstance(week_data['not_ot_or_if_count'], int)
        self.assertIsInstance(week_data['total_lines'], int)
        self.assertIsInstance(week_data['otif_percentage'], float)

    def test_get_weekly_otif_line_counts_correct_categories(self):
        """Test that counts are calculated correctly for each category."""
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        material3 = TestDataFactory.create_material()
        material4 = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        # Create data in the same week (same anticipated_date)
        anticipated_date = today - timedelta(days=10)
        as_of_date = today - timedelta(days=10)

        # OTIF line
        TestDataFactory.create_purchase_order(
            po_number="PO-CAT-001",
            material=material1,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        # OT but not IF line
        TestDataFactory.create_purchase_order(
            po_number="PO-CAT-002",
            material=material2,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=True,
            if_flag=False,
            plant=plant,
            po_line_number="001"
        )

        # IF but not OT line
        TestDataFactory.create_purchase_order(
            po_number="PO-CAT-003",
            material=material3,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=False,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        # NOT OT or IF line
        TestDataFactory.create_purchase_order(
            po_number="PO-CAT-004",
            material=material4,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=False,
            if_flag=False,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_weekly_otif_line_counts()

        # Find the week with our test data
        week_data = None
        for week in result:
            if week['total_lines'] >= 4:
                week_data = week
                break

        self.assertIsNotNone(week_data, "Could not find week with test data")
        self.assertEqual(week_data['otif_count'], 1)
        self.assertEqual(week_data['ot_but_not_if_count'], 1)
        self.assertEqual(week_data['if_but_not_ot_count'], 1)
        self.assertEqual(week_data['not_ot_or_if_count'], 1)
        self.assertEqual(week_data['total_lines'], 4)
        self.assertEqual(week_data['otif_percentage'], 25.0)  # 1/4 = 25%

    def test_get_weekly_otif_line_counts_filters_by_anticipated_date(self):
        """Test that the method filters by anticipated_date."""
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        # Both POs have as_of_date within 90 days (required for MV)
        # But anticipated_date differs - one within 90 days, one outside
        anticipated_date_in_range = today - timedelta(days=10)  # Within 90 days
        anticipated_date_out_range = today - timedelta(days=100)  # Outside 90 days
        as_of_date = today - timedelta(days=10)  # Within 90 days (for MV)

        # PO with anticipated_date within 90 days - should be included
        TestDataFactory.create_purchase_order(
            po_number="PO-ANTICIPATED-DATE-IN",
            material=material1,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date_in_range,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        # PO with anticipated_date outside 90 days - should be excluded
        TestDataFactory.create_purchase_order(
            po_number="PO-ANTICIPATED-DATE-OUT",
            material=material2,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date_out_range,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_weekly_otif_line_counts()

        # Should only find the PO with anticipated_date in range
        total_lines = sum(week['total_lines'] for week in result)
        self.assertEqual(total_lines, 1, "Should only include PO with anticipated_date in range")

    def test_get_weekly_otif_line_counts_excludes_old_anticipated_dates(self):
        """Test that data with anticipated_date outside 90 days is excluded."""
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        # Create PO with anticipated_date outside 90 days
        old_anticipated_date = today - timedelta(days=100)
        as_of_date = today - timedelta(days=10)  # Within 90 days (for MV)

        TestDataFactory.create_purchase_order(
            po_number="PO-OLD",
            material=material,
            ordered_date=today - timedelta(days=20),
            anticipated_date=old_anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_weekly_otif_line_counts()

        # Should not find the old PO
        total_lines = sum(week['total_lines'] for week in result)
        self.assertEqual(total_lines, 0, "Should exclude PO with anticipated_date outside 90 days")

    def test_get_weekly_otif_line_counts_groups_by_week(self):
        """Test that data is correctly grouped by week."""
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        # Create POs in different weeks (different anticipated_date)
        week1_anticipated_date = today - timedelta(days=10)
        week2_anticipated_date = today - timedelta(days=17)  # Different week
        as_of_date = today - timedelta(days=10)

        TestDataFactory.create_purchase_order(
            po_number="PO-WEEK1",
            material=material1,
            ordered_date=today - timedelta(days=20),
            anticipated_date=week1_anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            plant=plant,
            po_line_number="001"
        )

        TestDataFactory.create_purchase_order(
            po_number="PO-WEEK2",
            material=material2,
            ordered_date=today - timedelta(days=20),
            anticipated_date=week2_anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_weekly_otif_line_counts()

        # Should have at least 2 different weeks
        weeks = {(week['year'], week['week']) for week in result if week['total_lines'] > 0}
        self.assertGreaterEqual(len(weeks), 1, "Should group data by week")

    def test_get_weekly_otif_line_counts_otif_percentage_calculation(self):
        """Test that OTIF percentage is calculated correctly."""
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        material3 = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        anticipated_date = today - timedelta(days=10)
        as_of_date = today - timedelta(days=10)

        # Create 3 lines: 2 OTIF, 1 not OTIF
        TestDataFactory.create_purchase_order(
            po_number="PO-PCT-001",
            material=material1,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        TestDataFactory.create_purchase_order(
            po_number="PO-PCT-002",
            material=material2,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        TestDataFactory.create_purchase_order(
            po_number="PO-PCT-003",
            material=material3,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=False,
            if_flag=False,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_weekly_otif_line_counts()

        # Find the week with our test data
        week_data = None
        for week in result:
            if week['total_lines'] >= 3:
                week_data = week
                break

        self.assertIsNotNone(week_data)
        self.assertEqual(week_data['otif_count'], 2)
        self.assertEqual(week_data['total_lines'], 3)
        self.assertEqual(week_data['otif_percentage'], round((2 / 3) * 100.0, 2))

    def test_get_weekly_otif_line_counts_zero_percentage(self):
        """Test that OTIF percentage is 0 when no OTIF lines exist."""
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        anticipated_date = today - timedelta(days=10)
        as_of_date = today - timedelta(days=10)

        # Create line that is NOT OTIF
        TestDataFactory.create_purchase_order(
            po_number="PO-ZERO",
            material=material,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=False,
            if_flag=False,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_weekly_otif_line_counts()

        # Find the week with our test data
        week_data = None
        for week in result:
            if week['total_lines'] >= 1:
                week_data = week
                break

        self.assertIsNotNone(week_data)
        self.assertEqual(week_data['otif_count'], 0)
        self.assertEqual(week_data['total_lines'], 1)
        self.assertEqual(week_data['otif_percentage'], 0.0)

    def test_get_weekly_otif_line_counts_with_filter_params(self):
        """Test that filter parameters are applied correctly."""
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        anticipated_date = today - timedelta(days=10)
        as_of_date = today - timedelta(days=10)

        # Create PO for material1
        TestDataFactory.create_purchase_order(
            po_number="PO-FILTER-001",
            material=material1,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            plant=plant,
            po_line_number="001"
        )

        # Create PO for material2
        TestDataFactory.create_purchase_order(
            po_number="PO-FILTER-002",
            material=material2,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=False,
            if_flag=False,
            plant=plant,
            po_line_number="001"
        )

        # Filter by material1 only using new signature
        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_weekly_otif_line_counts(
            direct_mat_nbr=material1.mat_nbr
        )

        # Find the week with our test data
        week_data = None
        for week in result:
            if week['total_lines'] >= 1:
                week_data = week
                break

        self.assertIsNotNone(week_data)
        # Should only have material1, so 100% OTIF
        self.assertEqual(week_data['otif_count'], 1)
        self.assertEqual(week_data['total_lines'], 1)
        self.assertEqual(week_data['otif_percentage'], 100.0)

    def test_get_weekly_otif_line_counts_handles_null_anticipated_date(self):
        """Test that lines with null anticipated_date are excluded."""
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()

        # Create PO with null anticipated_date (will be in MV if as_of_date is in range)
        PurchaseOrder.objects.create(
            po_number="PO-NULL",
            material=material1,
            ordered_date=today - timedelta(days=20),
            anticipated_date=None,
            as_of_date=today - timedelta(days=10),
            buffered_otif_flag=True,
            plant=plant,
            po_line_number="001"
        )

        # Create PO with valid anticipated_date to verify filtering works
        TestDataFactory.create_purchase_order(
            po_number="PO-VALID",
            material=material2,
            ordered_date=today - timedelta(days=20),
            anticipated_date=today - timedelta(days=10),
            as_of_date=today - timedelta(days=10),
            buffered_otif_flag=True,
            plant=plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        result = PurchaseOrderService.get_weekly_otif_line_counts()

        # Should only include the PO with valid anticipated_date, exclude the null one
        total_lines = sum(week['total_lines'] for week in result)
        self.assertEqual(total_lines, 1, "Should exclude PO with null anticipated_date, include valid one")

    def test_list_otif_exceptions_returns_annotated_fields(self):
        from api.material_formulary.models import MaterialFormulary

        PurchaseOrder.objects.all().delete()
        today = date.today()
        material = TestDataFactory.create_material(name="Exception Material", ndc="12345678901")
        plant = TestDataFactory.create_plant(name="Exception Plant", state="PA")
        anticipated_date = today - timedelta(days=10)
        completion_date = today - timedelta(days=3)

        MaterialFormulary.objects.create(
            material=material,
            sales_group="PGEN",
            parent_program="Prog A",
            program="P1",
            contract_number="C1",
        )
        MaterialFormulary.objects.create(
            material=material,
            sales_group="PRxO",
            parent_program="Prog B",
            program="P2",
            contract_number="C2",
        )
        MaterialFormulary.objects.create(
            material=material,
            sales_group="",
            parent_program="Empty",
            program="P3",
            contract_number="C3",
        )

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-ANN",
            material=material,
            plant=plant,
            po_line_number="001",
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=today - timedelta(days=5),
            original_order_qty=100,
            received_qty=40,
            buffered_late_flag=True,
            buffered_ot_flag=False,
            if_flag=True,
            buffered_otif_flag=False,
            completion_date=completion_date,
            material_status="ACTIVE",
        )

        refresh_purchase_order_mvs()
        result = list(PurchaseOrderService.list_otif_exceptions())

        self.assertEqual(len(result), 1)
        row = result[0]
        self.assertEqual(row.po_number, "PO-EXC-ANN")
        self.assertEqual(row.po_line_number, "001")
        self.assertEqual(row.material_name, "Exception Material")
        self.assertEqual(row.material_number, material.mat_nbr)
        self.assertEqual(row.ndc, "12345678901")
        self.assertTrue(row.in_full)
        self.assertFalse(row.on_time)
        self.assertEqual(row.plant_nbr, plant.plant_nbr)
        self.assertEqual(row.plant_name, "Exception Plant")
        self.assertEqual(row.plant_state, "PA")
        self.assertEqual(row.po_due_date, anticipated_date)
        self.assertEqual(row.received_date, completion_date)
        self.assertEqual(row.units_ordered, 100)
        self.assertEqual(row.units_not_received, 60)
        self.assertEqual(row.units_received_late, 40)
        self.assertEqual(float(row.otif_percent), 0.0)
        self.assertEqual(row.material_status, "ACTIVE")
        self.assertEqual(row.formulary, ["PGEN", "PRxO"])

    def test_list_otif_exceptions_excludes_out_of_window_and_null_anticipated(self):
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()
        as_of_date = today - timedelta(days=5)

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-IN",
            material=material,
            plant=plant,
            po_line_number="001",
            anticipated_date=today - timedelta(days=10),
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-OUT",
            material=material,
            plant=plant,
            po_line_number="002",
            anticipated_date=today - timedelta(days=100),
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-NULL",
            material=material,
            plant=plant,
            po_line_number="003",
            anticipated_date=None,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
        )

        refresh_purchase_order_mvs()
        result = list(PurchaseOrderService.list_otif_exceptions())

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].po_number, "PO-EXC-IN")

    def test_list_otif_exceptions_excludes_perfect_orders(self):
        PurchaseOrder.objects.all().delete()
        today = date.today()
        plant = TestDataFactory.create_plant()
        anticipated_date = today - timedelta(days=10)
        as_of_date = today - timedelta(days=10)

        categories = [
            ("PO-EXC-OTIF", True, True, True),
            ("PO-EXC-OT", True, False, False),
            ("PO-EXC-IF", False, True, False),
            ("PO-EXC-NONE", False, False, False),
        ]
        for po_number, ot, iff, otif in categories:
            TestDataFactory.create_purchase_order(
                po_number=po_number,
                material=TestDataFactory.create_material(),
                plant=plant,
                po_line_number="001",
                ordered_date=today - timedelta(days=20),
                anticipated_date=anticipated_date,
                as_of_date=as_of_date,
                buffered_ot_flag=ot,
                if_flag=iff,
                buffered_otif_flag=otif,
                completion_date=None if not iff else as_of_date,
            )

        refresh_purchase_order_mvs()
        base_qs = PurchaseOrderService.list_otif_exceptions()
        po_numbers = set(base_qs.values_list("po_number", flat=True))

        self.assertNotIn("PO-EXC-OTIF", po_numbers)
        self.assertEqual(base_qs.filter(buffered_ot_flag=True, if_flag=False).count(), 1)
        self.assertEqual(base_qs.filter(if_flag=True, buffered_ot_flag=False).count(), 1)
        self.assertEqual(base_qs.filter(buffered_ot_flag=False, if_flag=False).count(), 1)
        self.assertEqual(base_qs.count(), 3)
        none_row = base_qs.get(po_number="PO-EXC-NONE")
        self.assertIsNone(none_row.received_date)
        if_row = base_qs.get(po_number="PO-EXC-IF")
        self.assertEqual(if_row.received_date, as_of_date)

    def test_list_otif_exceptions_filters_by_material(self):
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        plant = TestDataFactory.create_plant()
        anticipated_date = today - timedelta(days=8)
        as_of_date = today - timedelta(days=5)

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-M1",
            material=material1,
            plant=plant,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-M2",
            material=material2,
            plant=plant,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
        )

        refresh_purchase_order_mvs()
        result = list(PurchaseOrderService.list_otif_exceptions(direct_mat_nbr=material1.mat_nbr))

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].po_number, "PO-EXC-M1")

    def test_list_material_purchase_order_lines_returns_flat_fields(self):
        PurchaseOrder.objects.all().delete()
        today = date.today()
        material = TestDataFactory.create_material(name="Drill Mat", ndc="44455566677")
        other = TestDataFactory.create_material(name="Other Mat", ndc="99988877766")
        plant = TestDataFactory.create_plant()
        ordered_date = today - timedelta(days=15)
        anticipated_date = today - timedelta(days=5)

        TestDataFactory.create_purchase_order(
            po_number="PO-DRILL-1",
            material=material,
            plant=plant,
            po_line_number="001",
            ordered_date=ordered_date,
            anticipated_date=anticipated_date,
            as_of_date=today - timedelta(days=3),
            original_order_qty=100,
            received_qty=40,
            buffered_ot_flag=True,
            buffered_late_flag=False,
            material_status="ACTIVE",
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-OTHER",
            material=other,
            plant=plant,
            po_line_number="001",
            ordered_date=ordered_date,
            anticipated_date=anticipated_date,
            as_of_date=today - timedelta(days=3),
            original_order_qty=10,
            received_qty=0,
        )

        refresh_purchase_order_mvs()
        result = list(PurchaseOrderService.list_material_purchase_order_lines())

        po_numbers = {row.po_number for row in result}
        self.assertIn("PO-DRILL-1", po_numbers)
        self.assertIn("PO-OTHER", po_numbers)

        row = next(r for r in result if r.po_number == "PO-DRILL-1")
        self.assertEqual(row.material_name, "Drill Mat")
        self.assertEqual(row.material_number, material.mat_nbr)
        self.assertEqual(row.ndc, "44455566677")
        self.assertEqual(row.ordered_date, ordered_date)
        self.assertEqual(row.anticipated_date, anticipated_date)
        self.assertEqual(row.units_ordered, 100)
        self.assertEqual(row.units_received_on_time, 40)
        self.assertEqual(row.units_received_late, 0)
        self.assertEqual(row.units_not_received, 60)
        self.assertAlmostEqual(float(row.inbound_fill_rate), 0.4, places=4)
        self.assertEqual(row.material_status, "ACTIVE")

        filtered = list(
            PurchaseOrderService.list_material_purchase_order_lines(
                direct_mat_nbr=material.mat_nbr
            )
        )
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0].po_number, "PO-DRILL-1")


class GetNextScheduledPoDeliveryTest(MVTestCase):
    def setUp(self):
        self.material = TestDataFactory.create_material()
        self.plant_a = TestDataFactory.create_plant(name="Plant A")
        self.plant_b = TestDataFactory.create_plant(name="Plant B")
        self.today = date.today()

    def test_returns_earliest_future_delivery(self):
        TestDataFactory.create_purchase_order(
            po_number="PO-FUTURE-LATE",
            po_line_number="001",
            material=self.material,
            plant=self.plant_b,
            as_of_date=self.today,
            anticipated_date=self.today + timedelta(days=30),
            predicted_delv_date=self.today + timedelta(days=35),
            completion_date=None,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-FUTURE-SOON",
            po_line_number="001",
            material=self.material,
            plant=self.plant_a,
            as_of_date=self.today,
            anticipated_date=self.today + timedelta(days=5),
            predicted_delv_date=self.today + timedelta(days=8),
            completion_date=None,
        )

        result = PurchaseOrderService.get_next_scheduled_po_delivery(self.material)

        self.assertIsNotNone(result)
        self.assertEqual(result.anticipated_date, self.today + timedelta(days=5))
        self.assertEqual(result.predicted_delv_date, self.today + timedelta(days=8))
        self.assertEqual(result.plant.plant_nbr, self.plant_a.plant_nbr)

    def test_future_delivery_wins_over_overdue(self):
        TestDataFactory.create_purchase_order(
            po_number="PO-OVERDUE",
            po_line_number="001",
            material=self.material,
            plant=self.plant_a,
            as_of_date=self.today,
            anticipated_date=self.today - timedelta(days=10),
            predicted_delv_date=self.today - timedelta(days=5),
            completion_date=None,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-FUTURE",
            po_line_number="001",
            material=self.material,
            plant=self.plant_b,
            as_of_date=self.today,
            anticipated_date=self.today + timedelta(days=7),
            predicted_delv_date=self.today + timedelta(days=10),
            completion_date=None,
        )

        result = PurchaseOrderService.get_next_scheduled_po_delivery(self.material)

        self.assertEqual(result.anticipated_date, self.today + timedelta(days=7))
        self.assertEqual(result.plant.plant_nbr, self.plant_b.plant_nbr)

    def test_returns_earliest_overdue_when_no_future_dates(self):
        TestDataFactory.create_purchase_order(
            po_number="PO-OVERDUE-RECENT",
            po_line_number="001",
            material=self.material,
            plant=self.plant_a,
            as_of_date=self.today,
            anticipated_date=self.today - timedelta(days=3),
            completion_date=None,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-OVERDUE-OLD",
            po_line_number="001",
            material=self.material,
            plant=self.plant_b,
            as_of_date=self.today,
            anticipated_date=self.today - timedelta(days=20),
            completion_date=None,
        )

        result = PurchaseOrderService.get_next_scheduled_po_delivery(self.material)

        self.assertEqual(result.anticipated_date, self.today - timedelta(days=20))

    def test_returns_none_when_no_open_pos(self):
        TestDataFactory.create_purchase_order(
            po_number="PO-COMPLETE",
            po_line_number="001",
            material=self.material,
            plant=self.plant_a,
            as_of_date=self.today,
            anticipated_date=self.today + timedelta(days=5),
            completion_date=self.today,
        )

        result = PurchaseOrderService.get_next_scheduled_po_delivery(self.material)

        self.assertIsNone(result)

    def test_uses_latest_snapshot_per_po_line(self):
        TestDataFactory.create_purchase_order(
            po_number="PO-SNAPSHOT",
            po_line_number="001",
            material=self.material,
            plant=self.plant_a,
            as_of_date=self.today - timedelta(days=5),
            anticipated_date=self.today + timedelta(days=20),
            completion_date=None,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-SNAPSHOT",
            po_line_number="001",
            material=self.material,
            plant=self.plant_a,
            as_of_date=self.today,
            anticipated_date=self.today + timedelta(days=3),
            completion_date=None,
        )

        result = PurchaseOrderService.get_next_scheduled_po_delivery(self.material)

        self.assertEqual(result.anticipated_date, self.today + timedelta(days=3))

    def test_selection_uses_anticipated_date_not_predicted_delv_date(self):
        TestDataFactory.create_purchase_order(
            po_number="PO-EARLIER-ANTICIPATED",
            po_line_number="001",
            material=self.material,
            plant=self.plant_a,
            as_of_date=self.today,
            anticipated_date=self.today + timedelta(days=5),
            predicted_delv_date=self.today + timedelta(days=20),
            completion_date=None,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-LATER-ANTICIPATED",
            po_line_number="001",
            material=self.material,
            plant=self.plant_b,
            as_of_date=self.today,
            anticipated_date=self.today + timedelta(days=15),
            predicted_delv_date=self.today + timedelta(days=3),
            completion_date=None,
        )

        result = PurchaseOrderService.get_next_scheduled_po_delivery(self.material)

        self.assertEqual(result.anticipated_date, self.today + timedelta(days=5))
        self.assertEqual(result.predicted_delv_date, self.today + timedelta(days=20))
        self.assertEqual(result.plant.plant_nbr, self.plant_a.plant_nbr)

    def test_returns_null_predicted_delv_date_when_absent(self):
        TestDataFactory.create_purchase_order(
            po_number="PO-NO-PREDICTED",
            po_line_number="001",
            material=self.material,
            plant=self.plant_a,
            as_of_date=self.today,
            anticipated_date=self.today + timedelta(days=5),
            predicted_delv_date=None,
            completion_date=None,
        )

        result = PurchaseOrderService.get_next_scheduled_po_delivery(self.material)

        self.assertEqual(result.anticipated_date, self.today + timedelta(days=5))
        self.assertIsNone(result.predicted_delv_date)
