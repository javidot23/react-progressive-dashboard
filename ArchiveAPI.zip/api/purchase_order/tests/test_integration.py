from datetime import date, timedelta
from unittest.mock import MagicMock, patch

from django.urls.base import reverse
from rest_framework import status
from rest_framework.test import APIClient

from api.csv_export import DEFAULT_EXPORT_MAX_ROWS
from config.tenant_db import set_active_tenant_db
from tests.BaseTestCase import MVAPITestCase
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


PURCHASE_ORDER_LATEST_MV = ["purchase_order_latest_90d_mv"]


def refresh_purchase_order_mvs():
    MaterializedViewTestHelper.refresh_materialized_views(PURCHASE_ORDER_LATEST_MV)


class PurchaseOrderIntegrationTest(MVAPITestCase):
    def setUp(self):
        """Set up test data for purchase order integration tests."""
        self.client = APIClient(raise_request_exception=False)
        self.material = TestDataFactory.create_material()
        self.plant = TestDataFactory.create_plant(name="Test Plant")
        self.purchase_order = TestDataFactory.create_purchase_order(
            po_number="PO12345",
            material=self.material,
            original_order_qty=100,
            ordered_date="2023-10-01",
            as_of_date="2023-10-01",
            received_qty=50,
            buffered_late_flag=True,
            expected_delivery_days=7,
            plant=self.plant,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            damaged_flag=True,
            material_status='AC'
        )

    def test_get_purchase_order_list(self):
        """
        Test retrieving the list of purchase orders.
        """
        url = reverse('purchase-order:purchase-order-list')
        response = self.client.get(url, {'limit': 10, 'offset': 0})

        self.assertEqual(response.status_code, 200)
        self.assertIn('results', response.data)
        self.assertGreater(len(response.data['results']), 0)

    def test_get_purchase_order_detail(self):
        """
        Test retrieving a specific purchase order by its ID.
        """
        url = reverse('purchase-order:purchase-order-history', kwargs={'po_number': self.purchase_order.po_number})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data[0]['po_number'], self.purchase_order.po_number)
        self.assertEqual(response.data[0]['material']['id'], self.material.id)

    def test_get_material_purchase_order_snapshots(self):
        """Returns the latest snapshot per PO line from the 90d MV and excludes other materials."""
        today = date.today()
        newer_as_of_date = today - timedelta(days=5)
        second_po_as_of_date = today - timedelta(days=4)

        # Newer snapshot for the existing PO line; should win over the setUp snapshot in the MV.
        TestDataFactory.create_purchase_order(
            po_number=self.purchase_order.po_number,
            po_line_number=self.purchase_order.po_line_number,
            material=self.material,
            original_order_qty=100,
            received_qty=80,
            ordered_date=today - timedelta(days=20),
            as_of_date=newer_as_of_date,
            plant=self.plant,
        )

        TestDataFactory.create_purchase_order(
            po_number="PO-MAT-002",
            material=self.material,
            original_order_qty=200,
            received_qty=150,
            ordered_date=today - timedelta(days=15),
            as_of_date=second_po_as_of_date,
            plant=self.plant,
        )

        # Second line on the same PO; both lines should appear in the response.
        TestDataFactory.create_purchase_order(
            po_number=self.purchase_order.po_number,
            po_line_number="002",
            material=self.material,
            original_order_qty=50,
            received_qty=40,
            ordered_date=today - timedelta(days=18),
            as_of_date=today - timedelta(days=3),
            plant=self.plant,
        )

        # PO for a different material; must be excluded from the response.
        other_material = TestDataFactory.create_material()
        TestDataFactory.create_purchase_order(
            po_number="PO-OTHER-001",
            material=other_material,
            original_order_qty=50,
            received_qty=25,
            ordered_date=today - timedelta(days=12),
            as_of_date=today - timedelta(days=12),
            plant=self.plant,
        )

        refresh_purchase_order_mvs()

        url = reverse(
            'purchase-order:material-purchase-order-snapshots',
            kwargs={'material_id': self.material.id},
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        payload = response.data["data"] if isinstance(response.data, dict) else response.data
        self.assertIsInstance(payload, list)

        po_numbers = sorted(item['po_number'] for item in payload)
        self.assertEqual(
            po_numbers,
            sorted([self.purchase_order.po_number, self.purchase_order.po_number, "PO-MAT-002"]),
        )

        snapshot_fields = {
            "id", "po_number", "po_line_number", "as_of_date", "anticipated_date",
            "received_qty", "original_order_qty",
        }
        for item in payload:
            self.assertEqual(set(item.keys()), snapshot_fields)

        original_po = next(
            item for item in payload
            if item['po_number'] == self.purchase_order.po_number
            and item.get('po_line_number') != "002"
        )
        self.assertEqual(original_po['received_qty'], 80)
        self.assertEqual(str(original_po['as_of_date']), str(newer_as_of_date))

    def test_get_purchase_order_otif_trends(self):
        """
        Test retrieving daily OTIF trends for the last 30 days.
        """

        url = reverse('purchase-order:material-daily-otif-trends', kwargs={'material_id': self.material.id})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertGreater(len(response.data), 0)

        # Check that the data contains the expected fields
        for trend in response.data:
            self.assertIn('day', trend)
            self.assertIn('on_time_count', trend)
            self.assertIn('in_full_count', trend)
            self.assertIn('otif_count', trend)
            self.assertIn('total_materials', trend)
            self.assertIn('material_status', trend)

    def test_line_performance_and_service_level_view(self):
        """
        Test the combined line performance and service level endpoint.
        """
        today = date.today()

        # Create purchase order data for last 90 days
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        # Create PO lines within last 90 days
        TestDataFactory.create_purchase_order(
            po_number="PO-VIEW-001",
            material=material1,
            as_of_date=today - timedelta(days=10),
            buffered_ot_flag=True,
            if_flag=True,
            plant=self.plant,
            po_line_number="001"
        )

        TestDataFactory.create_purchase_order(
            po_number="PO-VIEW-001",
            material=material2,
            as_of_date=today - timedelta(days=10),
            buffered_ot_flag=False,
            if_flag=True,
            plant=self.plant,
            po_line_number="002"
        )

        # Create service level data within last 90 days
        TestDataFactory.create_service_level(
            record_date=today - timedelta(days=10),
            material=material1,
            on_order_qty=1000,
            fill_rate=0.85
        )

        TestDataFactory.create_service_level(
            record_date=today - timedelta(days=5),
            material=material2,
            on_order_qty=2000,
            fill_rate=0.90
        )

        url = reverse('purchase-order:line-performance-and-service-level')
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)

        # Check response structure
        self.assertIn('on_time_percentage', response.data)
        self.assertIn('in_full_percentage', response.data)
        self.assertIn('units_on_order', response.data)
        self.assertIn('inbound_fill_rate', response.data)

        # Check data types
        self.assertIsInstance(response.data['on_time_percentage'], float)
        self.assertIsInstance(response.data['in_full_percentage'], float)
        self.assertIsInstance(response.data['units_on_order'], int)
        self.assertIsInstance(response.data['inbound_fill_rate'], float)

        # Check values are reasonable
        self.assertGreaterEqual(response.data['on_time_percentage'], 0.0)
        self.assertLessEqual(response.data['on_time_percentage'], 100.0)
        self.assertGreaterEqual(response.data['in_full_percentage'], 0.0)
        self.assertLessEqual(response.data['in_full_percentage'], 100.0)
        self.assertGreaterEqual(response.data['units_on_order'], 0)
        self.assertGreaterEqual(response.data['inbound_fill_rate'], 0.0)
        self.assertLessEqual(response.data['inbound_fill_rate'], 100.0)

    def test_line_performance_and_service_level_view_with_filters(self):
        """
        Test the endpoint with filter parameters.
        """
        today = date.today()
        material = TestDataFactory.create_material()

        # Create filtered data
        TestDataFactory.create_purchase_order(
            po_number="PO-FILTER-VIEW",
            material=material,
            as_of_date=today - timedelta(days=10),
            buffered_ot_flag=True,
            if_flag=True,
            plant=self.plant,
            po_line_number="001"
        )

        TestDataFactory.create_service_level(
            record_date=today - timedelta(days=10),
            material=material,
            on_order_qty=500,
            fill_rate=0.75
        )

        url = reverse('purchase-order:line-performance-and-service-level')
        response = self.client.get(url, {'material__id': material.id})

        self.assertEqual(response.status_code, 200)
        self.assertIn('on_time_percentage', response.data)
        self.assertIn('units_on_order', response.data)

    def test_weekly_otif_line_counts_view(self):
        """
        Test the weekly OTIF line counts endpoint.
        """
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        material3 = TestDataFactory.create_material()
        material4 = TestDataFactory.create_material()

        # Create test data with different categories in the same week (same anticipated_date)
        anticipated_date = today - timedelta(days=10)
        as_of_date = today - timedelta(days=10)

        # OTIF line
        TestDataFactory.create_purchase_order(
            po_number="PO-INT-OTIF",
            material=material1,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            plant=self.plant,
            po_line_number="001"
        )

        # OT but not IF line
        TestDataFactory.create_purchase_order(
            po_number="PO-INT-OT",
            material=material2,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=True,
            if_flag=False,
            plant=self.plant,
            po_line_number="001"
        )

        # IF but not OT line
        TestDataFactory.create_purchase_order(
            po_number="PO-INT-IF",
            material=material3,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=False,
            if_flag=True,
            plant=self.plant,
            po_line_number="001"
        )

        # NOT OT or IF line
        TestDataFactory.create_purchase_order(
            po_number="PO-INT-NONE",
            material=material4,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=False,
            if_flag=False,
            plant=self.plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:weekly-otif-line-counts')
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.data, list)
        self.assertGreater(len(response.data), 0)

        # Find the week with our test data
        week_data = None
        for week in response.data:
            if week['total_lines'] >= 4:
                week_data = week
                break

        self.assertIsNotNone(week_data, "Could not find week with test data")

        # Check response structure
        self.assertIn('year', week_data)
        self.assertIn('week', week_data)
        self.assertIn('otif_count', week_data)
        self.assertIn('ot_but_not_if_count', week_data)
        self.assertIn('if_but_not_ot_count', week_data)
        self.assertIn('not_ot_or_if_count', week_data)
        self.assertIn('total_lines', week_data)
        self.assertIn('otif_percentage', week_data)

        # Check data types
        self.assertIsInstance(week_data['year'], int)
        self.assertIsInstance(week_data['week'], int)
        self.assertIsInstance(week_data['otif_count'], int)
        self.assertIsInstance(week_data['ot_but_not_if_count'], int)
        self.assertIsInstance(week_data['if_but_not_ot_count'], int)
        self.assertIsInstance(week_data['not_ot_or_if_count'], int)
        self.assertIsInstance(week_data['total_lines'], int)
        self.assertIsInstance(week_data['otif_percentage'], float)

        # Check values are correct
        self.assertEqual(week_data['otif_count'], 1)
        self.assertEqual(week_data['ot_but_not_if_count'], 1)
        self.assertEqual(week_data['if_but_not_ot_count'], 1)
        self.assertEqual(week_data['not_ot_or_if_count'], 1)
        self.assertEqual(week_data['total_lines'], 4)
        self.assertEqual(week_data['otif_percentage'], 25.0)  # 1/4 = 25%

        # Check values are reasonable
        self.assertGreaterEqual(week_data['otif_count'], 0)
        self.assertGreaterEqual(week_data['ot_but_not_if_count'], 0)
        self.assertGreaterEqual(week_data['if_but_not_ot_count'], 0)
        self.assertGreaterEqual(week_data['not_ot_or_if_count'], 0)
        self.assertGreaterEqual(week_data['total_lines'], 0)
        self.assertGreaterEqual(week_data['otif_percentage'], 0.0)
        self.assertLessEqual(week_data['otif_percentage'], 100.0)

    def test_weekly_otif_line_counts_view_with_filters(self):
        """
        Test the endpoint with filter parameters.
        """
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        anticipated_date = today - timedelta(days=10)
        as_of_date = today - timedelta(days=10)

        # Create PO for material1 (OTIF)
        TestDataFactory.create_purchase_order(
            po_number="PO-FILTER-VIEW-001",
            material=material1,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            buffered_ot_flag=True,
            if_flag=True,
            plant=self.plant,
            po_line_number="001"
        )

        # Create PO for material2 (not OTIF)
        TestDataFactory.create_purchase_order(
            po_number="PO-FILTER-VIEW-002",
            material=material2,
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=False,
            buffered_ot_flag=False,
            if_flag=False,
            plant=self.plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:weekly-otif-line-counts')
        response = self.client.get(url, {'material__id': material1.id})

        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.data, list)

        # Find the week with our test data
        week_data = None
        for week in response.data:
            if week['total_lines'] >= 1:
                week_data = week
                break

        self.assertIsNotNone(week_data)
        # Should only have material1, so 100% OTIF
        self.assertEqual(week_data['otif_count'], 1)
        self.assertEqual(week_data['total_lines'], 1)
        self.assertEqual(week_data['otif_percentage'], 100.0)

    def test_weekly_otif_line_counts_view_returns_multiple_weeks(self):
        """
        Test that the endpoint returns data for multiple weeks.
        """
        today = date.today()
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        # Create POs in different weeks (different anticipated_date)
        week1_anticipated_date = today - timedelta(days=10)
        week2_anticipated_date = today - timedelta(days=17)  # Different week
        as_of_date = today - timedelta(days=10)

        TestDataFactory.create_purchase_order(
            po_number="PO-MULTI-001",
            material=material1,
            ordered_date=today - timedelta(days=20),
            anticipated_date=week1_anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            plant=self.plant,
            po_line_number="001"
        )

        TestDataFactory.create_purchase_order(
            po_number="PO-MULTI-002",
            material=material2,
            ordered_date=today - timedelta(days=20),
            anticipated_date=week2_anticipated_date,
            as_of_date=as_of_date,
            buffered_otif_flag=True,
            plant=self.plant,
            po_line_number="001"
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:weekly-otif-line-counts')
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.data, list)
        self.assertGreater(len(response.data), 0)

        # Check that weeks are ordered by year, week
        if len(response.data) > 1:
            for i in range(len(response.data) - 1):
                current = response.data[i]
                next_week = response.data[i + 1]
                # Either same year and week is less, or year is less
                if current['year'] == next_week['year']:
                    self.assertLessEqual(current['week'], next_week['week'])
                else:
                    self.assertLess(current['year'], next_week['year'])

    def test_otif_exceptions_view_list_shape_and_pagination(self):
        today = date.today()
        material = TestDataFactory.create_material(name="OTIF Exc Mat", ndc="99887766554")
        anticipated_date = today - timedelta(days=12)
        as_of_date = today - timedelta(days=5)

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-VIEW-1",
            material=material,
            plant=self.plant,
            po_line_number="001",
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            original_order_qty=80,
            received_qty=20,
            buffered_late_flag=True,
            buffered_ot_flag=False,
            if_flag=False,
            buffered_otif_flag=False,
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:otif-exceptions')
        response = self.client.get(url, {'limit': 10, 'offset': 0})

        self.assertEqual(response.status_code, 200)
        self.assertIn('results', response.data)
        self.assertIn('count', response.data)
        self.assertGreaterEqual(response.data['count'], 1)

        required_fields = [
            'po_number', 'po_line_number', 'material_name', 'material_number', 'ndc',
            'otif_percent', 'in_full', 'on_time', 'plant_nbr', 'plant_name', 'plant_state',
            'po_due_date', 'received_date', 'units_ordered', 'units_not_received',
            'units_received_late', 'formulary', 'material_status',
        ]
        matching = [r for r in response.data['results'] if r['po_number'] == 'PO-EXC-VIEW-1']
        self.assertEqual(len(matching), 1)
        row = matching[0]
        for field in required_fields:
            self.assertIn(field, row)
        self.assertEqual(row['material_name'], 'OTIF Exc Mat')
        self.assertEqual(row['ndc'], '99887766554')
        self.assertEqual(row['units_ordered'], 80)
        self.assertEqual(row['units_not_received'], 60)
        self.assertEqual(row['units_received_late'], 20)
        self.assertFalse(row['in_full'])
        self.assertFalse(row['on_time'])
        self.assertEqual(row['otif_percent'], 0.0)
        self.assertIsInstance(row['formulary'], list)
        self.assertIsNone(row['received_date'])

    def test_otif_exceptions_view_excludes_perfect_orders(self):
        today = date.today()
        anticipated_date = today - timedelta(days=9)
        as_of_date = today - timedelta(days=5)

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-PERFECT",
            material=TestDataFactory.create_material(),
            plant=self.plant,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=True,
            if_flag=True,
            buffered_otif_flag=True,
            completion_date=as_of_date,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-BAD",
            material=TestDataFactory.create_material(),
            plant=self.plant,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
            buffered_otif_flag=False,
            completion_date=None,
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:otif-exceptions')
        response = self.client.get(url, {'limit': 50, 'offset': 0})

        self.assertEqual(response.status_code, 200)
        po_numbers = {r['po_number'] for r in response.data['results']}
        self.assertNotIn('PO-EXC-PERFECT', po_numbers)
        self.assertIn('PO-EXC-BAD', po_numbers)
        bad = next(r for r in response.data['results'] if r['po_number'] == 'PO-EXC-BAD')
        self.assertIsNone(bad['received_date'])

    def test_otif_exceptions_view_category_and_week_filters(self):
        today = date.today()
        anticipated_date = today - timedelta(days=10)
        as_of_date = today - timedelta(days=10)
        week = anticipated_date.isocalendar()[1]
        year = anticipated_date.isocalendar()[0]

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-CAT-OT",
            material=TestDataFactory.create_material(),
            plant=self.plant,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=True,
            if_flag=False,
            buffered_otif_flag=False,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-CAT-IF",
            material=TestDataFactory.create_material(),
            plant=self.plant,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=True,
            buffered_otif_flag=False,
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:otif-exceptions')
        response = self.client.get(url, {
            'category': 'ot_but_not_if',
            'year': year,
            'week': week,
            'limit': 50,
            'offset': 0,
        })

        self.assertEqual(response.status_code, 200)
        po_numbers = {r['po_number'] for r in response.data['results']}
        self.assertIn('PO-EXC-CAT-OT', po_numbers)
        self.assertNotIn('PO-EXC-CAT-IF', po_numbers)
        for row in response.data['results']:
            self.assertTrue(row['on_time'])
            self.assertFalse(row['in_full'])

    def test_otif_exceptions_view_ordering(self):
        today = date.today()
        as_of_date = today - timedelta(days=5)
        material = TestDataFactory.create_material()

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-ORD-A",
            material=material,
            plant=self.plant,
            po_line_number="001",
            anticipated_date=today - timedelta(days=20),
            as_of_date=as_of_date,
            original_order_qty=10,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-ORD-B",
            material=material,
            plant=self.plant,
            po_line_number="001",
            anticipated_date=today - timedelta(days=5),
            as_of_date=as_of_date,
            original_order_qty=50,
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:otif-exceptions')
        response = self.client.get(url, {
            'material_id': material.id,
            'ordering': '-units_ordered',
            'limit': 10,
            'offset': 0,
        })

        self.assertEqual(response.status_code, 200)
        results = response.data['results']
        self.assertGreaterEqual(len(results), 2)
        self.assertEqual(results[0]['po_number'], 'PO-EXC-ORD-B')
        self.assertEqual(results[1]['po_number'], 'PO-EXC-ORD-A')

    def test_otif_exceptions_view_plant_name_and_material_status_filters(self):
        today = date.today()
        as_of_date = today - timedelta(days=5)
        anticipated_date = today - timedelta(days=8)
        plant_match = TestDataFactory.create_plant(name="Philadelphia DC East")
        plant_other = TestDataFactory.create_plant(name="Dallas Hub")

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-FILT-MATCH",
            material=TestDataFactory.create_material(),
            plant=plant_match,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
            buffered_otif_flag=False,
            material_status="ACTIVE",
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-FILT-OTHER",
            material=TestDataFactory.create_material(),
            plant=plant_other,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
            buffered_otif_flag=False,
            material_status="INACTIVE",
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:otif-exceptions')

        by_plant = self.client.get(url, {
            'plant_name': 'Philadelphia',
            'limit': 50,
            'offset': 0,
        })
        self.assertEqual(by_plant.status_code, 200)
        plant_pos = {r['po_number'] for r in by_plant.data['results']}
        self.assertIn('PO-EXC-FILT-MATCH', plant_pos)
        self.assertNotIn('PO-EXC-FILT-OTHER', plant_pos)

        by_status = self.client.get(url, {
            'material_status': 'ACTIVE',
            'limit': 50,
            'offset': 0,
        })
        self.assertEqual(by_status.status_code, 200)
        status_pos = {r['po_number'] for r in by_status.data['results']}
        self.assertIn('PO-EXC-FILT-MATCH', status_pos)
        self.assertNotIn('PO-EXC-FILT-OTHER', status_pos)

    def test_otif_exceptions_export_csv_shape_and_content(self):
        today = date.today()
        material = TestDataFactory.create_material(name="OTIF Export Mat", ndc="88776655443")
        anticipated_date = today - timedelta(days=11)
        as_of_date = today - timedelta(days=4)

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-EXPORT-1",
            material=material,
            plant=self.plant,
            po_line_number="001",
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            original_order_qty=80,
            received_qty=20,
            buffered_late_flag=True,
            buffered_ot_flag=False,
            if_flag=False,
            buffered_otif_flag=False,
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:otif-exceptions-export')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response['Content-Type'], 'text/csv')
        self.assertIn('attachment; filename=', response['Content-Disposition'])
        self.assertIn('otif_exceptions_', response['Content-Disposition'])
        self.assertEqual(response.get('X-Accel-Buffering'), 'no')

        content = b''.join(response.streaming_content).decode('utf-8')
        lines = [line for line in content.splitlines() if line.strip()]
        self.assertGreaterEqual(len(lines), 2)
        self.assertIn('PO Number', lines[0])
        self.assertIn('Product name', lines[0])
        self.assertIn('Formulary', lines[0])
        matching = [line for line in lines[1:] if 'PO-EXC-EXPORT-1' in line]
        self.assertEqual(len(matching), 1)
        self.assertIn('OTIF Export Mat', matching[0])
        self.assertIn('88776655443', matching[0])
        self.assertIn('false', matching[0])

    def test_otif_exceptions_export_streams_rows_after_tenant_middleware_teardown(self):
        today = date.today()
        material = TestDataFactory.create_material(name="OTIF Export Teardown Mat", ndc="88776655444")
        anticipated_date = today - timedelta(days=11)
        as_of_date = today - timedelta(days=4)

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-EXPORT-TEARDOWN",
            material=material,
            plant=self.plant,
            po_line_number="001",
            ordered_date=today - timedelta(days=20),
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            original_order_qty=80,
            received_qty=20,
            buffered_late_flag=True,
            buffered_ot_flag=False,
            if_flag=False,
            buffered_otif_flag=False,
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:otif-exceptions-export')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Simulate TenantDatabaseMiddleware finally block before the stream is consumed.
        set_active_tenant_db(None)

        content = b''.join(response.streaming_content).decode('utf-8')
        lines = [line for line in content.splitlines() if line.strip()]
        self.assertGreaterEqual(len(lines), 2)
        matching = [line for line in lines[1:] if 'PO-EXC-EXPORT-TEARDOWN' in line]
        self.assertEqual(len(matching), 1)
        self.assertIn('OTIF Export Teardown Mat', matching[0])

    def test_otif_exceptions_export_excludes_perfect_orders(self):
        today = date.today()
        anticipated_date = today - timedelta(days=9)
        as_of_date = today - timedelta(days=5)

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-EXPORT-PERFECT",
            material=TestDataFactory.create_material(),
            plant=self.plant,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=True,
            if_flag=True,
            buffered_otif_flag=True,
            completion_date=as_of_date,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-EXPORT-BAD",
            material=TestDataFactory.create_material(),
            plant=self.plant,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
            buffered_otif_flag=False,
            completion_date=None,
        )

        refresh_purchase_order_mvs()
        response = self.client.get(reverse('purchase-order:otif-exceptions-export'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        content = b''.join(response.streaming_content).decode('utf-8')
        self.assertNotIn('PO-EXC-EXPORT-PERFECT', content)
        self.assertIn('PO-EXC-EXPORT-BAD', content)

    def test_otif_exceptions_export_respects_filters_and_ignores_pagination(self):
        today = date.today()
        as_of_date = today - timedelta(days=5)
        anticipated_date = today - timedelta(days=8)
        plant_match = TestDataFactory.create_plant(name="Export Filter DC")
        plant_other = TestDataFactory.create_plant(name="Other Export DC")

        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-EXPORT-FILT-MATCH",
            material=TestDataFactory.create_material(),
            plant=plant_match,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
            buffered_otif_flag=False,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-EXC-EXPORT-FILT-OTHER",
            material=TestDataFactory.create_material(),
            plant=plant_other,
            po_line_number="001",
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            buffered_ot_flag=False,
            if_flag=False,
            buffered_otif_flag=False,
        )

        refresh_purchase_order_mvs()
        response = self.client.get(
            reverse('purchase-order:otif-exceptions-export'),
            {
                'plant_name': 'Export Filter',
                'limit': 1,
                'offset': 0,
            },
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        content = b''.join(response.streaming_content).decode('utf-8')
        self.assertIn('PO-EXC-EXPORT-FILT-MATCH', content)
        self.assertNotIn('PO-EXC-EXPORT-FILT-OTHER', content)

    def test_otif_exceptions_export_soft_cap(self):
        mock_qs = MagicMock()
        mock_qs.count.return_value = DEFAULT_EXPORT_MAX_ROWS + 1

        with patch(
            'api.csv_export.get_filtered_ordered_queryset',
            return_value=mock_qs,
        ):
            response = self.client.get(reverse('purchase-order:otif-exceptions-export'))

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('Export exceeds the maximum', str(response.data['error']))
        mock_qs.iterator.assert_not_called()

    def test_material_purchase_order_lines_view(self):
        today = date.today()
        material = TestDataFactory.create_material(name="Lines View Mat", ndc="12121212121")
        as_of_date = today - timedelta(days=4)
        ordered_date = today - timedelta(days=20)
        anticipated_date = today - timedelta(days=8)

        TestDataFactory.create_purchase_order(
            po_number="PO-LINES-1",
            material=material,
            plant=self.plant,
            po_line_number="001",
            ordered_date=ordered_date,
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            original_order_qty=50,
            received_qty=25,
            buffered_ot_flag=False,
            buffered_late_flag=True,
            material_status="AC",
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:material-purchase-order-lines')
        response = self.client.get(url, {
            'limit': 10,
            'offset': 0,
            'ordering': 'inbound_fill_rate',
            'material': material.mat_nbr,
        })

        self.assertEqual(response.status_code, 200)
        self.assertIn('results', response.data)
        self.assertGreaterEqual(response.data['count'], 1)
        row = response.data['results'][0]
        for field in (
            'material_name', 'material_number', 'ndc', 'ordered_date', 'po_number',
            'anticipated_date', 'units_ordered', 'units_received_on_time',
            'units_not_received', 'units_received_late', 'inbound_fill_rate',
            'material_status',
        ):
            self.assertIn(field, row)
        self.assertEqual(row['po_number'], 'PO-LINES-1')
        self.assertEqual(row['material_name'], 'Lines View Mat')
        self.assertEqual(row['units_ordered'], 50)
        self.assertEqual(row['units_received_late'], 25)
        self.assertEqual(row['units_not_received'], 25)
        self.assertAlmostEqual(float(row['inbound_fill_rate']), 0.5, places=4)

    def test_material_purchase_order_lines_multiple_po_number_filter(self):
        today = date.today()
        material = TestDataFactory.create_material(name="Multi PO Mat")
        as_of_date = today - timedelta(days=4)
        ordered_date = today - timedelta(days=20)
        anticipated_date = today - timedelta(days=8)
        common = dict(
            material=material,
            plant=self.plant,
            po_line_number="001",
            ordered_date=ordered_date,
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            original_order_qty=10,
            received_qty=0,
        )
        TestDataFactory.create_purchase_order(po_number="PO-MULTI-A", **common)
        TestDataFactory.create_purchase_order(po_number="PO-MULTI-B", **common)
        TestDataFactory.create_purchase_order(po_number="PO-MULTI-C", **common)

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:material-purchase-order-lines')
        response = self.client.get(url, {
            'limit': 20,
            'po_number': 'PO-MULTI-A,PO-MULTI-B',
            'material': material.mat_nbr,
        })

        self.assertEqual(response.status_code, 200)
        po_numbers = {r['po_number'] for r in response.data['results']}
        self.assertEqual(po_numbers, {'PO-MULTI-A', 'PO-MULTI-B'})
        self.assertNotIn('PO-MULTI-C', po_numbers)

    def test_material_purchase_order_lines_multiple_ndc_filter(self):
        today = date.today()
        as_of_date = today - timedelta(days=4)
        ordered_date = today - timedelta(days=20)
        anticipated_date = today - timedelta(days=8)
        mat_a = TestDataFactory.create_material(name="NDC A Mat", ndc="11111111111")
        mat_b = TestDataFactory.create_material(name="NDC B Mat", ndc="22222222222")
        mat_c = TestDataFactory.create_material(name="NDC C Mat", ndc="33333333333")
        common = dict(
            plant=self.plant,
            po_line_number="001",
            ordered_date=ordered_date,
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            original_order_qty=10,
            received_qty=0,
        )
        TestDataFactory.create_purchase_order(po_number="PO-NDC-A", material=mat_a, **common)
        TestDataFactory.create_purchase_order(po_number="PO-NDC-B", material=mat_b, **common)
        TestDataFactory.create_purchase_order(po_number="PO-NDC-C", material=mat_c, **common)

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:material-purchase-order-lines')
        response = self.client.get(url, {
            'limit': 20,
            'ndc': '11111111111,22222222222',
        })

        self.assertEqual(response.status_code, 200)
        ndcs = {r['ndc'] for r in response.data['results']}
        self.assertEqual(ndcs, {'11111111111', '22222222222'})
        self.assertNotIn('33333333333', ndcs)

    def test_material_purchase_order_lines_po_number_or_line_number_filter(self):
        today = date.today()
        material = TestDataFactory.create_material(name="PO Or Line Mat")
        as_of_date = today - timedelta(days=4)
        ordered_date = today - timedelta(days=20)
        anticipated_date = today - timedelta(days=8)
        common = dict(
            material=material,
            plant=self.plant,
            ordered_date=ordered_date,
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            original_order_qty=10,
            received_qty=0,
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-OR-MATCH", po_line_number="001", **common
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-OTHER", po_line_number="010", **common
        )
        TestDataFactory.create_purchase_order(
            po_number="PO-UNRELATED", po_line_number="002", **common
        )

        refresh_purchase_order_mvs()
        url = reverse('purchase-order:material-purchase-order-lines')
        response = self.client.get(url, {
            'limit': 20,
            'po_number_or_line_number': 'PO-OR-MATCH,010',
            'material': material.mat_nbr,
        })

        self.assertEqual(response.status_code, 200)
        po_numbers = {r['po_number'] for r in response.data['results']}
        self.assertEqual(po_numbers, {'PO-OR-MATCH', 'PO-OTHER'})
        self.assertNotIn('PO-UNRELATED', po_numbers)


class MaterialPurchaseOrderLinesExportIntegrationTests(MVAPITestCase):

    def setUp(self):
        self.client = APIClient(raise_request_exception=False)
        self.plant = TestDataFactory.create_plant(name="Export Plant")
        self.url = reverse('purchase-order:material-purchase-order-lines-export')

    def test_material_purchase_order_lines_export_csv_shape_and_content(self):
        today = date.today()
        material = TestDataFactory.create_material(name="Export Lines Mat", ndc="99999999999")
        as_of_date = today - timedelta(days=4)
        ordered_date = today - timedelta(days=20)
        anticipated_date = today - timedelta(days=8)

        TestDataFactory.create_purchase_order(
            po_number="PO-EXPORT-LINES",
            material=material,
            plant=self.plant,
            po_line_number="001",
            ordered_date=ordered_date,
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            original_order_qty=100,
            received_qty=50,
            buffered_ot_flag=True,
            buffered_late_flag=False,
            material_status="AC",
        )

        refresh_purchase_order_mvs()
        response = self.client.get(self.url, {'material': material.mat_nbr})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response['Content-Type'], 'text/csv')
        content = b''.join(response.streaming_content).decode('utf-8')
        lines = [line for line in content.splitlines() if line.strip()]
        self.assertGreaterEqual(len(lines), 2)
        header = lines[0]
        for col in (
            "Product Name", "Product ID", "NDC", "PO Creation Date", "PO Number",
            "Inbound Fill Rate", "Material Status",
        ):
            self.assertIn(col, header)
        matching = [line for line in lines[1:] if 'PO-EXPORT-LINES' in line]
        self.assertEqual(len(matching), 1)
        self.assertIn('Export Lines Mat', matching[0])
        self.assertIn('50.0', matching[0])

    def test_material_purchase_order_lines_export_respects_filters_and_ignores_pagination(self):
        today = date.today()
        as_of_date = today - timedelta(days=4)
        ordered_date = today - timedelta(days=20)
        anticipated_date = today - timedelta(days=8)
        mat_match = TestDataFactory.create_material(name="Export Match Mat")
        mat_other = TestDataFactory.create_material(name="Export Other Mat")
        common = dict(
            plant=self.plant,
            po_line_number="001",
            ordered_date=ordered_date,
            anticipated_date=anticipated_date,
            as_of_date=as_of_date,
            original_order_qty=10,
            received_qty=0,
        )
        TestDataFactory.create_purchase_order(po_number="PO-EXPORT-MATCH", material=mat_match, **common)
        TestDataFactory.create_purchase_order(po_number="PO-EXPORT-OTHER", material=mat_other, **common)

        refresh_purchase_order_mvs()
        response = self.client.get(
            self.url,
            {'material': mat_match.mat_nbr, 'limit': 1, 'offset': 0},
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        content = b''.join(response.streaming_content).decode('utf-8')
        self.assertIn('PO-EXPORT-MATCH', content)
        self.assertNotIn('PO-EXPORT-OTHER', content)

    def test_material_purchase_order_lines_export_invalid_ordering(self):
        response = self.client.get(self.url, {'ordering': 'not_a_field'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_material_purchase_order_lines_export_soft_cap(self):
        mock_qs = MagicMock()
        mock_qs.count.return_value = DEFAULT_EXPORT_MAX_ROWS + 1

        with patch(
            'api.purchase_order.views.get_material_purchase_order_lines_filtered_queryset',
            return_value=mock_qs,
        ):
            response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('Export exceeds the maximum', str(response.data['error']))
        mock_qs.iterator.assert_not_called()
