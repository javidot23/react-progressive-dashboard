from django.db import models

from api.material.models import Material
from api.plant.models import Plant


class PurchaseOrder(models.Model):
    po_number = models.CharField(max_length=255, null=True, blank=True)  # Purchase Order Number from DBX
    po_line_number = models.CharField(max_length=255, null=True, blank=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE
    )
    original_order_qty = models.IntegerField(null=True, blank=True, default=0)
    received_qty = models.IntegerField(default=0, null=True, blank=True)
    buffered_late_flag = models.BooleanField(default=False, null=True, blank=True)
    buffered_otif_flag = models.BooleanField(default=False, null=True, blank=True)
    buffered_ot_flag = models.BooleanField(default=False, null=True, blank=True)
    expected_delivery_days = models.IntegerField(default=0, null=True, blank=True)
    ordered_date = models.DateField(null=True, blank=True)
    as_of_date = models.DateField(null=True, blank=True)
    if_flag = models.BooleanField(default=False, null=True, blank=True)
    damaged_flag = models.BooleanField(default=False, null=True, blank=True)

    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.CASCADE,
        related_name="purchase_orders",
        null=True,
    )
    anticipated_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    material_status = models.CharField(max_length=255, null=True, blank=True)
    completion_date = models.DateField(null=True, blank=True)
    yet_received_qty = models.IntegerField(default=0, null=True, blank=True)
    received_subtotal = models.IntegerField(default=0, null=True, blank=True)
    predicted_delv_date = models.DateField(null=True, blank=True)
    del_ind_flag = models.BooleanField(default=False, null=True, blank=True)
    delv_complt_no_receipt_flag = models.BooleanField(default=False, null=True, blank=True)
    br_no_receipt_flag = models.BooleanField(default=False, null=True, blank=True)

    class Meta:
        db_table = "purchase_orders"
        verbose_name = "Purchase Order"
        verbose_name_plural = "Purchase Orders"
        indexes = [
            models.Index(fields=["po_number"]),
            models.Index(fields=["material"]),
            models.Index(fields=["ordered_date"]),
            models.Index(fields=["po_number", "-as_of_date"]),
            models.Index(fields=["buffered_ot_flag"]),
            models.Index(fields=["buffered_late_flag"]),
            models.Index(fields=["as_of_date"]),
            models.Index(fields=["material", "ordered_date"]),
            models.Index(fields=["material", "as_of_date"]),
            models.Index(fields=["plant"]),
            models.Index(fields=["anticipated_date"]),
        ]
        unique_together = [
            [
                "po_number",
                "po_line_number",
                "as_of_date"
            ]
        ]
