import logging
from datetime import date
from datetime import timedelta

from django.contrib.postgres.expressions import ArraySubquery
from django.contrib.postgres.fields import ArrayField
from django.db.models import CharField, FloatField, OuterRef, Window, IntegerField, functions
from django.db.models.aggregates import Sum, Count
from django.db.models.expressions import F, Case, When, Value
from django.db.models.functions import Cast, Coalesce, RowNumber
from django.db.models.query_utils import Q

from api.material_formulary.models import MaterialFormulary
from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV
from api.purchase_order.models import PurchaseOrder

logger = logging.getLogger(__name__)


class PurchaseOrderService:
    """
    Service class for handling Purchase Order related operations.
    """

    # api/purchase_order/services.py

    @staticmethod
    def list_latest_purchase_orders_with_materials_and_plants():
        logger.info("Retrieving latest purchase orders with materials and plants")
        # One pass in DB: pick latest row per po_number using ROW_NUMBER()
        return (
            PurchaseOrder.objects.filter(as_of_date__isnull=False)
            .annotate(
                rn=Window(
                    expression=RowNumber(),
                    partition_by=[F("po_number")],
                    order_by=F("as_of_date").desc(),
                )
            )
            .filter(rn=1)
            .select_related("material")
            .only(
                "id", "po_number", "po_line_number", "original_order_qty", "received_qty",
                "buffered_ot_flag", "buffered_late_flag", "ordered_date", 'anticipated_date', 'ordered_date',
                "material__id", "material__mat_nbr", "material__name",
            )
            .annotate(
                units_received_on_time=Case(
                    When(buffered_ot_flag=True, then=F("received_qty")),
                    default=Value(0), output_field=IntegerField(),
                ),
                units_received_late=Case(
                    When(buffered_late_flag=True, then=F("received_qty")),
                    default=Value(0), output_field=IntegerField(),
                ),
                units_not_received=F("original_order_qty") - F("received_qty"),
            )
            .order_by("-ordered_date")
        )

    @staticmethod
    def get_purchase_order_by_id(po_number):
        """
        Get a specific purchase order by its ID.
        """
        logger.info("Retrieving purchase order by PO number: %s", po_number)
        return PurchaseOrder.objects.filter(po_number=po_number).select_related('material', 'plant')

    @staticmethod
    def get_latest_purchase_orders_by_material(material_id):
        """Return the latest snapshot per PO line for the given material (last 90 days)."""
        logger.info("Retrieving latest purchase orders for material_id: %s", material_id)
        return (
            PurchaseOrderLatest90dMV.objects
            .filter(material__id=material_id)
            .order_by("-ordered_date", "po_number", "po_line_number")
        )

    @staticmethod
    def get_next_scheduled_po_delivery(material):
        """
        Return the open PO line with the closest scheduled delivery for a material.

        Uses the latest snapshot per (po_number, po_line_number) from the last 90 days.
        Prefers the earliest future/today anticipated_date; falls back to earliest overdue.
        """
        mat_nbr = material.mat_nbr if hasattr(material, 'mat_nbr') else material
        today = date.today()
        start_date = today - timedelta(days=90)

        logger.info("Retrieving next scheduled PO delivery for material: %s", mat_nbr)

        return (
            PurchaseOrder.objects.filter(
                material=mat_nbr,
                as_of_date__gte=start_date,
                as_of_date__isnull=False,
                completion_date__isnull=True,
                anticipated_date__isnull=False,
            )
            .annotate(
                rn=Window(
                    expression=RowNumber(),
                    partition_by=[F("po_number"), F("po_line_number")],
                    order_by=F("as_of_date").desc(),
                )
            )
            .filter(rn=1)
            .annotate(
                priority=Case(
                    When(anticipated_date__gte=today, then=Value(0)),
                    default=Value(1),
                    output_field=IntegerField(),
                )
            )
            .select_related("plant")
            .order_by("priority", "anticipated_date", "plant_id", "id")
            .first()
        )

    @staticmethod
    def get_daily_otif_trends(filter_params=None):
        """
        Get daily OTIF trends for the last 30 days based on as_of_date.
        Returns counts for on-time, in-full, and OTIF for each day.

        Args:
            filter_params (dict, optional): Dictionary of filter parameters to apply BEFORE aggregation.
        """
        logger.info("Calculating daily OTIF trends for last 30 days")
        # Calculate date range for last 30 days
        end_date = date.today()
        start_date = end_date - timedelta(days=30)

        # Base queryset
        queryset = PurchaseOrderLatest90dMV.objects.filter(
            as_of_date__range=[start_date, end_date]
        )
        if filter_params:
            queryset = queryset.filter(**filter_params)

        # Get aggregated data for each day
        daily_trends = queryset.values('as_of_date').annotate(
            on_time_count=Count('id', filter=Q(buffered_ot_flag=True)),
            in_full_count=Count('id', filter=Q(if_flag=True)),
            otif_count=Count('id', filter=Q(buffered_otif_flag=True)),
            total_materials=Count('id')  # TODO: Replace with total_orders
        ).order_by('as_of_date')

        # Create a dictionary for quick lookup
        trends_dict = {item['as_of_date']: item for item in daily_trends}

        # Generate complete date range with zero values for missing days
        result = []
        current_date = start_date

        while current_date <= end_date:
            if current_date in trends_dict:
                trend_data = trends_dict[current_date]
                result.append({
                    'day': current_date,
                    'on_time_count': trend_data['on_time_count'],
                    'in_full_count': trend_data['in_full_count'],
                    'otif_count': trend_data['otif_count'],
                    'total_materials': trend_data['total_materials']
                })
            else:
                # Add zero values for days with no data
                result.append({
                    'day': current_date,
                    'on_time_count': 0,
                    'in_full_count': 0,
                    'otif_count': 0,
                    'total_materials': 0
                })

            current_date += timedelta(days=1)

        return result

    @staticmethod
    def get_today_otif_percentage(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Returns the OTIF percentage for today and the average OTIF percentage for the last week.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Calculating today's OTIF percentage and weekly average")
        today = date.today()
        week_start = today - timedelta(days=7)

        # Base queryset for today
        result = PurchaseOrderLatest90dMV.objects.filter(as_of_date=today)
        if direct_mat_nbr:
            result = result.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            result = result.filter(material__mat_nbr__in=mat_nbr_subquery)

        # Calculate today's OTIF percentage
        total_orders_today = result.count()

        if total_orders_today == 0:
            otif_percentage_today = 0.0
        else:
            otif_orders_today = result.filter(buffered_otif_flag=True).count()
            otif_percentage_today = (otif_orders_today / total_orders_today) * 100.0

        # Calculate last week's average OTIF percentage
        week_end = today - timedelta(days=1)

        # Base queryset for last week
        queryset_week = PurchaseOrderLatest90dMV.objects.filter(as_of_date__range=[week_start, week_end])
        if direct_mat_nbr:
            queryset_week = queryset_week.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset_week = queryset_week.filter(material__mat_nbr__in=mat_nbr_subquery)

        total_orders_week = queryset_week.count()
        if total_orders_week == 0:
            weekly_average_otif = 0.0
        else:
            otif_orders_week = queryset_week.filter(buffered_otif_flag=True).count()
            weekly_average_otif = (otif_orders_week / total_orders_week) * 100.0

        return [{
            'otif_percentage': otif_percentage_today,
            'weekly_average_otif': weekly_average_otif
        }]

    @staticmethod
    def get_material_otif_summary(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get OTIF summary grouped by material using latest purchase orders.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Calculating material OTIF summary from latest purchase orders")
        # Step 1: Efficiently get the IDs of the latest PO for each po_number.
        latest_po_ids = PurchaseOrder.objects.order_by(
            'po_number',
            '-as_of_date'
        ).distinct(
            'po_number'
        ).values_list('id', flat=True)

        latest_pos = PurchaseOrder.objects.filter(id__in=latest_po_ids)

        if direct_mat_nbr:
            latest_pos = latest_pos.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            latest_pos = latest_pos.filter(material__mat_nbr__in=mat_nbr_subquery)

        # Group by material and aggregate as before
        return latest_pos.values(
            'material__id', 'material__name', 'material__mat_nbr',
        ).annotate(
            material_id=F('material__id'),
            material_name=F('material__name'),
            mat_nbr=F('material__mat_nbr'),
            units_ordered=Sum('original_order_qty', default=0),
            units_received_on_time=Sum('received_qty', filter=Q(buffered_ot_flag=True), default=0),
            units_received_late=Sum('received_qty', filter=Q(buffered_late_flag=True), default=0),
            total_received=Sum('received_qty', default=0),
            total_orders=Count('id'),
        ).annotate(
            # Calculate units_not_received after the sums are known
            units_not_received=F('units_ordered') - F('total_received')
        )

    @staticmethod
    def get_weekly_otif_trends(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get weekly OTIF trends for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        # Calculate date range for last 90 days
        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        # Base queryset
        queryset = PurchaseOrderLatest90dMV.objects.filter(
            as_of_date__range=[start_date, end_date]
        )
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        # Get aggregated data grouped by week
        weekly_trends = queryset.annotate(
            week=functions.Extract('as_of_date', 'week'),
            year=functions.Extract('as_of_date', 'year')
        ).values('year', 'week').annotate(
            on_time_count=Count('id', filter=Q(buffered_ot_flag=True)),
            in_full_count=Count('id', filter=Q(if_flag=True)),
            otif_count=Count('id', filter=Q(buffered_otif_flag=True)),
            total_orders=Count('id')
        ).order_by('year', 'week')

        return weekly_trends

    @staticmethod
    def get_material_weekly_otif_trends(material_id):
        """
        Get weekly OTIF trends for a specific material over the last 90 days.
        Returns aggregated on-time, in-full, and OTIF counts per week for the material.
        """

        # Calculate date range for last 90 days
        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        # Get aggregated data grouped by week for the specific material
        weekly_trends = PurchaseOrderLatest90dMV.objects.filter(
            as_of_date__range=[start_date, end_date],
            material__id=material_id
        ).annotate(
            week=functions.Extract('as_of_date', 'week'),
            year=functions.Extract('as_of_date', 'year')
        ).values('year', 'week').annotate(
            on_time_count=Count('id', filter=Q(buffered_ot_flag=True)),
            in_full_count=Count('id', filter=Q(if_flag=True)),
            otif_count=Count('id', filter=Q(buffered_otif_flag=True)),
            total_orders=Count('id')
        ).order_by('year', 'week')

        return weekly_trends

    @staticmethod
    def get_material_daily_otif_trends(material_id):
        """
        Get daily OTIF trends for a specific material over the last 90 days.
        Returns aggregated on-time, in-full, and OTIF counts per day for the material.
        """
        logger.info("Calculating daily OTIF trends for material_id: %s (last 90 days)", material_id)
        # Calculate date range for last 90 days
        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        # Get aggregated data grouped by day for the specific material
        daily_trends = PurchaseOrder.objects.filter(
            as_of_date__range=[start_date, end_date],
            material__id=material_id
        ).values('as_of_date').annotate(
            on_time_count=Count('id', filter=Q(buffered_ot_flag=True, if_flag=False)),
            in_full_count=Count('id', filter=Q(if_flag=True, buffered_ot_flag=False)),
            otif_count=Count('id', filter=Q(buffered_otif_flag=True)),
            total_materials=Count('id'),
            material_status=F('material_status')
        ).order_by('as_of_date')

        # Create a dictionary for quick lookup
        trends_dict = {item['as_of_date']: item for item in daily_trends}

        # Generate complete date range with zero values for missing days
        result = []
        current_date = start_date

        while current_date <= end_date:
            if current_date in trends_dict:
                trend_data = trends_dict[current_date]
                result.append({
                    'day': current_date,
                    'on_time_count': trend_data['on_time_count'],
                    'in_full_count': trend_data['in_full_count'],
                    'otif_count': trend_data['otif_count'],
                    'total_materials': trend_data['total_materials'],
                    'material_status': trend_data['material_status']
                })
            else:
                # Add zero values for days with no data
                result.append({
                    'day': current_date,
                    'on_time_count': 0,
                    'in_full_count': 0,
                    'otif_count': 0,
                    'total_materials': 0,
                    'material_status': None
                })

            current_date += timedelta(days=1)

        return result

    @staticmethod
    def get_line_performance_percentages(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get percentage of lines "on time" and percentage of lines "in full" for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Calculating line performance percentages for last 90 days")

        # Calculate date range for last 90 days
        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        logger.info("Using materialized view for line performance percentages")
        queryset = PurchaseOrderLatest90dMV.objects.filter(
            as_of_date__range=[start_date, end_date]
        )

        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        metrics = queryset.aggregate(
            total_lines=Count('id'),
            on_time_lines=Count('id', filter=Q(buffered_ot_flag=True)),
            in_full_lines=Count('id', filter=Q(if_flag=True))
        )

        total_lines = metrics['total_lines'] or 0

        if total_lines == 0:
            return {
                'on_time_percentage': 0.0,
                'in_full_percentage': 0.0
            }

        on_time_lines = metrics['on_time_lines'] or 0
        in_full_lines = metrics['in_full_lines'] or 0

        on_time_percentage = (on_time_lines / total_lines) * 100.0
        in_full_percentage = (in_full_lines / total_lines) * 100.0

        logger.info(
            "Line performance: total_lines=%d, on_time_lines=%d (%.2f%%), in_full_lines=%d (%.2f%%)",
            total_lines,
            on_time_lines,
            on_time_percentage,
            in_full_lines,
            in_full_percentage
        )

        return {
            'on_time_percentage': round(on_time_percentage, 2),
            'in_full_percentage': round(in_full_percentage, 2)
        }

    @staticmethod
    def get_weekly_otif_line_counts(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get weekly OTIF line counts for the last 90 days, grouped by anticipated_date week.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Calculating weekly OTIF line counts for last 90 days by anticipated_date")

        # Calculate date range for last 90 days
        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        queryset = PurchaseOrderLatest90dMV.objects.filter(
            anticipated_date__range=[start_date, end_date],
            anticipated_date__isnull=False
        )
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        # Get aggregated data grouped by week (based on anticipated_date)
        weekly_counts = queryset.annotate(
            week=functions.Extract('anticipated_date', 'week'),
            year=functions.Extract('anticipated_date', 'year')
        ).values('year', 'week').annotate(
            otif_count=Count('id', filter=Q(buffered_otif_flag=True)),
            ot_but_not_if_count=Count('id', filter=Q(buffered_ot_flag=True, if_flag=False)),
            if_but_not_ot_count=Count('id', filter=Q(if_flag=True, buffered_ot_flag=False)),
            not_ot_or_if_count=Count('id', filter=Q(buffered_ot_flag=False, if_flag=False)),
            total_lines=Count('id')
        ).order_by('year', 'week')

        # Calculate OTIF percentage for each week
        result = []
        for week_data in weekly_counts:
            total = week_data['total_lines'] or 0
            otif_count = week_data['otif_count'] or 0

            if total > 0:
                otif_percentage = (otif_count / total) * 100.0
            else:
                otif_percentage = 0.0

            result.append({
                'year': week_data['year'],
                'week': week_data['week'],
                'otif_count': otif_count,
                'ot_but_not_if_count': week_data['ot_but_not_if_count'] or 0,
                'if_but_not_ot_count': week_data['if_but_not_ot_count'] or 0,
                'not_ot_or_if_count': week_data['not_ot_or_if_count'] or 0,
                'total_lines': total,
                'otif_percentage': round(otif_percentage, 2)
            })

        logger.info("Retrieved weekly OTIF line counts for %d weeks", len(result))
        return result

    @staticmethod
    def list_otif_exceptions(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        List non-perfect purchase order lines for OTIF Exceptions drill-through.

        Uses the latest snapshot per line from the last 90 days (materialized view),
        filtered to anticipated_date within the last 90 days — the same universe as
        get_weekly_otif_line_counts. Perfect orders (on time and in full) are excluded.
        received_date is completion_date and may be null when the line is not closed.
        """
        logger.info("Retrieving OTIF exception lines for last 90 days by anticipated_date")

        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        queryset = PurchaseOrderLatest90dMV.objects.filter(
            anticipated_date__range=[start_date, end_date],
            anticipated_date__isnull=False,
        ).exclude(
            buffered_ot_flag=True,
            if_flag=True,
        )
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        formulary_sq = (
            MaterialFormulary.objects.filter(material=OuterRef("material"))
            .exclude(sales_group__isnull=True)
            .exclude(sales_group="")
            .order_by("sales_group")
            .values("sales_group")
            .distinct()
        )

        return (
            queryset
            .select_related("material", "plant")
            .annotate(
                week=functions.Extract("anticipated_date", "week"),
                year=functions.Extract("anticipated_date", "year"),
                material_name=F("material__name"),
                material_number=F("material__mat_nbr"),
                ndc=F("material__ndc"),
                in_full=F("if_flag"),
                on_time=F("buffered_ot_flag"),
                plant_nbr=F("plant_id"),
                plant_name=F("plant__name"),
                plant_state=F("plant__state"),
                po_due_date=F("anticipated_date"),
                received_date=F("completion_date"),
                units_ordered=F("original_order_qty"),
                units_not_received=F("original_order_qty") - F("received_qty"),
                units_received_late=Case(
                    When(buffered_late_flag=True, then=F("received_qty")),
                    default=Value(0),
                    output_field=IntegerField(),
                ),
                otif_percent=Case(
                    When(buffered_otif_flag=True, then=Value(100.0)),
                    default=Value(0.0),
                    output_field=FloatField(),
                ),
                formulary=Coalesce(
                    ArraySubquery(formulary_sq),
                    Value([], output_field=ArrayField(CharField())),
                ),
            )
            .order_by("-po_due_date", "po_number", "po_line_number")
        )

    @staticmethod
    def list_material_purchase_order_lines(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Latest PO line snapshots across materials from purchase_order_latest_90d_mv.
        Flat drill-through for the low-performance "see all purchase orders" table.
        """
        logger.info("Retrieving purchase order lines (all materials)")

        queryset = PurchaseOrderLatest90dMV.objects.all()
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        return (
            queryset
            .select_related("material")
            .annotate(
                material_name=F("material__name"),
                material_number=F("material__mat_nbr"),
                ndc=F("material__ndc"),
                units_ordered=F("original_order_qty"),
                units_received_on_time=Case(
                    When(buffered_ot_flag=True, then=F("received_qty")),
                    default=Value(0),
                    output_field=IntegerField(),
                ),
                units_received_late=Case(
                    When(buffered_late_flag=True, then=F("received_qty")),
                    default=Value(0),
                    output_field=IntegerField(),
                ),
                units_not_received=F("original_order_qty") - F("received_qty"),
                inbound_fill_rate=Case(
                    When(
                        original_order_qty__gt=0,
                        then=Cast(F("received_qty"), FloatField())
                        / Cast(F("original_order_qty"), FloatField()),
                    ),
                    default=Value(0.0),
                    output_field=FloatField(),
                ),
            )
            .order_by("-ordered_date", "po_number", "po_line_number")
        )
