from rest_framework import serializers

from api.material.serializers import MaterialSerializer
from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV
from api.purchase_order.models import PurchaseOrder


class PurchaseOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = PurchaseOrder
        fields = '__all__'


class PurchaseOrderWithMaterialsAndPlantsSerializer(serializers.ModelSerializer):
    material = MaterialSerializer(read_only=True)
    plant = serializers.CharField(source="plant_id")
    units_received_on_time = serializers.IntegerField(read_only=True)
    units_received_late = serializers.IntegerField(read_only=True)
    units_not_received = serializers.IntegerField(read_only=True)

    class Meta:
        model = PurchaseOrder
        fields = "__all__"


class MaterialPurchaseOrderSnapshotSerializer(serializers.ModelSerializer):
    """Fields required for the orders-received-relative-to-due-date chart."""

    class Meta:
        model = PurchaseOrderLatest90dMV
        fields = [
            "id",
            "po_number",
            "po_line_number",
            "as_of_date",
            "anticipated_date",
            "received_qty",
            "original_order_qty",
        ]


class MaterialBasicSerializer(serializers.Serializer):
    """Lightweight serializer for material info"""
    id = serializers.IntegerField()
    mat_nbr = serializers.CharField()
    name = serializers.CharField()


class PurchaseOrderListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for list view"""
    material = MaterialBasicSerializer(read_only=True)
    units_received_on_time = serializers.IntegerField(read_only=True)
    units_received_late = serializers.IntegerField(read_only=True)
    units_not_received = serializers.IntegerField(read_only=True)

    class Meta:
        model = PurchaseOrder
        fields = [
            'id',
            'po_number',
            'po_line_number',
            'material',
            'original_order_qty',
            'received_qty',
            'units_received_on_time',
            'units_received_late',
            'units_not_received',
            'anticipated_date',
            'ordered_date'
        ]


class OtifTrendsSerializer(serializers.Serializer):
    day = serializers.DateField()
    on_time_count = serializers.IntegerField()
    in_full_count = serializers.IntegerField()
    otif_count = serializers.IntegerField()
    total_materials = serializers.IntegerField()

    class Meta:
        ref_name = 'PurchaseOrderOtifTrends'


class MaterialOtifTrendsSerializer(serializers.Serializer):
    day = serializers.DateField()
    on_time_count = serializers.IntegerField()
    in_full_count = serializers.IntegerField()
    otif_count = serializers.IntegerField()
    total_materials = serializers.IntegerField()
    material_status = serializers.CharField()

    class Meta:
        ref_name = 'PurchaseOrderMaterialOtifTrends'


class OtifTotalSerializer(serializers.Serializer):
    otif_percentage = serializers.FloatField()
    weekly_average_otif = serializers.FloatField()

    class Meta:
        ref_name = 'PurchaseOrderOtifTotal'


class MaterialOtifSummarySerializer(serializers.Serializer):
    material_id = serializers.CharField()
    material_name = serializers.CharField()
    mat_nbr = serializers.CharField()
    units_ordered = serializers.IntegerField()
    units_received_on_time = serializers.IntegerField()
    units_received_late = serializers.IntegerField()
    units_not_received = serializers.IntegerField()
    total_orders = serializers.IntegerField()

    class Meta:
        ref_name = 'PurchaseOrderMaterialOtifSummary'


class WeeklyOtifTrendsSerializer(serializers.Serializer):
    year = serializers.IntegerField()
    week = serializers.IntegerField()
    on_time_count = serializers.IntegerField()
    in_full_count = serializers.IntegerField()
    otif_count = serializers.IntegerField()
    total_orders = serializers.IntegerField()


class LinePerformanceAndServiceLevelSerializer(serializers.Serializer):
    """
    Serializer for combined line performance percentages and service level metrics.
    """
    on_time_percentage = serializers.FloatField()
    in_full_percentage = serializers.FloatField()
    units_on_order = serializers.IntegerField()
    inbound_fill_rate = serializers.FloatField()


class WeeklyOtifLineCountsSerializer(serializers.Serializer):
    """
    Serializer for weekly OTIF line counts grouped by anticipated_date week.
    Uses the latest snapshot per order (by as_of_date) from the materialized view.
    """
    year = serializers.IntegerField()
    week = serializers.IntegerField()
    otif_count = serializers.IntegerField()
    ot_but_not_if_count = serializers.IntegerField()
    if_but_not_ot_count = serializers.IntegerField()
    not_ot_or_if_count = serializers.IntegerField()
    total_lines = serializers.IntegerField()
    otif_percentage = serializers.FloatField()


class OtifExceptionSerializer(serializers.Serializer):
    """Flat line-level fields for the OTIF Exceptions drill-through table."""

    po_number = serializers.CharField(allow_null=True)
    po_line_number = serializers.CharField(allow_null=True)
    material_name = serializers.CharField(allow_null=True)
    material_number = serializers.CharField(allow_null=True)
    ndc = serializers.CharField(allow_null=True)
    otif_percent = serializers.FloatField(allow_null=True)
    in_full = serializers.BooleanField(allow_null=True)
    on_time = serializers.BooleanField(allow_null=True)
    plant_nbr = serializers.CharField(allow_null=True)
    plant_name = serializers.CharField(allow_null=True)
    plant_state = serializers.CharField(allow_null=True)
    po_due_date = serializers.DateField(allow_null=True)
    received_date = serializers.DateField(allow_null=True)
    units_ordered = serializers.IntegerField(allow_null=True)
    units_not_received = serializers.IntegerField(allow_null=True)
    units_received_late = serializers.IntegerField(allow_null=True)
    formulary = serializers.ListField(
        child=serializers.CharField(allow_null=True),
        allow_empty=True,
        required=False,
    )
    material_status = serializers.CharField(allow_null=True)

    class Meta:
        ref_name = 'PurchaseOrderOtifException'


class MaterialPurchaseOrderLineSerializer(serializers.Serializer):
    """Flat PO line fields for material drill-through (low-performance card)."""

    material_name = serializers.CharField(allow_null=True)
    material_number = serializers.CharField(allow_null=True)
    ndc = serializers.CharField(allow_null=True)
    ordered_date = serializers.DateField(allow_null=True)
    po_number = serializers.CharField(allow_null=True)
    anticipated_date = serializers.DateField(allow_null=True)
    units_ordered = serializers.IntegerField(allow_null=True)
    units_received_on_time = serializers.IntegerField(allow_null=True)
    units_not_received = serializers.IntegerField(allow_null=True)
    units_received_late = serializers.IntegerField(allow_null=True)
    inbound_fill_rate = serializers.FloatField(allow_null=True)
    material_status = serializers.CharField(allow_null=True)

    class Meta:
        ref_name = 'PurchaseOrderMaterialLine'

    def to_representation(self, instance):
        data = super().to_representation(instance)
        if data.get('inbound_fill_rate') is not None:
            data['inbound_fill_rate'] = round(float(data['inbound_fill_rate']), 4)
        return data
