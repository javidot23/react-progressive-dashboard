from django.apps import AppConfig


class PurchaseOrderConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.purchase_order"
