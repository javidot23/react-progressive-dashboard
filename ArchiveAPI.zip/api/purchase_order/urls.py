from django.urls import path

from .views import PurchaseOrderListView, PurchaseOrderHistoryView, DailyOtifTrendsView, OtifTotalView, \
    MaterialOtifSummaryView, WeeklyOtifTrendsView, MaterialDailyOtifTrendsView, LinePerformanceAndServiceLevelView, \
    WeeklyOtifLineCountsView, MaterialPurchaseOrderSnapshotsView, OtifExceptionsView, OtifExceptionsExportView, \
    MaterialPurchaseOrderLinesView, MaterialPurchaseOrderLinesExportView

app_name = "purchase-order"

urlpatterns = [
    path('', PurchaseOrderListView.as_view(), name="purchase-order-list"),
    path('otif-trends/', DailyOtifTrendsView.as_view(), name="daily-otif-trends"),
    path('otif-today/', OtifTotalView.as_view(), name="daily-otif-today"),
    path('material-summary/', MaterialOtifSummaryView.as_view(), name="material-otif-summary"),
    path('weekly-otif-trends/', WeeklyOtifTrendsView.as_view(), name="weekly-otif-trends"),
    path('weekly-otif-line-counts/', WeeklyOtifLineCountsView.as_view(), name="weekly-otif-line-counts"),
    path('otif-exceptions/export/', OtifExceptionsExportView.as_view(), name="otif-exceptions-export"),
    path('otif-exceptions/', OtifExceptionsView.as_view(), name="otif-exceptions"),
    path('otif-trends/<int:material_id>/', MaterialDailyOtifTrendsView.as_view(), name="material-daily-otif-trends"),
    path('material/<int:material_id>/snapshots/', MaterialPurchaseOrderSnapshotsView.as_view(),
         name="material-purchase-order-snapshots"),
    path('material-lines/export/', MaterialPurchaseOrderLinesExportView.as_view(),
         name="material-purchase-order-lines-export"),
    path('material-lines/', MaterialPurchaseOrderLinesView.as_view(),
         name="material-purchase-order-lines"),
    path('line-performance-and-service-level/', LinePerformanceAndServiceLevelView.as_view(),
         name="line-performance-and-service-level"),
    path('<str:po_number>/', PurchaseOrderHistoryView.as_view(), name="purchase-order-history"),
]
