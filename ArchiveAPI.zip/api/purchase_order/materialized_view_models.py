from django.db import models

from api.material.models import Material
from api.plant.models import Plant


class PurchaseOrderLatest90dMV(models.Model):
    """
    Materialized view storing the latest purchase order record per (po_number, po_line_number)
    combination for the last 90 days.
    Materialized view: purchase_order_latest_90d_mv

    This view pre-computes the latest snapshot of each purchase order line, eliminating
    the need for expensive Window functions when querying recent purchase order data.
    """
    id = models.BigIntegerField(primary_key=True)
    po_number = models.CharField(max_length=255, null=True, blank=True)
    po_line_number = models.CharField(max_length=255, null=True, blank=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name='+',  # Disable reverse relation
        null=True,
    )
    original_order_qty = models.IntegerField(null=True, blank=True, default=0)
    received_qty = models.IntegerField(default=0, null=True, blank=True)
    buffered_late_flag = models.BooleanField(default=False, null=True, blank=True)
    buffered_otif_flag = models.BooleanField(default=False, null=True, blank=True)
    buffered_ot_flag = models.BooleanField(default=False, null=True, blank=True)
    expected_delivery_days = models.IntegerField(default=0, null=True, blank=True)
    ordered_date = models.DateField(null=True, blank=True)
    as_of_date = models.DateField(null=True, blank=True)
    if_flag = models.BooleanField(default=False, null=True, blank=True)
    damaged_flag = models.BooleanField(default=False, null=True, blank=True)
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.DO_NOTHING,
        related_name='+',  # Disable reverse relation
        null=True,
    )
    anticipated_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(null=True, blank=True)
    material_status = models.CharField(max_length=255, null=True, blank=True)
    completion_date = models.DateField(null=True, blank=True)
    yet_received_qty = models.IntegerField(default=0, null=True, blank=True)
    predicted_delv_date = models.DateField(null=True, blank=True)
    del_ind_flag = models.BooleanField(default=False, null=True, blank=True)
    delv_complt_no_receipt_flag = models.BooleanField(default=False, null=True, blank=True)
    br_no_receipt_flag = models.BooleanField(default=False, null=True, blank=True)

    class Meta:
        managed = False
        db_table = "purchase_order_latest_90d_mv"
        ordering = ['-as_of_date', 'po_number', 'po_line_number']
