DROP MATERIALIZED VIEW IF EXISTS purchase_order_latest_90d_mv CASCADE;

CREATE MATERIALIZED VIEW purchase_order_latest_90d_mv AS
WITH ranked_orders AS (
    SELECT
        po.id,
        po.po_number,
        po.po_line_number,
        po.mat_nbr,
        po.original_order_qty,
        po.received_qty,
        po.buffered_late_flag,
        po.buffered_otif_flag,
        po.buffered_ot_flag,
        po.expected_delivery_days,
        po.ordered_date,
        po.as_of_date,
        po.if_flag,
        po.damaged_flag,
        po.plant_nbr,
        po.anticipated_date,
        po.created_at,
        po.updated_at,
        po.material_status,
        po.completion_date,
        po.yet_received_qty,
        po.predicted_delv_date,
        po.del_ind_flag,
        po.delv_complt_no_receipt_flag,
        po.br_no_receipt_flag,
        ROW_NUMBER() OVER (
            PARTITION BY po.po_number, po.po_line_number
            ORDER BY po.as_of_date DESC
        ) AS rn
    FROM purchase_orders po
    WHERE po.as_of_date >= CURRENT_DATE - INTERVAL '90 days'
        AND po.as_of_date <= CURRENT_DATE
        AND po.as_of_date IS NOT NULL
)
SELECT
    id,
    po_number,
    po_line_number,
    mat_nbr,
    original_order_qty,
    received_qty,
    buffered_late_flag,
    buffered_otif_flag,
    buffered_ot_flag,
    expected_delivery_days,
    ordered_date,
    as_of_date,
    if_flag,
    damaged_flag,
    plant_nbr,
    anticipated_date,
    created_at,
    updated_at,
    material_status,
    completion_date,
    yet_received_qty,
    predicted_delv_date,
    del_ind_flag,
    delv_complt_no_receipt_flag,
    br_no_receipt_flag
FROM ranked_orders
WHERE rn = 1;

-- Create indexes for fast lookups
CREATE UNIQUE INDEX idx_po_latest_90d_id ON purchase_order_latest_90d_mv(id);
CREATE INDEX idx_po_latest_90d_po_number ON purchase_order_latest_90d_mv(po_number);
CREATE INDEX idx_po_latest_90d_material ON purchase_order_latest_90d_mv(mat_nbr);
CREATE INDEX idx_po_latest_90d_plant ON purchase_order_latest_90d_mv(plant_nbr);
CREATE INDEX idx_po_latest_90d_as_of_date ON purchase_order_latest_90d_mv(as_of_date);
CREATE INDEX idx_po_latest_90d_ordered_date ON purchase_order_latest_90d_mv(ordered_date);
CREATE INDEX idx_po_latest_90d_buffered_ot_flag ON purchase_order_latest_90d_mv(buffered_ot_flag);
CREATE INDEX idx_po_latest_90d_buffered_late_flag ON purchase_order_latest_90d_mv(buffered_late_flag);
CREATE INDEX idx_po_latest_90d_if_flag ON purchase_order_latest_90d_mv(if_flag);
CREATE INDEX idx_po_latest_90d_composite_po_line ON purchase_order_latest_90d_mv(po_number, po_line_number);
