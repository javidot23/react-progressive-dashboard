import csv
import io
from datetime import timedelta

from django.urls import reverse
from django.utils import timezone
from rest_framework import status

from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class SwitchSummaryViewTest(BaseAPITestCase):

    def setUp(self):
        self.today = timezone.now().date()
        self.url = reverse("material_formulary_change:switch-summary")
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        TestDataFactory.create_material_formulary_change(
            material=material1,
            change_date=self.today - timedelta(days=10),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )
        TestDataFactory.create_material_formulary_change(
            material=material2,
            change_date=self.today - timedelta(days=20),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )
        # Outside default 90-day window
        TestDataFactory.create_material_formulary_change(
            material=TestDataFactory.create_material(),
            change_date=self.today - timedelta(days=100),
            initial_program_code="PMS",
            initial_sales_group="PGEN",
            final_program_code="PGN",
            final_sales_group="PRxO",
        )

    def test_returns_200(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_response_structure(self):
        """Test that each item has the expected fields."""
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        item = response.data[0]
        for field in ("initial_program_code", "initial_sales_group", "final_program_code", "final_sales_group",
                      "count"):
            self.assertIn(field, item)

    def test_default_window_excludes_old_records(self):
        """Test that the default 90-day window excludes older records."""
        response = self.client.get(self.url)
        groups = response.data
        # Only the PGN→PMG group should be present (the 100-day-old one is excluded)
        self.assertEqual(len(groups), 1)
        self.assertEqual(groups[0]["count"], 2)

    def test_days_param_narrows_window(self):
        """Test that ?days=15 returns only 1 match (day 10)."""
        response = self.client.get(self.url, {"days": 15})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data[0]["count"], 1)

    def test_from_sales_group_filter(self):
        """Test ?from_sales_group filters results."""
        response = self.client.get(self.url, {"from_sales_group": "PRxO"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        for item in response.data:
            self.assertEqual(item["initial_sales_group"], "PRxO")

    def test_to_sales_group_filter(self):
        """Test ?to_sales_group filters results."""
        response = self.client.get(self.url, {"to_sales_group": "PGEN"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        for item in response.data:
            self.assertEqual(item["final_sales_group"], "PGEN")

    def test_involves_sales_group_matches_either_side(self):
        """Test that involves_sales_group returns groups where the sales group is on either side."""
        # Add a PGEN→PRxO switch (PRxO on the final side)
        TestDataFactory.create_material_formulary_change(
            material=TestDataFactory.create_material(),
            change_date=self.today - timedelta(days=5),
            initial_sales_group="PGEN",
            final_sales_group="PRxO",
        )
        response = self.client.get(self.url, {"involves_sales_group": "PRxO"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # PRxO→PMG group and PGEN→PRxO group should both appear
        self.assertEqual(len(response.data), 2)

    def test_invalid_days_falls_back_to_default(self):
        """Test that a non-integer days value returns 200 using the 90-day default."""
        response = self.client.get(self.url, {"days": "abc"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class SwitchDetailViewTest(BaseAPITestCase):

    def setUp(self):
        self.today = timezone.now().date()
        self.url = reverse("material_formulary_change:switch-detail")
        self.material1 = TestDataFactory.create_material()
        self.material2 = TestDataFactory.create_material()

        self.change1 = TestDataFactory.create_material_formulary_change(
            material=self.material1,
            change_date=self.today - timedelta(days=10),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )
        self.change2 = TestDataFactory.create_material_formulary_change(
            material=self.material2,
            change_date=self.today - timedelta(days=20),
            initial_program_code="PMS",
            initial_sales_group="PGEN",
            final_program_code="PGN",
            final_sales_group="PRxO",
        )
        # Outside default 90-day window
        TestDataFactory.create_material_formulary_change(
            material=TestDataFactory.create_material(),
            change_date=self.today - timedelta(days=100),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )

    def test_returns_200(self):
        response = self.client.get(self.url, {"limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_response_is_paginated(self):
        """Test that the response has pagination envelope."""
        response = self.client.get(self.url, {"limit": 10, "offset": 0})
        self.assertIn("results", response.data)
        self.assertIn("count", response.data)

    def test_response_item_structure(self):
        """Test that each result has the expected fields."""
        response = self.client.get(self.url, {"limit": 10, "offset": 0})
        item = response.data["results"][0]
        for field in ("id", "mat_nbr", "material_name", "initial_program_code",
                      "initial_sales_group", "final_program_code", "final_sales_group", "change_date"):
            self.assertIn(field, item)

    def test_default_window_excludes_old_records(self):
        """Test that records outside the 90-day window are excluded."""
        response = self.client.get(self.url, {"limit": 10, "offset": 0})
        self.assertEqual(response.data["count"], 2)

    def test_from_program_filter(self):
        """Test ?from_program filters by initial_program_code."""
        response = self.client.get(self.url, {"from_program": "PGN", "limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)
        self.assertEqual(response.data["results"][0]["initial_program_code"], "PGN")

    def test_to_program_filter(self):
        """Test ?to_program filters by final_program_code."""
        response = self.client.get(self.url, {"to_program": "PMG", "limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)
        self.assertEqual(response.data["results"][0]["final_program_code"], "PMG")

    def test_from_sales_group_filter(self):
        """Test ?from_sales_group filters by initial_sales_group."""
        response = self.client.get(self.url, {"from_sales_group": "PRxO", "limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    def test_to_sales_group_filter(self):
        """Test ?to_sales_group filters by final_sales_group."""
        response = self.client.get(self.url, {"to_sales_group": "PGEN", "limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    def test_mat_nbr_present_in_response(self):
        """Test that mat_nbr from the related material is returned."""
        response = self.client.get(self.url, {"from_program": "PGN", "limit": 10, "offset": 0})
        result = response.data["results"][0]
        self.assertEqual(result["mat_nbr"], self.material1.mat_nbr)

    def test_involves_sales_group_matches_either_side(self):
        """Test that involves_sales_group returns records where the sales group is on either side."""
        inbound = TestDataFactory.create_material_formulary_change(
            material=TestDataFactory.create_material(),
            change_date=self.today - timedelta(days=5),
            initial_sales_group="PGEN",
            final_sales_group="PRxO",
        )
        response = self.client.get(self.url, {"involves_sales_group": "PRxO", "limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        ids = [r["id"] for r in response.data["results"]]
        self.assertIn(self.change1.id, ids)
        self.assertIn(inbound.id, ids)

    def test_invalid_days_falls_back_to_default(self):
        """Test that a non-integer days value returns 200 using the 90-day default."""
        response = self.client.get(self.url, {"days": "bad", "limit": 10, "offset": 0})
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class SwitchKpisViewTest(BaseAPITestCase):

    def setUp(self):
        self.today = timezone.now().date()
        self.url = reverse("material_formulary_change:switch-kpis")
        TestDataFactory.create_material_formulary_change(
            material=TestDataFactory.create_material(),
            change_date=self.today - timedelta(days=10),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )
        TestDataFactory.create_material_formulary_change(
            material=TestDataFactory.create_material(),
            change_date=self.today - timedelta(days=20),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )
        TestDataFactory.create_material_formulary_change(
            material=TestDataFactory.create_material(),
            change_date=self.today - timedelta(days=100),
            initial_program_code="PMS",
            initial_sales_group="PGEN",
            final_program_code="PGN",
            final_sales_group="PRxO",
        )

    def test_returns_200(self):
        response = self.client.get(self.url, {"sales_group": "PRxO"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_missing_sales_group_returns_400(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_blank_sales_group_returns_400(self):
        response = self.client.get(self.url, {"sales_group": "  "})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_response_structure(self):
        response = self.client.get(self.url, {"sales_group": "PRxO"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        for field in ("sales_group", "added_count", "removed_count", "cross_category_count", "trend"):
            self.assertIn(field, response.data)
        self.assertEqual(response.data["sales_group"], "PRxO")
        self.assertGreaterEqual(len(response.data["trend"]), 1)
        point = response.data["trend"][0]
        for field in ("week_start", "added_count", "removed_count", "cross_category_count"):
            self.assertIn(field, point)

    def test_prxo_counts_removed_as_cross(self):
        response = self.client.get(self.url, {"sales_group": "PRxO"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["added_count"], 0)
        self.assertEqual(response.data["removed_count"], 2)
        self.assertEqual(response.data["cross_category_count"], 2)

    def test_pgen_counts_added_as_cross(self):
        response = self.client.get(self.url, {"sales_group": "PGEN"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["added_count"], 2)
        self.assertEqual(response.data["removed_count"], 0)
        self.assertEqual(response.data["cross_category_count"], 2)

    def test_days_param_narrows_window(self):
        response = self.client.get(self.url, {"sales_group": "PRxO", "days": 15})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["removed_count"], 1)
        self.assertEqual(response.data["cross_category_count"], 1)

    def test_invalid_days_falls_back_to_default(self):
        response = self.client.get(self.url, {"sales_group": "PRxO", "days": "abc"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["removed_count"], 2)


class SwitchDetailExportViewTest(BaseAPITestCase):
    def setUp(self):
        self.today = timezone.now().date()
        self.url = reverse("material_formulary_change:switch-detail-export")
        self.material = TestDataFactory.create_material(name="Switch Export Material")
        TestDataFactory.create_material_formulary_change(
            material=self.material,
            change_date=self.today - timedelta(days=10),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )

    def test_export_returns_csv_matching_list_row(self):
        list_url = reverse("material_formulary_change:switch-detail")
        list_row = self.client.get(list_url, {"limit": 10, "offset": 0}).data["results"][0]

        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("inventory_status_change_products_", response["Content-Disposition"])

        content = b"".join(response.streaming_content).decode("utf-8")
        rows = list(csv.reader(io.StringIO(content)))
        self.assertEqual(rows[0], [
            "Product Name",
            "Product ID",
            "Previous program",
            "Current program",
            "Change date",
        ])
        self.assertEqual(rows[1][0], list_row["material_name"])
        self.assertEqual(rows[1][1], list_row["mat_nbr"])
        self.assertEqual(rows[1][2], list_row["initial_program_code"])
        self.assertEqual(rows[1][3], list_row["final_program_code"])
