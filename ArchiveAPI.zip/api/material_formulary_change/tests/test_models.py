from django.utils import timezone

from api.material_formulary_change.models import MaterialFormularyChange
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class MaterialFormularyChangeModelTest(BaseTestCase):

    def setUp(self):
        self.material = TestDataFactory.create_material()
        self.today = timezone.now().date()

    def test_creation(self):
        """Test basic creation with all fields."""
        change = MaterialFormularyChange.objects.create(
            material=self.material,
            change_date=self.today,
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )
        self.assertEqual(change.material, self.material)
        self.assertEqual(change.change_date, self.today)
        self.assertEqual(change.initial_program_code, "PGN")
        self.assertEqual(change.initial_sales_group, "PRxO")
        self.assertEqual(change.final_program_code, "PMG")
        self.assertEqual(change.final_sales_group, "PGEN")

    def test_nullable_fields_default_to_none(self):
        """Test that program/group fields are nullable."""
        change = MaterialFormularyChange.objects.create(
            material=self.material,
            change_date=self.today,
        )
        self.assertIsNone(change.initial_program_code)
        self.assertIsNone(change.initial_sales_group)
        self.assertIsNone(change.final_program_code)
        self.assertIsNone(change.final_sales_group)

    def test_material_cascade_delete(self):
        """Test that deleting a material deletes its formulary changes."""
        change = TestDataFactory.create_material_formulary_change(material=self.material)
        change_id = change.id
        self.material.delete()
        self.assertFalse(MaterialFormularyChange.objects.filter(id=change_id).exists())
