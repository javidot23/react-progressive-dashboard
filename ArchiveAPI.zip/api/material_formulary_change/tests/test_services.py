from datetime import timedelta

from django.utils import timezone

from api.material_formulary_change.services import MaterialFormularyChangeService
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class MaterialFormularyChangeServiceTest(BaseTestCase):

    def setUp(self):
        self.today = timezone.now().date()
        self.material1 = TestDataFactory.create_material()
        self.material2 = TestDataFactory.create_material()
        self.material3 = TestDataFactory.create_material()

        # Two switches within the default 90-day window
        self.change1 = TestDataFactory.create_material_formulary_change(
            material=self.material1,
            change_date=self.today - timedelta(days=10),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )
        self.change2 = TestDataFactory.create_material_formulary_change(
            material=self.material2,
            change_date=self.today - timedelta(days=20),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMG",
            final_sales_group="PGEN",
        )
        # Switch outside the default window
        self.old_change = TestDataFactory.create_material_formulary_change(
            material=self.material3,
            change_date=self.today - timedelta(days=100),
            initial_program_code="PGN",
            initial_sales_group="PRxO",
            final_program_code="PMS",
            final_sales_group="PGEN",
        )

    # --- get_switch_summary ---

    def test_summary_groups_and_counts(self):
        """Test that summary returns one group with count=2 for the default window."""
        results = list(MaterialFormularyChangeService.get_switch_summary())
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["count"], 2)
        self.assertEqual(results[0]["initial_program_code"], "PGN")
        self.assertEqual(results[0]["final_program_code"], "PMG")

    def test_summary_days_param_filters_window(self):
        """Test that a narrow window excludes older records."""
        results = list(MaterialFormularyChangeService.get_switch_summary(days=15))
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["count"], 1)

    def test_summary_excludes_outside_window(self):
        """Test that records older than the window are not counted."""
        results = list(MaterialFormularyChangeService.get_switch_summary(days=90))
        total = sum(r["count"] for r in results)
        # old_change is at day 100, must not appear
        self.assertEqual(total, 2)

    def test_summary_involves_sales_group_matches_either_side(self):
        """Test that involves_sales_group returns records where the group is on either side."""
        # change1 and change2: PRxO→PGEN (initial=PRxO)
        # Add one that has PGEN→PRxO (final=PRxO)
        inbound = TestDataFactory.create_material_formulary_change(
            material=TestDataFactory.create_material(),
            change_date=self.today - timedelta(days=5),
            initial_sales_group="PGEN",
            final_sales_group="PRxO",
        )
        results = list(
            MaterialFormularyChangeService.get_switch_summary(involves_sales_group="PRxO")
        )
        # PRxO→PGEN group (count 2) and PGEN→PRxO group (count 1)
        self.assertEqual(len(results), 2)
        total = sum(r["count"] for r in results)
        self.assertEqual(total, 3)
        inbound.delete()

    def test_summary_involves_sales_group_no_match(self):
        """Test that an unmatched involves_sales_group returns empty."""
        results = list(
            MaterialFormularyChangeService.get_switch_summary(involves_sales_group="WAG")
        )
        self.assertEqual(len(results), 0)

    def test_summary_from_sales_group_filter(self):
        """Test that from_sales_group filters the summary."""
        results = list(
            MaterialFormularyChangeService.get_switch_summary(from_sales_group="PRxO")
        )
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["initial_sales_group"], "PRxO")

    def test_summary_from_sales_group_no_match(self):
        """Test that an unmatched from_sales_group returns empty."""
        results = list(
            MaterialFormularyChangeService.get_switch_summary(from_sales_group="WAG")
        )
        self.assertEqual(len(results), 0)

    def test_summary_to_sales_group_filter(self):
        """Test that to_sales_group filters the summary."""
        results = list(
            MaterialFormularyChangeService.get_switch_summary(to_sales_group="PGEN")
        )
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["final_sales_group"], "PGEN")

    # --- get_switch_detail ---

    def test_detail_returns_records_in_window(self):
        """Test that detail returns only records within the window, ordered by date desc."""
        results = list(MaterialFormularyChangeService.get_switch_detail())
        self.assertEqual(len(results), 2)
        # Ordered by -change_date: change1 (day 10) before change2 (day 20)
        self.assertEqual(results[0].id, self.change1.id)
        self.assertEqual(results[1].id, self.change2.id)

    def test_detail_excludes_outside_window(self):
        """Test that records outside the window are excluded."""
        results = list(MaterialFormularyChangeService.get_switch_detail(days=90))
        ids = [r.id for r in results]
        self.assertNotIn(self.old_change.id, ids)

    def test_detail_involves_sales_group_matches_either_side(self):
        """Test that involves_sales_group returns records where the group is on either side."""
        inbound = TestDataFactory.create_material_formulary_change(
            material=TestDataFactory.create_material(),
            change_date=self.today - timedelta(days=5),
            initial_sales_group="PGEN",
            final_sales_group="PRxO",
        )
        results = list(
            MaterialFormularyChangeService.get_switch_detail(involves_sales_group="PRxO")
        )
        ids = [r.id for r in results]
        self.assertIn(self.change1.id, ids)
        self.assertIn(self.change2.id, ids)
        self.assertIn(inbound.id, ids)
        inbound.delete()

    def test_detail_involves_sales_group_no_match(self):
        """Test that an unmatched involves_sales_group returns empty."""
        results = list(
            MaterialFormularyChangeService.get_switch_detail(involves_sales_group="WAG")
        )
        self.assertEqual(len(results), 0)

    def test_detail_from_program_filter(self):
        """Test that from_program filters by initial_program_code."""
        results = list(
            MaterialFormularyChangeService.get_switch_detail(from_program="PGN")
        )
        self.assertEqual(len(results), 2)

    def test_detail_from_program_no_match(self):
        """Test that an unmatched from_program returns empty."""
        results = list(
            MaterialFormularyChangeService.get_switch_detail(from_program="WAG")
        )
        self.assertEqual(len(results), 0)

    def test_detail_to_program_filter(self):
        """Test that to_program filters by final_program_code."""
        results = list(
            MaterialFormularyChangeService.get_switch_detail(to_program="PMG")
        )
        self.assertEqual(len(results), 2)

    def test_detail_from_sales_group_filter(self):
        """Test that from_sales_group filters by initial_sales_group."""
        results = list(
            MaterialFormularyChangeService.get_switch_detail(from_sales_group="PRxO")
        )
        self.assertEqual(len(results), 2)

    def test_detail_to_sales_group_filter(self):
        """Test that to_sales_group filters by final_sales_group."""
        results = list(
            MaterialFormularyChangeService.get_switch_detail(to_sales_group="PGEN")
        )
        self.assertEqual(len(results), 2)

    def test_detail_combined_filters(self):
        """Test combining from_program and to_sales_group narrows results."""
        results = list(
            MaterialFormularyChangeService.get_switch_detail(
                from_program="PGN", to_sales_group="PGEN"
            )
        )
        self.assertEqual(len(results), 2)

    def test_detail_narrow_days_window(self):
        """Test that days=5 excludes both changes (day 10 and day 20)."""
        results = list(MaterialFormularyChangeService.get_switch_detail(days=5))
        self.assertEqual(len(results), 0)
