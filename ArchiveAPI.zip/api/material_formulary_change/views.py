from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework.exceptions import ValidationError
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiParameter, extend_schema

from api.pagination import MaxLimitOffsetPagination
from .serializers import SwitchDetailSerializer, SwitchKpisSerializer, SwitchSummarySerializer
from .services import MaterialFormularyChangeService


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SwitchSummaryView(APIView):
    """
    GET /material-formulary-change/switches/summary/

    Returns aggregated counts of material switches grouped by
    (initial_program_code, initial_sales_group, final_program_code, final_sales_group).

    Query params:
        days                 (int, default 90): lookback window in days
        involves_sales_group (str, optional): filter where sales group appears on either side
        from_sales_group     (str, optional): filter by initial_sales_group
        to_sales_group       (str, optional): filter by final_sales_group
    """

    @extend_schema(responses=SwitchSummarySerializer(many=True))
    def get(self, request):
        p = request.query_params
        try:
            days = int(p.get("days", 90))
        except (ValueError, TypeError):
            days = 90
        data = MaterialFormularyChangeService.get_switch_summary(
            days=days,
            involves_sales_group=p.get("involves_sales_group"),
            from_sales_group=p.get("from_sales_group"),
            to_sales_group=p.get("to_sales_group"),
        )
        serializer = SwitchSummarySerializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SwitchKpisView(APIView):
    """
    GET /material-formulary-change/switches/kpis/

    Headline counts and weekly sparkline series for one sales-group screen:
      - added_count: entered the chosen sales_group
      - removed_count: left the chosen sales_group
      - cross_category_count: added union removed

    Query params:
        sales_group (str, required): chosen formulary (PRxO or PGEN screen)
        days        (int, default 90): lookback window in days
    """

    @extend_schema(
        parameters=[
            OpenApiParameter(
                name="sales_group",
                type=OpenApiTypes.STR,
                required=True,
                enum=["PRxO", "PGEN"],
                description="Chosen formulary sales group (PRxO or PGEN screen).",
            ),
            OpenApiParameter(
                name="days",
                type=OpenApiTypes.INT,
                required=False,
                description="Lookback window in days. Default 90.",
            ),
        ],
        responses=SwitchKpisSerializer,
    )
    def get(self, request):
        p = request.query_params
        sales_group = (p.get("sales_group") or "").strip()
        if not sales_group:
            raise ValidationError({"sales_group": "This query parameter is required."})
        try:
            days = int(p.get("days", 90))
        except (ValueError, TypeError):
            days = 90
        data = MaterialFormularyChangeService.get_switch_kpis(
            sales_group=sales_group, days=days,
        )
        return Response(SwitchKpisSerializer(data).data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class SwitchDetailView(ListAPIView):
    """
    GET /material-formulary-change/switches/

    Returns a paginated list of individual MaterialFormularyChange records.
    Used to drill into a specific switch pair from the summary.

    Query params:
        days                 (int, default 90): lookback window in days
        involves_sales_group (str, optional): filter where sales group appears on either side
        from_program         (str, optional): filter by initial_program_code
        to_program           (str, optional): filter by final_program_code
        from_sales_group     (str, optional): filter by initial_sales_group
        to_sales_group       (str, optional): filter by final_sales_group
    """

    serializer_class = SwitchDetailSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        p = self.request.query_params
        try:
            days = int(p.get("days", 90))
        except (ValueError, TypeError):
            days = 90
        return MaterialFormularyChangeService.get_switch_detail(
            days=days,
            involves_sales_group=p.get("involves_sales_group"),
            from_program=p.get("from_program"),
            to_program=p.get("to_program"),
            from_sales_group=p.get("from_sales_group"),
            to_sales_group=p.get("to_sales_group"),
        )
