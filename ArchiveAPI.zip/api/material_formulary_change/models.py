from django.db import models

from api.material.models import Material


class MaterialFormularyChange(models.Model):
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
    )
    change_date = models.DateField()
    initial_program_code = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        db_column="initial_program_code"
    )
    final_program_code = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        db_column="final_program_code"
    )
    initial_sales_group = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        db_column="initial_sales_group"
    )
    final_sales_group = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        db_column="final_sales_group"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "material_formulary_change"
        unique_together = [("material", "change_date", "initial_program_code")]
        indexes = [
            models.Index(fields=["material"]),
            models.Index(fields=["change_date"]),
        ]
