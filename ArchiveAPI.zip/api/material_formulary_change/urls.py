from django.urls import path

from .views import SwitchDetailView, SwitchKpisView, SwitchSummaryView

app_name = "material_formulary_change"

urlpatterns = [
    path("switches/summary/", SwitchSummaryView.as_view(), name="switch-summary"),
    path("switches/kpis/", SwitchKpisView.as_view(), name="switch-kpis"),
    path("switches/", SwitchDetailView.as_view(), name="switch-detail"),
]
