import logging
from datetime import date, timedelta

from django.db.models import Count, Q

from .models import MaterialFormularyChange

logger = logging.getLogger(__name__)


class MaterialFormularyChangeService:

    @staticmethod
    def get_switch_summary(
        days: int = 90,
        from_sales_group: str = None,
        to_sales_group: str = None,
        involves_sales_group: str = None,
    ):
        since = date.today() - timedelta(days=days)
        logger.info("Retrieving switch summary for last %d days (since %s)", days, since)
        qs = MaterialFormularyChange.objects.filter(change_date__gte=since)
        if involves_sales_group:
            qs = qs.filter(
                Q(initial_sales_group=involves_sales_group) | Q(final_sales_group=involves_sales_group)
            )
        if from_sales_group:
            qs = qs.filter(initial_sales_group=from_sales_group)
        if to_sales_group:
            qs = qs.filter(final_sales_group=to_sales_group)
        return (
            qs
            .values(
                "initial_program_code",
                "initial_sales_group",
                "final_program_code",
                "final_sales_group",
            )
            .annotate(count=Count("material", distinct=True))
            .order_by("-count")
        )

    @staticmethod
    def get_switch_detail(
        days: int = 90,
        from_program: str = None,
        to_program: str = None,
        from_sales_group: str = None,
        to_sales_group: str = None,
        involves_sales_group: str = None,
    ):
        since = date.today() - timedelta(days=days)
        logger.info(
            "Retrieving switch detail since %s — from_program=%s, to_program=%s, "
            "from_sales_group=%s, to_sales_group=%s, involves_sales_group=%s",
            since, from_program, to_program, from_sales_group, to_sales_group, involves_sales_group,
        )
        qs = (
            MaterialFormularyChange.objects
            .select_related("material")
            .filter(change_date__gte=since)
        )
        if involves_sales_group:
            qs = qs.filter(
                Q(initial_sales_group=involves_sales_group) | Q(final_sales_group=involves_sales_group)
            )
        if from_program:
            qs = qs.filter(initial_program_code=from_program)
        if to_program:
            qs = qs.filter(final_program_code=to_program)
        if from_sales_group:
            qs = qs.filter(initial_sales_group=from_sales_group)
        if to_sales_group:
            qs = qs.filter(final_sales_group=to_sales_group)
        return qs.order_by("-change_date")
