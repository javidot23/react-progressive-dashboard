import logging
from datetime import date, timedelta

from django.db.models import Count, Q, Sum, Value
from django.db.models.functions import Coalesce, TruncWeek

from api.csv_export import csv_cell, csv_date

from .models import MaterialFormularyChange

logger = logging.getLogger(__name__)


class MaterialFormularyChangeService:

    @staticmethod
    def get_switch_summary(
        days: int = 90,
        from_sales_group: str = None,
        to_sales_group: str = None,
        involves_sales_group: str = None,
    ):
        since = date.today() - timedelta(days=days)
        logger.info("Retrieving switch summary for last %d days (since %s)", days, since)
        qs = MaterialFormularyChange.objects.filter(change_date__gte=since)
        if involves_sales_group:
            qs = qs.filter(
                Q(initial_sales_group=involves_sales_group) | Q(final_sales_group=involves_sales_group)
            )
        if from_sales_group:
            qs = qs.filter(initial_sales_group=from_sales_group)
        if to_sales_group:
            qs = qs.filter(final_sales_group=to_sales_group)
        return (
            qs
            .values(
                "initial_program_code",
                "initial_sales_group",
                "final_program_code",
                "final_sales_group",
            )
            .annotate(count=Count("material", distinct=True))
            .order_by("-count")
        )

    @staticmethod
    def get_switch_detail(
        days: int = 90,
        from_program: str = None,
        to_program: str = None,
        from_sales_group: str = None,
        to_sales_group: str = None,
        involves_sales_group: str = None,
    ):
        since = date.today() - timedelta(days=days)
        logger.info(
            "Retrieving switch detail since %s — from_program=%s, to_program=%s, "
            "from_sales_group=%s, to_sales_group=%s, involves_sales_group=%s",
            since, from_program, to_program, from_sales_group, to_sales_group, involves_sales_group,
        )
        qs = (
            MaterialFormularyChange.objects
            .select_related("material")
            .filter(change_date__gte=since)
        )
        if involves_sales_group:
            qs = qs.filter(
                Q(initial_sales_group=involves_sales_group) | Q(final_sales_group=involves_sales_group)
            )
        if from_program:
            qs = qs.filter(initial_program_code=from_program)
        if to_program:
            qs = qs.filter(final_program_code=to_program)
        if from_sales_group:
            qs = qs.filter(initial_sales_group=from_sales_group)
        if to_sales_group:
            qs = qs.filter(final_sales_group=to_sales_group)
        return qs.order_by("-change_date")

    SWITCH_DETAIL_CSV_HEADERS = [
        "Product Name",
        "Product ID",
        "Previous program",
        "Current program",
        "Change date",
    ]

    @classmethod
    def get_switch_detail_from_request(cls, request):
        p = request.query_params
        try:
            days = int(p.get("days", 90))
        except (ValueError, TypeError):
            days = 90
        return cls.get_switch_detail(
            days=days,
            involves_sales_group=p.get("involves_sales_group"),
            from_program=p.get("from_program"),
            to_program=p.get("to_program"),
            from_sales_group=p.get("from_sales_group"),
            to_sales_group=p.get("to_sales_group"),
        )

    @classmethod
    def iter_switch_detail_csv_rows(cls, queryset, chunk_size=2000):
        yield list(cls.SWITCH_DETAIL_CSV_HEADERS)
        for row in queryset.select_related("material").iterator(chunk_size=chunk_size):
            material = row.material if row.material_id else None
            yield [
                csv_cell(material.name if material else None),
                csv_cell(material.mat_nbr if material else None),
                csv_cell(row.initial_program_code),
                csv_cell(row.final_program_code),
                csv_date(row.change_date),
            ]

    @staticmethod
    def _neq_sales_group(field, sales_group):
        """True when field is null or a different sales group (SQL NULL-safe inequality)."""
        return Q(**{f"{field}__isnull": True}) | ~Q(**{field: sales_group})

    @staticmethod
    def _added_q(sales_group):
        return Q(final_sales_group=sales_group) & MaterialFormularyChangeService._neq_sales_group(
            "initial_sales_group", sales_group
        )

    @staticmethod
    def _removed_q(sales_group):
        return Q(initial_sales_group=sales_group) & MaterialFormularyChangeService._neq_sales_group(
            "final_sales_group", sales_group
        )

    @staticmethod
    def _cross_category_q(sales_group):
        """Entry or exit of the chosen sales group (added union removed)."""
        return (
            MaterialFormularyChangeService._added_q(sales_group)
            | MaterialFormularyChangeService._removed_q(sales_group)
        )

    @staticmethod
    def _pair_material_count(qs):
        """Same grain as summing switches/summary counts: distinct materials per from→to pair."""
        total = (
            qs.values(
                "initial_program_code",
                "initial_sales_group",
                "final_program_code",
                "final_sales_group",
            )
            .annotate(c=Count("material", distinct=True))
            .aggregate(total=Coalesce(Sum("c"), Value(0)))
        )["total"]
        return int(total or 0)

    @staticmethod
    def _as_date(value):
        if value is None:
            return None
        return value.date() if hasattr(value, "date") else value

    @staticmethod
    def get_switch_kpis(sales_group: str, days: int = 90):
        """
        Headline counts + weekly trend for one sales-group status-change screen.

        added_count / removed_count are distinct materials per from→to pair entering
        or leaving sales_group. cross_category_count is their union. Same-group tier
        moves are excluded from all three cards.
        """
        since = date.today() - timedelta(days=days)
        until = date.today()
        logger.info(
            "Retrieving formulary-change KPIs for sales_group=%s last %d days (since %s)",
            sales_group, days, since,
        )
        qs = MaterialFormularyChange.objects.filter(change_date__gte=since)
        added_q = MaterialFormularyChangeService._added_q(sales_group)
        removed_q = MaterialFormularyChangeService._removed_q(sales_group)
        cross_q = MaterialFormularyChangeService._cross_category_q(sales_group)

        added_count = MaterialFormularyChangeService._pair_material_count(qs.filter(added_q))
        removed_count = MaterialFormularyChangeService._pair_material_count(qs.filter(removed_q))
        cross_category_count = MaterialFormularyChangeService._pair_material_count(qs.filter(cross_q))

        weekly_rows = {
            MaterialFormularyChangeService._as_date(row["week_start"]): row
            for row in (
                qs.annotate(week_start=TruncWeek("change_date"))
                .values("week_start")
                .annotate(
                    added_count=Count("material", distinct=True, filter=added_q),
                    removed_count=Count("material", distinct=True, filter=removed_q),
                    cross_category_count=Count("material", distinct=True, filter=cross_q),
                )
            )
        }

        week_start = since - timedelta(days=since.weekday())
        trend = []
        while week_start <= until:
            row = weekly_rows.get(week_start) or {}
            trend.append({
                "week_start": week_start,
                "added_count": int(row.get("added_count") or 0),
                "removed_count": int(row.get("removed_count") or 0),
                "cross_category_count": int(row.get("cross_category_count") or 0),
            })
            week_start += timedelta(days=7)

        return {
            "sales_group": sales_group,
            "added_count": added_count,
            "removed_count": removed_count,
            "cross_category_count": cross_category_count,
            "trend": trend,
        }
