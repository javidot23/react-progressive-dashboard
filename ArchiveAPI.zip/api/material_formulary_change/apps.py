from django.apps import AppConfig


class MaterialFormularyChangeConfig(AppConfig):
    name = 'api.material_formulary_change'
