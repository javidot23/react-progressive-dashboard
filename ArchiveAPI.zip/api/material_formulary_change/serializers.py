from rest_framework import serializers

from .models import MaterialFormularyChange


class SwitchSummarySerializer(serializers.Serializer):
    initial_program_code = serializers.CharField(allow_null=True)
    final_program_code = serializers.CharField(allow_null=True)
    initial_sales_group = serializers.CharField(allow_null=True)
    final_sales_group = serializers.CharField(allow_null=True)
    count = serializers.IntegerField()


class SwitchDetailSerializer(serializers.ModelSerializer):
    mat_nbr = serializers.CharField(source="material.mat_nbr")
    material_name = serializers.CharField(source="material.name", allow_null=True)

    class Meta:
        model = MaterialFormularyChange
        fields = [
            "id",
            "mat_nbr",
            "material_name",
            "initial_program_code",
            "initial_sales_group",
            "final_program_code",
            "final_sales_group",
            "change_date",
        ]
