"""Keyset (seek) pagination helpers for chunked CSV exports."""

from __future__ import annotations

import hashlib
import re
from datetime import date, datetime
from decimal import Decimal
from uuid import UUID

from django.core import signing
from django.db.models import Q
from rest_framework.exceptions import ValidationError

CURSOR_SALT = "csv-export-cursor"
CURSOR_MAX_AGE_SECONDS = 2 * 60 * 60
EXPORT_PAGING_PARAMS = frozenset({"export_cursor", "export_stem", "export_part"})
STEM_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")

HEADER_HAS_MORE = "X-Export-Has-More"
HEADER_NEXT_CURSOR = "X-Export-Next-Cursor"
HEADER_ROW_COUNT = "X-Export-Row-Count"
HEADER_PAGE_SIZE = "X-Export-Page-Size"
HEADER_TRUNCATED = "X-Export-Truncated"


def parse_ordering(ordering):
    """Return [(field_name, descending), ...] from Django order_by strings."""
    parsed = []
    for item in ordering:
        if not item or not isinstance(item, str):
            continue
        parsed.append((item.lstrip("-"), item.startswith("-")))
    return parsed


def canonical_ordering(order_by, identity_fields):
    """Append missing identity fields so the sort is unique across pages."""
    fields = [item for item in order_by if item]
    ordered_bare = {item.lstrip("-") for item in fields}
    for identity in identity_fields:
        bare = identity.lstrip("-")
        if bare not in ordered_bare:
            fields.append(identity)
            ordered_bare.add(bare)
    return fields


def queryset_order_by(queryset):
    """String order_by tuple from a queryset, or empty if Django used expressions."""
    order_by = getattr(getattr(queryset, "query", None), "order_by", None)
    if not order_by:
        return []
    if all(isinstance(item, str) for item in order_by):
        return list(order_by)
    return []


def append_identity_ordering(queryset, identity_fields):
    """Ensure identity columns are in ORDER BY without replacing the current sort."""
    if not identity_fields:
        return queryset
    merged = canonical_ordering(queryset_order_by(queryset), identity_fields)
    if merged == queryset_order_by(queryset):
        return queryset
    return queryset.order_by(*merged)


def _eq(field, value):
    if value is None:
        return Q(**{f"{field}__isnull": True})
    return Q(**{field: value})


def _never(field):
    """Predicate that matches no rows, using only `field` (safe on .values() querysets)."""
    return Q(**{f"{field}__isnull": True}) & Q(**{f"{field}__isnull": False})


def _after(field, value, descending):
    """Rows strictly after `value` when NULLs sort as larger than every non-null (PostgreSQL)."""
    if descending:
        if value is None:
            return Q(**{f"{field}__isnull": False})
        return Q(**{f"{field}__lt": value})
    if value is None:
        return _never(field)
    return Q(**{f"{field}__gt": value}) | Q(**{f"{field}__isnull": True})


def seek_q(ordering, cursor_values):
    """
    Prefix-OR seek predicate for mixed ASC/DESC keyset pagination.

    For ORDER BY a DESC, b ASC and cursor (a0, b0):
      (a < a0) OR (a = a0 AND b > b0)  — plus NULL handling.
    """
    parsed = parse_ordering(ordering)
    if not parsed:
        raise ValidationError({"error": "Export cursor requires a stable ordering."})
    if len(parsed) != len(cursor_values):
        raise ValidationError({"error": "Export cursor does not match current ordering."})

    combined = Q()
    for index, (field, descending) in enumerate(parsed):
        prefix = Q()
        for earlier, earlier_value in zip(parsed[:index], cursor_values[:index]):
            prefix &= _eq(earlier[0], earlier_value)
        prefix &= _after(field, cursor_values[index], descending)
        combined |= prefix
    return combined


def encode_cursor_value(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        return {"__t": "dt", "v": value.isoformat()}
    if isinstance(value, date):
        return {"__t": "d", "v": value.isoformat()}
    if isinstance(value, Decimal):
        return {"__t": "dec", "v": str(value)}
    if isinstance(value, UUID):
        return {"__t": "uuid", "v": str(value)}
    if isinstance(value, bytes):
        return {"__t": "b64", "v": value.hex()}
    if isinstance(value, (int, float, str, bool)):
        return value
    return str(value)


def decode_cursor_value(value):
    if not isinstance(value, dict) or value.get("__t") is None:
        return value
    tag = value["__t"]
    raw = value.get("v")
    if tag == "d":
        return date.fromisoformat(raw)
    if tag == "dt":
        return datetime.fromisoformat(raw)
    if tag == "dec":
        return Decimal(raw)
    if tag == "uuid":
        return UUID(raw)
    if tag == "b64":
        return bytes.fromhex(raw)
    return raw


def filter_fingerprint(query_params):
    """Stable hash of filters; paging params are excluded so the cursor can change."""
    keys = sorted(
        key for key in query_params.keys()
        if key not in EXPORT_PAGING_PARAMS
    )
    parts = []
    for key in keys:
        if hasattr(query_params, "getlist"):
            values = query_params.getlist(key)
        else:
            raw = query_params.get(key)
            values = raw if isinstance(raw, (list, tuple)) else [raw]
        for item in sorted(str(item) for item in values):
            parts.append(f"{key}={item}")
    return hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()


def tenant_cursor_id(tenant):
    if tenant is None:
        return None
    pk = getattr(tenant, "pk", None)
    return str(pk) if pk is not None else None


def sign_cursor(*, ordering, values, filter_fp, tenant_id, pages_completed):
    payload = {
        "o": list(ordering),
        "v": [encode_cursor_value(item) for item in values],
        "f": filter_fp,
        "t": tenant_id,
        "n": pages_completed,
    }
    return signing.dumps(payload, salt=CURSOR_SALT)


def unsign_cursor(token, *, ordering, filter_fp, tenant_id):
    if not token:
        return None
    try:
        payload = signing.loads(token, salt=CURSOR_SALT, max_age=CURSOR_MAX_AGE_SECONDS)
    except signing.BadSignature as exc:
        raise ValidationError({"error": "Export cursor is invalid or expired."}) from exc

    if payload.get("o") != list(ordering):
        raise ValidationError({"error": "Export cursor does not match current ordering."})
    if payload.get("f") != filter_fp:
        raise ValidationError({"error": "Export cursor does not match current filters."})
    if payload.get("t") != tenant_id:
        raise ValidationError({"error": "Export cursor does not match current tenant."})

    values = tuple(decode_cursor_value(item) for item in payload.get("v") or ())
    if len(values) != len(ordering):
        raise ValidationError({"error": "Export cursor does not match current ordering."})
    try:
        pages_completed = int(payload.get("n", 0))
    except (TypeError, ValueError) as exc:
        raise ValidationError({"error": "Export cursor is invalid or expired."}) from exc
    return values, pages_completed


def peek_page(queryset, cursor_fields, page_size):
    """
    LIMIT page_size+1 on identity/sort scalars only.

    Returns (has_more, last_values_tuple_or_none, row_count_this_page).
    """
    if not cursor_fields:
        raise ValidationError({"error": "Export identity fields are required."})
    rows = list(queryset.values_list(*cursor_fields)[: page_size + 1])
    has_more = len(rows) > page_size
    page = rows[:page_size]
    last_values = tuple(page[-1]) if page else None
    return has_more, last_values, len(page)


def sanitize_export_stem(raw, fallback_prefix):
    if raw and STEM_RE.match(raw):
        return raw
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{fallback_prefix}_{timestamp}"


def parse_export_part(raw, page_number):
    if raw is None or raw == "":
        return page_number
    try:
        part = int(raw)
    except (TypeError, ValueError) as exc:
        raise ValidationError({"error": "export_part must be an integer."}) from exc
    if part < 1:
        raise ValidationError({"error": "export_part must be at least 1."})
    return part


def export_filename(stem, part):
    return f"{stem}_part{part:02d}.csv"
