from __future__ import annotations

from typing import Tuple

from authlib.integrations.django_client import OAuth
from django.conf import settings

_oauth = OAuth()


def _register_clients() -> None:
    explicit_authorize = getattr(settings, 'SAP_CDC_AUTHORIZE_URL', None)
    explicit_token = getattr(settings, 'SAP_CDC_TOKEN_URL', None)
    use_explicit = bool(explicit_authorize and explicit_token)

    issuer = (getattr(settings, 'SAP_CDC_ISSUER', None) or '').rstrip('/')
    metadata_url = (
        getattr(settings, 'SAP_CDC_METADATA_URL', None)
        or (f"{issuer}/.well-known/openid-configuration" if issuer else None)
    )
    jwks_uri = getattr(settings, 'SAP_CDC_JWKS_URI', None)

    sap_kwargs = dict(
        name='sap_cdc',
        client_id=settings.SAP_CDC_CLIENT_ID,
        client_secret=getattr(settings, 'SAP_CDC_CLIENT_SECRET', None),
        client_kwargs={
            'scope': 'openid profile email',
            'code_challenge_method': 'S256',
        },
    )

    # Always attach discovery/JWKS when available so ID-token signature verification
    # works even if authorize/token URLs are set explicitly.
    if metadata_url:
        sap_kwargs['server_metadata_url'] = metadata_url
    elif jwks_uri:
        sap_kwargs['jwks_uri'] = jwks_uri
    else:
        raise ValueError(
            "SAP CDC OIDC requires SAP_CDC_METADATA_URL, SAP_CDC_ISSUER, or "
            "SAP_CDC_JWKS_URI so ID tokens can be signature-verified."
        )

    if use_explicit:
        sap_kwargs['authorize_url'] = explicit_authorize
        sap_kwargs['access_token_url'] = explicit_token
        if settings.SAP_CDC_USERINFO_URL:
            sap_kwargs['userinfo_endpoint'] = settings.SAP_CDC_USERINFO_URL

    if 'sap_cdc' in _oauth._registry:
        del _oauth._registry['sap_cdc']
        _oauth._clients.pop('sap_cdc', None)
    _oauth.register(**sap_kwargs)


def get_oidc_client() -> Tuple[str, object]:
    _register_clients()
    return 'sap_cdc', _oauth.sap_cdc


def get_end_session_endpoint(idp_name: str = 'sap_cdc') -> str | None:
    _register_clients()
    override = getattr(settings, 'SAP_CDC_END_SESSION_URL', None)
    if override:
        return override

    client = getattr(_oauth, idp_name, None)
    if client is None:
        return None
    try:
        metadata = client.load_server_metadata()
    except Exception:
        return None
    return metadata.get('end_session_endpoint')
