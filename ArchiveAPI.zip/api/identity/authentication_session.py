from __future__ import annotations

import time

from rest_framework.authentication import SessionAuthentication
from rest_framework.exceptions import AuthenticationFailed


class CookieSessionAuthentication(SessionAuthentication):
    def authenticate_header(self, request):
        # Returning a string makes DRF respond 401 instead of 403 on failure,
        # which the SPA uses as the signal to redirect to /login/start/.
        return 'Session realm="api"'

    def authenticate(self, request):
        result = super().authenticate(request)
        if result is None:
            return None

        user, _ = result
        session = request.session

        absolute_expiry = session.get("absolute_expiry")
        if absolute_expiry is not None and time.time() > absolute_expiry:
            session.flush()
            raise AuthenticationFailed("session_expired_absolute")

        if not user.is_active or getattr(user, "is_deleted", False):
            session.flush()
            raise AuthenticationFailed("Access denied", code="user_inactive")

        return (user, None)
