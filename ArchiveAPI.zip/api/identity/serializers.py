from rest_framework import serializers


class LogoutResponseSerializer(serializers.Serializer):
    end_session_url = serializers.CharField(allow_null=True)
