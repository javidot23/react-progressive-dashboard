"""Production identity helpers — OIDC claim → user/tenant resolution."""

from typing import Optional

from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _
from rest_framework.exceptions import AuthenticationFailed

from api.tenant.services import TenantMembershipService, TenantService
from api.user.choices import TenantAccessScope
from api.user.services import UserService

User = get_user_model()


def get_or_create_user_from_sap_cdc_claims(
    claims: dict,
    userinfo: Optional[dict] = None,
    *,
    tenant_uuid_hint=None,
) -> tuple:
    """
    Resolve tenant + user from SAP CDC claims.

    Returns ``(user, tenant)``.
    """
    user_id = claims.get("sub")
    if not user_id:
        raise AuthenticationFailed("invalid_token")

    if userinfo and userinfo.get("sub") and userinfo.get("sub") != user_id:
        raise AuthenticationFailed(_("Access denied"), code="invalid_token")

    email_from_claims = (userinfo.get("email", "") or "") if userinfo else ""
    if not email_from_claims:
        email_from_claims = claims.get("email", "") or ""
    given_name = (
        ((userinfo.get("given_name", "") or "").strip() if userinfo else "")
        or (claims.get("given_name", "") or "").strip()
    )
    family_name = (
        ((userinfo.get("family_name", "") or "").strip() if userinfo else "")
        or (claims.get("family_name", "") or "").strip()
    )

    normalized_email = UserService._normalize_login_email(email_from_claims)
    identity = UserService.find_login_identity(user_id, normalized_email)

    if identity is not None and TenantMembershipService.has_all_tenant_access(identity.user):
        candidate_tenants = TenantService.list_active()
    elif identity is None and UserService.scope_for_email(normalized_email) == TenantAccessScope.ALL_TENANTS:
        raise AuthenticationFailed("Access denied", code="not_provisioned")
    else:
        candidate_tenants = TenantService.tenants_for_email(normalized_email)

    tenant = TenantService.resolve_for_login(
        normalized_email,
        tenant_uuid_hint=tenant_uuid_hint,
        matches=candidate_tenants,
    )
    user = UserService.resolve_or_provision_for_login(
        sub=user_id,
        email=normalized_email,
        tenant=tenant,
        candidate_tenants=candidate_tenants,
        first_name=given_name,
        last_name=family_name,
    )
    return user, tenant
