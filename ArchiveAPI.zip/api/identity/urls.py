"""Identity URL Configuration"""
from django.urls import path

from .views import LoginStartView, LoginView, LogoutView

app_name = 'identity'

urlpatterns = [
    path('login/start/', LoginStartView.as_view(), name='login-start'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
]
