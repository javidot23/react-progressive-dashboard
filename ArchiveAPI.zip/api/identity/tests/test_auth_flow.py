"""
Tests for the BFF auth flow: /login/start, /login (callback), /logout, plus
the absolute-cap logic in CookieSessionAuthentication.
"""
import time
from unittest.mock import patch, MagicMock

from django.conf import settings
from django.middleware.csrf import get_token
from django.test import RequestFactory, override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient

from api.audit.choices import AuditEventType
from api.audit.models import AuditLog
from api.tenant.models import TenantMembership
from api.tenant.services import ACTIVE_TENANT_SESSION_KEY, TenantMembershipService
from api.user.choices import TenantAccessScope, UserStatus
from api.user.models import User
from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory
from tests.factories import add_domain, add_membership, create_admin_user, create_tenant


@override_settings(
    SAP_CDC_CLIENT_ID="test-client",
    # No issuer/metadata URL, so authlib never fetches a discovery doc over the
    # network; an explicit jwks_uri satisfies the signature-verification guard.
    SAP_CDC_ISSUER=None,
    SAP_CDC_METADATA_URL=None,
    SAP_CDC_JWKS_URI="https://sap.example.com/jwks",
    SAP_CDC_AUTHORIZE_URL="https://sap.example.com/authorize",
    SAP_CDC_TOKEN_URL="https://sap.example.com/token",
    SAP_CDC_USERINFO_URL="https://sap.example.com/userinfo",
    SAP_CDC_END_SESSION_URL="https://sap.example.com/logout",
    FRONTEND_URL="http://localhost:5173",
)
class LoginStartViewTest(BaseAPITestCase):
    def test_login_start_redirects_to_idp(self):
        url = reverse("identity:login-start")
        response = self.client.get(url, HTTP_X_DISABLE_TEST_AUTH="1")
        self.assertEqual(response.status_code, status.HTTP_302_FOUND)
        self.assertIn("sap.example.com/authorize", response["Location"])


@override_settings(
    SAP_CDC_CLIENT_ID="test-client",
    # No issuer/metadata URL, so authlib never fetches a discovery doc over the
    # network; an explicit jwks_uri satisfies the signature-verification guard.
    SAP_CDC_ISSUER=None,
    SAP_CDC_METADATA_URL=None,
    SAP_CDC_JWKS_URI="https://sap.example.com/jwks",
    SAP_CDC_AUTHORIZE_URL="https://sap.example.com/authorize",
    SAP_CDC_TOKEN_URL="https://sap.example.com/token",
    SAP_CDC_USERINFO_URL="https://sap.example.com/userinfo",
    SAP_CDC_END_SESSION_URL="https://sap.example.com/logout",
    FRONTEND_URL="http://localhost:5173",
)
class LoginViewTest(BaseAPITestCase):
    def _patch_oidc(self, claims, access_token="tok"):
        client = MagicMock()
        client.authorize_access_token.return_value = {
            "access_token": access_token,
            "id_token": "id.token.jwt",
            "userinfo": claims,
        }
        return patch("api.identity.views.get_oidc_client", return_value=("sap_cdc", client))

    def test_login_callback_creates_session_and_user(self):
        claims = {
            "sub": "sap-user-1",
            "email": "alice@test.com",
            "given_name": "Alice",
            "family_name": "Doe",
        }
        with self._patch_oidc(claims), patch(
            "api.identity.views.UserService.get_user_profile_from_sap_cdc",
            return_value=None,
        ):
            response = self.client.get(
                reverse("identity:login") + "?code=abc&state=xyz",
                HTTP_X_DISABLE_TEST_AUTH="1",
            )

        self.assertEqual(response.status_code, status.HTTP_302_FOUND)
        self.assertEqual(response["Location"], "http://localhost:5173")
        session = self.client.session
        self.assertEqual(session["idp"], "sap_cdc")
        self.assertEqual(session["id_token"], "id.token.jwt")
        self.assertIn("absolute_expiry", session)
        from api.user.models import UserIdentity

        identity = UserIdentity.objects.get(auth_subject="sap-user-1", is_deleted=False)
        self.assertEqual(session["_auth_user_id"], str(identity.user_id))

    def test_login_callback_rejects_unclaimed_domain(self):
        claims = {
            "sub": "sap-user-2",
            "email": "bob@other.com",
            "given_name": "Bob",
            "family_name": "Smith",
        }
        with self._patch_oidc(claims), patch(
            "api.identity.views.UserService.get_user_profile_from_sap_cdc",
            return_value=None,
        ):
            response = self.client.get(
                reverse("identity:login") + "?code=abc&state=xyz",
                HTTP_X_DISABLE_TEST_AUTH="1",
            )
        self.assertEqual(response.status_code, status.HTTP_302_FOUND)
        self.assertIn("error=no_tenant_for_domain", response["Location"])
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_login_callback_token_exchange_failure_redirects_to_spa(self):
        client = MagicMock()
        client.authorize_access_token.side_effect = RuntimeError("bad code")
        with patch("api.identity.views.get_oidc_client", return_value=("sap_cdc", client)):
            response = self.client.get(
                reverse("identity:login") + "?code=bad&state=xyz",
                HTTP_X_DISABLE_TEST_AUTH="1",
            )
        self.assertEqual(response.status_code, status.HTTP_302_FOUND)
        self.assertTrue(response["Location"].startswith("http://localhost:5173/login?"))
        self.assertIn("error=oidc_callback_failed", response["Location"])
        self.assertNotIn("_auth_user_id", self.client.session)


@override_settings(
    SAP_CDC_CLIENT_ID="test-client",
    SAP_CDC_ISSUER=None,
    SAP_CDC_METADATA_URL=None,
    SAP_CDC_JWKS_URI="https://sap.example.com/jwks",
    SAP_CDC_END_SESSION_URL="https://sap.example.com/logout",
    FRONTEND_URL="http://localhost:5173",
)
class LogoutViewTest(BaseAPITestCase):
    def setUp(self):
        self.user = TestDataFactory.create_test_user(
            entra_id="logout-user",
            email="logout@test.com",
            first_name="Log",
            last_name="Out",
        )
        # CSRF must be enforced: LogoutView uses CookieSessionAuthentication only.
        self.client = APIClient(enforce_csrf_checks=True)

    def _login_with_bff_session(self):
        self.client.force_login(self.user)
        session = self.client.session
        session["idp"] = "sap_cdc"
        session["id_token"] = "id-token-abc"
        session["absolute_expiry"] = int(time.time() + 3600)
        session.save()

    def _csrf_headers(self):
        request = RequestFactory().post("/")
        request.session = self.client.session
        token = get_token(request)
        self.client.cookies[settings.CSRF_COOKIE_NAME] = token
        return {"HTTP_X_CSRFTOKEN": token}

    def test_logout_flushes_session_and_returns_end_session_url(self):
        self._login_with_bff_session()
        response = self.client.post(
            reverse("identity:logout"),
            **self._csrf_headers(),
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        url = response.data["end_session_url"]
        self.assertIn("https://sap.example.com/logout", url)
        self.assertIn("id_token_hint=id-token-abc", url)
        self.assertIn("post_logout_redirect_uri=", url)

        refreshed = self.client.session
        self.assertNotIn("idp", refreshed)
        self.assertNotIn("id_token", refreshed)

    def test_logout_without_csrf_is_forbidden(self):
        self._login_with_bff_session()
        response = self.client.post(reverse("identity:logout"))
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_logout_without_session_returns_401(self):
        response = self.client.post(reverse("identity:logout"))
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)


class CookieSessionAbsoluteExpiryTest(BaseAPITestCase):
    def setUp(self):
        self.user = TestDataFactory.create_test_user(
            entra_id="abs-user",
            email="abs@test.com",
            first_name="Abs",
            last_name="User",
        )

    def test_absolute_expiry_in_past_rejects_request(self):
        # Use force_login to populate _auth_user_id/_auth_user_hash correctly,
        # then stamp an absolute_expiry in the past.
        self.client.force_login(self.user)
        session = self.client.session
        session["absolute_expiry"] = int(time.time() - 1)
        session.save()

        # Disable TestAutoAuthentication so only CookieSessionAuthentication runs.
        response = self.client.get(reverse("user:user-profile"), HTTP_X_DISABLE_TEST_AUTH="1")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_active_session_within_window_passes(self):
        self.client.force_login(self.user)
        session = self.client.session
        session["absolute_expiry"] = int(time.time() + 3600)
        session.save()

        response = self.client.get(reverse("user:user-profile"), HTTP_X_DISABLE_TEST_AUTH="1")
        self.assertEqual(response.status_code, status.HTTP_200_OK)


@override_settings(
    SAP_CDC_CLIENT_ID="test-client",
    SAP_CDC_ISSUER=None,
    SAP_CDC_METADATA_URL=None,
    SAP_CDC_JWKS_URI="https://sap.example.com/jwks",
    SAP_CDC_AUTHORIZE_URL="https://sap.example.com/authorize",
    SAP_CDC_TOKEN_URL="https://sap.example.com/token",
    SAP_CDC_USERINFO_URL=None,
    FRONTEND_URL="http://localhost:5173",
)
class MultiTenantLoginTest(BaseAPITestCase):
    """A shared email domain must not lock the user out of logging in."""

    def setUp(self):
        super().setUp()
        # The harness otherwise pins the test tenant into every session, which is
        # exactly the state these tests assert the absence of.
        self.test_tenant = None
        self.client.test_tenant = None
        self.a = create_tenant(code="MT-A", is_federated=False)
        self.b = create_tenant(code="MT-B", is_federated=False)
        add_domain(self.a, "shared.com")
        add_domain(self.b, "shared.com")
        self.user = create_admin_user(email="multi@shared.com", subject="multi-sub")

    def _callback(self, sub="multi-sub", email="multi@shared.com", hint=None):
        claims = {"sub": sub, "email": email, "given_name": "Multi", "family_name": "Tenant"}
        client = MagicMock()
        client.authorize_access_token.return_value = {
            "access_token": "tok",
            "id_token": "id.token.jwt",
            "userinfo": claims,
        }
        url = reverse("identity:login") + "?code=abc&state=xyz"
        with patch("api.identity.views.get_oidc_client", return_value=("sap_cdc", client)):
            if hint is not None:
                start = reverse("identity:login-start") + f"?tenant_uuid={hint}"
                with patch("api.identity.views.get_oidc_client", return_value=("sap_cdc", client)):
                    self.client.get(start, HTTP_X_DISABLE_TEST_AUTH="1")
            return self.client.get(url, HTTP_X_DISABLE_TEST_AUTH="1")

    def test_ambiguous_domain_logs_in_without_an_active_tenant(self):
        add_membership(self.user, self.a)
        # Stale key from a prior session must not survive an ambiguous re-login.
        session = self.client.session
        session[ACTIVE_TENANT_SESSION_KEY] = str(self.a.pk)
        session.save()

        response = self._callback()

        self.assertEqual(response.status_code, status.HTTP_302_FOUND)
        self.assertEqual(response["Location"], settings.FRONTEND_URL)
        session = self.client.session
        self.assertEqual(session["_auth_user_id"], str(self.user.pk))
        self.assertNotIn(ACTIVE_TENANT_SESSION_KEY, session)

    def test_ambiguous_domain_without_any_membership_is_denied(self):
        response = self._callback()

        self.assertEqual(response.status_code, status.HTTP_302_FOUND)
        self.assertIn("error=membership_required", response["Location"])
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_unknown_user_on_ambiguous_domain_must_select_a_tenant(self):
        response = self._callback(sub="brand-new-sub", email="newcomer@shared.com")

        self.assertEqual(response.status_code, status.HTTP_302_FOUND)
        self.assertIn("error=tenant_selection_required", response["Location"])

    def test_the_spa_can_recover_by_selecting_a_tenant(self):
        add_membership(self.user, self.a)
        self._callback()

        response = self.client.post(
            reverse("tenant:tenant-active"),
            {"tenant_uuid": str(self.a.pk)},
            format="json",
            HTTP_X_DISABLE_TEST_AUTH="1",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            self.client.session[ACTIVE_TENANT_SESSION_KEY], str(self.a.pk)
        )


@override_settings(
    SAP_CDC_CLIENT_ID="test-client",
    SAP_CDC_ISSUER=None,
    SAP_CDC_METADATA_URL=None,
    SAP_CDC_JWKS_URI="https://sap.example.com/jwks",
    SAP_CDC_AUTHORIZE_URL="https://sap.example.com/authorize",
    SAP_CDC_TOKEN_URL="https://sap.example.com/token",
    SAP_CDC_USERINFO_URL=None,
    FRONTEND_URL="http://localhost:5173",
)
class LoginRejectionReasonTest(BaseAPITestCase):
    """Each guard must be distinguishable from the redirect code and the audit row."""

    def setUp(self):
        super().setUp()
        self.test_tenant = None
        self.client.test_tenant = None

    def _callback(self, email, sub="reason-sub"):
        claims = {"sub": sub, "email": email, "given_name": "R", "family_name": "T"}
        client = MagicMock()
        client.authorize_access_token.return_value = {
            "access_token": "tok",
            "id_token": "id.token.jwt",
            "userinfo": claims,
        }
        with patch("api.identity.views.get_oidc_client", return_value=("sap_cdc", client)):
            return self.client.get(
                reverse("identity:login") + "?code=abc&state=xyz",
                HTTP_X_DISABLE_TEST_AUTH="1",
            )

    def _last_failure(self):
        return (
            AuditLog.objects.filter(audit_event_type=AuditEventType.LOGIN_FAILURE)
            .order_by("-event_timestamp")
            .first()
        )

    def test_no_tenant_claims_the_domain(self):
        create_tenant(code="NOD", is_federated=False)  # no TenantDomain rows

        response = self._callback("someone@unclaimed.com")

        self.assertIn("error=no_tenant_for_domain", response["Location"])
        row = self._last_failure()
        self.assertEqual(row.reason_code, "no_tenant_for_domain")
        self.assertEqual(row.metadata["email"], "someone@unclaimed.com")

    def test_non_federated_tenant_rejects_an_unregistered_account(self):
        tenant = create_tenant(code="NFED", is_federated=False)
        add_domain(tenant, "nfed.com")

        response = self._callback("stranger@nfed.com")

        self.assertIn("error=not_provisioned", response["Location"])
        row = self._last_failure()
        self.assertEqual(row.reason_code, "not_provisioned")
        self.assertEqual(row.metadata["email"], "stranger@nfed.com")
        self.assertEqual(row.metadata["auth_subject"], "reason-sub")

    def test_federated_tenant_provisions_the_same_account(self):
        tenant = create_tenant(code="FED", is_federated=True)
        add_domain(tenant, "fed.com")

        response = self._callback("newcomer@fed.com")

        self.assertEqual(response["Location"], settings.FRONTEND_URL)
        self.assertIn("_auth_user_id", self.client.session)

    def test_inactive_user_is_reported_as_such(self):
        tenant = create_tenant(code="INACT", is_federated=False)
        add_domain(tenant, "inact.com")
        user = create_admin_user(email="dormant@inact.com", subject="dormant-sub")
        add_membership(user, tenant)
        user.status = UserStatus.INACTIVE
        user.save(update_fields=["status"])

        response = self._callback("dormant@inact.com", sub="dormant-sub")

        self.assertIn("error=user_inactive", response["Location"])
        self.assertEqual(self._last_failure().reason_code, "user_inactive")

    def test_unknown_internal_email_is_not_provisioned(self):
        create_tenant(code="INTDENY", is_federated=True)

        response = self._callback("stranger@cencora.com", sub="internal-stranger")

        self.assertIn("error=not_provisioned", response["Location"])
        self.assertEqual(self._last_failure().reason_code, "not_provisioned")
        self.assertFalse(User.objects.filter(identities__email="stranger@cencora.com").exists())

    def test_precreated_all_tenants_user_logs_in_without_domain_or_membership(self):
        a = create_tenant(code="INTA", is_federated=False)
        b = create_tenant(code="INTB", is_federated=False)
        user = create_admin_user(
            email="staff@cencora.com",
            subject="internal-staff",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )

        response = self._callback("staff@cencora.com", sub="internal-staff")

        self.assertEqual(response["Location"], settings.FRONTEND_URL)
        self.assertEqual(self.client.session["_auth_user_id"], str(user.pk))
        self.assertNotIn(ACTIVE_TENANT_SESSION_KEY, self.client.session)
        self.assertFalse(TenantMembership.objects.filter(user=user).exists())
        listed = {t.pk for t in TenantMembershipService.list_tenants_for_user(user)}
        self.assertIn(a.pk, listed)
        self.assertIn(b.pk, listed)
