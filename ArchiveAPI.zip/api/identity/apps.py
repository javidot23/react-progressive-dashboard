from django.apps import AppConfig

from config.db_scope import DBScope


class IdentityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.identity'
    label = 'identity'
    db_scope = DBScope.CORE
