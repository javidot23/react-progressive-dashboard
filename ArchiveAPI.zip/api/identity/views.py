from __future__ import annotations

import logging
import time
from urllib.parse import urlencode

from django.conf import settings
from django.contrib.auth import login as django_login
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from rest_framework import status
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import OpenApiResponse, extend_schema, extend_schema_view

from api.tenant.services import (
    ACTIVE_TENANT_SESSION_KEY,
    PENDING_TENANT_HINT_SESSION_KEY,
)
from api.user.services import UserService
from api.audit.choices import AuditEventType
from api.audit.services import AuditService

from .authentication import get_or_create_user_from_sap_cdc_claims
from .authentication_session import CookieSessionAuthentication
from .oidc import get_end_session_endpoint, get_oidc_client
from .serializers import LogoutResponseSerializer

logger = logging.getLogger(__name__)


LOCAL_DEV_SESSION_KEY = "local_dev_login"


def _local_dev_allowed() -> bool:
    """Whether this deployment serves logins to a proxying frontend dev server."""
    return settings.LOCAL_DEV_FRONTEND_URL in settings.CSRF_TRUSTED_ORIGINS


def _frontend_url(local: bool) -> str:
    """Base URL of the SPA this login belongs to."""
    return settings.LOCAL_DEV_FRONTEND_URL if local else settings.FRONTEND_URL


def _callback_url(request) -> str:
    """OIDC redirect_uri — must match the IdP allowlist (e.g. /api/login/)."""
    if request.session.get(LOCAL_DEV_SESSION_KEY):
        return f"{settings.LOCAL_DEV_FRONTEND_URL}/login"
    override = getattr(settings, "OIDC_CALLBACK_URL", None)
    if override:
        return override
    return request.build_absolute_uri(reverse("identity:login"))


def _login_error_redirect(code: str, local: bool = False):
    """Send the browser back to the SPA with a machine-readable failure code."""
    return redirect(f"{_frontend_url(local)}/login?{urlencode({'error': code})}")


def _failure_reason(exc) -> str:
    """The DRF error code behind a login rejection, e.g. ``not_provisioned``."""
    codes = exc.get_codes() if hasattr(exc, "get_codes") else None
    if isinstance(codes, str):
        return codes
    return str(getattr(exc, "default_code", None) or "login_rejected")


@method_decorator(never_cache, name="dispatch")
@extend_schema_view(
    get=extend_schema(responses={302: OpenApiResponse(description='Redirect')}),
)
class LoginStartView(APIView):
    """GET /login/start/ — begin OIDC; optional ``tenant_uuid`` query hint is stored in session.

    ``local=1`` points the callback and post-login redirect at a frontend dev
    server proxying /api to this deployment.
    """

    authentication_classes: list = []
    permission_classes = [AllowAny]

    def get(self, request):
        logger.info("OIDC login start")
        tenant_hint = request.query_params.get("tenant_uuid")
        if tenant_hint:
            request.session[PENDING_TENANT_HINT_SESSION_KEY] = str(tenant_hint)
        else:
            request.session.pop(PENDING_TENANT_HINT_SESSION_KEY, None)

        if request.query_params.get("local") and _local_dev_allowed():
            request.session[LOCAL_DEV_SESSION_KEY] = True
        else:
            request.session.pop(LOCAL_DEV_SESSION_KEY, None)
        request.session.save()

        _, client = get_oidc_client()
        return client.authorize_redirect(request, _callback_url(request))


@method_decorator(never_cache, name="dispatch")
@extend_schema_view(
    get=extend_schema(responses={302: OpenApiResponse(description='Redirect')}),
)
class LoginView(APIView):
    """GET /login/ — OIDC callback; establishes the session."""

    authentication_classes: list = []
    permission_classes = [AllowAny]

    def get(self, request):
        logger.info("OIDC login callback")
        local = bool(request.session.get(LOCAL_DEV_SESSION_KEY))
        idp, client = get_oidc_client()
        try:
            token = client.authorize_access_token(request)
        except Exception as e:
            logger.warning("OIDC token exchange failed: %s", e)
            return _login_error_redirect("oidc_callback_failed", local)

        claims = token.get("userinfo") or {}
        if not claims:
            try:
                claims = client.parse_id_token(request, token) or {}
            except Exception as e:
                logger.warning("ID token parse failed: %s", e)
                return _login_error_redirect("invalid_id_token", local)

        access_token = token.get("access_token")
        tenant_hint = request.session.pop(PENDING_TENANT_HINT_SESSION_KEY, None)

        try:
            userinfo = None
            if access_token and settings.SAP_CDC_USERINFO_URL:
                userinfo = UserService.get_user_profile_from_sap_cdc(access_token)
            user, tenant = get_or_create_user_from_sap_cdc_claims(
                claims,
                userinfo,
                tenant_uuid_hint=tenant_hint,
            )
        except AuthenticationFailed as e:
            reason = _failure_reason(e)
            attempted_email = (userinfo or {}).get("email") or claims.get("email") or ""

            logger.warning(
                "Login callback rejected: reason=%s email=%s tenant_hint=%s",
                reason,
                attempted_email or "<unknown>",
                tenant_hint or "<none>",
            )
            AuditService.record_from_request(
                request,
                AuditEventType.LOGIN_FAILURE,
                reason_code=reason,
                status=status.HTTP_403_FORBIDDEN,
                metadata={
                    "reason": reason,
                    "detail": str(e.detail),
                    "email": attempted_email,
                    "auth_subject": claims.get("sub") or "",
                    "tenant_hint": str(tenant_hint or ""),
                },
            )
            return _login_error_redirect(reason, local)

        user.backend = "django.contrib.auth.backends.ModelBackend"
        django_login(request, user)

        if local:
            request.session[LOCAL_DEV_SESSION_KEY] = True
        request.session["idp"] = idp
        request.session["id_token"] = token.get("id_token")
        request.session["claims"] = claims
        request.session["absolute_expiry"] = int(
            time.time() + settings.SESSION_ABSOLUTE_TIMEOUT_SECONDS
        )
        if tenant is not None:
            request.session[ACTIVE_TENANT_SESSION_KEY] = str(tenant.pk)
        else:
            request.session.pop(ACTIVE_TENANT_SESSION_KEY, None)
        request.session.set_expiry(settings.SESSION_IDLE_TIMEOUT_SECONDS)

        AuditService.record_from_request(
            request,
            AuditEventType.LOGIN_SUCCESS,
            actor_user=user,
            tenant=tenant,
            status=302,
            target_entity={"type": "user", "id": str(user.pk)},
        )
        if tenant is not None:
            AuditService.record_from_request(
                request,
                AuditEventType.TENANT_SELECTED,
                actor_user=user,
                tenant=tenant,
                status=302,
                target_entity={"type": "tenant", "id": str(tenant.pk)},
                metadata={"via": "login"},
            )

        return redirect(_frontend_url(local))


@method_decorator(never_cache, name="dispatch")
class LogoutView(APIView):
    authentication_classes = [CookieSessionAuthentication]
    serializer_class = LogoutResponseSerializer

    @extend_schema(responses=LogoutResponseSerializer)
    def post(self, request):
        session = request.session
        id_token = session.get("id_token")
        idp = session.get("idp")

        AuditService.record_from_request(
            request,
            AuditEventType.LOGOUT,
            status=status.HTTP_200_OK,
            target_entity={"type": "user", "id": str(getattr(request.user, "pk", ""))},
        )

        end_session_url = None
        if idp and id_token:
            base = get_end_session_endpoint(idp)
            if base:
                params = {
                    "id_token_hint": id_token,
                    "post_logout_redirect_uri": _frontend_url(
                        bool(session.get(LOCAL_DEV_SESSION_KEY))
                    ),
                }
                sep = "&" if "?" in base else "?"
                end_session_url = f"{base}{sep}{urlencode(params)}"

        session.flush()

        response = Response({"end_session_url": end_session_url})
        response.delete_cookie(
            settings.SESSION_COOKIE_NAME,
            path=settings.SESSION_COOKIE_PATH,
            domain=settings.SESSION_COOKIE_DOMAIN,
        )
        response.delete_cookie(
            settings.CSRF_COOKIE_NAME,
            path=settings.CSRF_COOKIE_PATH,
            domain=settings.CSRF_COOKIE_DOMAIN,
        )
        return response
