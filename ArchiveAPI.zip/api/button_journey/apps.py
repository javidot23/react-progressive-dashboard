from django.apps import AppConfig


class ButtonJourneyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.button_journey"
