from django.urls import path

from api.button_journey.views import ButtonJourneyTreeView

app_name = "button-journey"

urlpatterns = [
    path("", ButtonJourneyTreeView.as_view(), name="button-journey-tree"),
]
