from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from api.button_journey.serializers import ButtonJourneyTreeSerializer
from api.button_journey.services import ButtonJourneyService


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="get")
@extend_schema_view(
    get=extend_schema(
        tags=["Button Journey"],
        summary="Get latest button journey tree",
        description=(
            "Returns guided button-journey Q&A for the latest ``run_id``, shaped as "
            "entry buttons with nested followups. The Databricks SQL ``query`` field "
            "is stored but not returned."
        ),
        responses=ButtonJourneyTreeSerializer,
    ),
)
class ButtonJourneyTreeView(APIView):
    """Return the latest button journey as a chat tree."""

    def get(self, request):
        tree = ButtonJourneyService.get_latest_tree()
        serializer = ButtonJourneyTreeSerializer(tree)
        return Response(serializer.data, status=status.HTTP_200_OK)
