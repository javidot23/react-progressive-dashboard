from django.db import models


class ButtonJourneyResult(models.Model):
    """Precomputed guided button-journey Q&A response for a portfolio visual."""

    run_id = models.BigIntegerField()
    run_timestamp = models.DateTimeField()
    query_id = models.CharField(max_length=255)
    visual = models.CharField(max_length=255)
    button_label = models.CharField(max_length=255)
    result_type = models.CharField(max_length=255)
    time_window = models.CharField(max_length=255, null=True, blank=True)
    response_template = models.TextField(null=True, blank=True)
    query = models.TextField(null=True, blank=True)
    rendered_response = models.TextField()
    metrics_json = models.JSONField(default=list, blank=True)
    status = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "button_journey_results"
        verbose_name = "Button Journey Result"
        verbose_name_plural = "Button Journey Results"
        unique_together = [("run_id", "query_id")]
        indexes = [
            models.Index(fields=["run_id"]),
            models.Index(fields=["visual"]),
            models.Index(fields=["query_id"]),
        ]

    def __str__(self):
        return f"{self.query_id} (run {self.run_id})"
