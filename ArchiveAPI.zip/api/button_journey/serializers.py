from rest_framework import serializers


class ButtonJourneyNodeSerializer(serializers.Serializer):
    """A journey button with optional nested followups."""

    id = serializers.IntegerField()
    query_id = serializers.CharField()
    visual = serializers.CharField()
    button_label = serializers.CharField()
    result_type = serializers.CharField()
    time_window = serializers.CharField(allow_null=True)
    response_template = serializers.CharField(allow_null=True)
    rendered_response = serializers.CharField()
    metrics_json = serializers.JSONField()
    status = serializers.CharField(allow_null=True)
    followups = serializers.SerializerMethodField()

    def get_followups(self, obj):
        return ButtonJourneyNodeSerializer(obj.get("followups", []), many=True).data


class ButtonJourneyTreeSerializer(serializers.Serializer):
    """Latest button-journey run shaped as a chat tree."""

    run_id = serializers.IntegerField(allow_null=True)
    run_timestamp = serializers.DateTimeField(allow_null=True)
    entries = ButtonJourneyNodeSerializer(many=True)
