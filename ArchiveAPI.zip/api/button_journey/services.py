import logging

from django.db.models import Max

from api.button_journey.models import ButtonJourneyResult

logger = logging.getLogger(__name__)

VISUAL_SORT_ORDER = {
    "V1": 0,
    "V2": 1,
    "V2-V3": 2,
    "V3": 3,
    "V4": 4,
}

FOLLOWUP_MARKER = "_followup_"


class ButtonJourneyService:
    @staticmethod
    def get_latest_tree():
        """Return the latest run as a chat tree of entries with nested followups."""
        latest_run_id = ButtonJourneyResult.objects.aggregate(latest=Max("run_id")).get(
            "latest"
        )
        if latest_run_id is None:
            logger.info("No button journey results found")
            return {
                "run_id": None,
                "run_timestamp": None,
                "entries": [],
            }

        rows = list(
            ButtonJourneyResult.objects.filter(run_id=latest_run_id).order_by("query_id")
        )
        logger.info(
            "Building button journey tree for run_id=%s (%s rows)",
            latest_run_id,
            len(rows),
        )
        return ButtonJourneyService._build_tree(rows)

    @staticmethod
    def _build_tree(rows):
        if not rows:
            return {
                "run_id": None,
                "run_timestamp": None,
                "entries": [],
            }

        run_id = rows[0].run_id
        run_timestamp = rows[0].run_timestamp

        entries_by_query_id = {}
        followups = []

        for row in rows:
            if FOLLOWUP_MARKER in row.query_id:
                followups.append(row)
            else:
                entries_by_query_id[row.query_id] = {
                    "row": row,
                    "followups": [],
                }

        orphan_entries = []
        for followup in followups:
            prefix = followup.query_id.split(FOLLOWUP_MARKER, 1)[0]
            parent_query_id = f"{prefix}_entry"
            parent = entries_by_query_id.get(parent_query_id)
            if parent is not None:
                parent["followups"].append(followup)
            else:
                orphan_entries.append(
                    {
                        "row": followup,
                        "followups": [],
                    }
                )

        entry_nodes = list(entries_by_query_id.values()) + orphan_entries
        entry_nodes.sort(
            key=lambda node: (
                VISUAL_SORT_ORDER.get(node["row"].visual, 99),
                node["row"].query_id,
            )
        )

        for node in entry_nodes:
            node["followups"].sort(key=lambda row: row.query_id)

        return {
            "run_id": run_id,
            "run_timestamp": run_timestamp,
            "entries": [
                ButtonJourneyService._serialize_node(
                    node["row"],
                    followups=node["followups"],
                )
                for node in entry_nodes
            ],
        }

    @staticmethod
    def _serialize_node(row, followups=None):
        return {
            "id": row.id,
            "query_id": row.query_id,
            "visual": row.visual,
            "button_label": row.button_label,
            "result_type": row.result_type,
            "time_window": row.time_window,
            "response_template": row.response_template,
            "rendered_response": row.rendered_response,
            "metrics_json": row.metrics_json,
            "status": row.status,
            "followups": [
                ButtonJourneyService._serialize_node(child, followups=[])
                for child in (followups or [])
            ],
        }
