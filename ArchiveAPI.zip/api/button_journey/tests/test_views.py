from django.urls import reverse
from django.utils import timezone
from rest_framework import status

from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class ButtonJourneyTreeViewsTest(BaseAPITestCase):
    def setUp(self):
        super().setUp()
        self.user = TestDataFactory.create_test_user()
        self.client.force_authenticate(user=self.user)
        self.url = reverse("button-journey:button-journey-tree")

    def test_tree_view_empty(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            response.data,
            {
                "run_id": None,
                "run_timestamp": None,
                "entries": [],
            },
        )

    def test_tree_view_excludes_query_and_nests_followups(self):
        newer_ts = timezone.now()
        TestDataFactory.create_button_journey_result(
            run_id=1,
            query_id="v1_entry",
            rendered_response="Old",
            query="SELECT old",
        )
        TestDataFactory.create_button_journey_result(
            run_id=7,
            query_id="v1_entry",
            run_timestamp=newer_ts,
            visual="V1",
            button_label="Fill rate",
            rendered_response="Latest entry",
            query="SELECT secret sql",
            metrics_json=[{"otif_pct": "24.9"}],
        )
        TestDataFactory.create_button_journey_result(
            run_id=7,
            query_id="v1_followup_1b",
            run_timestamp=newer_ts,
            visual="V1",
            button_label="Which products are most affected?",
            result_type="list",
            rendered_response="Latest followup",
            query="SELECT secret followup",
        )

        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["run_id"], 7)
        self.assertEqual(len(response.data["entries"]), 1)

        entry = response.data["entries"][0]
        self.assertEqual(entry["query_id"], "v1_entry")
        self.assertEqual(entry["button_label"], "Fill rate")
        self.assertEqual(entry["rendered_response"], "Latest entry")
        self.assertEqual(entry["metrics_json"], [{"otif_pct": "24.9"}])
        self.assertNotIn("query", entry)
        self.assertNotIn("run_id", entry)
        self.assertEqual(len(entry["followups"]), 1)
        self.assertEqual(entry["followups"][0]["query_id"], "v1_followup_1b")
        self.assertNotIn("query", entry["followups"][0])
        self.assertEqual(entry["followups"][0]["followups"], [])
