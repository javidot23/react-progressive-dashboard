from django.utils import timezone

from api.button_journey.services import ButtonJourneyService
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class ButtonJourneyServiceTest(BaseTestCase):
    def test_empty_returns_empty_tree(self):
        tree = ButtonJourneyService.get_latest_tree()
        self.assertEqual(tree["run_id"], None)
        self.assertEqual(tree["run_timestamp"], None)
        self.assertEqual(tree["entries"], [])

    def test_returns_only_latest_run_as_tree(self):
        older_ts = timezone.now()
        newer_ts = timezone.now()

        TestDataFactory.create_button_journey_result(
            run_id=1,
            query_id="v1_entry",
            run_timestamp=older_ts,
            visual="V1",
            button_label="Old fill rate",
            rendered_response="Old response",
        )
        TestDataFactory.create_button_journey_result(
            run_id=2,
            query_id="v1_entry",
            run_timestamp=newer_ts,
            visual="V1",
            button_label="Fill rate",
            rendered_response="Latest V1",
            query="SELECT secret",
        )
        TestDataFactory.create_button_journey_result(
            run_id=2,
            query_id="v1_followup_1b",
            run_timestamp=newer_ts,
            visual="V1",
            button_label="Which products are most affected?",
            result_type="list",
            rendered_response="Latest V1 followup",
        )
        TestDataFactory.create_button_journey_result(
            run_id=2,
            query_id="bridge_v2_v3",
            run_timestamp=newer_ts,
            visual="V2-V3",
            button_label="Fulfillment impact on sales",
            rendered_response="Bridge response",
        )
        TestDataFactory.create_button_journey_result(
            run_id=2,
            query_id="v2_entry",
            run_timestamp=newer_ts,
            visual="V2",
            button_label="Unfilled quantity",
            rendered_response="Latest V2",
        )

        tree = ButtonJourneyService.get_latest_tree()
        self.assertEqual(tree["run_id"], 2)
        self.assertEqual(tree["run_timestamp"], newer_ts)
        self.assertEqual(
            [entry["query_id"] for entry in tree["entries"]],
            ["v1_entry", "v2_entry", "bridge_v2_v3"],
        )

        v1 = tree["entries"][0]
        self.assertEqual(v1["button_label"], "Fill rate")
        self.assertEqual(v1["rendered_response"], "Latest V1")
        self.assertNotIn("query", v1)
        self.assertEqual(len(v1["followups"]), 1)
        self.assertEqual(v1["followups"][0]["query_id"], "v1_followup_1b")
        self.assertEqual(v1["followups"][0]["followups"], [])

        bridge = tree["entries"][2]
        self.assertEqual(bridge["query_id"], "bridge_v2_v3")
        self.assertEqual(bridge["followups"], [])

    def test_orphan_followup_promoted_to_entry(self):
        TestDataFactory.create_button_journey_result(
            run_id=3,
            query_id="v9_followup_9a",
            visual="V4",
            button_label="Orphan followup",
            result_type="list",
            rendered_response="Orphan answer",
        )

        tree = ButtonJourneyService.get_latest_tree()
        self.assertEqual(len(tree["entries"]), 1)
        self.assertEqual(tree["entries"][0]["query_id"], "v9_followup_9a")
        self.assertEqual(tree["entries"][0]["followups"], [])

    def test_visual_sort_order(self):
        ts = timezone.now()
        for query_id, visual in [
            ("v4_entry", "V4"),
            ("v3_entry", "V3"),
            ("bridge_v2_v3", "V2-V3"),
            ("v2_entry", "V2"),
            ("v1_entry", "V1"),
        ]:
            TestDataFactory.create_button_journey_result(
                run_id=4,
                query_id=query_id,
                run_timestamp=ts,
                visual=visual,
                rendered_response=query_id,
            )

        tree = ButtonJourneyService.get_latest_tree()
        self.assertEqual(
            [entry["query_id"] for entry in tree["entries"]],
            ["v1_entry", "v2_entry", "bridge_v2_v3", "v3_entry", "v4_entry"],
        )
