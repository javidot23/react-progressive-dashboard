-- ============================================================================
-- Demand Forecast Performance Indexes
-- ============================================================================

-- ============================================================================
-- Index 1: Date + Forecast Quantity
-- ============================================================================
-- Helps: Filtering by date range and checking forecast_qty_7day > 0
-- Use case: Quick elimination of no-forecast records in date ranges
-- Size estimate: ~500 MB for 50M rows

DROP INDEX IF EXISTS idx_demand_forecast_date_forecast;
CREATE INDEX CONCURRENTLY idx_demand_forecast_date_forecast
ON demand_forecast (demand_date, forecast_qty_7day);

-- Analyze the table to update statistics after index creation
ANALYZE demand_forecast;

-- ============================================================================
-- Index 2: Date + Forecast + Saleable Quantity (Covering Index)
-- ============================================================================
-- Helps: Covers all columns needed for DOH calculation
-- Use case: May allow index-only scans (no table lookup needed)
-- Size estimate: ~700 MB for 50M rows
-- NOTE: This is the heaviest index - skip if disk space is a concern

DROP INDEX IF EXISTS idx_demand_forecast_date_forecast_saleable;
CREATE INDEX CONCURRENTLY idx_demand_forecast_date_forecast_saleable
ON demand_forecast (demand_date, forecast_qty_7day, saleable_qty_on_hand);

ANALYZE demand_forecast;

-- ============================================================================
-- Index 3: Date + Material + Forecast
-- ============================================================================
-- Helps: Queries filtered by specific materials in date ranges
-- Use case: Material-specific drill-downs
-- Size estimate: ~800 MB for 50M rows (mat_nbr is varchar)

DROP INDEX IF EXISTS idx_demand_forecast_date_material_forecast;
CREATE INDEX CONCURRENTLY idx_demand_forecast_date_material_forecast
ON demand_forecast (demand_date, mat_nbr, forecast_qty_7day);

-- ============================================================================
-- Rollback (if needed)
-- ============================================================================
-- To remove these indexes if they cause issues:
-- DROP INDEX CONCURRENTLY IF EXISTS idx_demand_forecast_date_forecast;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_demand_forecast_date_forecast_saleable;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_demand_forecast_date_material_forecast;
