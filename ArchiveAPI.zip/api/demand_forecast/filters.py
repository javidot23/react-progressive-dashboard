from django_filters.rest_framework import FilterSet, filters

from api.demand_forecast.materialized_view_models import (
    DemandForecastMaterialPlantMV,
)
from api.demand_forecast.models import DemandForecast
from api.global_filters import GlobalFilterForRelatedMaterialMixin, GlobalFilterMixin
from api.material.models import Material


class MaterialsLowInventoryFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """
    Filter set for materials with low inventory endpoint (pre-aggregation).
    Supports global filters for material-related fields.
    """

    material = filters.CharFilter(field_name='material', lookup_expr='exact')

    class Meta:
        model = DemandForecastMaterialPlantMV
        fields = []


class MaterialsLowInventoryAggregatedFilter(FilterSet):
    """
    Post-aggregation range filters for materials with low inventory endpoint.
    Applied to the aggregated queryset returned by the service.
    """

    dc_min = filters.NumberFilter(field_name='dc_count', lookup_expr='gte')
    dc_max = filters.NumberFilter(field_name='dc_count', lookup_expr='lte')
    outbound_fill_rate_min = filters.NumberFilter(field_name='outbound_fill_rate', lookup_expr='gte')
    outbound_fill_rate_max = filters.NumberFilter(field_name='outbound_fill_rate', lookup_expr='lte')
    doh_days_min = filters.NumberFilter(field_name='doh_days', lookup_expr='gte')
    doh_days_max = filters.NumberFilter(field_name='doh_days', lookup_expr='lte')
    doo_days_min = filters.NumberFilter(field_name='doo_days', lookup_expr='gte')
    doo_days_max = filters.NumberFilter(field_name='doo_days', lookup_expr='lte')

    class Meta:
        model = DemandForecast
        fields = []


class MaterialsInventoryFilter(GlobalFilterMixin, FilterSet):
    """
    FilterSet for All Products inventory list (Material queryset with DF annotations).
    """

    material_status = filters.CharFilter(field_name="material_status", lookup_expr="iexact")

    days_on_hand_min = filters.NumberFilter(field_name="days_on_hand", lookup_expr="gte")
    days_on_hand_max = filters.NumberFilter(field_name="days_on_hand", lookup_expr="lte")
    days_on_order_min = filters.NumberFilter(field_name="days_on_order", lookup_expr="gte")
    days_on_order_max = filters.NumberFilter(field_name="days_on_order", lookup_expr="lte")
    units_on_hand_min = filters.NumberFilter(field_name="units_on_hand", lookup_expr="gte")
    units_on_hand_max = filters.NumberFilter(field_name="units_on_hand", lookup_expr="lte")
    units_on_order_min = filters.NumberFilter(field_name="units_on_order", lookup_expr="gte")
    units_on_order_max = filters.NumberFilter(field_name="units_on_order", lookup_expr="lte")
    outbound_fill_rate_min = filters.NumberFilter(
        field_name="inventory_outbound_fill_rate", lookup_expr="gte"
    )
    outbound_fill_rate_max = filters.NumberFilter(
        field_name="inventory_outbound_fill_rate", lookup_expr="lte"
    )
    low_inventory_dcs_min = filters.NumberFilter(field_name="low_inventory_dcs", lookup_expr="gte")
    low_inventory_dcs_max = filters.NumberFilter(field_name="low_inventory_dcs", lookup_expr="lte")
    acceptable_inventory_dcs_min = filters.NumberFilter(field_name="acceptable_inventory_dcs", lookup_expr="gte")
    acceptable_inventory_dcs_max = filters.NumberFilter(field_name="acceptable_inventory_dcs", lookup_expr="lte")
    overstock_inventory_dcs_min = filters.NumberFilter(field_name="overstock_inventory_dcs", lookup_expr="gte")
    overstock_inventory_dcs_max = filters.NumberFilter(field_name="overstock_inventory_dcs", lookup_expr="lte")

    class Meta:
        model = Material
        fields = []


class MaterialsInventoryPostFilter(FilterSet):
    """
    Post-annotation filters for All Products inventory list.

    Global material filters are applied in the base queryset via
    get_filtered_material_subquery(). This filter set intentionally avoids
    re-applying global relational filters to keep list queries efficient.
    """

    material_status = filters.CharFilter(field_name="material_status", lookup_expr="iexact")

    days_on_hand_min = filters.NumberFilter(field_name="days_on_hand", lookup_expr="gte")
    days_on_hand_max = filters.NumberFilter(field_name="days_on_hand", lookup_expr="lte")
    days_on_order_min = filters.NumberFilter(field_name="days_on_order", lookup_expr="gte")
    days_on_order_max = filters.NumberFilter(field_name="days_on_order", lookup_expr="lte")
    units_on_hand_min = filters.NumberFilter(field_name="units_on_hand", lookup_expr="gte")
    units_on_hand_max = filters.NumberFilter(field_name="units_on_hand", lookup_expr="lte")
    units_on_order_min = filters.NumberFilter(field_name="units_on_order", lookup_expr="gte")
    units_on_order_max = filters.NumberFilter(field_name="units_on_order", lookup_expr="lte")
    outbound_fill_rate_min = filters.NumberFilter(
        field_name="inventory_outbound_fill_rate", lookup_expr="gte"
    )
    outbound_fill_rate_max = filters.NumberFilter(
        field_name="inventory_outbound_fill_rate", lookup_expr="lte"
    )
    low_inventory_dcs_min = filters.NumberFilter(field_name="low_inventory_dcs", lookup_expr="gte")
    low_inventory_dcs_max = filters.NumberFilter(field_name="low_inventory_dcs", lookup_expr="lte")
    acceptable_inventory_dcs_min = filters.NumberFilter(field_name="acceptable_inventory_dcs", lookup_expr="gte")
    acceptable_inventory_dcs_max = filters.NumberFilter(field_name="acceptable_inventory_dcs", lookup_expr="lte")
    overstock_inventory_dcs_min = filters.NumberFilter(field_name="overstock_inventory_dcs", lookup_expr="gte")
    overstock_inventory_dcs_max = filters.NumberFilter(field_name="overstock_inventory_dcs", lookup_expr="lte")

    class Meta:
        model = Material
        fields = []


class MaterialPlantsSummaryFilter(FilterSet):
    """
    Filter set for material plants summary endpoint.
    Note: This endpoint is for a specific material (mat_nbr in URL path),
    so global material filters are not applied here. Only date and plant filters.
    """

    # Date filters
    date_from = filters.DateFilter(field_name='demand_date', lookup_expr='gte')
    date_to = filters.DateFilter(field_name='demand_date', lookup_expr='lte')
    plant_nbr = filters.CharFilter(field_name='plant', lookup_expr='exact')

    class Meta:
        model = DemandForecast
        fields = []


class WeeklySupplySnapshotFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """
    Filter set for weekly supply snapshot endpoint.
    Supports global filters for material-related fields.
    """

    # Material filters (for exact matching)
    # Note: 'material' filter is overridden to filter by mat_nbr (string) instead of material_id (number)
    # This matches the frontend behavior where material=0424853774 is sent as mat_nbr
    material = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='exact')
    mat_nbr = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='exact')
    material_id = filters.NumberFilter(field_name='material__id', lookup_expr='exact')

    # Plant filters
    plant = filters.NumberFilter(field_name='plant__id', lookup_expr='exact')
    plant_nbr = filters.CharFilter(field_name='plant__plant_nbr', lookup_expr='exact')

    class Meta:
        model = DemandForecast
        fields = []


class WeeklyPerformanceFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """
    Filter set for weekly performance endpoint.
    Supports global filters for material-related fields.
    """

    # Material filters (for exact matching)
    # Note: 'material' filter is overridden to filter by mat_nbr (string) instead of material_id (number)
    # This matches the frontend behavior where material=0424853774 is sent as mat_nbr
    material = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='exact')
    mat_nbr = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='exact')
    material_id = filters.NumberFilter(field_name='material__id', lookup_expr='exact')

    # Plant filters
    plant = filters.NumberFilter(field_name='plant__id', lookup_expr='exact')
    plant_nbr = filters.CharFilter(field_name='plant__plant_nbr', lookup_expr='exact')

    class Meta:
        model = DemandForecast
        fields = []


class WeeklyTransfersFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """
    Filter set for weekly transfers endpoint.
    Supports global filters for material-related fields.
    """

    # Material filters (for exact matching)
    # Note: 'material' filter is overridden to filter by mat_nbr (string) instead of material_id (number)
    # This matches the frontend behavior where material=0424853774 is sent as mat_nbr
    material = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='exact')
    mat_nbr = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='exact')
    material_id = filters.NumberFilter(field_name='material__id', lookup_expr='exact')

    # Plant filters
    plant = filters.NumberFilter(field_name='plant__id', lookup_expr='exact')
    plant_nbr = filters.CharFilter(field_name='plant__plant_nbr', lookup_expr='exact')

    class Meta:
        model = DemandForecast
        fields = []


class WeeklyMaterialForecastComparisonFilter(FilterSet):
    """
    Filter set for fixed-window material forecast comparison.
    Filters target annotated fields on the aggregated queryset returned by the service.
    """

    forecast_this_week_min = filters.NumberFilter(field_name="forecast_this_week", lookup_expr="gte")
    forecast_this_week_max = filters.NumberFilter(field_name="forecast_this_week", lookup_expr="lte")
    forecast_last_week_min = filters.NumberFilter(field_name="forecast_last_week", lookup_expr="gte")
    forecast_last_week_max = filters.NumberFilter(field_name="forecast_last_week", lookup_expr="lte")
    forecast_this_month_min = filters.NumberFilter(field_name="forecast_this_month", lookup_expr="gte")
    forecast_this_month_max = filters.NumberFilter(field_name="forecast_this_month", lookup_expr="lte")
    forecast_last_month_min = filters.NumberFilter(field_name="forecast_last_month", lookup_expr="gte")
    forecast_last_month_max = filters.NumberFilter(field_name="forecast_last_month", lookup_expr="lte")
    wow_change_min = filters.NumberFilter(field_name="wow_change", lookup_expr="gte")
    wow_change_max = filters.NumberFilter(field_name="wow_change", lookup_expr="lte")
    wow_change_pct_min = filters.NumberFilter(field_name="wow_change_pct", lookup_expr="gte")
    wow_change_pct_max = filters.NumberFilter(field_name="wow_change_pct", lookup_expr="lte")
    mom_change_min = filters.NumberFilter(field_name="mom_change", lookup_expr="gte")
    mom_change_max = filters.NumberFilter(field_name="mom_change", lookup_expr="lte")
    mom_change_pct_min = filters.NumberFilter(field_name="mom_change_pct", lookup_expr="gte")
    mom_change_pct_max = filters.NumberFilter(field_name="mom_change_pct", lookup_expr="lte")
    days_on_hand_min = filters.NumberFilter(field_name="days_on_hand", lookup_expr="gte")
    days_on_hand_max = filters.NumberFilter(field_name="days_on_hand", lookup_expr="lte")

    class Meta:
        model = DemandForecast
        fields = []
