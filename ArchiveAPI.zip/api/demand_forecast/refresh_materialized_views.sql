-- ============================================================================
-- Refresh Commands
-- ============================================================================
REFRESH MATERIALIZED VIEW CONCURRENTLY demand_forecast_inventory_bands_weekly_mv;
REFRESH MATERIALIZED VIEW CONCURRENTLY demand_forecast_inventory_bands_total_mv;
REFRESH MATERIALIZED VIEW CONCURRENTLY demand_forecast_weekly_material_mv;
REFRESH MATERIALIZED VIEW CONCURRENTLY demand_forecast_material_plant_mv;
