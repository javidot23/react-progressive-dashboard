from rest_framework import serializers

from api.demand_forecast.models import DemandForecast
from api.plant.serializers import PlantSerializer, Neo4jPlantSerializer


class DemandForecastSerializer(serializers.ModelSerializer):
    class Meta:
        model = DemandForecast
        fields = "__all__"


class MaterialInventoryBandPeriodQuerySerializer(serializers.Serializer):
    """
    Serializer for service level period query parameters.
    """

    start_date = serializers.DateField(required=True)
    end_date = serializers.DateField(required=True)


class MaterialInventoryBandSerializer(serializers.Serializer):
    low = serializers.IntegerField()
    acceptable = serializers.IntegerField()
    overstock = serializers.IntegerField()
    no_forecast = serializers.IntegerField()
    daily = serializers.DictField()


class MonthlyBandItemSerializer(serializers.Serializer):
    month = serializers.CharField()
    month_num = serializers.IntegerField()
    low = serializers.IntegerField()
    acceptable = serializers.IntegerField()
    overstock = serializers.IntegerField()
    no_forecast = serializers.IntegerField()


class MonthlyMaterialInventoryBandSerializer(serializers.Serializer):
    low = serializers.IntegerField()
    acceptable = serializers.IntegerField()
    overstock = serializers.IntegerField()
    no_forecast = serializers.IntegerField()
    monthly = serializers.ListField(child=MonthlyBandItemSerializer())


class WeeklyBandItemSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    week_end = serializers.DateField()
    low = serializers.IntegerField()
    acceptable = serializers.IntegerField()
    overstock = serializers.IntegerField()
    no_forecast = serializers.IntegerField()


class MaterialInventoryWeeklyBandSerializer(serializers.Serializer):
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    low = serializers.IntegerField()
    acceptable = serializers.IntegerField()
    overstock = serializers.IntegerField()
    no_forecast = serializers.IntegerField()
    average_doh = serializers.FloatField(allow_null=True)
    weekly = serializers.ListField(child=WeeklyBandItemSerializer())


class MaterialInventoryOnEachPlantSerializer(serializers.ModelSerializer):
    plant = PlantSerializer()

    class Meta:
        model = DemandForecast
        fields = '__all__'


class WeeklyDemandForecastItemSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    week_end = serializers.DateField()
    demand_qty = serializers.IntegerField()  # Represents demand_7day, not qty_ordered
    forecast_qty = serializers.IntegerField()


class WeeklyForecastGroupItemSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    week_end = serializers.DateField()
    low_forecast_percentage = serializers.FloatField()
    medium_forecast_percentage = serializers.FloatField()
    high_forecast_percentage = serializers.FloatField()
    very_high_forecast_percentage = serializers.FloatField()
    total_materials = serializers.IntegerField()


# New serializers for the required endpoints

class MaterialsLowInventorySerializer(serializers.Serializer):
    """Serializer for materials with stocking-DC count and outbound fill rate."""
    material_id = serializers.IntegerField(source='material__id')
    mat_nbr = serializers.CharField(source='material__mat_nbr')
    ndc = serializers.CharField(source='material__ndc', allow_null=True)
    material_description = serializers.CharField(source='material__name')
    material_status = serializers.CharField(source='material__xplant_mat_stat', allow_null=True)
    dc_count = serializers.IntegerField()
    plants_no_stock = serializers.IntegerField()
    plants_stockout = serializers.IntegerField()
    plants_in_range = serializers.IntegerField()
    plants_overstock = serializers.IntegerField()
    outbound_fill_rate = serializers.DecimalField(max_digits=10, decimal_places=4, allow_null=True)
    doh_days = serializers.DecimalField(max_digits=10, decimal_places=1, allow_null=True)
    doo_days = serializers.DecimalField(max_digits=10, decimal_places=1, allow_null=True)

    def to_representation(self, instance):
        """Round outbound_fill_rate to 4 decimal places, and DOH/DOO to 1 decimal place."""
        data = super().to_representation(instance)
        if data['outbound_fill_rate'] is not None:
            data['outbound_fill_rate'] = round(float(data['outbound_fill_rate']), 4)
        if data['doh_days'] is not None:
            data['doh_days'] = round(float(data['doh_days']), 1)
        if data['doo_days'] is not None:
            data['doo_days'] = round(float(data['doo_days']), 1)
        return data


class MaterialsInventorySerializer(serializers.Serializer):
    """All-products inventory row for the FE materials inventory table."""

    material_number = serializers.CharField(allow_null=True)
    material_name = serializers.CharField(allow_null=True)
    ndc = serializers.CharField(allow_null=True)
    days_on_hand = serializers.FloatField(allow_null=True)
    units_on_hand = serializers.IntegerField(allow_null=True)
    units_on_order = serializers.IntegerField(allow_null=True)
    days_on_order = serializers.FloatField(allow_null=True)
    next_inbound_order_quantity = serializers.IntegerField(allow_null=True)
    forecast_qty_28day = serializers.IntegerField(allow_null=True)
    next_expected_arrival_date = serializers.DateField(allow_null=True)
    low_inventory_dcs = serializers.IntegerField(allow_null=True)
    acceptable_inventory_dcs = serializers.IntegerField(allow_null=True)
    overstock_inventory_dcs = serializers.IntegerField(allow_null=True)
    outbound_fill_rate = serializers.FloatField(
        source="inventory_outbound_fill_rate", allow_null=True
    )
    formulary = serializers.ListField(
        child=serializers.CharField(allow_null=True),
        allow_empty=True,
        required=False,
    )
    material_status = serializers.CharField(allow_null=True)

    class Meta:
        ref_name = "DemandForecastMaterialsInventory"

    def to_representation(self, instance):
        data = super().to_representation(instance)
        if data.get("outbound_fill_rate") is not None:
            data["outbound_fill_rate"] = round(float(data["outbound_fill_rate"]), 4)
        if data.get("days_on_hand") is not None:
            data["days_on_hand"] = round(float(data["days_on_hand"]), 1)
        if data.get("days_on_order") is not None:
            data["days_on_order"] = round(float(data["days_on_order"]), 1)
        return data


class MaterialPlantsSummarySerializer(serializers.Serializer):
    """Serializer for plants summary for a given material."""
    plant_id = serializers.IntegerField(source='plant__id')
    plant_nbr = serializers.CharField(source='plant__plant_nbr')
    plant_name = serializers.CharField(source='plant__name', allow_null=True)
    saleable_qty_on_hand_latest = serializers.IntegerField(allow_null=True)
    unrestricted_qty_on_hand_latest = serializers.IntegerField(allow_null=True)
    qty_ordered_sum = serializers.IntegerField()
    shipped_qty_sum = serializers.IntegerField()
    received_qty_sum = serializers.IntegerField()
    on_order_qty_sum = serializers.IntegerField()
    transfer_in_qty_sum = serializers.IntegerField()
    transfer_out_qty_sum = serializers.IntegerField()
    outbound_fill_rate = serializers.DecimalField(max_digits=10, decimal_places=4, allow_null=True)
    forecast_28day = serializers.IntegerField(allow_null=True)
    doh_days = serializers.DecimalField(max_digits=10, decimal_places=1, allow_null=True)

    def to_representation(self, instance):
        """Round outbound_fill_rate to 4 decimal places."""
        data = super().to_representation(instance)
        if data['outbound_fill_rate'] is not None:
            data['outbound_fill_rate'] = round(float(data['outbound_fill_rate']), 4)
        return data


class WeeklySupplySnapshotSerializer(serializers.Serializer):
    """Serializer for weekly supply snapshot."""
    week_start = serializers.DateField()
    on_hand_qty = serializers.IntegerField()
    on_order_qty = serializers.IntegerField()
    transfer_in_qty = serializers.IntegerField()
    transfer_out_qty = serializers.IntegerField()
    received_qty = serializers.IntegerField()
    sold_qty = serializers.IntegerField()
    omit_qty = serializers.IntegerField()
    forecast_7day_week = serializers.IntegerField(allow_null=True)
    forecast_28day = serializers.IntegerField(allow_null=True)
    doh_days = serializers.DecimalField(max_digits=10, decimal_places=1, allow_null=True)
    doo_days = serializers.DecimalField(max_digits=10, decimal_places=1, allow_null=True)

    def to_representation(self, instance):
        """Round DOH and DOO to 1 decimal place, and forecast fields to integers."""
        data = super().to_representation(instance)
        if data['forecast_7day_week'] is not None:
            data['forecast_7day_week'] = int(round(float(data['forecast_7day_week'])))
        if data['forecast_28day'] is not None:
            data['forecast_28day'] = int(round(float(data['forecast_28day'])))
        if data['doh_days'] is not None:
            data['doh_days'] = round(float(data['doh_days']), 1)
        if data['doo_days'] is not None:
            data['doo_days'] = round(float(data['doo_days']), 1)
        return data


class WeeklyPerformanceSerializer(serializers.Serializer):
    """Serializer for weekly inbound/outbound performance."""
    week_start = serializers.DateField()
    inbound_fill_rate = serializers.DecimalField(max_digits=10, decimal_places=4, allow_null=True)
    outbound_fill_rate = serializers.DecimalField(max_digits=10, decimal_places=4, allow_null=True)
    received_qty = serializers.IntegerField()
    forecast_7day = serializers.IntegerField(source='forecast_7day_week', allow_null=True)

    def to_representation(self, instance):
        """Round fill rates to 4 decimal places and forecast to integer."""
        data = super().to_representation(instance)
        if data['inbound_fill_rate'] is not None:
            data['inbound_fill_rate'] = round(float(data['inbound_fill_rate']), 4)
        if data['outbound_fill_rate'] is not None:
            data['outbound_fill_rate'] = round(float(data['outbound_fill_rate']), 4)
        if data['forecast_7day'] is not None:
            data['forecast_7day'] = round(float(data['forecast_7day']))
        return data


class WeeklyTransfersSerializer(serializers.Serializer):
    """Serializer for weekly transfers."""
    week_start = serializers.DateField()
    transfer_in_qty = serializers.IntegerField()
    transfer_out_qty = serializers.IntegerField()


class WeeklyMaterialForecastComparisonSerializer(serializers.Serializer):
    """Fixed-window forecast comparison per material (this/last week + this/last month)."""
    mat_nbr = serializers.CharField(source="material")
    material_name = serializers.CharField(allow_null=True)
    ndc = serializers.CharField(allow_null=True)
    material_status = serializers.CharField(allow_null=True)
    formulary = serializers.ListField(
        child=serializers.CharField(allow_null=True),
        allow_empty=True,
        required=False,
    )
    forecast_this_week = serializers.IntegerField()
    forecast_last_week = serializers.IntegerField()
    forecast_this_month = serializers.IntegerField()
    forecast_last_month = serializers.IntegerField()
    wow_change = serializers.IntegerField()
    wow_change_pct = serializers.FloatField(allow_null=True)
    mom_change = serializers.IntegerField()
    mom_change_pct = serializers.FloatField(allow_null=True)
    saleable_qty_on_hand = serializers.IntegerField(allow_null=True)
    days_on_hand = serializers.FloatField(allow_null=True)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        if data.get("days_on_hand") is not None:
            data["days_on_hand"] = round(float(data["days_on_hand"]), 1)
        return data


class ForecastChangeKpisSerializer(serializers.Serializer):
    prxo_count = serializers.IntegerField()
    pharmagen_count = serializers.IntegerField()


class Neo4jMaterialInventorySerializer(serializers.Serializer):
    """
    Serializer for material inventory data per plant from Neo4j.
    """
    plant = Neo4jPlantSerializer()
    demand_date = serializers.DateField()
    saleable_qty_on_hand = serializers.IntegerField()
    unrestricted_qty_on_hand = serializers.IntegerField()
    forecast_qty_7day = serializers.IntegerField()
    qty_ordered = serializers.IntegerField()
    shipped_qty = serializers.IntegerField()
    received_qty = serializers.IntegerField()
    on_order_qty = serializers.IntegerField()
    transfer_in_qty = serializers.IntegerField()
    transfer_out_qty = serializers.IntegerField()
    plant_nbr = serializers.CharField(allow_null=True)


class MaterialForecastPeriodSerializer(serializers.Serializer):
    week = serializers.DateField()
    sales_28d_prior = serializers.IntegerField(allow_null=True)
    forecast_28d_prior = serializers.IntegerField(allow_null=True)
    shipped_qty_28d_prior = serializers.IntegerField(allow_null=True)


class MaterialForecastFormularySerializer(serializers.Serializer):
    id = serializers.IntegerField()
    parent_program = serializers.CharField(allow_null=True)
    program = serializers.CharField(allow_null=True)
    contract_number = serializers.CharField(allow_null=True)
    sales_group = serializers.CharField(allow_null=True)


class MaterialForecastDetailSerializer(serializers.Serializer):
    formularies = MaterialForecastFormularySerializer(many=True)
    current_period = MaterialForecastPeriodSerializer()
    previous_period = MaterialForecastPeriodSerializer()
