from django.db import models

from api.material.models import Material
from api.plant.models import Plant


class DemandForecastInventoryBandsWeeklyMV(models.Model):
    """
    Weekly aggregated data for last 90 days - serves multiple endpoints.
    Materialized view: demand_forecast_inventory_bands_weekly_mv

    Inventory band counts:
    - Low: 0-10 days on hand (DOH)
    - Acceptable: 11-60 DOH
    - Overstock: 61+ DOH
    - No Forecast: forecast_qty_7day = 0
    """
    week_start = models.DateField(primary_key=True)
    # Inventory band counts
    low_count = models.IntegerField()
    acceptable_count = models.IntegerField()
    overstock_count = models.IntegerField()
    no_forecast_count = models.IntegerField()
    # Weekly totals for all fields
    total_qty_ordered = models.BigIntegerField()
    total_forecast_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_received_qty = models.BigIntegerField()
    total_qty_ordered_alt_serve = models.BigIntegerField()
    total_demand_7day = models.BigIntegerField()
    total_on_order_qty = models.BigIntegerField()
    total_transfer_in_qty = models.BigIntegerField()
    total_transfer_out_qty = models.BigIntegerField()
    total_inbound_qty_ordered = models.BigIntegerField()
    total_saleable_qty_on_hand = models.BigIntegerField()
    total_unrestricted_qty_on_hand = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = "demand_forecast_inventory_bands_weekly_mv"
        ordering = ['week_start']


class DemandForecastInventoryBandsTotalMV(models.Model):
    """
    Total inventory band counts for last 90 days.
    Materialized view: demand_forecast_inventory_bands_total_mv
    """
    id = models.IntegerField(primary_key=True)  # Dummy ID for Django ORM
    start_date = models.DateField()
    end_date = models.DateField()
    low_count = models.IntegerField()
    acceptable_count = models.IntegerField()
    overstock_count = models.IntegerField()
    no_forecast_count = models.IntegerField()
    avg_doh = models.FloatField(null=True)  # Average days on hand for all materials

    class Meta:
        managed = False
        db_table = "demand_forecast_inventory_bands_total_mv"


class DemandForecastWeeklyMaterialMV(models.Model):
    """
    Weekly aggregated data per material for last 90 days.
    Materialized view: demand_forecast_weekly_material_mv
    """
    id = models.BigIntegerField(primary_key=True)
    week_start = models.DateField()
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="material",
        on_delete=models.DO_NOTHING,
        related_name='+'  # Disable reverse relation
    )
    total_forecast = models.BigIntegerField()
    total_qty_ordered = models.BigIntegerField()
    total_qty_ordered_alt_serve = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = "demand_forecast_weekly_material_mv"
        ordering = ['week_start', 'material']


class DemandForecastMaterialPlantMV(models.Model):
    """
    Aggregated data per material and plant for last 90 days.
    Materialized view: demand_forecast_material_plant_mv
    Used by MaterialsLowInventoryView for fast queries without date filtering.
    """
    id = models.BigIntegerField(primary_key=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="material",
        on_delete=models.DO_NOTHING,
        related_name='+'  # Disable reverse relation
    )
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant",
        on_delete=models.DO_NOTHING,
        related_name='+'  # Disable reverse relation
    )
    total_shipped_qty = models.BigIntegerField()
    total_qty_ordered = models.BigIntegerField()
    latest_saleable_qty_on_hand = models.IntegerField(null=True)
    latest_on_order_qty = models.IntegerField(null=True)
    latest_forecast_qty_7day = models.IntegerField(null=True)

    class Meta:
        managed = False
        db_table = "demand_forecast_material_plant_mv"
        ordering = ['material', 'plant']
