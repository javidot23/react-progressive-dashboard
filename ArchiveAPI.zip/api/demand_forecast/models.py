from django.db import models

from api.material.models import Material
from api.plant.models import Plant


class DemandForecast(models.Model):
    demand_date = models.DateField(blank=True, null=True)
    forecast_qty_7day = models.IntegerField(blank=True, null=True)
    saleable_qty_on_hand = models.IntegerField(default=0, blank=True, null=True)
    unrestricted_qty_on_hand = models.IntegerField(default=0, blank=True, null=True)
    qty_ordered = models.IntegerField(default=0, blank=True, null=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
    )
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.CASCADE
    )
    qty_ordered_alt_serve = models.IntegerField(default=0, blank=True, null=True)
    demand_7day = models.IntegerField(default=0, blank=True, null=True)
    on_order_qty = models.IntegerField(default=0, blank=True, null=True)
    transfer_in_qty = models.IntegerField(default=0, blank=True, null=True)
    transfer_out_qty = models.IntegerField(default=0, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    received_qty = models.IntegerField(default=0, blank=True, null=True)
    inbound_qty_ordered = models.IntegerField(default=0, blank=True, null=True)
    shipped_qty = models.IntegerField(default=0, blank=True, null=True)
    mat_plant_stat = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = "demand_forecast"
        verbose_name = "Demand Forecast"
        verbose_name_plural = "Demand Forecasts"
        indexes = [
            models.Index(fields=["demand_date"]),
            models.Index(fields=["material"]),
            models.Index(fields=["plant"]),
            models.Index(fields=["material", "qty_ordered"]),
            models.Index(fields=["material", "forecast_qty_7day"]),
            models.Index(fields=["material", "saleable_qty_on_hand"]),
            models.Index(fields=["material", "unrestricted_qty_on_hand"]),
            models.Index(fields=["material", "plant"])
        ]
        unique_together = (
            "demand_date",
            "material",
            "plant"
        )
