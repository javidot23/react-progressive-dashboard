import logging

from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, status
from rest_framework.exceptions import ValidationError
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema, extend_schema_view

from api.demand_forecast.filters import (
    MaterialsLowInventoryAggregatedFilter,
    MaterialsLowInventoryFilter,
    MaterialsInventoryFilter,
    MaterialPlantsSummaryFilter,
    WeeklyMaterialForecastComparisonFilter,
    WeeklyTransfersFilter
)
from api.demand_forecast.materialized_view_models import (
    DemandForecastInventoryBandsWeeklyMV,
    DemandForecastMaterialPlantMV,
)
from api.demand_forecast.models import DemandForecast
from api.demand_forecast.serializers import (
    MonthlyMaterialInventoryBandSerializer,
    MaterialInventoryOnEachPlantSerializer,
    MaterialInventoryWeeklyBandSerializer,
    WeeklyDemandForecastItemSerializer,
    WeeklyForecastGroupItemSerializer,
    MaterialsLowInventorySerializer,
    MaterialsInventorySerializer,
    MaterialPlantsSummarySerializer,
    WeeklySupplySnapshotSerializer,
    WeeklyPerformanceSerializer,
    WeeklyTransfersSerializer,
    Neo4jMaterialInventorySerializer,
    WeeklyMaterialForecastComparisonSerializer,
    ForecastChangeKpisSerializer,
    MaterialForecastDetailSerializer,
)
from api.demand_forecast.services import DemandForecastService
from api.global_filters import get_filtered_material_subquery
from api.material.models import Material
from api.material_formulary.services import MaterialFormularyService
from api.neo4j_graph_api.exceptions import Neo4jConnectionError, Neo4jQueryError
from api.neo4j_graph_api.services import Neo4jGraphService
from api.pagination import MaxLimitOffsetPagination

logger = logging.getLogger(__name__)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialInventoryBandView(APIView):
    """
    Returns inventory band counts for materials for last 90 days aggregated per week.
    Supports global filters.
    """

    @extend_schema(responses=MaterialInventoryWeeklyBandSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = DemandForecastService.get_materials_in_each_inventory_band_last_90_days_weekly(
            direct_mat_nbr, mat_nbr_subquery
        )
        serializer = MaterialInventoryWeeklyBandSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialInventoryBandThisYearView(APIView):
    """
    Returns inventory band counts for materials for the current year.
    Supports global filters.
    """

    @extend_schema(responses=MonthlyMaterialInventoryBandSerializer)
    def get(self, request):
        from api.global_filters import extract_global_filter_params
        filter_params = extract_global_filter_params(request)
        data = DemandForecastService.get_materials_in_each_inventory_band_this_year(filter_params)
        serializer = MonthlyMaterialInventoryBandSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialInventoryOnEachPlantView(generics.ListAPIView):
    """Returns inventory on each plant for a specific material."""

    serializer_class = MaterialInventoryOnEachPlantSerializer
    pagination_class = None

    def get_queryset(self):
        material_id = self.kwargs.get('material_id')
        return DemandForecastService.get_material_inventory_on_each_plant(material_id)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class Neo4jMaterialInventoryOnEachPlantView(APIView):
    """
    Returns inventory on each plant for a specific material from Neo4j.
    """

    @extend_schema(responses=Neo4jMaterialInventorySerializer(many=True))
    def get(self, request, material_id):
        """Retrieve material inventory across all plants from Neo4j."""
        try:
            # Convert material_id to mat_nbr
            try:
                mat_nbr = Material.objects.get(mat_nbr=material_id).mat_nbr
            except Material.DoesNotExist:
                return Response(
                    {
                        "success": False,
                        "error": f"Material with mat_nbr {material_id!r} not found"
                    },
                    status=status.HTTP_404_NOT_FOUND
                )

            # Get data from Neo4j
            data = Neo4jGraphService.get_material_inventory_on_each_plant(mat_nbr=mat_nbr)

            serializer = Neo4jMaterialInventorySerializer(data, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except (Neo4jConnectionError, Neo4jQueryError) as e:
            logger.error(f"Neo4j error in Neo4jMaterialInventoryOnEachPlantView: {str(e)}")
            return Response(
                {
                    "success": False,
                    "error": "Neo4j service is temporarily unavailable."
                },
                status=status.HTTP_503_SERVICE_UNAVAILABLE
            )
        except Exception as e:
            logger.error(f"Unexpected error in Neo4jMaterialInventoryOnEachPlantView: {str(e)}")
            return Response(
                {
                    "success": False,
                    "error": "An unexpected error occurred while retrieving material inventory."
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyDemandForecastView(APIView):
    """
    Returns weekly aggregated demand forecast data for the latest 90 days.
    Supports global filters.
    """

    @extend_schema(responses=WeeklyDemandForecastItemSerializer(many=True))
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = DemandForecastService.get_weekly_demand_forecast_last_90_days(
            direct_mat_nbr, mat_nbr_subquery
        )
        serializer = WeeklyDemandForecastItemSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyForecastGroupsView(APIView):
    """
    Returns weekly percentages of materials grouped by forecast quantity ranges
    for the last 90 days (alt-served materials only).
    Supports global filters.
    """

    @extend_schema(responses=WeeklyForecastGroupItemSerializer(many=True))
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = DemandForecastService.get_weekly_forecast_groups_last_90_days(
            direct_mat_nbr, mat_nbr_subquery
        )
        serializer = WeeklyForecastGroupItemSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialsLowInventoryView(generics.ListAPIView):
    """
    GET /demand-forecast/materials-low-inventory/

    Returns materials with stocking-DC count, outbound fill rate, days on hand, and days on order.
    Supports global filters.

    Query params:
      - range_low / range_high: DOH zone thresholds for per-plant zone counts (defaults: 25, 35)
      - dc_min / dc_max: range filter on dc_count
      - outbound_fill_rate_min / outbound_fill_rate_max: range filter on outbound_fill_rate
      - doh_days_min / doh_days_max: range filter on doh_days
      - doo_days_min / doo_days_max: range filter on doo_days
      - ordering: sort field (prefix with - for descending), e.g. -plants_stockout
    """
    serializer_class = MaterialsLowInventorySerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialsLowInventoryFilter
    ordering_fields = [
        'dc_count', 'outbound_fill_rate', 'material__mat_nbr', 'doh_days', 'doo_days',
        'plants_no_stock', 'plants_stockout', 'plants_in_range', 'plants_overstock',
    ]
    ordering = ['-dc_count']

    def get_queryset(self):
        """Get queryset based on query parameters."""
        if getattr(self, "swagger_fake_view", False):
            return DemandForecastMaterialPlantMV.objects.none()

        base_queryset = DemandForecastMaterialPlantMV.objects.all()
        filterset = self.filterset_class(self.request.GET, queryset=base_queryset)
        if not filterset.is_valid():
            raise ValidationError(filterset.errors)

        range_low, range_high = self._parse_doh_range_thresholds()

        # Get the filtered queryset from filterset and aggregate
        aggregated_queryset = DemandForecastService.get_materials_low_inventory(
            queryset=filterset.qs,
            range_low=range_low,
            range_high=range_high,
        )

        aggregated_filterset = MaterialsLowInventoryAggregatedFilter(
            self.request.GET, queryset=aggregated_queryset
        )
        if not aggregated_filterset.is_valid():
            raise ValidationError(aggregated_filterset.errors)
        aggregated_queryset = aggregated_filterset.qs

        return aggregated_queryset

    def filter_queryset(self, queryset):
        """
        Apply ordering only; pre/post-aggregation filters are handled in get_queryset().
        """
        return OrderingFilter().filter_queryset(self.request, queryset, self)

    def _parse_doh_range_thresholds(self):
        """Parse and validate range_low / range_high from the current request."""
        range_low = self._parse_threshold_param('range_low', 25)
        range_high = self._parse_threshold_param('range_high', 35)
        if range_low >= range_high:
            raise ValidationError({'range_low': 'range_low must be less than range_high.'})
        return range_low, range_high

    def _parse_threshold_param(self, param_name, default):
        """Parse a numeric threshold query param, falling back to default on missing value."""
        raw = self.request.query_params.get(param_name)
        if raw is None:
            return default
        try:
            return float(raw)
        except (TypeError, ValueError):
            raise ValidationError({param_name: f'{param_name} must be a number.'})


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
@extend_schema_view(get=extend_schema(operation_id='api_demand_forecast_materials_inventory_list'))
class MaterialsInventoryView(generics.ListAPIView):
    """
    All Products inventory list: every material with DF/PO/formulary enrichment.
    Reuses MaterialsLowInventory DOH/DOO/fill-rate and plant-zone formulas.
    low_inventory_dcs = plants_no_stock + plants_stockout.

    Query params:
      - range_low / range_high: DOH zone thresholds (defaults: 25, 35)
      - global material filters, ordering, pagination
    """
    serializer_class = MaterialsInventorySerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialsInventoryFilter
    ordering_fields = [
        'material_number',
        'material_name',
        'ndc',
        'days_on_hand',
        'units_on_hand',
        'units_on_order',
        'days_on_order',
        'next_inbound_order_quantity',
        'forecast_qty_28day',
        'next_expected_arrival_date',
        'low_inventory_dcs',
        'acceptable_inventory_dcs',
        'overstock_inventory_dcs',
        'inventory_outbound_fill_rate',
        'outbound_fill_rate',
        'material_status',
    ]
    ordering = ['-units_on_hand', 'material_number']

    def filter_queryset(self, queryset):
        ordering = self.request.query_params.get('ordering', '')
        if ordering in ('outbound_fill_rate', '-outbound_fill_rate'):
            mutable = self.request.query_params.copy()
            mutable['ordering'] = ordering.replace(
                'outbound_fill_rate', 'inventory_outbound_fill_rate'
            )
            self.request._request.GET = mutable
        return super().filter_queryset(queryset)

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return Material.objects.none()

        range_low, range_high = self._parse_doh_range_thresholds()
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return DemandForecastService.list_materials_inventory(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            range_low=range_low,
            range_high=range_high,
        )

    def _parse_doh_range_thresholds(self):
        range_low = self._parse_threshold_param('range_low', 25)
        range_high = self._parse_threshold_param('range_high', 35)
        if range_low >= range_high:
            raise ValidationError({'range_low': 'range_low must be less than range_high.'})
        return range_low, range_high

    def _parse_threshold_param(self, param_name, default):
        raw = self.request.query_params.get(param_name)
        if raw is None:
            return default
        try:
            return float(raw)
        except (TypeError, ValueError):
            raise ValidationError({param_name: f'{param_name} must be a number.'})


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialPlantsSummaryView(generics.ListAPIView):
    """
    GET /demand-forecast/materials/{mat_nbr}/plants/

    Returns plants summary for a given material.
    """
    serializer_class = MaterialPlantsSummarySerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialPlantsSummaryFilter
    ordering_fields = [
        'outbound_fill_rate',
        'plant__plant_nbr',
        'saleable_qty_on_hand_latest',
        'unrestricted_qty_on_hand_latest',
        'qty_ordered_sum',
        'qty_ordered_sum',
        'received_qty_sum',
        'on_order_qty_sum',
        'transfer_in_qty_sum',
        'transfer_out_qty_sum',
        'outbound_fill_rate'
    ]
    ordering = ['-outbound_fill_rate']

    def get_queryset(self):
        """Get queryset based on path parameter and query parameters."""
        mat_nbr = self.kwargs.get('mat_nbr')

        # Get parameters from filters
        filterset = self.filterset_class(self.request.GET, queryset=DemandForecast.objects.all())
        if not filterset.is_valid():
            raise ValidationError(filterset.errors)

        # Extract filter values
        date_from = filterset.data.get('date_from')
        date_to = filterset.data.get('date_to')

        # Get ordering
        ordering = self.request.query_params.get('ordering', '-outbound_fill_rate')

        return DemandForecastService.get_material_plants_summary(
            mat_nbr=mat_nbr,
            date_from=date_from,
            date_to=date_to,
            ordering=ordering
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class WeeklySupplySnapshotView(generics.ListAPIView):
    """
    GET /demand-forecast/weekly-supply/

    Returns weekly supply snapshot for the last 90 days.
    Supports global filters for material-related fields.
    Results are ordered by week_start ascending for chart display.
    """
    serializer_class = WeeklySupplySnapshotSerializer
    pagination_class = None

    def get_queryset(self):
        """Get queryset with global filters applied using optimized subquery."""
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return DemandForecastService.get_weekly_supply_snapshot(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class WeeklyPerformanceView(generics.ListAPIView):
    """
    Returns weekly inbound/outbound performance for the last 90 days.
    Supports global filters for material-related fields.
    Results are ordered by week_start ascending for chart display.
    """
    serializer_class = WeeklyPerformanceSerializer
    pagination_class = None

    def get_queryset(self):
        """Get queryset with global filters applied using optimized subquery."""
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return DemandForecastService.get_weekly_performance(direct_mat_nbr, mat_nbr_subquery)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class WeeklyTransfersView(generics.ListAPIView):
    """
    GET /demand-forecast/weekly-transfers/

    Returns weekly transfers for the last 90 days.
    Supports global filters.
    """
    serializer_class = WeeklyTransfersSerializer
    pagination_class = None
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = WeeklyTransfersFilter
    ordering_fields = ['week_start']
    ordering = ['-week_start']

    def get_queryset(self):
        """Get queryset based on query parameters."""
        if getattr(self, "swagger_fake_view", False):
            return DemandForecast.objects.none()

        # Get parameters from filters
        filterset = self.filterset_class(self.request.GET, queryset=DemandForecast.objects.all())
        if not filterset.is_valid():
            raise ValidationError(filterset.errors)

        # Extract filter values
        # Note: 'material' parameter from frontend is a mat_nbr (string), not material_id
        # The filter now treats 'material' as mat_nbr via CharFilter on material__mat_nbr
        material_param = filterset.data.get('material')
        mat_nbr_param = filterset.data.get('mat_nbr')
        material_id = filterset.data.get('material_id')
        plant_id = filterset.data.get('plant')
        plant_nbr = filterset.data.get('plant_nbr')

        # Use material parameter as mat_nbr if provided (frontend sends material=mat_nbr)
        # Prefer explicit mat_nbr parameter if both are provided
        mat_nbr = mat_nbr_param or material_param

        # Get ordering
        ordering = self.request.query_params.get('ordering', '-week_start')

        return DemandForecastService.get_weekly_transfers(
            material_id=material_id,
            mat_nbr=mat_nbr,
            plant_id=plant_id,
            plant_nbr=plant_nbr,
            ordering=ordering
        )

    def filter_queryset(self, queryset):
        """
        Override to skip filter backends when using materialized view.
        MV QuerySet is already filtered/ordered by the service.
        """
        # Check if queryset is from materialized view
        if queryset.model == DemandForecastInventoryBandsWeeklyMV:
            # Skip filter backends - already handled by service
            return queryset
        # Apply normal filtering for direct queries
        return super().filter_queryset(queryset)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class WeeklyMaterialForecastComparisonView(generics.ListAPIView):
    """
    Forecast comparison per material for fixed windows: this/last ISO week and
    this/last calendar month. Includes WoW/MoM change, formulary, and days on hand.

    Query params:
      - sales_group (optional): restrict to materials on that formulary sales group
        (e.g. PRxO, PGEN)
      - ordering: field to order by (prefix with - for descending)
      - <field>_min / <field>_max: numeric range filters
      - <global material filters>
    """
    serializer_class = WeeklyMaterialForecastComparisonSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = WeeklyMaterialForecastComparisonFilter
    ordering_fields = [
        "material",
        "material_name",
        "ndc",
        "material_status",
        "forecast_this_week",
        "forecast_last_week",
        "forecast_this_month",
        "forecast_last_month",
        "wow_change",
        "wow_change_pct",
        "mom_change",
        "mom_change_pct",
        "days_on_hand",
    ]
    ordering = ["-wow_change_pct"]

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return DemandForecast.objects.none()
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return DemandForecastService.get_weekly_material_forecast_comparison(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            sales_group=self.request.query_params.get("sales_group"),
        )

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        rows = list(queryset) if page is None else page

        context = self.get_serializer_context()
        context["formulary_map"] = MaterialFormularyService.get_formulary_map(
            [row["material"] for row in rows]
        )
        serializer = self.get_serializer(rows, many=True, context=context)

        if page is None:
            return Response(serializer.data)
        return self.get_paginated_response(serializer.data)


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="get")
class ForecastChangeKpisView(APIView):
    """
    GET /demand-forecast/forecast-change-kpis/

    Counts of materials with a non-zero WoW forecast change on PRxO vs Pharmagen (PGEN).
    """

    @extend_schema(responses=ForecastChangeKpisSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = DemandForecastService.get_forecast_change_kpis(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )
        return Response(ForecastChangeKpisSerializer(data).data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialForecastDetailView(APIView):
    """
    Returns formularies and 28-day-prior sales/forecast for a specific material,
    for two provided week dates.

    Path param:
      - mat_nbr: material number

    Query params (both required, format YYYY-MM-DD — should be a Monday):
      - current_week
      - previous_week

    For each week, aggregates sales (qty_ordered) and forecast (forecast_qty_7day)
    from demand_forecast over the 4 weeks immediately before that week.
    """

    @extend_schema(responses=MaterialForecastDetailSerializer)
    def get(self, request, mat_nbr, *args, **kwargs):
        from datetime import date as _date

        current_week_raw = request.query_params.get('current_week')
        previous_week_raw = request.query_params.get('previous_week')

        if not current_week_raw or not previous_week_raw:
            raise ValidationError({'detail': 'current_week and previous_week are required (YYYY-MM-DD).'})

        try:
            current_week = _date.fromisoformat(current_week_raw)
            previous_week = _date.fromisoformat(previous_week_raw)
        except ValueError:
            raise ValidationError({'detail': 'Invalid date format. Expected YYYY-MM-DD.'})

        data = DemandForecastService.get_material_forecast_detail(
            mat_nbr=mat_nbr,
            current_week=current_week,
            previous_week=previous_week,
        )
        serializer = MaterialForecastDetailSerializer(data)
        return Response(serializer.data)
