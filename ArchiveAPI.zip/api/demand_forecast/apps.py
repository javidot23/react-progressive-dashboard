from django.apps import AppConfig


class DemandForecastConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.demand_forecast'
