import calendar
import logging
from datetime import timedelta, date

from django.contrib.postgres.expressions import ArraySubquery
from django.contrib.postgres.fields import ArrayField
from django.db.models import (
    BigIntegerField,
    Case,
    CharField,
    DateField,
    ExpressionWrapper,
    F,
    FloatField,
    IntegerField,
    Max,
    OuterRef,
    Q,
    Subquery,
    Value,
    When,
    Count,
)
from django.db.models.aggregates import Sum
from django.db.models.functions import Cast, Coalesce, ExtractMonth, Round
from django.db.models.functions.datetime import TruncWeek
from django.utils import timezone

from api.csv_export import csv_cell, csv_date, csv_percentage, csv_rounded
from api.demand_forecast.materialized_view_models import (
    DemandForecastInventoryBandsWeeklyMV,
    DemandForecastInventoryBandsTotalMV,
    DemandForecastMaterialPlantMV,
    DemandForecastWeeklyMaterialMV,
)
from api.date_bounds import calendar_month_bounds, iso_week_bounds
from api.demand_forecast.models import DemandForecast
from api.material.models import Material
from api.material_formulary.models import MaterialFormulary
from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV

logger = logging.getLogger(__name__)

# Return rows carry a non-positive ordered quantity. They stay in net volume sums but are
# excluded from fill rate denominators and omit subtractions, matching the treatment of
# returns in order_transactions.
POSITIVE_DEMAND = Q(qty_ordered__gt=0)

# Days-on-hand cutoffs for the Product Relative Inventory bands: Low (0-10), Acceptable (11-60),
# Overstock (61+), plus No Forecast for materials without a positive 7-day forecast. Bands are
# assigned per material, from on-hand and forecast summed over the material's plants, so every
# material falls in exactly one band. Mirrors demand_forecast_inventory_bands_*_mv.
INVENTORY_BAND_LOW_MAX_DOH = 10.0
INVENTORY_BAND_ACCEPTABLE_MAX_DOH = 60.0


class DemandForecastService:
    @staticmethod
    def _active_plant_filter():
        """Plant rows with any 90-day inventory/order/forecast activity."""
        return (
            Q(latest_saleable_qty_on_hand__gt=0)
            | Q(latest_on_order_qty__gt=0)
            | Q(latest_forecast_qty_7day__gt=0)
            | Q(total_shipped_qty__gt=0)
            | Q(total_qty_ordered__gt=0)
        )

    @staticmethod
    def _plant_doh_annotation():
        """Per-plant days-on-hand from latest on-hand / 7-day forecast."""
        return Case(
            When(
                latest_forecast_qty_7day__gt=0,
                then=Cast(F('latest_saleable_qty_on_hand'), FloatField()) * 7.0
                / Cast(F('latest_forecast_qty_7day'), FloatField()),
            ),
            default=Value(None),
            output_field=FloatField(),
        )

    @staticmethod
    def _material_doh_aggregates(queryset, extra_group_fields=()):
        """
        On-hand and positive 7-day forecast totals per material, optionally per extra grouping field.
        """
        group_fields = ('material',) + tuple(extra_group_fields)
        return queryset.values(*group_fields).annotate(
            total_on_hand=Sum('saleable_qty_on_hand'),
            total_forecast_7day=Sum('forecast_qty_7day', filter=Q(forecast_qty_7day__gt=0)),
        )

    @staticmethod
    def _inventory_band_of(row):
        """Band a material-level aggregate belongs to."""
        total_forecast_7day = row['total_forecast_7day'] or 0
        if total_forecast_7day <= 0:
            return 'no_forecast'

        doh = (row['total_on_hand'] or 0) / (total_forecast_7day / 7.0)
        if doh <= INVENTORY_BAND_LOW_MAX_DOH:
            return 'low'
        if doh <= INVENTORY_BAND_ACCEPTABLE_MAX_DOH:
            return 'acceptable'
        return 'overstock'

    @staticmethod
    def _empty_inventory_bands():
        return {'low': 0, 'acceptable': 0, 'overstock': 0, 'no_forecast': 0}

    @staticmethod
    def _count_inventory_bands(queryset):
        """Band counts over a forecast queryset, counting each material once."""
        counts = DemandForecastService._empty_inventory_bands()
        for row in DemandForecastService._material_doh_aggregates(queryset):
            counts[DemandForecastService._inventory_band_of(row)] += 1
        return counts

    @staticmethod
    def _count_inventory_bands_by(queryset, group_field):
        """Band counts keyed by a grouping field value, counting each material once per group."""
        grouped = {}
        rows = DemandForecastService._material_doh_aggregates(queryset, extra_group_fields=(group_field,))
        for row in rows:
            counts = grouped.setdefault(row[group_field], DemandForecastService._empty_inventory_bands())
            counts[DemandForecastService._inventory_band_of(row)] += 1
        return grouped

    @staticmethod
    def get_materials_in_each_inventory_band(start_date, end_date):
        """
        Count of materials in each inventory band.
        Low (0-10 DOH)
        Acceptable (11-60 DOH)
        Overstock (61+ DOH)
        and No Forecast.
        """
        logger.info("Getting materials in each inventory band for date range")

        forecasts = DemandForecast.objects.filter(demand_date__range=(start_date, end_date))

        bands = DemandForecastService._count_inventory_bands(forecasts)
        bands["daily"] = DemandForecastService.get_daily_materials_in_each_inventory_band(
            start_date, end_date
        )
        return bands

    @staticmethod
    def get_materials_in_each_inventory_band_this_year(filter_params=None):
        """
        Count of materials in each inventory band for the current year.
        """
        logger.info("Getting materials in each inventory band for the current year")
        current_year = timezone.now().year

        forecasts = DemandForecast.objects.filter(demand_date__year=current_year)
        if filter_params:
            forecasts = forecasts.filter(**filter_params)

        bands = DemandForecastService._count_inventory_bands(forecasts)
        bands["monthly"] = DemandForecastService.get_monthly_materials_in_each_inventory_band()
        return bands

    @staticmethod
    def get_materials_in_each_inventory_band_last_90_days_weekly(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Count of materials in each inventory band for the last 90 days aggregated per week.

        Each material is counted once per period, from on-hand and 7-day forecast summed over
        its plants and days.

        Uses materialized view when no filters are applied.
        For filtered queries, uses subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting weekly materials in each inventory band for last 90 days")

        if not direct_mat_nbr and mat_nbr_subquery is None:
            return DemandForecastService._get_inventory_bands_from_materialized_view()

        return DemandForecastService._get_inventory_bands_from_direct_query(direct_mat_nbr, mat_nbr_subquery)

    @staticmethod
    def _get_inventory_bands_from_materialized_view():
        """
        Fetch inventory band data from materialized views.
        This is extremely fast (~50-100ms) compared to the direct query approach (60+ seconds).
        Average DOH is pre-calculated in the materialized view for optimal performance.
        """
        # Get total counts from materialized view
        totals = DemandForecastInventoryBandsTotalMV.objects.first()

        if not totals:
            # Materialized view hasn't been created/refreshed yet
            logger.warning("Materialized view is empty. Using direct query as fallback.")
            return DemandForecastService._get_inventory_bands_from_direct_query(None)

        # Get weekly data from materialized view
        weekly_data = DemandForecastInventoryBandsWeeklyMV.objects.all().order_by('week_start')

        weekly = []
        for row in weekly_data:
            weekly.append({
                'week_start': row.week_start,
                'week_end': row.week_start + timedelta(days=6),
                'low': row.low_count,
                'acceptable': row.acceptable_count,
                'overstock': row.overstock_count,
                'no_forecast': row.no_forecast_count,
            })

        return {
            'start_date': totals.start_date,
            'end_date': totals.end_date,
            'low': totals.low_count,
            'acceptable': totals.acceptable_count,
            'overstock': totals.overstock_count,
            'no_forecast': totals.no_forecast_count,
            'average_doh': totals.avg_doh,  # Pre-calculated in materialized view
            'weekly': weekly,
        }

    @staticmethod
    def _get_inventory_bands_from_direct_query(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Direct query with optimized subquery pattern for filtered requests.
        """
        trend_end_date = timezone.now().date()
        trend_start_date = trend_end_date - timedelta(days=90)
        latest_snapshot_date = DemandForecast.objects.aggregate(
            latest_snapshot_date=Max('demand_date')
        )['latest_snapshot_date']

        # Trend uses the last 90 days; overall cards use only latest global snapshot date.
        trend_qs = DemandForecast.objects.filter(demand_date__range=(trend_start_date, trend_end_date))
        overall_qs = (
            DemandForecast.objects.filter(demand_date=latest_snapshot_date)
            if latest_snapshot_date
            else DemandForecast.objects.none()
        )

        if direct_mat_nbr:
            trend_qs = trend_qs.filter(material=direct_mat_nbr)
            overall_qs = overall_qs.filter(material=direct_mat_nbr)

        if mat_nbr_subquery is not None:
            trend_qs = trend_qs.filter(material__in=mat_nbr_subquery)
            overall_qs = overall_qs.filter(material__in=mat_nbr_subquery)

        # Overall totals from latest snapshot date only.
        totals = DemandForecastService._count_inventory_bands(overall_qs)

        # Calculate network-weighted DOH:
        # SUM(on_hand for forecasted rows) / SUM(daily_forecast for forecasted rows)
        weighted_doh_totals = overall_qs.aggregate(
            total_on_hand_forecasted=Sum('saleable_qty_on_hand', filter=Q(forecast_qty_7day__gt=0)),
            total_forecast_7day=Sum('forecast_qty_7day', filter=Q(forecast_qty_7day__gt=0)),
        )
        total_on_hand_forecasted = weighted_doh_totals['total_on_hand_forecasted'] or 0
        total_forecast_7day = weighted_doh_totals['total_forecast_7day'] or 0
        total_daily_forecast = total_forecast_7day / 7.0 if total_forecast_7day else 0
        avg_doh = (
            total_on_hand_forecasted / total_daily_forecast
            if total_daily_forecast > 0
            else None
        )

        weekly_counts = DemandForecastService._count_inventory_bands_by(
            trend_qs.annotate(week_start=TruncWeek('demand_date')), 'week_start'
        )

        weekly = [
            {
                'week_start': week_start,
                'week_end': week_start + timedelta(days=6),
                **counts,
            }
            for week_start, counts in sorted(weekly_counts.items())
        ]

        return {
            'start_date': latest_snapshot_date or trend_end_date,
            'end_date': latest_snapshot_date or trend_end_date,
            **totals,
            'average_doh': avg_doh,
            'weekly': weekly,
        }

    @staticmethod
    def get_daily_materials_in_each_inventory_band(start_date, end_date):
        """
        Count of materials in each inventory band for each day in a date range.
        """
        logger.info("Getting daily materials in each inventory band for date range")

        daily_bands = DemandForecastService._count_inventory_bands_by(
            DemandForecast.objects.filter(demand_date__range=(start_date, end_date)), 'demand_date'
        )

        return {
            demand_date.isoformat(): counts
            for demand_date, counts in sorted(daily_bands.items())
        }

    @staticmethod
    def get_monthly_materials_in_each_inventory_band():
        """
        Count of materials in each inventory band for each month in the current year.
        """
        logger.info("Getting monthly materials in each inventory band for the current year")
        current_year = timezone.now().year

        monthly_bands = DemandForecastService._count_inventory_bands_by(
            DemandForecast.objects.filter(demand_date__year=current_year).annotate(
                month=ExtractMonth('demand_date')
            ),
            'month',
        )

        return [
            {
                'month': calendar.month_name[month],
                'month_num': month,
                **counts,
            }
            for month, counts in sorted(monthly_bands.items())
        ]

    @staticmethod
    def get_material_inventory_on_each_plant(material_id):
        """
        Get the inventory of a specific material across all plants on the latest date.
        Only returns plants where saleable_qty_on_hand > 0
        """
        logger.info(f"Getting inventory for material {material_id} across all plants")

        # Get the latest date for the material
        latest_date = DemandForecast.objects.filter(material__id=material_id).order_by('-demand_date').values_list(
            'demand_date', flat=True).first()

        if not latest_date:
            return []

        # Filter by the latest date, material, and availability (saleable_qty_on_hand > 0)
        inventory = DemandForecast.objects.filter(
            demand_date=latest_date,
            material__id=material_id,
            saleable_qty_on_hand__gt=0,
        ).prefetch_related('plant')

        return list(inventory)

    @staticmethod
    def get_weekly_demand_forecast_last_90_days(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get weekly aggregated demand (demand_7day) and forecast (forecast_qty_7day)
        for the last 90 days.

        Uses materialized view when no filters are applied.
        For filtered queries, uses subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting weekly demand forecast for last 90 days")

        if not direct_mat_nbr and mat_nbr_subquery is None:
            weekly_data = DemandForecastInventoryBandsWeeklyMV.objects.all().order_by('week_start')

            weekly = []
            for row in weekly_data:
                weekly.append({
                    'week_start': row.week_start,
                    'week_end': row.week_start + timedelta(days=6),
                    'demand_qty': int(row.total_demand_7day or 0),
                    'forecast_qty': int(row.total_forecast_qty or 0),
                })

            return weekly

        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=89)

        queryset = DemandForecast.objects.filter(demand_date__range=(start_date, end_date))

        if direct_mat_nbr:
            queryset = queryset.filter(material=direct_mat_nbr)

        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__in=mat_nbr_subquery)

        weekly_data = queryset.annotate(
            week_start=TruncWeek('demand_date')
        ).values('week_start').annotate(
            total_demand_7day=Sum('demand_7day'),
            total_forecast_qty=Sum('forecast_qty_7day')
        ).order_by('week_start')

        weekly = []
        for item in weekly_data:
            week_start = item['week_start']
            week_end = week_start + timedelta(days=6)

            weekly.append({
                'week_start': week_start,
                'week_end': week_end,
                'demand_qty': int(item['total_demand_7day'] or 0),
                'forecast_qty': int(item['total_forecast_qty'] or 0),
            })

        return weekly

    @staticmethod
    def get_weekly_forecast_groups_last_90_days(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get weekly percentages of materials in forecast quantity groups for last 90 days.
        Uses subquery pattern for filtered queries to avoid expensive JOINs.
        """
        logger.info("Getting weekly forecast groups for last 90 days")
        material_weekly_totals = DemandForecastWeeklyMaterialMV.objects.all()

        if direct_mat_nbr:
            material_weekly_totals = material_weekly_totals.filter(material=direct_mat_nbr)

        if mat_nbr_subquery is not None:
            material_weekly_totals = material_weekly_totals.filter(material__in=mat_nbr_subquery)
        weekly_groups = {}

        for item in material_weekly_totals:
            week_start = item.week_start
            material_id = item.material_id
            total_forecast = item.total_forecast or 0
            qty_ordered = item.total_qty_ordered or 0
            qty_ordered_alt_serve = item.total_qty_ordered_alt_serve or 0

            if week_start not in weekly_groups:
                weekly_groups[week_start] = {
                    'low_forecast': {},
                    'medium_forecast': {},
                    'high_forecast': {},
                    'very_high_forecast': {},
                    'total_materials': set()
                }

            if total_forecast < 50:
                category = 'low_forecast'
            elif total_forecast <= 200:
                category = 'medium_forecast'
            elif total_forecast <= 500:
                category = 'high_forecast'
            else:
                category = 'very_high_forecast'

            if qty_ordered > 0:
                material_alt_serve_pct = (qty_ordered_alt_serve / qty_ordered) * 100
            else:
                material_alt_serve_pct = 0.0

            weekly_groups[week_start][category][material_id] = material_alt_serve_pct
            weekly_groups[week_start]['total_materials'].add(material_id)

        # Convert to list and calculate average alt serve percentages
        weekly = []
        for week_start in sorted(weekly_groups.keys()):
            data = weekly_groups[week_start]

            result = {
                'week_start': week_start,
                'week_end': week_start + timedelta(days=6),
                'total_materials': len(data['total_materials'])
            }

            # Calculate average alt serve percentage for each forecast band
            for category in ['low_forecast', 'medium_forecast', 'high_forecast', 'very_high_forecast']:
                percentages = list(data[category].values())
                if percentages:
                    avg_alt_serve_pct = sum(percentages) / len(percentages)
                else:
                    avg_alt_serve_pct = 0.0

                result[f'{category}_percentage'] = round(avg_alt_serve_pct, 2)

            weekly.append(result)

        return weekly

    @staticmethod
    def get_materials_low_inventory(queryset, range_low=25, range_high=35):
        """
        Get materials with stocking-DC count, outbound fill rate, days on hand, and days on order.

        Aligned with upstream inventory_material_current methodology:
        - dc_count: number of DCs with any activity in the 90-day window (on_hand, on_order,
          forecast, shipped, or ordered).
        - doh_days: SUM(latest on-hand across plants) * 7 / SUM(latest 7-day forecast across plants).
        - doo_days: SUM(latest on-order across plants) * 7 / SUM(latest 7-day forecast across plants).
        - outbound_fill_rate: 90-day SUM(shipped) / SUM(ordered).
        - plants_*: per-material counts of active plants in each DOH zone (per-plant DOH).
        """
        logger.info("Getting materials low inventory")

        active_plant_filter = DemandForecastService._active_plant_filter()

        queryset = queryset.annotate(
            plant_doh=DemandForecastService._plant_doh_annotation()
        )

        return queryset.values(
            'material',
        ).annotate(
            material__id=F('material__id'),
            material__mat_nbr=F('material'),
            material__name=F('material__name'),
            material__ndc=F('material__ndc'),
            material__xplant_mat_stat=F('material__xplant_mat_stat'),
            dc_count=Count(
                'plant',
                filter=active_plant_filter,
                distinct=True,
            ),
            plants_no_stock=Count(
                'plant',
                filter=active_plant_filter & (Q(plant_doh__isnull=True) | Q(plant_doh__lt=1)),
                distinct=True,
            ),
            plants_stockout=Count(
                'plant',
                filter=active_plant_filter & Q(plant_doh__gte=1, plant_doh__lt=range_low),
                distinct=True,
            ),
            plants_in_range=Count(
                'plant',
                filter=active_plant_filter & Q(plant_doh__gte=range_low, plant_doh__lte=range_high),
                distinct=True,
            ),
            plants_overstock=Count(
                'plant',
                filter=active_plant_filter & Q(plant_doh__gt=range_high),
                distinct=True,
            ),
            total_shipped_qty=Sum('total_shipped_qty'),
            total_qty_ordered=Sum('total_qty_ordered'),
            demand_qty_ordered=Sum('total_qty_ordered_pos'),
            demand_shipped_qty=Sum('total_shipped_qty_pos'),
            # Sum of latest-per-plant snapshots, used for DOH/DOO.
            total_latest_on_hand=Sum('latest_saleable_qty_on_hand'),
            total_latest_on_order=Sum('latest_on_order_qty'),
            total_latest_forecast=Sum('latest_forecast_qty_7day'),
        ).annotate(
            outbound_fill_rate=Case(
                When(
                    demand_qty_ordered__gt=0,
                    then=Cast(F('demand_shipped_qty'), FloatField()) / Cast(F('demand_qty_ordered'), FloatField())
                ),
                default=0.0,
                output_field=FloatField(),
            ),
            doh_days=Coalesce(
                Case(
                    When(
                        total_latest_forecast__gt=0,
                        then=(Cast(F('total_latest_on_hand'), FloatField()) * 7.0)
                        / Cast(F('total_latest_forecast'), FloatField())
                    ),
                    output_field=FloatField(),
                ),
                0.0,
                output_field=FloatField()
            ),
            doo_days=Coalesce(
                Case(
                    When(
                        total_latest_forecast__gt=0,
                        then=(Cast(F('total_latest_on_order'), FloatField()) * 7.0)
                        / Cast(F('total_latest_forecast'), FloatField())
                    ),
                    output_field=FloatField(),
                ),
                0.0,
                output_field=FloatField()
            ),
        ).filter(
            Q(total_qty_ordered__gt=0)
            | Q(total_shipped_qty__gt=0)
            | Q(total_latest_on_hand__gt=0)
            | Q(total_latest_on_order__gt=0)
            | Q(total_latest_forecast__gt=0)
        )

    @staticmethod
    def get_materials_furthest_from_threshold(queryset, range_low=25, range_high=35):
        """
        Filter to products outside the DOH threshold band and compute distance from
        the violated boundary.

        Distance formula:
        - low side:  range_low - doh_days
        - high side: doh_days - range_high
        """
        return queryset.filter(
            Q(doh_days__lt=range_low) | Q(doh_days__gt=range_high)
        ).annotate(
            doh_distance_from_threshold=Case(
                When(
                    doh_days__lt=range_low,
                    then=Value(range_low, output_field=FloatField()) - F('doh_days'),
                ),
                When(
                    doh_days__gt=range_high,
                    then=F('doh_days') - Value(range_high, output_field=FloatField()),
                ),
                default=Value(0.0),
                output_field=FloatField(),
            )
        )

    WEEKLY_MATERIAL_FORECAST_COMPARISON_CSV_HEADERS = [
        "Product Name",
        "Product ID",
        "NDC",
        "Total Forecast Last Week",
        "Total Forecast Current Week",
        "Total Forecast Last Month",
        "Total Forecast Current Month",
        "MoM Change %",
        "MoM Change Units",
        "Days on Hand",
        "Formulary",
        "Material Status",
    ]

    @staticmethod
    def format_forecast_mom_change_pct(value) -> str:
        """Match Manage UI formatForecastStatusChangePercentage."""
        if value is None:
            return "Undefined"
        num = float(value)
        formatted = f"{num:.2f}".rstrip("0").rstrip(".")
        prefix = "+" if num >= 0 else ""
        return f"{prefix}{formatted}%"

    @staticmethod
    def format_forecast_mom_change_units(value) -> str:
        """Match Manage UI formatForecastStatusSignedQuantity."""
        if value is None:
            return "Undefined"
        num = float(value)
        if num == int(num):
            body = f"{int(abs(num)):,}"
        else:
            body = f"{abs(num):,.2f}".rstrip("0").rstrip(".")
        sign = "+" if num >= 0 else "-"
        return f"{sign}{body}"

    @classmethod
    def iter_weekly_material_forecast_comparison_csv_rows(cls, queryset, formulary_map=None, chunk_size=2000):
        """
        Yield Products with Forecast Changes CSV header and rows without loading the full export.
        Formulary values come from ``formulary_map`` (material number → sales groups).
        """
        formulary_map = formulary_map or {}
        yield list(cls.WEEKLY_MATERIAL_FORECAST_COMPARISON_CSV_HEADERS)
        for row in queryset.iterator(chunk_size=chunk_size):
            formulary = formulary_map.get(row.get("material")) or []
            yield [
                csv_cell(row.get("material_name")),
                csv_cell(row.get("material")),
                csv_cell(row.get("ndc")),
                csv_cell(row.get("forecast_last_week")),
                csv_cell(row.get("forecast_this_week")),
                csv_cell(row.get("forecast_last_month")),
                csv_cell(row.get("forecast_this_month")),
                cls.format_forecast_mom_change_pct(row.get("mom_change_pct")),
                cls.format_forecast_mom_change_units(row.get("mom_change")),
                csv_rounded(row.get("days_on_hand"), 1),
                ";".join(str(item) for item in formulary if item is not None),
                csv_cell(row.get("material_status")),
            ]

    MATERIALS_LOW_INVENTORY_CSV_HEADERS = [
        "Product Name",
        "Product ID",
        "NDC",
        "Days on Hand",
        "Low Inventory DCs",
        "Acceptable Inventory DCs",
        "Overstock Inventory DCs",
        "Outbound Fill Rate",
        "Material Status",
    ]

    @classmethod
    def iter_materials_low_inventory_csv_rows(cls, queryset, chunk_size=2000):
        """
        Yield CSV header then data rows for Products Outside Threshold.
        Aggregated `.values()` rows are dicts; iterator keeps memory bounded.
        """
        yield list(cls.MATERIALS_LOW_INVENTORY_CSV_HEADERS)
        for row in queryset.iterator(chunk_size=chunk_size):
            plants_no_stock = row.get("plants_no_stock") or 0
            plants_stockout = row.get("plants_stockout") or 0
            yield [
                csv_cell(row.get("material__name")),
                csv_cell(row.get("material__mat_nbr")),
                csv_cell(row.get("material__ndc")),
                csv_cell(csv_rounded(row.get("doh_days"), 1)),
                csv_cell(plants_no_stock + plants_stockout),
                csv_cell(row.get("plants_in_range")),
                csv_cell(row.get("plants_overstock")),
                csv_cell(csv_percentage(row.get("outbound_fill_rate"))),
                csv_cell(row.get("material__xplant_mat_stat")),
            ]

    MATERIALS_INVENTORY_CSV_HEADERS = [
        "Product name",
        "Product ID",
        "NDC",
        "Days on hand",
        "Units on hand",
        "Units on Order",
        "Days on Order",
        "Next Inbound Order",
        "28-day Forecast",
        "Next Expected Arrival",
        "Low Inventory DCs",
        "Acceptable Inventory DCs",
        "Overstock Inventory DCs",
        "Outbound Fill Rate",
        "Formulary",
        "Material Status",
    ]

    @classmethod
    def iter_materials_inventory_csv_rows(cls, queryset, chunk_size=2000):
        """Yield All Products headers and rows without loading the full export."""
        yield list(cls.MATERIALS_INVENTORY_CSV_HEADERS)
        for row in queryset.iterator(chunk_size=chunk_size):
            formulary = row.formulary or []
            yield [
                csv_cell(row.material_name),
                csv_cell(row.material_number),
                csv_cell(row.ndc),
                csv_rounded(row.days_on_hand, 1),
                csv_cell(row.units_on_hand),
                csv_cell(row.units_on_order),
                csv_rounded(row.days_on_order, 1),
                csv_cell(row.next_inbound_order_quantity),
                csv_cell(row.forecast_qty_28day),
                csv_date(row.next_expected_arrival_date),
                csv_cell(row.low_inventory_dcs),
                csv_cell(row.acceptable_inventory_dcs),
                csv_cell(row.overstock_inventory_dcs),
                csv_percentage(row.inventory_outbound_fill_rate),
                ";".join(str(item) for item in formulary if item is not None),
                csv_cell(row.material_status),
            ]

    @staticmethod
    def list_materials_inventory(direct_mat_nbr=None, mat_nbr_subquery=None, range_low=25, range_high=35):
        """
        All-products inventory list: every material with DF/PO/formulary enrichment.

        Reuses MaterialsLowInventory DOH/DOO/fill-rate and plant-zone formulas against
        DemandForecastMaterialPlantMV. Materials with no DF activity return zeros/nulls.
        low_inventory_dcs = plants_no_stock + plants_stockout.
        """
        logger.info(
            "Listing all materials inventory (range_low=%s, range_high=%s)",
            range_low,
            range_high,
        )
        today = date.today()
        active_plant_filter = DemandForecastService._active_plant_filter()

        def _mv_sum_sq(field):
            return (
                DemandForecastMaterialPlantMV.objects.filter(material=OuterRef("mat_nbr"))
                .values("material")
                .annotate(total=Sum(field))
                .values("total")[:1]
            )

        def _zone_count_sq(zone_q):
            return (
                DemandForecastMaterialPlantMV.objects.filter(material=OuterRef("mat_nbr"))
                .annotate(plant_doh=DemandForecastService._plant_doh_annotation())
                .filter(active_plant_filter & zone_q)
                .values("material")
                .annotate(c=Count("plant", distinct=True))
                .values("c")[:1]
            )

        open_po_base = (
            PurchaseOrderLatest90dMV.objects.filter(
                material=OuterRef("mat_nbr"),
                completion_date__isnull=True,
                anticipated_date__isnull=False,
            )
            .annotate(
                priority=Case(
                    When(anticipated_date__gte=today, then=Value(0)),
                    default=Value(1),
                    output_field=IntegerField(),
                )
            )
            .order_by("priority", "anticipated_date", "id")
        )

        formulary_sq = (
            MaterialFormulary.objects.filter(material=OuterRef("mat_nbr"))
            .exclude(sales_group__isnull=True)
            .exclude(sales_group="")
            .order_by("sales_group")
            .values("sales_group")
            .distinct()
        )

        qs = Material.objects.all()
        if direct_mat_nbr:
            qs = qs.filter(mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(mat_nbr__in=mat_nbr_subquery)

        return (
            qs.annotate(
                material_number=F("mat_nbr"),
                material_name=F("name"),
                material_status=F("xplant_mat_stat"),
                units_on_hand=Coalesce(
                    Subquery(_mv_sum_sq("latest_saleable_qty_on_hand"), output_field=IntegerField()),
                    Value(0),
                    output_field=IntegerField(),
                ),
                units_on_order=Coalesce(
                    Subquery(_mv_sum_sq("latest_on_order_qty"), output_field=IntegerField()),
                    Value(0),
                    output_field=IntegerField(),
                ),
                total_latest_forecast=Coalesce(
                    Subquery(_mv_sum_sq("latest_forecast_qty_7day"), output_field=IntegerField()),
                    Value(0),
                    output_field=IntegerField(),
                ),
                total_shipped_qty=Coalesce(
                    Subquery(_mv_sum_sq("total_shipped_qty"), output_field=BigIntegerField()),
                    Value(0),
                    output_field=BigIntegerField(),
                ),
                total_qty_ordered=Coalesce(
                    Subquery(_mv_sum_sq("total_qty_ordered"), output_field=BigIntegerField()),
                    Value(0),
                    output_field=BigIntegerField(),
                ),
                demand_qty_ordered=Coalesce(
                    Subquery(_mv_sum_sq("total_qty_ordered_pos"), output_field=BigIntegerField()),
                    Value(0),
                    output_field=BigIntegerField(),
                ),
                demand_shipped_qty=Coalesce(
                    Subquery(_mv_sum_sq("total_shipped_qty_pos"), output_field=BigIntegerField()),
                    Value(0),
                    output_field=BigIntegerField(),
                ),
                plants_no_stock=Coalesce(
                    Subquery(
                        _zone_count_sq(Q(plant_doh__isnull=True) | Q(plant_doh__lt=1)),
                        output_field=IntegerField(),
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                plants_stockout=Coalesce(
                    Subquery(
                        _zone_count_sq(Q(plant_doh__gte=1, plant_doh__lt=range_low)),
                        output_field=IntegerField(),
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                acceptable_inventory_dcs=Coalesce(
                    Subquery(
                        _zone_count_sq(Q(plant_doh__gte=range_low, plant_doh__lte=range_high)),
                        output_field=IntegerField(),
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                overstock_inventory_dcs=Coalesce(
                    Subquery(
                        _zone_count_sq(Q(plant_doh__gt=range_high)),
                        output_field=IntegerField(),
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                next_expected_arrival_date=Subquery(
                    open_po_base.values("anticipated_date")[:1],
                    output_field=DateField(),
                ),
                next_inbound_order_quantity=Subquery(
                    open_po_base.values("original_order_qty")[:1],
                    output_field=IntegerField(),
                ),
                formulary=Coalesce(
                    ArraySubquery(formulary_sq),
                    Value([], output_field=ArrayField(CharField())),
                ),
            )
            .annotate(
                low_inventory_dcs=F("plants_no_stock") + F("plants_stockout"),
                forecast_qty_28day=F("total_latest_forecast") * Value(4),
                inventory_outbound_fill_rate=Case(
                    When(
                        demand_qty_ordered__gt=0,
                        then=Cast(F("demand_shipped_qty"), FloatField())
                        / Cast(F("demand_qty_ordered"), FloatField()),
                    ),
                    default=Value(0.0),
                    output_field=FloatField(),
                ),
                days_on_hand=Coalesce(
                    Case(
                        When(
                            total_latest_forecast__gt=0,
                            then=(Cast(F("units_on_hand"), FloatField()) * 7.0)
                            / Cast(F("total_latest_forecast"), FloatField()),
                        ),
                        output_field=FloatField(),
                    ),
                    Value(0.0),
                    output_field=FloatField(),
                ),
                days_on_order=Coalesce(
                    Case(
                        When(
                            total_latest_forecast__gt=0,
                            then=(Cast(F("units_on_order"), FloatField()) * 7.0)
                            / Cast(F("total_latest_forecast"), FloatField()),
                        ),
                        output_field=FloatField(),
                    ),
                    Value(0.0),
                    output_field=FloatField(),
                ),
            )
            .order_by("-units_on_hand", "material_number")
        )

    @staticmethod
    def get_material_plants_summary(
        mat_nbr: str,
        date_from: date = None,
        date_to: date = None,
        ordering: str = '-outbound_fill_rate'
    ):
        """
        Get plants summary for a given material with aggregated values.

        Args:
            mat_nbr: Material number
            date_from: Start date filter (optional)
            date_to: End date filter (optional)
            ordering: Ordering field (default: '-outbound_fill_rate')

        Returns:
            QuerySet with plant aggregation data
        """
        logger.info(
            "Getting plants summary for material %s. Date range: %s to %s",
            mat_nbr, date_from, date_to
        )

        queryset = DemandForecast.objects.select_related('plant').filter(material=mat_nbr)

        if date_from:
            queryset = queryset.filter(demand_date__gte=date_from)
        if date_to:
            queryset = queryset.filter(demand_date__lte=date_to)

        plant_data = queryset.values('plant__id', 'plant__plant_nbr', 'plant__name').annotate(
            qty_ordered_sum=Sum('qty_ordered'),
            shipped_qty_sum=Sum('shipped_qty'),
            demand_qty_ordered=Sum('qty_ordered', filter=POSITIVE_DEMAND),
            demand_shipped_qty=Sum('shipped_qty', filter=POSITIVE_DEMAND),
            received_qty_sum=Sum('received_qty'),
            on_order_qty_sum=Sum('on_order_qty'),
            transfer_in_qty_sum=Sum('transfer_in_qty'),
            transfer_out_qty_sum=Sum('transfer_out_qty'),
            saleable_qty_on_hand_latest=Max(
                'saleable_qty_on_hand',
                filter=Q(saleable_qty_on_hand__isnull=False)
            ),
            unrestricted_qty_on_hand_latest=Max(
                'unrestricted_qty_on_hand',
                filter=Q(unrestricted_qty_on_hand__isnull=False)
            ),
            forecast_7day_sum=Sum('forecast_qty_7day', filter=Q(forecast_qty_7day__isnull=False)),
            forecast_7day_count=Count('forecast_qty_7day', filter=Q(forecast_qty_7day__isnull=False))
        ).annotate(
            outbound_fill_rate=Case(
                When(
                    demand_qty_ordered__gt=0,
                    then=Cast(F('demand_shipped_qty'), FloatField()) / Cast(F('demand_qty_ordered'), FloatField())
                ),
                default=None,
                output_field=FloatField(),
            ),
            forecast_7day_avg=Case(
                When(forecast_7day_count__gt=0,
                     then=Cast(F('forecast_7day_sum'), FloatField()) / Cast(F('forecast_7day_count'), FloatField())),
                default=None,
                output_field=FloatField()
            ),
            forecast_28day=Case(
                When(forecast_7day_count__gt=0,
                     then=Cast(F('forecast_7day_sum'), FloatField()) / Cast(F('forecast_7day_count'),
                                                                            FloatField()) * 4),
                default=None,
                output_field=FloatField()
            ),
            daily_forecast_rate=Case(
                When(forecast_7day_count__gt=0,
                     then=(Cast(F('forecast_7day_sum'), FloatField()) / Cast(F('forecast_7day_count'),
                                                                             FloatField())) / 7),
                default=None,
                output_field=FloatField()
            )
        ).annotate(
            doh_days=Case(
                When(
                    daily_forecast_rate__gt=0,
                    then=Cast(F('saleable_qty_on_hand_latest'), FloatField()) / Cast(F('daily_forecast_rate'),
                                                                                     FloatField())
                ),
                default=None,
                output_field=FloatField(),
            )
        )

        # Only return plants where the material is active (has on-order quantity)
        plant_data = plant_data.filter(on_order_qty_sum__gt=0)

        # Apply ordering
        valid_orderings = [
            '-outbound_fill_rate', 'outbound_fill_rate',
            'plant__plant_nbr', '-plant__plant_nbr',
            '-doh_days', 'doh_days'
        ]
        if ordering in valid_orderings:
            plant_data = plant_data.order_by(ordering)
        else:
            plant_data = plant_data.order_by('-outbound_fill_rate')

        return plant_data

    @staticmethod
    def get_weekly_supply_snapshot(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get weekly supply snapshot for the last 90 days.
        Uses materialized view when no filters are applied.
        For filtered queries, uses subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting weekly supply snapshot")

        if not direct_mat_nbr and mat_nbr_subquery is None:
            return DemandForecastInventoryBandsWeeklyMV.objects.annotate(
                on_hand_qty=F('total_saleable_qty_on_hand'),
                on_order_qty=F('total_on_order_qty'),
                transfer_in_qty=F('total_transfer_in_qty'),
                transfer_out_qty=F('total_transfer_out_qty'),
                received_qty=F('total_received_qty'),
                sold_qty=F('total_shipped_qty'),
                omit_qty=F('total_qty_ordered_pos') - F('total_shipped_qty_pos'),
                forecast_7day_week=Cast(F('total_forecast_qty'), FloatField()),
                forecast_28day=Cast(F('total_forecast_qty'), FloatField()) * Value(4.0),
                daily_forecast_rate=Case(
                    When(total_forecast_qty__gt=0,
                         then=Cast(F('total_forecast_qty'), FloatField()) / 7),
                    default=None,
                    output_field=FloatField()
                ),
            ).annotate(
                doh_days=Case(
                    When(
                        daily_forecast_rate__gt=0,
                        then=Cast(F('on_hand_qty'), FloatField()) / Cast(F('daily_forecast_rate'), FloatField())
                    ),
                    default=None,
                    output_field=FloatField(),
                ),
                doo_days=Case(
                    When(
                        daily_forecast_rate__gt=0,
                        then=Cast(F('on_order_qty'), FloatField()) / Cast(F('daily_forecast_rate'), FloatField())
                    ),
                    default=None,
                    output_field=FloatField(),
                ),
            ).order_by('week_start')

        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=90)

        queryset = DemandForecast.objects.filter(demand_date__range=(start_date, end_date))

        if direct_mat_nbr:
            queryset = queryset.filter(material=direct_mat_nbr)

        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__in=mat_nbr_subquery)

        weekly_data = queryset.annotate(
            week_start=TruncWeek('demand_date')
        ).values('week_start').annotate(
            on_hand_qty=Sum('saleable_qty_on_hand'),
            on_order_qty=Sum('on_order_qty'),
            transfer_in_qty=Sum('transfer_in_qty'),
            transfer_out_qty=Sum('transfer_out_qty'),
            received_qty=Sum('received_qty'),
            sold_qty=Sum('shipped_qty'),
            qty_ordered_sum=Sum('qty_ordered'),
            demand_qty_ordered=Sum('qty_ordered', filter=POSITIVE_DEMAND),
            demand_shipped_qty=Sum('shipped_qty', filter=POSITIVE_DEMAND),
            forecast_7day_week=Sum('forecast_qty_7day',
                                   filter=Q(forecast_qty_7day__isnull=False, forecast_qty_7day__gt=0))
        ).annotate(
            omit_qty=F('demand_qty_ordered') - F('demand_shipped_qty'),
            forecast_28day=Case(
                When(
                    forecast_7day_week__isnull=False,
                    then=Cast(F('forecast_7day_week'), FloatField()) * Value(4.0),
                ),
                default=None,
                output_field=FloatField(),
            ),
            daily_forecast_rate=Case(
                When(forecast_7day_week__gt=0,
                     then=Cast(F('forecast_7day_week'), FloatField()) / 7),
                default=None,
                output_field=FloatField()
            )
        ).annotate(
            doh_days=Case(
                When(
                    daily_forecast_rate__gt=0,
                    then=Cast(F('on_hand_qty'), FloatField()) / Cast(F('daily_forecast_rate'), FloatField())
                ),
                default=None,
                output_field=FloatField(),
            ),
            doo_days=Case(
                When(
                    daily_forecast_rate__gt=0,
                    then=Cast(F('on_order_qty'), FloatField()) / Cast(F('daily_forecast_rate'), FloatField())
                ),
                default=None,
                output_field=FloatField(),
            ),
        )

        return weekly_data.order_by('week_start')

    @staticmethod
    def get_weekly_performance(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get weekly inbound/outbound performance for the last 90 days.
        Uses materialized view when no filters are applied.
        For filtered queries, uses subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting weekly performance")

        if not direct_mat_nbr and mat_nbr_subquery is None:
            return DemandForecastInventoryBandsWeeklyMV.objects.annotate(
                received_qty=F('total_received_qty'),
                inbound_qty_ordered_sum=F('total_inbound_qty_ordered'),
                qty_ordered_sum=F('total_qty_ordered'),
                shipped_qty_sum=F('total_shipped_qty'),
                forecast_7day_week=Cast(F('total_forecast_qty'), FloatField()),
                inbound_fill_rate=Case(
                    When(total_inbound_qty_ordered__gt=0,
                         then=Cast(F('total_received_qty'), FloatField()) / Cast(F('total_inbound_qty_ordered'),
                                                                                 FloatField())),
                    default=None,
                    output_field=FloatField()
                ),
                outbound_fill_rate=Case(
                    When(total_qty_ordered_pos__gt=0,
                         then=Cast(F('total_shipped_qty_pos'), FloatField())
                         / Cast(F('total_qty_ordered_pos'), FloatField())),
                    default=None,
                    output_field=FloatField()
                )
            ).order_by('week_start')

        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=90)

        queryset = DemandForecast.objects.filter(demand_date__range=(start_date, end_date))

        if direct_mat_nbr:
            queryset = queryset.filter(material=direct_mat_nbr)

        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__in=mat_nbr_subquery)

        weekly_data = queryset.annotate(
            week_start=TruncWeek('demand_date')
        ).values('week_start').annotate(
            received_qty=Sum('received_qty'),
            inbound_qty_ordered_sum=Sum('inbound_qty_ordered'),
            qty_ordered_sum=Sum('qty_ordered'),
            shipped_qty_sum=Sum('shipped_qty'),
            demand_qty_ordered=Sum('qty_ordered', filter=POSITIVE_DEMAND),
            demand_shipped_qty=Sum('shipped_qty', filter=POSITIVE_DEMAND),
            forecast_7day_week=Sum('forecast_qty_7day', filter=Q(forecast_qty_7day__isnull=False))
        ).annotate(
            inbound_fill_rate=Case(
                When(
                    inbound_qty_ordered_sum__gt=0,
                    then=Cast(F('received_qty'), FloatField()) / Cast(F('inbound_qty_ordered_sum'), FloatField())
                ),
                default=None,
                output_field=FloatField(),
            ),
            outbound_fill_rate=Case(
                When(
                    demand_qty_ordered__gt=0,
                    then=Cast(F('demand_shipped_qty'), FloatField()) / Cast(F('demand_qty_ordered'), FloatField())
                ),
                default=None,
                output_field=FloatField(),
            ),
        )

        return weekly_data.order_by('week_start')

    @staticmethod
    def get_weekly_transfers(
        material_id: int = None,
        mat_nbr: str = None,
        plant_id: int = None,
        plant_nbr: str = None,
        ordering: str = '-week_start'
    ):
        """
        Get weekly transfers for the last 90 days.

        Args:
            material_id: Filter by material ID (optional)
            mat_nbr: Filter by material number (optional)
            plant_id: Filter by plant ID (optional)
            plant_nbr: Filter by plant number (optional)
            ordering: Ordering field (default: '-week_start')

        Returns:
            QuerySet with weekly transfer data

        Note:
            Uses materialized view QuerySet when no filters are applied.
            Falls back to direct query when filters are needed.
        """
        logger.info("Getting weekly transfers")

        if not any([material_id, mat_nbr, plant_id, plant_nbr]):
            return DemandForecastInventoryBandsWeeklyMV.objects.annotate(
                transfer_in_qty=F('total_transfer_in_qty'),
                transfer_out_qty=F('total_transfer_out_qty')
            ).order_by(ordering)

        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=90)

        queryset = DemandForecast.objects.filter(demand_date__range=(start_date, end_date))

        if material_id:
            queryset = queryset.filter(material__id=material_id)
        if mat_nbr:
            queryset = queryset.filter(material__mat_nbr=mat_nbr)
        if plant_id:
            queryset = queryset.filter(plant__id=plant_id)
        if plant_nbr:
            queryset = queryset.filter(plant__plant_nbr=plant_nbr)

        weekly_data = queryset.annotate(
            week_start=TruncWeek('demand_date')
        ).values('week_start').annotate(
            transfer_in_qty=Sum('transfer_in_qty'),
            transfer_out_qty=Sum('transfer_out_qty')
        )

        valid_orderings = ['-week_start', 'week_start']
        if ordering in valid_orderings:
            weekly_data = weekly_data.order_by(ordering)
        else:
            weekly_data = weekly_data.order_by('-week_start')

        return weekly_data

    @staticmethod
    def _pct_change(this_field, last_field):
        """((this - last) / last) * 100, or 0 when last is 0 / missing."""
        return Case(
            When(Q(**{f"{last_field}__isnull": True}) | Q(**{last_field: 0}), then=Value(0.0)),
            default=ExpressionWrapper(
                (Cast(F(this_field), FloatField()) - Cast(F(last_field), FloatField()))
                * 100.0
                / Cast(F(last_field), FloatField()),
                output_field=FloatField(),
            ),
            output_field=FloatField(),
        )

    @staticmethod
    def get_weekly_material_forecast_comparison(
        direct_mat_nbr=None, mat_nbr_subquery=None, sales_group=None,
    ):
        """
        Forecast totals per material for this/last ISO week and this/last calendar month,
        plus WoW/MoM change and days on hand. Formulary values are attached per page by
        ``MaterialFormularyService.get_formulary_map``.
        """
        this_week_start, this_week_end, last_week_start, last_week_end = iso_week_bounds()
        this_month_start, this_month_end, last_month_start, last_month_end = calendar_month_bounds()
        logger.info(
            "Getting material forecast comparison, weeks=%s..%s / %s..%s months=%s..%s / %s..%s",
            this_week_start, this_week_end, last_week_start, last_week_end,
            this_month_start, this_month_end, last_month_start, last_month_end,
        )

        window_start = min(last_week_start, last_month_start)
        window_end = max(this_week_end, this_month_end)
        qs = DemandForecast.objects.filter(
            demand_date__gte=window_start,
            demand_date__lte=window_end,
        )
        if direct_mat_nbr:
            qs = qs.filter(material=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__in=mat_nbr_subquery)
        if sales_group:
            qs = qs.filter(
                material__in=MaterialFormulary.objects.filter(sales_group=sales_group).values("material")
            )

        zero = Value(0, output_field=IntegerField())
        aggregated = qs.values("material").annotate(
            material_name=F("material__name"),
            ndc=F("material__ndc"),
            material_status=F("material__xplant_mat_stat"),
            saleable_qty_on_hand=Coalesce(
                F("material__saleable_qty_on_hand"),
                Value(0),
                output_field=IntegerField(),
            ),
            material_forecast_qty_7day=Coalesce(
                F("material__forecast_qty_7day"),
                Value(0),
                output_field=IntegerField(),
            ),
            forecast_this_week=Coalesce(
                Sum(
                    "forecast_qty_7day",
                    filter=Q(demand_date__gte=this_week_start, demand_date__lte=this_week_end),
                ),
                zero,
                output_field=IntegerField(),
            ),
            forecast_last_week=Coalesce(
                Sum(
                    "forecast_qty_7day",
                    filter=Q(demand_date__gte=last_week_start, demand_date__lte=last_week_end),
                ),
                zero,
                output_field=IntegerField(),
            ),
            forecast_this_month=Coalesce(
                Sum(
                    "forecast_qty_7day",
                    filter=Q(demand_date__gte=this_month_start, demand_date__lte=this_month_end),
                ),
                zero,
                output_field=IntegerField(),
            ),
            forecast_last_month=Coalesce(
                Sum(
                    "forecast_qty_7day",
                    filter=Q(demand_date__gte=last_month_start, demand_date__lte=last_month_end),
                ),
                zero,
                output_field=IntegerField(),
            ),
        )

        return aggregated.annotate(
            wow_change=ExpressionWrapper(
                F("forecast_this_week") - F("forecast_last_week"),
                output_field=IntegerField(),
            ),
            mom_change=ExpressionWrapper(
                F("forecast_this_month") - F("forecast_last_month"),
                output_field=IntegerField(),
            ),
            wow_change_pct=Round(
                DemandForecastService._pct_change("forecast_this_week", "forecast_last_week"), 2
            ),
            mom_change_pct=Round(
                DemandForecastService._pct_change("forecast_this_month", "forecast_last_month"), 2
            ),
            days_on_hand=Coalesce(
                Case(
                    When(
                        material_forecast_qty_7day__gt=0,
                        then=(Cast(F("saleable_qty_on_hand"), FloatField()) * 7.0)
                        / Cast(F("material_forecast_qty_7day"), FloatField()),
                    ),
                    output_field=FloatField(),
                ),
                Value(0.0),
                output_field=FloatField(),
            ),
        )

    @staticmethod
    def get_forecast_change_kpis(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Count of materials with a non-zero WoW forecast change on PRxO vs Pharmagen (PGEN).
        """
        logger.info("Getting forecast-change KPI counts (PRxO / PGEN)")
        changed = DemandForecastService.get_weekly_material_forecast_comparison(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        ).exclude(wow_change=0)
        prxo_mats = MaterialFormulary.objects.filter(sales_group="PRxO").values("material")
        pgen_mats = MaterialFormulary.objects.filter(sales_group="PGEN").values("material")
        return {
            "prxo_count": changed.filter(material__in=prxo_mats).count(),
            "pharmagen_count": changed.filter(material__in=pgen_mats).count(),
        }

    @staticmethod
    def get_doh_summary(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Returns network-weighted average DOH for the two most recent weekly snapshots,
        a percentage change between them, and a 90-day weekly DOH trend.

        Data arrives every Monday; each demand_date is a full-network snapshot.
        DOH is calculated as SUM(on_hand) / (SUM(forecast_7day) / 7) for rows
        with forecast_qty_7day > 0, to avoid distortion from zero-forecast rows.
        """
        logger.info("Getting DOH summary (current week vs previous week + 90-day trend)")

        today = timezone.now().date()
        trend_start = today - timedelta(days=89)

        def _apply_filters(qs):
            if direct_mat_nbr:
                qs = qs.filter(material=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                qs = qs.filter(material__in=mat_nbr_subquery)
            return qs

        def _weighted_doh(demand_date):
            if demand_date is None:
                return None
            qs = _apply_filters(DemandForecast.objects.filter(demand_date=demand_date))
            totals = qs.aggregate(
                total_on_hand=Sum('saleable_qty_on_hand', filter=Q(forecast_qty_7day__gt=0)),
                total_forecast=Sum('forecast_qty_7day', filter=Q(forecast_qty_7day__gt=0)),
            )
            on_hand = totals['total_on_hand'] or 0
            forecast = totals['total_forecast'] or 0
            if forecast <= 0:
                return None
            return on_hand / (forecast / 7.0)

        # Retrieve the two most recent snapshot dates
        snapshot_dates = list(
            DemandForecast.objects
            .filter(demand_date__lte=today)
            .values_list('demand_date', flat=True)
            .distinct()
            .order_by('-demand_date')[:2]
        )
        current_date = snapshot_dates[0] if len(snapshot_dates) >= 1 else None
        previous_date = snapshot_dates[1] if len(snapshot_dates) >= 2 else None

        current_doh = _weighted_doh(current_date)
        previous_doh = _weighted_doh(previous_date)

        if current_doh is not None and previous_doh and previous_doh != 0:
            pct_change = (current_doh - previous_doh) / previous_doh * 100.0
        else:
            pct_change = None

        # Build weekly trend: one data point per snapshot date in the last 90 days
        trend_qs = _apply_filters(
            DemandForecast.objects.filter(demand_date__gte=trend_start, demand_date__lte=today)
        )
        weekly_rows = (
            trend_qs
            .values('demand_date')
            .annotate(
                total_on_hand=Sum('saleable_qty_on_hand', filter=Q(forecast_qty_7day__gt=0)),
                total_forecast=Sum('forecast_qty_7day', filter=Q(forecast_qty_7day__gt=0)),
            )
            .order_by('demand_date')
        )

        bucket_to_payload = {}
        for row in weekly_rows:
            on_hand = row['total_on_hand'] or 0
            forecast = row['total_forecast'] or 0
            doh = round(on_hand / (forecast / 7.0), 2) if forecast > 0 else 0.0
            bucket_to_payload[row['demand_date']] = {'value': doh}

        logger.info(
            "DOH summary — current: %s (%.2f days), previous: %s (%.2f days)",
            current_date,
            current_doh or 0.0,
            previous_date,
            previous_doh or 0.0,
        )

        return {
            'current_week_avg_doh': round(current_doh, 2) if current_doh is not None else None,
            'previous_week_avg_doh': round(previous_doh, 2) if previous_doh is not None else None,
            'pct_change': round(pct_change, 2) if pct_change is not None else None,
            'bucket_to_payload': bucket_to_payload,
        }

    @staticmethod
    def get_material_forecast_detail(mat_nbr, current_week, previous_week):
        """
        Returns formularies and 28-day-prior sales/forecast for a material
        for two provided week dates.

        For each week, aggregates qty_ordered (sales) and forecast_qty_7day
        over the 4 weeks immediately before that week (demand_date in
        [week - 28 days, week - 7 days]).
        """

        logger.info(
            "Getting material forecast detail for %s: current_week=%s, previous_week=%s",
            mat_nbr, current_week, previous_week
        )

        formularies = list(
            MaterialFormulary.objects.filter(material__mat_nbr=mat_nbr)
            .values('id', 'parent_program', 'program', 'contract_number', 'sales_group')
        )

        def aggregate_prior(week):
            start = week - timedelta(days=28)
            end = week - timedelta(days=7)
            return DemandForecast.objects.filter(
                material__mat_nbr=mat_nbr,
                demand_date__gte=start,
                demand_date__lte=end,
            ).aggregate(
                total_qty_ordered=Sum('qty_ordered'),
                total_forecast=Sum('forecast_qty_7day'),
                total_shipped_qty=Sum('shipped_qty'),
            )

        current = aggregate_prior(current_week)
        previous = aggregate_prior(previous_week)

        return {
            'formularies': formularies,
            'current_period': {
                'week': current_week,
                'sales_28d_prior': current['total_qty_ordered'],
                'forecast_28d_prior': current['total_forecast'],
                'shipped_qty_28d_prior': current['total_shipped_qty'],
            },
            'previous_period': {
                'week': previous_week,
                'sales_28d_prior': previous['total_qty_ordered'],
                'forecast_28d_prior': previous['total_forecast'],
                'shipped_qty_28d_prior': previous['total_shipped_qty'],
            },
        }
