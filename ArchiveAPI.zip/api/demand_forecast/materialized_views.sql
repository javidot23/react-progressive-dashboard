DROP MATERIALIZED VIEW IF EXISTS demand_forecast_inventory_bands_weekly_mv CASCADE;

CREATE MATERIALIZED VIEW demand_forecast_inventory_bands_weekly_mv AS
SELECT
    DATE_TRUNC('week', df.demand_date)::date AS week_start,
    -- Inventory band counts (for MaterialInventoryBandView)
    COUNT(DISTINCT df.mat_nbr) FILTER (
        WHERE df.forecast_qty_7day > 0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) >= 0.0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) <= 10.0
    ) AS low_count,
    COUNT(DISTINCT df.mat_nbr) FILTER (
        WHERE df.forecast_qty_7day > 0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) > 10.0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) <= 60.0
    ) AS acceptable_count,
    COUNT(DISTINCT df.mat_nbr) FILTER (
        WHERE df.forecast_qty_7day > 0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) > 60.0
    ) AS overstock_count,
    COUNT(DISTINCT df.mat_nbr) FILTER (
        WHERE df.forecast_qty_7day = 0
    ) AS no_forecast_count,
    -- Weekly totals for all numeric fields (reusable for any weekly chart)
    SUM(df.qty_ordered) AS total_qty_ordered,
    SUM(df.forecast_qty_7day) AS total_forecast_qty,
    SUM(df.shipped_qty) AS total_shipped_qty,
    SUM(df.received_qty) AS total_received_qty,
    SUM(df.qty_ordered_alt_serve) AS total_qty_ordered_alt_serve,
    SUM(df.demand_7day) AS total_demand_7day,
    AVG(df.on_order_qty) AS avg_on_order_qty,
    SUM(df.transfer_in_qty) AS total_transfer_in_qty,
    SUM(df.transfer_out_qty) AS total_transfer_out_qty,
    SUM(df.inbound_qty_ordered) AS total_inbound_qty_ordered,
    AVG(df.saleable_qty_on_hand) AS avg_saleable_qty_on_hand,
    SUM(df.unrestricted_qty_on_hand) AS total_unrestricted_qty_on_hand
FROM demand_forecast df
WHERE df.demand_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY DATE_TRUNC('week', df.demand_date)::date;

-- Create indexes for fast lookups
CREATE UNIQUE INDEX idx_inv_bands_weekly_week ON demand_forecast_inventory_bands_weekly_mv(week_start);

-- ============================================================================
-- 2. Total Inventory Bands Aggregation (Latest Snapshot)
-- ============================================================================
-- Pre-computes total material counts for the latest global demand_date snapshot

DROP MATERIALIZED VIEW IF EXISTS demand_forecast_inventory_bands_total_mv CASCADE;

CREATE MATERIALIZED VIEW demand_forecast_inventory_bands_total_mv AS
SELECT
    1 AS id,  -- Dummy ID for Django ORM
    MIN(df.demand_date) AS start_date,
    MAX(df.demand_date) AS end_date,
    -- Low inventory band (0-10 DOH)
    COUNT(DISTINCT df.mat_nbr) FILTER (
        WHERE df.forecast_qty_7day > 0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) >= 0.0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) <= 10.0
    ) AS low_count,
    -- Acceptable inventory band (11-60 DOH)
    COUNT(DISTINCT df.mat_nbr) FILTER (
        WHERE df.forecast_qty_7day > 0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) > 10.0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) <= 60.0
    ) AS acceptable_count,
    -- Overstock inventory band (61+ DOH)
    COUNT(DISTINCT df.mat_nbr) FILTER (
        WHERE df.forecast_qty_7day > 0
        AND (df.saleable_qty_on_hand::float / (df.forecast_qty_7day::float / 7.0)) > 60.0
    ) AS overstock_count,
    -- No forecast
    COUNT(DISTINCT df.mat_nbr) FILTER (
        WHERE df.forecast_qty_7day = 0
    ) AS no_forecast_count,
    -- Network-weighted days on hand (DOH) for all materials with forecast:
    -- SUM(on_hand) / SUM(daily_forecast)
    (
        SUM(df.saleable_qty_on_hand::float) FILTER (
            WHERE df.forecast_qty_7day > 0
        )
        / NULLIF(
            SUM(df.forecast_qty_7day::float / 7.0) FILTER (
                WHERE df.forecast_qty_7day > 0
            ),
            0
        )
    ) AS avg_doh
FROM demand_forecast df
WHERE df.demand_date = (
    SELECT MAX(df_latest.demand_date)
    FROM demand_forecast df_latest
);


-- ============================================================================
-- 3. Weekly Material Aggregation (Last 90 Days)
-- ============================================================================
-- Pre-aggregates forecast and order data per material per week

DROP MATERIALIZED VIEW IF EXISTS demand_forecast_weekly_material_mv CASCADE;

CREATE MATERIALIZED VIEW demand_forecast_weekly_material_mv AS
SELECT
    ROW_NUMBER() OVER (ORDER BY DATE_TRUNC('week', df.demand_date)::date, df.mat_nbr) AS id,
    DATE_TRUNC('week', df.demand_date)::date AS week_start,
    df.mat_nbr AS material,
    SUM(df.forecast_qty_7day) AS total_forecast,
    SUM(df.qty_ordered) AS total_qty_ordered,
    SUM(df.qty_ordered_alt_serve) AS total_qty_ordered_alt_serve
FROM demand_forecast df
WHERE df.demand_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY DATE_TRUNC('week', df.demand_date)::date, df.mat_nbr;

CREATE UNIQUE INDEX idx_weekly_material_id ON demand_forecast_weekly_material_mv(id);
CREATE INDEX idx_weekly_material_week ON demand_forecast_weekly_material_mv(week_start);
CREATE INDEX idx_weekly_material_mat ON demand_forecast_weekly_material_mv(material);
CREATE INDEX idx_weekly_material_composite ON demand_forecast_weekly_material_mv(week_start, material);

-- ============================================================================
-- 4. Material-Plant Aggregation for Low Inventory (Last 90 Days)
-- ============================================================================
-- Pre-aggregates data per material and plant for last 90 days
-- Used by MaterialsLowInventoryView for fast queries

DROP MATERIALIZED VIEW IF EXISTS demand_forecast_material_plant_mv CASCADE;

CREATE MATERIALIZED VIEW demand_forecast_material_plant_mv AS
WITH latest_values AS (
    SELECT DISTINCT ON (df.mat_nbr, df.plant_nbr)
        df.mat_nbr,
        df.plant_nbr,
        df.saleable_qty_on_hand AS latest_saleable_qty_on_hand,
        df.on_order_qty AS latest_on_order_qty,
        df.forecast_qty_7day AS latest_forecast_qty_7day
    FROM demand_forecast df
    WHERE df.demand_date >= CURRENT_DATE - INTERVAL '90 days'
    ORDER BY df.mat_nbr, df.plant_nbr, df.demand_date DESC
)
SELECT
    ROW_NUMBER() OVER (ORDER BY df.mat_nbr, df.plant_nbr) AS id,
    df.mat_nbr AS material,
    df.plant_nbr AS plant,
    SUM(df.shipped_qty) AS total_shipped_qty,
    SUM(df.qty_ordered) AS total_qty_ordered,
    lv.latest_saleable_qty_on_hand,
    lv.latest_on_order_qty,
    lv.latest_forecast_qty_7day
FROM demand_forecast df
LEFT JOIN latest_values lv ON df.mat_nbr = lv.mat_nbr AND df.plant_nbr = lv.plant_nbr
WHERE df.demand_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY df.mat_nbr, df.plant_nbr, lv.latest_saleable_qty_on_hand, lv.latest_on_order_qty, lv.latest_forecast_qty_7day;

CREATE UNIQUE INDEX idx_material_plant_id ON demand_forecast_material_plant_mv(id);
CREATE INDEX idx_material_plant_mat ON demand_forecast_material_plant_mv(material);
CREATE INDEX idx_material_plant_plant ON demand_forecast_material_plant_mv(plant);
CREATE INDEX idx_material_plant_composite ON demand_forecast_material_plant_mv(material, plant);
