from rest_framework import serializers


class DataUpdateHistorySerializer(serializers.Serializer):
    """
    Serializer for data update history aggregated by table name.
    """
    table_name = serializers.CharField()
    last_updated = serializers.DateTimeField()
