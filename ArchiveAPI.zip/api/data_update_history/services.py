from django.db.models import Max

from api.data_update_history.models import DataUpdateHistory


class DataUpdateHistoryService:
    """
    Service class for DataUpdateHistory operations.
    """

    @staticmethod
    def get_latest_update_by_table():
        """
        Retrieve the latest update date for each table name.
        :return: QuerySet of DataUpdateHistory objects with the latest last_updated per table_name.
        """
        # Get the latest last_updated for each table_name
        latest_updates = (
            DataUpdateHistory.objects
            .values('table_name')
            .annotate(last_updated=Max('last_updated'))
            .order_by('table_name')
        )

        # Convert to a list of DataUpdateHistory-like objects
        # We'll return the aggregated queryset which can be serialized
        return latest_updates
