from django.db import models


class DataUpdateHistory(models.Model):
    table_name = models.CharField(max_length=255)
    last_updated = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'data_update_history'
        verbose_name = 'Data Update History'
        verbose_name_plural = 'Data Update Histories'
