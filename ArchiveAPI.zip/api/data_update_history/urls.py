from django.urls import path

from .views import DataUpdateHistoryListView

app_name = "data-update-history"

urlpatterns = [
    path("", DataUpdateHistoryListView.as_view(), name="data-update-history-list"),
]
