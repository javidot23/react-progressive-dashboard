from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework import generics
from rest_framework.response import Response

from api.data_update_history.serializers import DataUpdateHistorySerializer
from api.data_update_history.services import DataUpdateHistoryService


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class DataUpdateHistoryListView(generics.ListAPIView):
    """
    API view to retrieve the latest update date for each table name.
    """
    serializer_class = DataUpdateHistorySerializer

    def get_queryset(self):
        """
        Get the latest update date for each table name.
        """
        return DataUpdateHistoryService.get_latest_update_by_table()

    def list(self, request, *args, **kwargs):
        """
        Override list to handle the aggregated queryset properly.
        """
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
