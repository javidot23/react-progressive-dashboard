from django.apps import AppConfig


class DataUpdateHistoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.data_update_history'
