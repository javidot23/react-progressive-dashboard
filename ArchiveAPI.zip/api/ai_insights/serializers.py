from rest_framework import serializers

from api.ai_insights.models import AnomalyHeadline, ReferenceParagraphResult


class AnomalyHeadlineSerializer(serializers.ModelSerializer):
    class Meta:
        model = AnomalyHeadline
        fields = "__all__"
        read_only_fields = ("created_at", "updated_at")


class ReferenceParagraphResultSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReferenceParagraphResult
        exclude = ("query",)
        read_only_fields = ("created_at", "updated_at")
