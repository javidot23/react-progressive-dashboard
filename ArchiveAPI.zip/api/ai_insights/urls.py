from django.urls import path

from api.ai_insights.views import AnomalyHeadlineListView, ReferenceParagraphResultListView

app_name = "ai-insights"

urlpatterns = [
    path(
        "anomaly-headlines/",
        AnomalyHeadlineListView.as_view(),
        name="anomaly-headline-list",
    ),
    path(
        "reference-paragraphs/",
        ReferenceParagraphResultListView.as_view(),
        name="reference-paragraph-list",
    ),
]
