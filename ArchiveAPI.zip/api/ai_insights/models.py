from django.db import models


class AnomalyHeadline(models.Model):
    """AI-generated anomaly headline for a portfolio visual signal."""

    run_id = models.BigIntegerField()
    run_timestamp = models.DateTimeField()
    visual = models.CharField(max_length=255)
    sentiment = models.CharField(max_length=255)
    headline_text = models.TextField()
    subheadline = models.TextField()
    deep_link_label = models.CharField(max_length=255, null=True, blank=True)
    source_signal_id = models.CharField(max_length=255)
    trigger_metric = models.CharField(max_length=255, null=True, blank=True)
    deviation_magnitude = models.FloatField(null=True, blank=True)
    metrics_json = models.JSONField(default=dict, blank=True)
    priority_rank = models.IntegerField(null=True, blank=True)
    is_winner = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "anomaly_headlines"
        verbose_name = "Anomaly Headline"
        verbose_name_plural = "Anomaly Headlines"
        unique_together = [("run_id", "source_signal_id")]
        indexes = [
            models.Index(fields=["run_id"]),
            models.Index(fields=["is_winner"]),
            models.Index(fields=["priority_rank"]),
        ]

    def __str__(self):
        return f"{self.source_signal_id} (run {self.run_id})"


class ReferenceParagraphResult(models.Model):
    """AI-generated reference paragraph for portfolio narrative layout."""

    run_id = models.BigIntegerField()
    run_timestamp = models.DateTimeField()
    paragraph_id = models.CharField(max_length=255)
    visual = models.CharField(max_length=255, null=True, blank=True)
    layout_type = models.CharField(max_length=255, null=True, blank=True)
    position = models.CharField(max_length=255, null=True, blank=True)
    response_template = models.TextField(null=True, blank=True)
    query = models.TextField(null=True, blank=True)
    rendered_paragraph = models.TextField()
    metrics_json = models.JSONField(default=dict, blank=True)
    status = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "reference_paragraph_results"
        verbose_name = "Reference Paragraph Result"
        verbose_name_plural = "Reference Paragraph Results"
        unique_together = [("run_id", "paragraph_id")]
        indexes = [
            models.Index(fields=["run_id"]),
            models.Index(fields=["visual"]),
        ]

    def __str__(self):
        return f"{self.paragraph_id} (run {self.run_id})"
