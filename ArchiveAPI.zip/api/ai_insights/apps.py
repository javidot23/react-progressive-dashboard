from django.apps import AppConfig


class AiInsightsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.ai_insights"
