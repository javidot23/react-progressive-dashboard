from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from api.ai_insights.serializers import (
    AnomalyHeadlineSerializer,
    ReferenceParagraphResultSerializer,
)
from api.ai_insights.services import AnomalyHeadlineService, ReferenceParagraphResultService


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="get")
@extend_schema_view(
    get=extend_schema(
        tags=["AI Insights"],
        summary="List latest winning anomaly headlines",
        description=(
            "Returns anomaly headlines for the latest run where ``is_winner=true``, "
            "ordered by ``priority_rank``."
        ),
        responses=AnomalyHeadlineSerializer(many=True),
    ),
)
class AnomalyHeadlineListView(APIView):
    """Return winning anomaly headlines for the latest run."""

    def get(self, request):
        headlines = AnomalyHeadlineService.get_latest_winners()
        serializer = AnomalyHeadlineSerializer(headlines, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)), name="get")
@extend_schema_view(
    get=extend_schema(
        tags=["AI Insights"],
        summary="List latest reference paragraphs",
        description=(
            "Returns reference paragraphs for the latest run, ordered by ``paragraph_id``. "
            "The Databricks SQL ``query`` field is stored but not returned."
        ),
        responses=ReferenceParagraphResultSerializer(many=True),
    ),
)
class ReferenceParagraphResultListView(APIView):
    """Return reference paragraphs for the latest run."""

    def get(self, request):
        paragraphs = ReferenceParagraphResultService.get_latest()
        serializer = ReferenceParagraphResultSerializer(paragraphs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
