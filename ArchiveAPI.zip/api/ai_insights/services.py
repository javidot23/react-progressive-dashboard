import logging

from django.db.models import Max

from api.ai_insights.models import AnomalyHeadline, ReferenceParagraphResult

logger = logging.getLogger(__name__)


class AnomalyHeadlineService:
    @staticmethod
    def get_latest_winners():
        """Return winning headlines for the latest run, ordered by priority."""
        latest_run_id = (
            AnomalyHeadline.objects.filter(is_winner=True)
            .aggregate(latest=Max("run_id"))
            .get("latest")
        )
        if latest_run_id is None:
            logger.info("No anomaly headline winners found")
            return AnomalyHeadline.objects.none()

        logger.info("Retrieving anomaly headline winners for run_id=%s", latest_run_id)
        return AnomalyHeadline.objects.filter(
            is_winner=True,
            run_id=latest_run_id,
        ).order_by("priority_rank")


class ReferenceParagraphResultService:
    @staticmethod
    def get_latest():
        """Return reference paragraphs for the latest run, ordered by paragraph_id."""
        latest_run_id = (
            ReferenceParagraphResult.objects.aggregate(latest=Max("run_id")).get("latest")
        )
        if latest_run_id is None:
            logger.info("No reference paragraph results found")
            return ReferenceParagraphResult.objects.none()

        logger.info("Retrieving reference paragraphs for run_id=%s", latest_run_id)
        return ReferenceParagraphResult.objects.filter(run_id=latest_run_id).order_by(
            "paragraph_id"
        )
