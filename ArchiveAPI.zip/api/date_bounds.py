"""Shared calendar date helpers for KPI windows."""
from datetime import date, timedelta


def iso_week_bounds(as_of: date | None = None) -> tuple[date, date, date, date]:
    """
    Return ISO calendar week bounds (Monday start).

    Returns:
        (this_week_start, this_week_end, last_week_start, last_week_end)

    - This week: Monday of the current week through as_of (inclusive).
    - Last week: previous Monday through previous Sunday (inclusive).
    """
    as_of = as_of or date.today()
    this_week_start = as_of - timedelta(days=as_of.weekday())
    this_week_end = as_of
    last_week_start = this_week_start - timedelta(days=7)
    last_week_end = this_week_start - timedelta(days=1)
    return this_week_start, this_week_end, last_week_start, last_week_end
