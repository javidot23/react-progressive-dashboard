from django.db import models

from api.vendor.models import Vendor


class ChargebackGenerationStatus(models.Model):
    week_bucket = models.DateField()
    vendor_nbr = models.ForeignKey(
        Vendor,
        to_field="vendor_nbr",
        db_column="vendor_nbr",
        on_delete=models.CASCADE,
    )
    chargebacks_generated_units = models.DecimalField(max_digits=18, decimal_places=3, null=True, blank=True)
    not_generated_units = models.DecimalField(max_digits=18, decimal_places=3, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "chargeback_generation_status"
        verbose_name = "Chargeback Generation Status"
        verbose_name_plural = "Chargeback Generation Statuses"
        unique_together = [("week_bucket", "vendor_nbr")]
        indexes = [
            models.Index(fields=["week_bucket"]),
            models.Index(fields=["vendor_nbr"]),
        ]
