from django.apps import AppConfig


class ChargebackGenerationStatusConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.chargeback_generation_status"
