from datetime import date

from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class ChargebackGenerationStatusModelTest(BaseTestCase):

    def test_create_chargeback_generation_status(self):
        vendor = TestDataFactory.create_vendor()
        record = TestDataFactory.create_chargeback_generation_status(
            vendor=vendor,
            week_bucket=date(2025, 1, 6),
            chargebacks_generated_units=5000.0,
            not_generated_units=200.0,
        )
        self.assertEqual(record.vendor_nbr, vendor)
        self.assertEqual(record.week_bucket, date(2025, 1, 6))
        self.assertEqual(float(record.chargebacks_generated_units), 5000.0)

    def test_unique_together_week_vendor(self):
        from django.db import IntegrityError
        vendor = TestDataFactory.create_vendor()
        week = date(2025, 1, 6)
        TestDataFactory.create_chargeback_generation_status(vendor=vendor, week_bucket=week)
        with self.assertRaises(IntegrityError):
            TestDataFactory.create_chargeback_generation_status(vendor=vendor, week_bucket=week)
