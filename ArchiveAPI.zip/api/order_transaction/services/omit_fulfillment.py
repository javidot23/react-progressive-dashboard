import logging
from datetime import date, timedelta

from api.csv_export import csv_cell, csv_date, csv_percentage
from django.db.models import (
    BigIntegerField,
    Case,
    DateField,
    ExpressionWrapper,
    F,
    FloatField,
    IntegerField,
    OuterRef,
    Subquery,
    Sum,
    Value,
    When,
)
from django.db.models.functions import Coalesce, Cast

from api.demand_forecast.materialized_view_models import DemandForecastMaterialPlantMV
from api.material.models import Material
from api.order_transaction.materialized_view_models import (
    OrderTransactionMaterial90dMV,
    OrderTransactionWeeklyTotalsMV,
    OrderTransactionWeeklyMaterialMV,
    OrderTransactionWeeklyOmitSummaryMV,
)
from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV

logger = logging.getLogger(__name__)


class OmitFulfillmentMixin:
    UNFILLED_MATERIALS_CSV_HEADERS = [
        "Product Name",
        "Product ID",
        "NDC",
        "Unfilled Quantity",
        "Ordered Quantity",
        "Outbound Fill Rate",
        "On Hand",
        "7-day Forecast",
        "28-day Forecast",
        "Next Expected Arrival",
        "On Order",
    ]

    @classmethod
    def iter_unfilled_materials_csv_rows(cls, queryset, chunk_size=2000):
        """Yield CSV header and unfilled-material rows without loading the full export."""
        yield list(cls.UNFILLED_MATERIALS_CSV_HEADERS)
        for row in queryset.iterator(chunk_size=chunk_size):
            outbound = getattr(row, "outbound_fill_rate", None)
            outbound_pct = 100.0 * outbound if outbound is not None else None
            yield [
                csv_cell(getattr(row, "material_name", None)),
                csv_cell(getattr(row, "material_number", None)),
                csv_cell(getattr(row, "ndc", None)),
                csv_cell(getattr(row, "unfilled_quantity", None)),
                csv_cell(getattr(row, "ordered_quantity", None)),
                csv_percentage(outbound_pct),
                csv_cell(getattr(row, "saleable_qty_on_hand", None)),
                csv_cell(getattr(row, "forecast_qty_7day", None)),
                csv_cell(getattr(row, "forecast_qty_28day", None)),
                csv_date(getattr(row, "next_expected_arrival_date", None)),
                csv_cell(getattr(row, "on_order_qty", None)),
            ]

    @staticmethod
    def get_material_omit_counts_for_period(start_date, end_date, direct_mat_nbr=None, mat_nbr_subquery=None,
                                            fill_rate_threshold=0.85, corp_chain_nbr=None):
        """
        Get distinct count of materials with different omit types based on fill_rate for the 90-day period.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        materials_data = OrderTransactionMaterial90dMV.objects.all()

        if corp_chain_nbr:
            materials_data = materials_data.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            materials_data = materials_data.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            materials_data = materials_data.filter(material__mat_nbr__in=mat_nbr_subquery)

        # Roll up to one row per material (sum across corp_chains), then compute
        # aggregate fill_rate so a material lands in exactly one bucket regardless
        # of how many corp_chain rows it has. The *_pos columns cover demand lines
        # only, so returns cannot shrink the denominator.
        per_material = list(
            materials_data.values('material').annotate(
                agg_order_qty=Sum('total_order_qty_pos'),
                agg_shipped_qty=Sum('total_shipped_qty_pos'),
            )
        )

        excess_count = 0
        allowed_count = 0
        no_omits_count = 0
        for row in per_material:
            ordered = row['agg_order_qty'] or 0
            shipped = row['agg_shipped_qty'] or 0
            fill_rate = float(shipped) / float(ordered) if ordered > 0 else 0.0
            if fill_rate < fill_rate_threshold:
                excess_count += 1
            elif fill_rate < 1.0:
                allowed_count += 1
            else:
                no_omits_count += 1

        total_products_ordered = len(per_material)

        return {
            "excess_omits_count": excess_count,
            "allowed_omits_count": allowed_count,
            "no_omits_count": no_omits_count,
            "total_products_ordered": total_products_ordered,
            "total_products_with_omits": excess_count + allowed_count,
        }

    @staticmethod
    def list_unfilled_materials(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Materials with aggregate fill rate under 1.0 over the last 90 days.

        Same OrderTransactionMaterial90dMV universe as omit counts. Enriches with
        material inventory/forecast, demand-forecast on-order, and next open PO arrival.
        """
        logger.info("Listing unfilled materials (fill_rate < 1.0) for last 90 days")

        today = date.today()

        ot_base = OrderTransactionMaterial90dMV.objects.all()
        if corp_chain_nbr:
            ot_base = ot_base.filter(corp_chain=corp_chain_nbr)

        ordered_sq = (
            ot_base.filter(material=OuterRef("mat_nbr"))
            .values("material")
            .annotate(total=Sum("total_order_qty"))
            .values("total")[:1]
        )
        shipped_sq = (
            ot_base.filter(material=OuterRef("mat_nbr"))
            .values("material")
            .annotate(total=Sum("total_shipped_qty"))
            .values("total")[:1]
        )
        demand_sq = (
            ot_base.filter(material=OuterRef("mat_nbr"))
            .values("material")
            .annotate(total=Sum("total_order_qty_pos"))
            .values("total")[:1]
        )
        demand_shipped_sq = (
            ot_base.filter(material=OuterRef("mat_nbr"))
            .values("material")
            .annotate(total=Sum("total_shipped_qty_pos"))
            .values("total")[:1]
        )
        on_order_sq = (
            DemandForecastMaterialPlantMV.objects.filter(material=OuterRef("mat_nbr"))
            .values("material")
            .annotate(total=Sum("latest_on_order_qty"))
            .values("total")[:1]
        )
        next_arrival_sq = (
            PurchaseOrderLatest90dMV.objects.filter(
                material=OuterRef("mat_nbr"),
                completion_date__isnull=True,
                anticipated_date__isnull=False,
            )
            .annotate(
                priority=Case(
                    When(anticipated_date__gte=today, then=Value(0)),
                    default=Value(1),
                    output_field=IntegerField(),
                )
            )
            .order_by("priority", "anticipated_date", "id")
            .values("anticipated_date")[:1]
        )

        qs = Material.objects.all()
        if direct_mat_nbr:
            qs = qs.filter(mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(mat_nbr__in=mat_nbr_subquery)

        return (
            qs.annotate(
                ordered_quantity=Coalesce(
                    Subquery(ordered_sq, output_field=BigIntegerField()),
                    Value(0),
                    output_field=BigIntegerField(),
                ),
                shipped_quantity=Coalesce(
                    Subquery(shipped_sq, output_field=BigIntegerField()),
                    Value(0),
                    output_field=BigIntegerField(),
                ),
                demand_quantity=Coalesce(
                    Subquery(demand_sq, output_field=BigIntegerField()),
                    Value(0),
                    output_field=BigIntegerField(),
                ),
                demand_shipped_quantity=Coalesce(
                    Subquery(demand_shipped_sq, output_field=BigIntegerField()),
                    Value(0),
                    output_field=BigIntegerField(),
                ),
            )
            .annotate(
                unfilled_quantity=F("demand_quantity") - F("demand_shipped_quantity"),
                fill_rate=Case(
                    When(
                        demand_quantity__gt=0,
                        then=ExpressionWrapper(
                            Cast(F("demand_shipped_quantity"), FloatField())
                            / Cast(F("demand_quantity"), FloatField()),
                            output_field=FloatField(),
                        ),
                    ),
                    default=Value(0.0),
                    output_field=FloatField(),
                ),
                material_number=F("mat_nbr"),
                material_name=F("name"),
                forecast_qty_28day=F("forecast_qty_7day") * Value(4),
                on_order_qty=Coalesce(
                    Subquery(on_order_sq, output_field=IntegerField()),
                    Value(0),
                    output_field=IntegerField(),
                ),
                next_expected_arrival_date=Subquery(
                    next_arrival_sq, output_field=DateField()
                ),
            )
            .filter(demand_quantity__gt=0, fill_rate__lt=1.0)
            .order_by("-unfilled_quantity", "material_number")
        )

    @staticmethod
    def get_material_omit_counts_for_last_three_months_weekly(direct_mat_nbr=None, mat_nbr_subquery=None,
                                                              fill_rate_threshold=0.85, corp_chain_nbr=None):
        """
        Weekly distinct material omit counts for the last 3 months (approx 12 weeks).
        Uses optimized subquery pattern to avoid expensive JOINs.
        The fast path (WeeklyOmitSummaryMV) has no cust_corp_chain_nbr dimension, so it is
        bypassed whenever a corp_chain filter is active.
        """
        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        if not direct_mat_nbr and mat_nbr_subquery is None and fill_rate_threshold == 0.85 and not corp_chain_nbr:
            logger.info("Retrieving weekly omit counts from pre-aggregated summary MV (fast path)")
            weekly_aggregated = (
                OrderTransactionWeeklyOmitSummaryMV.objects
                .values("year", "week", "excess_omits_count", "allowed_omits_count", "no_omits_count")
                .order_by("year", "week")
            )
        else:
            logger.info("Retrieving weekly omit counts with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.all()
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

            # MV is now at (year, week, mat_nbr, corp_chain) granularity.
            # Group by (year, week, material) first to get the aggregate fill_rate
            # per material per week across all corp_chains, then bucket in Python
            # so each material lands in exactly one omit bucket per week.
            per_mat_week = list(
                queryset.values('year', 'week', 'material_id').annotate(
                    agg_ordered=Sum('total_ordered'),
                    agg_shipped=Sum('total_shipped'),
                )
            )

            weekly_buckets = {}
            for row in per_mat_week:
                key = (row['year'], row['week'])
                if key not in weekly_buckets:
                    weekly_buckets[key] = {
                        'year': row['year'], 'week': row['week'],
                        'excess_omits_count': 0,
                        'allowed_omits_count': 0,
                        'no_omits_count': 0,
                    }
                ordered = row['agg_ordered'] or 0
                shipped = row['agg_shipped'] or 0
                fill_rate = float(shipped) / float(ordered) if ordered > 0 else 0.0
                if fill_rate < fill_rate_threshold:
                    weekly_buckets[key]['excess_omits_count'] += 1
                elif fill_rate < 1.0:
                    weekly_buckets[key]['allowed_omits_count'] += 1
                else:
                    weekly_buckets[key]['no_omits_count'] += 1

            weekly_aggregated = [weekly_buckets[k] for k in sorted(weekly_buckets.keys())]

        # Convert to final format with date calculations
        weekly_results = []
        for data in weekly_aggregated:
            year = data["year"]
            week = data["week"]

            # Helper to get week start (Monday) and end (Sunday) from ISO year/week
            from datetime import date as dt
            jan4 = dt(year, 1, 4)
            delta = timedelta(days=jan4.isoweekday() - 1)
            week1_monday = jan4 - delta
            week_monday = week1_monday + timedelta(weeks=week - 1)
            week_sunday = week_monday + timedelta(days=6)

            # Skip weeks entirely outside the 90-day window
            if week_sunday < start_date or week_monday > end_date:
                continue

            weekly_results.append({
                "year": year,
                "week": week,
                "week_start": week_monday,
                "week_end": week_sunday,
                "excess_omits_count": data["excess_omits_count"],
                "allowed_omits_count": data["allowed_omits_count"],
                "no_omits_count": data["no_omits_count"],
            })

        return weekly_results

    @staticmethod
    def get_fulfillment_metrics_weekly(start_date, end_date, direct_mat_nbr=None, mat_nbr_subquery=None,
                                       corp_chain_nbr=None):
        """
        Calculates unshipped quantity and fulfillment percentage per week for a given period.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        if not direct_mat_nbr and mat_nbr_subquery is None:
            logger.info("Using materialized view (fast path)")
            totals_qs = OrderTransactionWeeklyTotalsMV.objects.all()
            if corp_chain_nbr:
                totals_qs = totals_qs.filter(corp_chain=corp_chain_nbr)
            weekly_metrics = (
                totals_qs
                .values("year", "week", "week_start")
                .annotate(
                    total_ordered=Sum('total_ordered'),
                    total_shipped=Sum('total_shipped')
                )
                .order_by("year", "week")
            )
        else:
            logger.info("Using weekly material MV with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(
                week_start__gte=start_date, week_start__lte=end_date
            )
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            weekly_metrics = (
                queryset
                .values("year", "week", "week_start")
                .annotate(
                    total_ordered=Sum('total_ordered'),
                    total_shipped=Sum('total_shipped')
                )
                .order_by("year", "week")
            )

        def iso_week_bounds(year, week):
            from datetime import date as dt
            jan4 = dt(year, 1, 4)
            delta = timedelta(days=jan4.isoweekday() - 1)
            week1_monday = jan4 - delta
            week_monday = week1_monday + timedelta(weeks=week - 1)
            week_sunday = week_monday + timedelta(days=6)
            return week_monday, week_sunday

        results = []
        for metrics in weekly_metrics:
            total_ordered = metrics.get("total_ordered") or 0
            total_shipped = metrics.get("total_shipped") or 0

            unshipped_quantity = total_ordered - total_shipped

            if total_ordered > 0:
                fulfillment_percentage = (total_shipped / total_ordered) * 100
            else:
                fulfillment_percentage = 0.0

            year = metrics["year"]
            week = metrics["week"]
            week_start, week_end = iso_week_bounds(year, week)

            # Clip bounds to requested period
            if week_start < start_date:
                week_start = start_date
            if week_end > end_date:
                week_end = end_date

            results.append({
                "year": year,
                "week": week,
                "week_start": week_start,
                "week_end": week_end,
                "unshipped_quantity": round(unshipped_quantity, 2),
                "fulfillment_percentage": round(fulfillment_percentage, 2),
            })

        return results
