import logging
from datetime import timedelta
from itertools import groupby

from django.db.models import Case, DecimalField, Q, Sum, Value, When
from django.db.models.functions import TruncWeek

from api.order_transaction.models import OrderTransaction

logger = logging.getLogger(__name__)

# Bound to the assembled service class in package __init__.py
OrderTransactionService = None


class SalesComparisonMixin:
    @staticmethod
    def _build_period_qs(current_start, current_end, previous_start, previous_end,
                         direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns (queryset, current_q, previous_q) filtered to both periods
        with optional material and corp chain filters applied.
        """
        current_q = Q(ord_created_date__gte=current_start, ord_created_date__lte=current_end)
        previous_q = Q(ord_created_date__gte=previous_start, ord_created_date__lte=previous_end)

        qs = OrderTransaction.objects.filter(current_q | previous_q)
        if direct_mat_nbr:
            qs = qs.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__mat_nbr__in=mat_nbr_subquery)
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        return qs, current_q, previous_q

    @staticmethod
    def _comparison_annotations(current_q, previous_q):
        """Returns annotate kwargs for the 6 comparison fields."""
        return dict(
            current_period_sales=Sum(
                Case(When(current_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
            ),
            previous_period_sales=Sum(
                Case(When(previous_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
            ),
            current_period_order_qty=Sum(
                Case(When(current_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
            ),
            previous_period_order_qty=Sum(
                Case(When(previous_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
            ),
            current_period_shipped_qty=Sum(
                Case(When(current_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
            ),
            previous_period_shipped_qty=Sum(
                Case(When(previous_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
            ),
        )

    @staticmethod
    def get_sales_comparison_by_sales_group(current_start, current_end, previous_start, previous_end,
                                            direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """Returns sales comparison grouped by sales_group."""
        qs, current_q, previous_q = OrderTransactionService._build_period_qs(
            current_start, current_end, previous_start, previous_end, direct_mat_nbr, mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        logger.info("OT sales comparison by sales_group: %s-%s vs %s-%s",
                    current_start, current_end, previous_start, previous_end)
        return (
            qs.values('sales_group')
            .annotate(**OrderTransactionService._comparison_annotations(current_q, previous_q))
            .order_by('sales_group')
        )

    @staticmethod
    def get_sales_comparison_by_state(current_start, current_end, previous_start, previous_end,
                                      direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """Returns sales comparison grouped by state (via cust_nbr__state)."""
        qs, current_q, previous_q = OrderTransactionService._build_period_qs(
            current_start, current_end, previous_start, previous_end, direct_mat_nbr, mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        logger.info("OT sales comparison by state: %s-%s vs %s-%s",
                    current_start, current_end, previous_start, previous_end)
        return (
            qs.values('cust_nbr__state')
            .annotate(**OrderTransactionService._comparison_annotations(current_q, previous_q))
            .order_by('cust_nbr__state')
        )

    @staticmethod
    def get_sales_comparison_by_material(current_start, current_end, previous_start, previous_end,
                                         direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """Returns sales comparison grouped by material, ordered by current_period_sales desc."""
        qs, current_q, previous_q = OrderTransactionService._build_period_qs(
            current_start, current_end, previous_start, previous_end, direct_mat_nbr, mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        logger.info("OT sales comparison by material: %s-%s vs %s-%s",
                    current_start, current_end, previous_start, previous_end)
        return (
            qs.values('material_id', 'material__name')
            .annotate(**OrderTransactionService._comparison_annotations(current_q, previous_q))
            .order_by('-current_period_sales')
        )

    @staticmethod
    def get_sales_comparison_by_customer(current_start, current_end, previous_start, previous_end,
                                         direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """Returns sales comparison grouped by customer corp chain, ordered by current_period_sales desc."""
        qs, current_q, previous_q = OrderTransactionService._build_period_qs(
            current_start, current_end, previous_start, previous_end, direct_mat_nbr, mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        logger.info("OT sales comparison by customer: %s-%s vs %s-%s",
                    current_start, current_end, previous_start, previous_end)
        return (
            qs.values('cust_corp_chain_nbr_id', 'cust_corp_chain_nbr__name')
            .annotate(**OrderTransactionService._comparison_annotations(current_q, previous_q))
            .order_by('-current_period_sales')
        )

    @staticmethod
    def get_weekly_sales_by_sales_group(current_week, previous_week, direct_mat_nbr=None, mat_nbr_subquery=None,
                                        corp_chain_nbr=None):
        """
        Returns weekly sales per sales_group for two 4-week windows, grouped by week.

        For each provided week date, aggregates sales for the 4 weeks ending at
        (and including) that week. Returns a list of:
          {'week_start': date, 'sales': [{'sales_group', 'sales_amount', 'total_order_qty', 'total_shipped_qty'}]}
        """
        logger.info("OT weekly sales by sales_group: current_week=%s, previous_week=%s", current_week, previous_week)

        current_start = current_week - timedelta(weeks=3)
        current_end = current_week + timedelta(days=6)
        previous_start = previous_week - timedelta(weeks=3)
        previous_end = previous_week + timedelta(days=6)

        qs = OrderTransaction.objects.filter(
            Q(ord_created_date__gte=current_start, ord_created_date__lte=current_end) |
            Q(ord_created_date__gte=previous_start, ord_created_date__lte=previous_end)
        )

        if direct_mat_nbr:
            qs = qs.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__mat_nbr__in=mat_nbr_subquery)
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        rows = (
            qs.annotate(week_start=TruncWeek('ord_created_date'))
            .values('sales_group', 'week_start')
            .annotate(
                sales_amount=Sum('sales_amount'),
                total_order_qty=Sum('total_order_qty'),
                total_shipped_qty=Sum('total_shipped_qty'),
            )
            .order_by('week_start', 'sales_group')
        )

        return [
            {
                'week_start': week_start,
                'sales': [
                    {
                        'sales_group': r['sales_group'],
                        'sales_amount': r['sales_amount'],
                        'total_order_qty': r['total_order_qty'],
                        'total_shipped_qty': r['total_shipped_qty'],
                    }
                    for r in week_rows
                ],
            }
            for week_start, week_rows in groupby(rows, key=lambda r: r['week_start'])
        ]
