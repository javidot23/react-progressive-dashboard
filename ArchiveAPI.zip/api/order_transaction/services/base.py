import logging

from django.db.models import Q

logger = logging.getLogger(__name__)

# Returns are stored as order lines with a negative ``total_order_qty``. They are real
# sales activity but they are not demand, so they must not reach the denominator of a
# fill rate or either side of an omit subtraction. Aggregates that feed those metrics
# restrict to this predicate; display sums of sales and volume do not.
POSITIVE_DEMAND = Q(total_order_qty__gt=0)


def map_scrm_mat_grp_to_category(scrm_mat_grp):
    """
    Maps scrm_mat_grp field values to category names.
    Mapping:
    - Brand: BRX
    - Generic: GRX
    - OTC: OTC
    Args:
        scrm_mat_grp (str): The scrm_mat_grp value from the material table
    Returns:
        str: The category name ('brand', 'generic', 'otc') or None if not mapped
    """
    if not scrm_mat_grp:
        return None

    scrm_mat_grp = scrm_mat_grp.upper()

    # Brand mapping
    if scrm_mat_grp == 'BRX':
        return 'brand'

    # Generic mapping
    if scrm_mat_grp == 'GRX':
        return 'generic'

    # OTC mapping
    if scrm_mat_grp == 'OTC':
        return 'otc'

    return 'otc'


class BaseMixin:
    @staticmethod
    def _build_material_filter(direct_mat_nbr=None, mat_nbr_subquery=None):
        """Build filter dict for material FK fields from subquery pattern."""
        filters = {}
        if direct_mat_nbr:
            filters['material__mat_nbr'] = direct_mat_nbr
        return filters, mat_nbr_subquery
