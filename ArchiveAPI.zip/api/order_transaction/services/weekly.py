import logging
from datetime import date, timedelta

from django.db.models import Case, F, FloatField, Sum, Value, When
from django.db.models.functions import Cast

from api.order_transaction.materialized_view_models import (
    OrderTransactionMaterial90dMV,
    OrderTransactionWeeklyMV,
    OrderTransactionWeeklyMaterialMV,
)

logger = logging.getLogger(__name__)


class WeeklyMixin:
    @staticmethod
    def get_weekly_order_analysis(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns weekly aggregated data for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        if not direct_mat_nbr and mat_nbr_subquery is None:
            logger.info("get_weekly_order_analysis: Using materialized view (fast path)")
            weekly_qs = OrderTransactionWeeklyMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                weekly_qs = weekly_qs.filter(corp_chain=corp_chain_nbr)
            weekly_query = (
                weekly_qs
                .values('week_start')
                .annotate(
                    total_orders=Sum('total_orders'),
                    total_order_qty=Sum('total_order_qty'),
                    total_shipped_qty=Sum('total_shipped_qty'),
                    alt_served_count=Sum('alt_served_count'),
                    substituted_count=Sum('substituted_count'),
                    perfect_orders=Sum('perfect_orders'),
                )
                .annotate(
                    alt_served_percentage=Case(
                        When(total_orders__gt=0,
                             then=100.0 * F('alt_served_count') / F('total_orders')),
                        default=Value(0.0),
                        output_field=FloatField(),
                    ),
                    substituted_percentage=Case(
                        When(total_orders__gt=0,
                             then=100.0 * F('substituted_count') / F('total_orders')),
                        default=Value(0.0),
                        output_field=FloatField(),
                    ),
                    perfect_order_rate=Case(
                        When(total_orders__gt=0,
                             then=100.0 * F('perfect_orders') / F('total_orders')),
                        default=Value(0.0),
                        output_field=FloatField(),
                    )
                )
                .order_by('week_start')
            )
        else:
            logger.info("Using weekly material MV with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            weekly_query = (
                queryset
                .values('week_start')
                .annotate(
                    total_orders=Sum('total_orders'),
                    total_order_qty=Sum('total_ordered'),
                    total_shipped_qty=Sum('total_shipped'),
                    alt_served_count=Sum('alt_served_count'),
                    substituted_count=Sum('substituted_count'),
                    perfect_orders=Sum('perfect_orders'),
                )
                .annotate(
                    alt_served_percentage=Case(
                        When(total_orders__gt=0,
                             then=100.0 * F('alt_served_count') / F('total_orders')),
                        default=Value(0.0),
                        output_field=FloatField(),
                    ),
                    substituted_percentage=Case(
                        When(total_orders__gt=0,
                             then=100.0 * F('substituted_count') / F('total_orders')),
                        default=Value(0.0),
                        output_field=FloatField(),
                    ),
                    perfect_order_rate=Case(
                        When(total_orders__gt=0,
                             then=100.0 * F('perfect_orders') / F('total_orders')),
                        default=Value(0.0),
                        output_field=FloatField(),
                    )
                )
                .order_by('week_start')
            )

        return list(weekly_query)

    @staticmethod
    def get_order_kpi_stats(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns comprehensive order statistics for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Calculating order KPI stats for last 90 days")
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        if not direct_mat_nbr and mat_nbr_subquery is None:
            logger.info("get_order_kpi_stats: Using materialized view (fast path)")
            kpi_qs = OrderTransactionWeeklyMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                kpi_qs = kpi_qs.filter(corp_chain=corp_chain_nbr)
            stats = kpi_qs.aggregate(
                total_orders=Sum('total_orders'),
                total_units=Sum('total_order_qty'),
                alt_served_orders=Sum('alt_served_count'),
                alt_served_units=Sum('alt_served_units'),
                substituted_orders=Sum('substituted_count'),
                substituted_units=Sum('substituted_units'),
                perfect_orders=Sum('perfect_orders')
            )
        else:
            logger.info("Using weekly material MV with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            stats = queryset.aggregate(
                total_orders=Sum('total_orders'),
                total_units=Sum('total_ordered'),
                alt_served_orders=Sum('alt_served_count'),
                alt_served_units=Sum('alt_served_units'),
                substituted_orders=Sum('substituted_count'),
                substituted_units=Sum('substituted_units'),
                perfect_orders=Sum('perfect_orders')
            )

        total_orders = stats['total_orders'] or 0
        total_units = stats['total_units'] or 0

        return {
            'total_orders': total_orders,
            'total_units': total_units,
            'alt_served_orders': stats['alt_served_orders'] or 0,
            'alt_served_units': stats['alt_served_units'] or 0,
            'alt_serve_rate': round(
                (stats['alt_served_orders'] * 100.0 / total_orders) if total_orders > 0 else 0,
                2
            ),
            'substituted_orders': stats['substituted_orders'] or 0,
            'substituted_units': stats['substituted_units'] or 0,
            'substitution_rate': round(
                (stats['substituted_orders'] * 100.0 / total_orders) if total_orders > 0 else 0,
                2
            ),
            'perfect_orders': stats['perfect_orders'] or 0,
            'perfect_order_rate': round(
                (stats['perfect_orders'] * 100.0 / total_orders) if total_orders > 0 else 0,
                2
            )
        }

    @staticmethod
    def get_substitution_alt_serve_kpi_stats(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns substitution and alt serve KPI statistics.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Calculating substitution and alt serve KPI stats for last 90 days")

        queryset = OrderTransactionMaterial90dMV.objects.all()

        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        # Each MV row is (material, corp_chain), so raw .count() inflates by
        # the number of corp_chains per material. Use distinct on material FK.
        total_materials = queryset.values('material').distinct().count()

        materials_with_substitution = (
            queryset.filter(substituted_count__gt=0).values('material').distinct().count()
        )

        materials_with_alt_serve = (
            queryset.filter(alt_served_count__gt=0).values('material').distinct().count()
        )

        substitution_percent = round(
            (materials_with_substitution * 100.0 / total_materials) if total_materials > 0 else 0,
            1
        )

        alt_serve_percent = round(
            (materials_with_alt_serve * 100.0 / total_materials) if total_materials > 0 else 0,
            1
        )

        return {
            'total_materials': total_materials,
            'materials_with_substitution': materials_with_substitution,
            'substitution_percent': substitution_percent,
            'materials_with_alt_serve': materials_with_alt_serve,
            'alt_serve_percent': alt_serve_percent,
        }

    @staticmethod
    def get_weekly_perfect_order_analysis(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns weekly perfect order analysis for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        if not direct_mat_nbr and mat_nbr_subquery is None:
            logger.info("Using materialized view (fast path)")
            weekly_qs = OrderTransactionWeeklyMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                weekly_qs = weekly_qs.filter(corp_chain=corp_chain_nbr)
            weekly_query = (
                weekly_qs
                .values('week_start')
                .annotate(
                    total_orders=Sum('total_orders'),
                    perfect_orders=Sum('perfect_orders'),
                    imperfect_orders=Sum('imperfect_orders')
                )
                .annotate(
                    perfect_order_rate=Case(
                        When(total_orders__gt=0,
                             then=100.0 * F('perfect_orders') / F('total_orders')),
                        default=Value(0.0),
                        output_field=FloatField(),
                    )
                )
                .order_by('week_start')
            )
        else:
            logger.info("Using weekly material MV with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            weekly_query = (
                queryset
                .values('week_start')
                .annotate(
                    total_orders=Sum('total_orders'),
                    perfect_orders=Sum('perfect_orders'),
                    imperfect_orders=Sum('imperfect_orders')
                )
                .annotate(
                    perfect_order_rate=Case(
                        When(total_orders__gt=0,
                             then=100.0 * F('perfect_orders') / F('total_orders')),
                        default=Value(0.0),
                        output_field=FloatField(),
                    )
                )
                .order_by('week_start')
            )

        return list(weekly_query)

    @staticmethod
    def get_weekly_imperfect_line_rate_analysis(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns weekly imperfect line rate analysis for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        if not direct_mat_nbr and mat_nbr_subquery is None:
            logger.info("Using materialized view (fast path)")
            weekly_qs = OrderTransactionWeeklyMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                weekly_qs = weekly_qs.filter(corp_chain=corp_chain_nbr)
            weekly_query = (
                weekly_qs
                .values('week_start')
                .annotate(
                    total_orders=Sum('total_orders'),
                    unpredictable_demand_count=Sum('unpredictable_demand_count'),
                    omit_inflation_count=Sum('omit_inflation_count'),
                    unaligned_forecast_count=Sum('unaligned_forecast_count'),
                    demand_imperfect_count=Sum('demand_imperfect_count')
                )
                .annotate(
                    unpredictable_demand_rate=Case(
                        When(total_orders__gt=0,
                             then=Cast(F('unpredictable_demand_count') * 100.0 / F('total_orders'), FloatField())),
                        default=Value(0.0),
                        output_field=FloatField()
                    ),
                    omit_inflation_rate=Case(
                        When(total_orders__gt=0,
                             then=Cast(F('omit_inflation_count') * 100.0 / F('total_orders'), FloatField())),
                        default=Value(0.0),
                        output_field=FloatField()
                    ),
                    unaligned_forecast_rate=Case(
                        When(total_orders__gt=0,
                             then=Cast(F('unaligned_forecast_count') * 100.0 / F('total_orders'), FloatField())),
                        default=Value(0.0),
                        output_field=FloatField()
                    ),
                    demand_imperfect_rate=Case(
                        When(total_orders__gt=0,
                             then=Cast(F('demand_imperfect_count') * 100.0 / F('total_orders'), FloatField())),
                        default=Value(0.0),
                        output_field=FloatField()
                    )
                )
                .order_by('week_start')
            )
        else:
            logger.info("Using weekly material MV with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            weekly_query = (
                queryset
                .values('week_start')
                .annotate(
                    total_orders=Sum('total_orders'),
                    unpredictable_demand_count=Sum('unpredictable_demand_count'),
                    omit_inflation_count=Sum('omit_inflation_count'),
                    unaligned_forecast_count=Sum('unaligned_forecast_count'),
                    demand_imperfect_count=Sum('demand_imperfect_count')
                )
                .annotate(
                    unpredictable_demand_rate=Case(
                        When(total_orders__gt=0,
                             then=Cast(F('unpredictable_demand_count') * 100.0 / F('total_orders'), FloatField())),
                        default=Value(0.0),
                        output_field=FloatField()
                    ),
                    omit_inflation_rate=Case(
                        When(total_orders__gt=0,
                             then=Cast(F('omit_inflation_count') * 100.0 / F('total_orders'), FloatField())),
                        default=Value(0.0),
                        output_field=FloatField()
                    ),
                    unaligned_forecast_rate=Case(
                        When(total_orders__gt=0,
                             then=Cast(F('unaligned_forecast_count') * 100.0 / F('total_orders'), FloatField())),
                        default=Value(0.0),
                        output_field=FloatField()
                    ),
                    demand_imperfect_rate=Case(
                        When(total_orders__gt=0,
                             then=Cast(F('demand_imperfect_count') * 100.0 / F('total_orders'), FloatField())),
                        default=Value(0.0),
                        output_field=FloatField()
                    )
                )
                .order_by('week_start')
            )

        return list(weekly_query)

    @staticmethod
    def get_weekly_sales_timeline(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns weekly sales totals (sales_amount, order_qty, shipped_qty) for the last 90 days,
        ordered chronologically. Supports global material filters.
        """
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)

        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        logger.info("Retrieving weekly sales timeline from %s", week_filter_date)

        return (
            queryset
            .values('week_start')
            .annotate(
                sales_amount=Sum('total_sales_amount'),
                total_order_qty=Sum('total_ordered'),
                total_shipped_qty=Sum('total_shipped'),
            )
            .order_by('week_start')
        )
