import logging
from datetime import date, timedelta

from django.db.models import F, Sum

from api.order_transaction.materialized_view_models import (
    OrderTransactionWeeklyMV,
    OrderTransactionAltServedStatus90dMV,
    OrderTransactionWeeklyMaterialMV,
    OrderTransactionAltServedCost90dMV,
    OrderTransactionAltServedPlantMaterial90dMV,
    OrderTransactionAltServedClassOfTradeMaterial90dMV,
)
from api.order_transaction.models import OrderTransaction
from .base import map_scrm_mat_grp_to_category

logger = logging.getLogger(__name__)


class AltServedMixin:
    @staticmethod
    def get_alt_served_analysis_by_material_group(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns alt-served analysis by material group for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        if not direct_mat_nbr and mat_nbr_subquery is None:
            logger.info("get_alt_served_analysis_by_material_group: Using materialized view (fast path)")
            weekly_qs = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                weekly_qs = weekly_qs.filter(corp_chain=corp_chain_nbr)
            weekly_mv_data = (
                weekly_qs
                .values('week_start', 'material__scrm_mat_grp')
                .annotate(
                    scrm_mat_grp=F('material__scrm_mat_grp'),
                    alt_served_count=Sum('alt_served_count'),
                    total_orders=Sum('total_orders'),
                )
                .order_by('week_start')
            )
        else:
            logger.info(
                "get_alt_served_analysis_by_material_group: Using weekly material MV with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            weekly_mv_data = (
                queryset
                .values('week_start', 'material__scrm_mat_grp')
                .annotate(
                    scrm_mat_grp=F('material__scrm_mat_grp'),
                    alt_served_count=Sum('alt_served_count'),
                    total_orders=Sum('total_orders'),
                )
                .order_by('week_start')
            )

        # Transform to match expected format
        weekly_dict = {}
        for item in weekly_mv_data:
            week = item['week_start']
            if week not in weekly_dict:
                weekly_dict[week] = {
                    'week_start': week,
                    'generic_alt_served_count': 0,
                    'brand_alt_served_count': 0,
                    'otc_alt_served_count': 0,
                    'week_total': 0,
                    'total_orders': 0,
                }

            scrm_mat_grp = item['scrm_mat_grp']
            count = item['alt_served_count'] or 0
            weekly_dict[week]['week_total'] += count
            weekly_dict[week]['total_orders'] += item['total_orders'] or 0

            # Map scrm_mat_grp to category
            category = map_scrm_mat_grp_to_category(scrm_mat_grp)
            if category == 'generic':
                weekly_dict[week]['generic_alt_served_count'] += count
            elif category == 'brand':
                weekly_dict[week]['brand_alt_served_count'] += count
            elif category == 'otc':
                weekly_dict[week]['otc_alt_served_count'] += count

        # Calculate percentages
        weekly_data = []
        for week, data in sorted(weekly_dict.items()):
            week_total = data['week_total']
            data['generic_alt_served_percentage'] = (
                100.0 * data['generic_alt_served_count'] / week_total if week_total > 0 else 0.0
            )
            data['brand_alt_served_percentage'] = (
                100.0 * data['brand_alt_served_count'] / week_total if week_total > 0 else 0.0
            )
            data['otc_alt_served_percentage'] = (
                100.0 * data['otc_alt_served_count'] / week_total if week_total > 0 else 0.0
            )
            weekly_data.append(data)

        # Get totals by group - aggregate by mapped categories
        if not direct_mat_nbr and mat_nbr_subquery is None:
            totals_qs = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                totals_qs = totals_qs.filter(corp_chain=corp_chain_nbr)
            raw_totals = list(
                totals_qs
                .values('material__scrm_mat_grp')
                .annotate(
                    scrm_mat_grp=F('material__scrm_mat_grp'),
                    alt_served_count=Sum('alt_served_count')
                )
                .order_by('scrm_mat_grp')
            )
        else:
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

            raw_totals = list(queryset.values('material__scrm_mat_grp').annotate(
                scrm_mat_grp=F('material__scrm_mat_grp'),
                alt_served_count=Sum('alt_served_count')
            ).order_by('scrm_mat_grp'))

        # Aggregate by mapped categories
        totals_by_category = {}
        # Map category to display name (OTC should stay uppercase)
        category_display_map = {
            'brand': 'Brand',
            'generic': 'Generic',
            'otc': 'OTC'
        }

        for item in raw_totals:
            scrm_mat_grp = item['scrm_mat_grp']
            count = item['alt_served_count'] or 0
            category = map_scrm_mat_grp_to_category(scrm_mat_grp)

            if category:
                category_display = category_display_map.get(category, category.capitalize())
                if category_display not in totals_by_category:
                    totals_by_category[category_display] = 0
                totals_by_category[category_display] += count

        # Convert to list format expected by serializer
        totals_data = [
            {'material_group': category, 'alt_served_count': count}
            for category, count in totals_by_category.items()
        ]

        total_alt_served = sum(item['alt_served_count'] or 0 for item in totals_data)
        for item in totals_data:
            item['alt_served_percentage'] = round(
                (item['alt_served_count'] * 100.0 / total_alt_served) if total_alt_served > 0 else 0,
                2
            )

        # Get overall stats
        if not direct_mat_nbr and mat_nbr_subquery is None:
            overall_qs = OrderTransactionWeeklyMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                overall_qs = overall_qs.filter(corp_chain=corp_chain_nbr)
            overall_stats = overall_qs.aggregate(
                total_orders=Sum('total_orders'),
                alt_served_orders=Sum('alt_served_count')
            )
            overall_stats['total_orders'] = overall_stats['total_orders'] or 0
            overall_stats['alt_served_orders'] = overall_stats['alt_served_orders'] or 0
        else:
            queryset_all = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset_all = queryset_all.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset_all = queryset_all.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset_all = queryset_all.filter(material__mat_nbr__in=mat_nbr_subquery)

            overall_stats = queryset_all.aggregate(
                total_orders=Sum('total_orders'),
                alt_served_orders=Sum('alt_served_count')
            )
            overall_stats['total_orders'] = overall_stats['total_orders'] or 0
            overall_stats['alt_served_orders'] = overall_stats['alt_served_orders'] or 0

        overall_stats['alt_served_percentage'] = round(
            (overall_stats['alt_served_orders'] * 100.0 / overall_stats['total_orders'])
            if overall_stats['total_orders'] > 0 else 0,
            2
        )

        return {
            'weekly_data': weekly_data,
            'totals_by_group': totals_data,
            'overall_stats': overall_stats,
        }

    @staticmethod
    def get_substitution_analysis_by_material_group(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns substitution analysis by material group for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        if not direct_mat_nbr and mat_nbr_subquery is None:
            logger.info("Using materialized view (fast path)")
            weekly_qs = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                weekly_qs = weekly_qs.filter(corp_chain=corp_chain_nbr)
            weekly_mv_data = (
                weekly_qs
                .values('week_start', 'material__scrm_mat_grp')
                .annotate(
                    scrm_mat_grp=F('material__scrm_mat_grp'),
                    substituted_count=Sum('substituted_count'),
                    total_orders=Sum('total_orders'),
                )
                .order_by('week_start')
            )
        else:
            logger.info(
                "Using weekly material MV with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            weekly_mv_data = (
                queryset
                .values('week_start', 'material__scrm_mat_grp')
                .annotate(
                    scrm_mat_grp=F('material__scrm_mat_grp'),
                    substituted_count=Sum('substituted_count'),
                    total_orders=Sum('total_orders'),
                )
                .order_by('week_start')
            )

        # Transform to match expected format
        weekly_dict = {}
        for item in weekly_mv_data:
            week = item['week_start']
            if week not in weekly_dict:
                weekly_dict[week] = {
                    'week_start': week,
                    'generic_substituted_count': 0,
                    'brand_substituted_count': 0,
                    'otc_substituted_count': 0,
                    'week_total': 0,
                    'total_orders': 0,
                }

            scrm_mat_grp = item['scrm_mat_grp']
            count = item['substituted_count'] or 0
            weekly_dict[week]['week_total'] += count
            weekly_dict[week]['total_orders'] += item['total_orders'] or 0

            # Map scrm_mat_grp to category
            category = map_scrm_mat_grp_to_category(scrm_mat_grp)
            if category == 'generic':
                weekly_dict[week]['generic_substituted_count'] += count
            elif category == 'brand':
                weekly_dict[week]['brand_substituted_count'] += count
            elif category == 'otc':
                weekly_dict[week]['otc_substituted_count'] += count

        # Calculate percentages
        weekly_data = []
        for week, data in sorted(weekly_dict.items()):
            week_total = data['week_total']
            data['generic_substituted_percentage'] = (
                100.0 * data['generic_substituted_count'] / week_total if week_total > 0 else 0.0
            )
            data['brand_substituted_percentage'] = (
                100.0 * data['brand_substituted_count'] / week_total if week_total > 0 else 0.0
            )
            data['otc_substituted_percentage'] = (
                100.0 * data['otc_substituted_count'] / week_total if week_total > 0 else 0.0
            )
            weekly_data.append(data)

        # Get totals by group - aggregate by mapped categories
        if not direct_mat_nbr and mat_nbr_subquery is None:
            totals_qs = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                totals_qs = totals_qs.filter(corp_chain=corp_chain_nbr)
            raw_totals = list(
                totals_qs
                .values('material__scrm_mat_grp')
                .annotate(
                    scrm_mat_grp=F('material__scrm_mat_grp'),
                    substituted_count=Sum('substituted_count')
                )
                .order_by('scrm_mat_grp')
            )
        else:
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

            raw_totals = list(queryset.values('material__scrm_mat_grp').annotate(
                scrm_mat_grp=F('material__scrm_mat_grp'),
                substituted_count=Sum('substituted_count')
            ).order_by('scrm_mat_grp'))

        # Aggregate by mapped categories
        totals_by_category = {}
        # Map category to display name (OTC should stay uppercase)
        category_display_map = {
            'brand': 'Brand',
            'generic': 'Generic',
            'otc': 'OTC'
        }

        for item in raw_totals:
            scrm_mat_grp = item['scrm_mat_grp']
            count = item['substituted_count'] or 0
            category = map_scrm_mat_grp_to_category(scrm_mat_grp)

            if category:
                category_display = category_display_map.get(category, category.capitalize())
                if category_display not in totals_by_category:
                    totals_by_category[category_display] = 0
                totals_by_category[category_display] += count

        # Convert to list format expected by serializer
        totals_data = [
            {'material_group': category, 'substituted_count': count}
            for category, count in totals_by_category.items()
        ]

        total_substituted = sum(item['substituted_count'] or 0 for item in totals_data)
        for item in totals_data:
            item['substituted_percentage'] = round(
                (item['substituted_count'] * 100.0 / total_substituted) if total_substituted > 0 else 0,
                2
            )

        # Get overall stats
        if not direct_mat_nbr and mat_nbr_subquery is None:
            overall_qs = OrderTransactionWeeklyMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                overall_qs = overall_qs.filter(corp_chain=corp_chain_nbr)
            overall_stats = overall_qs.aggregate(
                total_orders=Sum('total_orders'),
                substituted_orders=Sum('substituted_count')
            )
            overall_stats['total_orders'] = overall_stats['total_orders'] or 0
            overall_stats['substituted_orders'] = overall_stats['substituted_orders'] or 0
        else:
            queryset_all = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset_all = queryset_all.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset_all = queryset_all.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset_all = queryset_all.filter(material__mat_nbr__in=mat_nbr_subquery)

            overall_stats = queryset_all.aggregate(
                total_orders=Sum('total_orders'),
                substituted_orders=Sum('substituted_count')
            )
            overall_stats['total_orders'] = overall_stats['total_orders'] or 0
            overall_stats['substituted_orders'] = overall_stats['substituted_orders'] or 0

        overall_stats['substituted_percentage'] = round(
            (overall_stats['substituted_orders'] * 100.0 / overall_stats['total_orders'])
            if overall_stats['total_orders'] > 0 else 0,
            2
        )

        return {
            'weekly_data': weekly_data,
            'totals_by_group': totals_data,
            'overall_stats': overall_stats,
        }

    @staticmethod
    def get_alt_served_breakdown_analysis(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns breakdown analysis of alt-served orders by material group,
        class of trade, and plant for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        # Get totals by material group - aggregate by mapped categories
        if not direct_mat_nbr and mat_nbr_subquery is None:
            logger.info("get_alt_served_breakdown_analysis: Using materialized view for material group (fast path)")
            mg_qs = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                mg_qs = mg_qs.filter(corp_chain=corp_chain_nbr)
            raw_material_group_data = list(
                mg_qs
                .values('material__scrm_mat_grp')
                .annotate(
                    scrm_mat_grp=F('material__scrm_mat_grp'),
                    alt_served_count=Sum('alt_served_count')
                )
                .filter(alt_served_count__gt=0)
                .order_by('scrm_mat_grp')
            )
        else:
            logger.info("Using weekly material MV with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            raw_material_group_data = list(
                queryset
                .values('material__scrm_mat_grp')
                .annotate(
                    scrm_mat_grp=F('material__scrm_mat_grp'),
                    alt_served_count=Sum('alt_served_count')
                )
                .filter(alt_served_count__gt=0)
                .order_by('scrm_mat_grp')
            )

        # Aggregate by mapped categories
        material_group_by_category = {}
        # Map category to display name (OTC should stay uppercase)
        category_display_map = {
            'brand': 'Brand',
            'generic': 'Generic',
            'otc': 'OTC'
        }

        for item in raw_material_group_data:
            scrm_mat_grp = item['scrm_mat_grp']
            count = item['alt_served_count'] or 0
            category = map_scrm_mat_grp_to_category(scrm_mat_grp)

            if category:
                category_display = category_display_map.get(category, category.capitalize())
                if category_display not in material_group_by_category:
                    material_group_by_category[category_display] = 0
                material_group_by_category[category_display] += count

        # Convert to list format expected by serializer
        material_group_data = [
            {'material_group': category, 'alt_served_count': count}
            for category, count in material_group_by_category.items()
        ]

        # Get totals by class of trade
        queryset_cot = OrderTransactionAltServedClassOfTradeMaterial90dMV.objects.all()

        if corp_chain_nbr:
            queryset_cot = queryset_cot.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset_cot = queryset_cot.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset_cot = queryset_cot.filter(material__mat_nbr__in=mat_nbr_subquery)

        class_of_trade_data = list(
            queryset_cot
            .values('class_of_trade_desc')
            .annotate(
                class_of_trade=F('class_of_trade_desc'),
                alt_served_count=Sum('alt_served_count')
            )
            .filter(alt_served_count__gt=0)
            .order_by('class_of_trade')
        )

        queryset_plant = OrderTransactionAltServedPlantMaterial90dMV.objects.all()

        if corp_chain_nbr:
            queryset_plant = queryset_plant.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset_plant = queryset_plant.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset_plant = queryset_plant.filter(material__mat_nbr__in=mat_nbr_subquery)

        plant_data = list(
            queryset_plant.values(
                'plant__name'
            ).annotate(
                plant=F('plant__name'),
                alt_served_count=Sum('alt_served_count')
            )
            .filter(alt_served_count__gt=0)
            .order_by('plant')
        )

        # Calculate total alt served for percentages
        total_material_group = sum(item['alt_served_count'] or 0 for item in material_group_data)
        total_class_of_trade = sum(item['alt_served_count'] or 0 for item in class_of_trade_data)
        total_plant = sum(item['alt_served_count'] or 0 for item in plant_data)

        # Add percentages to material group data
        for item in material_group_data:
            item['alt_served_percentage'] = round(
                (item['alt_served_count'] * 100.0 / total_material_group) if total_material_group > 0 else 0,
                2
            )

        # Add percentages to class of trade data
        for item in class_of_trade_data:
            item['alt_served_percentage'] = round(
                (item['alt_served_count'] * 100.0 / total_class_of_trade) if total_class_of_trade > 0 else 0,
                2
            )

        # Add percentages to plant data
        for item in plant_data:
            item['alt_served_percentage'] = round(
                (item['alt_served_count'] * 100.0 / total_plant) if total_plant > 0 else 0,
                2
            )

        return {
            'totals_by_group': material_group_data,
            'total_by_class_of_trade': class_of_trade_data,
            'totals_by_plant': plant_data,
        }

    @staticmethod
    def get_alt_served_by_material_status(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Get alt served orders grouped by material status with percentages.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Retrieving alt-served orders by material status for last 90 days")

        queryset = OrderTransactionAltServedStatus90dMV.objects.all()

        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        results = queryset.values(
            'material_status'
        ).annotate(
            alt_served_count=Sum('alt_served_count')
        ).order_by('-alt_served_count')

        results_list = list(results)

        total_alt_served = sum(item['alt_served_count'] or 0 for item in results_list)

        for item in results_list:
            item['status'] = item['material_status']
            if total_alt_served > 0:
                item['alt_served_percentage'] = round((item['alt_served_count'] * 100.0) / total_alt_served, 1)
            else:
                item['alt_served_percentage'] = 0.0

        return results_list

    @staticmethod
    def get_alt_served_materials_by_status(material_status, direct_mat_nbr=None, mat_nbr_subquery=None,
                                           corp_chain_nbr=None):
        """
        Get alt served materials breakdown by percentage for a specific material status.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Retrieving alt-served materials for status: %s (last 90 days)", material_status)

        queryset = OrderTransactionAltServedStatus90dMV.objects.filter(
            material_status=material_status
        )

        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        results = queryset.values(
            'material'
        ).annotate(
            mat_nbr=F('material__mat_nbr'),
            material_name=F('material__name'),
            alt_served_count=Sum('alt_served_count')
        ).order_by('-alt_served_count')

        results_list = list(results)

        total_alt_served = sum(item['alt_served_count'] or 0 for item in results_list)

        for item in results_list:
            if total_alt_served > 0:
                item['alt_served_percentage'] = round((item['alt_served_count'] * 100.0) / total_alt_served, 1)
            else:
                item['alt_served_percentage'] = 0.0

        return results_list

    @staticmethod
    def get_alt_served_units_by_type_weekly(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns weekly aggregated alt served units grouped by week_start.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        if not direct_mat_nbr and mat_nbr_subquery is None:
            logger.info("Using materialized view (fast path)")
            weekly_qs = OrderTransactionWeeklyMV.objects.filter(
                week_start__gte=week_filter_date,
                alt_served_count__gt=0
            )
            if corp_chain_nbr:
                weekly_qs = weekly_qs.filter(corp_chain=corp_chain_nbr)
            weekly_query = (
                weekly_qs
                .values('week_start')
                .annotate(
                    auto_units=Sum('auto_alt_served_units'),
                    manual_units=Sum('manual_alt_served_units'),
                    total_units=Sum('alt_served_units')
                )
                .order_by('week_start')
            )
        else:
            logger.info("Using weekly material MV with filters (aggregated path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.filter(week_start__gte=week_filter_date)
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            weekly_query = (
                queryset
                .values('week_start')
                .annotate(
                    auto_units=Sum('auto_alt_served_units'),
                    manual_units=Sum('manual_alt_served_units'),
                    total_units=Sum('alt_served_units')
                )
                .order_by('week_start')
            )

        return list(weekly_query)

    @staticmethod
    def get_alt_served_order_qty_by_cost_range_and_status(direct_mat_nbr=None, mat_nbr_subquery=None,
                                                          corp_chain_nbr=None):
        """
        Get alt-served order quantities grouped by cost range and material status.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        range_labels = [
            "0-15", "16-50", "51-100", "101-150", "151-200", "201+"
        ]

        queryset = OrderTransactionAltServedCost90dMV.objects.all()
        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
        if not direct_mat_nbr and mat_nbr_subquery is None and not corp_chain_nbr:
            logger.info("Using materialized view (fast path)")
        else:
            logger.info("Using materialized view with filters")

        all_statuses = queryset.values_list('material_status', flat=True).distinct()
        all_statuses = [status if status is not None else "Unknown" for status in all_statuses]

        qs = (
            queryset
            .values('cost_range', 'material_status')
            .annotate(total_qty=Sum('total_order_qty'))
            .order_by('cost_range', 'material_status')
        )

        result = {}
        for range_label in range_labels:
            result[range_label] = {}
            for status in all_statuses:
                result[range_label][status] = 0

        for row in qs:
            if row['cost_range'] is not None:
                cost_label = range_labels[row['cost_range']]
                status = row['material_status'] if row['material_status'] is not None else "Unknown"
                result[cost_label][status] = row['total_qty'] or 0

        return result

    @staticmethod
    def get_material_status_distinct():
        """
        Get all unique material statuses from order transactions.
        """
        return (OrderTransaction.objects
                .filter(material_status__isnull=False)
                .exclude(material_status="")
                .values('material_status')
                .distinct()
                )
