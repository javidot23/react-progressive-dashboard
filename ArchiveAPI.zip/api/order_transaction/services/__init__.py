from . import sales_comparison
from .alt_served import AltServedMixin
from .base import BaseMixin, map_scrm_mat_grp_to_category
from .crud import CrudMixin
from .fail_to_supply import FailToSupplyMixin
from .omit_fulfillment import OmitFulfillmentMixin
from .sales import SalesMixin
from .sales_comparison import SalesComparisonMixin
from .weekly import WeeklyMixin


class OrderTransactionService(
    BaseMixin,
    CrudMixin,
    SalesMixin,
    AltServedMixin,
    WeeklyMixin,
    OmitFulfillmentMixin,
    SalesComparisonMixin,
    FailToSupplyMixin,
):
    """Service class for handling order transaction operations."""


# Methods in sales_comparison reference OrderTransactionService by name.
sales_comparison.OrderTransactionService = OrderTransactionService

__all__ = ["OrderTransactionService", "map_scrm_mat_grp_to_category"]
