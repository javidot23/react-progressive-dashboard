import logging

from django.db.models import Case, F, FloatField, IntegerField, Value, When
from django.db.models.functions import Cast

from api.order_transaction.materialized_view_models import (
    OrderTransactionPlant90dMV,
)
from api.order_transaction.models import OrderTransaction

logger = logging.getLogger(__name__)


class CrudMixin:
    @staticmethod
    def get_order_transactions_with_material_and_plant():
        """Retrieve all order transactions."""
        logger.info("Retrieving all order transactions with related data")
        queryset = OrderTransaction.objects.select_related(
            'material', 'material__vendor', 'substituted_material',
            'substituted_material__vendor', 'plant',
            'ar_plant', "cust_corp_chain_nbr", "cust_company_nbr",
            "cust_bus_unit_nbr", "cust_location_nbr", "cust_nbr"
        ).all()
        return queryset

    @staticmethod
    def get_optimized_order_transactions():
        """
        Retrieve order transactions with optimized field loading.
        Only loads required fields from related tables to improve performance.
        """
        logger.info("Retrieving order transactions with optimized field loading")
        queryset = OrderTransaction.objects.select_related(
            'material', 'material__vendor', 'substituted_material',
            'substituted_material__vendor', 'plant', 'ar_plant'
        ).only(
            'id', 'sales_doc_nbr', 'sales_doc_itm_nbr', 'total_order_qty',
            'ord_created_date', 'material_status', 'sub_reas_code_name',
            'material__mat_nbr', 'material__name',
            'material__vendor__vendor_nbr', 'material__vendor__name',
            'substituted_material__mat_nbr', 'substituted_material__name',
            'substituted_material__vendor__vendor_nbr', 'substituted_material__vendor__name',
            'plant__plant_nbr', 'plant__name',
            'ar_plant__plant_nbr', 'ar_plant__name',
        ).all()
        return queryset

    @staticmethod
    def get_order_transaction_by_id(order_transaction_id):
        """Retrieve an order transaction by its ID."""
        logger.info("Retrieving order transaction by ID: %s", order_transaction_id)
        try:
            result = OrderTransaction.objects.get(id=order_transaction_id)
            logger.info("Successfully retrieved order transaction ID: %s", order_transaction_id)
            return result
        except OrderTransaction.DoesNotExist:
            logger.info("Order transaction not found: %s", order_transaction_id)
            return None

    @staticmethod
    def get_substituted_and_alt_served_material_count_by_plant():
        """
        Returns percentage of materials (products) that were substituted or alt-served per plant.
        Uses materialized view for improved performance.
        Percentages are based on distinct materials, not order lines.
        """
        logger.info("Calculating substituted and alt-served material percentages by plant from materialized view")

        return OrderTransactionPlant90dMV.objects.values(
            'plant',
            'plant__name',
            'plant__plant_nbr'
        ).annotate(
            total_materials=F('total_materials'),
            materials_with_substitution=F('materials_with_substitution'),
            materials_with_alt_serve=F('materials_with_alt_serve'),
            substituted_percent=Case(
                When(total_materials__gt=0,
                     then=Cast(
                         F('materials_with_substitution') * 100.0 / F('total_materials'),
                         FloatField()
                     )),
                default=Value(0.0),
                output_field=FloatField()
            ),
            alt_served_percent=Case(
                When(total_materials__gt=0,
                     then=Cast(
                         F('materials_with_alt_serve') * 100.0 / F('total_materials'),
                         FloatField()
                     )),
                default=Value(0.0),
                output_field=FloatField()
            ),
            # Keep these for backward compatibility with serializer
            total_orders=Value(0, output_field=IntegerField()),
            substituted_count=F('materials_with_substitution'),
            alt_served_count=F('materials_with_alt_serve')
        ).filter(total_materials__gt=0)
