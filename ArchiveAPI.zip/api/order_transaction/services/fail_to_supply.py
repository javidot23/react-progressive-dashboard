import logging
from datetime import date, timedelta

from django.db.models import Case, Count, DecimalField, OuterRef, Subquery
from django.db.models import F, FloatField, IntegerField, Q, Sum, Value, When
from django.db.models.functions import Coalesce, Least, TruncDay

from api.order_transaction.models import OrderTransaction

logger = logging.getLogger(__name__)


class FailToSupplyMixin:
    @staticmethod
    def _previous_calendar_month_bounds(as_of=None):
        """Return (start, end) dates for the calendar month before as_of (default today)."""
        as_of = as_of or date.today()
        last_month_end = as_of.replace(day=1) - timedelta(days=1)
        last_month_start = last_month_end.replace(day=1)
        return last_month_start, last_month_end

    @staticmethod
    def get_fail_to_supply_materials(from_date, to_date, direct_mat_nbr=None, mat_nbr_subquery=None,
                                     corp_chain_nbr=None):
        """
        Returns materials with last-window OT scalars for low outbound / FTS cards and table.

        Aggregates order_transactions between from_date and to_date (caller defaults to 90d):
        outbound fill rate, unfilled qty, FTS omits, sales $, sales qty, demand,
        PRxO/Pharmagen line service levels, material status, mode contract_name, 28d forecast.

        Also annotates omits_qty_last_month for the previous calendar month (independent of
        from_date/to_date).
        """
        logger.info("Getting fail to supply materials from %s to %s", from_date, to_date)
        prxo_q = Q(sales_group='PRxO')
        pgen_q = Q(sales_group='PGEN')
        last_month_start, last_month_end = FailToSupplyMixin._previous_calendar_month_bounds()

        qs = OrderTransaction.objects.filter(
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
        )
        if direct_mat_nbr:
            qs = qs.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__mat_nbr__in=mat_nbr_subquery)
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        contract_mode_qs = OrderTransaction.objects.filter(
            material_id=OuterRef('material_id'),
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
            contract_name__isnull=False,
        ).exclude(contract_name='')
        if corp_chain_nbr:
            contract_mode_qs = contract_mode_qs.filter(cust_corp_chain_nbr=corp_chain_nbr)
        contract_type_sq = (
            contract_mode_qs
            .values('contract_name')
            .annotate(freq=Count('id'))
            .order_by('-freq', 'contract_name')
            .values('contract_name')[:1]
        )

        omits_last_month_qs = OrderTransaction.objects.filter(
            material_id=OuterRef('material_id'),
            ord_created_date__gte=last_month_start,
            ord_created_date__lte=last_month_end,
        )
        if corp_chain_nbr:
            omits_last_month_qs = omits_last_month_qs.filter(cust_corp_chain_nbr=corp_chain_nbr)
        omits_qty_last_month_sq = (
            omits_last_month_qs
            .values('material_id')
            .annotate(
                _order_sum=Coalesce(Sum('total_order_qty'), Value(0), output_field=DecimalField()),
                _adj_sum=Coalesce(
                    Sum('fts_adj_qty_incl_72_hours'), Value(0), output_field=DecimalField()
                ),
            )
            .annotate(omits_qty_last_month=F('_order_sum') - F('_adj_sum'))
            .values('omits_qty_last_month')[:1]
        )

        return (
            qs
            .values(
                'material_id',
                'material__name',
                'material__ndc',
                'material__xplant_mat_stat',
                'material__forecast_qty_7day',
            )
            .annotate(
                total_demand=Coalesce(Sum('total_order_qty'), Value(0), output_field=IntegerField()),
                sales_qty=Coalesce(Sum('total_shipped_qty'), Value(0), output_field=IntegerField()),
                fts_adj_qty_sum=Coalesce(
                    Sum('fts_adj_qty_incl_72_hours'), Value(0), output_field=DecimalField()
                ),
                sales_amount=Coalesce(Sum('sales_amount'), Value(0), output_field=DecimalField()),
                prxo_lines_ordered=Coalesce(
                    Sum(
                        Case(
                            When(prxo_q, then='fts_lines_ordered'),
                            default=Value(0),
                            output_field=IntegerField(),
                        )
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                prxo_adj_lines=Coalesce(
                    Sum(
                        Case(
                            When(prxo_q, then='fts_adj_lines_incl_72_hours'),
                            default=Value(0),
                            output_field=IntegerField(),
                        )
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                pgen_lines_ordered=Coalesce(
                    Sum(
                        Case(
                            When(pgen_q, then='fts_lines_ordered'),
                            default=Value(0),
                            output_field=IntegerField(),
                        )
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                pgen_adj_lines=Coalesce(
                    Sum(
                        Case(
                            When(pgen_q, then='fts_adj_lines_incl_72_hours'),
                            default=Value(0),
                            output_field=IntegerField(),
                        )
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                contract_type=Subquery(contract_type_sq),
                omits_qty_last_month=Coalesce(
                    Subquery(omits_qty_last_month_sq, output_field=DecimalField()),
                    Value(0),
                    output_field=DecimalField(),
                ),
            )
            .annotate(
                omits_qty=F('total_demand') - F('fts_adj_qty_sum'),
                unfilled_quantity=F('total_demand') - F('sales_qty'),
                outbound_fill_rate=Case(
                    When(
                        total_demand__gt=0,
                        then=100.0 * F('sales_qty') / F('total_demand'),
                    ),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                prxo_service_level=Case(
                    When(
                        prxo_lines_ordered__gt=0,
                        then=Least(
                            100.0 * F('prxo_adj_lines') / F('prxo_lines_ordered'),
                            Value(100.0),
                        ),
                    ),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                pharmagen_service_level=Case(
                    When(
                        pgen_lines_ordered__gt=0,
                        then=Least(
                            100.0 * F('pgen_adj_lines') / F('pgen_lines_ordered'),
                            Value(100.0),
                        ),
                    ),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                forecast_qty_28day=Coalesce(
                    F('material__forecast_qty_7day') * Value(4),
                    Value(0),
                    output_field=IntegerField(),
                ),
            )
        )

    @staticmethod
    def get_fail_to_supply_by_plant(mat_nbr, from_date, to_date, corp_chain_nbr=None):
        """
        Returns per-plant aggregates for a single material on the Fail to Supply drill-down.
        Includes PRxO/PGEN missed lines, total missed lines (+ %), outbound fill rate,
        service level, omit qty, demand qty, and ordered lines.
        Default ordering: most missed lines first.
        """
        logger.info("get_fail_to_supply_by_plant: mat_nbr=%s from=%s to=%s", mat_nbr, from_date, to_date)
        prxo_q = Q(sales_group='PRxO')
        pgen_q = Q(sales_group='PGEN')

        qs = OrderTransaction.objects.filter(
            material_id=mat_nbr,
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
        )
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        return (
            qs
            .values('plant_id', 'plant__name')
            .annotate(
                prxo_lines_ordered=Sum(
                    Case(
                        When(prxo_q, then='fts_lines_ordered'),
                        default=Value(0), output_field=IntegerField()
                    )
                ),
                prxo_adj_lines=Sum(
                    Case(
                        When(prxo_q, then='fts_adj_lines_incl_72_hours'),
                        default=Value(0),
                        output_field=IntegerField()
                    )
                ),
                pgen_lines_ordered=Sum(
                    Case(When(pgen_q, then='fts_lines_ordered'),
                         default=Value(0),
                         output_field=IntegerField()
                         )
                ),
                pgen_adj_lines=Sum(
                    Case(When(pgen_q, then='fts_adj_lines_incl_72_hours'),
                         default=Value(0),
                         output_field=IntegerField()
                         )
                ),
                total_lines_ordered=Sum('fts_lines_ordered'),
                total_adj_lines=Sum('fts_adj_lines_incl_72_hours'),
                demand_qty=Sum('total_order_qty'),
                total_shipped_qty_sum=Sum('total_shipped_qty'),
                fts_adj_qty_sum=Sum('fts_adj_qty_incl_72_hours'),
            )
            .annotate(
                prxo_missed_lines=F('prxo_lines_ordered') - F('prxo_adj_lines'),
                pgen_missed_lines=F('pgen_lines_ordered') - F('pgen_adj_lines'),
                total_missed_lines=F('total_lines_ordered') - F('total_adj_lines'),
                omit_qty=F('demand_qty') - F('fts_adj_qty_sum'),
                total_missed_lines_pct=Case(
                    When(total_lines_ordered__gt=0,
                         then=100.0 * (F('total_lines_ordered') - F('total_adj_lines')) / F('total_lines_ordered')),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                outbound_fill_rate=Case(
                    When(demand_qty__gt=0,
                         then=100.0 * F('total_shipped_qty_sum') / F('demand_qty')),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                service_level=Case(
                    When(total_lines_ordered__gt=0,
                         then=100.0 * F('total_adj_lines') / F('total_lines_ordered')),
                    default=Value(None),
                    output_field=FloatField(),
                ),
            )
        )

    @staticmethod
    def get_fail_to_supply_trends(from_date, to_date, mat_nbrs, corp_chain_nbr=None):
        """
        Returns daily per-material trend data (legacy helper; materials list no longer uses it).
        Splits service level by sales_group (PRxO / Pharmagen) using conditional aggregation.
        Fill rate is quantity-based: sum(shipped) / sum(ordered).
        Service level is line-based: sum(adj_lines_incl_72h) / sum(lines_ordered).
        """
        logger.info("Getting fail to supply trends from %s to %s for materials: %s",
                    from_date,
                    to_date,
                    mat_nbrs
                    )
        prxo_q = Q(sales_group='PRxO')
        pharmagen_q = Q(sales_group='PGEN')

        qs = OrderTransaction.objects.filter(
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
            material_id__in=mat_nbrs,
        )
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        return list(
            qs
            .annotate(date=TruncDay('ord_created_date'))
            .values('material_id', 'date')
            .annotate(
                prxo_adj_lines=Sum(
                    Case(When(prxo_q, then='fts_adj_lines_incl_72_hours'), default=Value(0),
                         output_field=IntegerField())
                ),
                prxo_lines_ordered=Sum(
                    Case(When(prxo_q, then='fts_lines_ordered'), default=Value(0), output_field=IntegerField())
                ),
                pharmagen_adj_lines=Sum(
                    Case(When(pharmagen_q, then='fts_adj_lines_incl_72_hours'), default=Value(0),
                         output_field=IntegerField())
                ),
                pharmagen_lines_ordered=Sum(
                    Case(When(pharmagen_q, then='fts_lines_ordered'), default=Value(0), output_field=IntegerField())
                ),
                total_adj_lines=Sum('fts_adj_lines_incl_72_hours'),
                total_lines_ordered=Sum('fts_lines_ordered'),
                total_shipped_qty=Sum('total_shipped_qty'),
                total_order_qty=Sum('total_order_qty'),
            )
            .order_by('material__mat_nbr', 'date')
        )

    @staticmethod
    def get_customers_by_material_plant(mat_nbr, plant_nbr, from_date, to_date, corp_chain_nbr=None):
        """
        Returns per-customer inventory aggregates for a material and plant.
        Used by the Manage Inventory page customer drilldown (not Fail to Supply).
        Includes order/shipped qty, omit qty, imperfect lines, sales amount, and fill rate.
        """
        logger.info(
            "get_customers_by_material_plant: mat_nbr=%s plant_nbr=%s from=%s to=%s",
            mat_nbr,
            plant_nbr,
            from_date,
            to_date,
        )

        qs = OrderTransaction.objects.filter(
            material_id=mat_nbr,
            plant_id=plant_nbr,
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
        )
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        return (
            qs
            .values(
                'cust_nbr_id',
                'cust_nbr__name',
                'cust_corp_chain_nbr_id',
                'cust_corp_chain_nbr__name',
            )
            .annotate(
                order_qty=Coalesce(Sum('total_order_qty'), Value(0), output_field=IntegerField()),
                shipped_qty=Coalesce(Sum('total_shipped_qty'), Value(0), output_field=IntegerField()),
                adj_qty_sum=Coalesce(Sum('fts_adj_qty_incl_72_hours'), Value(0), output_field=DecimalField()),
                imperfect_lines=Coalesce(
                    Sum(
                        Case(
                            When(f_total_imperfect=1, then=Value(1)),
                            default=Value(0),
                            output_field=IntegerField(),
                        )
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                sales_amount=Coalesce(Sum('sales_amount'), Value(0), output_field=DecimalField()),
            )
            .annotate(
                omit_qty=F('order_qty') - F('adj_qty_sum'),
                outbound_fill_rate=Case(
                    When(order_qty__gt=0,
                         then=100.0 * F('shipped_qty') / F('order_qty')),
                    default=Value(None),
                    output_field=FloatField(),
                ),
            )
        )
