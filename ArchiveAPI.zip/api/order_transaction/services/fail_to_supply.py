import logging
from datetime import date, timedelta

from django.db.models import Case, Count, DecimalField, ExpressionWrapper
from django.db.models import F, FloatField, IntegerField, Min, Q, Sum, Value, When
from django.db.models.functions import Coalesce, Least, TruncDay, TruncWeek

from api.date_bounds import iso_week_bounds
from api.order_transaction.models import OrderTransaction

logger = logging.getLogger(__name__)


class FailToSupplyMixin:
    @staticmethod
    def _previous_calendar_month_bounds(as_of=None):
        """Return (start, end) dates for the calendar month before as_of (default today)."""
        as_of = as_of or date.today()
        last_month_end = as_of.replace(day=1) - timedelta(days=1)
        last_month_start = last_month_end.replace(day=1)
        return last_month_start, last_month_end

    @staticmethod
    def get_weekly_fts_exposure_qty(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns the total Fail to Supply exposure quantity for the current ISO week.

        Exposure is the unsupplied demand quantity: sum(total_order_qty) minus
        sum(fts_adj_qty_incl_72_hours) over order_transactions created from Monday
        through today. The total is clamped at zero; individual lines may carry an
        adjusted quantity above the ordered quantity.
        """
        week_start, week_end, _, _ = iso_week_bounds()
        logger.info("Getting weekly FTS exposure qty from %s to %s", week_start, week_end)

        qs = OrderTransaction.objects.filter(
            ord_created_date__gte=week_start,
            ord_created_date__lte=week_end,
        )
        if direct_mat_nbr:
            qs = qs.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__mat_nbr__in=mat_nbr_subquery)
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        totals = qs.aggregate(
            demand_qty=Coalesce(Sum('total_order_qty'), Value(0), output_field=DecimalField()),
            adj_qty=Coalesce(
                Sum('fts_adj_qty_incl_72_hours'), Value(0), output_field=DecimalField()
            ),
        )

        return {
            'week_start': week_start,
            'week_end': week_end,
            'exposure_qty': int(max(totals['demand_qty'] - totals['adj_qty'], 0)),
        }

    @staticmethod
    def _line_service_level(adj_lines_field, lines_ordered_field):
        """Line-based service level: 100 * adj_lines / lines_ordered, capped at 100."""
        return Case(
            When(
                **{f'{lines_ordered_field}__gt': 0},
                then=Least(
                    100.0 * F(adj_lines_field) / F(lines_ordered_field),
                    Value(100.0),
                ),
            ),
            default=Value(None),
            output_field=FloatField(),
        )

    SERVICE_LEVEL_METRICS = ('service_level', 'prxo_service_level', 'pharmagen_service_level')

    @staticmethod
    def _service_level_base_queryset(from_date, to_date, direct_mat_nbr=None, mat_nbr_subquery=None,
                                     corp_chain_nbr=None):
        """Order transactions in the window, narrowed by the global material and customer filters."""
        qs = OrderTransaction.objects.filter(
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
        )
        if direct_mat_nbr:
            qs = qs.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__mat_nbr__in=mat_nbr_subquery)
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)
        return qs

    @staticmethod
    def _ratio_pct(numerator, denominator):
        """Line-based percentage capped at 100, or None when nothing was ordered."""
        if not denominator:
            return None
        return min(100.0, 100.0 * numerator / denominator)

    @staticmethod
    def _service_level_totals(qs):
        """Overall, PRxO and Pharmagen service levels for a queryset, as a single aggregate."""
        prxo_q = Q(sales_group='PRxO')
        pgen_q = Q(sales_group='PGEN')
        totals = qs.aggregate(
            total_adj=Coalesce(Sum('fts_adj_lines_incl_72_hours'), Value(0), output_field=IntegerField()),
            total_ordered=Coalesce(Sum('fts_lines_ordered'), Value(0), output_field=IntegerField()),
            prxo_adj=Coalesce(
                Sum(Case(When(prxo_q, then='fts_adj_lines_incl_72_hours'), default=Value(0),
                         output_field=IntegerField())),
                Value(0), output_field=IntegerField(),
            ),
            prxo_ordered=Coalesce(
                Sum(Case(When(prxo_q, then='fts_lines_ordered'), default=Value(0),
                         output_field=IntegerField())),
                Value(0), output_field=IntegerField(),
            ),
            pgen_adj=Coalesce(
                Sum(Case(When(pgen_q, then='fts_adj_lines_incl_72_hours'), default=Value(0),
                         output_field=IntegerField())),
                Value(0), output_field=IntegerField(),
            ),
            pgen_ordered=Coalesce(
                Sum(Case(When(pgen_q, then='fts_lines_ordered'), default=Value(0),
                         output_field=IntegerField())),
                Value(0), output_field=IntegerField(),
            ),
        )
        return {
            'service_level': FailToSupplyMixin._ratio_pct(totals['total_adj'], totals['total_ordered']),
            'prxo_service_level': FailToSupplyMixin._ratio_pct(totals['prxo_adj'], totals['prxo_ordered']),
            'pharmagen_service_level': FailToSupplyMixin._ratio_pct(totals['pgen_adj'], totals['pgen_ordered']),
        }

    @staticmethod
    def get_service_level_week_comparison(anchor_date, direct_mat_nbr=None, mat_nbr_subquery=None,
                                          corp_chain_nbr=None):
        """
        Compares the week through anchor_date against the same span of the previous week.

        Both windows start on a Monday and cover the same number of days, so a Wednesday anchor
        compares Mon-Wed against Mon-Wed rather than against a full prior week. Returns the two
        window bounds alongside a current/previous/change entry per service level metric, where
        `change` is the difference in percentage points and `change_pct` that difference relative
        to the previous window.
        """
        week_start = anchor_date - timedelta(days=anchor_date.weekday())
        previous_week_start = week_start - timedelta(days=7)
        previous_anchor = anchor_date - timedelta(days=7)

        logger.info(
            "Getting service level week comparison %s..%s against %s..%s",
            week_start, anchor_date, previous_week_start, previous_anchor,
        )

        filters = (direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr)
        current = FailToSupplyMixin._service_level_totals(
            FailToSupplyMixin._service_level_base_queryset(week_start, anchor_date, *filters)
        )
        previous = FailToSupplyMixin._service_level_totals(
            FailToSupplyMixin._service_level_base_queryset(previous_week_start, previous_anchor, *filters)
        )

        summary = {}
        for metric in FailToSupplyMixin.SERVICE_LEVEL_METRICS:
            current_value = current[metric]
            previous_value = previous[metric]
            change = (
                None if current_value is None or previous_value is None
                else current_value - previous_value
            )
            summary[metric] = {
                'current': current_value,
                'previous': previous_value,
                'change': change,
                'change_pct': (
                    None if change is None or not previous_value
                    else 100.0 * change / previous_value
                ),
            }

        return {
            'current_period': {'from_date': week_start, 'to_date': anchor_date},
            'previous_period': {'from_date': previous_week_start, 'to_date': previous_anchor},
            **summary,
        }

    @staticmethod
    def get_weekly_service_levels(from_date, to_date, direct_mat_nbr=None, mat_nbr_subquery=None,
                                  corp_chain_nbr=None):
        """
        Returns one bucket per ISO week (Monday start) between from_date and to_date, each holding
        the overall service level plus the PRxO and Pharmagen splits.

        Service level is line-based across every material in the window:
        100 * sum(fts_adj_lines_incl_72_hours) / sum(fts_lines_ordered), capped at 100. Weeks are
        weighted by line volume rather than averaged per material. A split is null for a week with
        no ordered lines in that sales group. The first and last buckets cover a partial week when
        the window does not land on week boundaries.
        """
        logger.info("Getting weekly service levels from %s to %s", from_date, to_date)
        prxo_q = Q(sales_group='PRxO')
        pgen_q = Q(sales_group='PGEN')

        qs = FailToSupplyMixin._service_level_base_queryset(
            from_date, to_date, direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr
        )

        return list(
            qs
            .annotate(week_start=TruncWeek('ord_created_date'))
            .values('week_start')
            .annotate(
                total_adj_lines=Coalesce(
                    Sum('fts_adj_lines_incl_72_hours'), Value(0), output_field=IntegerField()
                ),
                total_lines_ordered=Coalesce(
                    Sum('fts_lines_ordered'), Value(0), output_field=IntegerField()
                ),
                prxo_adj_lines=Coalesce(
                    Sum(Case(When(prxo_q, then='fts_adj_lines_incl_72_hours'), default=Value(0),
                             output_field=IntegerField())),
                    Value(0), output_field=IntegerField(),
                ),
                prxo_lines_ordered=Coalesce(
                    Sum(Case(When(prxo_q, then='fts_lines_ordered'), default=Value(0),
                             output_field=IntegerField())),
                    Value(0), output_field=IntegerField(),
                ),
                pgen_adj_lines=Coalesce(
                    Sum(Case(When(pgen_q, then='fts_adj_lines_incl_72_hours'), default=Value(0),
                             output_field=IntegerField())),
                    Value(0), output_field=IntegerField(),
                ),
                pgen_lines_ordered=Coalesce(
                    Sum(Case(When(pgen_q, then='fts_lines_ordered'), default=Value(0),
                             output_field=IntegerField())),
                    Value(0), output_field=IntegerField(),
                ),
            )
            .annotate(
                service_level=FailToSupplyMixin._line_service_level(
                    'total_adj_lines', 'total_lines_ordered'
                ),
                prxo_service_level=FailToSupplyMixin._line_service_level(
                    'prxo_adj_lines', 'prxo_lines_ordered'
                ),
                pharmagen_service_level=FailToSupplyMixin._line_service_level(
                    'pgen_adj_lines', 'pgen_lines_ordered'
                ),
            )
            .values(
                'week_start',
                'service_level',
                'prxo_service_level',
                'pharmagen_service_level',
            )
            .order_by('week_start')
        )

    @staticmethod
    def get_fail_to_supply_materials(from_date, to_date, direct_mat_nbr=None, mat_nbr_subquery=None,
                                     corp_chain_nbr=None):
        """
        Returns materials with last-window OT scalars for low outbound / FTS cards and table.

        Aggregates order_transactions between from_date and to_date (caller defaults to 90d):
        outbound fill rate, unfilled qty, FTS omits, sales $, sales qty,
        PRxO/Pharmagen line service levels, material status, 28d forecast.

        total_demand and omits_qty_last_month use the previous calendar month (independent of
        from_date/to_date). Fill rate / unfilled / window omits stay on the caller window.

        Grouping is on material only; material identity columns come back as aggregates so the
        group key stays narrow. The scanned range spans both the caller window and the previous
        calendar month, and every aggregate carries the filter for the range it belongs to, so
        the whole result set is produced by a single pass over order_transactions. Only materials
        with at least one transaction inside the caller window are returned.

        contract_type is not part of this queryset; resolve it for a page of materials with
        ``get_material_contract_types``.
        """
        logger.info("Getting fail to supply materials from %s to %s", from_date, to_date)
        prxo_q = Q(sales_group='PRxO')
        pgen_q = Q(sales_group='PGEN')
        last_month_start, last_month_end = FailToSupplyMixin._previous_calendar_month_bounds()

        window_q = Q(ord_created_date__gte=from_date, ord_created_date__lte=to_date)
        last_month_q = Q(
            ord_created_date__gte=last_month_start, ord_created_date__lte=last_month_end
        )

        qs = OrderTransaction.objects.filter(
            ord_created_date__gte=min(from_date, last_month_start),
            ord_created_date__lte=max(to_date, last_month_end),
        )
        if direct_mat_nbr:
            qs = qs.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__mat_nbr__in=mat_nbr_subquery)
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        return (
            qs
            .values('material_id')
            .annotate(
                material_name=Min('material__name'),
                material_ndc=Min('material__ndc'),
                material_status=Min('material__xplant_mat_stat'),
                material_forecast_qty_7day=Min('material__forecast_qty_7day'),
                window_lines=Count('id', filter=window_q),
                window_demand=Coalesce(
                    Sum('total_order_qty', filter=window_q), Value(0), output_field=IntegerField()
                ),
                total_demand=Coalesce(
                    Sum('total_order_qty', filter=last_month_q),
                    Value(0),
                    output_field=IntegerField(),
                ),
                sales_qty=Coalesce(
                    Sum('total_shipped_qty', filter=window_q), Value(0), output_field=IntegerField()
                ),
                fts_adj_qty_sum=Coalesce(
                    Sum('fts_adj_qty_incl_72_hours', filter=window_q),
                    Value(0),
                    output_field=DecimalField(),
                ),
                sales_amount=Coalesce(
                    Sum('sales_amount', filter=window_q), Value(0), output_field=DecimalField()
                ),
                prxo_lines_ordered=Coalesce(
                    Sum('fts_lines_ordered', filter=prxo_q & window_q),
                    Value(0),
                    output_field=IntegerField(),
                ),
                prxo_adj_lines=Coalesce(
                    Sum('fts_adj_lines_incl_72_hours', filter=prxo_q & window_q),
                    Value(0),
                    output_field=IntegerField(),
                ),
                pgen_lines_ordered=Coalesce(
                    Sum('fts_lines_ordered', filter=pgen_q & window_q),
                    Value(0),
                    output_field=IntegerField(),
                ),
                pgen_adj_lines=Coalesce(
                    Sum('fts_adj_lines_incl_72_hours', filter=pgen_q & window_q),
                    Value(0),
                    output_field=IntegerField(),
                ),
                last_month_adj_qty=Coalesce(
                    Sum('fts_adj_qty_incl_72_hours', filter=last_month_q),
                    Value(0),
                    output_field=DecimalField(),
                ),
            )
            .filter(window_lines__gt=0)
            .annotate(
                omits_qty_last_month=ExpressionWrapper(
                    F('total_demand') - F('last_month_adj_qty'), output_field=DecimalField()
                ),
                omits_qty=F('window_demand') - F('fts_adj_qty_sum'),
                unfilled_quantity=F('window_demand') - F('sales_qty'),
                outbound_fill_rate=Case(
                    When(
                        window_demand__gt=0,
                        then=100.0 * F('sales_qty') / F('window_demand'),
                    ),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                prxo_service_level=Case(
                    When(
                        prxo_lines_ordered__gt=0,
                        then=Least(
                            100.0 * F('prxo_adj_lines') / F('prxo_lines_ordered'),
                            Value(100.0),
                        ),
                    ),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                pharmagen_service_level=Case(
                    When(
                        pgen_lines_ordered__gt=0,
                        then=Least(
                            100.0 * F('pgen_adj_lines') / F('pgen_lines_ordered'),
                            Value(100.0),
                        ),
                    ),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                forecast_qty_28day=Coalesce(
                    F('material_forecast_qty_7day') * Value(4),
                    Value(0),
                    output_field=IntegerField(),
                ),
            )
        )

    @staticmethod
    def get_material_contract_types(mat_nbrs, from_date, to_date, corp_chain_nbr=None):
        """
        Maps each material number to its most frequent non-empty contract_name over the window.

        Ties break on contract_name ascending. Materials with no named contract are absent
        from the mapping. Pass ``mat_nbrs=None`` to resolve every material in the window.
        """
        if mat_nbrs is not None and not mat_nbrs:
            return {}

        qs = OrderTransaction.objects.filter(
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
            contract_name__isnull=False,
        ).exclude(contract_name='')
        if mat_nbrs is not None:
            qs = qs.filter(material_id__in=mat_nbrs)
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        rows = (
            qs
            .values('material_id', 'contract_name')
            .annotate(freq=Count('id'))
            .order_by('material_id', '-freq', 'contract_name')
        )

        contract_types = {}
        for row in rows:
            contract_types.setdefault(row['material_id'], row['contract_name'])
        return contract_types

    @staticmethod
    def get_fail_to_supply_by_plant(mat_nbr, from_date, to_date, corp_chain_nbr=None):
        """
        Returns per-plant aggregates for a single material on the Fail to Supply drill-down.
        Includes PRxO/PGEN missed lines, total missed lines (+ %), outbound fill rate,
        service level, omit qty, demand qty, and ordered lines.
        Default ordering: most missed lines first.
        """
        logger.info("get_fail_to_supply_by_plant: mat_nbr=%s from=%s to=%s", mat_nbr, from_date, to_date)
        prxo_q = Q(sales_group='PRxO')
        pgen_q = Q(sales_group='PGEN')

        qs = OrderTransaction.objects.filter(
            material_id=mat_nbr,
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
        )
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        return (
            qs
            .values('plant_id', 'plant__name')
            .annotate(
                prxo_lines_ordered=Sum(
                    Case(
                        When(prxo_q, then='fts_lines_ordered'),
                        default=Value(0), output_field=IntegerField()
                    )
                ),
                prxo_adj_lines=Sum(
                    Case(
                        When(prxo_q, then='fts_adj_lines_incl_72_hours'),
                        default=Value(0),
                        output_field=IntegerField()
                    )
                ),
                pgen_lines_ordered=Sum(
                    Case(When(pgen_q, then='fts_lines_ordered'),
                         default=Value(0),
                         output_field=IntegerField()
                         )
                ),
                pgen_adj_lines=Sum(
                    Case(When(pgen_q, then='fts_adj_lines_incl_72_hours'),
                         default=Value(0),
                         output_field=IntegerField()
                         )
                ),
                total_lines_ordered=Sum('fts_lines_ordered'),
                total_adj_lines=Sum('fts_adj_lines_incl_72_hours'),
                demand_qty=Sum('total_order_qty'),
                total_shipped_qty_sum=Sum('total_shipped_qty'),
                fts_adj_qty_sum=Sum('fts_adj_qty_incl_72_hours'),
            )
            .annotate(
                prxo_missed_lines=F('prxo_lines_ordered') - F('prxo_adj_lines'),
                pgen_missed_lines=F('pgen_lines_ordered') - F('pgen_adj_lines'),
                total_missed_lines=F('total_lines_ordered') - F('total_adj_lines'),
                omit_qty=F('demand_qty') - F('fts_adj_qty_sum'),
                total_missed_lines_pct=Case(
                    When(total_lines_ordered__gt=0,
                         then=100.0 * (F('total_lines_ordered') - F('total_adj_lines')) / F('total_lines_ordered')),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                outbound_fill_rate=Case(
                    When(demand_qty__gt=0,
                         then=100.0 * F('total_shipped_qty_sum') / F('demand_qty')),
                    default=Value(None),
                    output_field=FloatField(),
                ),
                service_level=Case(
                    When(total_lines_ordered__gt=0,
                         then=100.0 * F('total_adj_lines') / F('total_lines_ordered')),
                    default=Value(None),
                    output_field=FloatField(),
                ),
            )
        )

    @staticmethod
    def get_fail_to_supply_trends(from_date, to_date, mat_nbrs, corp_chain_nbr=None):
        """
        Returns daily per-material trend data (legacy helper; materials list no longer uses it).
        Splits service level by sales_group (PRxO / Pharmagen) using conditional aggregation.
        Fill rate is quantity-based: sum(shipped) / sum(ordered).
        Service level is line-based: sum(adj_lines_incl_72h) / sum(lines_ordered).
        """
        logger.info("Getting fail to supply trends from %s to %s for materials: %s",
                    from_date,
                    to_date,
                    mat_nbrs
                    )
        prxo_q = Q(sales_group='PRxO')
        pharmagen_q = Q(sales_group='PGEN')

        qs = OrderTransaction.objects.filter(
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
            material_id__in=mat_nbrs,
        )
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        return list(
            qs
            .annotate(date=TruncDay('ord_created_date'))
            .values('material_id', 'date')
            .annotate(
                prxo_adj_lines=Sum(
                    Case(When(prxo_q, then='fts_adj_lines_incl_72_hours'), default=Value(0),
                         output_field=IntegerField())
                ),
                prxo_lines_ordered=Sum(
                    Case(When(prxo_q, then='fts_lines_ordered'), default=Value(0), output_field=IntegerField())
                ),
                pharmagen_adj_lines=Sum(
                    Case(When(pharmagen_q, then='fts_adj_lines_incl_72_hours'), default=Value(0),
                         output_field=IntegerField())
                ),
                pharmagen_lines_ordered=Sum(
                    Case(When(pharmagen_q, then='fts_lines_ordered'), default=Value(0), output_field=IntegerField())
                ),
                total_adj_lines=Sum('fts_adj_lines_incl_72_hours'),
                total_lines_ordered=Sum('fts_lines_ordered'),
                total_shipped_qty=Sum('total_shipped_qty'),
                total_order_qty=Sum('total_order_qty'),
            )
            .order_by('material__mat_nbr', 'date')
        )

    @staticmethod
    def get_customers_by_material_plant(mat_nbr, plant_nbr, from_date, to_date, corp_chain_nbr=None):
        """
        Returns per-customer inventory aggregates for a material and plant.
        Used by the Manage Inventory page customer drilldown (not Fail to Supply).
        Includes order/shipped qty, omit qty, imperfect lines, sales amount, and fill rate.
        """
        logger.info(
            "get_customers_by_material_plant: mat_nbr=%s plant_nbr=%s from=%s to=%s",
            mat_nbr,
            plant_nbr,
            from_date,
            to_date,
        )

        qs = OrderTransaction.objects.filter(
            material_id=mat_nbr,
            plant_id=plant_nbr,
            ord_created_date__gte=from_date,
            ord_created_date__lte=to_date,
        )
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        return (
            qs
            .values(
                'cust_nbr_id',
                'cust_nbr__name',
                'cust_corp_chain_nbr_id',
                'cust_corp_chain_nbr__name',
            )
            .annotate(
                order_qty=Coalesce(Sum('total_order_qty'), Value(0), output_field=IntegerField()),
                shipped_qty=Coalesce(Sum('total_shipped_qty'), Value(0), output_field=IntegerField()),
                adj_qty_sum=Coalesce(Sum('fts_adj_qty_incl_72_hours'), Value(0), output_field=DecimalField()),
                imperfect_lines=Coalesce(
                    Sum(
                        Case(
                            When(f_total_imperfect=1, then=Value(1)),
                            default=Value(0),
                            output_field=IntegerField(),
                        )
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                sales_amount=Coalesce(Sum('sales_amount'), Value(0), output_field=DecimalField()),
            )
            .annotate(
                omit_qty=F('order_qty') - F('adj_qty_sum'),
                outbound_fill_rate=Case(
                    When(order_qty__gt=0,
                         then=100.0 * F('shipped_qty') / F('order_qty')),
                    default=Value(None),
                    output_field=FloatField(),
                ),
            )
        )
