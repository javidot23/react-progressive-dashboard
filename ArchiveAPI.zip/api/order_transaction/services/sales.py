import logging
from datetime import date, timedelta

from django.contrib.postgres.expressions import ArraySubquery
from django.contrib.postgres.fields import ArrayField
from django.db.models import Case, CharField, DecimalField, ExpressionWrapper, OuterRef
from django.db.models import F, FloatField, Q, Sum, Value, When
from django.db.models.functions import Cast, Coalesce

from api.chargeback.models import Chargeback
from api.chargeback.services import OPEN_CLOSED as CHARGEBACK_OPEN_CLOSED
from api.date_bounds import calendar_month_bounds
from api.material_formulary.models import MaterialFormulary
from api.order_transaction.materialized_view_models import (
    OrderTransactionMaterial90dMV,
    OrderTransactionContract90dMV,
    OrderTransactionCustomer90dMV,
    OrderTransactionCorpChain90dMV,
    OrderTransactionMaterialGroup90dMV,
    OrderTransactionWeeklyMaterialMV,
    OrderTransactionStateMaterial90dMV,
    OrderTransactionClassOfTradeMaterial90dMV,
    OrderTransactionSalesGroupMaterial90dMV,
    OrderTransactionSalesGroupCorpChain90dMV,
)
from api.order_transaction.models import OrderTransaction

from .base import map_scrm_mat_grp_to_category

logger = logging.getLogger(__name__)


class SalesMixin:
    @staticmethod
    def get_sales_mtd_kpis(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Month-to-date sales KPIs for the sales page: total sales, contract sales, sales without
        a chargeback (no contract attached), and chargeback dollars.

        Sales dollars come from order transactions by ord_created_date; chargeback dollars from
        open/closed chargeback lines by chbk_hdr_created_date. Contract and non-contract sales
        partition total sales, so the two always add back up to it.
        """
        period_start, period_end, _, _ = calendar_month_bounds()
        logger.info("Retrieving sales MTD KPIs, %s..%s", period_start, period_end)

        sales_queryset = OrderTransaction.objects.filter(
            ord_created_date__gte=period_start,
            ord_created_date__lte=period_end,
        )
        if direct_mat_nbr:
            sales_queryset = sales_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            sales_queryset = sales_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
        if corp_chain_nbr:
            sales_queryset = sales_queryset.filter(cust_corp_chain_nbr=corp_chain_nbr)

        under_contract = Q(contract_name__isnull=False) & Q(contract_name__gt='')
        sales = sales_queryset.aggregate(
            total_sales_amount=Coalesce(
                Sum('sales_amount'), Value(0), output_field=DecimalField()
            ),
            contract_sales_amount=Coalesce(
                Sum(Case(When(under_contract, then='sales_amount'), output_field=DecimalField())),
                Value(0), output_field=DecimalField(),
            ),
            sales_without_chargeback_amount=Coalesce(
                Sum(Case(When(~under_contract, then='sales_amount'), output_field=DecimalField())),
                Value(0), output_field=DecimalField(),
            ),
        )

        chargeback_queryset = Chargeback.objects.filter(
            chbk_hdr_created_date__gte=period_start,
            chbk_hdr_created_date__lte=period_end,
            chbk_line_stat__in=CHARGEBACK_OPEN_CLOSED,
        )
        if direct_mat_nbr:
            chargeback_queryset = chargeback_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            chargeback_queryset = chargeback_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        chargebacks = chargeback_queryset.aggregate(
            chargeback_amount=Coalesce(
                Sum('abc_req_amt'), Value(0), output_field=DecimalField()
            ),
        )

        return {
            'period_start': period_start,
            'period_end': period_end,
            **sales,
            **chargebacks,
        }

    @staticmethod
    def get_material_sales(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns a QuerySet of materials aggregated by total sales quantity for the last 3 months,
        ordered by the highest sales quantity.
        Uses 90-day materialized view for improved performance.
        corp_chain_nbr filters directly via the corp_chain FK on the MV.
        """
        logger.info("Retrieving material sales for last 90 days from materialized view")
        queryset = OrderTransactionMaterial90dMV.objects.all()
        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
        return queryset.values(
            'material'
        ).annotate(
            name=F('material__name'),
            mat_nbr=F('material__mat_nbr'),
            total_sales_qty=Sum('total_shipped_qty')
        ).order_by('-total_sales_qty')

    @staticmethod
    def get_material_sales_with_contract_breakdown(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns materials with their contract sales breakdown for the last 3 months.
        Uses optimized subquery pattern to avoid expensive JOINs.
        corp_chain_nbr filters directly via the corp_chain FK on both MVs.
        """
        logging.info("Retrieving material sales with contract breakdown for last 90 days from materialized views")
        materials_base_queryset = OrderTransactionMaterial90dMV.objects.all()

        if corp_chain_nbr:
            materials_base_queryset = materials_base_queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            materials_base_queryset = materials_base_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            materials_base_queryset = materials_base_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        materials_queryset = materials_base_queryset.values(
            'material'
        ).annotate(
            mat_nbr=F('material__mat_nbr'),
            name=F('material__name'),
            total_sales_qty=Sum('total_shipped_qty')
        ).order_by('-total_sales_qty')

        materials = list(materials_queryset)

        # Get contract breakdowns using contract 90d MV (data already aggregated!)
        contract_base_queryset = OrderTransactionContract90dMV.objects.all()

        if corp_chain_nbr:
            contract_base_queryset = contract_base_queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            contract_base_queryset = contract_base_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            contract_base_queryset = contract_base_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        contract_queryset = contract_base_queryset.values(
            'material__mat_nbr',
            'contract_name',
        ).annotate(
            mat_nbr=F('material__mat_nbr'),
            contract_shipped_qty=Sum('total_shipped_qty'),
        ).order_by('mat_nbr', 'contract_name')

        contract_data = contract_queryset

        # Group contracts by material
        contract_dict = {}
        for contract in contract_data:
            key = contract['mat_nbr']
            if key not in contract_dict:
                contract_dict[key] = []
            contract_dict[key].append({
                'contract_name': contract['contract_name'],
                'total_sales_qty': contract['contract_shipped_qty'] or 0
            })

        # Combine the data
        for material in materials:
            mat_nbr = material['mat_nbr']
            material['contract_sales'] = contract_dict.get(mat_nbr, [])

        return materials

    @staticmethod
    def get_contract_sales(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns a QuerySet of contract sales aggregated by total sales quantity for the last 3 months.
        Uses optimized subquery pattern to avoid expensive JOINs.
        corp_chain_nbr filters directly via the corp_chain FK on the MV.
        """
        logging.info("Retrieving contract sales for last 90 days from materialized view")
        queryset = OrderTransactionContract90dMV.objects.all()

        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        return queryset.values(
            'contract_name'
        ).annotate(
            name=F('contract_name'),
            total_sales_qty=Sum('total_shipped_qty')
        ).order_by('-total_sales_qty')

    @staticmethod
    def get_corporate_chain_sales(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns a QuerySet of corporate chain sales aggregated by total sales quantity for the last 3 months.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logging.info("Retrieving corporate chain sales for last 90 days from materialized view")

        if direct_mat_nbr or mat_nbr_subquery is not None or corp_chain_nbr:
            three_months_ago = date.today() - timedelta(days=90)
            queryset = OrderTransaction.objects.filter(ord_created_date__gte=three_months_ago)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            if corp_chain_nbr:
                queryset = queryset.filter(cust_corp_chain_nbr=corp_chain_nbr)

            return queryset.values(
                "cust_corp_chain_nbr",
                name=F('cust_corp_chain_nbr__name')
            ).annotate(
                total_sales_qty=Sum('total_shipped_qty')
            ).order_by('-total_sales_qty')

        return OrderTransactionCorpChain90dMV.objects.values(
            'corp_chain'
        ).annotate(
            cust_corp_chain_nbr=F('corp_chain__cust_corp_chain_nbr'),
            name=F('corp_chain__name'),
            total_sales_qty=Sum('total_shipped_qty')
        ).order_by('-total_sales_qty')

    @staticmethod
    def get_corporate_sales_with_contract_breakdown(corp_chain_nbr=None):
        """
        Returns corporate chains with their contract sales breakdown for the last 3 months.
        corp_chain_nbr filters to a single corporate chain directly via FK.
        """
        # Get all corporate chains with their total sales from 90d MV
        corp_qs = OrderTransactionCorpChain90dMV.objects.all()
        if corp_chain_nbr:
            corp_qs = corp_qs.filter(corp_chain=corp_chain_nbr)
        corporates = list(
            corp_qs.values(
                'corp_chain'
            ).annotate(
                cust_corp_chain_nbr=F('corp_chain__cust_corp_chain_nbr'),
                name=F('corp_chain__name'),
                total_sales_qty=Sum('total_shipped_qty')
            ).order_by('-total_sales_qty')
        )

        # Get contract breakdowns using 90d MV (data already aggregated!)
        contract_qs = OrderTransactionCorpChain90dMV.objects.filter(
            contract_name__isnull=False,
            contract_name__gt=''
        )
        if corp_chain_nbr:
            contract_qs = contract_qs.filter(corp_chain=corp_chain_nbr)
        contract_data = contract_qs.annotate(
            cust_corp_chain_nbr=F('corp_chain__cust_corp_chain_nbr'),
            contract_shipped_qty=F('total_shipped_qty')
        ).values(
            'cust_corp_chain_nbr',
            'contract_name',
            'contract_shipped_qty'
        ).order_by('contract_name')

        # Group contracts by corporate chain
        contract_dict = {}
        for contract in contract_data:
            key = contract['cust_corp_chain_nbr']
            if key not in contract_dict:
                contract_dict[key] = []
            contract_dict[key].append({
                'contract_name': contract['contract_name'],
                'total_sales_qty': contract['contract_shipped_qty'] or 0
            })

        # Combine the data
        for corporate in corporates:
            corp_nbr = corporate['cust_corp_chain_nbr']
            corporate['contract_sales'] = contract_dict.get(corp_nbr, [])

        return corporates

    @staticmethod
    def get_material_sales_with_sales_group_breakdown(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns materials with their sales group breakdown for the last 3 months.
        Uses materialized views for pre-aggregated data.
        corp_chain_nbr filters directly via the corp_chain FK on both MVs.
        """
        logging.info("Retrieving material sales with sales group breakdown for last 90 days from materialized views")
        materials_base_queryset = OrderTransactionMaterial90dMV.objects.all()

        if corp_chain_nbr:
            materials_base_queryset = materials_base_queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            materials_base_queryset = materials_base_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            materials_base_queryset = materials_base_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        materials = list(
            materials_base_queryset.values(
                'material'
            ).annotate(
                mat_nbr=F('material__mat_nbr'),
                name=F('material__name'),
                total_sales_qty=Sum('total_shipped_qty')
            ).order_by('-total_sales_qty')
        )

        sg_base_queryset = OrderTransactionSalesGroupMaterial90dMV.objects.all()

        if corp_chain_nbr:
            sg_base_queryset = sg_base_queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            sg_base_queryset = sg_base_queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            sg_base_queryset = sg_base_queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        sg_data = sg_base_queryset.values(
            'material__mat_nbr',
            'sales_group',
        ).annotate(
            mat_nbr=F('material__mat_nbr'),
            shipped_qty=Sum('total_shipped_qty'),
        ).order_by('mat_nbr', 'sales_group')

        sales_group_dict = {}
        for row in sg_data:
            key = row['mat_nbr']
            if key not in sales_group_dict:
                sales_group_dict[key] = []
            sales_group_dict[key].append({
                'sales_group': row['sales_group'],
                'total_sales_qty': row['shipped_qty'] or 0,
            })

        for material in materials:
            material['sales_group_sales'] = sales_group_dict.get(material['mat_nbr'], [])

        return materials

    @staticmethod
    def get_corporate_sales_with_sales_group_breakdown(corp_chain_nbr=None):
        """
        Returns corporate chains with their sales group breakdown for the last 3 months.
        Uses materialized views for pre-aggregated data.
        corp_chain_nbr filters to a single corporate chain directly via FK.
        """
        logging.info("Retrieving corporate sales with sales group breakdown for last 90 days from materialized views")
        corp_qs = OrderTransactionSalesGroupCorpChain90dMV.objects.all()
        if corp_chain_nbr:
            corp_qs = corp_qs.filter(corp_chain=corp_chain_nbr)
        corporates = list(
            corp_qs.values(
                'corp_chain'
            ).annotate(
                cust_corp_chain_nbr=F('corp_chain__cust_corp_chain_nbr'),
                name=F('corp_chain__name'),
                total_sales_qty=Sum('total_shipped_qty')
            ).order_by('-total_sales_qty')
        )

        sg_qs = OrderTransactionSalesGroupCorpChain90dMV.objects.filter(
            sales_group__isnull=False,
            sales_group__gt=''
        )
        if corp_chain_nbr:
            sg_qs = sg_qs.filter(corp_chain=corp_chain_nbr)
        sg_data = sg_qs.annotate(
            cust_corp_chain_nbr=F('corp_chain__cust_corp_chain_nbr'),
            shipped_qty=F('total_shipped_qty')
        ).values(
            'cust_corp_chain_nbr',
            'sales_group',
            'shipped_qty'
        ).order_by('sales_group')

        sales_group_dict = {}
        for row in sg_data:
            key = row['cust_corp_chain_nbr']
            if key not in sales_group_dict:
                sales_group_dict[key] = []
            sales_group_dict[key].append({
                'sales_group': row['sales_group'],
                'total_sales_qty': row['shipped_qty'] or 0,
            })

        for corporate in corporates:
            corp_nbr = corporate['cust_corp_chain_nbr']
            corporate['sales_group_sales'] = sales_group_dict.get(corp_nbr, [])

        return corporates

    @staticmethod
    def get_material_order_quantities(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns a QuerySet of materials aggregated by total order quantity for the last 90 days,
        ordered by the highest order quantity with actual performance metrics.
        corp_chain_nbr filters directly via the corp_chain FK on the MV.
        fill_rate is recomputed from the summed quantities to stay correct when
        grouping across multiple corp_chain rows per material.
        """
        logger.info("Retrieving material order quantities for last 90 days")

        queryset = OrderTransactionMaterial90dMV.objects.all()
        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        return queryset.values(
            'material'
        ).annotate(
            material_name=F('material__name'),
            mat_nbr=F('material__mat_nbr'),
            ndc=F('material__ndc'),
            material_status=F('material__xplant_mat_stat'),
            forecast_qty_28day=F('material__forecast_qty_7day') * Value(4),
            total_order_qty=Sum('total_order_qty'),
            total_shipped_qty_sum=Sum('total_shipped_qty'),
            perfect_lines=Sum('perfect_lines'),
            imperfect_lines=Sum('imperfect_lines'),
            total_lines=Sum('total_orders'),
            unpredictable_demand=Sum('unpredictable_demand_count'),
            demand_variability=Sum('demand_variability_count'),
        ).annotate(
            fill_rate=Case(
                When(total_order_qty__gt=0,
                     then=ExpressionWrapper(
                         Cast(F('total_shipped_qty_sum'), FloatField()) /
                         Cast(F('total_order_qty'), FloatField()),
                         output_field=FloatField()
                     )),
                default=Value(0.0),
                output_field=FloatField(),
            ),
            perfect_line_rate=Case(
                When(total_lines__gt=0,
                     then=Cast(F('perfect_lines') * 100.0 / F('total_lines'), FloatField())),
                default=Value(0.0),
                output_field=FloatField(),
            )
        ).order_by('-total_order_qty')

    @staticmethod
    def list_material_order_quantities_mtd(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Materials aggregated by MTD order quantity (calendar month-to-date).

        Fill rate is shipped/ordered * 100 over the same window. Formulary is the
        distinct non-empty MaterialFormulary.sales_group values per material.
        """
        today = date.today()
        month_start = today.replace(day=1)
        logger.info(
            "Retrieving material order quantities MTD (%s to %s)",
            month_start,
            today,
        )

        queryset = OrderTransaction.objects.filter(
            ord_created_date__gte=month_start,
            ord_created_date__lte=today,
        )
        if corp_chain_nbr:
            queryset = queryset.filter(cust_corp_chain_nbr=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        formulary_sq = (
            MaterialFormulary.objects.filter(material=OuterRef("material"))
            .exclude(sales_group__isnull=True)
            .exclude(sales_group="")
            .order_by("sales_group")
            .values("sales_group")
            .distinct()
        )

        return (
            queryset.values("material")
            .annotate(
                material_number=F("material__mat_nbr"),
                material_name=F("material__name"),
                ndc=F("material__ndc"),
                material_status=F("material__xplant_mat_stat"),
                total_demand_mtd_units=Sum("total_order_qty"),
                total_shipped_qty_sum=Sum("total_shipped_qty"),
            )
            .annotate(
                fill_rate_percentage=Case(
                    When(
                        total_demand_mtd_units__gt=0,
                        then=ExpressionWrapper(
                            Cast(F("total_shipped_qty_sum"), FloatField())
                            / Cast(F("total_demand_mtd_units"), FloatField())
                            * Value(100.0),
                            output_field=FloatField(),
                        ),
                    ),
                    default=Value(0.0),
                    output_field=FloatField(),
                ),
                formulary=Coalesce(
                    ArraySubquery(formulary_sq),
                    Value([], output_field=ArrayField(CharField())),
                ),
            )
            .order_by("-total_demand_mtd_units", "material_number")
        )

    @staticmethod
    def get_cust_nbr_order_quantities(corp_chain_nbr=None):
        """
        Returns a QuerySet of customers aggregated by total order quantity for the last 90 days,
        ordered by the highest order quantity with actual performance metrics.
        Uses 90-day materialized view for improved performance.
        corp_chain_nbr filters via the customer__cust_corp_chain_nbr traversal.
        """
        # Get customers with all metrics from comprehensive 90d MV
        queryset = OrderTransactionCustomer90dMV.objects.all()
        if corp_chain_nbr:
            queryset = queryset.filter(customer__cust_corp_chain_nbr=corp_chain_nbr)
        return queryset.values(
            'customer'
        ).annotate(
            cust_nbr_name=F('customer__name'),
            cust_nbr=F('customer__cust_nbr'),
            total_order_qty=Sum('total_order_qty'),
            perfect_lines=Sum('perfect_lines'),
            imperfect_lines=Sum('imperfect_lines'),
            total_lines=Sum('total_orders'),
            unpredictable_demand=Sum('unpredictable_demand_count'),
            demand_variability=Sum('demand_variability_count'),
            perfect_line_rate=Case(
                When(total_lines__gt=0,
                     then=Cast(F('perfect_lines') * 100.0 / F('total_lines'), FloatField())),
                default=Value(0.0),
                output_field=FloatField(),
            )
        ).order_by('-total_order_qty')

    @staticmethod
    def get_class_of_trade_units(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns a QuerySet of class of trade units aggregated by total order quantity.
        Uses optimized subquery pattern to avoid expensive JOINs.
        corp_chain_nbr filters directly via the corp_chain FK on the MV.
        """
        queryset = OrderTransactionClassOfTradeMaterial90dMV.objects.all()

        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        return queryset.values(
            'class_of_trade_desc',
            'class_of_trade_nbr'
        ).annotate(
            class_of_trade=F('class_of_trade_desc'),
            class_of_trade_id=F('class_of_trade_nbr'),
            ordered_units=Sum('total_order_qty'),
            filled_units=Sum('total_shipped_qty')
        ).order_by('-ordered_units')

    @staticmethod
    def get_material_group_units(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns a QuerySet of material groups aggregated by total order quantity.
        Uses optimized subquery pattern to avoid expensive JOINs.
        corp_chain_nbr filters directly via the corp_chain FK on the MV (fast path)
        or via material FK traversal on the weekly material MV (filtered path).
        """
        if direct_mat_nbr or mat_nbr_subquery is not None:
            logger.info("get_material_group_units: Using weekly material MV with filters (fast path)")
            queryset = OrderTransactionWeeklyMaterialMV.objects.all()
            if corp_chain_nbr:
                queryset = queryset.filter(corp_chain=corp_chain_nbr)
            if direct_mat_nbr:
                queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
            if mat_nbr_subquery is not None:
                queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
            return queryset.values(
                'material__scrm_mat_grp'
            ).annotate(
                material_group=Case(
                    When(material__scrm_mat_grp='BRX', then=Value('Brand')),
                    When(material__scrm_mat_grp='GRX', then=Value('Generic')),
                    When(material__scrm_mat_grp='OTC', then=Value('OTC')),
                    default=Value('OTC'),
                    output_field=CharField()
                ),
                ordered_units=Sum('total_ordered'),
                filled_units=Sum('total_shipped')
            ).values(
                'material_group', 'ordered_units', 'filled_units'
            ).order_by('-ordered_units')

        mv_qs = OrderTransactionMaterialGroup90dMV.objects.all()
        if corp_chain_nbr:
            mv_qs = mv_qs.filter(corp_chain=corp_chain_nbr)
        return mv_qs.annotate(
            material_group_mapped=Case(
                When(material_group='BRX', then=Value('Brand')),
                When(material_group='GRX', then=Value('Generic')),
                When(material_group='OTC', then=Value('OTC')),
                default=Value('OTC'),
                output_field=CharField()
            )
        ).values(
            'material_group_mapped'
        ).annotate(
            material_group=F('material_group_mapped'),
            ordered_units=Sum('total_order_qty'),
            filled_units=Sum('total_shipped_qty')
        ).values(
            'material_group', 'ordered_units', 'filled_units'
        ).order_by('-ordered_units')

    @staticmethod
    def get_material_group_units_weekly(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns weekly aggregated data for the last 90 days, grouped by week with material groups as properties.
        """
        logger.info("Retrieving weekly material group units for last 90 days")
        ninety_days_ago = date.today() - timedelta(days=90)
        week_filter_date = ninety_days_ago - timedelta(days=6)

        queryset = OrderTransactionWeeklyMaterialMV.objects.filter(
            week_start__gte=week_filter_date,
            material__scrm_mat_grp__in=['BRX', 'GRX', 'OTC']
        )

        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        # Get raw weekly data grouped by week and material group
        weekly_mv_data = queryset.values(
            'week_start',
            'material__scrm_mat_grp'
        ).annotate(
            scrm_mat_grp=F('material__scrm_mat_grp'),
            ordered_units=Sum('total_ordered'),
            shipped_units=Sum('total_shipped')
        ).order_by('week_start', 'scrm_mat_grp')

        weekly_dict = {}
        for item in weekly_mv_data:
            week = item['week_start']
            if week not in weekly_dict:
                weekly_dict[week] = {
                    'week_start': week,
                    'brand_ordered_units': 0,
                    'brand_shipped_units': 0,
                    'generic_ordered_units': 0,
                    'generic_shipped_units': 0,
                    'otc_ordered_units': 0,
                    'otc_shipped_units': 0,
                }

            scrm_mat_grp = item['scrm_mat_grp']
            ordered_units = item['ordered_units'] or 0
            shipped_units = item['shipped_units'] or 0

            # Map scrm_mat_grp to category
            category = map_scrm_mat_grp_to_category(scrm_mat_grp)
            if category == 'brand':
                weekly_dict[week]['brand_ordered_units'] += ordered_units
                weekly_dict[week]['brand_shipped_units'] += shipped_units
            elif category == 'generic':
                weekly_dict[week]['generic_ordered_units'] += ordered_units
                weekly_dict[week]['generic_shipped_units'] += shipped_units
            elif category == 'otc':
                weekly_dict[week]['otc_ordered_units'] += ordered_units
                weekly_dict[week]['otc_shipped_units'] += shipped_units

        # Convert to list format, sorted by week
        weekly_data = [weekly_dict[week] for week in sorted(weekly_dict.keys())]

        return weekly_data

    @staticmethod
    def get_state_sales(direct_mat_nbr=None, mat_nbr_subquery=None, corp_chain_nbr=None):
        """
        Returns states with their total sales for the last 90 days.
        Uses optimized subquery pattern to avoid expensive JOINs.
        corp_chain_nbr filters directly via the corp_chain FK on the MV.
        """
        queryset = OrderTransactionStateMaterial90dMV.objects.all()

        if corp_chain_nbr:
            queryset = queryset.filter(corp_chain=corp_chain_nbr)
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)

        return queryset.values(
            'state'
        ).annotate(
            name=F('state'),
            total_sales_qty=Sum('total_shipped_qty')
        ).order_by('-total_sales_qty')
