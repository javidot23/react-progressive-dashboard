from django.apps import AppConfig


class OrderTransactionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.order_transaction'
