from rest_framework import serializers

from api.material.serializers import MaterialSerializer
from api.order_transaction.models import OrderTransaction
from api.plant.serializers import PlantSerializer
from api.serializer_mixins import NanSafeSerializerMixin
from api.vendor.serializers import VendorSerializer


class OrderTransactionSerializerWithMaterialAndPlant(serializers.ModelSerializer):
    material = MaterialSerializer()
    supplier = VendorSerializer(source='material.vendor')
    sub_material = MaterialSerializer(source='substituted_material', allow_null=True)
    substituted_material_supplier = VendorSerializer(source='substituted_material.vendor', allow_null=True)
    plant = PlantSerializer()
    ar_plant = PlantSerializer()

    class Meta:
        model = OrderTransaction
        fields = "__all__"


class OptimizedMaterialSerializer(serializers.Serializer):
    """Minimal material serializer with only required fields."""
    mat_nbr = serializers.CharField()
    name = serializers.CharField()


class OptimizedVendorSerializer(serializers.Serializer):
    """Minimal vendor serializer with only required fields."""
    vendor_nbr = serializers.CharField()
    name = serializers.CharField(allow_null=True)


class OptimizedPlantSerializer(serializers.Serializer):
    """Minimal plant serializer with only required fields."""
    plant_nbr = serializers.CharField()
    name = serializers.CharField(allow_null=True)


class OptimizedOrderTransactionSerializer(serializers.ModelSerializer):
    """
    Minimalist serializer for OrderTransaction with related fields.
    """
    material = OptimizedMaterialSerializer(read_only=True)
    supplier = OptimizedVendorSerializer(source='material.vendor', read_only=True, allow_null=True)
    sub_material = OptimizedMaterialSerializer(source='substituted_material', read_only=True, allow_null=True)
    substituted_material_supplier = OptimizedVendorSerializer(
        source='substituted_material.vendor',
        read_only=True,
        allow_null=True
    )
    plant = OptimizedPlantSerializer(read_only=True)
    ar_plant = OptimizedPlantSerializer(read_only=True, allow_null=True)

    class Meta:
        model = OrderTransaction
        fields = [
            'id',
            'sales_doc_nbr',
            'sales_doc_itm_nbr',
            'material',
            'material_status',
            'supplier',
            'plant',
            'ar_plant',
            'total_order_qty',
            'ord_created_date',
            'sub_material',
            'substituted_material_supplier',
            'sub_reas_code_name',
        ]


class PlantSubstitutionStatsSerializer(serializers.Serializer):
    plant = serializers.CharField()
    plant__name = serializers.CharField()
    plant__plant_nbr = serializers.CharField()
    total_orders = serializers.IntegerField()
    total_materials = serializers.IntegerField()
    substituted_count = serializers.IntegerField()
    substituted_percent = serializers.FloatField()
    alt_served_count = serializers.IntegerField()
    alt_served_percent = serializers.FloatField()


class SalesComparisonByMonthSerializer(serializers.Serializer):
    month = serializers.CharField()
    month_num = serializers.IntegerField()
    last_year_sales = serializers.IntegerField()
    current_year_sales = serializers.IntegerField()


class MaterialSalesSerializer(serializers.Serializer):
    name = serializers.CharField()
    mat_nbr = serializers.CharField()
    total_sales_qty = serializers.IntegerField()


class ContractSalesBreakdownSerializer(serializers.Serializer):
    contract_name = serializers.CharField()
    total_sales_qty = serializers.IntegerField()


class MaterialSalesWithContractSerializer(serializers.Serializer):
    name = serializers.CharField()
    mat_nbr = serializers.CharField()
    total_sales_qty = serializers.IntegerField()
    contract_sales = ContractSalesBreakdownSerializer(many=True)


class ContractCorporateSalesSerializer(serializers.Serializer):
    name = serializers.CharField()
    total_sales_qty = serializers.IntegerField()


class CorporateSalesWithContractSerializer(serializers.Serializer):
    name = serializers.CharField()
    corporate_chain_nbr = serializers.CharField(source="cust_corp_chain_nbr")
    total_sales_qty = serializers.IntegerField()
    contract_sales = ContractSalesBreakdownSerializer(many=True)


class SalesGroupSalesBreakdownSerializer(serializers.Serializer):
    sales_group = serializers.CharField()
    total_sales_qty = serializers.IntegerField()


class MaterialSalesWithSalesGroupSerializer(serializers.Serializer):
    name = serializers.CharField()
    mat_nbr = serializers.CharField()
    total_sales_qty = serializers.IntegerField()
    sales_group_sales = SalesGroupSalesBreakdownSerializer(many=True)


class CorporateSalesWithSalesGroupSerializer(serializers.Serializer):
    name = serializers.CharField()
    corporate_chain_nbr = serializers.CharField(source="cust_corp_chain_nbr")
    total_sales_qty = serializers.IntegerField()
    sales_group_sales = SalesGroupSalesBreakdownSerializer(many=True)


class MaterialOrderQuantitySerializer(serializers.Serializer):
    material_name = serializers.CharField()
    mat_nbr = serializers.CharField()
    ndc = serializers.CharField(allow_null=True)
    material_status = serializers.CharField()
    fill_rate = serializers.FloatField()
    total_order_qty = serializers.IntegerField()
    forecast_qty_28day = serializers.IntegerField(allow_null=True)
    perfect_line_rate = serializers.FloatField()
    imperfect_lines = serializers.IntegerField()
    unpredictable_demand = serializers.IntegerField()
    demand_variability = serializers.IntegerField()


class MaterialOrderQuantityMtdSerializer(serializers.Serializer):
    """Calendar MTD material demand row for the FE order-quantities table."""

    material_number = serializers.CharField(allow_null=True)
    material_name = serializers.CharField(allow_null=True)
    ndc = serializers.CharField(allow_null=True)
    total_demand_mtd_units = serializers.IntegerField(allow_null=True)
    fill_rate_percentage = serializers.FloatField(allow_null=True)
    material_status = serializers.CharField(allow_null=True)
    formulary = serializers.ListField(
        child=serializers.CharField(allow_null=True),
        allow_empty=True,
        required=False,
    )

    class Meta:
        ref_name = "OrderTransactionMaterialOrderQuantityMtd"


class SoldToPartyOrderQuantitySerializer(serializers.Serializer):
    cust_nbr = serializers.CharField()
    cust_nbr_name = serializers.CharField()
    total_order_qty = serializers.IntegerField()
    perfect_line_rate = serializers.FloatField()
    imperfect_lines = serializers.IntegerField()
    unpredictable_demand = serializers.IntegerField()
    demand_variability = serializers.IntegerField()


class ClassOfTradeUnitsSerializer(serializers.Serializer):
    class_of_trade_id = serializers.CharField()
    class_of_trade = serializers.CharField()
    ordered_units = serializers.IntegerField()
    filled_units = serializers.IntegerField()


class MaterialGroupUnitsSerializer(serializers.Serializer):
    material_group = serializers.CharField()
    ordered_units = serializers.IntegerField()
    filled_units = serializers.IntegerField()


class MaterialGroupUnitsWeeklySerializer(serializers.Serializer):
    week_start = serializers.DateField()
    brand_ordered_units = serializers.IntegerField(default=0)
    brand_shipped_units = serializers.IntegerField(default=0)
    generic_ordered_units = serializers.IntegerField(default=0)
    generic_shipped_units = serializers.IntegerField(default=0)
    otc_ordered_units = serializers.IntegerField(default=0)
    otc_shipped_units = serializers.IntegerField(default=0)


class StateSalesSerializer(serializers.Serializer):
    name = serializers.CharField()
    total_sales_qty = serializers.IntegerField()


class OverallAltServedStatsSerializer(serializers.Serializer):
    total_orders = serializers.IntegerField()
    alt_served_orders = serializers.IntegerField()
    alt_served_percentage = serializers.FloatField()


class AltServedWeeklyByMaterialGroupSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    total_orders = serializers.IntegerField(default=0)

    # Generic fields
    generic_alt_served_count = serializers.IntegerField(default=0)
    generic_alt_served_percentage = serializers.FloatField(default=0.0)

    # Brand fields
    brand_alt_served_count = serializers.IntegerField(default=0)
    brand_alt_served_percentage = serializers.FloatField(default=0.0)

    # OTC fields
    otc_alt_served_count = serializers.IntegerField(default=0)
    otc_alt_served_percentage = serializers.FloatField(default=0.0)


class AltServedTotalsByMaterialGroupSerializer(serializers.Serializer):
    material_group = serializers.CharField()
    alt_served_count = serializers.IntegerField()
    alt_served_percentage = serializers.FloatField()


class OverallSubstitutedStatsSerializer(serializers.Serializer):
    total_orders = serializers.IntegerField()
    substituted_orders = serializers.IntegerField()
    substituted_percentage = serializers.FloatField()


class SubstitutedWeeklyByMaterialGroupSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    total_orders = serializers.IntegerField(default=0)

    # Generic fields
    generic_substituted_count = serializers.IntegerField(default=0)
    generic_substituted_percentage = serializers.FloatField(default=0.0)

    # Brand fields
    brand_substituted_count = serializers.IntegerField(default=0)
    brand_substituted_percentage = serializers.FloatField(default=0.0)

    # OTC fields
    otc_substituted_count = serializers.IntegerField(default=0)
    otc_substituted_percentage = serializers.FloatField(default=0.0)


class SubstitutedTotalsByMaterialGroupSerializer(serializers.Serializer):
    material_group = serializers.CharField()
    substituted_count = serializers.IntegerField()
    substituted_percentage = serializers.FloatField()


class WeeklyOrderAnalysisSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    total_orders = serializers.IntegerField()
    total_order_qty = serializers.IntegerField()
    total_shipped_qty = serializers.IntegerField()
    alt_served_count = serializers.IntegerField()
    alt_served_percentage = serializers.FloatField()
    substituted_count = serializers.IntegerField()
    substituted_percentage = serializers.FloatField()
    perfect_order_rate = serializers.FloatField()
    perfect_orders = serializers.IntegerField()


class OrderKpisSerializer(serializers.Serializer):
    total_orders = serializers.IntegerField()
    total_units = serializers.IntegerField()
    alt_served_orders = serializers.IntegerField()
    alt_served_units = serializers.IntegerField()
    alt_serve_rate = serializers.FloatField()
    substituted_orders = serializers.IntegerField()
    substituted_units = serializers.IntegerField()
    substitution_rate = serializers.FloatField()
    perfect_orders = serializers.IntegerField()
    perfect_order_rate = serializers.FloatField()


class SalesMtdKpisSerializer(serializers.Serializer):
    """
    Month-to-date sales KPIs. `sales_without_chargeback_amount` covers sales with no contract
    attached, so it and `contract_sales_amount` partition `total_sales_amount`.
    """
    period_start = serializers.DateField()
    period_end = serializers.DateField()
    total_sales_amount = serializers.DecimalField(max_digits=38, decimal_places=2)
    contract_sales_amount = serializers.DecimalField(max_digits=38, decimal_places=2)
    sales_without_chargeback_amount = serializers.DecimalField(max_digits=38, decimal_places=2)
    chargeback_amount = serializers.DecimalField(max_digits=38, decimal_places=2)


class SubstitutionAltServeKpisSerializer(serializers.Serializer):
    """Returns percentage of materials that have substitution/alt serve."""
    total_materials = serializers.IntegerField()
    materials_with_substitution = serializers.IntegerField()
    substitution_percent = serializers.FloatField()
    materials_with_alt_serve = serializers.IntegerField()
    alt_serve_percent = serializers.FloatField()


class WeeklyFtsExposureSerializer(serializers.Serializer):
    """Total Fail to Supply exposure quantity for the current ISO week."""
    week_start = serializers.DateField()
    week_end = serializers.DateField()
    exposure_qty = serializers.IntegerField()


class AltServedBreakdownByClassOfTradeSerializer(serializers.Serializer):
    class_of_trade = serializers.CharField()
    alt_served_count = serializers.IntegerField()
    alt_served_percentage = serializers.FloatField()


class AltServedBreakdownByPlantSerializer(serializers.Serializer):
    plant = serializers.CharField()
    alt_served_count = serializers.IntegerField()
    alt_served_percentage = serializers.FloatField()


class AltServeBreakdownByMaterialStatusSerializer(serializers.Serializer):
    status = serializers.CharField()
    alt_served_count = serializers.IntegerField()
    alt_served_percentage = serializers.FloatField()


class AltServedMaterialsByStatusSerializer(serializers.Serializer):
    material_name = serializers.CharField()
    mat_nbr = serializers.CharField()
    alt_served_count = serializers.IntegerField()
    alt_served_percentage = serializers.FloatField()


class AltServedUnitsByTypeWeeklySerializer(serializers.Serializer):
    week_start = serializers.DateField()
    auto_units = serializers.IntegerField()
    manual_units = serializers.IntegerField()
    total_units = serializers.IntegerField()


class CostRangeOrderQtyByMaterialStatusSerializer(serializers.Serializer):
    cost_range = serializers.CharField()
    material_statuses = serializers.DictField(child=serializers.IntegerField())


class MaterialStatusSerializer(serializers.Serializer):
    material_status = serializers.CharField()


class MaterialOmitWeeklyCountSerializer(serializers.Serializer):
    year = serializers.IntegerField()
    week = serializers.IntegerField()
    week_start = serializers.DateField()
    week_end = serializers.DateField()
    excess_omits_count = serializers.IntegerField()
    allowed_omits_count = serializers.IntegerField()
    no_omits_count = serializers.IntegerField()


class MaterialOmitCountThisYearSerializer(serializers.Serializer):
    """
    Represents omit counts for the last 3 months (weekly breakdown).
    """
    excess_omits_count = serializers.IntegerField()
    allowed_omits_count = serializers.IntegerField()
    no_omits_count = serializers.IntegerField()
    total_products_ordered = serializers.IntegerField()
    total_products_with_omits = serializers.IntegerField()
    weekly_data = MaterialOmitWeeklyCountSerializer(many=True)

    class Meta:
        ref_name = 'OrderTransactionMaterialOmitCountThisYear'


class FulfillmentMetricsSerializer(serializers.Serializer):
    """
    Serializer for fulfillment metrics.
    """
    year = serializers.IntegerField()
    week = serializers.IntegerField()
    week_start = serializers.DateField()
    week_end = serializers.DateField()
    unshipped_quantity = serializers.FloatField()
    fulfillment_percentage = serializers.FloatField()

    class Meta:
        ref_name = 'OrderTransactionFulfillmentMetrics'


class WeeklyPerfectOrderAnalysisSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    total_orders = serializers.IntegerField()
    perfect_orders = serializers.IntegerField()
    perfect_order_rate = serializers.FloatField()


class WeeklyImperfectLineRateAnalysisSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    total_orders = serializers.IntegerField()
    unpredictable_demand_count = serializers.IntegerField()
    unpredictable_demand_rate = serializers.FloatField()
    omit_inflation_count = serializers.IntegerField()
    omit_inflation_rate = serializers.FloatField()
    unaligned_forecast_count = serializers.IntegerField()
    unaligned_forecast_rate = serializers.FloatField()
    demand_imperfect_count = serializers.IntegerField()
    demand_imperfect_rate = serializers.FloatField()


class OTSalesComparisonBySalesGroupSerializer(serializers.Serializer):
    sales_group = serializers.CharField(allow_null=True)
    current_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)


class OTSalesComparisonByStateSerializer(serializers.Serializer):
    state = serializers.CharField(source='cust_nbr__state', allow_null=True)
    current_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)


class OTSalesComparisonByMaterialSerializer(serializers.Serializer):
    mat_nbr = serializers.CharField(source='material_id')
    material_name = serializers.CharField(source='material__name', allow_null=True)
    current_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)


class OTSalesComparisonByCustomerSerializer(serializers.Serializer):
    cust_corp_chain_nbr = serializers.CharField(source='cust_corp_chain_nbr_id', allow_null=True)
    customer_name = serializers.CharField(source='cust_corp_chain_nbr__name', allow_null=True)
    current_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)


class WeeklySalesBySalesGroupSerializer(serializers.Serializer):
    """Weekly sales per sales_group for a 4-week window around each provided week."""
    sales_group = serializers.CharField(allow_null=True)
    week_start = serializers.DateField()
    sales_amount = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    total_order_qty = serializers.IntegerField(allow_null=True)
    total_shipped_qty = serializers.IntegerField(allow_null=True)


class WeeklySalesBySalesGroupSalesSerializer(serializers.Serializer):
    sales_group = serializers.CharField(allow_null=True)
    sales_amount = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    total_order_qty = serializers.IntegerField(allow_null=True)
    total_shipped_qty = serializers.IntegerField(allow_null=True)


class WeeklySalesBySalesGroupWeekSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    sales = WeeklySalesBySalesGroupSalesSerializer(many=True)


class AltServedByMaterialGroupResponseSerializer(serializers.Serializer):
    overall_stats = OverallAltServedStatsSerializer()
    totals_by_group = AltServedTotalsByMaterialGroupSerializer(many=True)
    weekly_data = AltServedWeeklyByMaterialGroupSerializer(many=True)


class SubstitutedByMaterialGroupResponseSerializer(serializers.Serializer):
    overall_stats = OverallSubstitutedStatsSerializer()
    totals_by_group = SubstitutedTotalsByMaterialGroupSerializer(many=True)
    weekly_data = SubstitutedWeeklyByMaterialGroupSerializer(many=True)


class AltServedBreakdownAnalysisResponseSerializer(serializers.Serializer):
    totals_by_group = AltServedTotalsByMaterialGroupSerializer(many=True)
    total_by_class_of_trade = AltServedBreakdownByClassOfTradeSerializer(many=True)
    totals_by_plant = AltServedBreakdownByPlantSerializer(many=True)


class WeeklySalesTimelineSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    sales_amount = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    total_order_qty = serializers.IntegerField()
    total_shipped_qty = serializers.IntegerField()


class FailToSupplyMaterialSerializer(serializers.Serializer):
    """Scalars for low-outbound / FTS material cards and drill-through table."""

    mat_nbr = serializers.CharField(source='material_id')
    material_name = serializers.CharField(source='material__name', allow_null=True)
    material_ndc = serializers.CharField(source='material__ndc', allow_null=True)
    outbound_fill_rate = serializers.FloatField(allow_null=True)
    unfilled_quantity = serializers.FloatField(allow_null=True)
    omits_qty = serializers.FloatField(allow_null=True)
    omits_qty_last_month = serializers.FloatField(allow_null=True)
    sales_amount = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    sales_qty = serializers.IntegerField(allow_null=True)
    total_demand = serializers.IntegerField(allow_null=True)
    prxo_service_level = serializers.FloatField(allow_null=True)
    pharmagen_service_level = serializers.FloatField(allow_null=True)
    material_status = serializers.CharField(source='material__xplant_mat_stat', allow_null=True)
    contract_type = serializers.CharField(allow_null=True)
    forecast_qty_28day = serializers.IntegerField(allow_null=True)


class ServiceLevelWeekSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    service_level = serializers.FloatField(allow_null=True)
    prxo_service_level = serializers.FloatField(allow_null=True)
    pharmagen_service_level = serializers.FloatField(allow_null=True)


class ServiceLevelKpiSerializer(serializers.Serializer):
    current = serializers.FloatField(allow_null=True)
    previous = serializers.FloatField(allow_null=True)
    change = serializers.FloatField(allow_null=True)
    change_pct = serializers.FloatField(allow_null=True)


class ServiceLevelPeriodSerializer(serializers.Serializer):
    from_date = serializers.DateField()
    to_date = serializers.DateField()


class ServiceLevelKpisSerializer(serializers.Serializer):
    """Weekly service level trend plus the week-to-date summary per KPI card."""

    from_date = serializers.DateField()
    to_date = serializers.DateField()
    weekly = ServiceLevelWeekSerializer(many=True)
    current_period = ServiceLevelPeriodSerializer()
    previous_period = ServiceLevelPeriodSerializer()
    service_level = ServiceLevelKpiSerializer()
    prxo_service_level = ServiceLevelKpiSerializer()
    pharmagen_service_level = ServiceLevelKpiSerializer()


class FailToSupplyPlantSerializer(serializers.Serializer):
    plant_nbr = serializers.CharField(source='plant_id')
    plant_name = serializers.CharField(source='plant__name', allow_null=True)
    prxo_missed_lines = serializers.IntegerField()
    pgen_missed_lines = serializers.IntegerField()
    total_missed_lines = serializers.IntegerField()
    total_missed_lines_pct = serializers.FloatField(allow_null=True)
    outbound_fill_rate = serializers.FloatField(allow_null=True)
    service_level = serializers.FloatField(allow_null=True)
    omit_qty = serializers.FloatField()
    demand_qty = serializers.IntegerField()
    ordered_lines = serializers.IntegerField(source='total_lines_ordered')


class MaterialPlantCustomerSerializer(serializers.Serializer):
    """Serializer for inventory customer drilldown on the Manage Inventory page."""
    cust_nbr = serializers.CharField(source='cust_nbr_id', allow_null=True)
    customer_name = serializers.CharField(source='cust_nbr__name', allow_null=True)
    cust_corp_chain_nbr = serializers.CharField(source='cust_corp_chain_nbr_id', allow_null=True)
    cust_corp_chain_name = serializers.CharField(source='cust_corp_chain_nbr__name', allow_null=True)
    order_qty = serializers.IntegerField()
    shipped_qty = serializers.IntegerField()
    omit_qty = serializers.FloatField()
    imperfect_lines = serializers.IntegerField()
    sales_amount = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    outbound_fill_rate = serializers.FloatField(allow_null=True)


class UnfilledMaterialSerializer(NanSafeSerializerMixin, serializers.Serializer):
    """Flat fields for the Unfilled Materials drill-through table."""

    material_number = serializers.CharField(allow_null=True)
    material_name = serializers.CharField(allow_null=True)
    ndc = serializers.CharField(allow_null=True)
    unfilled_quantity = serializers.IntegerField(allow_null=True)
    ordered_quantity = serializers.IntegerField(allow_null=True)
    outbound_fill_rate = serializers.FloatField(allow_null=True)
    saleable_qty_on_hand = serializers.IntegerField(allow_null=True)
    forecast_qty_7day = serializers.IntegerField(allow_null=True)
    forecast_qty_28day = serializers.IntegerField(allow_null=True)
    next_expected_arrival_date = serializers.DateField(allow_null=True)
    on_order_qty = serializers.IntegerField(allow_null=True)

    class Meta:
        ref_name = "OrderTransactionUnfilledMaterial"
