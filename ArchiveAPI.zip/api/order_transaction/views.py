from datetime import date as _date
from datetime import timedelta

from django.conf import settings
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiParameter, extend_schema, extend_schema_view, inline_serializer
from rest_framework import generics, serializers, status
from rest_framework.exceptions import ValidationError as _ValidationError
from rest_framework.exceptions import ValidationError
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView

from api.csv_export import (
    CsvExportView,
    enforce_export_row_cap_count,
    get_filtered_ordered_queryset,
    streaming_csv_response,
    wrap_csv_rows_with_tenant,
)
from api.global_filters import get_filtered_material_subquery, FederalCsIndFilterMixin, extract_corp_chain_param
from api.material_formulary.services import MaterialFormularyService
from .filters import OrderTransactionFilter, FailToSupplyPlantFilter, FailToSupplyMaterialFilter, \
    InventoryMaterialPlantCustomerFilter, \
    UnfilledMaterialsFilter
from .models import OrderTransaction
from .serializers import (
    OTSalesComparisonBySalesGroupSerializer,
    OTSalesComparisonByStateSerializer,
    OTSalesComparisonByMaterialSerializer,
    OTSalesComparisonByCustomerSerializer,
    WeeklySalesTimelineSerializer,
    WeeklySalesBySalesGroupWeekSerializer,
    AltServedByMaterialGroupResponseSerializer,
    SubstitutedByMaterialGroupResponseSerializer,
    AltServedBreakdownAnalysisResponseSerializer,
    FailToSupplyMaterialSerializer,
    ServiceLevelKpisSerializer,
    FailToSupplyPlantSerializer,
    MaterialPlantCustomerSerializer,
    UnfilledMaterialSerializer,
    WeeklyFtsExposureSerializer,
    SalesMtdKpisSerializer,
)
from .serializers import PlantSubstitutionStatsSerializer, ContractCorporateSalesSerializer, \
    OptimizedOrderTransactionSerializer, \
    MaterialOrderQuantitySerializer, \
    MaterialOrderQuantityMtdSerializer, \
    SoldToPartyOrderQuantitySerializer, ClassOfTradeUnitsSerializer, MaterialGroupUnitsSerializer, \
    MaterialGroupUnitsWeeklySerializer, \
    MaterialSalesWithContractSerializer, CorporateSalesWithContractSerializer, \
    MaterialSalesWithSalesGroupSerializer, CorporateSalesWithSalesGroupSerializer, StateSalesSerializer, \
    MaterialSalesSerializer, AltServedWeeklyByMaterialGroupSerializer, AltServedTotalsByMaterialGroupSerializer, \
    OverallAltServedStatsSerializer, SubstitutedWeeklyByMaterialGroupSerializer, \
    SubstitutedTotalsByMaterialGroupSerializer, OverallSubstitutedStatsSerializer, WeeklyOrderAnalysisSerializer, \
    OrderKpisSerializer, SubstitutionAltServeKpisSerializer, AltServedBreakdownByClassOfTradeSerializer, \
    AltServedBreakdownByPlantSerializer, AltServeBreakdownByMaterialStatusSerializer, \
    AltServedMaterialsByStatusSerializer, AltServedUnitsByTypeWeeklySerializer, \
    CostRangeOrderQtyByMaterialStatusSerializer, MaterialStatusSerializer, \
    MaterialOmitCountThisYearSerializer, FulfillmentMetricsSerializer, WeeklyPerfectOrderAnalysisSerializer, \
    WeeklyImperfectLineRateAnalysisSerializer
from .services import OrderTransactionService
from ..pagination import MaxLimitOffsetPagination

_SALES_COMPARISON_DATE_PARAMS = [
    OpenApiParameter(name='current_start_date', type=OpenApiTypes.DATE, required=True),
    OpenApiParameter(name='current_end_date', type=OpenApiTypes.DATE, required=True),
    OpenApiParameter(name='previous_start_date', type=OpenApiTypes.DATE, required=True),
    OpenApiParameter(name='previous_end_date', type=OpenApiTypes.DATE, required=True),
]

_PAGINATED_FAIL_TO_SUPPLY_MATERIAL_RESPONSE = inline_serializer(
    'PaginatedFailToSupplyMaterialResponse',
    fields={
        'count': serializers.IntegerField(),
        'next': serializers.URLField(allow_null=True, required=False),
        'previous': serializers.URLField(allow_null=True, required=False),
        'results': FailToSupplyMaterialSerializer(many=True),
    },
)

FAIL_TO_SUPPLY_MATERIAL_ORDERING_FIELDS = [
    'outbound_fill_rate',
    'unfilled_quantity',
    'omits_qty',
    'omits_qty_last_month',
    'sales_amount',
    'sales_qty',
    'total_demand',
    'prxo_service_level',
    'pharmagen_service_level',
    'forecast_qty_28day',
    'mat_nbr',
    'material_name',
]
FAIL_TO_SUPPLY_MATERIAL_DEFAULT_ORDERING = ['outbound_fill_rate']
FAIL_TO_SUPPLY_MATERIAL_ORDERING_MAP = {
    'mat_nbr': 'material_id',
}

FAIL_TO_SUPPLY_MATERIAL_OPENAPI_PARAMETERS = [
    OpenApiParameter(name='from_date', type=OpenApiTypes.DATE, required=False,
                     description='Start of metrics window (default: today - 90 days).'),
    OpenApiParameter(name='to_date', type=OpenApiTypes.DATE, required=False,
                     description='End of metrics window (default: today).'),
    OpenApiParameter(
        name='ordering',
        type=OpenApiTypes.STR,
        required=False,
        enum=[
            'outbound_fill_rate', '-outbound_fill_rate',
            'unfilled_quantity', '-unfilled_quantity',
            'omits_qty', '-omits_qty',
            'omits_qty_last_month', '-omits_qty_last_month',
            'sales_amount', '-sales_amount',
            'sales_qty', '-sales_qty',
            'total_demand', '-total_demand',
            'prxo_service_level', '-prxo_service_level',
            'pharmagen_service_level', '-pharmagen_service_level',
            'forecast_qty_28day', '-forecast_qty_28day',
            'mat_nbr', '-mat_nbr',
            'material_name', '-material_name',
        ],
        description='Sort field (prefix with - for descending). Default: outbound_fill_rate.',
    ),
    OpenApiParameter(
        name='contract_type',
        type=OpenApiTypes.STR,
        required=False,
        description=(
            'Restrict to materials whose most frequent contract over the window '
            'matches this value (case-insensitive).'
        ),
    ),
]

_PAGINATED_OT_SALES_COMPARISON_BY_MATERIAL_RESPONSE = inline_serializer(
    'PaginatedOTSalesComparisonByMaterialResponse',
    fields={
        'count': serializers.IntegerField(),
        'next': serializers.URLField(allow_null=True, required=False),
        'previous': serializers.URLField(allow_null=True, required=False),
        'results': OTSalesComparisonByMaterialSerializer(many=True),
    },
)

_PAGINATED_OT_SALES_COMPARISON_BY_CUSTOMER_RESPONSE = inline_serializer(
    'PaginatedOTSalesComparisonByCustomerResponse',
    fields={
        'count': serializers.IntegerField(),
        'next': serializers.URLField(allow_null=True, required=False),
        'previous': serializers.URLField(allow_null=True, required=False),
        'results': OTSalesComparisonByCustomerSerializer(many=True),
    },
)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class PlantOrderStatsView(generics.ListAPIView):
    """
    API view to retrieve statistics about order transactions by plant.
    Note: This returns aggregated plant-level data, so material filters are not applicable.
    """
    serializer_class = PlantSubstitutionStatsSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        return OrderTransactionService.get_substituted_and_alt_served_material_count_by_plant()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialSalesView(generics.ListAPIView):
    """
    API view to retrieve materials sorted by their total sales quantity.
    Supports global filters for material-related fields.
    """
    serializer_class = MaterialSalesSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        corp_chain_nbr = extract_corp_chain_param(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request, skip_corp_chain=True)
        return OrderTransactionService.get_material_sales(direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialWithContractSalesView(generics.ListAPIView):
    """
    API view to retrieve materials sorted by their total sales quantity.
    Supports global filters for material-related fields.
    """
    serializer_class = MaterialSalesWithContractSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        corp_chain_nbr = extract_corp_chain_param(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request, skip_corp_chain=True)
        return OrderTransactionService.get_material_sales_with_contract_breakdown(
            direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class ContractSalesView(generics.ListAPIView):
    """
    API view to retrieve contract sales sorted by their total sales quantity.
    Supports global filters through underlying order transactions.
    """
    serializer_class = ContractCorporateSalesSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        corp_chain_nbr = extract_corp_chain_param(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request, skip_corp_chain=True)
        return OrderTransactionService.get_contract_sales(direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class CorporateSalesView(generics.ListAPIView):
    """
    API view to retrieve corporate sales sorted by their total sales quantity.
    Supports global filters through underlying order transactions.
    """
    serializer_class = ContractCorporateSalesSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        corp_chain_nbr = extract_corp_chain_param(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request, skip_corp_chain=True)
        return OrderTransactionService.get_corporate_chain_sales(
            direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr=corp_chain_nbr
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class CorporateWithContractSalesView(generics.ListAPIView):
    """
    API view to retrieve corporate chains with contract breakdown sorted by their total sales quantity.
    """
    serializer_class = CorporateSalesWithContractSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        corp_chain_nbr = extract_corp_chain_param(self.request)
        return OrderTransactionService.get_corporate_sales_with_contract_breakdown(corp_chain_nbr)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialWithSalesGroupSalesView(generics.ListAPIView):
    """
    API view to retrieve materials sorted by their total sales quantity with sales group breakdown.
    Supports global filters for material-related fields.
    """
    serializer_class = MaterialSalesWithSalesGroupSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        return get_material_with_sales_group_sales_results(self.request)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class CorporateWithSalesGroupSalesView(generics.ListAPIView):
    """
    API view to retrieve corporate chains with sales group breakdown sorted by their total sales quantity.
    Supports global material filters via query params (formulary, xplant_mat_stat, material, who_essential).
    """
    serializer_class = CorporateSalesWithSalesGroupSerializer
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        return get_corporate_with_sales_group_sales_results(self.request)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class OrderTransactionView(generics.ListAPIView):
    """
    API view to retrieve order transactions with filtering, ordering, and pagination.
    Uses optimized serializer and query to improve performance on large datasets.
    """
    serializer_class = OptimizedOrderTransactionSerializer
    pagination_class = MaxLimitOffsetPagination
    filterset_class = OrderTransactionFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = [
        'id', 'sales_doc_nbr', 'ord_created_date', 'total_order_qty',
        'total_shipped_qty', 'material__name', 'plant__name',
        'ar_plant__name', 'contract_name', 'corporate_chain_name', 'material_status'
    ]
    ordering = ['-ord_created_date']

    def get_queryset(self):
        return OrderTransactionService.get_optimized_order_transactions()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class ClassOfTradeUnitsView(generics.ListAPIView):
    """
    API view to retrieve class of trade units aggregated by total order quantity
    and sales quantity for the last 90 days.
    Supports global filters through underlying order transactions.
    """
    serializer_class = ClassOfTradeUnitsSerializer
    pagination_class = None

    def get_queryset(self):
        corp_chain_nbr = extract_corp_chain_param(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request, skip_corp_chain=True)
        return OrderTransactionService.get_class_of_trade_units(direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr)


MATERIAL_ORDER_QUANTITIES_ORDERING_FIELDS = [
    'material_name',
    'mat_nbr',
    'ndc',
    'material_status',
    'fill_rate',
    'total_order_qty',
    'forecast_qty_28day',
    'perfect_line_rate',
    'imperfect_lines',
    'unpredictable_demand',
    'demand_variability',
]

MATERIAL_ORDER_QUANTITIES_OPENAPI_PARAMETERS = [
    OpenApiParameter(
        name='ordering',
        type=OpenApiTypes.STR,
        required=False,
        enum=[field for field in MATERIAL_ORDER_QUANTITIES_ORDERING_FIELDS for field in (field, f'-{field}')],
        description='Sort field (prefix with - for descending). Default: -total_order_qty.',
    ),
]

UNFILLED_MATERIALS_ORDERING_FIELDS = [
    'material_number',
    'material_name',
    'ndc',
    'unfilled_quantity',
    'ordered_quantity',
    'outbound_fill_rate',
    'saleable_qty_on_hand',
    'forecast_qty_7day',
    'forecast_qty_28day',
    'on_order_qty',
    'next_expected_arrival_date',
]
UNFILLED_MATERIALS_DEFAULT_ORDERING = ['-unfilled_quantity', 'material_number']

UNFILLED_MATERIALS_OPENAPI_PARAMETERS = [
    OpenApiParameter(
        name='ordering',
        type=OpenApiTypes.STR,
        required=False,
        enum=[field for field in UNFILLED_MATERIALS_ORDERING_FIELDS for field in (field, f'-{field}')],
        description='Sort field (prefix with - for descending). Default: -unfilled_quantity, material_number.',
    ),
]


def get_material_order_quantities_queryset(request):
    corp_chain_nbr = extract_corp_chain_param(request)
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
    return OrderTransactionService.get_material_order_quantities(
        direct_mat_nbr,
        mat_nbr_subquery,
        corp_chain_nbr,
    )


def get_sold_to_party_order_quantities_queryset(request):
    corp_chain_nbr = extract_corp_chain_param(request)
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(
        request, skip_corp_chain=True
    )
    return OrderTransactionService.get_cust_nbr_order_quantities(
        direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr
    )


SOLD_TO_PARTY_ORDERING_FIELDS = [
    'cust_nbr',
    'cust_nbr_name',
    'total_order_qty',
    'perfect_line_rate',
    'imperfect_lines',
    'unpredictable_demand',
    'demand_variability',
]


def get_material_with_sales_group_sales_results(request):
    corp_chain_nbr = extract_corp_chain_param(request)
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
    return OrderTransactionService.get_material_sales_with_sales_group_breakdown(
        direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr
    )


def get_corporate_with_sales_group_sales_results(request):
    corp_chain_nbr = extract_corp_chain_param(request)
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(
        request, skip_corp_chain=True
    )
    return OrderTransactionService.get_corporate_sales_with_sales_group_breakdown(
        direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr
    )


def get_unfilled_materials_queryset(request):
    corp_chain_nbr = extract_corp_chain_param(request)
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(
        request, skip_corp_chain=True
    )
    return OrderTransactionService.list_unfilled_materials(
        direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr
    )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialOrderQuantitiesView(generics.ListAPIView):
    """
    API view to retrieve materials aggregated by total order quantity for the last 90 days.
    Supports global filters for material-related fields and ordering via the ordering query param.
    """
    serializer_class = MaterialOrderQuantitySerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [OrderingFilter]
    ordering_fields = MATERIAL_ORDER_QUANTITIES_ORDERING_FIELDS
    ordering = ['-total_order_qty']

    def get_queryset(self):
        return get_material_order_quantities_queryset(self.request)


class MaterialOrderQuantitiesExportView(CsvExportView):
    """
    Stream all filtered Products in High Demand rows in the table's current order.
    limit and offset query params are ignored.
    """

    filename_prefix = "products_in_high_demand"
    ordering_fields = MATERIAL_ORDER_QUANTITIES_ORDERING_FIELDS
    default_ordering = ['-total_order_qty']
    strict_ordering = True

    @extend_schema(
        operation_id="api_order_transaction_material_order_quantities_export",
        parameters=MATERIAL_ORDER_QUANTITIES_OPENAPI_PARAMETERS,
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_base_queryset(self, request):
        return get_material_order_quantities_queryset(request)

    def iter_csv_rows(self, queryset):
        return OrderTransactionService.iter_material_order_quantities_csv_rows(queryset)


class SoldToPartyOrderQuantitiesExportView(CsvExportView):
    """
    Stream all filtered High Demand customer rows in the table's current order.
    limit and offset query params are ignored.
    """

    filename_prefix = "products_in_high_demand_customers"
    ordering_fields = SOLD_TO_PARTY_ORDERING_FIELDS
    default_ordering = ['-total_order_qty']
    strict_ordering = True

    @extend_schema(
        operation_id="api_order_transaction_sold_to_party_order_quantities_export",
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_base_queryset(self, request):
        return get_sold_to_party_order_quantities_queryset(request)

    def iter_csv_rows(self, queryset):
        return OrderTransactionService.iter_sold_to_party_order_quantities_csv_rows(queryset)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
@extend_schema_view(get=extend_schema(operation_id='api_order_transaction_material_order_quantities_mtd_list'))
class MaterialOrderQuantitiesMtdView(generics.ListAPIView):
    """
    Materials aggregated by calendar month-to-date order quantity.
    Returns material identity, MTD demand, fill rate %, status, and distinct formulary sales_groups.
    Supports global filters (cust_corp_chain via OT direct FK), ordering, and pagination.
    """
    serializer_class = MaterialOrderQuantityMtdSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [OrderingFilter]
    ordering_fields = [
        'material_number',
        'material_name',
        'ndc',
        'total_demand_mtd_units',
        'fill_rate_percentage',
        'material_status',
    ]
    ordering = ['-total_demand_mtd_units', 'material_number']

    def get_queryset(self):
        corp_chain_nbr = extract_corp_chain_param(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(
            self.request, skip_corp_chain=True
        )
        return OrderTransactionService.list_material_order_quantities_mtd(
            direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr
        )

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        rows = list(queryset) if page is None else page

        context = self.get_serializer_context()
        context['formulary_map'] = MaterialFormularyService.get_formulary_map(
            [row['material'] for row in rows]
        )
        serializer = self.get_serializer(rows, many=True, context=context)

        if page is None:
            return Response(serializer.data)
        return self.get_paginated_response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class SoldToPartyOrderQuantitiesView(generics.ListAPIView):
    """
    API view to retrieve cust_nbr aggregated by total order quantity for the last 90 days.
    Supports ordering via the ordering query param.
    """
    serializer_class = SoldToPartyOrderQuantitySerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [OrderingFilter]
    ordering_fields = [
        'cust_nbr',
        'cust_nbr_name',
        'total_order_qty',
        'perfect_line_rate',
        'imperfect_lines',
        'unpredictable_demand',
        'demand_variability',
    ]
    ordering = ['-total_order_qty']

    def get_queryset(self):
        return get_sold_to_party_order_quantities_queryset(self.request)


class MaterialWithSalesGroupSalesExportView(APIView):
    """Stream Top Units Sales (material grouping) as CSV; limit and offset are ignored."""

    @extend_schema(
        operation_id="api_order_transaction_material_with_sales_group_sales_export",
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        results = get_material_with_sales_group_sales_results(request)
        enforce_export_row_cap_count(len(results))
        tenant = getattr(request, "tenant", None)
        rows = OrderTransactionService.iter_material_with_sales_group_sales_csv_rows(results)
        if tenant is not None:
            rows = wrap_csv_rows_with_tenant(tenant, rows)
        return streaming_csv_response(rows, "material_with_sales_group_sales")


class CorporateWithSalesGroupSalesExportView(APIView):
    """Stream Top Units Sales (corporate chain grouping) as CSV; limit and offset are ignored."""

    @extend_schema(
        operation_id="api_order_transaction_corporate_with_sales_group_sales_export",
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        results = get_corporate_with_sales_group_sales_results(request)
        enforce_export_row_cap_count(len(results))
        tenant = getattr(request, "tenant", None)
        rows = OrderTransactionService.iter_corporate_with_sales_group_sales_csv_rows(results)
        if tenant is not None:
            rows = wrap_csv_rows_with_tenant(tenant, rows)
        return streaming_csv_response(rows, "corporate_with_sales_group_sales")


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialGroupUnitsView(generics.ListAPIView):
    """
    API view to retrieve material group units aggregated by total order quantity
    and sales quantity for the last 90 days.
    Supports global filters through underlying order transactions.
    """
    serializer_class = MaterialGroupUnitsSerializer
    pagination_class = None

    def get_queryset(self):
        corp_chain_nbr = extract_corp_chain_param(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request, skip_corp_chain=True)
        return OrderTransactionService.get_material_group_units(direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr)


@extend_schema_view(
    get=extend_schema(responses=MaterialGroupUnitsWeeklySerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialGroupUnitsWeeklyView(APIView):
    """
    API view to retrieve weekly material group units for the last 90 days.
    Returns ordered units and shipped units grouped by week, with separate fields for Brand, Generic, and OTC.
    Each week is a single object with properties for each material group.
    Supports global filters through underlying order transactions.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        weekly_data = OrderTransactionService.get_material_group_units_weekly(direct_mat_nbr, mat_nbr_subquery,
                                                                              corp_chain_nbr)
        serializer = MaterialGroupUnitsWeeklySerializer(weekly_data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class StateSalesView(generics.ListAPIView):
    """
    API view to retrieve states sorted by their total sales quantity.
    Supports global filters through underlying order transactions.
    """
    serializer_class = StateSalesSerializer
    pagination_class = None

    def get_queryset(self):
        corp_chain_nbr = extract_corp_chain_param(self.request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request, skip_corp_chain=True)
        return OrderTransactionService.get_state_sales(direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr)


@extend_schema_view(
    get=extend_schema(responses=AltServedByMaterialGroupResponseSerializer),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class AltServedByMaterialGroupWeeklyView(APIView):
    """
    API view to retrieve alt-served order analysis by material group
    for the last 90 days including weekly breakdown, totals, and overall stats.
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        analysis_data = OrderTransactionService.get_alt_served_analysis_by_material_group(direct_mat_nbr,
                                                                                          mat_nbr_subquery,
                                                                                          corp_chain_nbr)

        weekly_serializer = AltServedWeeklyByMaterialGroupSerializer(
            analysis_data['weekly_data'], many=True
        )
        totals_serializer = AltServedTotalsByMaterialGroupSerializer(
            analysis_data['totals_by_group'], many=True
        )
        overall_serializer = OverallAltServedStatsSerializer(
            analysis_data['overall_stats']
        )

        return Response({
            'overall_stats': overall_serializer.data,
            'totals_by_group': totals_serializer.data,
            'weekly_data': weekly_serializer.data
        })


@extend_schema_view(
    get=extend_schema(responses=SubstitutedByMaterialGroupResponseSerializer),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SubstitutedByMaterialGroupWeeklyView(APIView):
    """
    API view to retrieve substitution order analysis by material group
    for the last 90 days including weekly breakdown, totals, and overall stats.
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        analysis_data = OrderTransactionService.get_substitution_analysis_by_material_group(direct_mat_nbr,
                                                                                            mat_nbr_subquery,
                                                                                            corp_chain_nbr)

        weekly_serializer = SubstitutedWeeklyByMaterialGroupSerializer(
            analysis_data['weekly_data'], many=True
        )
        totals_serializer = SubstitutedTotalsByMaterialGroupSerializer(
            analysis_data['totals_by_group'], many=True
        )
        overall_serializer = OverallSubstitutedStatsSerializer(
            analysis_data['overall_stats']
        )

        return Response({
            'overall_stats': overall_serializer.data,
            'totals_by_group': totals_serializer.data,
            'weekly_data': weekly_serializer.data
        })


@extend_schema_view(
    get=extend_schema(responses=WeeklyOrderAnalysisSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyOrderAnalysisView(APIView):
    """
    API view to retrieve weekly order analysis for the last 90 days including:
    - Total orders per week
    - Alt-served orders count and percentage
    - Substituted orders count and percentage
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        weekly_data = OrderTransactionService.get_weekly_order_analysis(direct_mat_nbr, mat_nbr_subquery,
                                                                        corp_chain_nbr)
        serializer = WeeklyOrderAnalysisSerializer(weekly_data, many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=OrderKpisSerializer),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OrderKpisView(APIView):
    """
    API view to retrieve comprehensive order statistics for the last 90 days including:
    - Alt serve rate (percentage and count)
    - Substitution rate (percentage and count)
    - Perfect order rate
    - Total orders and units
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        stats_data = OrderTransactionService.get_order_kpi_stats(direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr)
        serializer = OrderKpisSerializer(stats_data)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=SalesMtdKpisSerializer),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesMtdKpisView(APIView):
    """
    Month-to-date sales KPIs for the sales page: total sales dollars, contract sales dollars,
    sales without a chargeback (no contract attached), and chargeback dollars.

    Sales dollars are taken by order created date, chargeback dollars by chargeback header
    created date. Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        data = OrderTransactionService.get_sales_mtd_kpis(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        serializer = SalesMtdKpisSerializer(data)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=SubstitutionAltServeKpisSerializer),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SubstitutionAltServeKpisView(APIView):
    """
    API view to retrieve substitution and alt serve KPI statistics.
    Returns percentage of materials that have substitution/alt serve.
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        stats_data = OrderTransactionService.get_substitution_alt_serve_kpi_stats(
            direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr)
        serializer = SubstitutionAltServeKpisSerializer(stats_data)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=AltServedBreakdownAnalysisResponseSerializer),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class AltServedBreakdownAnalysisView(APIView):
    """
    API view to retrieve alt-served order breakdown analysis by material group,
    class of trade, and plant for the last 90 days.
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        analysis_data = OrderTransactionService.get_alt_served_breakdown_analysis(direct_mat_nbr, mat_nbr_subquery,
                                                                                  corp_chain_nbr)

        material_group_serializer = AltServedTotalsByMaterialGroupSerializer(
            analysis_data['totals_by_group'], many=True
        )
        class_of_trade_serializer = AltServedBreakdownByClassOfTradeSerializer(
            analysis_data['total_by_class_of_trade'], many=True
        )
        plant_serializer = AltServedBreakdownByPlantSerializer(
            analysis_data['totals_by_plant'], many=True
        )

        return Response({
            'totals_by_group': material_group_serializer.data,
            'total_by_class_of_trade': class_of_trade_serializer.data,
            'totals_by_plant': plant_serializer.data
        })


@extend_schema_view(
    get=extend_schema(responses=AltServeBreakdownByMaterialStatusSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class AltServedByMaterialStatusView(APIView):
    """
    API view to get alt served orders grouped by material status.
    Returns percentage breakdown of alt served orders by material status.
    Supports global filters.
    """

    def get(self, request):
        """Get alt served breakdown by material status"""
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        breakdown_data = OrderTransactionService.get_alt_served_by_material_status(direct_mat_nbr, mat_nbr_subquery,
                                                                                   corp_chain_nbr)
        serializer = AltServeBreakdownByMaterialStatusSerializer(breakdown_data, many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=AltServedMaterialsByStatusSerializer(many=True),
        parameters=[
            OpenApiParameter(
                name='material_status',
                type=OpenApiTypes.STR,
                location=OpenApiParameter.PATH,
                required=True,
            ),
        ],
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class AltServedMaterialsByStatusView(APIView):
    """
    API view to get alt served materials breakdown by percentage for a specific material status.
    Returns materials that have been alt served within the last 90 days.
    Supports global filters.
    """

    def get(self, request, material_status):
        """Get alt served materials breakdown by material status"""
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        breakdown_data = OrderTransactionService.get_alt_served_materials_by_status(material_status, direct_mat_nbr,
                                                                                    mat_nbr_subquery, corp_chain_nbr)
        serializer = AltServedMaterialsByStatusSerializer(breakdown_data, many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=AltServedUnitsByTypeWeeklySerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class AltServedUnitsByTypeWeeklyView(APIView):
    """
    API view to retrieve weekly aggregated alt served units grouped by alt_serve_type
    for the last 90 days.
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        weekly_data = OrderTransactionService.get_alt_served_units_by_type_weekly(direct_mat_nbr, mat_nbr_subquery,
                                                                                  corp_chain_nbr)
        serializer = AltServedUnitsByTypeWeeklySerializer(weekly_data, many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=CostRangeOrderQtyByMaterialStatusSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class AltServedOrderQtyByCostRangeAndMaterialStatusView(APIView):
    """
    Returns total_order_qty for each cost_per_unit range and material_status.
    Supports global filters.
    """

    def get(self, request):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        data = OrderTransactionService.get_alt_served_order_qty_by_cost_range_and_status(direct_mat_nbr,
                                                                                         mat_nbr_subquery,
                                                                                         corp_chain_nbr)
        serialized_data = CostRangeOrderQtyByMaterialStatusSerializer(
            [{"cost_range": k, "material_statuses": v} for k, v in data.items()],
            many=True
        ).data
        return Response(serialized_data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialStatusListView(generics.ListAPIView):
    """
    API view to retrieve distinct material statuses from order transactions.
    """
    serializer_class = MaterialStatusSerializer
    pagination_class = None

    def get_queryset(self):
        return OrderTransactionService.get_material_status_distinct()


@extend_schema_view(
    get=extend_schema(
        responses=MaterialOmitCountThisYearSerializer,
        parameters=[
            OpenApiParameter(name='fill_rate_threshold', type=OpenApiTypes.FLOAT, required=False),
        ],
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class MaterialOmitCountLastThreeMonthsView(APIView):
    """
    Returns distinct count of materials with Excess Omits, Allowed Omits and No Omits
    for the last 3 months, along with weekly breakdown.
    Supports global filters.
    """

    def get(self, request):
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=84)  # Approximately 12 weeks

        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)

        fill_rate_threshold_str = request.query_params.get('fill_rate_threshold')
        if fill_rate_threshold_str:
            try:
                fill_rate_threshold = float(fill_rate_threshold_str)
            except (ValueError, TypeError):
                fill_rate_threshold = 0.85
        else:
            fill_rate_threshold = 0.85

        grouped_data = OrderTransactionService.get_material_omit_counts_for_period(
            start_date, end_date, direct_mat_nbr, mat_nbr_subquery, fill_rate_threshold, corp_chain_nbr
        )

        weekly_data = (
            OrderTransactionService.get_material_omit_counts_for_last_three_months_weekly(
                direct_mat_nbr, mat_nbr_subquery, fill_rate_threshold, corp_chain_nbr
            )
        )
        combined_data = {
            **grouped_data,
            "weekly_data": weekly_data,
        }
        serializer = MaterialOmitCountThisYearSerializer(combined_data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
@extend_schema_view(get=extend_schema(operation_id='api_order_transaction_unfilled_materials_list'))
class UnfilledMaterialsView(generics.ListAPIView):
    """
    Materials with aggregate fill rate under 1.0 over the last 90 days (OT material MV).
    Drill-through for MaterialOmitCountLastThreeMonthsView. Includes material inventory,
    forecast, demand-forecast on-order, and next open PO anticipated_date.
    Supports global filters (cust_corp_chain via OT MV), ordering, and pagination.
    """
    serializer_class = UnfilledMaterialSerializer
    filterset_class = UnfilledMaterialsFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = UNFILLED_MATERIALS_ORDERING_FIELDS
    ordering = UNFILLED_MATERIALS_DEFAULT_ORDERING
    pagination_class = MaxLimitOffsetPagination

    def get_queryset(self):
        return get_unfilled_materials_queryset(self.request)


class UnfilledMaterialsExportView(CsvExportView):
    """
    Stream all filtered Products With Unfilled Quantity rows in the table's current order.
    limit and offset query params are ignored.
    """

    filename_prefix = "products_with_unfilled_quantity"
    filterset_class = UnfilledMaterialsFilter
    ordering_fields = UNFILLED_MATERIALS_ORDERING_FIELDS
    default_ordering = UNFILLED_MATERIALS_DEFAULT_ORDERING
    strict_ordering = True

    @extend_schema(
        operation_id="api_order_transaction_unfilled_materials_export",
        parameters=UNFILLED_MATERIALS_OPENAPI_PARAMETERS,
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_base_queryset(self, request):
        return get_unfilled_materials_queryset(request)

    def iter_csv_rows(self, queryset):
        return OrderTransactionService.iter_unfilled_materials_csv_rows(queryset)


@extend_schema_view(
    get=extend_schema(responses=FulfillmentMetricsSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class FulfillmentMetricsView(APIView):
    """
    Returns the total quantity ordered but not shipped and the fulfillment percentage for the last 90 days,
    aggregated per week.
    Supports global filters.
    """

    def get(self, request):
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=90)

        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)

        data = OrderTransactionService.get_fulfillment_metrics_weekly(start_date, end_date, direct_mat_nbr,
                                                                      mat_nbr_subquery, corp_chain_nbr)
        serializer = FulfillmentMetricsSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema_view(
    get=extend_schema(responses=WeeklyPerfectOrderAnalysisSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyPerfectOrderAnalysisView(APIView):
    """
    API view to retrieve weekly perfect order analysis for the last 90 days including:
    - Total orders per week
    - Perfect orders count (orders without alt serve or substitution)
    - Perfect order rate percentage
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        weekly_data = OrderTransactionService.get_weekly_perfect_order_analysis(direct_mat_nbr, mat_nbr_subquery,
                                                                                corp_chain_nbr)
        serializer = WeeklyPerfectOrderAnalysisSerializer(weekly_data, many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=WeeklyImperfectLineRateAnalysisSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyImperfectLineRateAnalysisView(APIView):
    """
    API view to retrieve weekly imperfect line rate analysis for the last 90 days including:
    - Unpredictable Demand Imperfect Line Rate
    - Omit Inflation Imperfect Line Rate
    - Unaligned Forecast Imperfect Line Rate
    - Demand Planning Imperfect Line Rate
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        weekly_data = OrderTransactionService.get_weekly_imperfect_line_rate_analysis(direct_mat_nbr, mat_nbr_subquery,
                                                                                      corp_chain_nbr)
        serializer = WeeklyImperfectLineRateAnalysisSerializer(weekly_data, many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=WeeklySalesTimelineSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklySalesTimelineView(FederalCsIndFilterMixin, APIView):
    """
    Returns weekly sales totals (sales_amount, total_order_qty, total_shipped_qty)
    for the last 90 days, ordered chronologically.
    Supports all global material filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        data = OrderTransactionService.get_weekly_sales_timeline(direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr)
        data = self.apply_federal_cs_ind_filter(data, request)
        serializer = WeeklySalesTimelineSerializer(data, many=True)
        return Response(serializer.data)


def _parse_date_params(request):
    """
    Parses current_start_date, current_end_date, previous_start_date, previous_end_date
    from query params. Raises ValidationError (400) if any are missing or malformed.
    """
    params = {}
    for key in ('current_start_date', 'current_end_date', 'previous_start_date', 'previous_end_date'):
        raw = request.query_params.get(key)
        if not raw:
            raise _ValidationError({key: 'This parameter is required.'})
        try:
            params[key] = _date.fromisoformat(raw)
        except ValueError:
            raise _ValidationError({key: f'Invalid date format. Expected YYYY-MM-DD, got "{raw}".'})
    return params['current_start_date'], params['current_end_date'], params['previous_start_date'], params[
        'previous_end_date']


@extend_schema_view(
    get=extend_schema(
        responses=OTSalesComparisonBySalesGroupSerializer(many=True),
        parameters=_SALES_COMPARISON_DATE_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OTSalesComparisonBySalesGroupView(FederalCsIndFilterMixin, APIView):
    """
    Returns sales comparison (current period vs previous period) grouped by sales_group,
    queried directly from order_transactions.

    Query params (all required, format YYYY-MM-DD):
      - current_start_date
      - current_end_date
      - previous_start_date
      - previous_end_date

    Optional global material filters: supplier, product_family, therapeutic_class,
    buyer, category_manager, material, gcn, formulary, etc.
    """

    def get(self, request, *args, **kwargs):
        current_start, current_end, previous_start, previous_end = _parse_date_params(request)
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        data = OrderTransactionService.get_sales_comparison_by_sales_group(
            current_start, current_end, previous_start, previous_end, direct_mat_nbr, mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        data = self.apply_federal_cs_ind_filter(data, request)
        serializer = OTSalesComparisonBySalesGroupSerializer(list(data), many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=OTSalesComparisonByStateSerializer(many=True),
        parameters=_SALES_COMPARISON_DATE_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OTSalesComparisonByStateView(FederalCsIndFilterMixin, APIView):
    """
    Returns sales comparison (current period vs previous period) grouped by state,
    queried directly from order_transactions (state via cust_nbr__state).

    Query params (all required, format YYYY-MM-DD):
      - current_start_date, current_end_date, previous_start_date, previous_end_date

    Optional global material filters apply.
    """

    def get(self, request, *args, **kwargs):
        current_start, current_end, previous_start, previous_end = _parse_date_params(request)
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        data = OrderTransactionService.get_sales_comparison_by_state(
            current_start, current_end, previous_start, previous_end, direct_mat_nbr, mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        data = self.apply_federal_cs_ind_filter(data, request)
        serializer = OTSalesComparisonByStateSerializer(list(data), many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=_PAGINATED_OT_SALES_COMPARISON_BY_MATERIAL_RESPONSE,
        parameters=_SALES_COMPARISON_DATE_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OTSalesComparisonByMaterialView(FederalCsIndFilterMixin, APIView):
    """
    Returns paginated sales comparison (current period vs previous period) grouped by material,
    ordered by current_period_sales desc. Queried directly from order_transactions.

    Query params (all required, format YYYY-MM-DD):
      - current_start_date, current_end_date, previous_start_date, previous_end_date

    Pagination: limit (default 25, max 50), offset.
    Optional global material filters apply.
    """
    pagination_class = MaxLimitOffsetPagination

    def get(self, request, *args, **kwargs):
        current_start, current_end, previous_start, previous_end = _parse_date_params(request)
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        queryset = OrderTransactionService.get_sales_comparison_by_material(
            current_start, current_end, previous_start, previous_end, direct_mat_nbr, mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        queryset = self.apply_federal_cs_ind_filter(queryset, request)
        paginator = self.pagination_class()
        paginator.default_limit = 25
        page = paginator.paginate_queryset(queryset, request)
        serializer = OTSalesComparisonByMaterialSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=_PAGINATED_OT_SALES_COMPARISON_BY_CUSTOMER_RESPONSE,
        parameters=_SALES_COMPARISON_DATE_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OTSalesComparisonByCustomerView(FederalCsIndFilterMixin, APIView):
    """
    Returns paginated sales comparison (current period vs previous period) grouped by customer
    corp chain, ordered by current_period_sales desc. Queried directly from order_transactions.

    Query params (all required, format YYYY-MM-DD):
      - current_start_date, current_end_date, previous_start_date, previous_end_date

    Pagination: limit (default 25, max 50), offset.
    Optional global material filters apply.
    """
    pagination_class = MaxLimitOffsetPagination

    def get(self, request, *args, **kwargs):
        current_start, current_end, previous_start, previous_end = _parse_date_params(request)
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        queryset = OrderTransactionService.get_sales_comparison_by_customer(
            current_start, current_end, previous_start, previous_end, direct_mat_nbr, mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        queryset = self.apply_federal_cs_ind_filter(queryset, request)
        paginator = self.pagination_class()
        paginator.default_limit = 25
        page = paginator.paginate_queryset(queryset, request)
        serializer = OTSalesComparisonByCustomerSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=WeeklySalesBySalesGroupWeekSerializer(many=True),
        parameters=[
            OpenApiParameter(name='current_week', type=OpenApiTypes.DATE, required=True),
            OpenApiParameter(name='previous_week', type=OpenApiTypes.DATE, required=True),
        ],
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklySalesBySalesGroupView(APIView):
    """
    Returns weekly sales per sales_group for two 4-week windows ending at the
    provided week dates, grouped by week.

    Query params (both required, format YYYY-MM-DD — should be a Monday):
      - current_week
      - previous_week

    Response: list of {week_start, sales: [{sales_group, sales_amount, total_order_qty, total_shipped_qty}]}
    Optional global material filters apply.
    """

    def get(self, request, *args, **kwargs):
        current_week_raw = request.query_params.get('current_week')
        previous_week_raw = request.query_params.get('previous_week')

        if not current_week_raw or not previous_week_raw:
            raise _ValidationError({'detail': 'current_week and previous_week are required (YYYY-MM-DD).'})

        try:
            current_week = _date.fromisoformat(current_week_raw)
            previous_week = _date.fromisoformat(previous_week_raw)
        except ValueError:
            raise _ValidationError({'detail': 'Invalid date format. Expected YYYY-MM-DD.'})

        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        data = OrderTransactionService.get_weekly_sales_by_sales_group(
            current_week=current_week,
            previous_week=previous_week,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )
        return Response(data)


@extend_schema_view(
    get=extend_schema(responses=WeeklyFtsExposureSerializer),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyFtsExposureView(APIView):
    """
    Total Fail to Supply exposure quantity for the current ISO week (Monday through today).

    Exposure is unsupplied demand: sum(total_order_qty) - sum(fts_adj_qty_incl_72_hours).
    Supports global filters.
    """

    def get(self, request, *args, **kwargs):
        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        data = OrderTransactionService.get_weekly_fts_exposure_qty(
            direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr
        )
        serializer = WeeklyFtsExposureSerializer(data)
        return Response(serializer.data)


def get_fail_to_supply_material_window(request):
    """Metrics window from from_date/to_date, defaulting to the last 90 days."""
    today = _date.today()
    from_date_raw = request.query_params.get(
        'from_date', (today - timedelta(days=90)).isoformat()
    )
    to_date_raw = request.query_params.get('to_date', today.isoformat())
    try:
        return _date.fromisoformat(from_date_raw), _date.fromisoformat(to_date_raw)
    except ValueError:
        raise _ValidationError({'detail': 'Invalid date format. Expected YYYY-MM-DD.'})


def get_fail_to_supply_material_base_queryset(request):
    from_date, to_date = get_fail_to_supply_material_window(request)

    corp_chain_nbr = extract_corp_chain_param(request)
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(
        request, skip_corp_chain=True
    )
    queryset = OrderTransactionService.get_fail_to_supply_materials(
        from_date,
        to_date,
        direct_mat_nbr,
        mat_nbr_subquery,
        corp_chain_nbr=corp_chain_nbr,
    )

    contract_type = request.query_params.get('contract_type')
    if contract_type:
        contract_types = OrderTransactionService.get_material_contract_types(
            None, from_date, to_date, corp_chain_nbr=corp_chain_nbr
        )
        wanted = contract_type.casefold()
        queryset = queryset.filter(material_id__in=[
            mat_nbr for mat_nbr, name in contract_types.items()
            if name.casefold() == wanted
        ])

    return queryset


def get_fail_to_supply_material_filtered_queryset(request, base_queryset=None):
    if base_queryset is None:
        base_queryset = get_fail_to_supply_material_base_queryset(request)
    return get_filtered_ordered_queryset(
        request,
        base_queryset,
        FailToSupplyMaterialFilter,
        FAIL_TO_SUPPLY_MATERIAL_ORDERING_FIELDS,
        FAIL_TO_SUPPLY_MATERIAL_DEFAULT_ORDERING,
        FAIL_TO_SUPPLY_MATERIAL_ORDERING_MAP,
        strict_ordering=True,
    )


@extend_schema_view(
    get=extend_schema(
        responses=ServiceLevelKpisSerializer,
        parameters=[
            OpenApiParameter(name='from_date', type=OpenApiTypes.DATE, required=False,
                             description='Start of trend window (default: today - 90 days).'),
            OpenApiParameter(name='to_date', type=OpenApiTypes.DATE, required=False,
                             description='End of trend window (default: today).'),
        ],
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class ServiceLevelKpisView(APIView):
    """
    Weekly overall / PRxO / Pharmagen service levels for the KPI cards.

    Returns one bucket per ISO week (Monday start) over the window for the trend, plus a
    per-metric summary comparing the week through to_date against the same span of the previous
    week, so a partial current week is never measured against a full prior one. The first and
    last trend buckets can cover a partial week when the window does not land on week boundaries.

    Query params:
      - from_date (YYYY-MM-DD, default: today - 90 days)
      - to_date   (YYYY-MM-DD, default: today)
    Supports global material filters.
    """

    def get(self, request, *args, **kwargs):
        today = _date.today()
        from_date_raw = request.query_params.get(
            'from_date', (today - timedelta(days=90)).isoformat()
        )
        to_date_raw = request.query_params.get('to_date', today.isoformat())
        try:
            from_date = _date.fromisoformat(from_date_raw)
            to_date = _date.fromisoformat(to_date_raw)
        except ValueError:
            raise _ValidationError({'detail': 'Invalid date format. Expected YYYY-MM-DD.'})

        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(
            request, skip_corp_chain=True
        )
        weekly = OrderTransactionService.get_weekly_service_levels(
            from_date, to_date, direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr=corp_chain_nbr
        )
        comparison = OrderTransactionService.get_service_level_week_comparison(
            to_date, direct_mat_nbr, mat_nbr_subquery, corp_chain_nbr=corp_chain_nbr
        )

        data = {
            'from_date': from_date,
            'to_date': to_date,
            'weekly': weekly,
            **comparison,
        }
        serializer = ServiceLevelKpisSerializer(data)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=_PAGINATED_FAIL_TO_SUPPLY_MATERIAL_RESPONSE,
        parameters=FAIL_TO_SUPPLY_MATERIAL_OPENAPI_PARAMETERS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class FailToSupplyMaterialView(generics.ListAPIView):
    """
    Materials with outbound / FTS scalars over a date window (default last 90 days).
    total_demand is previous calendar month order qty (independent of from_date/to_date).

    Cards and table share this list; default ordering is lowest outbound_fill_rate first.
    Supports global material filters (via get_filtered_material_subquery), range filters,
    ordering, and pagination.
    """
    serializer_class = FailToSupplyMaterialSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend]
    filterset_class = FailToSupplyMaterialFilter
    ordering_fields = FAIL_TO_SUPPLY_MATERIAL_ORDERING_FIELDS
    ordering = FAIL_TO_SUPPLY_MATERIAL_DEFAULT_ORDERING
    ordering_field_map = FAIL_TO_SUPPLY_MATERIAL_ORDERING_MAP

    def paginate_queryset(self, queryset):
        """Prefer a larger default page size for card + table consumers."""
        paginator = self.paginator
        if paginator is not None and 'limit' not in self.request.query_params:
            paginator.default_limit = 25
        return super().paginate_queryset(queryset)

    def filter_queryset(self, queryset):
        return get_fail_to_supply_material_filtered_queryset(self.request, queryset)

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return OrderTransaction.objects.none()

        return get_fail_to_supply_material_base_queryset(self.request)

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        rows = list(queryset) if page is None else page

        from_date, to_date = get_fail_to_supply_material_window(request)
        contract_types = OrderTransactionService.get_material_contract_types(
            [row['material_id'] for row in rows],
            from_date,
            to_date,
            corp_chain_nbr=extract_corp_chain_param(request),
        )
        for row in rows:
            row['contract_type'] = contract_types.get(row['material_id'])

        serializer = self.get_serializer(rows, many=True)

        if page is None:
            return Response(serializer.data)
        return self.get_paginated_response(serializer.data)


class FailToSupplyMaterialExportView(CsvExportView):
    """
    Stream all filtered Fail to Supply materials in the table's current order.
    28-day Forecast in CSV follows list API coalescing (null 7-day forecast → 0).
    limit/offset are ignored.
    """

    filename_prefix = "products_low_outbound_line_service"
    filterset_class = FailToSupplyMaterialFilter
    ordering_fields = FAIL_TO_SUPPLY_MATERIAL_ORDERING_FIELDS
    default_ordering = FAIL_TO_SUPPLY_MATERIAL_DEFAULT_ORDERING
    ordering_field_map = FAIL_TO_SUPPLY_MATERIAL_ORDERING_MAP
    strict_ordering = True

    @extend_schema(
        operation_id="api_order_transaction_fail_to_supply_materials_export",
        parameters=FAIL_TO_SUPPLY_MATERIAL_OPENAPI_PARAMETERS,
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_filtered_queryset(self, request):
        return get_fail_to_supply_material_filtered_queryset(request)

    def get_base_queryset(self, request):
        return get_fail_to_supply_material_base_queryset(request)

    def iter_csv_rows(self, queryset):
        from_date, to_date = get_fail_to_supply_material_window(self.request)
        contract_types = OrderTransactionService.get_material_contract_types(
            None,
            from_date,
            to_date,
            corp_chain_nbr=extract_corp_chain_param(self.request),
        )
        return OrderTransactionService.iter_fail_to_supply_materials_csv_rows(
            queryset, contract_types=contract_types
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class FailToSupplyPlantView(generics.ListAPIView):
    """
    Returns paginated per-plant Fail to Supply data for a single material.
    Used as the drill-down from the material list.

    Path param:
      - mat_nbr (str)
    Query params:
      - from_date   (YYYY-MM-DD, default: first day of current month)
      - to_date     (YYYY-MM-DD, default: today)
      - ordering    (any field, prefix with - for desc; default: -total_missed_lines)
      - *_min / *_max filters for all numeric fields
    """
    serializer_class = FailToSupplyPlantSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = FailToSupplyPlantFilter
    ordering_fields = [
        'prxo_missed_lines', 'pgen_missed_lines', 'total_missed_lines',
        'total_missed_lines_pct', 'outbound_fill_rate', 'service_level',
        'omit_qty', 'demand_qty', 'total_lines_ordered',
    ]
    ordering = ['-total_missed_lines']

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return OrderTransaction.objects.none()
        today = _date.today()
        from_date_raw = self.request.query_params.get('from_date', today.replace(day=1).isoformat())
        to_date_raw = self.request.query_params.get('to_date', today.isoformat())
        try:
            from_date = _date.fromisoformat(from_date_raw)
            to_date = _date.fromisoformat(to_date_raw)
        except ValueError:
            raise _ValidationError({'detail': 'Invalid date format. Expected YYYY-MM-DD.'})
        corp_chain_nbr = extract_corp_chain_param(self.request)
        return OrderTransactionService.get_fail_to_supply_by_plant(
            self.kwargs['mat_nbr'], from_date, to_date, corp_chain_nbr
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialPlantCustomersView(generics.ListAPIView):
    """
    GET /order-transaction/materials/{mat_nbr}/plants/{plant_nbr}/customers/

    Returns paginated per-customer inventory impact for a material and plant.
    Defaults to the last 90 days when from_date/to_date are omitted.
    """
    serializer_class = MaterialPlantCustomerSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = InventoryMaterialPlantCustomerFilter
    ordering_fields = [
        'cust_nbr_id', 'cust_nbr__name',
        'cust_corp_chain_nbr_id', 'cust_corp_chain_nbr__name',
        'order_qty', 'shipped_qty', 'omit_qty', 'imperfect_lines', 'sales_amount',
        'outbound_fill_rate',
    ]
    ordering = ['-omit_qty']

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return OrderTransaction.objects.none()
        today = _date.today()
        from_date_raw = self.request.query_params.get('from_date', (today - timedelta(days=90)).isoformat())
        to_date_raw = self.request.query_params.get('to_date', today.isoformat())
        try:
            from_date = _date.fromisoformat(from_date_raw)
            to_date = _date.fromisoformat(to_date_raw)
        except ValueError:
            raise ValidationError({'detail': 'Invalid date format. Expected YYYY-MM-DD.'})
        corp_chain_nbr = extract_corp_chain_param(self.request)
        return OrderTransactionService.get_customers_by_material_plant(
            self.kwargs['mat_nbr'], self.kwargs['plant_nbr'], from_date, to_date, corp_chain_nbr
        )
