"""
Materialized View Models for Order Transaction
These models represent pre-aggregated data stored in PostgreSQL materialized views over 90-day periods.
They use managed=False to indicate Django should not create/migrate these tables.
ForeignKey relationships enable filtering on related model fields (e.g., material__vendor__name).
"""
from django.db import models

from api.customer.models import Customer
from api.customer_corp_chain.models import CustomerCorpChain
from api.material.models import Material
from api.plant.models import Plant


class OrderTransactionMaterial90dMV(models.Model):
    """
    Comprehensive 90-day aggregation by material and corporate chain with ALL metrics.
    Materialized view: order_transaction_material_90d_mv
    Enables filtering on material fields: material__vendor__name, material__product_family, etc.
    Enables direct corporate chain filtering via corp_chain FK.
    """
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",  # No reverse relation needed
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    # Order metrics
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2)
    # Perfect/Imperfect lines
    perfect_lines = models.IntegerField()
    imperfect_lines = models.IntegerField()
    unpredictable_demand_count = models.IntegerField()
    demand_variability_count = models.IntegerField()
    omit_inflation_count = models.IntegerField()
    unaligned_forecast_count = models.IntegerField()
    # Alt-served metrics
    alt_served_count = models.IntegerField()
    alt_served_units = models.BigIntegerField()
    # Substitution metrics
    substituted_count = models.IntegerField()
    substituted_units = models.BigIntegerField()
    # Fill rate
    fill_rate = models.FloatField()
    # Date tracking
    first_order_date = models.DateField()
    last_order_date = models.DateField()

    class Meta:
        managed = False
        db_table = "order_transaction_material_90d_mv"


class OrderTransactionWeeklyMV(models.Model):
    """
    Weekly aggregation with material group and corporate chain breakdown for last 90 days.
    Materialized view: order_transaction_weekly_mv
    """
    week_start = models.DateField()
    material_group = models.CharField(max_length=255, null=True, blank=True)
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    alt_served_count = models.IntegerField()
    alt_served_units = models.BigIntegerField()
    auto_alt_served_units = models.BigIntegerField()
    manual_alt_served_units = models.BigIntegerField()
    substituted_count = models.IntegerField()
    substituted_units = models.BigIntegerField()
    perfect_orders = models.IntegerField()
    imperfect_orders = models.IntegerField()
    unpredictable_demand_count = models.IntegerField()
    omit_inflation_count = models.IntegerField()
    unaligned_forecast_count = models.IntegerField()
    demand_imperfect_count = models.IntegerField()

    class Meta:
        managed = False
        db_table = "order_transaction_weekly_mv"


class OrderTransactionCustomer90dMV(models.Model):
    """
    Comprehensive 90-day aggregation by customer.
    Materialized view: order_transaction_customer_90d_mv
    Enables filtering on customer fields: customer__state, customer__name, etc.
    """
    customer = models.ForeignKey(
        Customer,
        to_field="cust_nbr",
        db_column="cust_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    # Order metrics
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2)
    # Perfect/Imperfect lines
    perfect_lines = models.IntegerField()
    imperfect_lines = models.IntegerField()
    unpredictable_demand_count = models.IntegerField()
    demand_variability_count = models.IntegerField()
    # Fill rate
    fill_rate = models.FloatField()

    class Meta:
        managed = False
        db_table = "order_transaction_customer_90d_mv"


class OrderTransactionContract90dMV(models.Model):
    """
    90-day aggregation by contract, material, and corporate chain.
    Materialized view: order_transaction_contract_90d_mv
    Enables filtering on material fields via material FK and direct corp chain filtering.
    """
    contract_name = models.CharField(max_length=255)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2)

    class Meta:
        managed = False
        db_table = "order_transaction_contract_90d_mv"


class OrderTransactionCorpChain90dMV(models.Model):
    """
    90-day aggregation by corporate chain with contract breakdown.
    Materialized view: order_transaction_corp_chain_90d_mv
    Enables filtering on corporate chain fields.
    """
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    contract_name = models.CharField(max_length=255, null=True, blank=True)
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2)

    class Meta:
        managed = False
        db_table = "order_transaction_corp_chain_90d_mv"


class OrderTransactionSalesGroupMaterial90dMV(models.Model):
    """
    90-day aggregation by sales group, material, and corporate chain.
    Materialized view: order_transaction_sales_group_material_90d_mv
    Enables filtering on material fields via material FK and direct corp chain filtering.
    Used by get_material_sales_with_sales_group_breakdown().
    """
    sales_group = models.CharField(max_length=255)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2)

    class Meta:
        managed = False
        db_table = "order_transaction_sales_group_material_90d_mv"


class OrderTransactionSalesGroupCorpChain90dMV(models.Model):
    """
    90-day aggregation by corporate chain with sales group breakdown.
    Materialized view: order_transaction_sales_group_corp_chain_90d_mv
    Enables filtering on corporate chain fields.
    Used by get_corporate_sales_with_sales_group_breakdown().
    """
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    sales_group = models.CharField(max_length=255, null=True, blank=True)
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2)

    class Meta:
        managed = False
        db_table = "order_transaction_sales_group_corp_chain_90d_mv"


class OrderTransactionMaterialGroup90dMV(models.Model):
    """
    90-day aggregation by material group and corporate chain.
    Materialized view: order_transaction_material_group_90d_mv
    Enables direct corporate chain filtering via corp_chain FK.
    """
    material_group = models.CharField(max_length=255)
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2)

    class Meta:
        managed = False
        db_table = "order_transaction_material_group_90d_mv"


class OrderTransactionAltServedStatus90dMV(models.Model):
    """
    90-day aggregation of alt-served orders by material status, material, and corporate chain.
    Materialized view: order_transaction_alt_served_status_90d_mv
    Enables filtering on material fields and direct corporate chain filtering.
    """
    material_status = models.CharField(max_length=255, null=True, blank=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    alt_served_count = models.IntegerField()
    alt_served_units = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = "order_transaction_alt_served_status_90d_mv"


class OrderTransactionWeeklyTotalsMV(models.Model):
    """
    Weekly totals by corporate chain for fulfillment metrics.
    Materialized view: order_transaction_weekly_totals_mv
    """
    week_start = models.DateField()
    year = models.IntegerField()
    week = models.IntegerField()
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    total_ordered = models.BigIntegerField()
    total_shipped = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = "order_transaction_weekly_totals_mv"


class OrderTransactionPlant90dMV(models.Model):
    """
    90-day aggregation by plant with substitution and alt-serve metrics.
    Materialized view: order_transaction_plant_90d_mv
    Enables filtering on plant fields.
    """
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    total_materials = models.IntegerField()
    materials_with_substitution = models.IntegerField()
    materials_with_alt_serve = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = "order_transaction_plant_90d_mv"


class OrderTransactionWeeklyMaterialMV(models.Model):
    """
    Weekly × material × corporate chain aggregation for fill rate analysis.
    Materialized view: order_transaction_weekly_material_mv
    Enables filtering on material fields and direct corporate chain filtering.
    Also used for vendor scorecard weekly metrics.
    """
    week_start = models.DateField()
    year = models.IntegerField()
    week = models.IntegerField()
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    total_orders = models.IntegerField()
    total_ordered = models.BigIntegerField()
    total_shipped = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True)
    total_lines = models.IntegerField()
    fully_shipped_lines = models.IntegerField()
    alt_served_count = models.IntegerField()
    alt_served_units = models.BigIntegerField()
    auto_alt_served_units = models.BigIntegerField()
    manual_alt_served_units = models.BigIntegerField()
    substituted_count = models.IntegerField()
    substituted_units = models.BigIntegerField()
    perfect_orders = models.IntegerField()
    imperfect_orders = models.IntegerField()
    unpredictable_demand_count = models.IntegerField()
    omit_inflation_count = models.IntegerField()
    unaligned_forecast_count = models.IntegerField()
    demand_imperfect_count = models.IntegerField()
    fill_rate = models.FloatField()

    class Meta:
        managed = False
        db_table = "order_transaction_weekly_material_mv"


class OrderTransactionAltServedCost90dMV(models.Model):
    """
    Alt-served orders with material cost and corporate chain for cost range queries.
    Materialized view: order_transaction_alt_served_cost_90d_mv
    Enables filtering on material fields via material FK and direct corporate chain filtering.
    """
    material_status = models.CharField(max_length=255, null=True, blank=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    cost_per_unit = models.FloatField()
    cost_range = models.IntegerField(null=True, blank=True)
    total_order_qty = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = "order_transaction_alt_served_cost_90d_mv"


class OrderTransactionWeeklyOmitSummaryMV(models.Model):
    """
    Pre-aggregated weekly omit counts for instant retrieval.
    Materialized view: order_transaction_weekly_omit_summary_mv
    This MV has only ~13 rows (one per week) with pre-computed counts.
    """
    year = models.IntegerField()
    week = models.IntegerField()
    excess_omits_count = models.IntegerField()
    allowed_omits_count = models.IntegerField()
    no_omits_count = models.IntegerField()

    class Meta:
        managed = False
        db_table = "order_transaction_weekly_omit_summary_mv"


class OrderTransactionStateMaterial90dMV(models.Model):
    """
    90-day aggregation by state, material, and corporate chain.
    Materialized view: order_transaction_state_material_90d_mv
    Enables filtering on material fields via material FK and direct corp chain filtering.
    Used by get_state_sales() for both filtered and unfiltered queries.
    """
    state = models.CharField(max_length=255)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2)

    class Meta:
        managed = False
        db_table = "order_transaction_state_material_90d_mv"


class OrderTransactionClassOfTradeMaterial90dMV(models.Model):
    """
    90-day aggregation by class of trade, material, and corporate chain.
    Materialized view: order_transaction_class_of_trade_material_90d_mv
    Enables filtering on material fields via material FK and direct corp chain filtering.
    Used by get_class_of_trade_units() for both filtered and unfiltered queries.
    """
    class_of_trade_desc = models.CharField(max_length=255)
    class_of_trade_nbr = models.CharField(max_length=255)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    total_orders = models.IntegerField()
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    total_sales_amount = models.DecimalField(max_digits=20, decimal_places=2)

    class Meta:
        managed = False
        db_table = "order_transaction_class_of_trade_material_90d_mv"


class OrderTransactionAltServedPlantMaterial90dMV(models.Model):
    """
    90-day aggregation of alt-served orders by plant, material, and corporate chain.
    Materialized view: order_transaction_alt_served_plant_material_90d_mv
    Enables filtering on material fields via material FK and direct corporate chain filtering.
    Used by get_alt_served_breakdown_analysis() plant breakdown for both filtered and unfiltered queries.
    """
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    alt_served_count = models.IntegerField()
    alt_served_units = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = "order_transaction_alt_served_plant_material_90d_mv"


class OrderTransactionAltServedClassOfTradeMaterial90dMV(models.Model):
    """
    90-day aggregation of alt-served orders by class of trade, material, and corporate chain.
    Materialized view: order_transaction_alt_served_class_of_trade_material_90d_mv
    Enables filtering on material fields via material FK and direct corporate chain filtering.
    Used by get_alt_served_breakdown_analysis() class of trade breakdown for both filtered and unfiltered queries.
    """
    class_of_trade_desc = models.CharField(max_length=255)
    class_of_trade_nbr = models.CharField(max_length=255)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    corp_chain = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
        null=True,
    )
    alt_served_count = models.IntegerField()
    alt_served_units = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = "order_transaction_alt_served_class_of_trade_material_90d_mv"
