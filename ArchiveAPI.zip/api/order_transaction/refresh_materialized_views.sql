-- ============================================================================
-- Refresh Commands (to be run from Databricks)
-- ============================================================================
REFRESH MATERIALIZED VIEW order_transaction_material_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_weekly_mv;
REFRESH MATERIALIZED VIEW order_transaction_customer_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_contract_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_corp_chain_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_material_group_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_alt_served_status_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_weekly_totals_mv;
REFRESH MATERIALIZED VIEW order_transaction_plant_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_weekly_material_mv;
REFRESH MATERIALIZED VIEW order_transaction_weekly_omit_summary_mv;
REFRESH MATERIALIZED VIEW order_transaction_alt_served_cost_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_state_material_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_class_of_trade_material_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_alt_served_plant_material_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_alt_served_class_of_trade_material_90d_mv;
REFRESH MATERIALIZED VIEW corp_chain_materials_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_sales_group_material_90d_mv;
REFRESH MATERIALIZED VIEW order_transaction_sales_group_corp_chain_90d_mv;
