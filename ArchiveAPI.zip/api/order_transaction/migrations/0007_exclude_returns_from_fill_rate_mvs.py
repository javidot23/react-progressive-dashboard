from django.db import migrations


FORWARD_SQL = """
DROP MATERIALIZED VIEW IF EXISTS order_transaction_material_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_material_90d_mv AS
SELECT
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    -- Order metrics
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount,
    -- Demand-only metrics: return lines carry a negative total_order_qty and are
    -- excluded so they cannot shrink a fill rate denominator or an omit subtraction.
    COUNT(ot.id) FILTER (WHERE ot.total_order_qty > 0) AS total_orders_pos,
    SUM(ot.total_order_qty) FILTER (WHERE ot.total_order_qty > 0) AS total_order_qty_pos,
    SUM(ot.total_shipped_qty) FILTER (WHERE ot.total_order_qty > 0) AS total_shipped_qty_pos,
    -- Perfect/Imperfect line counts
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END) AS perfect_lines,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END) AS imperfect_lines,
    -- Individual imperfect flags
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END) AS demand_variability_count,
    COUNT(CASE WHEN ot.f_omit_inflation = 1 THEN 1 END) AS omit_inflation_count,
    COUNT(CASE WHEN ot.f_unaligned_forecast = 1 THEN 1 END) AS unaligned_forecast_count,
    -- Alt-served metrics
    COUNT(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN 1 END) AS alt_served_count,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN ot.total_order_qty ELSE 0 END) AS alt_served_units,
    -- Substitution metrics
    COUNT(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN 1 END) AS substituted_count,
    SUM(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN ot.total_order_qty ELSE 0 END) AS substituted_units,
    -- Fill rate calculation
    CASE
        WHEN SUM(ot.total_order_qty) FILTER (WHERE ot.total_order_qty > 0) > 0
        THEN CAST(SUM(ot.total_shipped_qty) FILTER (WHERE ot.total_order_qty > 0) AS FLOAT)
           / CAST(SUM(ot.total_order_qty) FILTER (WHERE ot.total_order_qty > 0) AS FLOAT)
        ELSE 0.0
    END AS fill_rate,
    -- Date range for tracking
    MIN(ot.ord_created_date) AS first_order_date,
    MAX(ot.ord_created_date) AS last_order_date
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_mat_90d_mat_nbr ON order_transaction_material_90d_mv(mat_nbr);
CREATE INDEX idx_mat_90d_total_sales ON order_transaction_material_90d_mv(total_shipped_qty DESC);
CREATE INDEX idx_mat_90d_total_order ON order_transaction_material_90d_mv(total_order_qty DESC);
CREATE INDEX idx_mat_90d_fill_rate ON order_transaction_material_90d_mv(fill_rate);
CREATE INDEX idx_mat_90d_corp_chain ON order_transaction_material_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_mat_90d_corp_mat ON order_transaction_material_90d_mv(cust_corp_chain_nbr, mat_nbr);


DROP MATERIALIZED VIEW IF EXISTS order_transaction_customer_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_customer_90d_mv AS
SELECT
    ot.cust_nbr,
    -- Order metrics
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount,
    -- Perfect/Imperfect line counts
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END) AS perfect_lines,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END) AS imperfect_lines,
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END) AS demand_variability_count,
    -- Fill rate, over demand lines only (return lines carry a negative total_order_qty)
    CASE
        WHEN SUM(ot.total_order_qty) FILTER (WHERE ot.total_order_qty > 0) > 0
        THEN CAST(SUM(ot.total_shipped_qty) FILTER (WHERE ot.total_order_qty > 0) AS FLOAT)
           / CAST(SUM(ot.total_order_qty) FILTER (WHERE ot.total_order_qty > 0) AS FLOAT)
        ELSE 0.0
    END AS fill_rate
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.cust_nbr IS NOT NULL
GROUP BY ot.cust_nbr;

CREATE INDEX idx_customer_90d_cust_nbr ON order_transaction_customer_90d_mv(cust_nbr);
CREATE INDEX idx_customer_90d_total_order ON order_transaction_customer_90d_mv(total_order_qty DESC);


DROP MATERIALIZED VIEW IF EXISTS order_transaction_weekly_totals_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_weekly_totals_mv AS
SELECT
    DATE_TRUNC('week', ot.ord_created_date)::date AS week_start,
    EXTRACT(ISOYEAR FROM ot.ord_created_date)::INTEGER AS year,
    EXTRACT(WEEK FROM ot.ord_created_date)::INTEGER AS week,
    ot.cust_corp_chain_nbr,
    SUM(ot.total_order_qty) AS total_ordered,
    SUM(ot.total_shipped_qty) AS total_shipped
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.total_order_qty > 0
GROUP BY DATE_TRUNC('week', ot.ord_created_date)::date,
         EXTRACT(ISOYEAR FROM ot.ord_created_date),
         EXTRACT(WEEK FROM ot.ord_created_date),
         ot.cust_corp_chain_nbr;

CREATE UNIQUE INDEX idx_weekly_totals_year_week ON order_transaction_weekly_totals_mv(year, week, cust_corp_chain_nbr);
CREATE INDEX idx_weekly_totals_week_start ON order_transaction_weekly_totals_mv(week_start);
CREATE INDEX idx_weekly_totals_corp_chain ON order_transaction_weekly_totals_mv(cust_corp_chain_nbr);
CREATE INDEX idx_weekly_totals_corp_week ON order_transaction_weekly_totals_mv(cust_corp_chain_nbr, week_start);
"""


REVERSE_SQL = """
DROP MATERIALIZED VIEW IF EXISTS order_transaction_material_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_material_90d_mv AS
SELECT
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    -- Order metrics
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount,
    -- Perfect/Imperfect line counts
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END) AS perfect_lines,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END) AS imperfect_lines,
    -- Individual imperfect flags
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END) AS demand_variability_count,
    COUNT(CASE WHEN ot.f_omit_inflation = 1 THEN 1 END) AS omit_inflation_count,
    COUNT(CASE WHEN ot.f_unaligned_forecast = 1 THEN 1 END) AS unaligned_forecast_count,
    -- Alt-served metrics
    COUNT(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN 1 END) AS alt_served_count,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN ot.total_order_qty ELSE 0 END) AS alt_served_units,
    -- Substitution metrics
    COUNT(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN 1 END) AS substituted_count,
    SUM(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN ot.total_order_qty ELSE 0 END) AS substituted_units,
    -- Fill rate calculation
    CASE
        WHEN SUM(ot.total_order_qty) > 0
        THEN CAST(SUM(ot.total_shipped_qty) AS FLOAT) / CAST(SUM(ot.total_order_qty) AS FLOAT)
        ELSE 0.0
    END AS fill_rate,
    -- Date range for tracking
    MIN(ot.ord_created_date) AS first_order_date,
    MAX(ot.ord_created_date) AS last_order_date
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_mat_90d_mat_nbr ON order_transaction_material_90d_mv(mat_nbr);
CREATE INDEX idx_mat_90d_total_sales ON order_transaction_material_90d_mv(total_shipped_qty DESC);
CREATE INDEX idx_mat_90d_total_order ON order_transaction_material_90d_mv(total_order_qty DESC);
CREATE INDEX idx_mat_90d_fill_rate ON order_transaction_material_90d_mv(fill_rate);
CREATE INDEX idx_mat_90d_corp_chain ON order_transaction_material_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_mat_90d_corp_mat ON order_transaction_material_90d_mv(cust_corp_chain_nbr, mat_nbr);


DROP MATERIALIZED VIEW IF EXISTS order_transaction_customer_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_customer_90d_mv AS
SELECT
    ot.cust_nbr,
    -- Order metrics
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount,
    -- Perfect/Imperfect line counts
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END) AS perfect_lines,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END) AS imperfect_lines,
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END) AS demand_variability_count,
    -- Fill rate
    CASE
        WHEN SUM(ot.total_order_qty) > 0
        THEN CAST(SUM(ot.total_shipped_qty) AS FLOAT) / CAST(SUM(ot.total_order_qty) AS FLOAT)
        ELSE 0.0
    END AS fill_rate
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.cust_nbr IS NOT NULL
GROUP BY ot.cust_nbr;

CREATE INDEX idx_customer_90d_cust_nbr ON order_transaction_customer_90d_mv(cust_nbr);
CREATE INDEX idx_customer_90d_total_order ON order_transaction_customer_90d_mv(total_order_qty DESC);


DROP MATERIALIZED VIEW IF EXISTS order_transaction_weekly_totals_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_weekly_totals_mv AS
SELECT
    DATE_TRUNC('week', ot.ord_created_date)::date AS week_start,
    EXTRACT(ISOYEAR FROM ot.ord_created_date)::INTEGER AS year,
    EXTRACT(WEEK FROM ot.ord_created_date)::INTEGER AS week,
    ot.cust_corp_chain_nbr,
    SUM(ot.total_order_qty) AS total_ordered,
    SUM(ot.total_shipped_qty) AS total_shipped
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY DATE_TRUNC('week', ot.ord_created_date)::date,
         EXTRACT(ISOYEAR FROM ot.ord_created_date),
         EXTRACT(WEEK FROM ot.ord_created_date),
         ot.cust_corp_chain_nbr;

CREATE UNIQUE INDEX idx_weekly_totals_year_week ON order_transaction_weekly_totals_mv(year, week, cust_corp_chain_nbr);
CREATE INDEX idx_weekly_totals_week_start ON order_transaction_weekly_totals_mv(week_start);
CREATE INDEX idx_weekly_totals_corp_chain ON order_transaction_weekly_totals_mv(cust_corp_chain_nbr);
CREATE INDEX idx_weekly_totals_corp_week ON order_transaction_weekly_totals_mv(cust_corp_chain_nbr, week_start);
"""


class Migration(migrations.Migration):

    dependencies = [
        ('order_transaction', '0006_ordertransaction_fts_adj_lines_incl_72_hours_and_more'),
    ]

    operations = [
        migrations.RunSQL(sql=FORWARD_SQL, reverse_sql=REVERSE_SQL),
    ]
