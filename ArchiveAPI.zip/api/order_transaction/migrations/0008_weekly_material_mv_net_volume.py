from django.db import migrations


FORWARD_SQL = """
DROP MATERIALIZED VIEW IF EXISTS order_transaction_weekly_material_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_weekly_material_mv AS
SELECT
    DATE_TRUNC('week', ot.ord_created_date)::date AS week_start,
    EXTRACT(ISOYEAR FROM ot.ord_created_date)::INTEGER AS year,
    EXTRACT(WEEK FROM ot.ord_created_date)::INTEGER AS week,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    -- Demand-only aggregates: return lines carry a negative total_order_qty and are
    -- excluded so they cannot shrink a fill rate denominator or inflate a line count.
    COUNT(ot.id) FILTER (WHERE ot.total_order_qty > 0) AS total_orders,
    SUM(ot.total_order_qty) FILTER (WHERE ot.total_order_qty > 0) AS total_ordered,
    SUM(ot.total_shipped_qty) FILTER (WHERE ot.total_order_qty > 0) AS total_shipped,
    SUM(ot.sales_amount) FILTER (WHERE ot.total_order_qty > 0) AS total_sales_amount,
    COUNT(ot.id) FILTER (WHERE ot.total_order_qty > 0) AS total_lines,
    COUNT(CASE WHEN ot.total_shipped_qty >= ot.total_order_qty THEN 1 END)
        FILTER (WHERE ot.total_order_qty > 0) AS fully_shipped_lines,
    -- Net volume, returns included, for display alongside sales figures.
    SUM(ot.total_order_qty) AS total_ordered_net,
    SUM(ot.total_shipped_qty) AS total_shipped_net,
    SUM(ot.sales_amount) AS total_sales_amount_net,
    -- Alt-served metrics
    COUNT(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN 1 END)
        FILTER (WHERE ot.total_order_qty > 0) AS alt_served_count,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN ot.total_order_qty ELSE 0 END)
        FILTER (WHERE ot.total_order_qty > 0) AS alt_served_units,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE AND UPPER(TRIM(ot.alt_serve_type)) = 'AUTO' THEN ot.total_order_qty ELSE 0 END)
        FILTER (WHERE ot.total_order_qty > 0) AS auto_alt_served_units,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE AND UPPER(TRIM(ot.alt_serve_type)) = 'MANUAL' THEN ot.total_order_qty ELSE 0 END)
        FILTER (WHERE ot.total_order_qty > 0) AS manual_alt_served_units,
    -- Substitution metrics
    COUNT(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN 1 END)
        FILTER (WHERE ot.total_order_qty > 0) AS substituted_count,
    SUM(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN ot.total_order_qty ELSE 0 END)
        FILTER (WHERE ot.total_order_qty > 0) AS substituted_units,
    -- Perfect/Imperfect metrics
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END)
        FILTER (WHERE ot.total_order_qty > 0) AS perfect_orders,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END)
        FILTER (WHERE ot.total_order_qty > 0) AS imperfect_orders,
    -- Imperfect flags breakdown
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END)
        FILTER (WHERE ot.total_order_qty > 0) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_omit_inflation = 1 THEN 1 END)
        FILTER (WHERE ot.total_order_qty > 0) AS omit_inflation_count,
    COUNT(CASE WHEN ot.f_unaligned_forecast = 1 THEN 1 END)
        FILTER (WHERE ot.total_order_qty > 0) AS unaligned_forecast_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END)
        FILTER (WHERE ot.total_order_qty > 0) AS demand_imperfect_count,
    CASE
        WHEN SUM(ot.total_order_qty) FILTER (WHERE ot.total_order_qty > 0) > 0
        THEN CAST(SUM(ot.total_shipped_qty) FILTER (WHERE ot.total_order_qty > 0) AS FLOAT)
           / CAST(SUM(ot.total_order_qty) FILTER (WHERE ot.total_order_qty > 0) AS FLOAT)
        ELSE 0.0
    END AS fill_rate
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY DATE_TRUNC('week', ot.ord_created_date)::date,
         EXTRACT(ISOYEAR FROM ot.ord_created_date),
         EXTRACT(WEEK FROM ot.ord_created_date),
         ot.mat_nbr,
         ot.cust_corp_chain_nbr
HAVING COUNT(ot.id) FILTER (WHERE ot.total_order_qty > 0) > 0;

CREATE INDEX idx_weekly_mat_week_start ON order_transaction_weekly_material_mv(week_start);
CREATE INDEX idx_weekly_mat_year_week ON order_transaction_weekly_material_mv(year, week);
CREATE INDEX idx_weekly_mat_mat_nbr ON order_transaction_weekly_material_mv(mat_nbr);
CREATE INDEX idx_weekly_mat_combined ON order_transaction_weekly_material_mv(year, week, mat_nbr);
CREATE INDEX idx_weekly_mat_year_week_fillrate ON order_transaction_weekly_material_mv(year, week) INCLUDE (fill_rate, mat_nbr);
CREATE INDEX idx_weekly_mat_corp_chain ON order_transaction_weekly_material_mv(cust_corp_chain_nbr);
CREATE INDEX idx_weekly_mat_corp_week ON order_transaction_weekly_material_mv(cust_corp_chain_nbr, week_start);
"""


REVERSE_SQL = """
DROP MATERIALIZED VIEW IF EXISTS order_transaction_weekly_material_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_weekly_material_mv AS
SELECT
    DATE_TRUNC('week', ot.ord_created_date)::date AS week_start,
    EXTRACT(ISOYEAR FROM ot.ord_created_date)::INTEGER AS year,
    EXTRACT(WEEK FROM ot.ord_created_date)::INTEGER AS week,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_ordered,
    SUM(ot.total_shipped_qty) AS total_shipped,
    SUM(ot.sales_amount) AS total_sales_amount,
    COUNT(ot.id) AS total_lines,
    COUNT(CASE WHEN ot.total_shipped_qty >= ot.total_order_qty THEN 1 END) AS fully_shipped_lines,
    -- Alt-served metrics
    COUNT(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN 1 END) AS alt_served_count,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN ot.total_order_qty ELSE 0 END) AS alt_served_units,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE AND UPPER(TRIM(ot.alt_serve_type)) = 'AUTO' THEN ot.total_order_qty ELSE 0 END) AS auto_alt_served_units,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE AND UPPER(TRIM(ot.alt_serve_type)) = 'MANUAL' THEN ot.total_order_qty ELSE 0 END) AS manual_alt_served_units,
    -- Substitution metrics
    COUNT(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN 1 END) AS substituted_count,
    SUM(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN ot.total_order_qty ELSE 0 END) AS substituted_units,
    -- Perfect/Imperfect metrics
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END) AS perfect_orders,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END) AS imperfect_orders,
    -- Imperfect flags breakdown
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_omit_inflation = 1 THEN 1 END) AS omit_inflation_count,
    COUNT(CASE WHEN ot.f_unaligned_forecast = 1 THEN 1 END) AS unaligned_forecast_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END) AS demand_imperfect_count,
    CASE
        WHEN SUM(ot.total_order_qty) > 0
        THEN CAST(SUM(ot.total_shipped_qty) AS FLOAT) / CAST(SUM(ot.total_order_qty) AS FLOAT)
        ELSE 0.0
    END AS fill_rate
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.total_order_qty > 0
GROUP BY DATE_TRUNC('week', ot.ord_created_date)::date,
         EXTRACT(ISOYEAR FROM ot.ord_created_date),
         EXTRACT(WEEK FROM ot.ord_created_date),
         ot.mat_nbr,
         ot.cust_corp_chain_nbr;

CREATE INDEX idx_weekly_mat_week_start ON order_transaction_weekly_material_mv(week_start);
CREATE INDEX idx_weekly_mat_year_week ON order_transaction_weekly_material_mv(year, week);
CREATE INDEX idx_weekly_mat_mat_nbr ON order_transaction_weekly_material_mv(mat_nbr);
CREATE INDEX idx_weekly_mat_combined ON order_transaction_weekly_material_mv(year, week, mat_nbr);
CREATE INDEX idx_weekly_mat_year_week_fillrate ON order_transaction_weekly_material_mv(year, week) INCLUDE (fill_rate, mat_nbr);
CREATE INDEX idx_weekly_mat_corp_chain ON order_transaction_weekly_material_mv(cust_corp_chain_nbr);
CREATE INDEX idx_weekly_mat_corp_week ON order_transaction_weekly_material_mv(cust_corp_chain_nbr, week_start);
"""


class Migration(migrations.Migration):

    dependencies = [
        ('order_transaction', '0007_exclude_returns_from_fill_rate_mvs'),
    ]

    operations = [
        migrations.RunSQL(sql=FORWARD_SQL, reverse_sql=REVERSE_SQL),
    ]
