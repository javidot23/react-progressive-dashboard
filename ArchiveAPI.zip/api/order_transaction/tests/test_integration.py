import random
from datetime import date, timedelta

from django.urls import reverse
from rest_framework import status

from api.order_transaction.models import OrderTransaction
from tests.BaseTestCase import BaseTestCase, MVAPITestCase, TenantAPIClient
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


ORDER_TRANSACTION_INTEGRATION_MVS = [
    "order_transaction_material_90d_mv",
    "order_transaction_customer_90d_mv",
    "order_transaction_contract_90d_mv",
    "order_transaction_corp_chain_90d_mv",
    "order_transaction_material_group_90d_mv",
    "order_transaction_plant_90d_mv",
    "order_transaction_state_material_90d_mv",
    "order_transaction_class_of_trade_material_90d_mv",
    "order_transaction_alt_served_status_90d_mv",
    "order_transaction_alt_served_cost_90d_mv",
    "order_transaction_alt_served_plant_material_90d_mv",
    "order_transaction_alt_served_class_of_trade_material_90d_mv",
    "order_transaction_sales_group_material_90d_mv",
    "order_transaction_sales_group_corp_chain_90d_mv",
    "order_transaction_weekly_mv",
    "order_transaction_weekly_material_mv",
    "order_transaction_weekly_totals_mv",
    "order_transaction_weekly_omit_summary_mv",
    "corp_chain_materials_90d_mv",
]

ORDER_TRANSACTION_WEEKLY_MATERIAL_MV = ["order_transaction_weekly_material_mv"]
ORDER_TRANSACTION_MATERIAL_MV = ["order_transaction_material_90d_mv"]
ORDER_TRANSACTION_STATE_MATERIAL_MV = ["order_transaction_state_material_90d_mv"]
ORDER_TRANSACTION_CONTRACT_MV = ["order_transaction_contract_90d_mv"]
ORDER_TRANSACTION_SALES_GROUP_MATERIAL_MV = ["order_transaction_sales_group_material_90d_mv"]
ORDER_TRANSACTION_MANAGE_SALES_MVS = [
    *ORDER_TRANSACTION_MATERIAL_MV,
    *ORDER_TRANSACTION_STATE_MATERIAL_MV,
    *ORDER_TRANSACTION_CONTRACT_MV,
    *ORDER_TRANSACTION_SALES_GROUP_MATERIAL_MV,
]


def refresh_order_transaction_integration_mvs(view_names=None):
    MaterializedViewTestHelper.refresh_materialized_views(view_names or ORDER_TRANSACTION_INTEGRATION_MVS)


class OrderTransactionMVRefreshingClient(TenantAPIClient):
    def __init__(self, test_case, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._test_case = test_case

    def get(self, *args, **kwargs):
        self._test_case.refresh_order_transaction_mvs_if_needed()
        return super().get(*args, **kwargs)


class OrderTransactionIntegrationTest(MVAPITestCase):
    def setUp(self):
        self._original_create_order_transaction = TestDataFactory.create_order_transaction
        self._order_transaction_mvs_dirty = True
        self.client = OrderTransactionMVRefreshingClient(self)
        self.plant = TestDataFactory.create_plant()
        self.material = TestDataFactory.create_material()
        self.substituted_material = TestDataFactory.create_material()
        TestDataFactory.create_order_transaction = self._create_order_transaction_without_auto_refresh

    def tearDown(self):
        TestDataFactory.create_order_transaction = self._original_create_order_transaction
        super().tearDown()

    def _create_order_transaction_without_auto_refresh(self, *args, **kwargs):
        with MaterializedViewTestHelper.defer_auto_refresh():
            order_transaction = self._original_create_order_transaction(*args, **kwargs)
        self._order_transaction_mvs_dirty = True
        return order_transaction

    def refresh_order_transaction_mvs_if_needed(self):
        if self._order_transaction_mvs_dirty:
            refresh_order_transaction_integration_mvs()
            self._order_transaction_mvs_dirty = False

    def test_plant_order_stats_view(self):
        """Test plant order statistics endpoint"""
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant
        )

        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant
        )

        url = reverse('order-transaction:plant-order-stats')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)
        self.assertGreater(len(response.data['results']), 0)

    def test_plant_order_stats_view_pagination(self):
        """Test pagination on plant order stats"""
        # Create multiple plants with orders
        for i in range(15):
            plant = TestDataFactory.create_plant()
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=plant,
                ord_created_date=date.today() - timedelta(days=random.randint(0, 30)),
            )
        url = reverse('order-transaction:plant-order-stats')
        response = self.client.get(url, {'limit': 5})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 5)
        self.assertIn('next', response.data)

    def test_material_sales_view(self):
        """Test material sales endpoint"""
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=150,
            ord_created_date=date.today()
        )
        TestDataFactory.create_order_transaction(
            material=self.substituted_material,
            plant=self.plant,
            total_shipped_qty=200,
            ord_created_date=date.today()
        )

        url = reverse('order-transaction:material-sales')
        response = self.client.get(url, {'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)
        self.assertEqual(len(response.data['results']), 2)
        self.assertIn('name', response.data['results'][0])
        self.assertIn('mat_nbr', response.data['results'][0])
        self.assertIn('total_sales_qty', response.data['results'][0])

    def test_contract_sales_view(self):
        """Test contract sales endpoint"""
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=150,
            ord_created_date=date.today(),
            contract_name='Contract A'
        )
        TestDataFactory.create_order_transaction(
            material=self.substituted_material,
            plant=self.plant,
            total_shipped_qty=200,
            ord_created_date=date.today(),
            contract_name='Contract B'
        )

        url = reverse('order-transaction:contract-sales')
        response = self.client.get(url, {'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)
        self.assertEqual(len(response.data['results']), 2)
        self.assertIn('name', response.data['results'][0])
        self.assertIn('total_sales_qty', response.data['results'][0])

    def test_corporate_sales_view(self):
        """Test corporate sales endpoint"""
        corporate_a = TestDataFactory.create_customer_corp_chain(name="Corporate A")
        corporate_b = TestDataFactory.create_customer_corp_chain(name="Corporate B")

        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=150,
            ord_created_date=date.today(),
            cust_corp_chain_nbr=corporate_a
        )
        TestDataFactory.create_order_transaction(
            material=self.substituted_material,
            plant=self.plant,
            total_shipped_qty=200,
            ord_created_date=date.today(),
            cust_corp_chain_nbr=corporate_b
        )

        url = reverse('order-transaction:corporate-sales')
        response = self.client.get(url, {'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)
        self.assertEqual(len(response.data['results']), 2)
        self.assertIn('name', response.data['results'][0])
        self.assertIn('total_sales_qty', response.data['results'][0])

    def test_order_transaction_list_view(self):
        """Test order transaction list view with filtering and pagination"""
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=150,
            ord_created_date=date.today()
        )

        url = reverse('order-transaction:order-transaction-list')
        response = self.client.get(url, {'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)
        self.assertGreater(len(response.data['results']), 0)
        self.assertIn('sales_doc_nbr', response.data['results'][0])
        self.assertIn('material', response.data['results'][0])
        self.assertIn('plant', response.data['results'][0])

    def test_order_transaction_list_view_filtering(self):
        """Test order transaction list view with filtering"""
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=150,
            ord_created_date=date.today()
        )

        url = reverse('order-transaction:order-transaction-list')
        response = self.client.get(url, {
            'mat_nbr': self.material.mat_nbr,
            'plant': self.plant.plant_nbr,
            'limit': 10
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['results'][0]['material']['mat_nbr'], self.material.mat_nbr)
        self.assertEqual(response.data['results'][0]['plant']['plant_nbr'], self.plant.plant_nbr)

    def test_class_of_trade_units_view(self):
        """Test class of trade units endpoint"""
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_order_qty=150,
            total_shipped_qty=120,
            ord_created_date=date.today(),
            class_of_trade_desc="HOSPITAL",
            class_of_trade_nbr="1005"
        )
        TestDataFactory.create_order_transaction(
            material=self.substituted_material,
            plant=self.plant,
            total_order_qty=200,
            total_shipped_qty=180,
            ord_created_date=date.today(),
            class_of_trade_desc="INDEPENDENT",
            class_of_trade_nbr="1004"
        )

        url = reverse('order-transaction:class-of-trade-filled-rate-trend')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('class_of_trade_id', response.data[0])
        self.assertIn('class_of_trade', response.data[0])
        self.assertIn('ordered_units', response.data[0])
        self.assertIn('filled_units', response.data[0])
        # check at least 2 results (one per class of trade)
        self.assertGreaterEqual(len(response.data), 2)

        # Check response structure
        first_result = response.data[0]
        self.assertIn('class_of_trade_id', first_result)
        self.assertIn('class_of_trade', first_result)
        self.assertIn('ordered_units', first_result)
        self.assertIn('filled_units', first_result)

        # Check ordering (should be by ordered_units descending)
        self.assertEqual(first_result['class_of_trade'], 'INDEPENDENT')
        self.assertEqual(first_result['ordered_units'], 200)
        self.assertEqual(first_result['filled_units'], 180)

    def test_material_group_units_view(self):
        """Test material group units endpoint"""
        # Create materials with different groups using actual codes
        generic_material = TestDataFactory.create_material(scrm_mat_grp='GRX')
        brand_material = TestDataFactory.create_material(scrm_mat_grp='BRX')

        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            total_order_qty=250,
            total_shipped_qty=200,
            ord_created_date=date.today()
        )
        TestDataFactory.create_order_transaction(
            material=brand_material,
            plant=self.plant,
            total_order_qty=180,
            total_shipped_qty=150,
            ord_created_date=date.today()
        )

        url = reverse('order-transaction:material-group-units')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertEqual(len(response.data), 2)

        # Check response structure
        first_result = response.data[0]
        self.assertIn('material_group', first_result)
        self.assertIn('ordered_units', first_result)
        self.assertIn('filled_units', first_result)

        # Check ordering (should be by ordered_units descending)
        # get_material_group_units returns raw codes, not mapped categories
        self.assertEqual(first_result['material_group'], 'Generic')
        self.assertEqual(first_result['ordered_units'], 250)
        self.assertEqual(first_result['filled_units'], 200)

    def test_material_group_units_view_all_three_groups(self):
        """Test material group units with all three possible groups"""
        generic_material = TestDataFactory.create_material(scrm_mat_grp='GRX')
        brand_material = TestDataFactory.create_material(scrm_mat_grp='BRX')
        otc_material = TestDataFactory.create_material(scrm_mat_grp='OTC')

        # Create orders with varying quantities to test ordering
        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            total_order_qty=300,
            total_shipped_qty=250,
            ord_created_date=date.today()
        )
        TestDataFactory.create_order_transaction(
            material=brand_material,
            plant=self.plant,
            total_order_qty=200,
            total_shipped_qty=180,
            ord_created_date=date.today()
        )
        TestDataFactory.create_order_transaction(
            material=otc_material,
            plant=self.plant,
            total_order_qty=100,
            total_shipped_qty=90,
            ord_created_date=date.today()
        )

        url = reverse('order-transaction:material-group-units')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 3)

        # Check that all three material groups are present and ordered correctly
        # get_material_group_units returns raw codes, not mapped categories
        material_groups = [item['material_group'] for item in response.data]
        self.assertIn('Generic', material_groups)
        self.assertIn('Brand', material_groups)
        self.assertIn('OTC', material_groups)

        # Check ordering (GRX should be first with 300 units)
        self.assertEqual(response.data[0]['material_group'], 'Generic')
        self.assertEqual(response.data[0]['ordered_units'], 300)

    def test_material_group_units_weekly_view(self):
        """Test material group units weekly endpoint"""
        # Create materials with different groups using actual codes
        generic_material = TestDataFactory.create_material(scrm_mat_grp='GRX')
        brand_material = TestDataFactory.create_material(scrm_mat_grp='BRX')
        otc_material = TestDataFactory.create_material(scrm_mat_grp='OTC')

        # Create orders across multiple weeks
        base_date = date.today() - timedelta(days=30)

        # Week 1: Generic and Brand orders
        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            total_order_qty=150,
            total_shipped_qty=120,
            ord_created_date=base_date
        )
        TestDataFactory.create_order_transaction(
            material=brand_material,
            plant=self.plant,
            total_order_qty=200,
            total_shipped_qty=180,
            ord_created_date=base_date + timedelta(days=1)
        )

        # Week 2: OTC and more Generic orders
        TestDataFactory.create_order_transaction(
            material=otc_material,
            plant=self.plant,
            total_order_qty=100,
            total_shipped_qty=90,
            ord_created_date=base_date + timedelta(days=7)
        )
        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            total_order_qty=50,
            total_shipped_qty=40,
            ord_created_date=base_date + timedelta(days=8)
        )

        url = reverse('order-transaction:material-group-units-weekly')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertGreater(len(response.data), 0)

        # Check response structure
        for week_data in response.data:
            self.assertIn('week_start', week_data)
            self.assertIn('brand_ordered_units', week_data)
            self.assertIn('brand_shipped_units', week_data)
            self.assertIn('generic_ordered_units', week_data)
            self.assertIn('generic_shipped_units', week_data)
            self.assertIn('otc_ordered_units', week_data)
            self.assertIn('otc_shipped_units', week_data)

        # Verify totals across all weeks
        total_brand_ordered = sum(week['brand_ordered_units'] for week in response.data)
        total_brand_shipped = sum(week['brand_shipped_units'] for week in response.data)
        total_generic_ordered = sum(week['generic_ordered_units'] for week in response.data)
        total_generic_shipped = sum(week['generic_shipped_units'] for week in response.data)
        total_otc_ordered = sum(week['otc_ordered_units'] for week in response.data)
        total_otc_shipped = sum(week['otc_shipped_units'] for week in response.data)

        self.assertEqual(total_brand_ordered, 200)
        self.assertEqual(total_brand_shipped, 180)
        self.assertEqual(total_generic_ordered, 200)  # 150 + 50
        self.assertEqual(total_generic_shipped, 160)  # 120 + 40
        self.assertEqual(total_otc_ordered, 100)
        self.assertEqual(total_otc_shipped, 90)

    def test_material_group_units_weekly_view_empty_data(self):
        """Test material group units weekly view with no data"""
        url = reverse('order-transaction:material-group-units-weekly')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertEqual(len(response.data), 0)

    def test_material_group_units_weekly_view_all_three_groups(self):
        """Test material group units weekly with all three groups in same week"""
        generic_material = TestDataFactory.create_material(scrm_mat_grp='GRX')
        brand_material = TestDataFactory.create_material(scrm_mat_grp='BRX')
        otc_material = TestDataFactory.create_material(scrm_mat_grp='OTC')

        # Create orders for all three groups in the same week
        test_date = date.today() - timedelta(days=7)

        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            total_order_qty=300,
            total_shipped_qty=250,
            ord_created_date=test_date
        )
        TestDataFactory.create_order_transaction(
            material=brand_material,
            plant=self.plant,
            total_order_qty=200,
            total_shipped_qty=180,
            ord_created_date=test_date
        )
        TestDataFactory.create_order_transaction(
            material=otc_material,
            plant=self.plant,
            total_order_qty=100,
            total_shipped_qty=90,
            ord_created_date=test_date
        )

        url = reverse('order-transaction:material-group-units-weekly')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(len(response.data), 0)

        # Find the week with all three groups
        week_with_all_groups = None
        for week_data in response.data:
            if (week_data['generic_ordered_units'] > 0 and
                week_data['brand_ordered_units'] > 0 and
                    week_data['otc_ordered_units'] > 0):
                week_with_all_groups = week_data
                break

        self.assertIsNotNone(week_with_all_groups, "Should have a week with all three material groups")
        self.assertEqual(week_with_all_groups['generic_ordered_units'], 300)
        self.assertEqual(week_with_all_groups['generic_shipped_units'], 250)
        self.assertEqual(week_with_all_groups['brand_ordered_units'], 200)
        self.assertEqual(week_with_all_groups['brand_shipped_units'], 180)
        self.assertEqual(week_with_all_groups['otc_ordered_units'], 100)
        self.assertEqual(week_with_all_groups['otc_shipped_units'], 90)

    def test_material_with_contract_sales_view(self):
        """Test material sales with contract breakdown endpoint"""

        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=150,
            ord_created_date=date.today(),
            contract_name="Contract A"
        )
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=100,
            ord_created_date=date.today(),
            contract_name="Contract B"
        )

        url = reverse('order-transaction:material-with-contract-sales')
        response = self.client.get(url, {'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)
        material_data = response.data['results'][0]
        self.assertIn('name', material_data)
        self.assertIn('mat_nbr', material_data)
        self.assertIn('total_sales_qty', material_data)
        self.assertIn('contract_sales', material_data)
        self.assertEqual(material_data['total_sales_qty'], 250)
        self.assertEqual(len(material_data['contract_sales']), 2)

    def test_corporate_with_contract_sales_view(self):
        """Test corporate sales with contract breakdown endpoint"""
        corporate_a = TestDataFactory.create_customer_corp_chain(name="Corporate Chain A")

        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=200,
            ord_created_date=date.today(),
            cust_corp_chain_nbr=corporate_a,
            contract_name='Contract X'
        )
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=300,
            ord_created_date=date.today(),
            cust_corp_chain_nbr=corporate_a,
            contract_name='Contract Y'
        )

        url = reverse('order-transaction:contract-with-corporate-sales')
        response = self.client.get(url, {'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)

        corporate_data = response.data['results'][0]
        self.assertIn('name', corporate_data)
        self.assertIn('corporate_chain_nbr', corporate_data)
        self.assertIn('total_sales_qty', corporate_data)
        self.assertIn('contract_sales', corporate_data)
        self.assertEqual(corporate_data['total_sales_qty'], 500)
        self.assertEqual(len(corporate_data['contract_sales']), 2)

    def test_material_with_sales_group_sales_view(self):
        """Test material sales with sales group breakdown endpoint"""
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=150,
            ord_created_date=date.today(),
            sales_group="PGEN"
        )
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=100,
            ord_created_date=date.today(),
            sales_group="PRxO"
        )

        url = reverse('order-transaction:material-with-sales-group-sales')
        response = self.client.get(url, {'limit': 10, 'offset': 0})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)

        result = response.data['results'][0]
        self.assertEqual(result['mat_nbr'], self.material.mat_nbr)
        self.assertEqual(result['total_sales_qty'], 250)
        self.assertEqual(len(result['sales_group_sales']), 2)
        groups = [s['sales_group'] for s in result['sales_group_sales']]
        self.assertIn('PGEN', groups)
        self.assertIn('PRxO', groups)

    def test_corporate_with_sales_group_sales_view(self):
        """Test corporate sales with sales group breakdown endpoint"""
        corporate = TestDataFactory.create_customer_corp_chain(name="Corp A")

        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=200,
            ord_created_date=date.today(),
            cust_corp_chain_nbr=corporate,
            sales_group="PGEN"
        )
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=300,
            ord_created_date=date.today(),
            cust_corp_chain_nbr=corporate,
            sales_group="PRxO"
        )

        url = reverse('order-transaction:corporate-with-sales-group-sales')
        response = self.client.get(url, {'limit': 10, 'offset': 0})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)

        result = response.data['results'][0]
        self.assertIn('name', result)
        self.assertIn('corporate_chain_nbr', result)
        self.assertIn('total_sales_qty', result)
        self.assertIn('sales_group_sales', result)
        self.assertEqual(result['total_sales_qty'], 500)
        self.assertEqual(len(result['sales_group_sales']), 2)

    def test_state_sales_view(self):
        """Test state sales endpoint"""
        customer_ca = TestDataFactory.create_customer(state="California")
        customer_ny = TestDataFactory.create_customer(state="New York")

        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=400,
            ord_created_date=date.today(),
            cust_nbr=customer_ca
        )
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=300,
            ord_created_date=date.today(),
            cust_nbr=customer_ny
        )

        url = reverse('order-transaction:state-sales')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertEqual(len(response.data), 2)

        # Check response structure
        state_data = response.data[0]
        self.assertIn('name', state_data)
        self.assertIn('total_sales_qty', state_data)

        # Check ordering (California should be first with higher sales)
        self.assertEqual(state_data['name'], 'California')
        self.assertEqual(state_data['total_sales_qty'], 400)

    def test_state_sales_view_no_pagination(self):
        """Test that state sales view doesn't use pagination"""
        customer_tx = TestDataFactory.create_customer(state="Texas")

        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            total_shipped_qty=100,
            ord_created_date=date.today(),
            cust_nbr=customer_tx
        )

        url = reverse('order-transaction:state-sales')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Should return list directly, not paginated response
        self.assertIsInstance(response.data, list)
        self.assertNotIn('results', response.data)
        self.assertNotIn('count', response.data)

    def test_alt_served_by_material_group_weekly_view(self):
        """Test alt served by material group weekly endpoint"""
        from datetime import timedelta

        # Create materials with different groups using actual codes
        generic_material = TestDataFactory.create_material(material_group='GRX')
        brand_material = TestDataFactory.create_material(material_group='BRX')

        # Create alt served orders
        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            alt_plant_serv_flg_key=True
        )
        TestDataFactory.create_order_transaction(
            material=brand_material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=14),
            alt_plant_serv_flg_key=True
        )

        # Create regular orders
        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=10),
            alt_plant_serv_flg_key=False
        )

        url = reverse('order-transaction:material-group-alt-serve-trend')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Check response structure
        self.assertIn('weekly_data', response.data)
        self.assertIn('totals_by_group', response.data)
        self.assertIn('overall_stats', response.data)

        # Check overall stats structure
        overall_stats = response.data['overall_stats']
        self.assertIn('total_orders', overall_stats)
        self.assertIn('alt_served_orders', overall_stats)
        self.assertIn('alt_served_percentage', overall_stats)

        # Check totals by group structure
        totals_by_group = response.data['totals_by_group']
        if len(totals_by_group) > 0:
            first_group = totals_by_group[0]
            self.assertIn('material_group', first_group)
            self.assertIn('alt_served_count', first_group)
            self.assertIn('alt_served_percentage', first_group)

        # Check weekly data structure
        weekly_data = response.data['weekly_data']
        if len(weekly_data) > 0:
            first_week = weekly_data[0]
            self.assertIn('week_start', first_week)
            self.assertIn('generic_alt_served_count', first_week)
            self.assertIn('brand_alt_served_count', first_week)
            self.assertIn('otc_alt_served_count', first_week)

    def test_alt_served_by_material_group_weekly_view_empty_data(self):
        """Test alt served weekly view with no data"""
        url = reverse('order-transaction:material-group-alt-serve-trend')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Should still return proper structure even with no data
        self.assertIn('weekly_data', response.data)
        self.assertIn('totals_by_group', response.data)
        self.assertIn('overall_stats', response.data)

        # Overall stats should indicate no data
        overall_stats = response.data['overall_stats']
        self.assertEqual(overall_stats['total_orders'], 0)
        self.assertEqual(overall_stats['alt_served_orders'], 0)
        self.assertEqual(overall_stats['alt_served_percentage'], 0)

    def test_alt_served_by_material_group_weekly_view_comprehensive(self):
        """Test alt served weekly view with comprehensive data across multiple weeks"""

        # Create materials with scrm_mat_grp set
        generic_material = TestDataFactory.create_material()
        generic_material.scrm_mat_grp = 'GRX'
        generic_material.save()

        brand_material = TestDataFactory.create_material()
        brand_material.scrm_mat_grp = 'BRX'
        brand_material.save()

        otc_material = TestDataFactory.create_material()
        otc_material.scrm_mat_grp = 'OTC'
        otc_material.save()

        # Create orders across multiple weeks
        base_date = date.today() - timedelta(days=30)

        # Week 1: Generic and Brand alt served
        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            ord_created_date=base_date,
            alt_plant_serv_flg_key=True
        )
        TestDataFactory.create_order_transaction(
            material=brand_material,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=1),
            alt_plant_serv_flg_key=True
        )

        # Week 2: OTC alt served
        TestDataFactory.create_order_transaction(
            material=otc_material,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=7),
            alt_plant_serv_flg_key=True
        )

        # Regular orders (not alt served)
        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=2),
            alt_plant_serv_flg_key=False
        )

        url = reverse('order-transaction:material-group-alt-serve-trend')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Verify overall stats
        overall_stats = response.data['overall_stats']
        self.assertEqual(overall_stats['total_orders'], 4)
        self.assertEqual(overall_stats['alt_served_orders'], 3)
        self.assertEqual(overall_stats['alt_served_percentage'], 75.0)

        # Verify totals by group
        totals_by_group = response.data['totals_by_group']
        self.assertEqual(len(totals_by_group), 3)  # All 3 material groups should be present

        # Verify each material group appears in totals
        material_groups = [item['material_group'] for item in totals_by_group]
        self.assertIn('Generic', material_groups)
        self.assertIn('Brand', material_groups)
        self.assertIn('OTC', material_groups)

        # Verify weekly data has the expected structure
        weekly_data = response.data['weekly_data']
        self.assertGreater(len(weekly_data), 0)

        # Check that weekly data contains the expected counts
        total_weekly_alt_served = sum(
            week['generic_alt_served_count'] +
            week['brand_alt_served_count'] +
            week['otc_alt_served_count']
            for week in weekly_data
        )
        self.assertEqual(total_weekly_alt_served, 3)

    def test_substituted_by_material_group_weekly_view_empty_data(self):
        """Test substituted weekly view with no data"""
        url = reverse('order-transaction:material-group-substituted-trend')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Verify overall stats
        overall_stats = response.data['overall_stats']
        self.assertEqual(overall_stats['total_orders'], 0)
        self.assertEqual(overall_stats['substituted_orders'], 0)
        self.assertEqual(overall_stats['substituted_percentage'], 0)

    def test_substituted_by_material_group_weekly_view_comprehensive(self):
        """Test substituted weekly view with comprehensive data across multiple weeks"""

        # Create materials with scrm_mat_grp set
        generic_material = TestDataFactory.create_material()
        generic_material.scrm_mat_grp = 'GRX'
        generic_material.save()

        brand_material = TestDataFactory.create_material()
        brand_material.scrm_mat_grp = 'BRX'
        brand_material.save()

        otc_material = TestDataFactory.create_material()
        otc_material.scrm_mat_grp = 'OTC'
        otc_material.save()

        # Create substituted materials
        substituted_generic = TestDataFactory.create_material()
        substituted_generic.scrm_mat_grp = 'GRX'
        substituted_generic.save()

        substituted_brand = TestDataFactory.create_material()
        substituted_brand.scrm_mat_grp = 'BRX'
        substituted_brand.save()

        substituted_otc = TestDataFactory.create_material()
        substituted_otc.scrm_mat_grp = 'OTC'
        substituted_otc.save()

        # Create orders across multiple weeks
        base_date = date.today() - timedelta(days=30)

        # Week 1: Generic and Brand substituted
        TestDataFactory.create_order_transaction(
            material=generic_material,
            substituted_material=substituted_generic,
            plant=self.plant,
            ord_created_date=base_date
        )
        TestDataFactory.create_order_transaction(
            material=brand_material,
            substituted_material=substituted_brand,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=1)
        )

        # Week 2: OTC substituted
        TestDataFactory.create_order_transaction(
            material=otc_material,
            substituted_material=substituted_otc,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=7)
        )

        # Regular orders (not substituted)
        TestDataFactory.create_order_transaction(
            material=generic_material,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=2)
        )

        url = reverse('order-transaction:material-group-substituted-trend')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Verify overall stats
        overall_stats = response.data['overall_stats']
        self.assertEqual(overall_stats['total_orders'], 4)
        self.assertEqual(overall_stats['substituted_orders'], 3)
        self.assertEqual(overall_stats['substituted_percentage'], 75.0)

        # Verify totals by group
        totals_by_group = response.data['totals_by_group']
        self.assertEqual(len(totals_by_group), 3)  # All 3 material groups should be present

        # Verify each material group appears in totals
        material_groups = [item['material_group'] for item in totals_by_group]
        self.assertIn('Generic', material_groups)
        self.assertIn('Brand', material_groups)
        self.assertIn('OTC', material_groups)

        # Verify weekly data has the expected structure
        weekly_data = response.data['weekly_data']
        self.assertGreater(len(weekly_data), 0)

        # Check that weekly data contains the expected counts
        total_weekly_substituted = sum(
            week['generic_substituted_count'] +
            week['brand_substituted_count'] +
            week['otc_substituted_count']
            for week in weekly_data
        )
        self.assertEqual(total_weekly_substituted, 3)

    def test_weekly_order_analysis_view(self):
        """Test weekly order analysis view endpoint"""

        # Create materials for testing
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        # Create orders with different characteristics across multiple weeks
        # Week 1 - 7 days ago
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            alt_plant_serv_flg_key=True
        )
        TestDataFactory.create_order_transaction(
            material=material1,
            substituted_material=material2,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7)
        )
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7)
        )

        # Week 2 - 14 days ago
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=14),
            alt_plant_serv_flg_key=True
        )
        TestDataFactory.create_order_transaction(
            material=material2,
            substituted_material=material1,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=14),
            alt_plant_serv_flg_key=True
        )

        url = reverse('order-transaction:alt-serve-substituted-overall-stats')
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        data = response.data

        # Ddata structure
        for week_data in data:
            self.assertIn('week_start', week_data)
            self.assertIn('total_orders', week_data)
            self.assertIn('total_order_qty', week_data)
            self.assertIn('total_shipped_qty', week_data)
            self.assertIn('alt_served_count', week_data)
            self.assertIn('alt_served_percentage', week_data)
            self.assertIn('substituted_count', week_data)
            self.assertIn('substituted_percentage', week_data)

            # Verify data types
            self.assertIsInstance(week_data['total_orders'], int)
            self.assertIsInstance(week_data['total_order_qty'], int)
            self.assertIsInstance(week_data['total_shipped_qty'], int)
            self.assertIsInstance(week_data['alt_served_count'], int)
            self.assertIsInstance(week_data['substituted_count'], int)
            self.assertIsInstance(week_data['alt_served_percentage'], float)
            self.assertIsInstance(week_data['substituted_percentage'], float)

        # Verify totals match expected values
        total_orders_sum = sum(week['total_orders'] for week in data)
        total_alt_served_sum = sum(week['alt_served_count'] for week in data)
        total_substituted_sum = sum(week['substituted_count'] for week in data)

        self.assertEqual(total_orders_sum, 5)
        self.assertEqual(total_alt_served_sum, 3)
        self.assertEqual(total_substituted_sum, 2)

    def test_weekly_order_analysis_view_with_material_filter(self):
        """Material filter returns 200 with total_order_qty and total_shipped_qty per week."""
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            total_order_qty=100,
            total_shipped_qty=90,
            ord_created_date=date.today() - timedelta(days=7),
        )
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            total_order_qty=500,
            total_shipped_qty=400,
            ord_created_date=date.today() - timedelta(days=7),
        )

        url = reverse('order-transaction:alt-serve-substituted-overall-stats')
        response = self.client.get(
            url,
            {'material': f'{material1.mat_nbr},{material2.mat_nbr}'},
        )

        self.assertEqual(response.status_code, 200)
        for week_data in response.data:
            self.assertIn('week_start', week_data)
            self.assertIn('total_orders', week_data)
            self.assertIn('total_order_qty', week_data)
            self.assertIn('total_shipped_qty', week_data)
            self.assertIn('alt_served_count', week_data)
            self.assertIn('substituted_count', week_data)

    def test_order_kpis_view(self):
        """Test the OrderKpisView endpoint"""
        # Create test data
        material = TestDataFactory.create_material()
        substituted_material = TestDataFactory.create_material()

        # Create various order types
        # Perfect order
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=10),
            total_order_qty=100,
            alt_plant_serv_flg_key=False,
            f_total_imperfect=0
        )
        # Imperfect order (alt-served + substituted)
        TestDataFactory.create_order_transaction(
            material=material,
            substituted_material=substituted_material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=20),
            total_order_qty=200,
            alt_plant_serv_flg_key=True,
            f_total_imperfect=1
        )

        url = reverse('order-transaction:order-kpis')
        response = self.client.get(url)

        # Check response structure
        self.assertEqual(response.status_code, 200)
        self.assertIn('total_orders', response.data)
        self.assertIn('total_units', response.data)
        self.assertIn('alt_served_orders', response.data)
        self.assertIn('alt_served_units', response.data)
        self.assertIn('alt_serve_rate', response.data)
        self.assertIn('substituted_orders', response.data)
        self.assertIn('substituted_units', response.data)
        self.assertIn('substitution_rate', response.data)
        self.assertIn('perfect_orders', response.data)
        self.assertIn('perfect_order_rate', response.data)

        # Verify data types
        self.assertIsInstance(response.data['total_orders'], int)
        self.assertIsInstance(response.data['total_units'], int)
        self.assertIsInstance(response.data['alt_served_orders'], int)
        self.assertIsInstance(response.data['alt_served_units'], int)
        self.assertIsInstance(response.data['alt_serve_rate'], float)
        self.assertIsInstance(response.data['substituted_orders'], int)
        self.assertIsInstance(response.data['substituted_units'], int)
        self.assertIsInstance(response.data['substitution_rate'], float)
        self.assertIsInstance(response.data['perfect_orders'], int)
        self.assertIsInstance(response.data['perfect_order_rate'], float)

        # Verify specific values
        self.assertEqual(response.data['total_orders'], 2)
        self.assertEqual(response.data['total_units'], 300)
        self.assertEqual(response.data['alt_served_orders'], 1)
        self.assertEqual(response.data['alt_served_units'], 200)
        self.assertEqual(response.data['alt_serve_rate'], 50.0)
        self.assertEqual(response.data['substituted_orders'], 1)
        self.assertEqual(response.data['substituted_units'], 200)
        self.assertEqual(response.data['substitution_rate'], 50.0)
        self.assertEqual(response.data['perfect_orders'], 1)
        self.assertEqual(response.data['perfect_order_rate'], 50.0)

    def test_order_kpis_view_empty_data(self):
        """Test OrderKpisView with no data"""
        url = reverse('order-transaction:order-kpis')
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)

        # All values should be zero when no data exists
        self.assertEqual(response.data['total_orders'], 0)
        self.assertEqual(response.data['total_units'], 0)
        self.assertEqual(response.data['alt_served_orders'], 0)
        self.assertEqual(response.data['alt_served_units'], 0)
        self.assertEqual(response.data['alt_serve_rate'], 0)
        self.assertEqual(response.data['substituted_orders'], 0)
        self.assertEqual(response.data['substituted_units'], 0)
        self.assertEqual(response.data['substitution_rate'], 0)
        self.assertEqual(response.data['perfect_orders'], 0)
        self.assertEqual(response.data['perfect_order_rate'], 0)

    def test_order_kpis_view_date_filtering(self):
        """Test that OrderKpisView only includes last 90 days"""
        material = TestDataFactory.create_material()

        # Order outside 90-day window
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=100),
            total_order_qty=500,
            alt_plant_serv_flg_key=True
        )

        # Order within 90-day window
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=10),
            total_order_qty=100,
            alt_plant_serv_flg_key=True
        )

        url = reverse('order-transaction:order-kpis')
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        # Should only include the recent order
        self.assertEqual(response.data['total_orders'], 1)
        self.assertEqual(response.data['total_units'], 100)
        self.assertEqual(response.data['alt_served_orders'], 1)

    def test_substitution_alt_serve_kpis_view(self):
        """Test the SubstitutionAltServeKpisView endpoint"""
        # Create test data
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        material3 = TestDataFactory.create_material()
        material4 = TestDataFactory.create_material()
        substituted_material = TestDataFactory.create_material()

        # Material 1: has substitution only
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=10),
            substituted_material=substituted_material
        )

        # Material 2: has alt serve only
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=20),
            alt_plant_serv_flg_key=True
        )

        # Material 3: has both substitution and alt serve
        TestDataFactory.create_order_transaction(
            material=material3,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=30),
            substituted_material=substituted_material,
            alt_plant_serv_flg_key=True
        )

        # Material 4: has neither
        TestDataFactory.create_order_transaction(
            material=material4,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=40)
        )

        url = reverse('order-transaction:substitution-alt-serve-kpis')
        response = self.client.get(url)

        # Check response structure
        self.assertEqual(response.status_code, 200)
        self.assertIn('total_materials', response.data)
        self.assertIn('materials_with_substitution', response.data)
        self.assertIn('substitution_percent', response.data)
        self.assertIn('materials_with_alt_serve', response.data)
        self.assertIn('alt_serve_percent', response.data)

        # Verify data types
        self.assertIsInstance(response.data['total_materials'], int)
        self.assertIsInstance(response.data['materials_with_substitution'], int)
        self.assertIsInstance(response.data['substitution_percent'], float)
        self.assertIsInstance(response.data['materials_with_alt_serve'], int)
        self.assertIsInstance(response.data['alt_serve_percent'], float)

        # Verify specific values
        self.assertEqual(response.data['total_materials'], 4)
        self.assertEqual(response.data['materials_with_substitution'], 2)  # material1, material3
        self.assertEqual(response.data['substitution_percent'], 50.0)  # 2/4 * 100
        self.assertEqual(response.data['materials_with_alt_serve'], 2)  # material2, material3
        self.assertEqual(response.data['alt_serve_percent'], 50.0)  # 2/4 * 100

    def test_substitution_alt_serve_kpis_view_empty_data(self):
        """Test SubstitutionAltServeKpisView with no data"""
        url = reverse('order-transaction:substitution-alt-serve-kpis')
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)

        # All values should be zero when no data exists
        self.assertEqual(response.data['total_materials'], 0)
        self.assertEqual(response.data['materials_with_substitution'], 0)
        self.assertEqual(response.data['substitution_percent'], 0.0)
        self.assertEqual(response.data['materials_with_alt_serve'], 0)
        self.assertEqual(response.data['alt_serve_percent'], 0.0)

    def test_alt_served_breakdown_analysis_view_comprehensive(self):
        """Test alt served breakdown analysis view with comprehensive data validation"""
        # Create materials with scrm_mat_grp set
        generic_material = TestDataFactory.create_material()
        generic_material.scrm_mat_grp = 'GRX'
        generic_material.save()

        brand_material = TestDataFactory.create_material()
        brand_material.scrm_mat_grp = 'BRX'
        brand_material.save()

        otc_material = TestDataFactory.create_material()
        otc_material.scrm_mat_grp = 'OTC'
        otc_material.save()

        # Create multiple plants
        plant2 = TestDataFactory.create_plant()
        plant3 = TestDataFactory.create_plant()

        # Create alt served orders with known quantities for percentage validation
        # 4 Generic orders (44.44%)
        for _ in range(4):
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=True,
                class_of_trade_desc="HOSPITAL",
                class_of_trade_nbr="1005"
            )

        # 3 Brand orders (33.33%)
        for _ in range(3):
            TestDataFactory.create_order_transaction(
                material=brand_material,
                plant=plant2,
                ord_created_date=date.today() - timedelta(days=20),
                alt_plant_serv_flg_key=True,
                class_of_trade_desc="INDEPENDENT",
                class_of_trade_nbr="1004"
            )

        # 2 OTC orders (22.22%)
        for _ in range(2):
            TestDataFactory.create_order_transaction(
                material=otc_material,
                plant=plant3,
                ord_created_date=date.today() - timedelta(days=30),
                alt_plant_serv_flg_key=True,
                class_of_trade_desc="CHAIN",
                class_of_trade_nbr="1003"
            )

        url = reverse('order-transaction:alt-served-breakdown-analysis')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Verify material group percentages
        totals_by_group = response.data['totals_by_group']
        self.assertEqual(len(totals_by_group), 3)

        material_group_data = {item['material_group']: item for item in totals_by_group}
        self.assertEqual(material_group_data['Generic']['alt_served_count'], 4)
        self.assertAlmostEqual(material_group_data['Generic']['alt_served_percentage'], 44.44, places=1)
        self.assertEqual(material_group_data['Brand']['alt_served_count'], 3)
        self.assertAlmostEqual(material_group_data['Brand']['alt_served_percentage'], 33.33, places=1)
        self.assertEqual(material_group_data['OTC']['alt_served_count'], 2)
        self.assertAlmostEqual(material_group_data['OTC']['alt_served_percentage'], 22.22, places=1)

        # Verify class of trade data
        total_by_class_of_trade = response.data['total_by_class_of_trade']
        self.assertEqual(len(total_by_class_of_trade), 3)  # HOSPITAL, INDEPENDENT, CHAIN

        class_of_trade_data = {item['class_of_trade']: item for item in total_by_class_of_trade}
        self.assertEqual(class_of_trade_data['HOSPITAL']['alt_served_count'], 4)  # 4 Generic
        self.assertEqual(class_of_trade_data['INDEPENDENT']['alt_served_count'], 3)  # 3 Brand
        self.assertEqual(class_of_trade_data['CHAIN']['alt_served_count'], 2)  # 2 OTC

        # Verify plant data
        totals_by_plant = response.data['totals_by_plant']
        self.assertEqual(len(totals_by_plant), 3)  # Three plants

        plant_data = {item['plant']: item for item in totals_by_plant}
        self.assertEqual(plant_data[self.plant.name]['alt_served_count'], 4)  # 4 Generic
        self.assertEqual(plant_data[plant2.name]['alt_served_count'], 3)  # 3 Brand
        self.assertEqual(plant_data[plant3.name]['alt_served_count'], 2)  # 2 OTC

        # Verify percentages sum to 100% for each breakdown
        total_material_percentage = sum(item['alt_served_percentage'] for item in totals_by_group)
        total_class_percentage = sum(item['alt_served_percentage'] for item in total_by_class_of_trade)
        total_plant_percentage = sum(item['alt_served_percentage'] for item in totals_by_plant)

        self.assertAlmostEqual(total_material_percentage, 100.0, places=1)
        self.assertAlmostEqual(total_class_percentage, 100.0, places=1)
        self.assertAlmostEqual(total_plant_percentage, 100.0, places=1)

        # Verify data types
        for group in totals_by_group:
            self.assertIsInstance(group['material_group'], str)
            self.assertIsInstance(group['alt_served_count'], int)
            self.assertIsInstance(group['alt_served_percentage'], float)

        for trade in total_by_class_of_trade:
            self.assertIsInstance(trade['class_of_trade'], str)
            self.assertIsInstance(trade['alt_served_count'], int)
            self.assertIsInstance(trade['alt_served_percentage'], float)

        for plant in totals_by_plant:
            self.assertIsInstance(plant['plant'], str)
            self.assertIsInstance(plant['alt_served_count'], int)
            self.assertIsInstance(plant['alt_served_percentage'], float)

    def test_alt_served_breakdown_analysis_view_empty_data(self):
        """Test alt served breakdown analysis view with no alt served orders"""
        # Create regular order (not alt served)
        TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=10),
            alt_plant_serv_flg_key=False
        )

        url = reverse('order-transaction:alt-served-breakdown-analysis')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # All arrays should be empty
        self.assertEqual(len(response.data['totals_by_group']), 0)
        self.assertEqual(len(response.data['total_by_class_of_trade']), 0)
        self.assertEqual(len(response.data['totals_by_plant']), 0)

    def test_alt_served_by_material_status_view(self):
        """Test alt served by material status API endpoint"""
        # Create test data
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=10),
            alt_plant_serv_flg_key=True,
            material_status="ACTIVE"
        )
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=20),
            alt_plant_serv_flg_key=True,
            material_status="DISCONTINUED"
        )

        url = reverse('order-transaction:alt-served-material-group-breakdown')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)

        # Check data structure
        for item in response.data:
            self.assertIn('status', item)
            self.assertIn('alt_served_count', item)
            self.assertIn('alt_served_percentage', item)

    def test_alt_served_by_material_status_view_empty(self):
        """Test alt served by material status API endpoint with no data"""
        url = reverse('order-transaction:alt-served-material-group-breakdown')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 0)

    def test_alt_served_by_material_status_view_single_status(self):
        """Test alt served by material status API endpoint with single status"""
        material = TestDataFactory.create_material()
        second_material = TestDataFactory.create_material()

        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=10),
            alt_plant_serv_flg_key=True,
            material_status="ACTIVE",
        )
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=15),
            alt_plant_serv_flg_key=True,
            material_status="ACTIVE"
        )

        TestDataFactory.create_order_transaction(
            material=second_material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=5),
            alt_plant_serv_flg_key=True,
            material_status="ACTIVE"
        )

        url = reverse('order-transaction:alt-served-materials-by-status',
                      kwargs={'material_status': 'ACTIVE'})
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)

        # Material has 2 alt-served orders, second_material has 1
        # So material comes first (index 0)
        first_item = response.data[0]
        self.assertEqual(first_item['material_name'], material.name)
        self.assertEqual(first_item['alt_served_count'], 2)
        self.assertEqual(first_item['alt_served_percentage'], 66.7)  # 2/3 * 100

        second_item = response.data[1]
        self.assertEqual(second_item['material_name'], second_material.name)
        self.assertEqual(second_item['alt_served_count'], 1)
        self.assertEqual(second_item['alt_served_percentage'], 33.3)  # 1/3 * 100

    def test_alt_served_units_by_type_weekly_view(self):
        """Test alt served units by type weekly endpoint """

        # Create test materials
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        # Create alt served orders with different types across multiple weeks
        base_date = date.today() - timedelta(days=30)

        # Week 1: AUTO and MANUAL orders
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=base_date,
            total_order_qty=100,
            alt_plant_serv_flg_key=True,
            alt_serve_type=OrderTransaction.AltServeTypes.AUTO
        )
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=1),
            total_order_qty=150,
            alt_plant_serv_flg_key=True,
            alt_serve_type=OrderTransaction.AltServeTypes.MANUAL
        )

        # Week 2: More AUTO and MANUAL orders
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=7),
            total_order_qty=200,
            alt_plant_serv_flg_key=True,
            alt_serve_type=OrderTransaction.AltServeTypes.AUTO
        )
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=8),
            total_order_qty=75,
            alt_plant_serv_flg_key=True,
            alt_serve_type=OrderTransaction.AltServeTypes.MANUAL
        )

        # Non-alt served order (should be excluded)
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=base_date + timedelta(days=2),
            total_order_qty=300,
            alt_plant_serv_flg_key=False
        )

        url = reverse('order-transaction:alt-served-units-by-type')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertGreater(len(response.data), 0)

        # Check response structure
        for week_data in response.data:
            self.assertIn('week_start', week_data)
            self.assertIn('auto_units', week_data)
            self.assertIn('manual_units', week_data)
            self.assertIn('total_units', week_data)

            # Verify data types
            self.assertIsInstance(week_data['auto_units'], (int, type(None)))
            self.assertIsInstance(week_data['manual_units'], (int, type(None)))
            self.assertIsInstance(week_data['total_units'], (int, type(None)))

        # Verify total units across all weeks
        total_auto_units = sum(week['auto_units'] or 0 for week in response.data)
        total_manual_units = sum(week['manual_units'] or 0 for week in response.data)
        total_units_sum = sum(week['total_units'] or 0 for week in response.data)

        self.assertEqual(total_auto_units, 300)  # 100 + 200
        self.assertEqual(total_manual_units, 225)  # 150 + 75
        self.assertEqual(total_units_sum, 525)  # 300 + 225

    def test_alt_served_order_qty_by_cost_range_and_status_view(self):
        """Test alt served order quantity by cost range and material status endpoint"""

        # Create test materials
        material_low = TestDataFactory.create_material(cost_per_unit=5.0)
        material_mid = TestDataFactory.create_material(cost_per_unit=25.0)
        material_high = TestDataFactory.create_material(cost_per_unit=75.0)

        # Create alt served orders
        TestDataFactory.create_order_transaction(
            material=material_low,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=10),
            alt_plant_serv_flg_key=True,
            material_status="ACTIVE",
            total_order_qty=100
        )

        TestDataFactory.create_order_transaction(
            material=material_mid,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=20),
            alt_plant_serv_flg_key=True,
            material_status="OBSOLETE",
            total_order_qty=200
        )

        TestDataFactory.create_order_transaction(
            material=material_high,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=30),
            alt_plant_serv_flg_key=True,
            material_status="TEMP UNAVAILABLE",
            total_order_qty=150
        )

        # Non-alt served order (should be excluded)
        TestDataFactory.create_order_transaction(
            material=material_low,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=5),
            alt_plant_serv_flg_key=False,
            material_status="NON_ACTIVE",
            total_order_qty=500
        )

        url = reverse('order-transaction:alt-served-order-qty-by-status-and-cost-range')
        response = self.client.get(url)

        # Basic checks
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertGreater(len(response.data), 0)

        for item in response.data:
            self.assertIn('cost_range', item)
            self.assertIn('material_statuses', item)
            self.assertIsInstance(item['material_statuses'], dict)

        cost_map = {item['cost_range']: item['material_statuses'] for item in response.data}
        self.assertEqual(cost_map["0-15"]["ACTIVE"], 100)
        self.assertEqual(cost_map["16-50"]["OBSOLETE"], 200)
        self.assertEqual(cost_map["51-100"]["TEMP UNAVAILABLE"], 150)

        # Ensure non-alt served order is excluded
        self.assertNotIn("NON_ACTIVE", cost_map.get("0-15", {}) or {} or {},
                         msg="Non-alt served order included")

    def test_get_material_status_distinct(self):
        """Test distinct material statuses retrieval"""
        # Create test materials
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        material3 = TestDataFactory.create_material()

        # Create orders with different material statuses
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE"
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=20),
                alt_plant_serv_flg_key=True,
                material_status="DISCONTINUED"
            )
            TestDataFactory.create_order_transaction(
                material=material3,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=30),
                alt_plant_serv_flg_key=True,
                material_status="OBSOLETE"
            )
            # Duplicate status to test distinct
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=5),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE"
            )

        self._order_transaction_mvs_dirty = False

        url = reverse('order-transaction:material-status')
        response = self.client.get(url)

        # Assertions
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 3)

        # Extract material_status values from response
        status_values = [item['material_status'] for item in response.data]

        self.assertIn("ACTIVE", status_values)
        self.assertIn("DISCONTINUED", status_values)
        self.assertIn("OBSOLETE", status_values)

    def test_material_omit_counts_last_three_months(self):
        """Test material omit counts for last three months endpoint"""
        # Create test materials with different fill rates
        material1 = TestDataFactory.create_material(mat_nbr="MAT_EXCESS")
        material2 = TestDataFactory.create_material(mat_nbr="MAT_ALLOWED")
        material3 = TestDataFactory.create_material(mat_nbr="MAT_NO_OMIT")

        today = date.today()

        # Material with excess omits (fill rate < 0.85)
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=today - timedelta(days=10),
            total_order_qty=100,
            total_shipped_qty=50  # 50% fill rate
        )

        # Material with allowed omits (0.85 <= fill rate < 1.0)
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            ord_created_date=today - timedelta(days=15),
            total_order_qty=100,
            total_shipped_qty=90  # 90% fill rate
        )

        # Material with no omits (fill rate >= 1.0)
        TestDataFactory.create_order_transaction(
            material=material3,
            plant=self.plant,
            ord_created_date=today - timedelta(days=20),
            total_order_qty=100,
            total_shipped_qty=100  # 100% fill rate
        )

        url = reverse('order-transaction:material-omit-counts-last-three-months')
        response = self.client.get(url)

        # Assertions
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('excess_omits_count', response.data)
        self.assertIn('allowed_omits_count', response.data)
        self.assertIn('no_omits_count', response.data)
        self.assertIn('total_products_ordered', response.data)
        self.assertIn('total_products_with_omits', response.data)
        self.assertIn('weekly_data', response.data)

        # Check counts
        self.assertEqual(response.data['excess_omits_count'], 1)
        self.assertEqual(response.data['allowed_omits_count'], 1)
        self.assertEqual(response.data['no_omits_count'], 1)
        self.assertEqual(response.data['total_products_with_omits'], 2)

        # Check weekly data structure
        self.assertIsInstance(response.data['weekly_data'], list)
        if len(response.data['weekly_data']) > 0:
            week_data = response.data['weekly_data'][0]
            self.assertIn('year', week_data)
            self.assertIn('week', week_data)
            self.assertIn('week_start', week_data)
            self.assertIn('week_end', week_data)
            self.assertIn('excess_omits_count', week_data)
            self.assertIn('allowed_omits_count', week_data)
            self.assertIn('no_omits_count', week_data)

    def test_fulfillment_metrics(self):
        """Test fulfillment metrics endpoint"""
        today = date.today()

        # Create orders across multiple weeks
        for week_offset in [0, 7, 14, 21]:
            test_date = today - timedelta(days=week_offset)

            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=test_date,
                total_order_qty=100,
                total_shipped_qty=85
            )

            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=test_date,
                total_order_qty=200,
                total_shipped_qty=190
            )

        url = reverse('order-transaction:fulfillment-metrics')
        response = self.client.get(url)

        # Assertions
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)

        # Check each week's data structure
        for week_metrics in response.data:
            self.assertIn('year', week_metrics)
            self.assertIn('week', week_metrics)
            self.assertIn('week_start', week_metrics)
            self.assertIn('week_end', week_metrics)
            self.assertIn('unshipped_quantity', week_metrics)
            self.assertIn('fulfillment_percentage', week_metrics)

            # Verify fulfillment percentage is within valid range
            self.assertGreaterEqual(week_metrics['fulfillment_percentage'], 0)
            self.assertLessEqual(week_metrics['fulfillment_percentage'], 100)

            # Verify unshipped_quantity is a number
            self.assertIsInstance(week_metrics['unshipped_quantity'], (int, float))

    def test_weekly_perfect_order_analysis_view(self):
        """Integration test for WeeklyPerfectOrderAnalysisView"""
        # Create test materials
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        # Create orders with different perfect/imperfect status across multiple weeks
        # Week 1 - 7 days ago
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            f_total_imperfect=0  # Perfect order
        )
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            f_total_imperfect=1  # Imperfect order
        )

        # Week 2 - 14 days ago
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=14),
            f_total_imperfect=0  # Perfect order
        )
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=14),
            f_total_imperfect=1  # Imperfect order
        )

        # Make API request
        response = self.client.get(reverse('order-transaction:perfect-order-rate'))

        # Verify response
        self.assertEqual(response.status_code, 200)

        response = response.json()
        data = response['data']
        self.assertIsInstance(data, list)
        self.assertGreater(len(data), 0)

        # Verify data structure
        for week_data in data:
            self.assertIn('week_start', week_data)
            self.assertIn('total_orders', week_data)
            self.assertIn('perfect_orders', week_data)
            self.assertIn('perfect_order_rate', week_data)

            # Verify data types and ranges
            self.assertIsInstance(week_data['total_orders'], int)
            self.assertIsInstance(week_data['perfect_orders'], int)
            self.assertGreaterEqual(week_data['perfect_order_rate'], 0.0)
            self.assertLessEqual(week_data['perfect_order_rate'], 100.0)

        # Verify totals
        total_orders = sum(week['total_orders'] for week in data)
        total_perfect = sum(week['perfect_orders'] for week in data)

        self.assertEqual(total_orders, 4)
        self.assertEqual(total_perfect, 2)

    def test_weekly_perfect_order_analysis_view_empty_data(self):
        """Test WeeklyPerfectOrderAnalysisView with no data"""
        response = self.client.get(reverse('order-transaction:perfect-order-rate'))

        self.assertEqual(response.status_code, 200)
        response = response.json()
        data = response['data']
        self.assertIsInstance(data, list)
        self.assertEqual(len(data), 0)

    def test_weekly_imperfect_line_rate_analysis_view(self):
        """Test weekly imperfect line rate analysis view endpoint"""
        # Create materials for testing
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        # Create orders with different imperfect flags
        TestDataFactory.create_order_transaction(
            material=material1,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            f_unpredictable_demand=1,
            f_omit_inflation=0,
            f_unaligned_forecast=1,
            f_demand_imperfect=0
        )
        TestDataFactory.create_order_transaction(
            material=material2,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=14),
            f_unpredictable_demand=0,
            f_omit_inflation=1,
            f_unaligned_forecast=0,
            f_demand_imperfect=1
        )

        url = reverse("order-transaction:demand-imperfect-line-rate")
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        response = response.json()
        data = response['data']
        # Verify response structure
        self.assertIsInstance(data, list)
        self.assertGreater(len(data), 0)

        # Check data structure for each week
        for week_data in data:
            required_fields = [
                'week_start', 'total_orders', 'unpredictable_demand_count',
                'unpredictable_demand_rate', 'omit_inflation_count', 'omit_inflation_rate',
                'unaligned_forecast_count', 'unaligned_forecast_rate',
                'demand_imperfect_count', 'demand_imperfect_rate'
            ]
            for field in required_fields:
                self.assertIn(field, week_data)

            # Verify data types and ranges
            self.assertIsInstance(week_data['total_orders'], int)
            self.assertGreaterEqual(week_data['unpredictable_demand_rate'], 0.0)
            self.assertLessEqual(week_data['unpredictable_demand_rate'], 100.0)
            self.assertGreaterEqual(week_data['omit_inflation_rate'], 0.0)
            self.assertLessEqual(week_data['omit_inflation_rate'], 100.0)

    def test_weekly_imperfect_line_rate_analysis_view_percentage_calculations(self):
        """Test weekly imperfect line rate analysis view percentage calculations accuracy"""
        material = TestDataFactory.create_material()

        # Create 4 orders with known flag combinations for predictable percentages
        # Week with 4 orders:
        # 2 unpredictable (50%),
        # 3 omit_inflation (75%),
        # 1 unaligned (25%),
        # 4 demand_imperfect (100%)
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            f_unpredictable_demand=1, f_omit_inflation=1, f_unaligned_forecast=0, f_demand_imperfect=1
        )
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            f_unpredictable_demand=1, f_omit_inflation=1, f_unaligned_forecast=1, f_demand_imperfect=1
        )
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            f_unpredictable_demand=0, f_omit_inflation=1, f_unaligned_forecast=0, f_demand_imperfect=1
        )
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            f_unpredictable_demand=0, f_omit_inflation=0, f_unaligned_forecast=0, f_demand_imperfect=1
        )

        url = reverse("order-transaction:demand-imperfect-line-rate")
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        response = response.json()
        data = response['data']
        self.assertEqual(len(data), 1)
        week_data = data[0]

        # Verify calculated percentages
        self.assertEqual(week_data['total_orders'], 4)
        self.assertEqual(week_data['unpredictable_demand_count'], 2)
        self.assertEqual(week_data['unpredictable_demand_rate'], 50.0)
        self.assertEqual(week_data['omit_inflation_count'], 3)
        self.assertEqual(week_data['omit_inflation_rate'], 75.0)
        self.assertEqual(week_data['unaligned_forecast_count'], 1)
        self.assertEqual(week_data['unaligned_forecast_rate'], 25.0)
        self.assertEqual(week_data['demand_imperfect_count'], 4)
        self.assertEqual(week_data['demand_imperfect_rate'], 100.0)

    def test_weekly_imperfect_line_rate_analysis_view_multiple_weeks_aggregation(self):
        """Test view with data across multiple weeks and verify aggregation accuracy"""
        material = TestDataFactory.create_material()

        # Week 1: 2 orders with different flags
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            f_unpredictable_demand=1, f_omit_inflation=0, f_unaligned_forecast=0, f_demand_imperfect=1
        )
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=7),
            f_unpredictable_demand=0, f_omit_inflation=1, f_unaligned_forecast=1, f_demand_imperfect=0
        )

        # Week 2: 1 order with all flags
        TestDataFactory.create_order_transaction(
            material=material,
            plant=self.plant,
            ord_created_date=date.today() - timedelta(days=14),
            f_unpredictable_demand=1, f_omit_inflation=1, f_unaligned_forecast=1, f_demand_imperfect=1
        )

        url = reverse("order-transaction:demand-imperfect-line-rate")
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        response = response.json()
        data = response['data']
        self.assertEqual(len(data), 2)

        # Verify totals across all weeks
        total_orders = sum(week['total_orders'] for week in data)
        total_unpredictable = sum(week['unpredictable_demand_count'] for week in data)
        total_omit_inflation = sum(week['omit_inflation_count'] for week in data)
        total_unaligned = sum(week['unaligned_forecast_count'] for week in data)
        total_demand_imperfect = sum(week['demand_imperfect_count'] for week in data)

        self.assertEqual(total_orders, 3)
        self.assertEqual(total_unpredictable, 2)  # 2 orders with f_unpredictable_demand=1
        self.assertEqual(total_omit_inflation, 2)  # 2 orders with f_omit_inflation=1
        self.assertEqual(total_unaligned, 2)  # 2 orders with f_unaligned_forecast=1
        self.assertEqual(total_demand_imperfect, 2)  # 2 orders with f_demand_imperfect=1


class OTSalesComparisonIntegrationTest(MVAPITestCase):
    """
    Integration tests for the 4 order_transaction sales comparison endpoints.
    Uses direct date params: current period Mar 1–17 2026, previous period Feb 1–17 2026.
    """

    CURRENT_START = "2026-03-01"
    CURRENT_END = "2026-03-17"
    PREVIOUS_START = "2026-02-01"
    PREVIOUS_END = "2026-02-17"

    def _params(self, **extra):
        return {
            "current_start_date": self.CURRENT_START,
            "current_end_date": self.CURRENT_END,
            "previous_start_date": self.PREVIOUS_START,
            "previous_end_date": self.PREVIOUS_END,
            **extra,
        }

    def setUp(self):
        self.material = TestDataFactory.create_material()
        self.customer = TestDataFactory.create_customer(state="CA")
        self.corp_chain = TestDataFactory.create_customer_corp_chain()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Current period orders (March 2026)
            for day in [5, 10, 15]:
                TestDataFactory.create_order_transaction(
                    material=self.material,
                    cust_nbr=self.customer,
                    cust_corp_chain_nbr=self.corp_chain,
                    sales_amount=1000.00,
                    total_order_qty=100,
                    total_shipped_qty=90,
                    sales_group="PGEN",
                    ord_created_date=date(2026, 3, day),
                )

            # Previous period orders (February 2026)
            for day in [5, 10, 15]:
                TestDataFactory.create_order_transaction(
                    material=self.material,
                    cust_nbr=self.customer,
                    cust_corp_chain_nbr=self.corp_chain,
                    sales_amount=600.00,
                    total_order_qty=60,
                    total_shipped_qty=50,
                    sales_group="PGEN",
                    ord_created_date=date(2026, 2, day),
                )

    def _assert_comparison_fields(self, item):
        for field in [
            "current_period_sales", "previous_period_sales",
            "current_period_order_qty", "previous_period_order_qty",
            "current_period_shipped_qty", "previous_period_shipped_qty",
        ]:
            self.assertIn(field, item)

    def test_by_sales_group_returns_200(self):
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params())
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_by_sales_group_response_shape(self):
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params())
        self.assertEqual(len(response.data), 1)
        row = response.data[0]
        self.assertIn("sales_group", row)
        self._assert_comparison_fields(row)

    def test_by_sales_group_correct_values(self):
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params())
        row = response.data[0]
        self.assertEqual(row["sales_group"], "PGEN")
        self.assertEqual(float(row["current_period_sales"]), 3000.0)
        self.assertEqual(float(row["previous_period_sales"]), 1800.0)

    def test_by_sales_group_missing_dates_returns_400(self):
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, {"current_start_date": "2026-03-01"})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_by_sales_group_invalid_date_returns_400(self):
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params(current_start_date="not-a-date"))
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_by_sales_group_no_data_returns_empty(self):
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, {
            "current_start_date": "2020-01-01", "current_end_date": "2020-01-31",
            "previous_start_date": "2019-12-01", "previous_end_date": "2019-12-31",
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 0)

    def test_by_state_returns_200(self):
        url = reverse("order-transaction:ot-sales-comparison-by-state")
        response = self.client.get(url, self._params())
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_by_state_response_shape(self):
        url = reverse("order-transaction:ot-sales-comparison-by-state")
        response = self.client.get(url, self._params())
        self.assertEqual(len(response.data), 1)
        row = response.data[0]
        self.assertIn("state", row)
        self._assert_comparison_fields(row)

    def test_by_state_correct_values(self):
        url = reverse("order-transaction:ot-sales-comparison-by-state")
        response = self.client.get(url, self._params())
        row = response.data[0]
        self.assertEqual(row["state"], "CA")
        self.assertEqual(float(row["current_period_sales"]), 3000.0)
        self.assertEqual(float(row["previous_period_sales"]), 1800.0)

    def test_by_material_returns_200(self):
        url = reverse("order-transaction:ot-sales-comparison-by-material")
        response = self.client.get(url, self._params())
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_by_material_is_paginated(self):
        url = reverse("order-transaction:ot-sales-comparison-by-material")
        response = self.client.get(url, self._params())
        self.assertIn("results", response.data)
        self.assertIn("count", response.data)

    def test_by_material_response_shape(self):
        url = reverse("order-transaction:ot-sales-comparison-by-material")
        response = self.client.get(url, self._params())
        results = response.data["results"]
        self.assertEqual(len(results), 1)
        row = results[0]
        self.assertIn("mat_nbr", row)
        self.assertIn("material_name", row)
        self._assert_comparison_fields(row)

    def test_by_material_correct_values(self):
        url = reverse("order-transaction:ot-sales-comparison-by-material")
        response = self.client.get(url, self._params())
        row = response.data["results"][0]
        self.assertEqual(row["mat_nbr"], self.material.mat_nbr)
        self.assertEqual(float(row["current_period_sales"]), 3000.0)

    def test_by_material_pagination_limit(self):
        url = reverse("order-transaction:ot-sales-comparison-by-material")
        response = self.client.get(url, self._params(limit=1, offset=0))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("count", response.data)
        self.assertIn("results", response.data)

    def test_by_customer_returns_200(self):
        url = reverse("order-transaction:ot-sales-comparison-by-customer")
        response = self.client.get(url, self._params())
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_by_customer_is_paginated(self):
        url = reverse("order-transaction:ot-sales-comparison-by-customer")
        response = self.client.get(url, self._params())
        self.assertIn("results", response.data)
        self.assertIn("count", response.data)

    def test_by_customer_response_shape(self):
        url = reverse("order-transaction:ot-sales-comparison-by-customer")
        response = self.client.get(url, self._params())
        results = response.data["results"]
        self.assertEqual(len(results), 1)
        row = results[0]
        self.assertIn("cust_corp_chain_nbr", row)
        self.assertIn("customer_name", row)
        self._assert_comparison_fields(row)

    def test_by_customer_correct_values(self):
        url = reverse("order-transaction:ot-sales-comparison-by-customer")
        response = self.client.get(url, self._params())
        row = response.data["results"][0]
        self.assertEqual(row["cust_corp_chain_nbr"], self.corp_chain.cust_corp_chain_nbr)
        self.assertEqual(float(row["current_period_sales"]), 3000.0)
        self.assertEqual(float(row["previous_period_sales"]), 1800.0)

    def test_by_customer_pagination_limit(self):
        url = reverse("order-transaction:ot-sales-comparison-by-customer")
        response = self.client.get(url, self._params(limit=1, offset=0))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("count", response.data)
        self.assertIn("results", response.data)


class WeeklySalesTimelineIntegrationTest(MVAPITestCase):
    """Integration tests for GET order-transaction/sales-timeline/"""

    def setUp(self):
        self.plant = TestDataFactory.create_plant()
        self.material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            for days_ago in [7, 14, 21]:
                TestDataFactory.create_order_transaction(
                    material=self.material,
                    plant=self.plant,
                    sales_amount=500.00,
                    total_order_qty=100,
                    total_shipped_qty=90,
                    ord_created_date=date.today() - timedelta(days=days_ago),
                )
        refresh_order_transaction_integration_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)

    def test_returns_200(self):
        url = reverse('order-transaction:sales-timeline')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_response_is_list(self):
        url = reverse('order-transaction:sales-timeline')
        response = self.client.get(url)
        self.assertIsInstance(response.data, list)

    def test_response_fields(self):
        url = reverse('order-transaction:sales-timeline')
        response = self.client.get(url)
        self.assertGreater(len(response.data), 0)
        for row in response.data:
            self.assertIn('week_start', row)
            self.assertIn('sales_amount', row)
            self.assertIn('total_order_qty', row)
            self.assertIn('total_shipped_qty', row)

    def test_no_query_params_required(self):
        """Endpoint requires no params — global filters are optional."""
        url = reverse('order-transaction:sales-timeline')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class WeeklySalesBySalesGroupIntegrationTest(MVAPITestCase):
    """Integration tests for GET order-transaction/weekly-sales-by-sales-group/"""

    # current_week = Monday 2026-03-16, so 4-week window: 2026-02-23 to 2026-03-22
    CURRENT_WEEK = date(2026, 3, 16)
    # previous_week = Monday 2026-02-16, so 4-week window: 2026-01-26 to 2026-02-22
    PREVIOUS_WEEK = date(2026, 2, 16)

    def _params(self, **extra):
        return {
            "current_week": self.CURRENT_WEEK.isoformat(),
            "previous_week": self.PREVIOUS_WEEK.isoformat(),
            **extra,
        }

    def setUp(self):
        self.material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # 3 orders in current window, sales_group=PGEN
            for day in [date(2026, 3, 2), date(2026, 3, 9), date(2026, 3, 16)]:
                TestDataFactory.create_order_transaction(
                    material=self.material,
                    sales_amount=1000.00,
                    total_order_qty=100,
                    total_shipped_qty=90,
                    sales_group="PGEN",
                    ord_created_date=day,
                )

            # 2 orders in previous window, sales_group=PGEN
            for day in [date(2026, 2, 2), date(2026, 2, 9)]:
                TestDataFactory.create_order_transaction(
                    material=self.material,
                    sales_amount=600.00,
                    total_order_qty=60,
                    total_shipped_qty=50,
                    sales_group="PGEN",
                    ord_created_date=day,
                )

    def test_returns_200(self):
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url, self._params())
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_missing_both_params_returns_400(self):
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_missing_previous_week_returns_400(self):
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url, {"current_week": self.CURRENT_WEEK.isoformat()})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_missing_current_week_returns_400(self):
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url, {"previous_week": self.PREVIOUS_WEEK.isoformat()})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_invalid_date_format_returns_400(self):
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url, self._params(current_week="not-a-date"))
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_response_structure(self):
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url, self._params())
        self.assertIsInstance(response.data, list)
        self.assertGreater(len(response.data), 0)
        week = response.data[0]
        self.assertIn("week_start", week)
        self.assertIn("sales", week)
        self.assertIsInstance(week["sales"], list)
        sale = week["sales"][0]
        for field in ("sales_group", "sales_amount", "total_order_qty", "total_shipped_qty"):
            self.assertIn(field, sale)

    def test_returns_one_entry_per_week(self):
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url, self._params())
        week_starts = [w["week_start"] for w in response.data]
        self.assertEqual(len(week_starts), len(set(week_starts)))

    def test_current_window_values_correct(self):
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url, self._params())
        # 2026-03-02, 2026-03-09, 2026-03-16 each have 1 order of 1000
        current_weeks = [w for w in response.data if w["week_start"] >= date(2026, 2, 23)]
        total_sales = sum(float(s["sales_amount"]) for w in current_weeks for s in w["sales"])
        self.assertAlmostEqual(total_sales, 3000.0)

    def test_previous_window_values_correct(self):
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url, self._params())
        # 2026-02-02 and 2026-02-09 each have 1 order of 600
        previous_weeks = [w for w in response.data if w["week_start"] < date(2026, 2, 23)]
        total_sales = sum(float(s["sales_amount"]) for w in previous_weeks for s in w["sales"])
        self.assertAlmostEqual(total_sales, 1200.0)

    def test_no_data_outside_windows(self):
        """Orders outside both 4-week windows should not appear."""
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                sales_amount=9999.00,
                total_order_qty=999,
                total_shipped_qty=999,
                sales_group="OUTSIDE",
                ord_created_date=date(2025, 1, 1),  # far outside both windows
            )
        url = reverse("order-transaction:weekly-sales-by-sales-group")
        response = self.client.get(url, self._params())
        all_sales_groups = [s["sales_group"] for w in response.data for s in w["sales"]]
        self.assertNotIn("OUTSIDE", all_sales_groups)


class FailToSupplyIntegrationTests(BaseTestCase):
    """Integration tests for the fail-to-supply/materials/ endpoint."""

    def setUp(self):
        self.client = TenantAPIClient()
        self.plant = TestDataFactory.create_plant()
        self.today = date.today()
        self.url = reverse("order-transaction:fail-to-supply-materials")

    def _create_ot(self, material=None, sales_group='PRxO', lines_ordered=10,
                   adj_lines=8, adj_qty=800.0, order_qty=1000, shipped_qty=900,
                   sales_amount=5000.0, days_ago=None, contract_name=None):
        if days_ago is None:
            days_ago = 5
        if material is None:
            material = TestDataFactory.create_material()
        with MaterializedViewTestHelper.defer_auto_refresh():
            return TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                sales_group=sales_group,
                total_order_qty=order_qty,
                total_shipped_qty=shipped_qty,
                sales_amount=sales_amount,
                ord_created_date=self.today - timedelta(days=days_ago),
                fts_lines_ordered=lines_ordered,
                fts_adj_lines_incl_72_hours=adj_lines,
                fts_adj_qty_incl_72_hours=adj_qty,
                contract_name=contract_name or 'PMGN',
            )

    def test_returns_200_with_expected_structure(self):
        mat = TestDataFactory.create_material(
            xplant_mat_stat='AC',
            forecast_qty_7day=10,
        )
        self._create_ot(material=mat, order_qty=100, shipped_qty=70, adj_qty=60.0)

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('count', response.data)
        self.assertIn('results', response.data)
        result = response.data['results'][0]
        for key in (
            'mat_nbr', 'material_name', 'material_ndc',
            'outbound_fill_rate', 'unfilled_quantity', 'omits_qty', 'omits_qty_last_month',
            'sales_amount', 'sales_qty', 'total_demand',
            'prxo_service_level', 'pharmagen_service_level',
            'material_status', 'contract_type', 'forecast_qty_28day',
        ):
            self.assertIn(key, result)
        for trend_key in (
            'prxo_service_level_trend', 'pharmagen_service_level_trend',
            'total_service_level_trend', 'fill_rate_trend',
        ):
            self.assertNotIn(trend_key, result)
        self.assertEqual(result['material_status'], 'AC')
        self.assertEqual(result['forecast_qty_28day'], 40)
        self.assertAlmostEqual(result['outbound_fill_rate'], 70.0, places=1)
        self.assertEqual(result['unfilled_quantity'], 30)
        self.assertEqual(result['total_demand'], 100)
        self.assertEqual(result['sales_qty'], 70)

    def test_default_window_includes_last_90_days(self):
        mat = TestDataFactory.create_material()
        self._create_ot(material=mat, sales_amount=100.0, days_ago=60)

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)

    def test_date_filter_excludes_out_of_range_transactions(self):
        mat = TestDataFactory.create_material()
        self._create_ot(material=mat, sales_amount=9999.0, days_ago=60)

        from_date = self.today.replace(day=1).isoformat()
        to_date = self.today.isoformat()
        response = self.client.get(self.url, {'from_date': from_date, 'to_date': to_date})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 0)

    def test_invalid_date_returns_400(self):
        response = self.client.get(self.url, {'from_date': 'not-a-date'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_pagination_limit_offset(self):
        for _ in range(5):
            self._create_ot()

        response_p1 = self.client.get(self.url, {'limit': 2, 'offset': 0})
        response_p2 = self.client.get(self.url, {'limit': 2, 'offset': 2})

        self.assertEqual(response_p1.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response_p1.data['results']), 2)
        ids_p1 = {r['mat_nbr'] for r in response_p1.data['results']}
        ids_p2 = {r['mat_nbr'] for r in response_p2.data['results']}
        self.assertTrue(ids_p1.isdisjoint(ids_p2))

    def test_default_ordering_lowest_outbound_fill_rate_first(self):
        mat_low = TestDataFactory.create_material()
        mat_high = TestDataFactory.create_material()
        self._create_ot(material=mat_low, order_qty=100, shipped_qty=20)
        self._create_ot(material=mat_high, order_qty=100, shipped_qty=90)

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        rates = [r['outbound_fill_rate'] for r in response.data['results']]
        self.assertEqual(rates, sorted(rates))

    def test_ordering_by_sales_amount_desc(self):
        mat_a = TestDataFactory.create_material()
        mat_b = TestDataFactory.create_material()
        self._create_ot(material=mat_a, sales_amount=100.0)
        self._create_ot(material=mat_b, sales_amount=9999.0)

        response = self.client.get(self.url, {'ordering': '-sales_amount'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        amounts = [float(r['sales_amount']) for r in response.data['results']]
        self.assertEqual(amounts, sorted(amounts, reverse=True))

    def test_ordering_by_omits_qty_desc(self):
        mat_a = TestDataFactory.create_material()
        mat_b = TestDataFactory.create_material()
        self._create_ot(material=mat_a, order_qty=100, adj_qty=90.0)   # omits = 10
        self._create_ot(material=mat_b, order_qty=100, adj_qty=10.0)   # omits = 90

        response = self.client.get(self.url, {'ordering': '-omits_qty'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        omits = [float(r['omits_qty']) for r in response.data['results']]
        self.assertEqual(omits, sorted(omits, reverse=True))

    def test_invalid_ordering_returns_400(self):
        response = self.client.get(self.url, {'ordering': 'invalid_field'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_prxo_service_level_only_counts_prxo_rows(self):
        mat = TestDataFactory.create_material()
        self._create_ot(material=mat, sales_group='PRxO', lines_ordered=10, adj_lines=8)
        self._create_ot(material=mat, sales_group='PGEN', lines_ordered=20, adj_lines=5)

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertAlmostEqual(response.data['results'][0]['prxo_service_level'], 80.0, places=1)

    def test_pharmagen_service_level_only_counts_pgen_rows(self):
        mat = TestDataFactory.create_material()
        self._create_ot(material=mat, sales_group='PRxO', lines_ordered=10, adj_lines=8)
        self._create_ot(material=mat, sales_group='PGEN', lines_ordered=20, adj_lines=10)

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertAlmostEqual(response.data['results'][0]['pharmagen_service_level'], 50.0, places=1)


class FailToSupplyPlantIntegrationTests(BaseTestCase):
    """Integration tests for the fail-to-supply/materials/<mat_nbr>/plants/ endpoint."""

    def setUp(self):
        self.client = TenantAPIClient()
        self.material = TestDataFactory.create_material()
        self.plant_a = TestDataFactory.create_plant()
        self.plant_b = TestDataFactory.create_plant()
        self.today = date.today()

    def _url(self, mat_nbr=None):
        return reverse('order-transaction:fail-to-supply-plants',
                       kwargs={'mat_nbr': mat_nbr or self.material.mat_nbr})

    def _create_ot(self, plant=None, sales_group='PRxO', lines_ordered=10,
                   adj_lines=8, adj_qty=800.0, order_qty=1000, shipped_qty=900,
                   days_ago=None):
        if days_ago is None:
            days_ago = min(5, self.today.day - 1)
        with MaterializedViewTestHelper.defer_auto_refresh():
            return TestDataFactory.create_order_transaction(
                material=self.material,
                plant=plant or self.plant_a,
                sales_group=sales_group,
                total_order_qty=order_qty,
                total_shipped_qty=shipped_qty,
                ord_created_date=self.today - timedelta(days=days_ago),
                fts_lines_ordered=lines_ordered,
                fts_adj_lines_incl_72_hours=adj_lines,
                fts_adj_qty_incl_72_hours=adj_qty,
            )

    def test_returns_200_with_expected_structure(self):
        self._create_ot()

        response = self.client.get(self._url())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('count', response.data)
        self.assertIn('results', response.data)
        result = response.data['results'][0]
        for key in ('plant_nbr', 'plant_name', 'prxo_missed_lines', 'pgen_missed_lines',
                    'total_missed_lines', 'total_missed_lines_pct', 'outbound_fill_rate',
                    'service_level', 'omit_qty', 'demand_qty', 'ordered_lines'):
            self.assertIn(key, result)

    def test_numeric_fields_are_not_strings(self):
        self._create_ot()

        response = self.client.get(self._url())

        result = response.data['results'][0]
        for field in ('omit_qty', 'outbound_fill_rate', 'service_level', 'total_missed_lines_pct'):
            self.assertIsInstance(result[field], (int, float))

    def test_scoped_to_material_in_path(self):
        other_material = TestDataFactory.create_material()
        self._create_ot(plant=self.plant_a)
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=other_material,
                plant=self.plant_b,
                ord_created_date=self.today - timedelta(days=min(5, self.today.day - 1)),
            )

        response = self.client.get(self._url(self.material.mat_nbr))

        self.assertEqual(response.data['count'], 1)

    def test_date_filter_excludes_out_of_range(self):
        self._create_ot(days_ago=60)

        from_date = self.today.replace(day=1).isoformat()
        to_date = self.today.isoformat()
        response = self.client.get(self._url(), {'from_date': from_date, 'to_date': to_date})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 0)

    def test_invalid_date_returns_400(self):
        response = self.client.get(self._url(), {'from_date': 'not-a-date'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_default_ordering_by_total_missed_lines_desc(self):
        self._create_ot(plant=self.plant_a, lines_ordered=10, adj_lines=2)  # missed = 8
        self._create_ot(plant=self.plant_b, lines_ordered=10, adj_lines=8)  # missed = 2

        response = self.client.get(self._url())

        missed = [r['total_missed_lines'] for r in response.data['results']]
        self.assertEqual(missed, sorted(missed, reverse=True))

    def test_ordering_by_total_lines_ordered(self):
        self._create_ot(plant=self.plant_a, lines_ordered=5)
        self._create_ot(plant=self.plant_b, lines_ordered=20)

        response = self.client.get(self._url(), {'ordering': '-total_lines_ordered'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        ordered = [r['ordered_lines'] for r in response.data['results']]
        self.assertEqual(ordered, sorted(ordered, reverse=True))

    def test_filter_by_total_missed_lines_min(self):
        self._create_ot(plant=self.plant_a, lines_ordered=10, adj_lines=8)  # missed = 2
        self._create_ot(plant=self.plant_b, lines_ordered=10, adj_lines=2)  # missed = 8

        response = self.client.get(self._url(), {'total_missed_lines_min': 5})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        self.assertEqual(response.data['results'][0]['total_missed_lines'], 8)

    def test_filter_by_service_level_min(self):
        self._create_ot(plant=self.plant_a, lines_ordered=10, adj_lines=9)  # SL = 90%
        self._create_ot(plant=self.plant_b, lines_ordered=10, adj_lines=5)  # SL = 50%

        response = self.client.get(self._url(), {'service_level_min': 80})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 1)
        self.assertGreaterEqual(response.data['results'][0]['service_level'], 80)

    def test_pagination(self):
        self._create_ot(plant=self.plant_a)
        self._create_ot(plant=self.plant_b)

        response = self.client.get(self._url(), {'limit': 1, 'offset': 0})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['count'], 2)


class OTFederalCsIndFilterTest(MVAPITestCase):
    """Integration tests for the federal_cs_ind query param filter on OT views."""

    CURRENT_START = "2026-03-01"
    CURRENT_END = "2026-03-17"
    PREVIOUS_START = "2026-02-01"
    PREVIOUS_END = "2026-02-17"

    def _params(self, **extra):
        return {
            "current_start_date": self.CURRENT_START,
            "current_end_date": self.CURRENT_END,
            "previous_start_date": self.PREVIOUS_START,
            "previous_end_date": self.PREVIOUS_END,
            **extra,
        }

    def setUp(self):
        self.mat_cs2 = TestDataFactory.create_material(federal_cs_ind='2')
        self.mat_cs3 = TestDataFactory.create_material(federal_cs_ind='3')
        self.mat_none = TestDataFactory.create_material(federal_cs_ind=None)
        self.customer = TestDataFactory.create_customer(state="CA")
        self.corp_chain = TestDataFactory.create_customer_corp_chain()

        with MaterializedViewTestHelper.defer_auto_refresh():
            for mat in [self.mat_cs2, self.mat_cs3, self.mat_none]:
                for day in [5, 10, 15]:
                    TestDataFactory.create_order_transaction(
                        material=mat,
                        cust_nbr=self.customer,
                        cust_corp_chain_nbr=self.corp_chain,
                        sales_amount=1000.00,
                        total_order_qty=100,
                        total_shipped_qty=90,
                        sales_group="PGEN",
                        ord_created_date=date(2026, 3, day),
                    )
                for day in [5, 10, 15]:
                    TestDataFactory.create_order_transaction(
                        material=mat,
                        cust_nbr=self.customer,
                        cust_corp_chain_nbr=self.corp_chain,
                        sales_amount=600.00,
                        total_order_qty=60,
                        total_shipped_qty=50,
                        sales_group="PGEN",
                        ord_created_date=date(2026, 2, day),
                    )

    def test_by_sales_group_filters_single_value(self):
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params(federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(float(response.data[0]['current_period_sales']), 3000.0)

    def test_by_sales_group_no_filter_returns_all(self):
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(float(response.data[0]['current_period_sales']), 9000.0)

    def test_by_state_filters_comma_separated(self):
        url = reverse("order-transaction:ot-sales-comparison-by-state")
        response = self.client.get(url, self._params(federal_cs_ind='2,3'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(float(response.data[0]['current_period_sales']), 6000.0)

    def test_by_material_filters(self):
        url = reverse("order-transaction:ot-sales-comparison-by-material")
        response = self.client.get(url, self._params(federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['mat_nbr'], self.mat_cs2.mat_nbr)

    def test_by_customer_filters(self):
        url = reverse("order-transaction:ot-sales-comparison-by-customer")
        response = self.client.get(url, self._params(federal_cs_ind='3'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        self.assertEqual(float(results[0]['current_period_sales']), 3000.0)

    def test_weekly_sales_timeline_filters(self):
        with MaterializedViewTestHelper.defer_auto_refresh():
            for days_ago in [7, 14, 21]:
                TestDataFactory.create_order_transaction(
                    material=self.mat_cs2,
                    cust_nbr=self.customer,
                    cust_corp_chain_nbr=self.corp_chain,
                    sales_amount=500.00,
                    total_order_qty=100,
                    total_shipped_qty=90,
                    sales_group="PGEN",
                    ord_created_date=date.today() - timedelta(days=days_ago),
                )
                TestDataFactory.create_order_transaction(
                    material=self.mat_none,
                    cust_nbr=self.customer,
                    cust_corp_chain_nbr=self.corp_chain,
                    sales_amount=300.00,
                    total_order_qty=60,
                    total_shipped_qty=50,
                    sales_group="PGEN",
                    ord_created_date=date.today() - timedelta(days=days_ago),
                )
        refresh_order_transaction_integration_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)

        url = reverse("order-transaction:sales-timeline")

        response_all = self.client.get(url)
        response_filtered = self.client.get(url, {'federal_cs_ind': '2'})

        self.assertEqual(response_all.status_code, status.HTTP_200_OK)
        self.assertEqual(response_filtered.status_code, status.HTTP_200_OK)

        total_all = sum(float(r['sales_amount']) for r in response_all.data)
        total_filtered = sum(float(r['sales_amount']) for r in response_filtered.data)
        self.assertGreater(total_all, total_filtered)

    def test_nonexistent_value_returns_empty(self):
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params(federal_cs_ind='99'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 0)

    def test_exclude_single_value(self):
        """exclude_federal_cs_ind=2 should return data for cs3 and None materials only."""
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params(exclude_federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(float(response.data[0]['current_period_sales']), 6000.0)

    def test_exclude_comma_separated(self):
        """exclude_federal_cs_ind=2,3 should return data for None material only."""
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params(exclude_federal_cs_ind='2,3'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(float(response.data[0]['current_period_sales']), 3000.0)

    def test_include_and_exclude_combined(self):
        """federal_cs_ind=2,3 + exclude_federal_cs_ind=3 should return only cs2."""
        url = reverse("order-transaction:ot-sales-comparison-by-sales-group")
        response = self.client.get(url, self._params(
            federal_cs_ind='2,3', exclude_federal_cs_ind='3'
        ))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(float(response.data[0]['current_period_sales']), 3000.0)


class ManageSalesFederalCsIndFilterTest(MVAPITestCase):
    """
    Integration tests for the federal_cs_ind / exclude_federal_cs_ind query params on the
    90-day Manage Sales endpoints (state-sales, contract-sales, material-with-sales-group-sales).
    These flow through the global material-filter resolver (get_filtered_material_subquery).
    """

    def setUp(self):
        self.plant = TestDataFactory.create_plant()
        self.customer = TestDataFactory.create_customer(state="California")
        # Distinct quantities per CS schedule so assertions pinpoint which materials survive filtering.
        self.mat_cs2 = TestDataFactory.create_material(federal_cs_ind='2')
        self.mat_cs3 = TestDataFactory.create_material(federal_cs_ind='3')
        self.mat_none = TestDataFactory.create_material(federal_cs_ind=None)
        with MaterializedViewTestHelper.defer_auto_refresh():
            for mat, qty in [(self.mat_cs2, 100), (self.mat_cs3, 50), (self.mat_none, 30)]:
                TestDataFactory.create_order_transaction(
                    material=mat,
                    plant=self.plant,
                    cust_nbr=self.customer,
                    total_shipped_qty=qty,
                    ord_created_date=date.today(),
                    contract_name="Contract A",
                    sales_group="PGEN",
                )
        refresh_order_transaction_integration_mvs(ORDER_TRANSACTION_MANAGE_SALES_MVS)

    def test_state_sales_include_single_value(self):
        url = reverse('order-transaction:state-sales')
        response = self.client.get(url, {'federal_cs_ind': '2'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['name'], 'California')
        self.assertEqual(response.data[0]['total_sales_qty'], 100)

    def test_state_sales_include_comma_separated(self):
        url = reverse('order-transaction:state-sales')
        response = self.client.get(url, {'federal_cs_ind': '2,3'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data[0]['total_sales_qty'], 150)

    def test_state_sales_exclude(self):
        url = reverse('order-transaction:state-sales')
        response = self.client.get(url, {'exclude_federal_cs_ind': '2'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data[0]['total_sales_qty'], 80)

    def test_state_sales_no_filter_returns_all(self):
        url = reverse('order-transaction:state-sales')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data[0]['total_sales_qty'], 180)

    def test_contract_sales_include_and_exclude(self):
        url = reverse('order-transaction:contract-sales')

        included = self.client.get(url, {'federal_cs_ind': '2', 'limit': 10})
        self.assertEqual(included.status_code, status.HTTP_200_OK)
        self.assertEqual(included.data['results'][0]['total_sales_qty'], 100)

        excluded = self.client.get(url, {'exclude_federal_cs_ind': '2', 'limit': 10})
        self.assertEqual(excluded.status_code, status.HTTP_200_OK)
        self.assertEqual(excluded.data['results'][0]['total_sales_qty'], 80)

    def test_material_with_sales_group_include_and_exclude(self):
        url = reverse('order-transaction:material-with-sales-group-sales')

        included = self.client.get(url, {'federal_cs_ind': '2', 'limit': 10})
        self.assertEqual(included.status_code, status.HTTP_200_OK)
        self.assertEqual(len(included.data['results']), 1)
        self.assertEqual(included.data['results'][0]['mat_nbr'], self.mat_cs2.mat_nbr)

        excluded = self.client.get(url, {'exclude_federal_cs_ind': '2', 'limit': 10})
        self.assertEqual(excluded.status_code, status.HTTP_200_OK)
        excluded_mat_nbrs = {r['mat_nbr'] for r in excluded.data['results']}
        self.assertEqual(excluded_mat_nbrs, {self.mat_cs3.mat_nbr, self.mat_none.mat_nbr})


class MaterialPlantCustomersIntegrationTests(BaseTestCase):
    """Integration tests for inventory customer impact drilldown."""

    INVENTORY_FIELDS = (
        'cust_nbr', 'customer_name', 'cust_corp_chain_nbr', 'cust_corp_chain_name',
        'order_qty', 'shipped_qty', 'omit_qty', 'imperfect_lines', 'sales_amount',
        'outbound_fill_rate',
    )
    REMOVED_FIELDS = (
        'prxo_missed_lines', 'pgen_missed_lines', 'total_missed_lines',
        'total_missed_lines_pct', 'service_level', 'ordered_lines', 'demand_qty',
    )

    def setUp(self):
        self.client = TenantAPIClient()
        self.material = TestDataFactory.create_material()
        self.other_material = TestDataFactory.create_material()
        self.plant_a = TestDataFactory.create_plant()
        self.plant_b = TestDataFactory.create_plant()
        self.customer_a = TestDataFactory.create_customer(cust_nbr="CUST9001", name="Customer A")
        self.customer_b = TestDataFactory.create_customer(cust_nbr="CUST9002", name="Customer B")
        self.corp_chain_a = TestDataFactory.create_customer_corp_chain(name="Chain A")
        self.corp_chain_b = TestDataFactory.create_customer_corp_chain(name="Chain B")
        self.today = date.today()

    def _url(self, mat_nbr=None, plant_nbr=None):
        return reverse(
            'order-transaction:material-plant-customers',
            kwargs={
                'mat_nbr': mat_nbr or self.material.mat_nbr,
                'plant_nbr': plant_nbr or self.plant_a.plant_nbr,
            },
        )

    def _create_ot(self, customer=None, corp_chain=None, plant=None, material=None,
                   order_qty=1000, shipped_qty=900, adj_qty=800.0,
                   sales_amount=5000.0, imperfect=0, days_ago=None):
        if days_ago is None:
            days_ago = min(5, self.today.day - 1)
        with MaterializedViewTestHelper.defer_auto_refresh():
            return TestDataFactory.create_order_transaction(
                material=material or self.material,
                plant=plant or self.plant_a,
                cust_nbr=customer or self.customer_a,
                cust_corp_chain_nbr=corp_chain or self.corp_chain_a,
                total_order_qty=order_qty,
                total_shipped_qty=shipped_qty,
                sales_amount=sales_amount,
                ord_created_date=self.today - timedelta(days=days_ago),
                fts_adj_qty_incl_72_hours=adj_qty,
                f_total_imperfect=imperfect,
            )

    def test_returns_jira_aligned_fields_only(self):
        self._create_ot()

        response = self.client.get(self._url())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        result = response.data['results'][0]
        self.assertEqual(set(result.keys()), set(self.INVENTORY_FIELDS))
        for field in self.REMOVED_FIELDS:
            self.assertNotIn(field, result)

    def test_scoped_to_material_and_plant(self):
        self._create_ot(customer=self.customer_a, material=self.material, plant=self.plant_a)
        self._create_ot(customer=self.customer_b, material=self.material, plant=self.plant_b)
        self._create_ot(customer=self.customer_b, material=self.other_material, plant=self.plant_a)

        response = self.client.get(self._url())

        self.assertEqual(response.data['count'], 1)
        self.assertEqual(response.data['results'][0]['cust_nbr'], self.customer_a.cust_nbr)

    def test_groups_multiple_rows_by_customer(self):
        self._create_ot(order_qty=100, shipped_qty=70, adj_qty=60.0, sales_amount=1000.0, imperfect=1)
        self._create_ot(order_qty=200, shipped_qty=180, adj_qty=150.0, sales_amount=2000.0, imperfect=0)

        response = self.client.get(self._url())

        result = response.data['results'][0]
        self.assertEqual(result['order_qty'], 300)
        self.assertEqual(result['shipped_qty'], 250)
        self.assertAlmostEqual(float(result['omit_qty']), 90.0, places=1)
        self.assertEqual(result['imperfect_lines'], 1)
        self.assertEqual(float(result['sales_amount']), 3000.0)

    def test_default_ordering_by_omit_qty_desc(self):
        self._create_ot(customer=self.customer_a, order_qty=100, adj_qty=90.0)
        self._create_ot(customer=self.customer_b, corp_chain=self.corp_chain_b, order_qty=100, adj_qty=20.0)

        response = self.client.get(self._url())

        omits = [float(r['omit_qty']) for r in response.data['results']]
        self.assertEqual(omits, sorted(omits, reverse=True))

    def test_filter_by_omit_qty_min(self):
        self._create_ot(customer=self.customer_a, order_qty=100, adj_qty=90.0)
        self._create_ot(customer=self.customer_b, corp_chain=self.corp_chain_b, order_qty=100, adj_qty=20.0)

        response = self.client.get(self._url(), {'omit_qty_min': 50})

        self.assertEqual(response.data['count'], 1)
        self.assertEqual(response.data['results'][0]['cust_nbr'], self.customer_b.cust_nbr)

    def test_filter_by_imperfect_lines_min(self):
        self._create_ot(customer=self.customer_a, imperfect=0)
        self._create_ot(customer=self.customer_b, corp_chain=self.corp_chain_b, imperfect=1)

        response = self.client.get(self._url(), {'imperfect_lines_min': 1})

        self.assertEqual(response.data['count'], 1)
        self.assertEqual(response.data['results'][0]['cust_nbr'], self.customer_b.cust_nbr)

    def test_corp_chain_filter_applies(self):
        self._create_ot(customer=self.customer_a, corp_chain=self.corp_chain_a)
        self._create_ot(customer=self.customer_b, corp_chain=self.corp_chain_b)

        response = self.client.get(
            self._url(),
            {'cust_corp_chain': self.corp_chain_b.cust_corp_chain_nbr},
        )

        self.assertEqual(response.data['count'], 1)
        self.assertEqual(response.data['results'][0]['cust_nbr'], self.customer_b.cust_nbr)

    def test_fail_to_supply_customer_url_removed(self):
        url = (
            f'/order-transaction/fail-to-supply/materials/{self.material.mat_nbr}'
            f'/plants/{self.plant_a.plant_nbr}/customers/'
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


class UnfilledMaterialsIntegrationTest(MVAPITestCase):
    """HTTP tests for GET /order-transaction/unfilled-materials/."""

    def setUp(self):
        super().setUp()
        self.plant = TestDataFactory.create_plant(name="UM Integration Plant")

    def _refresh_unfilled_mvs(self):
        MaterializedViewTestHelper.refresh_materialized_views([
            "order_transaction_material_90d_mv",
            "purchase_order_latest_90d_mv",
            "demand_forecast_material_plant_mv",
        ])

    def test_unfilled_materials_list_shape_pagination_and_ordering(self):
        today = date.today()
        mat_high = TestDataFactory.create_material(
            mat_nbr="UM_INT_HIGH",
            name="High Unfilled",
            ndc="99988877766",
            forecast_qty_7day=10,
            outbound_fill_rate=0.55,
        )
        mat_high.saleable_qty_on_hand = 120
        mat_high.save(update_fields=["saleable_qty_on_hand"])
        mat_low = TestDataFactory.create_material(mat_nbr="UM_INT_LOW", name="Low Unfilled")
        mat_full = TestDataFactory.create_material(mat_nbr="UM_INT_FULL", name="Full")

        arrival = today + timedelta(days=7)

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=mat_high,
                plant=self.plant,
                ord_created_date=today - timedelta(days=8),
                total_order_qty=200,
                total_shipped_qty=50,
            )
            TestDataFactory.create_order_transaction(
                material=mat_low,
                plant=self.plant,
                ord_created_date=today - timedelta(days=8),
                total_order_qty=100,
                total_shipped_qty=80,
            )
            TestDataFactory.create_order_transaction(
                material=mat_full,
                plant=self.plant,
                ord_created_date=today - timedelta(days=8),
                total_order_qty=100,
                total_shipped_qty=100,
            )
            TestDataFactory.create_update_demand_forecast(
                material=mat_high,
                plant=self.plant,
                demand_date=today - timedelta(days=1),
                on_order_qty=75,
            )
            TestDataFactory.create_purchase_order(
                po_number="UM-INT-PO",
                material=mat_high,
                plant=self.plant,
                ordered_date=today - timedelta(days=15),
                as_of_date=today - timedelta(days=3),
                anticipated_date=arrival,
                completion_date=None,
                po_line_number="001",
            )

        self._refresh_unfilled_mvs()

        url = reverse("order-transaction:unfilled-materials")
        response = self.client.get(url, {
            "ordering": "-unfilled_quantity",
            "limit": 10,
            "offset": 0,
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("results", response.data)
        self.assertIn("count", response.data)

        results = response.data["results"]
        mat_nbrs = {r["material_number"] for r in results}
        self.assertIn("UM_INT_HIGH", mat_nbrs)
        self.assertIn("UM_INT_LOW", mat_nbrs)
        self.assertNotIn("UM_INT_FULL", mat_nbrs)

        scoped = [r for r in results if r["material_number"] in {"UM_INT_HIGH", "UM_INT_LOW"}]
        self.assertEqual(scoped[0]["material_number"], "UM_INT_HIGH")
        self.assertEqual(scoped[1]["material_number"], "UM_INT_LOW")

        row = scoped[0]
        required_fields = [
            "material_number",
            "material_name",
            "ndc",
            "unfilled_quantity",
            "ordered_quantity",
            "outbound_fill_rate",
            "saleable_qty_on_hand",
            "forecast_qty_7day",
            "forecast_qty_28day",
            "next_expected_arrival_date",
            "on_order_qty",
        ]
        for field in required_fields:
            self.assertIn(field, row)

        self.assertEqual(row["material_name"], "High Unfilled")
        self.assertEqual(row["ndc"], "99988877766")
        self.assertEqual(row["ordered_quantity"], 200)
        self.assertEqual(row["unfilled_quantity"], 150)
        self.assertEqual(row["forecast_qty_7day"], 10)
        self.assertEqual(row["forecast_qty_28day"], 40)
        self.assertEqual(row["saleable_qty_on_hand"], 120)
        self.assertEqual(row["on_order_qty"], 75)
        self.assertEqual(row["next_expected_arrival_date"], arrival.isoformat())

    def test_unfilled_materials_ndc_filter(self):
        today = date.today()
        target = TestDataFactory.create_material(mat_nbr="UM_NDC_T", ndc="12345098765")
        other = TestDataFactory.create_material(mat_nbr="UM_NDC_O", ndc="00011122233")

        with MaterializedViewTestHelper.defer_auto_refresh():
            for material in (target, other):
                TestDataFactory.create_order_transaction(
                    material=material,
                    plant=self.plant,
                    ord_created_date=today - timedelta(days=4),
                    total_order_qty=40,
                    total_shipped_qty=10,
                )

        self._refresh_unfilled_mvs()

        url = reverse("order-transaction:unfilled-materials")
        response = self.client.get(url, {"ndc": "12345098765", "limit": 20})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mat_nbrs = {r["material_number"] for r in response.data["results"]}
        self.assertIn("UM_NDC_T", mat_nbrs)
        self.assertNotIn("UM_NDC_O", mat_nbrs)


class MaterialOrderQuantitiesMtdIntegrationTest(MVAPITestCase):
    """HTTP tests for GET /order-transaction/material-order-quantities-mtd/."""

    def setUp(self):
        super().setUp()
        self.plant = TestDataFactory.create_plant(name="MTD Integration Plant")
        self.today = date.today()
        self.month_start = self.today.replace(day=1)
        self.prior_month = self.month_start - timedelta(days=1)

    def test_material_order_quantities_mtd_list_shape_and_pagination(self):
        from api.material_formulary.models import MaterialFormulary

        material = TestDataFactory.create_material(
            mat_nbr="MTD_INT_1",
            name="MTD Int Material",
            ndc="99887766554",
            xplant_mat_stat="ACTIVE",
        )
        MaterialFormulary.objects.create(
            material=material,
            sales_group="WAG",
            program="WAG PRIMARY",
            contract_number="CN-INT-1",
        )
        MaterialFormulary.objects.create(
            material=material,
            sales_group="WAG",
            program="WAG SECONDARY",
            contract_number="CN-INT-2",
        )
        MaterialFormulary.objects.create(
            material=material,
            sales_group="GOVT",
            program="GOVT",
            contract_number="CN-INT-3",
        )

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=self.today,
                total_order_qty=80,
                total_shipped_qty=40,
            )
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=self.prior_month,
                total_order_qty=500,
                total_shipped_qty=500,
            )

        url = reverse("order-transaction:material-order-quantities-mtd")
        response = self.client.get(url, {
            "material": material.mat_nbr,
            "ordering": "-total_demand_mtd_units",
            "limit": 10,
            "offset": 0,
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("results", response.data)
        self.assertIn("count", response.data)
        self.assertGreaterEqual(response.data["count"], 1)

        matching = [
            r for r in response.data["results"] if r["material_number"] == "MTD_INT_1"
        ]
        self.assertEqual(len(matching), 1)
        row = matching[0]
        required_fields = [
            "material_number",
            "material_name",
            "ndc",
            "total_demand_mtd_units",
            "fill_rate_percentage",
            "material_status",
            "formulary",
        ]
        for field in required_fields:
            self.assertIn(field, row)

        self.assertEqual(row["material_name"], "MTD Int Material")
        self.assertEqual(row["ndc"], "99887766554")
        self.assertEqual(row["material_status"], "ACTIVE")
        self.assertEqual(row["total_demand_mtd_units"], 80)
        self.assertAlmostEqual(float(row["fill_rate_percentage"]), 50.0, places=2)
        self.assertEqual(row["formulary"], ["GOVT", "WAG"])

    def test_material_order_quantities_mtd_ordering(self):
        low = TestDataFactory.create_material(mat_nbr="MTD_INT_LOW")
        high = TestDataFactory.create_material(mat_nbr="MTD_INT_HIGH")

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=low,
                plant=self.plant,
                ord_created_date=self.today,
                total_order_qty=15,
                total_shipped_qty=10,
            )
            TestDataFactory.create_order_transaction(
                material=high,
                plant=self.plant,
                ord_created_date=self.today,
                total_order_qty=150,
                total_shipped_qty=100,
            )

        url = reverse("order-transaction:material-order-quantities-mtd")
        response = self.client.get(url, {
            "ordering": "-total_demand_mtd_units",
            "limit": 50,
            "offset": 0,
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        scoped = [
            r for r in response.data["results"]
            if r["material_number"] in {"MTD_INT_LOW", "MTD_INT_HIGH"}
        ]
        self.assertEqual(len(scoped), 2)
        self.assertEqual(scoped[0]["material_number"], "MTD_INT_HIGH")
        self.assertEqual(scoped[1]["material_number"], "MTD_INT_LOW")
