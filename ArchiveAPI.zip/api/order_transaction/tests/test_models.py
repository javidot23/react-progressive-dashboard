from api.order_transaction.models import OrderTransaction
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class OrderTransactionModelTest(BaseTestCase):
    def setUp(self):
        self.plant = TestDataFactory.create_plant()
        self.ar_plant = TestDataFactory.create_plant()
        self.material = TestDataFactory.create_material()
        self.customer = TestDataFactory.create_customer()

    def test_order_transaction_creation(self):
        """Test basic order transaction creation"""
        order = TestDataFactory.create_order_transaction(
            sales_doc_nbr="ORD-001",
            material=self.material,
            plant=self.plant,
            ar_plant=self.ar_plant
        )
        self.assertEqual(order.sales_doc_nbr, "ORD-001")
        self.assertFalse(order.alt_plant_serv_flg_key)

    def test_substituted_material_relationship(self):
        """Test optional substituted material relationship"""
        substituted_material = TestDataFactory.create_material()
        order = TestDataFactory.create_order_transaction(
            material=self.material,
            substituted_material=substituted_material,
            plant=self.plant
        )

        self.assertEqual(order.substituted_material, substituted_material)
        self.assertIn(order, substituted_material.substituted_order_transactions.all())

    def test_plant_relationships(self):
        """Test plant and ar_plant relationships"""
        order = TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant,
            ar_plant=self.ar_plant
        )

        self.assertEqual(order.plant, self.plant)
        self.assertEqual(order.ar_plant, self.ar_plant)
        self.assertIn(order, self.plant.order_transactions.all())
        self.assertIn(order, self.ar_plant.ar_order_transactions.all())

    def test_cascade_delete_material(self):
        """Test cascade delete when material is deleted"""
        order = TestDataFactory.create_order_transaction(
            material=self.material,
            plant=self.plant
        )
        order_id = order.id

        self.material.delete()

        self.assertFalse(OrderTransaction.objects.filter(id=order_id).exists())
