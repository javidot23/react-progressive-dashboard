from datetime import date, timedelta

from api.chargeback.models import Chargeback
from api.date_bounds import calendar_month_bounds, iso_week_bounds
from api.material.models import Material
from api.order_transaction.models import OrderTransaction
from api.order_transaction.services import OrderTransactionService
from tests.BaseTestCase import BaseTestCase, MVTestCase
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


ORDER_TRANSACTION_WEEKLY_MATERIAL_MV = ["order_transaction_weekly_material_mv"]
ORDER_TRANSACTION_WEEKLY_MV = ["order_transaction_weekly_mv"]
ORDER_TRANSACTION_WEEKLY_TOTALS_MV = ["order_transaction_weekly_totals_mv"]
ORDER_TRANSACTION_MATERIAL_MV = ["order_transaction_material_90d_mv"]
ORDER_TRANSACTION_ALT_SERVED_STATUS_MV = ["order_transaction_alt_served_status_90d_mv"]
ORDER_TRANSACTION_ALT_SERVED_COST_MV = ["order_transaction_alt_served_cost_90d_mv"]
ORDER_TRANSACTION_PLANT_MV = ["order_transaction_plant_90d_mv"]
ORDER_TRANSACTION_CONTRACT_MV = ["order_transaction_contract_90d_mv"]
ORDER_TRANSACTION_CORP_CHAIN_MV = ["order_transaction_corp_chain_90d_mv"]
ORDER_TRANSACTION_CLASS_OF_TRADE_MV = ["order_transaction_class_of_trade_material_90d_mv"]
ORDER_TRANSACTION_MATERIAL_GROUP_MV = ["order_transaction_material_group_90d_mv"]
ORDER_TRANSACTION_SALES_GROUP_MATERIAL_MV = ["order_transaction_sales_group_material_90d_mv"]
ORDER_TRANSACTION_SALES_GROUP_CORP_CHAIN_MV = ["order_transaction_sales_group_corp_chain_90d_mv"]
ORDER_TRANSACTION_STATE_MATERIAL_MV = ["order_transaction_state_material_90d_mv"]
ORDER_TRANSACTION_ALT_SERVED_CLASS_OF_TRADE_MV = [
    "order_transaction_alt_served_class_of_trade_material_90d_mv"
]
ORDER_TRANSACTION_ALT_SERVED_PLANT_MV = ["order_transaction_alt_served_plant_material_90d_mv"]
ORDER_TRANSACTION_WEEKLY_OMIT_SUMMARY_MV = ["order_transaction_weekly_omit_summary_mv"]
ORDER_TRANSACTION_ALT_SERVED_BREAKDOWN_MVS = (
    ORDER_TRANSACTION_WEEKLY_MATERIAL_MV
    + ORDER_TRANSACTION_ALT_SERVED_CLASS_OF_TRADE_MV
    + ORDER_TRANSACTION_ALT_SERVED_PLANT_MV
)
ORDER_TRANSACTION_WEEKLY_ANALYSIS_MVS = (
    ORDER_TRANSACTION_WEEKLY_MATERIAL_MV + ORDER_TRANSACTION_WEEKLY_MV
)


def refresh_order_transaction_service_mvs(view_names):
    MaterializedViewTestHelper.refresh_materialized_views(view_names)


class OrderTransactionServiceTests(MVTestCase):
    """Tests for OrderTransactionService that use materialized views."""

    @classmethod
    def setUpTestData(cls):
        """Create test data once for all test methods."""
        super().setUpTestData()
        cls.plant = TestDataFactory.create_plant(name="Main Plant")
        cls.material = TestDataFactory.create_material()
        cls.substituted_material = TestDataFactory.create_material()

    def setUp(self):
        super().setUp()

    def test_get_order_transaction_by_id(self):
        """Test retrieving order transaction by ID"""
        with MaterializedViewTestHelper.defer_auto_refresh():
            order = TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant
            )

        result = OrderTransactionService.get_order_transaction_by_id(order.id)

        self.assertEqual(result, order)

    def test_get_order_transaction_by_id_not_found(self):
        """Test retrieving non-existent order transaction"""
        result = OrderTransactionService.get_order_transaction_by_id(99999)

        self.assertIsNone(result)

    def test_get_substituted_and_alt_served_material_count_by_plant(self):
        """
        Test plant substitution statistics - percentages based on distinct materials, not orders.

        This test verifies that:
        1. Percentages are calculated as % of distinct materials (products), not % of orders
        2. Multiple orders for the same material are counted as one material
        3. A material is counted as having substitution/alt serve if ANY order for that material has it
        """
        # Create additional materials for testing
        material2 = TestDataFactory.create_material()
        material3 = TestDataFactory.create_material()
        material4 = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant
            )

            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant
            )

            TestDataFactory.create_order_transaction(
                material=material2,
                substituted_material=self.substituted_material,
                plant=self.plant
            )

            TestDataFactory.create_order_transaction(
                material=material2,
                substituted_material=self.substituted_material,
                plant=self.plant
            )

            TestDataFactory.create_order_transaction(
                material=material3,
                plant=self.plant,
                alt_plant_serv_flg_key=True,
                alt_serve_type=OrderTransaction.AltServeTypes.AUTO
            )

            TestDataFactory.create_order_transaction(
                material=material4,
                substituted_material=self.substituted_material,
                plant=self.plant,
                alt_plant_serv_flg_key=True,
                alt_serve_type=OrderTransaction.AltServeTypes.MANUAL
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_PLANT_MV)

        result = OrderTransactionService.get_substituted_and_alt_served_material_count_by_plant()

        plant_stats = result.order_by('plant__name').first()

        self.assertEqual(plant_stats['total_materials'], 4)

        self.assertEqual(plant_stats['materials_with_substitution'], 2)

        self.assertEqual(plant_stats['materials_with_alt_serve'], 2)

        # Percentages: 2/4 = 50% for both substitution and alt serve
        self.assertAlmostEqual(plant_stats['substituted_percent'], 50.0, places=1)
        self.assertAlmostEqual(plant_stats['alt_served_percent'], 50.0, places=1)

        self.assertEqual(plant_stats['total_orders'], 0)  # No longer meaningful, set to 0
        self.assertEqual(plant_stats['substituted_count'], 2)  # Now represents material count
        self.assertEqual(plant_stats['alt_served_count'], 2)  # Now represents material count

    def test_get_material_sales(self):
        """Test material sales retrieval"""
        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders for materials
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=150,
                ord_created_date=date.today()
            )
            TestDataFactory.create_order_transaction(
                material=self.substituted_material,
                plant=self.plant,
                total_shipped_qty=200,
                ord_created_date=date.today()
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_MATERIAL_MV)

        result = OrderTransactionService.get_material_sales()

        # Check if materials are sorted by total sales quantity
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['name'], self.substituted_material.name)
        self.assertEqual(result[0]['total_sales_qty'], 200)
        self.assertEqual(result[1]['name'], self.material.name)
        self.assertEqual(result[1]['total_sales_qty'], 150)

    def test_get_contract_sales(self):
        """Test contract sales retrieval"""
        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create contract orders
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=300,
                ord_created_date=date.today(),
                contract_name="Contract A"
            )
            TestDataFactory.create_order_transaction(
                material=self.substituted_material,
                plant=self.plant,
                total_shipped_qty=400,
                ord_created_date=date.today(),
                contract_name="Contract B"
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_CONTRACT_MV)

        result = OrderTransactionService.get_contract_sales()

        # Check if contracts are sorted by total sales quantity
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['name'], 'Contract B')
        self.assertEqual(result[0]['total_sales_qty'], 400)
        self.assertEqual(result[1]['name'], 'Contract A')
        self.assertEqual(result[1]['total_sales_qty'], 300)

    def test_get_corporate_chain_sales(self):
        """Test corporate chain sales retrieval"""
        # Create corporate chain orders
        corp_chain = TestDataFactory.create_customer_corp_chain(name="Corporate Chain A")
        corp_chain_b = TestDataFactory.create_customer_corp_chain(name="Corporate Chain B")
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=500,
                ord_created_date=date.today(),
                cust_corp_chain_nbr=corp_chain,
            )
            TestDataFactory.create_order_transaction(
                material=self.substituted_material,
                plant=self.plant,
                total_shipped_qty=600,
                ord_created_date=date.today(),
                cust_corp_chain_nbr=corp_chain_b
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_CORP_CHAIN_MV)

        result = OrderTransactionService.get_corporate_chain_sales()

        # Check if corporate chains are sorted by total sales quantity
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['name'], "Corporate Chain B")
        self.assertEqual(result[0]['total_sales_qty'], 600)
        self.assertEqual(result[1]['name'], "Corporate Chain A")
        self.assertEqual(result[1]['total_sales_qty'], 500)

    def test_get_class_of_trade_units(self):
        """Test class of trade units retrieval"""
        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders with different class of trade descriptions
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_order_qty=100,
                total_shipped_qty=80,
                ord_created_date=date.today(),
                class_of_trade_desc="HOSPITAL",
                class_of_trade_nbr="1005"
            )
            TestDataFactory.create_order_transaction(
                material=self.substituted_material,
                plant=self.plant,
                total_order_qty=200,
                total_shipped_qty=150,
                ord_created_date=date.today(),
                class_of_trade_desc="INDEPENDENT",
                class_of_trade_nbr="1004"
            )
            # Create another order with same class of trade to test aggregation
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_order_qty=50,
                total_shipped_qty=40,
                ord_created_date=date.today(),
                class_of_trade_desc="HOSPITAL",
                class_of_trade_nbr="1005"
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_CLASS_OF_TRADE_MV)

        result = OrderTransactionService.get_class_of_trade_units()

        # Should have 2 unique class of trade groups
        self.assertEqual(len(result), 2)

        # Check ordering by total_order_qty (descending)
        first_result = result[0]
        self.assertEqual(first_result['class_of_trade_desc'], 'INDEPENDENT')
        self.assertEqual(first_result['class_of_trade_nbr'], '1004')
        self.assertEqual(first_result['ordered_units'], 200)
        self.assertEqual(first_result['filled_units'], 150)

        # Check aggregated hospital orders
        second_result = result[1]
        self.assertEqual(second_result['class_of_trade_desc'], 'HOSPITAL')
        self.assertEqual(second_result['class_of_trade_nbr'], '1005')
        self.assertEqual(second_result['ordered_units'], 150)  # 100 + 50
        self.assertEqual(second_result['filled_units'], 120)  # 80 + 40

    def test_get_material_group_units(self):
        """Test material group units retrieval"""
        # Create materials with different groups using actual codes
        generic_material = TestDataFactory.create_material(scrm_mat_grp='GRX')
        brand_material = TestDataFactory.create_material(scrm_mat_grp='BRX')
        TestDataFactory.create_material(scrm_mat_grp='OTC')

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders for different material groups
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                total_order_qty=150,
                total_shipped_qty=120,
                ord_created_date=date.today()
            )
            TestDataFactory.create_order_transaction(
                material=brand_material,
                plant=self.plant,
                total_order_qty=200,
                total_shipped_qty=180,
                ord_created_date=date.today()
            )
            # Create another generic order to test aggregation
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                total_order_qty=100,
                total_shipped_qty=80,
                ord_created_date=date.today()
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_MATERIAL_GROUP_MV)

        result = OrderTransactionService.get_material_group_units()

        # Should have 2 unique material groups (GRX and BRX)
        self.assertEqual(len(result), 2)

        # Check ordering by ordered_units (descending)
        first_result = result[0]
        self.assertEqual(first_result['material_group'], 'Generic')
        self.assertEqual(first_result['ordered_units'], 250)  # 150 + 100
        self.assertEqual(first_result['filled_units'], 200)  # 120 + 80

        # Check brand material group
        second_result = result[1]
        self.assertEqual(second_result['material_group'], 'Brand')
        self.assertEqual(second_result['ordered_units'], 200)
        self.assertEqual(second_result['filled_units'], 180)

    def test_get_material_group_units_weekly(self):
        """Test material group units weekly retrieval"""
        # Create materials with different groups using actual codes
        generic_material = TestDataFactory.create_material(scrm_mat_grp='GRX')
        brand_material = TestDataFactory.create_material(scrm_mat_grp='BRX')
        otc_material = TestDataFactory.create_material(scrm_mat_grp='OTC')

        # Create orders across multiple weeks
        base_date = date.today() - timedelta(days=30)

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Week 1: Generic and Brand orders
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                total_order_qty=150,
                total_shipped_qty=120,
                ord_created_date=base_date
            )
            TestDataFactory.create_order_transaction(
                material=brand_material,
                plant=self.plant,
                total_order_qty=200,
                total_shipped_qty=180,
                ord_created_date=base_date + timedelta(days=1)
            )

            # Week 2: OTC and more Generic orders
            TestDataFactory.create_order_transaction(
                material=otc_material,
                plant=self.plant,
                total_order_qty=100,
                total_shipped_qty=90,
                ord_created_date=base_date + timedelta(days=7)
            )
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                total_order_qty=50,
                total_shipped_qty=40,
                ord_created_date=base_date + timedelta(days=8)
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)

        result = OrderTransactionService.get_material_group_units_weekly()

        # Should return list of weekly data
        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)

        # Check structure of each week
        for week_data in result:
            self.assertIn('week_start', week_data)
            self.assertIn('brand_ordered_units', week_data)
            self.assertIn('brand_shipped_units', week_data)
            self.assertIn('generic_ordered_units', week_data)
            self.assertIn('generic_shipped_units', week_data)
            self.assertIn('otc_ordered_units', week_data)
            self.assertIn('otc_shipped_units', week_data)

        # Verify totals across all weeks
        total_brand_ordered = sum(week['brand_ordered_units'] for week in result)
        total_brand_shipped = sum(week['brand_shipped_units'] for week in result)
        total_generic_ordered = sum(week['generic_ordered_units'] for week in result)
        total_generic_shipped = sum(week['generic_shipped_units'] for week in result)
        total_otc_ordered = sum(week['otc_ordered_units'] for week in result)
        total_otc_shipped = sum(week['otc_shipped_units'] for week in result)

        self.assertEqual(total_brand_ordered, 200)
        self.assertEqual(total_brand_shipped, 180)
        self.assertEqual(total_generic_ordered, 200)  # 150 + 50
        self.assertEqual(total_generic_shipped, 160)  # 120 + 40
        self.assertEqual(total_otc_ordered, 100)
        self.assertEqual(total_otc_shipped, 90)

    def test_get_material_group_units_weekly_empty_data(self):
        """Test material group units weekly with no data"""
        result = OrderTransactionService.get_material_group_units_weekly()

        # Should return empty list when no data
        self.assertEqual(len(result), 0)

    def test_get_material_group_units_weekly_date_filtering(self):
        """Test that weekly material group units only includes last 90 days"""
        generic_material = TestDataFactory.create_material(scrm_mat_grp='GRX')

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create order outside 90-day window
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                total_order_qty=500,
                total_shipped_qty=400,
                ord_created_date=date.today() - timedelta(days=100)
            )

            # Create order within 90-day window
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                total_order_qty=100,
                total_shipped_qty=90,
                ord_created_date=date.today() - timedelta(days=10)
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)

        result = OrderTransactionService.get_material_group_units_weekly()

        # Should only include the recent order
        total_generic_ordered = sum(week['generic_ordered_units'] for week in result)
        self.assertEqual(total_generic_ordered, 100)

    def test_get_material_sales_with_contract_breakdown(self):
        """Test material sales with contract breakdown"""
        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders with contracts
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=150,
                ord_created_date=date.today(),
                contract_name="Contract A"
            )
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=100,
                ord_created_date=date.today(),
                contract_name="Contract B"
            )

        refresh_order_transaction_service_mvs(
            ORDER_TRANSACTION_MATERIAL_MV + ORDER_TRANSACTION_CONTRACT_MV
        )

        result = OrderTransactionService.get_material_sales_with_contract_breakdown()

        self.assertEqual(len(result), 1)
        material_data = result[0]
        self.assertEqual(material_data['name'], self.material.name)
        self.assertEqual(material_data['total_sales_qty'], 250)
        self.assertEqual(len(material_data['contract_sales']), 2)

        # Check contracts are included
        contract_names = [c['contract_name'] for c in material_data['contract_sales']]
        self.assertIn('Contract A', contract_names)
        self.assertIn('Contract B', contract_names)

    def test_get_corporate_sales_with_contract_breakdown(self):
        """Test corporate sales with contract breakdown"""
        corporate_a = TestDataFactory.create_customer_corp_chain(name="Corporate A")

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=200,
                ord_created_date=date.today(),
                cust_corp_chain_nbr=corporate_a,
                contract_name="Contract X"
            )
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=300,
                ord_created_date=date.today(),
                cust_corp_chain_nbr=corporate_a,
                contract_name="Contract Y"
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_CORP_CHAIN_MV)

        result = OrderTransactionService.get_corporate_sales_with_contract_breakdown()

        self.assertEqual(len(result), 1)
        corporate_data = result[0]
        self.assertEqual(corporate_data['name'], "Corporate A")
        self.assertEqual(corporate_data['cust_corp_chain_nbr'], corporate_a.cust_corp_chain_nbr)
        self.assertEqual(corporate_data['total_sales_qty'], 500)
        self.assertEqual(len(corporate_data['contract_sales']), 2)

    def test_get_material_sales_with_sales_group_breakdown(self):
        """Test material sales with sales group breakdown"""
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=150,
                ord_created_date=date.today(),
                sales_group="PGEN"
            )
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=100,
                ord_created_date=date.today(),
                sales_group="PRxO"
            )

        refresh_order_transaction_service_mvs(
            ORDER_TRANSACTION_MATERIAL_MV + ORDER_TRANSACTION_SALES_GROUP_MATERIAL_MV
        )

        result = OrderTransactionService.get_material_sales_with_sales_group_breakdown()

        self.assertEqual(len(result), 1)
        material_data = result[0]
        self.assertEqual(material_data['name'], self.material.name)
        self.assertEqual(material_data['total_sales_qty'], 250)
        self.assertEqual(len(material_data['sales_group_sales']), 2)

        groups = [s['sales_group'] for s in material_data['sales_group_sales']]
        self.assertIn('PGEN', groups)
        self.assertIn('PRxO', groups)

    def test_get_corporate_sales_with_sales_group_breakdown(self):
        """Test corporate sales with sales group breakdown"""
        corporate = TestDataFactory.create_customer_corp_chain(name="Corporate A")

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=200,
                ord_created_date=date.today(),
                cust_corp_chain_nbr=corporate,
                sales_group="PGEN"
            )
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=300,
                ord_created_date=date.today(),
                cust_corp_chain_nbr=corporate,
                sales_group="PRxO"
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_SALES_GROUP_CORP_CHAIN_MV)

        result = OrderTransactionService.get_corporate_sales_with_sales_group_breakdown()

        self.assertEqual(len(result), 1)
        corporate_data = result[0]
        self.assertEqual(corporate_data['name'], "Corporate A")
        self.assertEqual(corporate_data['cust_corp_chain_nbr'], corporate.cust_corp_chain_nbr)
        self.assertEqual(corporate_data['total_sales_qty'], 500)
        self.assertEqual(len(corporate_data['sales_group_sales']), 2)

    def test_get_state_sales(self):
        """Test state sales retrieval"""
        customer_ca = TestDataFactory.create_customer(state="California")
        customer_ny = TestDataFactory.create_customer(state="New York")

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=400,
                ord_created_date=date.today(),
                cust_nbr=customer_ca
            )
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                total_shipped_qty=300,
                ord_created_date=date.today(),
                cust_nbr=customer_ny
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_STATE_MATERIAL_MV)

        result = OrderTransactionService.get_state_sales()

        self.assertEqual(len(result), 2)
        # Check ordering by sales quantity (descending)
        self.assertEqual(result[0]['name'], 'California')
        self.assertEqual(result[0]['total_sales_qty'], 400)
        self.assertEqual(result[1]['name'], 'New York')
        self.assertEqual(result[1]['total_sales_qty'], 300)

    def test_get_alt_served_analysis_by_material_group(self):
        """Test alt served analysis by material group"""

        # Create materials with scrm_mat_grp set
        generic_material = TestDataFactory.create_material()
        generic_material.scrm_mat_grp = 'GRX'
        generic_material.save()

        brand_material = TestDataFactory.create_material()
        brand_material.scrm_mat_grp = 'BRX'
        brand_material.save()

        otc_material = TestDataFactory.create_material()
        otc_material.scrm_mat_grp = 'OTC'
        otc_material.save()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create alt served orders for different material groups
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                alt_plant_serv_flg_key=True
            )
            TestDataFactory.create_order_transaction(
                material=brand_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14),
                alt_plant_serv_flg_key=True
            )
            TestDataFactory.create_order_transaction(
                material=otc_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=21),
                alt_plant_serv_flg_key=True
            )

            # Create regular orders (not alt served)
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=False
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_ANALYSIS_MVS)

        result = OrderTransactionService.get_alt_served_analysis_by_material_group()

        # Check structure
        self.assertIn('weekly_data', result)
        self.assertIn('totals_by_group', result)
        self.assertIn('overall_stats', result)

        # Check overall stats
        overall_stats = result['overall_stats']
        self.assertEqual(overall_stats['total_orders'], 4)
        self.assertEqual(overall_stats['alt_served_orders'], 3)
        self.assertEqual(overall_stats['alt_served_percentage'], 75.0)

        # Check totals by group - should be mapped to category names
        totals_by_group = result['totals_by_group']
        self.assertEqual(len(totals_by_group), 3)

        # Find specific material groups by mapped category names
        generic_total = next(
            item for item in totals_by_group if item['material_group'] == 'Generic')
        brand_total = next(item for item in totals_by_group if item['material_group'] == 'Brand')
        otc_total = next(item for item in totals_by_group if item['material_group'] == 'OTC')

        self.assertEqual(generic_total['alt_served_count'], 1)
        self.assertEqual(brand_total['alt_served_count'], 1)
        self.assertEqual(otc_total['alt_served_count'], 1)

        # Check weekly data
        weekly_data = result['weekly_data']
        self.assertGreater(len(weekly_data), 0)

        # Check weekly data structure
        for week_data in weekly_data:
            self.assertIn('week_start', week_data)
            self.assertIn('generic_alt_served_count', week_data)
            self.assertIn('brand_alt_served_count', week_data)
            self.assertIn('otc_alt_served_count', week_data)
            self.assertIn('week_total', week_data)

    def test_get_alt_served_analysis_empty_data(self):
        """Test alt served analysis with no data"""
        result = OrderTransactionService.get_alt_served_analysis_by_material_group()

        # Should still return proper structure
        self.assertIn('weekly_data', result)
        self.assertIn('totals_by_group', result)
        self.assertIn('overall_stats', result)

        # Overall stats should be zero
        overall_stats = result['overall_stats']
        self.assertEqual(overall_stats['total_orders'], 0)
        self.assertEqual(overall_stats['alt_served_orders'], 0)
        self.assertEqual(overall_stats['alt_served_percentage'], 0)

        # No group totals
        self.assertEqual(len(result['totals_by_group']), 0)

    def test_get_substitution_analysis_by_material_group(self):
        """Test substitution analysis by material group"""

        # Create materials with scrm_mat_grp set
        generic_material = TestDataFactory.create_material()
        generic_material.scrm_mat_grp = 'GRX'
        generic_material.save()

        brand_material = TestDataFactory.create_material()
        brand_material.scrm_mat_grp = 'BRX'
        brand_material.save()

        otc_material = TestDataFactory.create_material()
        otc_material.scrm_mat_grp = 'OTC'
        otc_material.save()

        # Create substituted materials
        substituted_generic = TestDataFactory.create_material()
        substituted_generic.scrm_mat_grp = 'GRX'
        substituted_generic.save()

        substituted_brand = TestDataFactory.create_material()
        substituted_brand.scrm_mat_grp = 'BRX'
        substituted_brand.save()

        substituted_otc = TestDataFactory.create_material()
        substituted_otc.scrm_mat_grp = 'OTC'
        substituted_otc.save()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create substituted orders for different material groups
            TestDataFactory.create_order_transaction(
                material=generic_material,
                substituted_material=substituted_generic,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7)
            )
            TestDataFactory.create_order_transaction(
                material=brand_material,
                substituted_material=substituted_brand,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14)
            )
            TestDataFactory.create_order_transaction(
                material=otc_material,
                substituted_material=substituted_otc,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=21)
            )

            # Create regular orders (not substituted)
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10)
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_ANALYSIS_MVS)

        result = OrderTransactionService.get_substitution_analysis_by_material_group()

        # Check structure
        self.assertIn('weekly_data', result)
        self.assertIn('totals_by_group', result)
        self.assertIn('overall_stats', result)

        # Check overall stats
        overall_stats = result['overall_stats']
        self.assertEqual(overall_stats['total_orders'], 4)
        self.assertEqual(overall_stats['substituted_orders'], 3)
        self.assertEqual(overall_stats['substituted_percentage'], 75.0)

        # Check totals by group - should be mapped to category names
        totals_by_group = result['totals_by_group']
        self.assertEqual(len(totals_by_group), 3)

        # Find specific material groups by mapped category names
        generic_total = next(
            item for item in totals_by_group if item['material_group'] == 'Generic')
        brand_total = next(item for item in totals_by_group if item['material_group'] == 'Brand')
        otc_total = next(item for item in totals_by_group if item['material_group'] == 'OTC')

        self.assertEqual(generic_total['substituted_count'], 1)
        self.assertEqual(brand_total['substituted_count'], 1)
        self.assertEqual(otc_total['substituted_count'], 1)

        # Check weekly data
        weekly_data = result['weekly_data']
        self.assertGreater(len(weekly_data), 0)

        # Check weekly data structure
        for week_data in weekly_data:
            self.assertIn('week_start', week_data)
            self.assertIn('generic_substituted_count', week_data)
            self.assertIn('brand_substituted_count', week_data)
            self.assertIn('otc_substituted_count', week_data)
            self.assertIn('week_total', week_data)

    def test_get_substitution_analysis_empty_data(self):
        """Test substitution analysis with no data"""
        result = OrderTransactionService.get_substitution_analysis_by_material_group()

        # Should still return proper structure
        self.assertIn('weekly_data', result)
        self.assertIn('totals_by_group', result)
        self.assertIn('overall_stats', result)

        # Overall stats should be zero
        overall_stats = result['overall_stats']
        self.assertEqual(overall_stats['total_orders'], 0)
        self.assertEqual(overall_stats['substituted_orders'], 0)
        self.assertEqual(overall_stats['substituted_percentage'], 0)

        # No group totals
        self.assertEqual(len(result['totals_by_group']), 0)

    def test_get_weekly_order_analysis(self):
        """Test weekly order analysis service method"""

        # Create materials for testing
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders with different characteristics across multiple weeks
            # Week 1 - 7 days ago
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                alt_plant_serv_flg_key=True,
                f_total_imperfect=0
            )
            TestDataFactory.create_order_transaction(
                material=material1,
                substituted_material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_total_imperfect=0
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_total_imperfect=0
            )

            # Week 2 - 14 days ago
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14),
                alt_plant_serv_flg_key=True,
                f_total_imperfect=1
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                substituted_material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14),
                alt_plant_serv_flg_key=True,
                f_total_imperfect=1
            )

            # Week 3 - 21 days ago
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=21),
                f_total_imperfect=1
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_order_analysis()

        # Should return data
        self.assertGreater(len(result), 0)

        # Check data structure
        for week_data in result:
            self.assertIn('week_start', week_data)
            self.assertIn('total_orders', week_data)
            self.assertIn('total_order_qty', week_data)
            self.assertIn('total_shipped_qty', week_data)
            self.assertIn('alt_served_count', week_data)
            self.assertIn('alt_served_percentage', week_data)
            self.assertIn('substituted_count', week_data)
            self.assertIn('substituted_percentage', week_data)
            self.assertIn('perfect_orders', week_data)
            self.assertIn('perfect_order_rate', week_data)

            # Verify percentages are calculated correctly
            if week_data['total_orders'] > 0:
                expected_alt_percentage = (week_data['alt_served_count'] * 100.0) / week_data['total_orders']
                expected_sub_percentage = (week_data['substituted_count'] * 100.0) / week_data['total_orders']
                self.assertAlmostEqual(week_data['alt_served_percentage'], expected_alt_percentage, places=1)
                self.assertAlmostEqual(week_data['substituted_percentage'], expected_sub_percentage, places=1)

        # Verify specific week data
        total_orders_sum = sum(week['total_orders'] for week in result)
        total_alt_served_sum = sum(week['alt_served_count'] for week in result)
        total_substituted_sum = sum(week['substituted_count'] for week in result)
        total_perfect_orders_sum = sum(week['perfect_orders'] for week in result)

        self.assertEqual(total_orders_sum, 6)
        self.assertEqual(total_alt_served_sum, 3)
        self.assertEqual(total_substituted_sum, 2)
        self.assertEqual(total_perfect_orders_sum, 3)

    def test_get_weekly_order_analysis_empty_data(self):
        """Test weekly order analysis with no data"""
        result = OrderTransactionService.get_weekly_order_analysis()

        # Should return empty list when no data
        self.assertEqual(len(result), 0)

    def test_get_weekly_order_analysis_date_filtering(self):
        """Test that weekly order analysis only includes last 90 days"""

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create order outside 90-day window
            TestDataFactory.create_order_transaction(
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=100),
                alt_plant_serv_flg_key=True
            )

            # Create order within 90-day window
            TestDataFactory.create_order_transaction(
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=True
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_order_analysis()

        # Should only include the recent order
        total_orders = sum(week['total_orders'] for week in result)
        self.assertEqual(total_orders, 1)

    def test_get_weekly_order_analysis_result_fields_with_material_filter(self):
        """Filtered path returns total_order_qty and total_shipped_qty for serializer contract."""
        material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                total_order_qty=100,
                total_shipped_qty=90,
                ord_created_date=date.today() - timedelta(days=7),
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)

        result = OrderTransactionService.get_weekly_order_analysis(
            direct_mat_nbr=material.mat_nbr
        )

        self.assertGreater(len(result), 0)
        row = result[0]
        self.assertIn('week_start', row)
        self.assertIn('total_order_qty', row)
        self.assertIn('total_shipped_qty', row)

    def test_get_weekly_order_analysis_mat_nbr_subquery_filter(self):
        """Multiple material filter returns quantity fields and narrows results."""
        from api.material.models import Material

        vendor = TestDataFactory.create_vendor()
        mat_in = TestDataFactory.create_material(vendor=vendor)
        mat_out = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=mat_in,
                plant=self.plant,
                total_order_qty=100,
                total_shipped_qty=90,
                ord_created_date=date.today() - timedelta(days=7),
            )
            TestDataFactory.create_order_transaction(
                material=mat_out,
                plant=self.plant,
                total_order_qty=500,
                total_shipped_qty=400,
                ord_created_date=date.today() - timedelta(days=7),
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_ANALYSIS_MVS)

        results_all = OrderTransactionService.get_weekly_order_analysis()
        subquery = Material.objects.filter(vendor=vendor).values_list('mat_nbr', flat=True)
        results_filtered = OrderTransactionService.get_weekly_order_analysis(
            mat_nbr_subquery=subquery
        )

        self.assertGreater(len(results_filtered), 0)
        for row in results_filtered:
            self.assertIn('total_order_qty', row)
            self.assertIn('total_shipped_qty', row)

        total_qty_all = sum(week['total_order_qty'] for week in results_all)
        total_qty_filtered = sum(week['total_order_qty'] for week in results_filtered)
        self.assertLess(total_qty_filtered, total_qty_all)

    def test_order_kpis_integration(self):
        """Integration test for order KPIs calculation"""
        # Create materials for testing
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        substituted_material = TestDataFactory.create_material()

        # Create orders within 90-day window
        ninety_days_ago = date.today() - timedelta(days=89)

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Regular orders (perfect orders)
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=ninety_days_ago,
                total_order_qty=100,
                alt_plant_serv_flg_key=False,
                substituted_material=None
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=ninety_days_ago + timedelta(days=10),
                total_order_qty=200,
                alt_plant_serv_flg_key=False,
                substituted_material=None
            )

            # Alt-served orders (imperfect)
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=ninety_days_ago + timedelta(days=20),
                total_order_qty=150,
                alt_plant_serv_flg_key=True,
                substituted_material=None,
                f_total_imperfect=1
            )

            # Substituted orders
            TestDataFactory.create_order_transaction(
                material=material2,
                substituted_material=substituted_material,
                plant=self.plant,
                ord_created_date=ninety_days_ago + timedelta(days=30),
                total_order_qty=300,
                alt_plant_serv_flg_key=False
            )

            # Both alt-served and substituted (imperfect)
            TestDataFactory.create_order_transaction(
                material=material1,
                substituted_material=substituted_material,
                plant=self.plant,
                ord_created_date=ninety_days_ago + timedelta(days=40),
                total_order_qty=250,
                alt_plant_serv_flg_key=True,
                f_total_imperfect=1
            )

            # Create order outside 90-day window (should be excluded)
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=95),
                total_order_qty=500,
                alt_plant_serv_flg_key=True
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_order_kpi_stats()

        # Verify calculations
        self.assertEqual(result['total_orders'], 5)
        self.assertEqual(result['total_units'], 1000)  # 100+200+150+300+250

        # Alt-served: 2 orders (150+250=400 units)
        self.assertEqual(result['alt_served_orders'], 2)
        self.assertEqual(result['alt_served_units'], 400)
        self.assertEqual(result['alt_serve_rate'], 40.0)  # 2/5 * 100

        # Substituted: 2 orders (300+250=550 units)
        self.assertEqual(result['substituted_orders'], 2)
        self.assertEqual(result['substituted_units'], 550)
        self.assertEqual(result['substitution_rate'], 40.0)  # 2/5 * 100

        # Perfect orders: 2 orders (orders with no alt-serve flag)
        self.assertEqual(result['perfect_orders'], 3)
        self.assertEqual(result['perfect_order_rate'], 60.0)  # 3/5 * 100

    def test_get_alt_served_breakdown_analysis(self):
        """Test alt served breakdown analysis by material group, class of trade, and plant"""
        # Create materials with scrm_mat_grp set
        generic_material = TestDataFactory.create_material()
        generic_material.scrm_mat_grp = 'GRX'
        generic_material.save()

        brand_material = TestDataFactory.create_material()
        brand_material.scrm_mat_grp = 'BRX'
        brand_material.save()

        otc_material = TestDataFactory.create_material()
        otc_material.scrm_mat_grp = 'OTC'
        otc_material.save()

        # Create additional plants for testing
        plant2 = TestDataFactory.create_plant()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create alt served orders across different dimensions
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=True,
                class_of_trade_desc="HOSPITAL",
                class_of_trade_nbr="1005"
            )

            TestDataFactory.create_order_transaction(
                material=brand_material,
                plant=plant2,
                ord_created_date=date.today() - timedelta(days=20),
                alt_plant_serv_flg_key=True,
                class_of_trade_desc="INDEPENDENT",
                class_of_trade_nbr="1004"
            )

            TestDataFactory.create_order_transaction(
                material=otc_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=30),
                alt_plant_serv_flg_key=True,
                class_of_trade_desc="HOSPITAL",
                class_of_trade_nbr="1005"
            )

            # Create non-alt served order (should be excluded)
            TestDataFactory.create_order_transaction(
                material=generic_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=5),
                alt_plant_serv_flg_key=False,
                class_of_trade_desc="CHAIN",
                class_of_trade_nbr="1003"
            )

            # Create order outside 90-day window (should be excluded)
            TestDataFactory.create_order_transaction(
                material=brand_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=100),
                alt_plant_serv_flg_key=True,
                class_of_trade_desc="HOSPITAL",
                class_of_trade_nbr="1005"
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_ALT_SERVED_BREAKDOWN_MVS)

        result = OrderTransactionService.get_alt_served_breakdown_analysis()

        # Check structure
        self.assertIn('totals_by_group', result)
        self.assertIn('total_by_class_of_trade', result)
        self.assertIn('totals_by_plant', result)

        # Check material group breakdown
        totals_by_group = result['totals_by_group']
        self.assertEqual(len(totals_by_group), 3)  # Generic, Brand, OTC

        material_groups = [item['material_group'] for item in totals_by_group]
        self.assertIn('Generic', material_groups)
        self.assertIn('Brand', material_groups)
        self.assertIn('OTC', material_groups)

        # Check percentages sum to 100%
        total_percentage = sum(item['alt_served_percentage'] for item in totals_by_group)
        self.assertAlmostEqual(total_percentage, 100.0, places=1)

        # Check class of trade breakdown
        total_by_class_of_trade = result['total_by_class_of_trade']
        self.assertEqual(len(total_by_class_of_trade), 2)  # HOSPITAL, INDEPENDENT

        class_of_trades = [item['class_of_trade'] for item in total_by_class_of_trade]
        self.assertIn('HOSPITAL', class_of_trades)
        self.assertIn('INDEPENDENT', class_of_trades)

        # HOSPITAL should have 2 orders (Generic + OTC)
        hospital_data = next(item for item in total_by_class_of_trade if item['class_of_trade'] == 'HOSPITAL')
        self.assertEqual(hospital_data['alt_served_count'], 2)

        # Check plant breakdown
        totals_by_plant = result['totals_by_plant']
        self.assertEqual(len(totals_by_plant), 2)  # Two different plants

        plant_names = [item['plant'] for item in totals_by_plant]
        self.assertIn(self.plant.name, plant_names)
        self.assertIn(plant2.name, plant_names)

    def test_get_alt_served_breakdown_analysis_percentage_calculation(self):
        """Test percentage calculations in alt served breakdown analysis"""
        # Create materials with scrm_mat_grp set
        generic_material = TestDataFactory.create_material()
        generic_material.scrm_mat_grp = 'GRX'
        generic_material.save()

        brand_material = TestDataFactory.create_material()
        brand_material.scrm_mat_grp = 'BRX'
        brand_material.save()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create 3 Generic alt served orders and 1 Brand alt served order
            for _ in range(3):
                TestDataFactory.create_order_transaction(
                    material=generic_material,
                    plant=self.plant,
                    ord_created_date=date.today() - timedelta(days=10),
                    alt_plant_serv_flg_key=True
                )

            TestDataFactory.create_order_transaction(
                material=brand_material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=20),
                alt_plant_serv_flg_key=True
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_ALT_SERVED_BREAKDOWN_MVS)

        result = OrderTransactionService.get_alt_served_breakdown_analysis()

        # Check material group percentages: Generic=75%, Brand=25%
        totals_by_group = result['totals_by_group']
        generic_data = next(item for item in totals_by_group if item['material_group'] == 'Generic')
        brand_data = next(item for item in totals_by_group if item['material_group'] == 'Brand')

        self.assertEqual(generic_data['alt_served_count'], 3)
        self.assertEqual(generic_data['alt_served_percentage'], 75.0)
        self.assertEqual(brand_data['alt_served_count'], 1)
        self.assertEqual(brand_data['alt_served_percentage'], 25.0)

    def test_get_alt_served_by_material_status(self):
        """Test alt served breakdown by material status"""
        # Create materials with different statuses
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        material3 = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create alt served orders with different material statuses
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE"
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=20),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE"
            )
            TestDataFactory.create_order_transaction(
                material=material3,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=30),
                alt_plant_serv_flg_key=True,
                material_status="DISCONTINUED"
            )

            # Create non-alt served order (should be excluded)
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=5),
                alt_plant_serv_flg_key=False,
                material_status="ACTIVE"
            )

            # Create order outside 90-day window (should be excluded)
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=100),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE"
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_ALT_SERVED_STATUS_MV)

        result = OrderTransactionService.get_alt_served_by_material_status()

        # Should have 2 material statuses
        self.assertEqual(len(result), 2)

        # Check ordering by alt_served_count (descending)
        first_result = result[0]
        self.assertEqual(first_result['status'], 'ACTIVE')
        self.assertEqual(first_result['alt_served_count'], 2)
        self.assertEqual(first_result['alt_served_percentage'], 66.7)  # 2/3 * 100

        second_result = result[1]
        self.assertEqual(second_result['status'], 'DISCONTINUED')
        self.assertEqual(second_result['alt_served_count'], 1)
        self.assertEqual(second_result['alt_served_percentage'], 33.3)  # 1/3 * 100

        # Verify percentages sum to 100%
        total_percentage = sum(item['alt_served_percentage'] for item in result)
        self.assertAlmostEqual(total_percentage, 100.0, places=0)

    def test_get_alt_served_by_material_status_empty_data(self):
        """Test alt served by material status with no data"""
        result = OrderTransactionService.get_alt_served_by_material_status()
        self.assertEqual(len(result), 0)

    def test_get_alt_served_by_material_status_no_alt_served(self):
        """Test alt served by material status with no alt served orders"""
        # Create regular orders (not alt served)
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=False,
                material_status="ACTIVE"
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_ALT_SERVED_STATUS_MV)
        result = OrderTransactionService.get_alt_served_by_material_status()
        self.assertEqual(len(result), 0)

    def test_get_alt_served_by_material_status_null_status(self):
        """Test alt served by material status with null material status"""
        # Create alt served order with null material status
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=True,
                material_status=None
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_ALT_SERVED_STATUS_MV)
        result = OrderTransactionService.get_alt_served_by_material_status()

        self.assertEqual(len(result), 1)
        self.assertIsNone(result[0]['status'])
        self.assertEqual(result[0]['alt_served_count'], 1)
        self.assertEqual(result[0]['alt_served_percentage'], 100.0)

    def test_get_alt_served_materials_by_status(self):
        """Test alt served materials breakdown by specific material status"""
        # Create materials
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        material3 = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create alt served orders with ACTIVE status
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE"
            )
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=15),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE"
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=20),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE"
            )

            # Create alt served order with different status (should be excluded)
            TestDataFactory.create_order_transaction(
                material=material3,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=25),
                alt_plant_serv_flg_key=True,
                material_status="DISCONTINUED"
            )

            # Create non-alt served order with ACTIVE status (should be excluded)
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=5),
                alt_plant_serv_flg_key=False,
                material_status="ACTIVE"
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_ALT_SERVED_STATUS_MV)

        result = OrderTransactionService.get_alt_served_materials_by_status("ACTIVE")

        # Should have 2 materials (material1 and material2)
        self.assertEqual(len(result), 2)

        # Check ordering by alt_served_count (descending)
        first_result = result[0]
        self.assertEqual(first_result['material_name'], material1.name)
        self.assertEqual(first_result['mat_nbr'], material1.mat_nbr)
        self.assertEqual(first_result['alt_served_count'], 2)
        self.assertEqual(first_result['alt_served_percentage'], 66.7)  # 2/3 * 100

        second_result = result[1]
        self.assertEqual(second_result['material_name'], material2.name)
        self.assertEqual(second_result['mat_nbr'], material2.mat_nbr)
        self.assertEqual(second_result['alt_served_count'], 1)
        self.assertEqual(second_result['alt_served_percentage'], 33.3)  # 1/3 * 100

        # Verify percentages sum to 100%
        total_percentage = sum(item['alt_served_percentage'] for item in result)
        self.assertAlmostEqual(total_percentage, 100.0, places=0)

    def test_get_alt_served_materials_by_status_empty_data(self):
        """Test alt served materials by status with no data"""
        result = OrderTransactionService.get_alt_served_materials_by_status("ACTIVE")
        self.assertEqual(len(result), 0)

    def test_get_alt_served_materials_by_status_nonexistent_status(self):
        """Test alt served materials by status for non-existent status"""
        # Create alt served order with different status
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE"
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_ALT_SERVED_STATUS_MV)
        result = OrderTransactionService.get_alt_served_materials_by_status("NONEXISTENT")
        self.assertEqual(len(result), 0)

    def test_get_alt_served_units_by_type_weekly(self):
        """Test alt served units by type weekly breakdown"""

        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        # Create alt served orders with different types across multiple weeks
        base_date = date.today() - timedelta(days=30)

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Week 1: AUTO and MANUAL orders
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=base_date,
                total_order_qty=100,
                alt_plant_serv_flg_key=True,
                alt_serve_type=OrderTransaction.AltServeTypes.AUTO
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=base_date + timedelta(days=1),
                total_order_qty=150,
                alt_plant_serv_flg_key=True,
                alt_serve_type=OrderTransaction.AltServeTypes.MANUAL
            )

            # Week 2: More AUTO and MANUAL orders
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=base_date + timedelta(days=7),
                total_order_qty=200,
                alt_plant_serv_flg_key=True,
                alt_serve_type=OrderTransaction.AltServeTypes.AUTO
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=base_date + timedelta(days=8),
                total_order_qty=75,
                alt_plant_serv_flg_key=True,
                alt_serve_type=OrderTransaction.AltServeTypes.MANUAL
            )

            # Non-alt served order (should be excluded)
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=base_date + timedelta(days=2),
                total_order_qty=300,
                alt_plant_serv_flg_key=False
            )

            # Order outside 90-day window (should be excluded)
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=100),
                total_order_qty=500,
                alt_plant_serv_flg_key=True,
                alt_serve_type=OrderTransaction.AltServeTypes.AUTO
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_alt_served_units_by_type_weekly()

        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)

        for week_data in result:
            self.assertIn('week_start', week_data)
            self.assertIn('auto_units', week_data)
            self.assertIn('manual_units', week_data)
            self.assertIn('total_units', week_data)

            # Verify data types
            self.assertIsInstance(week_data['auto_units'], (int, type(None)))
            self.assertIsInstance(week_data['manual_units'], (int, type(None)))
            self.assertIsInstance(week_data['total_units'], (int, type(None)))

            auto_units = week_data['auto_units'] or 0
            manual_units = week_data['manual_units'] or 0
            total_units = week_data['total_units'] or 0
            self.assertEqual(total_units, auto_units + manual_units)

        # totals
        total_auto_units = sum(week['auto_units'] or 0 for week in result)
        total_manual_units = sum(week['manual_units'] or 0 for week in result)
        total_units_sum = sum(week['total_units'] or 0 for week in result)

        self.assertEqual(total_auto_units, 300)  # 100 + 200
        self.assertEqual(total_manual_units, 225)  # 150 + 75
        self.assertEqual(total_units_sum, 525)  # 300 + 225

    def test_get_alt_served_units_by_type_weekly_only_non_alt_served(self):
        """Test alt served units by type weekly with only non-alt served orders"""
        # Create non-alt served order
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                total_order_qty=100,
                alt_plant_serv_flg_key=False
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_alt_served_units_by_type_weekly()

        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 0)

    def test_get_alt_served_order_qty_by_cost_range_and_status(self):
        """Test alt served order quantity breakdown by cost range and material status"""
        # Create materials with different cost per unit values
        material_low = TestDataFactory.create_material(cost_per_unit=5.0)
        material_mid = TestDataFactory.create_material(cost_per_unit=25.0)
        material_high = TestDataFactory.create_material(cost_per_unit=75.0)
        material_very_high = TestDataFactory.create_material(cost_per_unit=120.0)

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create alt served orders with different material statuses
            TestDataFactory.create_order_transaction(
                material=material_low,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                alt_plant_serv_flg_key=True,
                material_status="Discontinued by ABC",
                total_order_qty=100
            )

            TestDataFactory.create_order_transaction(
                material=material_mid,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=20),
                alt_plant_serv_flg_key=True,
                material_status="Temp Unavail from Mfg",
                total_order_qty=200
            )

            TestDataFactory.create_order_transaction(
                material=material_high,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=30),
                alt_plant_serv_flg_key=True,
                material_status="ACTIVE",
                total_order_qty=150
            )

            TestDataFactory.create_order_transaction(
                material=material_very_high,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=40),
                alt_plant_serv_flg_key=True,
                material_status="OBSOLETE",
                total_order_qty=80
            )

            # Create non-alt served order (should be excluded)
            TestDataFactory.create_order_transaction(
                material=material_low,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=5),
                alt_plant_serv_flg_key=False,
                material_status="ACTIVE",
                total_order_qty=500
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_ALT_SERVED_COST_MV)

        result = OrderTransactionService.get_alt_served_order_qty_by_cost_range_and_status()

        self.assertIsInstance(result, dict)

        expected_ranges = ["0-15", "16-50", "51-100", "101-150", "151-200", "201+"]
        for range_key in expected_ranges:
            self.assertIn(range_key, result)
            self.assertIsInstance(result[range_key], dict)

        self.assertEqual(result["0-15"]["Discontinued by ABC"], 100)
        self.assertEqual(result["16-50"]["Temp Unavail from Mfg"], 200)
        self.assertEqual(result["51-100"]["ACTIVE"], 150)
        self.assertEqual(result["101-150"]["OBSOLETE"], 80)
        self.assertTrue(all(v == 0 for v in result["201+"].values()))

    def test_get_material_statuses_distinct(self):
        """Test retrieval of distinct material statuses from order transactions"""
        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders with different material statuses
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                material_status="ACTIVE"
            )
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=20),
                material_status="DISCONTINUED"
            )
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=30),
                material_status="TEMP UNAVAIL FROM MFG"
            )
            # Duplicate status to test distinctness
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=5),
                material_status="ACTIVE"
            )

        result = OrderTransactionService.get_material_status_distinct()
        statuses = [item['material_status'] for item in result]

        self.assertEqual(len(statuses), 3)
        self.assertIn("ACTIVE", statuses)
        self.assertIn("DISCONTINUED", statuses)
        self.assertIn("TEMP UNAVAIL FROM MFG", statuses)

    def test_get_material_omit_counts_for_period(self):
        """Test material omit counts calculation for a given period"""
        end_date = date.today()
        start_date = end_date - timedelta(days=30)

        material1 = TestDataFactory.create_material(mat_nbr="MAT001")
        material2 = TestDataFactory.create_material(mat_nbr="MAT002")
        material3 = TestDataFactory.create_material(mat_nbr="MAT003")

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Material with excess omits (fill rate < 0.85)
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=start_date + timedelta(days=5),
                total_order_qty=100,
                total_shipped_qty=50  # 50% fill rate
            )

            # Material with allowed omits (0.85 <= fill rate < 1.0)
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=start_date + timedelta(days=10),
                total_order_qty=100,
                total_shipped_qty=90  # 90% fill rate
            )

            # Material with no omits (fill rate >= 1.0)
            TestDataFactory.create_order_transaction(
                material=material3,
                plant=self.plant,
                ord_created_date=start_date + timedelta(days=15),
                total_order_qty=100,
                total_shipped_qty=100  # 100% fill rate
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_MATERIAL_MV)

        result = OrderTransactionService.get_material_omit_counts_for_period(start_date, end_date)

        self.assertEqual(result["excess_omits_count"], 1)
        self.assertEqual(result["allowed_omits_count"], 1)
        self.assertEqual(result["no_omits_count"], 1)
        self.assertEqual(result["total_products_ordered"], 3)
        self.assertEqual(result["total_products_with_omits"], 2)

    def test_get_material_omit_counts_for_last_three_months_weekly(self):
        """Test weekly material omit counts for the last 3 months"""
        today = date.today()

        # Create test data
        material1 = TestDataFactory.create_material(mat_nbr="MAT004")
        material2 = TestDataFactory.create_material(mat_nbr="MAT005")

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Orders from different weeks
            for week_offset in [0, 7, 14, 21]:
                test_date = today - timedelta(days=week_offset)

                # Material with excess omits
                TestDataFactory.create_order_transaction(
                    material=material1,
                    plant=self.plant,
                    ord_created_date=test_date,
                    total_order_qty=100,
                    total_shipped_qty=50  # 50% fill rate
                )

                # Material with allowed omits
                TestDataFactory.create_order_transaction(
                    material=material2,
                    plant=self.plant,
                    ord_created_date=test_date,
                    total_order_qty=100,
                    total_shipped_qty=90  # 90% fill rate
                )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_OMIT_SUMMARY_MV)

        result = OrderTransactionService.get_material_omit_counts_for_last_three_months_weekly()

        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)

        # Check structure of each weekly result
        for week_data in result:
            self.assertIn("year", week_data)
            self.assertIn("week", week_data)
            self.assertIn("week_start", week_data)
            self.assertIn("week_end", week_data)
            self.assertIn("excess_omits_count", week_data)
            self.assertIn("allowed_omits_count", week_data)
            self.assertIn("no_omits_count", week_data)

    def test_get_fulfillment_metrics_weekly(self):
        """Test weekly fulfillment metrics calculation"""
        end_date = date.today()
        start_date = end_date - timedelta(days=90)

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders across different weeks
            for week_offset in [0, 7, 14, 21, 28]:
                test_date = end_date - timedelta(days=week_offset)

                # Create multiple orders for each week
                TestDataFactory.create_order_transaction(
                    material=self.material,
                    plant=self.plant,
                    ord_created_date=test_date,
                    total_order_qty=100,
                    total_shipped_qty=90
                )

                TestDataFactory.create_order_transaction(
                    material=self.material,
                    plant=self.plant,
                    ord_created_date=test_date,
                    total_order_qty=200,
                    total_shipped_qty=180
                )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_TOTALS_MV)

        result = OrderTransactionService.get_fulfillment_metrics_weekly(start_date, end_date)

        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)

        # Check structure of each weekly result
        for week_metrics in result:
            self.assertIn("year", week_metrics)
            self.assertIn("week", week_metrics)
            self.assertIn("week_start", week_metrics)
            self.assertIn("week_end", week_metrics)
            self.assertIn("unshipped_quantity", week_metrics)
            self.assertIn("fulfillment_percentage", week_metrics)

            # Verify fulfillment percentage is within valid range
            self.assertGreaterEqual(week_metrics["fulfillment_percentage"], 0)
            self.assertLessEqual(week_metrics["fulfillment_percentage"], 100)

    def test_get_weekly_perfect_order_analysis(self):
        """Test weekly perfect order analysis service method"""

        # Create materials for testing
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders with different perfect/imperfect status across multiple weeks
            # Week 1 - 7 days ago
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_total_imperfect=0  # Perfect order
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_total_imperfect=1  # Imperfect order
            )
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_total_imperfect=0  # Perfect order
            )

            # Week 2 - 14 days ago
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14),
                f_total_imperfect=1  # Imperfect order
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14),
                f_total_imperfect=0  # Perfect order
            )

            # Week 3 - 21 days ago
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=21),
                f_total_imperfect=0  # Perfect order
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_perfect_order_analysis()

        # Should return data
        self.assertGreater(len(result), 0)

        # Check data structure
        for week_data in result:
            self.assertIn('week_start', week_data)
            self.assertIn('total_orders', week_data)
            self.assertIn('perfect_orders', week_data)
            self.assertIn('imperfect_orders', week_data)
            self.assertIn('perfect_order_rate', week_data)

            # Verify data types and ranges
            self.assertIsInstance(week_data['total_orders'], int)
            self.assertIsInstance(week_data['perfect_orders'], int)
            self.assertIsInstance(week_data['imperfect_orders'], int)
            self.assertGreaterEqual(week_data['perfect_order_rate'], 0.0)
            self.assertLessEqual(week_data['perfect_order_rate'], 100.0)

            # Verify perfect + imperfect = total
            self.assertEqual(
                week_data['perfect_orders'] + week_data['imperfect_orders'],
                week_data['total_orders']
            )

        # Verify totals across all weeks
        total_orders_sum = sum(week['total_orders'] for week in result)
        total_perfect_sum = sum(week['perfect_orders'] for week in result)
        total_imperfect_sum = sum(week['imperfect_orders'] for week in result)

        self.assertEqual(total_orders_sum, 6)
        self.assertEqual(total_perfect_sum, 4)  # 4 orders with f_total_imperfect=0
        self.assertEqual(total_imperfect_sum, 2)  # 2 orders with f_total_imperfect=1

    def test_get_weekly_perfect_order_analysis_empty_data(self):
        """Test weekly perfect order analysis with no data"""
        result = OrderTransactionService.get_weekly_perfect_order_analysis()

        # Should return empty list when no data
        self.assertEqual(len(result), 0)

    def test_get_weekly_perfect_order_analysis_all_perfect_orders(self):
        """Test weekly perfect order analysis with all perfect orders"""
        material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create only perfect orders
            for i in range(3):
                TestDataFactory.create_order_transaction(
                    material=material,
                    plant=self.plant,
                    ord_created_date=date.today() - timedelta(days=7),
                    f_total_imperfect=0  # All perfect orders
                )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_perfect_order_analysis()

        self.assertEqual(len(result), 1)
        week_data = result[0]

        self.assertEqual(week_data['total_orders'], 3)
        self.assertEqual(week_data['perfect_orders'], 3)
        self.assertEqual(week_data['imperfect_orders'], 0)
        self.assertEqual(week_data['perfect_order_rate'], 100.0)

    def test_get_weekly_perfect_order_analysis_all_imperfect_orders(self):
        """Test weekly perfect order analysis with all imperfect orders"""
        material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create only imperfect orders
            for i in range(2):
                TestDataFactory.create_order_transaction(
                    material=material,
                    plant=self.plant,
                    ord_created_date=date.today() - timedelta(days=7),
                    f_total_imperfect=1  # All imperfect orders
                )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_perfect_order_analysis()

        self.assertEqual(len(result), 1)
        week_data = result[0]

        self.assertEqual(week_data['total_orders'], 2)
        self.assertEqual(week_data['perfect_orders'], 0)
        self.assertEqual(week_data['imperfect_orders'], 2)
        self.assertEqual(week_data['perfect_order_rate'], 0.0)

    def test_get_weekly_perfect_order_analysis_date_filtering(self):
        """Test that weekly perfect order analysis only includes last 90 days"""
        material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create order outside 90-day window
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=100),
                f_total_imperfect=0
            )

            # Create order within 90-day window
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=30),
                f_total_imperfect=0
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_perfect_order_analysis()

        # Should only include the recent order
        total_orders = sum(week['total_orders'] for week in result)
        self.assertEqual(total_orders, 1)

    def test_get_weekly_perfect_order_analysis_percentage_calculation(self):
        """Test perfect order rate percentage calculations"""
        material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders with specific perfect/imperfect ratios
            # Week 1: 3 perfect, 1 imperfect = 75% perfect rate
            for i in range(3):
                TestDataFactory.create_order_transaction(
                    material=material,
                    plant=self.plant,
                    ord_created_date=date.today() - timedelta(days=7),
                    f_total_imperfect=0
                )
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_total_imperfect=1
            )

            # Week 2: 1 perfect, 2 imperfect = 33.33% perfect rate
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14),
                f_total_imperfect=0
            )
            for i in range(2):
                TestDataFactory.create_order_transaction(
                    material=material,
                    plant=self.plant,
                    ord_created_date=date.today() - timedelta(days=14),
                    f_total_imperfect=1
                )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_perfect_order_analysis()

        self.assertEqual(len(result), 2)

        # Find weeks and verify percentages
        week_rates = [week['perfect_order_rate'] for week in result]

        # Should contain 75.0 and 33.33... (rounded to appropriate decimal places)
        self.assertIn(75.0, week_rates)
        # Check if any rate is close to 33.33
        has_33_percent = any(abs(rate - 33.33) < 0.1 for rate in week_rates)
        self.assertTrue(has_33_percent)

    def test_get_weekly_perfect_order_analysis_ordering(self):
        """Test that weekly perfect order analysis is ordered by week_start"""
        material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders in different weeks (not in chronological order)
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=21),  # Week 3
                f_total_imperfect=0
            )
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),  # Week 1
                f_total_imperfect=1
            )
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14),  # Week 2
                f_total_imperfect=0
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_perfect_order_analysis()

        self.assertEqual(len(result), 3)

        # Verify ordering by week_start (ascending)
        week_starts = [week['week_start'] for week in result]
        self.assertEqual(week_starts, sorted(week_starts))

    def test_get_weekly_imperfect_line_rate_analysis(self):
        """Test weekly imperfect line rate analysis service method"""

        # Create materials for testing
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders with different imperfect flags across multiple weeks
            # Week 1 - 7 days ago
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_unpredictable_demand=1,
                f_omit_inflation=0,
                f_unaligned_forecast=0,
                f_demand_imperfect=0
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_unpredictable_demand=0,
                f_omit_inflation=1,
                f_unaligned_forecast=1,
                f_demand_imperfect=0
            )
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_unpredictable_demand=0,
                f_omit_inflation=0,
                f_unaligned_forecast=0,
                f_demand_imperfect=1
            )

            # Week 2 - 14 days ago
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14),
                f_unpredictable_demand=1,
                f_omit_inflation=1,
                f_unaligned_forecast=0,
                f_demand_imperfect=0
            )
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=14),
                f_unpredictable_demand=0,
                f_omit_inflation=0,
                f_unaligned_forecast=0,
                f_demand_imperfect=0
            )

            # Week 3 - 21 days ago
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=21),
                f_unpredictable_demand=1,
                f_omit_inflation=0,
                f_unaligned_forecast=1,
                f_demand_imperfect=1
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_imperfect_line_rate_analysis()

        # Should return data
        self.assertGreater(len(result), 0)

        # Check data structure
        for week_data in result:
            self.assertIn('week_start', week_data)
            self.assertIn('total_orders', week_data)
            self.assertIn('unpredictable_demand_count', week_data)
            self.assertIn('unpredictable_demand_rate', week_data)
            self.assertIn('omit_inflation_count', week_data)
            self.assertIn('omit_inflation_rate', week_data)
            self.assertIn('unaligned_forecast_count', week_data)
            self.assertIn('unaligned_forecast_rate', week_data)
            self.assertIn('demand_imperfect_count', week_data)
            self.assertIn('demand_imperfect_rate', week_data)

        # Verify totals across all weeks
        total_orders_sum = sum(week['total_orders'] for week in result)
        total_unpredictable = sum(week['unpredictable_demand_count'] for week in result)
        total_omit_inflation = sum(week['omit_inflation_count'] for week in result)
        total_unaligned = sum(week['unaligned_forecast_count'] for week in result)
        total_demand_imperfect = sum(week['demand_imperfect_count'] for week in result)

        self.assertEqual(total_orders_sum, 6)
        self.assertEqual(total_unpredictable, 3)  # 3 orders with f_unpredictable_demand=1
        self.assertEqual(total_omit_inflation, 2)  # 2 orders with f_omit_inflation=1
        self.assertEqual(total_unaligned, 2)  # 2 orders with f_unaligned_forecast=1
        self.assertEqual(total_demand_imperfect, 2)  # 2 orders with f_demand_imperfect=1

    def test_get_weekly_imperfect_line_rate_analysis_empty_data(self):
        """Test weekly imperfect line rate analysis with no data"""
        result = OrderTransactionService.get_weekly_imperfect_line_rate_analysis()

        # Should return empty list when no data
        self.assertEqual(len(result), 0)

    def test_get_weekly_imperfect_line_rate_analysis_all_perfect_lines(self):
        """Test weekly imperfect line rate analysis with all perfect lines"""
        material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders with all flags set to 0
            for i in range(3):
                TestDataFactory.create_order_transaction(
                    material=material,
                    plant=self.plant,
                    ord_created_date=date.today() - timedelta(days=7),
                    f_unpredictable_demand=0,
                    f_omit_inflation=0,
                    f_unaligned_forecast=0,
                    f_demand_imperfect=0
                )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_imperfect_line_rate_analysis()

        self.assertEqual(len(result), 1)
        week_data = result[0]

        self.assertEqual(week_data['total_orders'], 3)
        self.assertEqual(week_data['unpredictable_demand_count'], 0)
        self.assertEqual(week_data['unpredictable_demand_rate'], 0.0)
        self.assertEqual(week_data['omit_inflation_count'], 0)
        self.assertEqual(week_data['omit_inflation_rate'], 0.0)
        self.assertEqual(week_data['unaligned_forecast_count'], 0)
        self.assertEqual(week_data['unaligned_forecast_rate'], 0.0)
        self.assertEqual(week_data['demand_imperfect_count'], 0)
        self.assertEqual(week_data['demand_imperfect_rate'], 0.0)

    def test_get_weekly_imperfect_line_rate_analysis_percentage_calculation(self):
        """Test imperfect line rate percentage calculations"""
        material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create 4 orders with different flag combinations
            # 2 with unpredictable demand = 50%
            # 3 with omit inflation = 75%
            # 1 with unaligned forecast = 25%
            # 4 with demand imperfect = 100%
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_unpredictable_demand=1,
                f_omit_inflation=1,
                f_unaligned_forecast=0,
                f_demand_imperfect=1
            )
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_unpredictable_demand=1,
                f_omit_inflation=1,
                f_unaligned_forecast=1,
                f_demand_imperfect=1
            )
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_unpredictable_demand=0,
                f_omit_inflation=1,
                f_unaligned_forecast=0,
                f_demand_imperfect=1
            )
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=7),
                f_unpredictable_demand=0,
                f_omit_inflation=0,
                f_unaligned_forecast=0,
                f_demand_imperfect=1
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_imperfect_line_rate_analysis()

        self.assertEqual(len(result), 1)
        week_data = result[0]

        self.assertEqual(week_data['total_orders'], 4)
        self.assertEqual(week_data['unpredictable_demand_count'], 2)
        self.assertEqual(week_data['unpredictable_demand_rate'], 50.0)
        self.assertEqual(week_data['omit_inflation_count'], 3)
        self.assertEqual(week_data['omit_inflation_rate'], 75.0)
        self.assertEqual(week_data['unaligned_forecast_count'], 1)
        self.assertEqual(week_data['unaligned_forecast_rate'], 25.0)
        self.assertEqual(week_data['demand_imperfect_count'], 4)
        self.assertEqual(week_data['demand_imperfect_rate'], 100.0)

    def test_get_weekly_imperfect_line_rate_analysis_date_filtering(self):
        """Test that weekly imperfect line rate analysis only includes last 90 days"""
        material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create order outside 90-day window
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=100),
                f_unpredictable_demand=1,
                f_omit_inflation=1,
                f_unaligned_forecast=1,
                f_demand_imperfect=1
            )

            # Create order within 90-day window
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=30),
                f_unpredictable_demand=1,
                f_omit_inflation=0,
                f_unaligned_forecast=0,
                f_demand_imperfect=0
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MV)

        result = OrderTransactionService.get_weekly_imperfect_line_rate_analysis()

        # Should only include the recent order
        total_orders = sum(week['total_orders'] for week in result)
        self.assertEqual(total_orders, 1)

    def test_get_substitution_alt_serve_kpi_stats(self):
        """Test substitution and alt serve KPI stats calculation"""
        # Create materials for testing
        material1 = TestDataFactory.create_material()
        material2 = TestDataFactory.create_material()
        material3 = TestDataFactory.create_material()
        material4 = TestDataFactory.create_material()
        substituted_material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Material 1: has substitution only
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                substituted_material=substituted_material
            )

            # Material 2: has alt serve only
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=20),
                alt_plant_serv_flg_key=True
            )

            # Material 3: has both substitution and alt serve
            TestDataFactory.create_order_transaction(
                material=material3,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=30),
                substituted_material=substituted_material,
                alt_plant_serv_flg_key=True
            )

            # Material 4: has neither
            TestDataFactory.create_order_transaction(
                material=material4,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=40)
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_MATERIAL_MV)

        result = OrderTransactionService.get_substitution_alt_serve_kpi_stats()

        # Total materials: 4
        self.assertEqual(result['total_materials'], 4)

        # Materials with substitution: material1, material3 = 2
        self.assertEqual(result['materials_with_substitution'], 2)
        self.assertEqual(result['substitution_percent'], 50.0)  # 2/4 * 100

        # Materials with alt serve: material2, material3 = 2
        self.assertEqual(result['materials_with_alt_serve'], 2)
        self.assertEqual(result['alt_serve_percent'], 50.0)  # 2/4 * 100

    def test_get_substitution_alt_serve_kpi_stats_empty_data(self):
        """Test substitution and alt serve KPI stats with no data"""
        result = OrderTransactionService.get_substitution_alt_serve_kpi_stats()

        self.assertEqual(result['total_materials'], 0)
        self.assertEqual(result['materials_with_substitution'], 0)
        self.assertEqual(result['substitution_percent'], 0.0)
        self.assertEqual(result['materials_with_alt_serve'], 0)
        self.assertEqual(result['alt_serve_percent'], 0.0)

    def test_get_substitution_alt_serve_kpi_stats_with_filters(self):
        """Test substitution and alt serve KPI stats with filters"""
        # Create materials with different vendors
        vendor1 = TestDataFactory.create_vendor(name="Vendor A")
        vendor2 = TestDataFactory.create_vendor(name="Vendor B")

        material1 = TestDataFactory.create_material(vendor=vendor1)
        material2 = TestDataFactory.create_material(vendor=vendor1)
        material3 = TestDataFactory.create_material(vendor=vendor2)
        substituted_material = TestDataFactory.create_material()

        with MaterializedViewTestHelper.defer_auto_refresh():
            # Create orders for vendor1 materials
            TestDataFactory.create_order_transaction(
                material=material1,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=10),
                substituted_material=substituted_material
            )
            TestDataFactory.create_order_transaction(
                material=material2,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=20),
                alt_plant_serv_flg_key=True
            )

            # Create order for vendor2 material (should be excluded by filter)
            TestDataFactory.create_order_transaction(
                material=material3,
                plant=self.plant,
                ord_created_date=date.today() - timedelta(days=30),
                substituted_material=substituted_material
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_MATERIAL_MV)

        # Filter by vendor1 using subquery pattern
        from api.material.models import Material
        mat_nbr_subquery = Material.objects.filter(vendor=vendor1).values_list('mat_nbr', flat=True)
        result = OrderTransactionService.get_substitution_alt_serve_kpi_stats(
            mat_nbr_subquery=mat_nbr_subquery
        )

        # Should only include vendor1 materials: material1, material2 = 2
        self.assertEqual(result['total_materials'], 2)
        self.assertEqual(result['materials_with_substitution'], 1)  # material1
        self.assertEqual(result['substitution_percent'], 50.0)  # 1/2 * 100
        self.assertEqual(result['materials_with_alt_serve'], 1)  # material2
        self.assertEqual(result['alt_serve_percent'], 50.0)  # 1/2 * 100


class OrderTransactionComparisonServiceTest(BaseTestCase):
    """
    Unit tests for the period-based sales comparison methods on OrderTransactionService.

    Integration tests cover response shape and basic aggregation.
    These tests focus on:
      - Correct period bucketing (current vs previous)
      - Orders outside both windows are excluded
      - direct_mat_nbr filter narrows results
      - mat_nbr_subquery filter narrows results
      - Grouping dimensions (sales_group, state, material, customer)
    """

    CURRENT_START = date(2026, 3, 1)
    CURRENT_END = date(2026, 3, 17)
    PREVIOUS_START = date(2026, 2, 1)
    PREVIOUS_END = date(2026, 2, 17)

    def setUp(self):
        from api.order_transaction.services import OrderTransactionService
        self.service = OrderTransactionService

        self.plant = TestDataFactory.create_plant()
        self.material_a = TestDataFactory.create_material()
        self.material_b = TestDataFactory.create_material()
        self.customer = TestDataFactory.create_customer(state="TX")
        self.corp_chain = TestDataFactory.create_customer_corp_chain()

    def _create_ot(self, ord_date, sales_amount, material=None, sales_group="GRP1",
                   customer=None, corp_chain=None):
        with MaterializedViewTestHelper.defer_auto_refresh():
            return TestDataFactory.create_order_transaction(
                material=material or self.material_a,
                cust_nbr=customer or self.customer,
                cust_corp_chain_nbr=corp_chain or self.corp_chain,
                sales_amount=sales_amount,
                total_order_qty=10,
                total_shipped_qty=9,
                sales_group=sales_group,
                ord_created_date=ord_date,
                plant=self.plant,
            )

    def _call(self, method, **kwargs):
        return list(method(
            self.CURRENT_START, self.CURRENT_END,
            self.PREVIOUS_START, self.PREVIOUS_END,
            **kwargs
        ))

    # ------------------------------------------------------------------ #
    # Period bucketing                                                     #
    # ------------------------------------------------------------------ #

    def test_by_sales_group_buckets_current_and_previous_correctly(self):
        self._create_ot(date(2026, 3, 10), sales_amount=500)  # current
        self._create_ot(date(2026, 2, 10), sales_amount=300)  # previous

        results = self._call(self.service.get_sales_comparison_by_sales_group)
        self.assertEqual(len(results), 1)
        row = results[0]
        self.assertEqual(float(row['current_period_sales']), 500.0)
        self.assertEqual(float(row['previous_period_sales']), 300.0)

    def test_by_sales_group_excludes_orders_outside_both_windows(self):
        self._create_ot(date(2026, 3, 10), sales_amount=500)  # current — in
        self._create_ot(date(2026, 1, 10), sales_amount=999)  # outside — must not appear

        results = self._call(self.service.get_sales_comparison_by_sales_group)
        self.assertEqual(len(results), 1)
        row = results[0]
        self.assertEqual(float(row['current_period_sales']), 500.0)
        self.assertEqual(float(row['previous_period_sales']), 0.0)

    def test_by_sales_group_groups_by_dimension(self):
        self._create_ot(date(2026, 3, 5), sales_amount=100, sales_group="ALPHA")
        self._create_ot(date(2026, 3, 6), sales_amount=200, sales_group="BETA")

        results = self._call(self.service.get_sales_comparison_by_sales_group)
        groups = {r['sales_group'] for r in results}
        self.assertIn("ALPHA", groups)
        self.assertIn("BETA", groups)
        self.assertEqual(len(results), 2)

    # ------------------------------------------------------------------ #
    # State grouping (via cust_nbr__state FK)                             #
    # ------------------------------------------------------------------ #

    def test_by_state_groups_by_customer_state(self):
        customer_ca = TestDataFactory.create_customer(state="CA")
        customer_ny = TestDataFactory.create_customer(state="NY")

        self._create_ot(date(2026, 3, 5), sales_amount=400, customer=customer_ca)
        self._create_ot(date(2026, 3, 6), sales_amount=600, customer=customer_ny)

        results = self._call(self.service.get_sales_comparison_by_state)
        states = {r['cust_nbr__state']: float(r['current_period_sales']) for r in results}
        self.assertEqual(states.get("CA"), 400.0)
        self.assertEqual(states.get("NY"), 600.0)

    def test_by_state_previous_period_zero_when_no_previous_orders(self):
        self._create_ot(date(2026, 3, 5), sales_amount=200)

        results = self._call(self.service.get_sales_comparison_by_state)
        self.assertEqual(len(results), 1)
        self.assertEqual(float(results[0]['previous_period_sales']), 0.0)

    # ------------------------------------------------------------------ #
    # Material grouping                                                    #
    # ------------------------------------------------------------------ #

    def test_by_material_groups_by_material(self):
        self._create_ot(date(2026, 3, 5), sales_amount=100, material=self.material_a)
        self._create_ot(date(2026, 3, 6), sales_amount=200, material=self.material_b)

        results = self._call(self.service.get_sales_comparison_by_material)
        mat_ids = {r['material_id'] for r in results}
        self.assertIn(self.material_a.mat_nbr, mat_ids)
        self.assertIn(self.material_b.mat_nbr, mat_ids)

    def test_by_material_ordered_by_current_period_sales_desc(self):
        self._create_ot(date(2026, 3, 5), sales_amount=100, material=self.material_a)
        self._create_ot(date(2026, 3, 6), sales_amount=900, material=self.material_b)

        results = self._call(self.service.get_sales_comparison_by_material)
        sales = [float(r['current_period_sales']) for r in results]
        self.assertEqual(sales, sorted(sales, reverse=True))

    # ------------------------------------------------------------------ #
    # Customer grouping                                                    #
    # ------------------------------------------------------------------ #

    def test_by_customer_groups_by_corp_chain(self):
        chain_a = TestDataFactory.create_customer_corp_chain()
        chain_b = TestDataFactory.create_customer_corp_chain()

        self._create_ot(date(2026, 3, 5), sales_amount=300, corp_chain=chain_a)
        self._create_ot(date(2026, 3, 6), sales_amount=700, corp_chain=chain_b)

        results = self._call(self.service.get_sales_comparison_by_customer)
        chain_ids = {r['cust_corp_chain_nbr_id'] for r in results}
        self.assertIn(chain_a.cust_corp_chain_nbr, chain_ids)
        self.assertIn(chain_b.cust_corp_chain_nbr, chain_ids)

    def test_by_customer_ordered_by_current_period_sales_desc(self):
        chain_a = TestDataFactory.create_customer_corp_chain()
        chain_b = TestDataFactory.create_customer_corp_chain()

        self._create_ot(date(2026, 3, 5), sales_amount=100, corp_chain=chain_a)
        self._create_ot(date(2026, 3, 6), sales_amount=800, corp_chain=chain_b)

        results = self._call(self.service.get_sales_comparison_by_customer)
        sales = [float(r['current_period_sales']) for r in results]
        self.assertEqual(sales, sorted(sales, reverse=True))

    # ------------------------------------------------------------------ #
    # Material filter: direct_mat_nbr                                     #
    # ------------------------------------------------------------------ #

    def test_direct_mat_nbr_filter_excludes_other_materials(self):
        self._create_ot(date(2026, 3, 5), sales_amount=500, material=self.material_a)
        self._create_ot(date(2026, 3, 6), sales_amount=999, material=self.material_b)

        results = self._call(
            self.service.get_sales_comparison_by_material,
            direct_mat_nbr=self.material_a.mat_nbr
        )
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['material_id'], self.material_a.mat_nbr)

    def test_direct_mat_nbr_filter_on_sales_group(self):
        """Filter propagates correctly even when grouping by a different dimension."""
        self._create_ot(date(2026, 3, 5), sales_amount=400, material=self.material_a, sales_group="KEEP")
        self._create_ot(date(2026, 3, 6), sales_amount=600, material=self.material_b, sales_group="DROP")

        results = self._call(
            self.service.get_sales_comparison_by_sales_group,
            direct_mat_nbr=self.material_a.mat_nbr
        )
        groups = [r['sales_group'] for r in results]
        self.assertIn("KEEP", groups)
        self.assertNotIn("DROP", groups)

    # ------------------------------------------------------------------ #
    # Material filter: mat_nbr_subquery                                   #
    # ------------------------------------------------------------------ #

    def test_mat_nbr_subquery_filter_excludes_other_materials(self):
        from api.material.models import Material
        vendor = TestDataFactory.create_vendor()
        mat_in = TestDataFactory.create_material(vendor=vendor)
        mat_out = TestDataFactory.create_material()

        self._create_ot(date(2026, 3, 5), sales_amount=300, material=mat_in)
        self._create_ot(date(2026, 3, 6), sales_amount=700, material=mat_out)

        subquery = Material.objects.filter(vendor=vendor).values_list('mat_nbr', flat=True)
        results = self._call(
            self.service.get_sales_comparison_by_material,
            mat_nbr_subquery=subquery
        )
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['material_id'], mat_in.mat_nbr)

    def test_mat_nbr_subquery_empty_returns_no_results(self):
        from api.material.models import Material
        self._create_ot(date(2026, 3, 5), sales_amount=300)

        subquery = Material.objects.none().values_list('mat_nbr', flat=True)
        results = self._call(
            self.service.get_sales_comparison_by_sales_group,
            mat_nbr_subquery=subquery
        )
        self.assertEqual(len(results), 0)


class WeeklySalesTimelineServiceTest(MVTestCase):
    """Tests for OrderTransactionService.get_weekly_sales_timeline."""

    def setUp(self):
        self.plant = TestDataFactory.create_plant()
        self.material = TestDataFactory.create_material()
        self.other_material = TestDataFactory.create_material()

    def _create_ot(self, days_ago, sales_amount, material=None):
        with MaterializedViewTestHelper.defer_auto_refresh():
            return TestDataFactory.create_order_transaction(
                material=material or self.material,
                plant=self.plant,
                sales_amount=sales_amount,
                total_order_qty=10,
                total_shipped_qty=9,
                ord_created_date=date.today() - timedelta(days=days_ago),
            )

    def test_returns_results_within_90_days(self):
        self._create_ot(days_ago=7, sales_amount=500)
        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)
        results = list(OrderTransactionService.get_weekly_sales_timeline())
        self.assertGreater(len(results), 0)

    def test_results_are_ordered_by_week_start(self):
        self._create_ot(days_ago=14, sales_amount=200)
        self._create_ot(days_ago=7, sales_amount=300)
        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)
        results = list(OrderTransactionService.get_weekly_sales_timeline())
        dates = [r['week_start'] for r in results]
        self.assertEqual(dates, sorted(dates))

    def test_result_fields(self):
        self._create_ot(days_ago=7, sales_amount=500)
        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)
        results = list(OrderTransactionService.get_weekly_sales_timeline())
        row = results[0]
        self.assertIn('week_start', row)
        self.assertIn('sales_amount', row)
        self.assertIn('total_order_qty', row)
        self.assertIn('total_shipped_qty', row)

    def test_direct_mat_nbr_filter_excludes_other_materials(self):
        self._create_ot(days_ago=7, sales_amount=500, material=self.material)
        self._create_ot(days_ago=7, sales_amount=999, material=self.other_material)
        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)

        results_all = list(OrderTransactionService.get_weekly_sales_timeline())
        results_filtered = list(OrderTransactionService.get_weekly_sales_timeline(
            direct_mat_nbr=self.material.mat_nbr
        ))

        total_all = sum(float(r['sales_amount'] or 0) for r in results_all)
        total_filtered = sum(float(r['sales_amount'] or 0) for r in results_filtered)
        self.assertLess(total_filtered, total_all)

    def test_mat_nbr_subquery_filter(self):
        from api.material.models import Material
        vendor = TestDataFactory.create_vendor()
        mat_in = TestDataFactory.create_material(vendor=vendor)
        mat_out = TestDataFactory.create_material()

        self._create_ot(days_ago=7, sales_amount=300, material=mat_in)
        self._create_ot(days_ago=7, sales_amount=700, material=mat_out)
        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_WEEKLY_MATERIAL_MV)

        subquery = Material.objects.filter(vendor=vendor).values_list('mat_nbr', flat=True)
        results = list(OrderTransactionService.get_weekly_sales_timeline(mat_nbr_subquery=subquery))
        total = sum(float(r['sales_amount'] or 0) for r in results)
        self.assertAlmostEqual(total, 300.0, places=1)


class FailToSupplyServiceTests(BaseTestCase):
    """Tests for get_fail_to_supply_materials and get_fail_to_supply_trends.
    No materialized views used — queries run directly on OrderTransaction.
    """

    def setUp(self):
        self.plant = TestDataFactory.create_plant()
        self.material = TestDataFactory.create_material(
            xplant_mat_stat='AC',
            forecast_qty_7day=25,
        )
        self.other_material = TestDataFactory.create_material()
        self.today = date.today()
        self.from_date = self.today - timedelta(days=90)
        self.to_date = self.today

    def _create_ot(self, material=None, sales_group='PRxO', lines_ordered=10,
                   adj_lines=8, adj_qty=800.0, order_qty=1000, shipped_qty=900,
                   sales_amount=5000.0, days_ago=None, contract_name=None):
        if days_ago is None:
            days_ago = 5
        with MaterializedViewTestHelper.defer_auto_refresh():
            return TestDataFactory.create_order_transaction(
                material=material or self.material,
                plant=self.plant,
                sales_group=sales_group,
                total_order_qty=order_qty,
                total_shipped_qty=shipped_qty,
                sales_amount=sales_amount,
                ord_created_date=self.today - timedelta(days=days_ago),
                fts_lines_ordered=lines_ordered,
                fts_adj_lines_incl_72_hours=adj_lines,
                fts_adj_qty_incl_72_hours=adj_qty,
                contract_name=contract_name or 'PMGN',
            )

    # --- get_fail_to_supply_materials ---

    def test_aggregates_multiple_rows_per_material(self):
        self._create_ot(order_qty=100, shipped_qty=80, adj_qty=80.0, sales_amount=1000.0)
        self._create_ot(order_qty=200, shipped_qty=160, adj_qty=160.0, sales_amount=2000.0)

        results = list(OrderTransactionService.get_fail_to_supply_materials(
            self.from_date, self.to_date
        ))

        self.assertEqual(len(results), 1)
        self.assertEqual(float(results[0]['sales_amount']), 3000.0)
        self.assertEqual(results[0]['sales_qty'], 240)
        self.assertEqual(results[0]['unfilled_quantity'], 60)
        self.assertAlmostEqual(results[0]['outbound_fill_rate'], 80.0, places=1)
        self.assertEqual(results[0]['material__ndc'], self.material.ndc)

    def test_total_demand_is_previous_calendar_month(self):
        last_month_start, _ = (
            OrderTransactionService._previous_calendar_month_bounds(self.today)
        )
        days_into_last_month = (self.today - last_month_start).days
        self._create_ot(order_qty=500, days_ago=days_into_last_month)
        self._create_ot(order_qty=999, days_ago=0)

        results = list(OrderTransactionService.get_fail_to_supply_materials(
            self.from_date, self.to_date
        ))

        self.assertEqual(results[0]['total_demand'], 500)

    def test_omits_qty_annotation(self):
        self._create_ot(order_qty=1000, adj_qty=750.0)

        results = list(OrderTransactionService.get_fail_to_supply_materials(
            self.from_date, self.to_date
        ))

        self.assertAlmostEqual(float(results[0]['omits_qty']), 250.0, places=1)

    def test_omits_qty_last_month_previous_calendar_month(self):
        last_month_start, last_month_end = (
            OrderTransactionService._previous_calendar_month_bounds(self.today)
        )
        days_into_last_month = (self.today - last_month_start).days
        self._create_ot(order_qty=500, adj_qty=200.0, days_ago=days_into_last_month)
        # Current month row should not affect last-month omits
        self._create_ot(order_qty=999, adj_qty=0.0, days_ago=0)

        results = list(OrderTransactionService.get_fail_to_supply_materials(
            self.from_date, self.to_date
        ))

        self.assertAlmostEqual(float(results[0]['omits_qty_last_month']), 300.0, places=1)
        self.assertEqual(results[0]['total_demand'], 500)
        # Window omits include both rows
        self.assertAlmostEqual(float(results[0]['omits_qty']), 1299.0, places=1)

    def test_excludes_transactions_outside_date_range(self):
        self._create_ot(days_ago=0)
        self._create_ot(days_ago=120)

        results = list(OrderTransactionService.get_fail_to_supply_materials(
            self.from_date, self.to_date
        ))

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['sales_qty'], 900)

    def test_groups_across_multiple_materials(self):
        self._create_ot(material=self.material)
        self._create_ot(material=self.other_material)

        results = list(OrderTransactionService.get_fail_to_supply_materials(
            self.from_date, self.to_date
        ))

        self.assertEqual(len(results), 2)

    def test_prxo_and_pharmagen_service_levels(self):
        self._create_ot(sales_group='PRxO', lines_ordered=10, adj_lines=8)
        self._create_ot(sales_group='PGEN', lines_ordered=20, adj_lines=10)

        results = list(OrderTransactionService.get_fail_to_supply_materials(
            self.from_date, self.to_date
        ))

        self.assertAlmostEqual(results[0]['prxo_service_level'], 80.0, places=1)
        self.assertAlmostEqual(results[0]['pharmagen_service_level'], 50.0, places=1)

    def test_material_status_forecast_and_contract_mode(self):
        self._create_ot(contract_name='PMGN')
        self._create_ot(contract_name='PMGN')
        self._create_ot(contract_name='ABDC')

        results = list(OrderTransactionService.get_fail_to_supply_materials(
            self.from_date, self.to_date
        ))

        self.assertEqual(results[0]['material__xplant_mat_stat'], 'AC')
        self.assertEqual(results[0]['forecast_qty_28day'], 100)
        self.assertEqual(results[0]['contract_type'], 'PMGN')

    def test_trends_buckets_by_day(self):
        if self.today.day >= 4:
            day_a, day_b = 2, 3
            from_date = self.today.replace(day=1)
        else:
            day_a, day_b = 0, 1
            from_date = self.today - timedelta(days=1)
        self._create_ot(days_ago=day_a)
        self._create_ot(days_ago=day_b)

        mat_nbrs = [self.material.mat_nbr]
        results = OrderTransactionService.get_fail_to_supply_trends(
            from_date, self.to_date, mat_nbrs
        )

        dates = [r['date'] for r in results if r['material_id'] == self.material.mat_nbr]
        self.assertEqual(len(set(dates)), 2)

    def test_trends_prxo_lines_only_count_prxo_rows(self):
        from_date = self.today.replace(day=1)
        self._create_ot(sales_group='PRxO', lines_ordered=10, adj_lines=8, days_ago=min(5, self.today.day - 1))
        self._create_ot(sales_group='PGEN', lines_ordered=20, adj_lines=15, days_ago=min(5, self.today.day - 1))

        mat_nbrs = [self.material.mat_nbr]
        results = OrderTransactionService.get_fail_to_supply_trends(
            from_date, self.to_date, mat_nbrs
        )

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['prxo_lines_ordered'], 10)
        self.assertEqual(results[0]['prxo_adj_lines'], 8)
        self.assertEqual(results[0]['pharmagen_lines_ordered'], 20)
        self.assertEqual(results[0]['pharmagen_adj_lines'], 15)

    def test_trends_total_lines_cover_all_groups(self):
        from_date = self.today.replace(day=1)
        days_ago = min(5, self.today.day - 1)
        self._create_ot(sales_group='PRxO', lines_ordered=10, adj_lines=8, days_ago=days_ago)
        self._create_ot(sales_group='PGEN', lines_ordered=5, adj_lines=4, days_ago=days_ago)

        mat_nbrs = [self.material.mat_nbr]
        results = OrderTransactionService.get_fail_to_supply_trends(
            from_date, self.to_date, mat_nbrs
        )

        self.assertEqual(results[0]['total_lines_ordered'], 15)
        self.assertEqual(results[0]['total_adj_lines'], 12)

    def test_trends_excludes_materials_not_in_list(self):
        from_date = self.today.replace(day=1)
        days_ago = min(5, self.today.day - 1)
        self._create_ot(material=self.material, days_ago=days_ago)
        self._create_ot(material=self.other_material, days_ago=days_ago)

        results = OrderTransactionService.get_fail_to_supply_trends(
            from_date, self.to_date, [self.material.mat_nbr]
        )

        material_ids = {r['material_id'] for r in results}
        self.assertNotIn(self.other_material.mat_nbr, material_ids)

    def test_trends_excludes_out_of_range_dates(self):
        from_date = self.today.replace(day=1)
        self._create_ot(days_ago=0)
        self._create_ot(days_ago=60)

        mat_nbrs = [self.material.mat_nbr]
        results = OrderTransactionService.get_fail_to_supply_trends(
            from_date, self.to_date, mat_nbrs
        )

        total_ordered = sum(r['total_order_qty'] for r in results)
        self.assertEqual(total_ordered, 1000)


class FailToSupplyByPlantServiceTests(BaseTestCase):
    """Tests for get_fail_to_supply_by_plant."""

    def setUp(self):
        self.plant_a = TestDataFactory.create_plant()
        self.plant_b = TestDataFactory.create_plant()
        self.material = TestDataFactory.create_material()
        self.today = date.today()
        self.from_date = self.today.replace(day=1)
        self.to_date = self.today

    def _create_ot(self, plant=None, sales_group='PRxO', lines_ordered=10,
                   adj_lines=8, adj_qty=800.0, order_qty=1000, shipped_qty=900,
                   days_ago=None):
        if days_ago is None:
            days_ago = min(5, self.today.day - 1)
        with MaterializedViewTestHelper.defer_auto_refresh():
            return TestDataFactory.create_order_transaction(
                material=self.material,
                plant=plant or self.plant_a,
                sales_group=sales_group,
                total_order_qty=order_qty,
                total_shipped_qty=shipped_qty,
                ord_created_date=self.today - timedelta(days=days_ago),
                fts_lines_ordered=lines_ordered,
                fts_adj_lines_incl_72_hours=adj_lines,
                fts_adj_qty_incl_72_hours=adj_qty,
            )

    def test_groups_by_plant(self):
        self._create_ot(plant=self.plant_a)
        self._create_ot(plant=self.plant_b)

        results = list(OrderTransactionService.get_fail_to_supply_by_plant(
            self.material.mat_nbr, self.from_date, self.to_date
        ))

        plant_ids = {r['plant_id'] for r in results}
        self.assertEqual(len(results), 2)
        self.assertIn(self.plant_a.plant_nbr, plant_ids)
        self.assertIn(self.plant_b.plant_nbr, plant_ids)

    def test_only_returns_rows_for_given_material(self):
        other_material = TestDataFactory.create_material()
        self._create_ot(plant=self.plant_a)
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=other_material,
                plant=self.plant_b,
                ord_created_date=self.today - timedelta(days=min(5, self.today.day - 1)),
            )

        results = list(OrderTransactionService.get_fail_to_supply_by_plant(
            self.material.mat_nbr, self.from_date, self.to_date
        ))

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['plant_id'], self.plant_a.plant_nbr)

    def test_missed_lines_calculation(self):
        self._create_ot(lines_ordered=10, adj_lines=6)

        results = list(OrderTransactionService.get_fail_to_supply_by_plant(
            self.material.mat_nbr, self.from_date, self.to_date
        ))

        self.assertEqual(results[0]['total_missed_lines'], 4)

    def test_prxo_and_pgen_missed_lines_split(self):
        self._create_ot(sales_group='PRxO', lines_ordered=10, adj_lines=7)
        self._create_ot(sales_group='PGEN', lines_ordered=20, adj_lines=12)

        results = list(OrderTransactionService.get_fail_to_supply_by_plant(
            self.material.mat_nbr, self.from_date, self.to_date
        ))

        self.assertEqual(results[0]['prxo_missed_lines'], 3)
        self.assertEqual(results[0]['pgen_missed_lines'], 8)

    def test_service_level_annotation(self):
        self._create_ot(lines_ordered=10, adj_lines=8)

        results = list(OrderTransactionService.get_fail_to_supply_by_plant(
            self.material.mat_nbr, self.from_date, self.to_date
        ))

        self.assertAlmostEqual(results[0]['service_level'], 80.0, places=1)

    def test_outbound_fill_rate_annotation(self):
        self._create_ot(order_qty=100, shipped_qty=60)

        results = list(OrderTransactionService.get_fail_to_supply_by_plant(
            self.material.mat_nbr, self.from_date, self.to_date
        ))

        self.assertAlmostEqual(results[0]['outbound_fill_rate'], 60.0, places=1)

    def test_omit_qty_annotation(self):
        self._create_ot(order_qty=1000, adj_qty=750.0)

        results = list(OrderTransactionService.get_fail_to_supply_by_plant(
            self.material.mat_nbr, self.from_date, self.to_date
        ))

        self.assertAlmostEqual(float(results[0]['omit_qty']), 250.0, places=1)

    def test_excludes_out_of_range_transactions(self):
        self._create_ot(days_ago=0)  # within range (today is always within MTD)
        self._create_ot(days_ago=60)  # outside range

        results = list(OrderTransactionService.get_fail_to_supply_by_plant(
            self.material.mat_nbr, self.from_date, self.to_date
        ))

        self.assertEqual(results[0]['demand_qty'], 1000)

    def test_null_service_level_when_no_lines_ordered(self):
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=self.material,
                plant=self.plant_a,
                ord_created_date=self.today - timedelta(days=min(5, self.today.day - 1)),
                fts_lines_ordered=0,
                fts_adj_lines_incl_72_hours=0,
            )

        results = list(OrderTransactionService.get_fail_to_supply_by_plant(
            self.material.mat_nbr, self.from_date, self.to_date
        ))

        self.assertIsNone(results[0]['service_level'])


class InventoryCustomersByMaterialPlantServiceTests(BaseTestCase):
    """Tests for OrderTransactionService.get_customers_by_material_plant."""

    def setUp(self):
        self.plant_a = TestDataFactory.create_plant()
        self.plant_b = TestDataFactory.create_plant()
        self.material = TestDataFactory.create_material()
        self.other_material = TestDataFactory.create_material()
        self.customer_a = TestDataFactory.create_customer(cust_nbr="CUST1001", name="Customer A")
        self.customer_b = TestDataFactory.create_customer(cust_nbr="CUST1002", name="Customer B")
        self.corp_chain_a = TestDataFactory.create_customer_corp_chain(name="Corporate Chain A")
        self.corp_chain_b = TestDataFactory.create_customer_corp_chain(name="Corporate Chain B")
        self.today = date.today()
        self.from_date = self.today.replace(day=1)
        self.to_date = self.today

    def _create_ot(self, customer=None, corp_chain=None, plant=None, material=None,
                   adj_qty=800.0, order_qty=1000, shipped_qty=900,
                   sales_amount=5000.0, imperfect=0, days_ago=None):
        if days_ago is None:
            days_ago = min(5, self.today.day - 1)
        with MaterializedViewTestHelper.defer_auto_refresh():
            return TestDataFactory.create_order_transaction(
                material=material or self.material,
                plant=plant or self.plant_a,
                cust_nbr=customer or self.customer_a,
                cust_corp_chain_nbr=corp_chain or self.corp_chain_a,
                total_order_qty=order_qty,
                total_shipped_qty=shipped_qty,
                sales_amount=sales_amount,
                ord_created_date=self.today - timedelta(days=days_ago),
                fts_adj_qty_incl_72_hours=adj_qty,
                f_total_imperfect=imperfect,
            )

    def _results(self):
        return list(OrderTransactionService.get_customers_by_material_plant(
            self.material.mat_nbr, self.plant_a.plant_nbr, self.from_date, self.to_date
        ))

    def test_groups_by_customer(self):
        self._create_ot(customer=self.customer_a)
        self._create_ot(customer=self.customer_b, corp_chain=self.corp_chain_b)

        results = self._results()

        customer_ids = {r['cust_nbr_id'] for r in results}
        self.assertEqual(len(results), 2)
        self.assertIn(self.customer_a.cust_nbr, customer_ids)
        self.assertIn(self.customer_b.cust_nbr, customer_ids)

    def test_only_returns_rows_for_given_material_and_plant(self):
        self._create_ot(customer=self.customer_a, plant=self.plant_a, material=self.material)
        self._create_ot(customer=self.customer_b, plant=self.plant_b, material=self.material)
        self._create_ot(customer=self.customer_b, plant=self.plant_a, material=self.other_material)

        results = self._results()

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['cust_nbr_id'], self.customer_a.cust_nbr)

    def test_aggregates_multiple_rows_per_customer(self):
        self._create_ot(order_qty=100, shipped_qty=70, adj_qty=60.0, sales_amount=1000.0, imperfect=1)
        self._create_ot(order_qty=200, shipped_qty=180, adj_qty=150.0, sales_amount=2000.0, imperfect=0)

        result = self._results()[0]

        self.assertEqual(result['order_qty'], 300)
        self.assertEqual(result['shipped_qty'], 250)
        self.assertAlmostEqual(float(result['omit_qty']), 90.0, places=1)
        self.assertEqual(result['imperfect_lines'], 1)
        self.assertEqual(float(result['sales_amount']), 3000.0)

    def test_outbound_fill_rate_annotation(self):
        self._create_ot(order_qty=100, shipped_qty=75)

        result = self._results()[0]

        self.assertAlmostEqual(result['outbound_fill_rate'], 75.0, places=1)

    def test_excludes_out_of_range_transactions(self):
        self._create_ot(days_ago=0, order_qty=100)
        self._create_ot(days_ago=60, order_qty=200)

        result = self._results()[0]

        self.assertEqual(result['order_qty'], 100)

    def test_corp_chain_filter_applies(self):
        self._create_ot(customer=self.customer_a, corp_chain=self.corp_chain_a)
        self._create_ot(customer=self.customer_b, corp_chain=self.corp_chain_b)

        results = list(OrderTransactionService.get_customers_by_material_plant(
            self.material.mat_nbr,
            self.plant_a.plant_nbr,
            self.from_date,
            self.to_date,
            self.corp_chain_b.cust_corp_chain_nbr,
        ))

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['cust_nbr_id'], self.customer_b.cust_nbr)

    def test_does_not_include_fts_line_metrics(self):
        self._create_ot()

        result = self._results()[0]

        for field in (
            'prxo_missed_lines', 'pgen_missed_lines', 'total_missed_lines',
            'total_missed_lines_pct', 'service_level', 'total_lines_ordered',
            'demand_qty',
        ):
            self.assertNotIn(field, result)


class UnfilledMaterialsServiceTests(MVTestCase):
    """Tests for OrderTransactionService.list_unfilled_materials."""

    @classmethod
    def setUpTestData(cls):
        super().setUpTestData()
        cls.plant = TestDataFactory.create_plant(name="Unfilled Materials Plant")

    def test_list_unfilled_materials_membership_and_fields(self):
        today = date.today()
        unfilled = TestDataFactory.create_material(
            mat_nbr="UM_UNFILLED",
            name="Unfilled Mat",
            ndc="11122233344",
            forecast_qty_7day=25,
            outbound_fill_rate=0.72,
        )
        unfilled.saleable_qty_on_hand = 400
        unfilled.save(update_fields=["saleable_qty_on_hand"])

        allowed = TestDataFactory.create_material(mat_nbr="UM_ALLOWED", name="Allowed Mat")
        fulfilled = TestDataFactory.create_material(mat_nbr="UM_FULL", name="Full Mat")

        future_arrival = today + timedelta(days=5)
        overdue_arrival = today - timedelta(days=3)

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=unfilled,
                plant=self.plant,
                ord_created_date=today - timedelta(days=10),
                total_order_qty=100,
                total_shipped_qty=40,
            )
            TestDataFactory.create_order_transaction(
                material=allowed,
                plant=self.plant,
                ord_created_date=today - timedelta(days=10),
                total_order_qty=100,
                total_shipped_qty=90,
            )
            TestDataFactory.create_order_transaction(
                material=fulfilled,
                plant=self.plant,
                ord_created_date=today - timedelta(days=10),
                total_order_qty=100,
                total_shipped_qty=100,
            )
            TestDataFactory.create_update_demand_forecast(
                material=unfilled,
                plant=self.plant,
                demand_date=today - timedelta(days=1),
                on_order_qty=150,
            )
            TestDataFactory.create_update_demand_forecast(
                material=unfilled,
                plant=TestDataFactory.create_plant(name="UM Plant 2"),
                demand_date=today - timedelta(days=1),
                on_order_qty=50,
            )
            TestDataFactory.create_purchase_order(
                po_number="UM-PO-FUTURE",
                material=unfilled,
                plant=self.plant,
                ordered_date=today - timedelta(days=20),
                as_of_date=today - timedelta(days=5),
                anticipated_date=future_arrival,
                completion_date=None,
                po_line_number="001",
            )
            TestDataFactory.create_purchase_order(
                po_number="UM-PO-OVERDUE",
                material=unfilled,
                plant=self.plant,
                ordered_date=today - timedelta(days=30),
                as_of_date=today - timedelta(days=5),
                anticipated_date=overdue_arrival,
                completion_date=None,
                po_line_number="001",
            )
            TestDataFactory.create_purchase_order(
                po_number="UM-PO-DONE",
                material=unfilled,
                plant=self.plant,
                ordered_date=today - timedelta(days=25),
                as_of_date=today - timedelta(days=5),
                anticipated_date=today + timedelta(days=1),
                completion_date=today - timedelta(days=2),
                po_line_number="002",
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_MATERIAL_MV)
        MaterializedViewTestHelper.refresh_materialized_views([
            "purchase_order_latest_90d_mv",
            "demand_forecast_material_plant_mv",
        ])

        rows = list(OrderTransactionService.list_unfilled_materials())
        mat_nbrs = {row.material_number for row in rows}

        self.assertIn("UM_UNFILLED", mat_nbrs)
        self.assertIn("UM_ALLOWED", mat_nbrs)
        self.assertNotIn("UM_FULL", mat_nbrs)

        row = next(r for r in rows if r.material_number == "UM_UNFILLED")
        self.assertEqual(row.material_name, "Unfilled Mat")
        self.assertEqual(row.ndc, "11122233344")
        self.assertEqual(row.ordered_quantity, 100)
        self.assertEqual(row.unfilled_quantity, 60)
        self.assertAlmostEqual(float(row.outbound_fill_rate), 0.72, places=2)
        self.assertEqual(row.saleable_qty_on_hand, 400)
        self.assertEqual(row.forecast_qty_7day, 25)
        self.assertEqual(row.forecast_qty_28day, 100)
        self.assertEqual(row.on_order_qty, 200)
        self.assertEqual(row.next_expected_arrival_date, future_arrival)

    def test_list_unfilled_materials_default_ordering(self):
        today = date.today()
        low = TestDataFactory.create_material(mat_nbr="UM_ORD_LOW")
        high = TestDataFactory.create_material(mat_nbr="UM_ORD_HIGH")

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=low,
                plant=self.plant,
                ord_created_date=today - timedelta(days=5),
                total_order_qty=100,
                total_shipped_qty=80,
            )
            TestDataFactory.create_order_transaction(
                material=high,
                plant=self.plant,
                ord_created_date=today - timedelta(days=5),
                total_order_qty=100,
                total_shipped_qty=10,
            )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_MATERIAL_MV)

        rows = [
            r for r in OrderTransactionService.list_unfilled_materials()
            if r.material_number in {"UM_ORD_LOW", "UM_ORD_HIGH"}
        ]
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0].material_number, "UM_ORD_HIGH")
        self.assertEqual(rows[1].material_number, "UM_ORD_LOW")

    def test_list_unfilled_materials_filters_by_material(self):
        today = date.today()
        keep = TestDataFactory.create_material(mat_nbr="UM_KEEP")
        drop = TestDataFactory.create_material(mat_nbr="UM_DROP")

        with MaterializedViewTestHelper.defer_auto_refresh():
            for material in (keep, drop):
                TestDataFactory.create_order_transaction(
                    material=material,
                    plant=self.plant,
                    ord_created_date=today - timedelta(days=5),
                    total_order_qty=50,
                    total_shipped_qty=10,
                )

        refresh_order_transaction_service_mvs(ORDER_TRANSACTION_MATERIAL_MV)

        rows = list(OrderTransactionService.list_unfilled_materials(direct_mat_nbr=keep.mat_nbr))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].material_number, "UM_KEEP")


class MaterialOrderQuantitiesMtdServiceTests(BaseTestCase):
    """Tests for OrderTransactionService.list_material_order_quantities_mtd."""

    def setUp(self):
        super().setUp()
        self.plant = TestDataFactory.create_plant(name="MTD Qty Plant")
        self.today = date.today()
        self.month_start = self.today.replace(day=1)
        self.prior_month = self.month_start - timedelta(days=1)

    def test_list_material_order_quantities_mtd_fields_and_window(self):
        from api.material_formulary.models import MaterialFormulary

        material = TestDataFactory.create_material(
            mat_nbr="MTD_QTY_1",
            name="MTD Material",
            ndc="11223344556",
            xplant_mat_stat="ACTIVE",
        )
        other = TestDataFactory.create_material(mat_nbr="MTD_QTY_OTHER")

        MaterialFormulary.objects.create(
            material=material,
            sales_group="PGEN",
            program="PMX",
            contract_number="CN-MTD-1",
        )
        MaterialFormulary.objects.create(
            material=material,
            sales_group="PGEN",
            program="PM2",
            contract_number="CN-MTD-2",
        )
        MaterialFormulary.objects.create(
            material=material,
            sales_group="PRxO",
            program="PGS",
            contract_number="CN-MTD-3",
        )
        MaterialFormulary.objects.create(
            material=material,
            sales_group="",
            program="SKIP",
            contract_number="CN-MTD-4",
        )

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=self.today,
                total_order_qty=100,
                total_shipped_qty=80,
            )
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=self.month_start,
                total_order_qty=50,
                total_shipped_qty=40,
            )
            # Prior month — excluded from MTD
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=self.prior_month,
                total_order_qty=999,
                total_shipped_qty=999,
            )
            TestDataFactory.create_order_transaction(
                material=other,
                plant=self.plant,
                ord_created_date=self.today,
                total_order_qty=10,
                total_shipped_qty=5,
            )

        rows = list(
            OrderTransactionService.list_material_order_quantities_mtd(
                direct_mat_nbr=material.mat_nbr
            )
        )
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row["material_number"], "MTD_QTY_1")
        self.assertEqual(row["material_name"], "MTD Material")
        self.assertEqual(row["ndc"], "11223344556")
        self.assertEqual(row["material_status"], "ACTIVE")
        self.assertEqual(row["total_demand_mtd_units"], 150)
        self.assertAlmostEqual(row["fill_rate_percentage"], 80.0, places=2)
        self.assertEqual(row["formulary"], ["PGEN", "PRxO"])

    def test_list_material_order_quantities_mtd_ordering(self):
        low = TestDataFactory.create_material(mat_nbr="MTD_ORD_LOW")
        high = TestDataFactory.create_material(mat_nbr="MTD_ORD_HIGH")

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=low,
                plant=self.plant,
                ord_created_date=self.today,
                total_order_qty=20,
                total_shipped_qty=10,
            )
            TestDataFactory.create_order_transaction(
                material=high,
                plant=self.plant,
                ord_created_date=self.today,
                total_order_qty=200,
                total_shipped_qty=100,
            )

        rows = [
            r for r in OrderTransactionService.list_material_order_quantities_mtd()
            if r["material_number"] in {"MTD_ORD_LOW", "MTD_ORD_HIGH"}
        ]
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["material_number"], "MTD_ORD_HIGH")
        self.assertEqual(rows[1]["material_number"], "MTD_ORD_LOW")

    def test_list_material_order_quantities_mtd_corp_chain_filter(self):
        chain_a = TestDataFactory.create_customer_corp_chain(name="MTD Chain A")
        chain_b = TestDataFactory.create_customer_corp_chain(name="MTD Chain B")
        material = TestDataFactory.create_material(mat_nbr="MTD_CC")

        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=self.today,
                total_order_qty=30,
                total_shipped_qty=15,
                cust_corp_chain_nbr=chain_a,
            )
            TestDataFactory.create_order_transaction(
                material=material,
                plant=self.plant,
                ord_created_date=self.today,
                total_order_qty=70,
                total_shipped_qty=70,
                cust_corp_chain_nbr=chain_b,
            )

        rows = list(
            OrderTransactionService.list_material_order_quantities_mtd(
                direct_mat_nbr=material.mat_nbr,
                corp_chain_nbr=chain_b.cust_corp_chain_nbr,
            )
        )
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["total_demand_mtd_units"], 70)
        self.assertAlmostEqual(rows[0]["fill_rate_percentage"], 100.0, places=2)


class WeeklyFtsExposureServiceTests(BaseTestCase):
    """Tests for get_weekly_fts_exposure_qty. Queries run directly on OrderTransaction."""

    def setUp(self):
        self.plant = TestDataFactory.create_plant()
        self.material = TestDataFactory.create_material()
        self.other_material = TestDataFactory.create_material()
        self.week_start, self.week_end, self.last_week_start, self.last_week_end = iso_week_bounds()

    def _create_ot(self, material=None, order_qty=1000, adj_qty=800.0, ord_created_date=None,
                   cust_corp_chain_nbr=None):
        with MaterializedViewTestHelper.defer_auto_refresh():
            return TestDataFactory.create_order_transaction(
                material=material or self.material,
                plant=self.plant,
                total_order_qty=order_qty,
                total_shipped_qty=order_qty,
                ord_created_date=ord_created_date or self.week_end,
                fts_adj_qty_incl_72_hours=adj_qty,
                cust_corp_chain_nbr=cust_corp_chain_nbr,
            )

    def test_sums_multiple_rows_in_current_week(self):
        self._create_ot(order_qty=1000, adj_qty=800.0)
        self._create_ot(order_qty=500, adj_qty=350.0)

        result = OrderTransactionService.get_weekly_fts_exposure_qty()

        self.assertEqual(result['exposure_qty'], 350)

    def test_returns_current_week_bounds(self):
        result = OrderTransactionService.get_weekly_fts_exposure_qty()

        self.assertEqual(result['week_start'], self.week_start)
        self.assertEqual(result['week_end'], self.week_end)

    def test_excludes_last_week(self):
        self._create_ot(order_qty=1000, adj_qty=800.0)
        self._create_ot(order_qty=9999, adj_qty=0.0, ord_created_date=self.last_week_end)
        self._create_ot(order_qty=8888, adj_qty=0.0, ord_created_date=self.last_week_start)

        result = OrderTransactionService.get_weekly_fts_exposure_qty()

        self.assertEqual(result['exposure_qty'], 200)

    def test_excludes_dates_after_week_end(self):
        self._create_ot(order_qty=1000, adj_qty=800.0)
        self._create_ot(
            order_qty=7777, adj_qty=0.0, ord_created_date=self.week_end + timedelta(days=1)
        )

        result = OrderTransactionService.get_weekly_fts_exposure_qty()

        self.assertEqual(result['exposure_qty'], 200)

    def test_includes_week_start_boundary(self):
        self._create_ot(order_qty=600, adj_qty=100.0, ord_created_date=self.week_start)

        result = OrderTransactionService.get_weekly_fts_exposure_qty()

        self.assertEqual(result['exposure_qty'], 500)

    def test_returns_zero_with_no_data(self):
        result = OrderTransactionService.get_weekly_fts_exposure_qty()

        self.assertEqual(result['exposure_qty'], 0)

    def test_clamps_total_at_zero(self):
        self._create_ot(order_qty=100, adj_qty=500.0)

        result = OrderTransactionService.get_weekly_fts_exposure_qty()

        self.assertEqual(result['exposure_qty'], 0)

    def test_negative_row_offsets_positive_rows(self):
        self._create_ot(order_qty=1000, adj_qty=700.0)
        self._create_ot(order_qty=100, adj_qty=200.0)

        result = OrderTransactionService.get_weekly_fts_exposure_qty()

        self.assertEqual(result['exposure_qty'], 200)

    def test_treats_null_quantities_as_zero(self):
        ot = self._create_ot(order_qty=1000, adj_qty=800.0)
        OrderTransaction.objects.filter(pk=ot.pk).update(fts_adj_qty_incl_72_hours=None)
        null_demand = self._create_ot(order_qty=400, adj_qty=150.0)
        OrderTransaction.objects.filter(pk=null_demand.pk).update(total_order_qty=None)

        result = OrderTransactionService.get_weekly_fts_exposure_qty()

        self.assertEqual(result['exposure_qty'], 850)

    def test_filters_by_direct_mat_nbr(self):
        self._create_ot(material=self.material, order_qty=1000, adj_qty=800.0)
        self._create_ot(material=self.other_material, order_qty=500, adj_qty=0.0)

        result = OrderTransactionService.get_weekly_fts_exposure_qty(
            direct_mat_nbr=self.material.mat_nbr
        )

        self.assertEqual(result['exposure_qty'], 200)

    def test_filters_by_mat_nbr_subquery(self):
        self._create_ot(material=self.material, order_qty=1000, adj_qty=800.0)
        self._create_ot(material=self.other_material, order_qty=500, adj_qty=0.0)

        subquery = Material.objects.filter(mat_nbr=self.other_material.mat_nbr).values('mat_nbr')
        result = OrderTransactionService.get_weekly_fts_exposure_qty(mat_nbr_subquery=subquery)

        self.assertEqual(result['exposure_qty'], 500)

    def test_filters_by_corp_chain(self):
        chain_a = TestDataFactory.create_customer_corp_chain()
        chain_b = TestDataFactory.create_customer_corp_chain()
        self._create_ot(order_qty=1000, adj_qty=800.0, cust_corp_chain_nbr=chain_a)
        self._create_ot(order_qty=700, adj_qty=100.0, cust_corp_chain_nbr=chain_b)

        result = OrderTransactionService.get_weekly_fts_exposure_qty(
            corp_chain_nbr=chain_b.cust_corp_chain_nbr
        )

        self.assertEqual(result['exposure_qty'], 600)


class SalesMtdKpisServiceTest(BaseTestCase):
    """
    Tests for get_sales_mtd_kpis. Seeds order transactions inside and outside the
    current month-to-date window, split across contract and non-contract sales.
    """

    def _create_without_contract(self, sales_amount, contract_name):
        """The factory substitutes a random contract for a falsy contract_name, so clear it after."""
        transaction = TestDataFactory.create_order_transaction(
            material=self.material,
            ord_created_date=self.today,
            sales_amount=sales_amount,
        )
        OrderTransaction.objects.filter(pk=transaction.pk).update(contract_name=contract_name)
        return transaction

    def setUp(self):
        self.this_month_start, self.today, self.last_month_start, _ = calendar_month_bounds()
        self.vendor = TestDataFactory.create_vendor()
        self.material = TestDataFactory.create_material(vendor=self.vendor)

        # In window, under contract.
        TestDataFactory.create_order_transaction(
            material=self.material,
            ord_created_date=self.this_month_start,
            sales_amount=1000,
            contract_name='CONTRACT-A',
        )
        # In window, no contract — one null, one empty string.
        self._create_without_contract(sales_amount=400, contract_name=None)
        self._create_without_contract(sales_amount=100, contract_name='')
        # Outside the window — previous month must not be counted.
        TestDataFactory.create_order_transaction(
            material=self.material,
            ord_created_date=self.last_month_start,
            sales_amount=9999,
            contract_name='CONTRACT-A',
        )

        TestDataFactory.create_chargeback(
            vendor=self.vendor,
            material=self.material,
            chbk_hdr_created_date=self.today,
            abc_req_amt=250,
        )
        # Outside the window, and an excluded line status inside it.
        TestDataFactory.create_chargeback(
            vendor=self.vendor,
            material=self.material,
            chbk_hdr_created_date=self.last_month_start,
            abc_req_amt=7777,
        )
        TestDataFactory.create_chargeback(
            vendor=self.vendor,
            material=self.material,
            chbk_hdr_created_date=self.today,
            chbk_line_stat='Cancelled',
            abc_req_amt=5555,
        )

    def test_reports_the_month_to_date_window(self):
        result = OrderTransactionService.get_sales_mtd_kpis()

        self.assertEqual(result['period_start'], self.this_month_start)
        self.assertEqual(result['period_end'], self.today)

    def test_sales_totals_exclude_prior_months(self):
        result = OrderTransactionService.get_sales_mtd_kpis()

        self.assertEqual(result['total_sales_amount'], 1500)
        self.assertEqual(result['contract_sales_amount'], 1000)
        self.assertEqual(result['sales_without_chargeback_amount'], 500)

    def test_contract_and_non_contract_partition_total(self):
        result = OrderTransactionService.get_sales_mtd_kpis()

        self.assertEqual(
            result['contract_sales_amount'] + result['sales_without_chargeback_amount'],
            result['total_sales_amount'],
        )

    def test_chargeback_amount_counts_open_closed_in_window_only(self):
        result = OrderTransactionService.get_sales_mtd_kpis()
        self.assertEqual(result['chargeback_amount'], 250)

    def test_material_filter_narrows_all_metrics(self):
        other_material = TestDataFactory.create_material(vendor=self.vendor)
        TestDataFactory.create_order_transaction(
            material=other_material,
            ord_created_date=self.today,
            sales_amount=800,
            contract_name='CONTRACT-B',
        )
        TestDataFactory.create_chargeback(
            vendor=self.vendor,
            material=other_material,
            chbk_hdr_created_date=self.today,
            abc_req_amt=90,
        )

        result = OrderTransactionService.get_sales_mtd_kpis(
            direct_mat_nbr=self.material.mat_nbr
        )
        self.assertEqual(result['total_sales_amount'], 1500)
        self.assertEqual(result['chargeback_amount'], 250)

    def test_zeros_when_no_data_in_window(self):
        OrderTransaction.objects.all().delete()
        Chargeback.objects.all().delete()

        result = OrderTransactionService.get_sales_mtd_kpis()
        self.assertEqual(result['total_sales_amount'], 0)
        self.assertEqual(result['contract_sales_amount'], 0)
        self.assertEqual(result['sales_without_chargeback_amount'], 0)
        self.assertEqual(result['chargeback_amount'], 0)
