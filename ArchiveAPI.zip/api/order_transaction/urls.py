from django.urls import path

from .views import OTSalesComparisonBySalesGroupView, OTSalesComparisonByStateView, \
    OTSalesComparisonByMaterialView, OTSalesComparisonByCustomerView, \
    PlantOrderStatsView, MaterialSalesView, ContractSalesView, \
    CorporateSalesView, OrderTransactionView, MaterialOrderQuantitiesView, \
    MaterialOrderQuantitiesMtdView, \
    SoldToPartyOrderQuantitiesView, ClassOfTradeUnitsView, MaterialGroupUnitsView, MaterialGroupUnitsWeeklyView, \
    MaterialWithContractSalesView, \
    CorporateWithContractSalesView, MaterialWithSalesGroupSalesView, CorporateWithSalesGroupSalesView, StateSalesView, \
    AltServedByMaterialGroupWeeklyView, \
    SubstitutedByMaterialGroupWeeklyView, WeeklyOrderAnalysisView, OrderKpisView, SubstitutionAltServeKpisView, \
    AltServedBreakdownAnalysisView, \
    AltServedByMaterialStatusView, AltServedMaterialsByStatusView, AltServedUnitsByTypeWeeklyView, \
    AltServedOrderQtyByCostRangeAndMaterialStatusView, MaterialStatusListView, \
    MaterialOmitCountLastThreeMonthsView, FulfillmentMetricsView, WeeklyPerfectOrderAnalysisView, \
    WeeklyImperfectLineRateAnalysisView, WeeklySalesTimelineView, WeeklySalesBySalesGroupView, \
    FailToSupplyMaterialView, FailToSupplyPlantView, MaterialPlantCustomersView, UnfilledMaterialsView, \
    WeeklyFtsExposureView

app_name = "order-transaction"

urlpatterns = [
    path('', OrderTransactionView.as_view(), name="order-transaction-list"),
    path("plant-order-stats/", PlantOrderStatsView.as_view(), name="plant-order-stats"),
    path("material-sales/", MaterialSalesView.as_view(), name="material-sales"),
    path("material-with-contract-sales/", MaterialWithContractSalesView.as_view(), name="material-with-contract-sales"),
    path("contract-sales/", ContractSalesView.as_view(), name="contract-sales"),
    path("corporate-sales/", CorporateSalesView.as_view(), name="corporate-sales"),
    path("contract-with-contract-sales/", CorporateWithContractSalesView.as_view(),
         name="contract-with-corporate-sales"),
    path("material-with-sales-group-sales/", MaterialWithSalesGroupSalesView.as_view(),
         name="material-with-sales-group-sales"),
    path("corporate-with-sales-group-sales/", CorporateWithSalesGroupSalesView.as_view(),
         name="corporate-with-sales-group-sales"),
    path(
        "class-of-trade-filled-rate/",
        ClassOfTradeUnitsView.as_view(),
        name="class-of-trade-filled-rate-trend"
    ),
    path("material-order-quantities/", MaterialOrderQuantitiesView.as_view(), name="material-order-quantities"),
    path(
        "material-order-quantities-mtd/",
        MaterialOrderQuantitiesMtdView.as_view(),
        name="material-order-quantities-mtd",
    ),
    path("sold-to-party-order-quantities/", SoldToPartyOrderQuantitiesView.as_view(),
         name="sold-to-party-order-quantities"),
    path('material-group-units/', MaterialGroupUnitsView.as_view(), name='material-group-units'),
    path('material-group-units-weekly/', MaterialGroupUnitsWeeklyView.as_view(), name='material-group-units-weekly'),
    path("state-sales/", StateSalesView.as_view(), name="state-sales"),
    path("material-group-alt-serve-trend/", AltServedByMaterialGroupWeeklyView.as_view(),
         name="material-group-alt-serve-trend"),
    path("material-group-substituted-trend/", SubstitutedByMaterialGroupWeeklyView.as_view(),
         name="material-group-substituted-trend"),
    path("alt-serve-substituted-overall-stats/", WeeklyOrderAnalysisView.as_view(),
         name="alt-serve-substituted-overall-stats"),
    path("kpis/", OrderKpisView.as_view(), name="order-kpis"),
    path("substitution-alt-serve-kpis/", SubstitutionAltServeKpisView.as_view(), name="substitution-alt-serve-kpis"),
    path("alt-served-breakdown-analysis/", AltServedBreakdownAnalysisView.as_view(),
         name="alt-served-breakdown-analysis"),
    path("alt-served-material-status-breakdown/", AltServedByMaterialStatusView.as_view(),
         name="alt-served-material-group-breakdown"),
    path("alt-served-materials-by-status/<str:material_status>/", AltServedMaterialsByStatusView.as_view(),
         name="alt-served-materials-by-status"),
    path("alt-served-units-by-type/", AltServedUnitsByTypeWeeklyView.as_view(),
         name="alt-served-units-by-type"),
    path("alt-served-order-qty-by-status-and-cost-range/", AltServedOrderQtyByCostRangeAndMaterialStatusView.as_view(),
         name="alt-served-order-qty-by-status-and-cost-range"),
    path("material-status/", MaterialStatusListView.as_view(), name="material-status"),
    path(
        "material-omit-counts-last-three-months/",
        MaterialOmitCountLastThreeMonthsView.as_view(),
        name="material-omit-counts-last-three-months",
    ),
    path(
        "unfilled-materials/",
        UnfilledMaterialsView.as_view(),
        name="unfilled-materials",
    ),
    path(
        "fulfillment/",
        FulfillmentMetricsView.as_view(),
        name="fulfillment-metrics",
    ),
    path(
        "perfect-order-rate/",
        WeeklyPerfectOrderAnalysisView.as_view(),
        name="perfect-order-rate",
    ),
    path(
        "demand-imperfect-line-rate/",
        WeeklyImperfectLineRateAnalysisView.as_view(),
        name="demand-imperfect-line-rate",
    ),
    path(
        "sales-comparison/by-sales-group/",
        OTSalesComparisonBySalesGroupView.as_view(),
        name="ot-sales-comparison-by-sales-group",
    ),
    path(
        "sales-comparison/by-state/",
        OTSalesComparisonByStateView.as_view(),
        name="ot-sales-comparison-by-state",
    ),
    path(
        "sales-comparison/by-material/",
        OTSalesComparisonByMaterialView.as_view(),
        name="ot-sales-comparison-by-material",
    ),
    path(
        "sales-comparison/by-customer/",
        OTSalesComparisonByCustomerView.as_view(),
        name="ot-sales-comparison-by-customer",
    ),
    path(
        "sales-timeline/",
        WeeklySalesTimelineView.as_view(),
        name="sales-timeline",
    ),
    path(
        "weekly-sales-by-sales-group/",
        WeeklySalesBySalesGroupView.as_view(),
        name="weekly-sales-by-sales-group",
    ),
    path(
        "fail-to-supply/weekly-exposure/",
        WeeklyFtsExposureView.as_view(),
        name="fail-to-supply-weekly-exposure",
    ),
    path(
        "fail-to-supply/materials/",
        FailToSupplyMaterialView.as_view(),
        name="fail-to-supply-materials",
    ),
    path(
        "fail-to-supply/materials/<str:mat_nbr>/plants/",
        FailToSupplyPlantView.as_view(),
        name="fail-to-supply-plants",
    ),
    path(
        "materials/<str:mat_nbr>/plants/<str:plant_nbr>/customers/",
        MaterialPlantCustomersView.as_view(),
        name="material-plant-customers",
    ),
]
