DROP MATERIALIZED VIEW IF EXISTS order_transaction_material_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_material_90d_mv AS
SELECT
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    -- Order metrics
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount,
    -- Perfect/Imperfect line counts
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END) AS perfect_lines,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END) AS imperfect_lines,
    -- Individual imperfect flags
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END) AS demand_variability_count,
    COUNT(CASE WHEN ot.f_omit_inflation = 1 THEN 1 END) AS omit_inflation_count,
    COUNT(CASE WHEN ot.f_unaligned_forecast = 1 THEN 1 END) AS unaligned_forecast_count,
    -- Alt-served metrics
    COUNT(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN 1 END) AS alt_served_count,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN ot.total_order_qty ELSE 0 END) AS alt_served_units,
    -- Substitution metrics
    COUNT(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN 1 END) AS substituted_count,
    SUM(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN ot.total_order_qty ELSE 0 END) AS substituted_units,
    -- Fill rate calculation
    CASE
        WHEN SUM(ot.total_order_qty) > 0
        THEN CAST(SUM(ot.total_shipped_qty) AS FLOAT) / CAST(SUM(ot.total_order_qty) AS FLOAT)
        ELSE 0.0
    END AS fill_rate,
    -- Date range for tracking
    MIN(ot.ord_created_date) AS first_order_date,
    MAX(ot.ord_created_date) AS last_order_date
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_mat_90d_mat_nbr ON order_transaction_material_90d_mv(mat_nbr);
CREATE INDEX idx_mat_90d_total_sales ON order_transaction_material_90d_mv(total_shipped_qty DESC);
CREATE INDEX idx_mat_90d_total_order ON order_transaction_material_90d_mv(total_order_qty DESC);
CREATE INDEX idx_mat_90d_fill_rate ON order_transaction_material_90d_mv(fill_rate);
CREATE INDEX idx_mat_90d_corp_chain ON order_transaction_material_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_mat_90d_corp_mat ON order_transaction_material_90d_mv(cust_corp_chain_nbr, mat_nbr);

-- ============================================================================
-- 2. Weekly Order Aggregation with Material Group
-- ============================================================================
-- Weekly aggregations for all order metrics broken down by material group
DROP MATERIALIZED VIEW IF EXISTS order_transaction_weekly_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_weekly_mv AS
SELECT
    DATE_TRUNC('week', ot.ord_created_date)::date AS week_start,
    m.material_group,
    ot.cust_corp_chain_nbr,
    -- Total counts
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    -- Alt served metrics
    COUNT(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN 1 END) AS alt_served_count,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN ot.total_order_qty ELSE 0 END) AS alt_served_units,
    -- Alt serve by type (case-insensitive comparison to handle 'Auto', 'AUTO', 'Manual', 'MANUAL')
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE AND UPPER(TRIM(ot.alt_serve_type)) = 'AUTO' THEN ot.total_order_qty ELSE 0 END) AS auto_alt_served_units,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE AND UPPER(TRIM(ot.alt_serve_type)) = 'MANUAL' THEN ot.total_order_qty ELSE 0 END) AS manual_alt_served_units,
    -- Substitution metrics
    COUNT(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN 1 END) AS substituted_count,
    SUM(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN ot.total_order_qty ELSE 0 END) AS substituted_units,
    -- Perfect order metrics
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END) AS perfect_orders,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END) AS imperfect_orders,
    -- Imperfect flags breakdown
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_omit_inflation = 1 THEN 1 END) AS omit_inflation_count,
    COUNT(CASE WHEN ot.f_unaligned_forecast = 1 THEN 1 END) AS unaligned_forecast_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END) AS demand_imperfect_count
FROM order_transactions ot
LEFT JOIN materials m ON ot.mat_nbr = m.mat_nbr
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY DATE_TRUNC('week', ot.ord_created_date)::date, m.material_group, ot.cust_corp_chain_nbr;

CREATE INDEX idx_weekly_week ON order_transaction_weekly_mv(week_start);
CREATE INDEX idx_weekly_week_group ON order_transaction_weekly_mv(week_start, material_group);
CREATE INDEX idx_weekly_corp_chain ON order_transaction_weekly_mv(cust_corp_chain_nbr);
CREATE INDEX idx_weekly_corp_week ON order_transaction_weekly_mv(cust_corp_chain_nbr, week_start);

-- ============================================================================
-- 3. Customer 90-Day Aggregation
-- ============================================================================
-- Comprehensive customer-level aggregation for all metrics over 90 days
DROP MATERIALIZED VIEW IF EXISTS order_transaction_customer_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_customer_90d_mv AS
SELECT
    ot.cust_nbr,
    -- Order metrics
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount,
    -- Perfect/Imperfect line counts
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END) AS perfect_lines,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END) AS imperfect_lines,
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END) AS demand_variability_count,
    -- Fill rate
    CASE
        WHEN SUM(ot.total_order_qty) > 0
        THEN CAST(SUM(ot.total_shipped_qty) AS FLOAT) / CAST(SUM(ot.total_order_qty) AS FLOAT)
        ELSE 0.0
    END AS fill_rate
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.cust_nbr IS NOT NULL
GROUP BY ot.cust_nbr;

CREATE INDEX idx_customer_90d_cust_nbr ON order_transaction_customer_90d_mv(cust_nbr);
CREATE INDEX idx_customer_90d_total_order ON order_transaction_customer_90d_mv(total_order_qty DESC);

-- ============================================================================
-- 4. Contract 90-Day Aggregation
-- ============================================================================
-- Contract-level aggregation with material breakdown
DROP MATERIALIZED VIEW IF EXISTS order_transaction_contract_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_contract_90d_mv AS
SELECT
    ot.contract_name,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.contract_name IS NOT NULL
  AND ot.contract_name != ''
GROUP BY ot.contract_name, ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_contract_90d_contract ON order_transaction_contract_90d_mv(contract_name);
CREATE INDEX idx_contract_90d_mat_nbr ON order_transaction_contract_90d_mv(mat_nbr);
CREATE INDEX idx_contract_90d_both ON order_transaction_contract_90d_mv(contract_name, mat_nbr);
CREATE INDEX idx_contract_90d_corp_chain ON order_transaction_contract_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_contract_90d_corp_contract ON order_transaction_contract_90d_mv(cust_corp_chain_nbr, contract_name);

-- ============================================================================
-- 5. Corporate Chain 90-Day Aggregation
-- ============================================================================
-- Corporate chain aggregation with contract breakdown
DROP MATERIALIZED VIEW IF EXISTS order_transaction_corp_chain_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_corp_chain_90d_mv AS
SELECT
    ot.cust_corp_chain_nbr,
    ot.contract_name,
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.cust_corp_chain_nbr IS NOT NULL
GROUP BY ot.cust_corp_chain_nbr, ot.contract_name;

CREATE INDEX idx_corp_90d_corp ON order_transaction_corp_chain_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_corp_90d_contract ON order_transaction_corp_chain_90d_mv(contract_name);

-- ============================================================================
-- 8. Material Group 90-Day Aggregation
-- ============================================================================
DROP MATERIALIZED VIEW IF EXISTS order_transaction_material_group_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_material_group_90d_mv AS
SELECT
    m.scrm_mat_grp AS material_group,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount
FROM order_transactions ot
INNER JOIN materials m ON ot.mat_nbr = m.mat_nbr
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND m.scrm_mat_grp IS NOT NULL
GROUP BY m.scrm_mat_grp, ot.cust_corp_chain_nbr;

CREATE INDEX idx_mat_group_90d_group ON order_transaction_material_group_90d_mv(material_group);
CREATE INDEX idx_mat_group_90d_corp_chain ON order_transaction_material_group_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_mat_group_90d_corp_group ON order_transaction_material_group_90d_mv(cust_corp_chain_nbr, material_group);

-- ============================================================================
-- 9. Alt-Served by Material Status 90-Day Aggregation
-- ============================================================================
DROP MATERIALIZED VIEW IF EXISTS order_transaction_alt_served_status_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_alt_served_status_90d_mv AS
SELECT
    ot.material_status,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS alt_served_count,
    SUM(ot.total_order_qty) AS alt_served_units
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.alt_plant_serv_flg_key = TRUE
GROUP BY ot.material_status, ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_alt_status_90d_status ON order_transaction_alt_served_status_90d_mv(material_status);
CREATE INDEX idx_alt_status_90d_mat ON order_transaction_alt_served_status_90d_mv(mat_nbr);
CREATE INDEX idx_alt_status_90d_corp_chain ON order_transaction_alt_served_status_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_alt_status_90d_corp_status ON order_transaction_alt_served_status_90d_mv(cust_corp_chain_nbr, material_status);

-- ============================================================================
-- 11. Weekly Totals Aggregation (no grouping dimensions)
-- ============================================================================
-- Simple weekly totals for fast fulfillment metrics queries
DROP MATERIALIZED VIEW IF EXISTS order_transaction_weekly_totals_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_weekly_totals_mv AS
SELECT
    DATE_TRUNC('week', ot.ord_created_date)::date AS week_start,
    EXTRACT(ISOYEAR FROM ot.ord_created_date)::INTEGER AS year,
    EXTRACT(WEEK FROM ot.ord_created_date)::INTEGER AS week,
    ot.cust_corp_chain_nbr,
    SUM(ot.total_order_qty) AS total_ordered,
    SUM(ot.total_shipped_qty) AS total_shipped
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY DATE_TRUNC('week', ot.ord_created_date)::date,
         EXTRACT(ISOYEAR FROM ot.ord_created_date),
         EXTRACT(WEEK FROM ot.ord_created_date),
         ot.cust_corp_chain_nbr;

CREATE UNIQUE INDEX idx_weekly_totals_year_week ON order_transaction_weekly_totals_mv(year, week, cust_corp_chain_nbr);
CREATE INDEX idx_weekly_totals_week_start ON order_transaction_weekly_totals_mv(week_start);
CREATE INDEX idx_weekly_totals_corp_chain ON order_transaction_weekly_totals_mv(cust_corp_chain_nbr);
CREATE INDEX idx_weekly_totals_corp_week ON order_transaction_weekly_totals_mv(cust_corp_chain_nbr, week_start);

-- ============================================================================
-- 12. Plant 90-Day Aggregation
-- ============================================================================
-- Plant-level statistics with substitution and alt-serve counts
DROP MATERIALIZED VIEW IF EXISTS order_transaction_plant_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_plant_90d_mv AS
SELECT
    ot.plant_nbr,
    COUNT(DISTINCT ot.mat_nbr) AS total_materials,
    COUNT(DISTINCT CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN ot.mat_nbr END) AS materials_with_substitution,
    COUNT(DISTINCT CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN ot.mat_nbr END) AS materials_with_alt_serve,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY ot.plant_nbr;

CREATE UNIQUE INDEX idx_plant_90d_plant ON order_transaction_plant_90d_mv(plant_nbr);

-- ============================================================================
-- 13. Weekly Material Aggregation (for omit count tracking)
-- ============================================================================
-- Weekly × material aggregation for fill rate analysis
DROP MATERIALIZED VIEW IF EXISTS order_transaction_weekly_material_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_weekly_material_mv AS
SELECT
    DATE_TRUNC('week', ot.ord_created_date)::date AS week_start,
    EXTRACT(ISOYEAR FROM ot.ord_created_date)::INTEGER AS year,
    EXTRACT(WEEK FROM ot.ord_created_date)::INTEGER AS week,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_ordered,
    SUM(ot.total_shipped_qty) AS total_shipped,
    SUM(ot.sales_amount) AS total_sales_amount,
    COUNT(ot.id) AS total_lines,
    COUNT(CASE WHEN ot.total_shipped_qty >= ot.total_order_qty THEN 1 END) AS fully_shipped_lines,
    -- Alt-served metrics
    COUNT(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN 1 END) AS alt_served_count,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE THEN ot.total_order_qty ELSE 0 END) AS alt_served_units,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE AND UPPER(TRIM(ot.alt_serve_type)) = 'AUTO' THEN ot.total_order_qty ELSE 0 END) AS auto_alt_served_units,
    SUM(CASE WHEN ot.alt_plant_serv_flg_key = TRUE AND UPPER(TRIM(ot.alt_serve_type)) = 'MANUAL' THEN ot.total_order_qty ELSE 0 END) AS manual_alt_served_units,
    -- Substitution metrics
    COUNT(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN 1 END) AS substituted_count,
    SUM(CASE WHEN ot.substituted_mat_nbr IS NOT NULL THEN ot.total_order_qty ELSE 0 END) AS substituted_units,
    -- Perfect/Imperfect metrics
    COUNT(CASE WHEN ot.f_total_imperfect = 0 THEN 1 END) AS perfect_orders,
    COUNT(CASE WHEN ot.f_total_imperfect = 1 THEN 1 END) AS imperfect_orders,
    -- Imperfect flags breakdown
    COUNT(CASE WHEN ot.f_unpredictable_demand = 1 THEN 1 END) AS unpredictable_demand_count,
    COUNT(CASE WHEN ot.f_omit_inflation = 1 THEN 1 END) AS omit_inflation_count,
    COUNT(CASE WHEN ot.f_unaligned_forecast = 1 THEN 1 END) AS unaligned_forecast_count,
    COUNT(CASE WHEN ot.f_demand_imperfect = 1 THEN 1 END) AS demand_imperfect_count,
    CASE
        WHEN SUM(ot.total_order_qty) > 0
        THEN CAST(SUM(ot.total_shipped_qty) AS FLOAT) / CAST(SUM(ot.total_order_qty) AS FLOAT)
        ELSE 0.0
    END AS fill_rate
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.total_order_qty > 0
GROUP BY DATE_TRUNC('week', ot.ord_created_date)::date,
         EXTRACT(ISOYEAR FROM ot.ord_created_date),
         EXTRACT(WEEK FROM ot.ord_created_date),
         ot.mat_nbr,
         ot.cust_corp_chain_nbr;

CREATE INDEX idx_weekly_mat_week_start ON order_transaction_weekly_material_mv(week_start);
CREATE INDEX idx_weekly_mat_year_week ON order_transaction_weekly_material_mv(year, week);
CREATE INDEX idx_weekly_mat_mat_nbr ON order_transaction_weekly_material_mv(mat_nbr);
CREATE INDEX idx_weekly_mat_combined ON order_transaction_weekly_material_mv(year, week, mat_nbr);
CREATE INDEX idx_weekly_mat_year_week_fillrate ON order_transaction_weekly_material_mv(year, week) INCLUDE (fill_rate, mat_nbr);
CREATE INDEX idx_weekly_mat_corp_chain ON order_transaction_weekly_material_mv(cust_corp_chain_nbr);
CREATE INDEX idx_weekly_mat_corp_week ON order_transaction_weekly_material_mv(cust_corp_chain_nbr, week_start);

-- ============================================================================
-- 14. Weekly Material Omit Summary (pre-aggregated for fastest queries)
-- ============================================================================
-- Pre-aggregate omit counts by week for instant retrieval
-- This eliminates the need to scan millions of rows at query time
DROP MATERIALIZED VIEW IF EXISTS order_transaction_weekly_omit_summary_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_weekly_omit_summary_mv AS
WITH material_weekly_fill_rates AS (
    SELECT
        EXTRACT(ISOYEAR FROM ot.ord_created_date)::INTEGER AS year,
        EXTRACT(WEEK FROM ot.ord_created_date)::INTEGER AS week,
        ot.mat_nbr,
        CASE
            WHEN SUM(ot.total_order_qty) > 0
            THEN CAST(SUM(ot.total_shipped_qty) AS FLOAT) / CAST(SUM(ot.total_order_qty) AS FLOAT)
            ELSE 0.0
        END AS fill_rate
    FROM order_transactions ot
    WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
      AND ot.total_order_qty > 0
    GROUP BY EXTRACT(ISOYEAR FROM ot.ord_created_date),
             EXTRACT(WEEK FROM ot.ord_created_date),
             ot.mat_nbr
)
SELECT
    year,
    week,
    COUNT(DISTINCT CASE WHEN fill_rate < 0.85 THEN mat_nbr END) AS excess_omits_count,
    COUNT(DISTINCT CASE WHEN fill_rate >= 0.85 AND fill_rate < 1.0 THEN mat_nbr END) AS allowed_omits_count,
    COUNT(DISTINCT CASE WHEN fill_rate >= 1.0 THEN mat_nbr END) AS no_omits_count
FROM material_weekly_fill_rates
GROUP BY year, week;

CREATE UNIQUE INDEX idx_weekly_omit_summary_year_week ON order_transaction_weekly_omit_summary_mv(year, week);

-- ============================================================================
-- 15. Alt-Served with Material Cost (denormalized for fast queries)
-- ============================================================================
-- Alt-served orders with material cost pre-joined for cost range queries
DROP MATERIALIZED VIEW IF EXISTS order_transaction_alt_served_cost_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_alt_served_cost_90d_mv AS
SELECT
    ot.material_status,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    m.cost_per_unit,
    CASE
        WHEN m.cost_per_unit >= 0 AND m.cost_per_unit <= 15 THEN 0
        WHEN m.cost_per_unit >= 16 AND m.cost_per_unit <= 50 THEN 1
        WHEN m.cost_per_unit >= 51 AND m.cost_per_unit <= 100 THEN 2
        WHEN m.cost_per_unit >= 101 AND m.cost_per_unit <= 150 THEN 3
        WHEN m.cost_per_unit >= 151 AND m.cost_per_unit <= 200 THEN 4
        WHEN m.cost_per_unit > 200 THEN 5
        ELSE NULL
    END AS cost_range,
    SUM(ot.total_order_qty) AS total_order_qty
FROM order_transactions ot
INNER JOIN materials m ON ot.mat_nbr = m.mat_nbr
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.alt_plant_serv_flg_key = TRUE
GROUP BY ot.material_status, ot.mat_nbr, ot.cust_corp_chain_nbr, m.cost_per_unit, cost_range;

CREATE INDEX idx_alt_cost_status_range ON order_transaction_alt_served_cost_90d_mv(material_status, cost_range);
CREATE INDEX idx_alt_cost_range ON order_transaction_alt_served_cost_90d_mv(cost_range);
CREATE INDEX idx_alt_cost_mat_nbr ON order_transaction_alt_served_cost_90d_mv(mat_nbr);
CREATE INDEX idx_alt_cost_status_range_mat ON order_transaction_alt_served_cost_90d_mv(material_status, cost_range, mat_nbr);
CREATE INDEX idx_alt_cost_corp_chain ON order_transaction_alt_served_cost_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_alt_cost_corp_status ON order_transaction_alt_served_cost_90d_mv(cust_corp_chain_nbr, material_status);

DROP MATERIALIZED VIEW IF EXISTS order_transaction_state_material_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_state_material_90d_mv AS
SELECT
    c.state,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount
FROM order_transactions ot
INNER JOIN customers c ON ot.cust_nbr = c.cust_nbr
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND c.state IS NOT NULL
  AND c.state != ''
GROUP BY c.state, ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_state_mat_90d_state ON order_transaction_state_material_90d_mv(state);
CREATE INDEX idx_state_mat_90d_mat ON order_transaction_state_material_90d_mv(mat_nbr);
CREATE INDEX idx_state_mat_90d_both ON order_transaction_state_material_90d_mv(state, mat_nbr);
CREATE INDEX idx_state_mat_90d_corp_chain ON order_transaction_state_material_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_state_mat_90d_corp_state ON order_transaction_state_material_90d_mv(cust_corp_chain_nbr, state);

-- ============================================================================
-- 2. Class of Trade × Material 90-Day Aggregation
-- ============================================================================
-- Enables filtering on get_class_of_trade_units() when global filters are applied

DROP MATERIALIZED VIEW IF EXISTS order_transaction_class_of_trade_material_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_class_of_trade_material_90d_mv AS
SELECT
    ot.class_of_trade_desc,
    ot.class_of_trade_nbr,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.class_of_trade_desc IS NOT NULL
  AND ot.class_of_trade_desc != ''
GROUP BY ot.class_of_trade_desc, ot.class_of_trade_nbr, ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_cot_mat_90d_cot ON order_transaction_class_of_trade_material_90d_mv(class_of_trade_desc);
CREATE INDEX idx_cot_mat_90d_mat ON order_transaction_class_of_trade_material_90d_mv(mat_nbr);
CREATE INDEX idx_cot_mat_90d_both ON order_transaction_class_of_trade_material_90d_mv(class_of_trade_desc, mat_nbr);
CREATE INDEX idx_cot_mat_90d_corp_chain ON order_transaction_class_of_trade_material_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_cot_mat_90d_corp_cot ON order_transaction_class_of_trade_material_90d_mv(cust_corp_chain_nbr, class_of_trade_desc);

-- ============================================================================
-- 3. Alt-Served Plant × Material 90-Day Aggregation
-- ============================================================================
-- Enables filtering on get_alt_served_breakdown_analysis() plant breakdown when global filters are applied

DROP MATERIALIZED VIEW IF EXISTS order_transaction_alt_served_plant_material_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_alt_served_plant_material_90d_mv AS
SELECT
    ot.plant_nbr,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS alt_served_count,
    SUM(ot.total_order_qty) AS alt_served_units
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.alt_plant_serv_flg_key = TRUE
GROUP BY ot.plant_nbr, ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_alt_plant_mat_90d_plant ON order_transaction_alt_served_plant_material_90d_mv(plant_nbr);
CREATE INDEX idx_alt_plant_mat_90d_mat ON order_transaction_alt_served_plant_material_90d_mv(mat_nbr);
CREATE INDEX idx_alt_plant_mat_90d_both ON order_transaction_alt_served_plant_material_90d_mv(plant_nbr, mat_nbr);
CREATE INDEX idx_alt_plant_mat_90d_corp_chain ON order_transaction_alt_served_plant_material_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_alt_plant_mat_90d_corp_plant ON order_transaction_alt_served_plant_material_90d_mv(cust_corp_chain_nbr, plant_nbr);

-- ============================================================================
-- 4. Alt-Served Class of Trade × Material 90-Day Aggregation
-- ============================================================================
-- Enables filtering on get_alt_served_breakdown_analysis() class of trade breakdown when global filters are applied

DROP MATERIALIZED VIEW IF EXISTS order_transaction_alt_served_class_of_trade_material_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_alt_served_class_of_trade_material_90d_mv AS
SELECT
    ot.class_of_trade_desc,
    ot.class_of_trade_nbr,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS alt_served_count,
    SUM(ot.total_order_qty) AS alt_served_units
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.alt_plant_serv_flg_key = TRUE
  AND ot.class_of_trade_desc IS NOT NULL
  AND ot.class_of_trade_desc != ''
GROUP BY ot.class_of_trade_desc, ot.class_of_trade_nbr, ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_alt_cot_mat_90d_cot ON order_transaction_alt_served_class_of_trade_material_90d_mv(class_of_trade_desc);
CREATE INDEX idx_alt_cot_mat_90d_mat ON order_transaction_alt_served_class_of_trade_material_90d_mv(mat_nbr);
CREATE INDEX idx_alt_cot_mat_90d_both ON order_transaction_alt_served_class_of_trade_material_90d_mv(class_of_trade_desc, mat_nbr);
CREATE INDEX idx_alt_cot_mat_90d_corp_chain ON order_transaction_alt_served_class_of_trade_material_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_alt_cot_mat_90d_corp_cot ON order_transaction_alt_served_class_of_trade_material_90d_mv(cust_corp_chain_nbr, class_of_trade_desc);

-- ============================================================================
-- Corp Chain to Materials Array Mapping (for global filter)
-- ============================================================================
-- Maps each corporate chain to an array of materials they've ordered in last 90 days.
-- Used by the cust_corp_chain global filter to efficiently find materials ordered by a customer.

DROP MATERIALIZED VIEW IF EXISTS corp_chain_materials_90d_mv CASCADE;

CREATE MATERIALIZED VIEW corp_chain_materials_90d_mv AS
SELECT
    ot.cust_corp_chain_nbr,
    ARRAY_AGG(DISTINCT ot.mat_nbr) AS mat_nbrs
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.cust_corp_chain_nbr IS NOT NULL
  AND ot.mat_nbr IS NOT NULL
GROUP BY ot.cust_corp_chain_nbr;

CREATE UNIQUE INDEX idx_corp_materials_corp ON corp_chain_materials_90d_mv(cust_corp_chain_nbr);

-- ============================================================================
-- Sales Group × Material 90-Day Aggregation
-- ============================================================================
-- Enables MaterialWithSalesGroupSalesView to read pre-aggregated data
-- instead of scanning the base order_transactions table.

DROP MATERIALIZED VIEW IF EXISTS order_transaction_sales_group_material_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_sales_group_material_90d_mv AS
SELECT
    ot.sales_group,
    ot.mat_nbr,
    ot.cust_corp_chain_nbr,
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.sales_group IS NOT NULL
  AND ot.sales_group != ''
GROUP BY ot.sales_group, ot.mat_nbr, ot.cust_corp_chain_nbr;

CREATE INDEX idx_sg_mat_90d_sg ON order_transaction_sales_group_material_90d_mv(sales_group);
CREATE INDEX idx_sg_mat_90d_mat ON order_transaction_sales_group_material_90d_mv(mat_nbr);
CREATE INDEX idx_sg_mat_90d_both ON order_transaction_sales_group_material_90d_mv(sales_group, mat_nbr);
CREATE INDEX idx_sg_mat_90d_corp_chain ON order_transaction_sales_group_material_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_sg_mat_90d_corp_sg ON order_transaction_sales_group_material_90d_mv(cust_corp_chain_nbr, sales_group);

-- ============================================================================
-- Sales Group × Corporate Chain 90-Day Aggregation
-- ============================================================================
-- Enables CorporateWithSalesGroupSalesView to read pre-aggregated data
-- instead of scanning the base order_transactions table.

DROP MATERIALIZED VIEW IF EXISTS order_transaction_sales_group_corp_chain_90d_mv CASCADE;

CREATE MATERIALIZED VIEW order_transaction_sales_group_corp_chain_90d_mv AS
SELECT
    ot.cust_corp_chain_nbr,
    ot.sales_group,
    COUNT(ot.id) AS total_orders,
    SUM(ot.total_order_qty) AS total_order_qty,
    SUM(ot.total_shipped_qty) AS total_shipped_qty,
    SUM(ot.sales_amount) AS total_sales_amount
FROM order_transactions ot
WHERE ot.ord_created_date >= CURRENT_DATE - INTERVAL '90 days'
  AND ot.cust_corp_chain_nbr IS NOT NULL
GROUP BY ot.cust_corp_chain_nbr, ot.sales_group;

CREATE INDEX idx_sg_corp_90d_corp ON order_transaction_sales_group_corp_chain_90d_mv(cust_corp_chain_nbr);
CREATE INDEX idx_sg_corp_90d_sg ON order_transaction_sales_group_corp_chain_90d_mv(sales_group);
