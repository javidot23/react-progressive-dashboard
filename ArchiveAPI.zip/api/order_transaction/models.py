from django.db import models
from django.db.models import Q

from api.customer.models import Customer
from api.customer_business_unit.models import CustomerBusinessUnit
from api.customer_company.models import CustomerCompany
from api.customer_corp_chain.models import CustomerCorpChain
from api.customer_location.models import CustomerLocation
from api.material.models import Material
from api.plant.models import Plant


class OrderTransaction(models.Model):
    """Model representing an order transaction."""

    class AltServeTypes(models.TextChoices):
        AUTO = "AUTO", "Auto"
        MANUAL = "MANUAL", "Manual",
        NO_ALT_SERVE = "NO_ALT_SERVE", "No Alternate Serve"

    sales_doc_nbr = models.CharField(
        max_length=255, null=True
    )  # Order ID from Databricks
    sales_doc_itm_nbr = models.CharField(
        max_length=255,
        null=True
    )  # Order line item number from Databricks, linking to the sales_doc_nbr with material ordered
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        related_name="order_transactions"
    )
    substituted_material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="substituted_mat_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="substituted_order_transactions"
    )
    total_order_qty = models.IntegerField(null=True, default=0)
    ord_created_date = models.DateField()
    cust_nbr = models.ForeignKey(
        Customer,
        to_field="cust_nbr",
        db_column="cust_nbr",
        on_delete=models.CASCADE,
        default=None,
        null=True
    )
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.CASCADE,
        related_name="order_transactions"
    )

    total_shipped_qty = models.IntegerField(default=0, null=True)
    sales_amount = models.DecimalField(
        max_digits=20,
        decimal_places=2,
        default=0.00,
        null=True,
    )  # Total sales amount for the order line item in USD
    alt_plant_serv_flg_key = models.BooleanField(
        default=False
    )  # True if the order was shipped from an alternate plant, TODO: Rename to alt_serve_flag
    contract_name = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        default=""
    )

    class_of_trade_nbr = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        default=""
    )  # Class of trade id
    class_of_trade_desc = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        default=""
    )  # Class of trade description/name

    ar_plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="ar_plant_nbr",
        on_delete=models.CASCADE,
        related_name="ar_order_transactions",
        null=True,
        blank=True,
        default=None
    )  # Primary Plant
    material_status = models.CharField(max_length=255, null=True, blank=True)
    sub_reas_code_name = models.CharField(max_length=255, null=True, blank=True)  # Reason of substitution
    alt_serve_type = models.CharField(
        max_length=255,
        choices=AltServeTypes.choices,
        null=True,
        blank=True
    )
    contract_nbr = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        default=""
    )
    f_total_imperfect = models.IntegerField(default=0, null=True)
    f_unpredictable_demand = models.IntegerField(default=0, null=True)
    f_unaligned_forecast = models.IntegerField(default=0, null=True)
    f_demand_imperfect = models.IntegerField(default=0, null=True)
    f_omit_inflation = models.IntegerField(default=0, null=True)
    f_altserve_certified = models.IntegerField(default=0, null=True)
    f_credit_and_rebill = models.IntegerField(default=0, null=True)
    f_customer_allocation_blocked = models.IntegerField(default=0, null=True)
    f_customer_substitutions_opt_out = models.IntegerField(default=0, null=True)
    f_damaged = models.IntegerField(default=0, null=True)
    f_delivery_early = models.IntegerField(default=0, null=True)
    f_delivery_failed = models.IntegerField(default=0, null=True)
    f_delivery_late = models.IntegerField(default=0, null=True)
    f_fail_to_pick = models.IntegerField(default=0, null=True)
    f_late_fulfillment = models.IntegerField(default=0, null=True)
    f_ndc_delays = models.IntegerField(default=0, null=True)
    f_no_scan = models.IntegerField(default=0, null=True)
    f_overage_or_shortage = models.IntegerField(default=0, null=True)
    f_receiving_delays = models.IntegerField(default=0, null=True)
    f_rejection = models.IntegerField(default=0, null=True)
    f_substitutions_present = models.IntegerField(default=0, null=True)
    f_supplier_backorder = models.IntegerField(default=0, null=True)
    f_supplier_delivery_problem = models.IntegerField(default=0, null=True)
    f_unplaced_po = models.IntegerField(default=0, null=True)
    omit_indicator = models.IntegerField(default=0, null=True)
    f_supply_imperfect = models.IntegerField(default=0, null=True)
    f_order_imperfect = models.IntegerField(default=0, null=True)
    f_distribution_imperfect = models.IntegerField(default=0, null=True)
    f_delivery_imperfect = models.IntegerField(default=0, null=True)
    r_condition = models.IntegerField(default=0, null=True)
    r_cost = models.IntegerField(default=0, null=True)
    r_customer = models.IntegerField(default=0, null=True)
    r_place = models.IntegerField(default=0, null=True)
    r_product = models.IntegerField(default=0, null=True)
    r_quantity = models.IntegerField(default=0, null=True)
    r_time = models.IntegerField(default=0, null=True)
    cust_location_nbr = models.ForeignKey(
        CustomerLocation,
        to_field="cust_location_nbr",
        db_column="cust_location_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    cust_bus_unit_nbr = models.ForeignKey(
        CustomerBusinessUnit,
        to_field="cust_bus_unit_nbr",
        db_column="cust_bus_unit_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    cust_company_nbr = models.ForeignKey(
        CustomerCompany,
        to_field="cust_company_nbr",
        db_column="cust_company_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    cust_corp_chain_nbr = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    original_sales_doc_itm_nbr = models.CharField(max_length=255, null=True, blank=True)
    sales_group = models.CharField(max_length=255, null=True, blank=True)
    program = models.CharField(max_length=255, null=True, blank=True)
    program_description = models.CharField(max_length=255, null=True, blank=True)
    fts_invoice_quantity = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True)
    fts_total_omits_quantity = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True)
    fts_lines_fully_filled = models.IntegerField(null=True, blank=True)
    fts_lines_ordered = models.IntegerField(null=True, blank=True)
    fts_mfr_line_outs = models.IntegerField(null=True, blank=True)
    fts_adj_lines_incl_72_hours = models.IntegerField(null=True, blank=True)
    fts_adj_service_lines = models.IntegerField(null=True, blank=True)
    fts_lines_temp_out_excp = models.IntegerField(null=True, blank=True)
    fts_mfr_outs_qty = models.DecimalField(max_digits=26, decimal_places=3, null=True, blank=True)
    fts_adj_qty = models.DecimalField(max_digits=23, decimal_places=3, null=True, blank=True)
    fts_adj_qty_incl_72_hours = models.DecimalField(max_digits=23, decimal_places=3, null=True, blank=True)
    fts_whse_temp_out_excp_qty = models.DecimalField(max_digits=22, decimal_places=3, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        db_table = "order_transactions"
        verbose_name = "Order Transaction"
        verbose_name_plural = "Order Transactions"
        unique_together = ("sales_doc_nbr", "sales_doc_itm_nbr")
        indexes = [
            models.Index(
                fields=["alt_plant_serv_flg_key"],
                name="idx_alt_plant_serv_true",
                condition=Q(alt_plant_serv_flg_key=True),
            ),
            models.Index(
                fields=["substituted_material"],
                name="idx_sub_mat_not_null",
                condition=Q(substituted_material__isnull=False),
            ),
            models.Index(
                fields=["-ord_created_date"],
                name="idx_order_trs_ord_created_date",
            )
        ]
