CREATE INDEX IF NOT EXISTS idx_order_trans_weekly_omit
ON order_transactions(ord_created_date, mat_nbr)
WHERE total_order_qty > 0;

-- Index for date range queries with material lookups
-- Used by various queries that need to aggregate by material over time
CREATE INDEX IF NOT EXISTS idx_order_trans_date_material
ON order_transactions(ord_created_date, mat_nbr)
INCLUDE (total_order_qty, total_shipped_qty);

-- ============================================================================
-- ADDITIONAL OPTIMIZATIONS FOR SPECIFIC QUERIES
-- ============================================================================

-- Index for plant-based queries (PlantOrderStatsView)
-- Supports efficient plant aggregation with substitution/alt-serve checks
CREATE INDEX IF NOT EXISTS idx_order_trans_plant_nbr
ON order_transactions(plant_nbr)
INCLUDE (substituted_mat_nbr, alt_plant_serv_flg_key);

-- Partial index for material_status queries (MaterialStatusListView)
-- Dramatically speeds up DISTINCT material_status queries
CREATE INDEX IF NOT EXISTS idx_order_trans_material_status_present
ON order_transactions(material_status)
WHERE material_status IS NOT NULL AND material_status != '';

-- Index for alt-served queries with material status
-- Optimizes queries filtering on alt_plant_serv_flg_key
CREATE INDEX IF NOT EXISTS idx_order_trans_alt_served_status
ON order_transactions(alt_plant_serv_flg_key, ord_created_date, material_status)
WHERE alt_plant_serv_flg_key = TRUE;

-- ============================================================================
-- MAINTENANCE
-- ============================================================================

-- These indexes should be rebuilt periodically (monthly recommended):
-- REINDEX INDEX CONCURRENTLY idx_order_trans_weekly_omit;
-- REINDEX INDEX CONCURRENTLY idx_order_trans_date_material;
-- REINDEX INDEX CONCURRENTLY idx_order_trans_plant_nbr;
-- REINDEX INDEX CONCURRENTLY idx_order_trans_material_status_present;
-- REINDEX INDEX CONCURRENTLY idx_order_trans_alt_served_status;
