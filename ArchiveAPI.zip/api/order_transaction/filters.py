from django_filters.rest_framework import FilterSet, filters

from api.global_filters import GlobalFilterMixin, GlobalFilterWithDirectCorpChainMixin
from api.material.models import Material
from api.order_transaction.models import OrderTransaction


class OrderTransactionFilter(GlobalFilterWithDirectCorpChainMixin, FilterSet):
    """
    Filter set for order transactions with comprehensive filtering options.
    Includes global filters: supplier, product_family, therapeutic_class, buyer,
    category_manager, material, gcn, and formulary.
    The cust_corp_chain filter uses DirectCorpChainFilter to filter directly
    on the cust_corp_chain_nbr FK field, rather than filtering through materials.
    This ensures transactions are filtered by the actual customer that placed
    the order, not just by materials that customer has ordered.
    """

    sales_doc_nbr = filters.CharFilter(field_name='sales_doc_nbr', lookup_expr='icontains')
    alt_serve = filters.BooleanFilter(field_name='alt_plant_serv_flg_key')

    material_id = filters.CharFilter(field_name='material__id', lookup_expr='exact')
    material_name = filters.CharFilter(field_name='material__name', lookup_expr='icontains')
    material_mat_nbr = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='icontains')

    vendor_nbr = filters.CharFilter(field_name='material__vendor__vendor_nbr', lookup_expr='exact')

    substituted_material_id = filters.CharFilter(field_name='substituted_material__id', lookup_expr='exact')
    substituted_material_name = filters.CharFilter(field_name='substituted_material__name', lookup_expr='icontains')
    substituted_material_mat_nbr = filters.CharFilter(field_name='substituted_material__mat_nbr',
                                                      lookup_expr='icontains')

    sub_vendor_nbr = filters.CharFilter(field_name='substituted_material__vendor__vendor_nbr',
                                        lookup_expr='exact')

    plant_nbr = filters.CharFilter(field_name='plant__plant_nbr', lookup_expr='exact')
    plant_name = filters.CharFilter(field_name='plant__name', lookup_expr='icontains')

    ar_plant_nbr = filters.CharFilter(field_name='ar_plant__plant_nbr', lookup_expr='exact')
    ar_plant_name = filters.CharFilter(field_name='ar_plant__name', lookup_expr='icontains')

    cust_nbr = filters.CharFilter(field_name='cust_nbr__id', lookup_expr='exact')

    ord_created_date = filters.DateFilter(field_name='ord_created_date')
    ord_created_date_from = filters.DateFilter(field_name='ord_created_date', lookup_expr='gte')
    ord_created_date_to = filters.DateFilter(field_name='ord_created_date', lookup_expr='lte')

    total_order_qty_min = filters.NumberFilter(field_name='total_order_qty', lookup_expr='gte')
    total_order_qty_max = filters.NumberFilter(field_name='total_order_qty', lookup_expr='lte')
    sales_qty_min = filters.NumberFilter(field_name='total_shipped_qty', lookup_expr='gte')
    sales_qty_max = filters.NumberFilter(field_name='total_shipped_qty', lookup_expr='lte')

    contract_name = filters.CharFilter(field_name='contract_name', lookup_expr='icontains')
    corporate_chain_name = filters.CharFilter(field_name='cust_corp_chain_nbr__name', lookup_expr='icontains')

    has_substituted_material = filters.BooleanFilter(field_name='substituted_material', lookup_expr='isnull',
                                                     exclude=True)
    material_status = filters.CharFilter(field_name='material_status', lookup_expr='icontains')

    class Meta:
        model = OrderTransaction
        fields = [
            'sales_doc_nbr', 'alt_plant_serv_flg_key',
            'material_name', 'material_mat_nbr',
            'plant', 'plant_name', 'plant_nbr', 'ar_plant', 'ar_plant__name',
            'cust_nbr',
            'ord_created_date', 'ord_created_date_from', 'ord_created_date_to',
            'total_order_qty_min', 'total_order_qty_max',
            'sales_qty_min', 'sales_qty_max',
            'contract_name', 'corporate_chain_name',
            'has_substituted_material'
        ]


class FailToSupplyPlantFilter(FilterSet):
    prxo_missed_lines_min = filters.NumberFilter(field_name='prxo_missed_lines', lookup_expr='gte')
    prxo_missed_lines_max = filters.NumberFilter(field_name='prxo_missed_lines', lookup_expr='lte')
    pgen_missed_lines_min = filters.NumberFilter(field_name='pgen_missed_lines', lookup_expr='gte')
    pgen_missed_lines_max = filters.NumberFilter(field_name='pgen_missed_lines', lookup_expr='lte')
    total_missed_lines_min = filters.NumberFilter(field_name='total_missed_lines', lookup_expr='gte')
    total_missed_lines_max = filters.NumberFilter(field_name='total_missed_lines', lookup_expr='lte')
    total_missed_lines_pct_min = filters.NumberFilter(field_name='total_missed_lines_pct', lookup_expr='gte')
    total_missed_lines_pct_max = filters.NumberFilter(field_name='total_missed_lines_pct', lookup_expr='lte')
    outbound_fill_rate_min = filters.NumberFilter(field_name='outbound_fill_rate', lookup_expr='gte')
    outbound_fill_rate_max = filters.NumberFilter(field_name='outbound_fill_rate', lookup_expr='lte')
    service_level_min = filters.NumberFilter(field_name='service_level', lookup_expr='gte')
    service_level_max = filters.NumberFilter(field_name='service_level', lookup_expr='lte')
    omit_qty_min = filters.NumberFilter(field_name='omit_qty', lookup_expr='gte')
    omit_qty_max = filters.NumberFilter(field_name='omit_qty', lookup_expr='lte')
    demand_qty_min = filters.NumberFilter(field_name='demand_qty', lookup_expr='gte')
    demand_qty_max = filters.NumberFilter(field_name='demand_qty', lookup_expr='lte')
    ordered_lines_min = filters.NumberFilter(field_name='total_lines_ordered', lookup_expr='gte')
    ordered_lines_max = filters.NumberFilter(field_name='total_lines_ordered', lookup_expr='lte')

    class Meta:
        model = OrderTransaction
        fields = []


class FailToSupplyMaterialFilter(FilterSet):
    """Post-aggregation filters for the low-outbound / FTS materials list."""

    outbound_fill_rate_min = filters.NumberFilter(field_name='outbound_fill_rate', lookup_expr='gte')
    outbound_fill_rate_max = filters.NumberFilter(field_name='outbound_fill_rate', lookup_expr='lte')
    unfilled_quantity_min = filters.NumberFilter(field_name='unfilled_quantity', lookup_expr='gte')
    unfilled_quantity_max = filters.NumberFilter(field_name='unfilled_quantity', lookup_expr='lte')
    omits_qty_min = filters.NumberFilter(field_name='omits_qty', lookup_expr='gte')
    omits_qty_max = filters.NumberFilter(field_name='omits_qty', lookup_expr='lte')
    omits_qty_last_month_min = filters.NumberFilter(field_name='omits_qty_last_month', lookup_expr='gte')
    omits_qty_last_month_max = filters.NumberFilter(field_name='omits_qty_last_month', lookup_expr='lte')
    sales_amount_min = filters.NumberFilter(field_name='sales_amount', lookup_expr='gte')
    sales_amount_max = filters.NumberFilter(field_name='sales_amount', lookup_expr='lte')
    sales_qty_min = filters.NumberFilter(field_name='sales_qty', lookup_expr='gte')
    sales_qty_max = filters.NumberFilter(field_name='sales_qty', lookup_expr='lte')
    total_demand_min = filters.NumberFilter(field_name='total_demand', lookup_expr='gte')
    total_demand_max = filters.NumberFilter(field_name='total_demand', lookup_expr='lte')
    prxo_service_level_min = filters.NumberFilter(field_name='prxo_service_level', lookup_expr='gte')
    prxo_service_level_max = filters.NumberFilter(field_name='prxo_service_level', lookup_expr='lte')
    pharmagen_service_level_min = filters.NumberFilter(field_name='pharmagen_service_level', lookup_expr='gte')
    pharmagen_service_level_max = filters.NumberFilter(field_name='pharmagen_service_level', lookup_expr='lte')
    forecast_qty_28day_min = filters.NumberFilter(field_name='forecast_qty_28day', lookup_expr='gte')
    forecast_qty_28day_max = filters.NumberFilter(field_name='forecast_qty_28day', lookup_expr='lte')
    material_status = filters.CharFilter(field_name='material__xplant_mat_stat', lookup_expr='iexact')
    mat_nbr = filters.CharFilter(field_name='material_id', lookup_expr='iexact')
    material_name = filters.CharFilter(field_name='material__name', lookup_expr='icontains')
    material_ndc = filters.CharFilter(field_name='material__ndc', lookup_expr='icontains')

    class Meta:
        model = OrderTransaction
        fields = []


class InventoryMaterialPlantCustomerFilter(FilterSet):
    """Post-aggregation filters for inventory customer drilldown."""

    omit_qty_min = filters.NumberFilter(field_name='omit_qty', lookup_expr='gte')
    omit_qty_max = filters.NumberFilter(field_name='omit_qty', lookup_expr='lte')
    imperfect_lines_min = filters.NumberFilter(field_name='imperfect_lines', lookup_expr='gte')
    imperfect_lines_max = filters.NumberFilter(field_name='imperfect_lines', lookup_expr='lte')
    sales_amount_min = filters.NumberFilter(field_name='sales_amount', lookup_expr='gte')
    sales_amount_max = filters.NumberFilter(field_name='sales_amount', lookup_expr='lte')
    order_qty_min = filters.NumberFilter(field_name='order_qty', lookup_expr='gte')
    order_qty_max = filters.NumberFilter(field_name='order_qty', lookup_expr='lte')
    shipped_qty_min = filters.NumberFilter(field_name='shipped_qty', lookup_expr='gte')
    shipped_qty_max = filters.NumberFilter(field_name='shipped_qty', lookup_expr='lte')
    outbound_fill_rate_min = filters.NumberFilter(field_name='outbound_fill_rate', lookup_expr='gte')
    outbound_fill_rate_max = filters.NumberFilter(field_name='outbound_fill_rate', lookup_expr='lte')

    class Meta:
        model = OrderTransaction
        fields = []


class UnfilledMaterialsFilter(GlobalFilterMixin, FilterSet):
    """
    FilterSet for Unfilled Materials list (Material queryset with OT annotations).
    cust_corp_chain is handled in the view/service via OrderTransactionMaterial90dMV,
    matching material-omit-counts-last-three-months.
    """

    unfilled_quantity_min = filters.NumberFilter(field_name="unfilled_quantity", lookup_expr="gte")
    unfilled_quantity_max = filters.NumberFilter(field_name="unfilled_quantity", lookup_expr="lte")
    ordered_quantity_min = filters.NumberFilter(field_name="ordered_quantity", lookup_expr="gte")
    ordered_quantity_max = filters.NumberFilter(field_name="ordered_quantity", lookup_expr="lte")
    outbound_fill_rate_min = filters.NumberFilter(field_name="outbound_fill_rate", lookup_expr="gte")
    outbound_fill_rate_max = filters.NumberFilter(field_name="outbound_fill_rate", lookup_expr="lte")
    saleable_qty_on_hand_min = filters.NumberFilter(field_name="saleable_qty_on_hand", lookup_expr="gte")
    saleable_qty_on_hand_max = filters.NumberFilter(field_name="saleable_qty_on_hand", lookup_expr="lte")
    on_order_qty_min = filters.NumberFilter(field_name="on_order_qty", lookup_expr="gte")
    on_order_qty_max = filters.NumberFilter(field_name="on_order_qty", lookup_expr="lte")
    forecast_qty_7day_min = filters.NumberFilter(field_name="forecast_qty_7day", lookup_expr="gte")
    forecast_qty_7day_max = filters.NumberFilter(field_name="forecast_qty_7day", lookup_expr="lte")

    class Meta:
        model = Material
        fields = []

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Applied on OT MV corp_chain in the service, not via materials-ordered-by-customer.
        self.filters.pop("cust_corp_chain", None)
