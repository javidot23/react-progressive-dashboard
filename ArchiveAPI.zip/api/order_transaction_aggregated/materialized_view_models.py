"""
Materialized View Models for Order Transaction Aggregated.

These models represent pre-aggregated data stored in PostgreSQL materialized views.
They use managed=False to indicate Django should not create/migrate these tables.
ForeignKey relationships enable filtering on related model fields (e.g., material__vendor__name).
"""

from django.db import models

from api.material.models import Material


class OtAggMonthlyMaterialMV(models.Model):
    """
    Monthly aggregation by material, pre-computed from order_transactions_aggregated.
    Materialized view: ot_agg_monthly_material_mv

    Collapses ~82M rows (keyed by year/month/customer/material/sales_group/state)
    to ~1M rows (keyed by year/month/material) for fast dashboard queries.
    """
    year = models.IntegerField()
    month = models.IntegerField()
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.DO_NOTHING,
        related_name="+",
    )
    total_order_qty = models.BigIntegerField()
    total_shipped_qty = models.BigIntegerField()
    sales_amount = models.DecimalField(max_digits=20, decimal_places=2)

    class Meta:
        managed = False
        db_table = "ot_agg_monthly_material_mv"
