from django.urls import path

from .views import (
    FtsMaterialExposureView,
    OrderTransactionAggregatedListView,
    SalesComparisonByCustomerView,
    SalesComparisonByMaterialView,
    SalesComparisonByMonthView,
    SalesComparisonBySalesGroupView,
    SalesComparisonByStateView,
    SalesTimelineView,
    SalesYtdView,
)

app_name = "order-transaction-aggregated"

urlpatterns = [
    path(
        "last-two-years/",
        OrderTransactionAggregatedListView.as_view(),
        name="last_two_years",
    ),
    path(
        "sales-comparison-by-month/",
        SalesComparisonByMonthView.as_view(),
        name="sales-comparison-by-month",
    ),
    path(
        "sales-timeline/",
        SalesTimelineView.as_view(),
        name="sales-timeline",
    ),
    path(
        "sales-ytd/",
        SalesYtdView.as_view(),
        name="sales-ytd",
    ),
    path(
        "sales-comparison/by-sales-group/",
        SalesComparisonBySalesGroupView.as_view(),
        name="sales-comparison-by-sales-group",
    ),
    path(
        "sales-comparison/by-state/",
        SalesComparisonByStateView.as_view(),
        name="sales-comparison-by-state",
    ),
    path(
        "sales-comparison/by-material/",
        SalesComparisonByMaterialView.as_view(),
        name="sales-comparison-by-material",
    ),
    path(
        "sales-comparison/by-customer/",
        SalesComparisonByCustomerView.as_view(),
        name="sales-comparison-by-customer",
    ),
    path(
        "fail-to-supply/material-exposure/",
        FtsMaterialExposureView.as_view(),
        name="fail-to-supply-material-exposure",
    ),
]
