from django.db import IntegrityError
from tests.BaseTestCase import BaseTestCase

from api.order_transaction_aggregated.models import OrderTransactionAggregated
from tests.TestDataFactory import TestDataFactory


class TestOrderTransactionAggregatedModel(BaseTestCase):
    def setUp(self):
        self.this_year = 2025
        self.last_year = 2024
        self.total_order_qty = 5500
        self.total_shipped_qty = 5000
        self.substituted_count = 100
        self.alt_served_count = 50
        self.material = TestDataFactory.create_material()
        self.customer = TestDataFactory.create_customer_corp_chain()

    def test_order_transaction_aggregated_creation(self):
        """Test basic creation of OrderTransactionAggregated"""
        aggregated = OrderTransactionAggregated.objects.create(
            year=self.this_year,
            month=1,
            total_order_qty=self.total_order_qty,
            total_shipped_qty=self.total_shipped_qty
        )

        self.assertEqual(aggregated.year, self.this_year)
        self.assertEqual(aggregated.month, 1)
        self.assertEqual(aggregated.total_order_qty, self.total_order_qty)
        self.assertEqual(aggregated.total_shipped_qty, self.total_shipped_qty)

    def test_order_transaction_aggregated_creation_with_new_fields(self):
        """Test creation with all new fields"""
        aggregated = OrderTransactionAggregated.objects.create(
            year=self.this_year,
            month=1,
            total_order_qty=self.total_order_qty,
            total_shipped_qty=self.total_shipped_qty,
            sales_amount=12345.67,
            material=self.material,
            sales_group='SG01',
            state='CA',
            cust_corp_chain_nbr=self.customer,
        )

        self.assertEqual(aggregated.sales_amount, 12345.67)
        self.assertEqual(aggregated.material, self.material)
        self.assertEqual(aggregated.sales_group, 'SG01')
        self.assertEqual(aggregated.state, 'CA')

    def test_unique_together_constraint(self):
        """Test unique together constraint on all key fields"""
        customer2 = TestDataFactory.create_customer_corp_chain()
        material2 = TestDataFactory.create_material()

        OrderTransactionAggregated.objects.create(
            year=self.this_year,
            month=1,
            total_order_qty=self.total_order_qty,
            total_shipped_qty=self.total_shipped_qty,
            cust_corp_chain_nbr=self.customer,
            material=self.material,
            sales_group='SG01',
            state='CA',
        )

        # Different customer — allowed
        OrderTransactionAggregated.objects.create(
            year=self.this_year,
            month=1,
            total_order_qty=1000,
            total_shipped_qty=2000,
            cust_corp_chain_nbr=customer2,
            material=self.material,
            sales_group='SG01',
            state='CA',
        )

        # Different material — allowed
        OrderTransactionAggregated.objects.create(
            year=self.this_year,
            month=1,
            total_order_qty=1000,
            total_shipped_qty=2000,
            cust_corp_chain_nbr=self.customer,
            material=material2,
            sales_group='SG01',
            state='CA',
        )

        # Different sales_group — allowed
        OrderTransactionAggregated.objects.create(
            year=self.this_year,
            month=1,
            total_order_qty=1000,
            total_shipped_qty=2000,
            cust_corp_chain_nbr=self.customer,
            material=self.material,
            sales_group='SG02',
            state='CA',
        )

        # Different state — allowed
        OrderTransactionAggregated.objects.create(
            year=self.this_year,
            month=1,
            total_order_qty=1000,
            total_shipped_qty=2000,
            cust_corp_chain_nbr=self.customer,
            material=self.material,
            sales_group='SG01',
            state='TX',
        )

        # Exact duplicate of first record — must raise
        with self.assertRaises(IntegrityError):
            OrderTransactionAggregated.objects.create(
                year=self.this_year,
                month=1,
                total_order_qty=3000,
                total_shipped_qty=4000,
                cust_corp_chain_nbr=self.customer,
                material=self.material,
                sales_group='SG01',
                state='CA',
            )
