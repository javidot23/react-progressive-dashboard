from datetime import date

from dateutil.relativedelta import relativedelta
from tests.BaseTestCase import BaseTestCase, MVTestCase

from api.order_transaction_aggregated.materialized_view_models import OtAggMonthlyMaterialMV
from api.order_transaction_aggregated.models import OrderTransactionAggregated
from api.order_transaction_aggregated.services import OrderTransactionAggregatedService
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


class OrderTransactionAggregatedServiceTest(MVTestCase):
    """Tests for the two MV-backed endpoints: last-two-years and sales-comparison-by-month."""

    def setUp(self):
        self.material = TestDataFactory.create_material()
        self.transactions = TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025,
            end_year=2026,
            total_shipped_qty=1000000,
            total_order_qty=1000,
            material=self.material,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

    def test_get_sales_comparison_by_month(self):
        """Test sales comparison by month for two years"""
        result = OrderTransactionAggregatedService.get_sales_comparison_by_month()

        self.assertEqual(len(result), 12)
        self.assertEqual(result[0]['month'], 'January')
        self.assertEqual(result[0]['month_num'], 1)
        self.assertGreater(result[0]['last_year_sales'], 0)
        self.assertGreater(result[0]['current_year_sales'], 0)
        self.assertEqual(result[0]['last_year_sales'], 1000000)
        self.assertEqual(result[0]['current_year_sales'], 1000000)

    def test_get_aggregated_data_for_current_and_previous_year(self):
        """Test retrieval of aggregated data for current and previous year"""
        result = OrderTransactionAggregatedService.get_aggregated_data_for_current_and_previous_year()

        self.assertEqual(len(result), 24)
        result_list = list(result)
        self.assertTrue(all(item['year'] in [2025, 2026] for item in result_list))
        self.assertTrue(all(1 <= item['month'] <= 12 for item in result_list))
        self.assertTrue(all(item['total_order_qty'] == 1000 for item in result_list))
        self.assertTrue(all(item['total_shipped_qty'] == 1000000 for item in result_list))

    def test_get_aggregated_data_with_material_filter(self):
        """Filtering by material returns only that material's data"""
        other_material = TestDataFactory.create_material()
        OrderTransactionAggregated.objects.create(
            year=2026, month=1,
            total_order_qty=999, total_shipped_qty=888,
            material=other_material,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        result = list(
            OrderTransactionAggregatedService.get_aggregated_data_for_current_and_previous_year(
                material_ids=[self.material.mat_nbr]
            )
        )

        self.assertEqual(len(result), 24)
        self.assertTrue(all(item['total_order_qty'] == 1000 for item in result))

    def test_get_sales_comparison_by_month_with_material_filter(self):
        """Filtering by material returns only that material's shipped qty"""
        other_material = TestDataFactory.create_material()
        for year in [2025, 2026]:
            for month in range(1, 13):
                OrderTransactionAggregated.objects.create(
                    year=year, month=month,
                    total_order_qty=1, total_shipped_qty=5000,
                    material=other_material,
                )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        result = OrderTransactionAggregatedService.get_sales_comparison_by_month(
            material_ids=[self.material.mat_nbr]
        )

        self.assertEqual(result[0]['last_year_sales'], 1000000)
        self.assertEqual(result[0]['current_year_sales'], 1000000)

    def test_get_aggregated_data_no_filter_aggregates_all_materials(self):
        """Without filter, data from all materials is aggregated together"""
        other_material = TestDataFactory.create_material()
        OrderTransactionAggregated.objects.create(
            year=2026, month=1,
            total_order_qty=500, total_shipped_qty=400,
            material=other_material,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        result = list(
            OrderTransactionAggregatedService.get_aggregated_data_for_current_and_previous_year()
        )

        jan_2026 = next(r for r in result if r['year'] == 2026 and r['month'] == 1)
        self.assertEqual(jan_2026['total_order_qty'], 1500)
        self.assertEqual(jan_2026['total_shipped_qty'], 1000400)

    def test_mv_has_expected_row_count(self):
        """MV should have one row per (year, month, material) combination"""
        mv_count = OtAggMonthlyMaterialMV.objects.count()
        self.assertEqual(mv_count, 24)


class SalesComparisonServiceTest(BaseTestCase):
    """
    Tests for the period-based comparison service methods.
    Uses end_year=2025, end_month=6, months=3:
      current period:  Apr-Jun 2025
      previous period: Jan-Mar 2025
    """

    def setUp(self):
        self.material = TestDataFactory.create_material()
        self.customer = TestDataFactory.create_customer_corp_chain()

        # Current period: Apr-Jun 2025
        for month in [4, 5, 6]:
            OrderTransactionAggregated.objects.create(
                year=2025, month=month,
                sales_amount=1000, total_order_qty=100, total_shipped_qty=90,
                sales_group='SG01', state='CA',
                material=self.material, cust_corp_chain_nbr=self.customer,
            )

        # Previous period: Jan-Mar 2025
        for month in [1, 2, 3]:
            OrderTransactionAggregated.objects.create(
                year=2025, month=month,
                sales_amount=600, total_order_qty=60, total_shipped_qty=50,
                sales_group='SG01', state='CA',
                material=self.material, cust_corp_chain_nbr=self.customer,
            )

    def test_get_sales_comparison_by_sales_group(self):
        result = list(OrderTransactionAggregatedService.get_sales_comparison_by_sales_group(2025, 6, 3))

        self.assertEqual(len(result), 1)
        row = result[0]
        self.assertEqual(row['sales_group'], 'SG01')
        self.assertEqual(row['current_period_sales'], 3000)   # 1000 x 3 months
        self.assertEqual(row['previous_period_sales'], 1800)  # 600 x 3 months
        self.assertEqual(row['current_period_order_qty'], 300)
        self.assertEqual(row['previous_period_order_qty'], 180)
        self.assertEqual(row['current_period_shipped_qty'], 270)
        self.assertEqual(row['previous_period_shipped_qty'], 150)

    def test_get_sales_comparison_by_state(self):
        result = list(OrderTransactionAggregatedService.get_sales_comparison_by_state(2025, 6, 3))

        self.assertEqual(len(result), 1)
        row = result[0]
        self.assertEqual(row['state'], 'CA')
        self.assertEqual(row['current_period_sales'], 3000)
        self.assertEqual(row['previous_period_sales'], 1800)

    def test_get_sales_comparison_by_material(self):
        result = list(OrderTransactionAggregatedService.get_sales_comparison_by_material(2025, 6, 3))

        self.assertEqual(len(result), 1)
        row = result[0]
        self.assertEqual(row['material_id'], self.material.mat_nbr)
        self.assertEqual(row['current_period_sales'], 3000)
        self.assertEqual(row['previous_period_sales'], 1800)

    def test_get_sales_comparison_by_customer(self):
        result = list(OrderTransactionAggregatedService.get_sales_comparison_by_customer(2025, 6, 3))

        self.assertEqual(len(result), 1)
        row = result[0]
        self.assertEqual(row['cust_corp_chain_nbr_id'], self.customer.cust_corp_chain_nbr)
        self.assertEqual(row['current_period_sales'], 3000)
        self.assertEqual(row['previous_period_sales'], 1800)

    def test_get_sales_comparison_multiple_groups(self):
        """Multiple sales groups are returned and separated correctly"""
        material2 = TestDataFactory.create_material()
        for month in [4, 5, 6]:
            OrderTransactionAggregated.objects.create(
                year=2025, month=month,
                sales_amount=500, total_order_qty=50, total_shipped_qty=45,
                sales_group='SG02', state='TX',
                material=material2, cust_corp_chain_nbr=self.customer,
            )

        result = {
            row['sales_group']: row
            for row in OrderTransactionAggregatedService.get_sales_comparison_by_sales_group(2025, 6, 3)
        }

        self.assertIn('SG01', result)
        self.assertIn('SG02', result)
        self.assertEqual(result['SG01']['current_period_sales'], 3000)
        self.assertEqual(result['SG02']['current_period_sales'], 1500)
        self.assertEqual(result['SG02']['previous_period_sales'], 0)

    def test_get_sales_comparison_no_data_returns_empty(self):
        result = list(OrderTransactionAggregatedService.get_sales_comparison_by_sales_group(2020, 1, 3))
        self.assertEqual(result, [])


class SalesTimelineServiceTest(BaseTestCase):
    def setUp(self):
        self.material = TestDataFactory.create_material()
        today = date.today()
        # Create records for all 25 months of the timeline window
        for i in range(25):
            d = date(today.year, today.month, 1) - relativedelta(months=24 - i)
            OrderTransactionAggregated.objects.create(
                year=d.year, month=d.month,
                sales_amount=100 * (i + 1),
                total_order_qty=10,
                total_shipped_qty=9,
                material=self.material,
            )

    def test_get_sales_timeline_returns_25_months(self):
        result = list(OrderTransactionAggregatedService.get_sales_timeline())
        self.assertEqual(len(result), 25)

    def test_get_sales_timeline_ordered_chronologically(self):
        result = list(OrderTransactionAggregatedService.get_sales_timeline())
        year_months = [(r['year'], r['month']) for r in result]
        self.assertEqual(year_months, sorted(year_months))

    def test_get_sales_timeline_ends_at_current_month(self):
        today = date.today()
        result = list(OrderTransactionAggregatedService.get_sales_timeline())
        last = result[-1]
        self.assertEqual(last['year'], today.year)
        self.assertEqual(last['month'], today.month)

    def test_get_sales_timeline_starts_24_months_ago(self):
        start = date.today().replace(day=1) - relativedelta(months=24)
        result = list(OrderTransactionAggregatedService.get_sales_timeline())
        first = result[0]
        self.assertEqual(first['year'], start.year)
        self.assertEqual(first['month'], start.month)

    def test_get_sales_timeline_aggregates_values(self):
        result = list(OrderTransactionAggregatedService.get_sales_timeline())
        for row in result:
            self.assertIn('sales_amount', row)
            self.assertIn('total_order_qty', row)
            self.assertIn('total_shipped_qty', row)


class FtsMaterialExposureServiceTests(BaseTestCase):
    """Tests for get_fts_material_exposure."""

    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.selected = date(2026, 7, 1)
        self.material = TestDataFactory.create_material(
            vendor=self.vendor,
            ndc="00001-0001-01",
            name="Product A",
        )

    def _month(self, months_before: int) -> date:
        return self.selected - relativedelta(months=months_before)

    def _agg(
        self,
        material=None,
        months_before=0,
        filled=95,
        ordered=100,
        net_sales=1000,
        sales_group="PRxO",
        state=None,
        total_order_qty=0,
        total_shipped_qty=0,
    ):
        month_date = self._month(months_before)
        return TestDataFactory.create_order_transaction_aggregated(
            year=month_date.year,
            month=month_date.month,
            material=material or self.material,
            sales_group=sales_group,
            state=state or f"S{months_before}-{filled}-{ordered}-{net_sales}",
            sales_less_cred_qty=net_sales,
            fts_lines_fully_filled=filled,
            fts_lines_ordered=ordered,
            total_order_qty=total_order_qty,
            total_shipped_qty=total_shipped_qty,
        )

    def _results(self, **kwargs):
        defaults = {"selected_month": self.selected, "lookback_months": 6}
        defaults.update(kwargs)
        return OrderTransactionAggregatedService.get_fts_material_exposure(**defaults)

    def test_uses_three_most_recent_months_at_95(self):
        self._agg(months_before=1, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=2, filled=95, ordered=100, net_sales=300)
        self._agg(months_before=3, filled=98, ordered=100, net_sales=400)
        self._agg(months_before=4, filled=90, ordered=100, net_sales=500)
        self._agg(months_before=0, filled=80, ordered=100, net_sales=100)

        result = self._results()[0]

        self.assertEqual(result["full_supply_qty"], 300)
        self.assertEqual(result["service_level_pct"], 80)
        self.assertEqual(result["net_sales"], 100)
        self.assertEqual(result["fts_exposure"], 200)

    def test_omits_qty_sums_selected_month_only(self):
        self._agg(months_before=1, filled=100, ordered=100, net_sales=200,
                  total_order_qty=999, total_shipped_qty=0)
        self._agg(months_before=2, filled=100, ordered=100, net_sales=300)
        self._agg(months_before=3, filled=100, ordered=100, net_sales=400)
        self._agg(months_before=0, filled=80, ordered=100, net_sales=100,
                  total_order_qty=500, total_shipped_qty=320)
        self._agg(months_before=0, filled=80, ordered=100, net_sales=100,
                  state='SECOND-ROW', total_order_qty=100, total_shipped_qty=70)

        result = self._results()[0]

        self.assertEqual(result["omits_qty"], 210)

    def test_outbound_fill_rate_is_shipped_over_ordered_percentage(self):
        self._agg(months_before=1, filled=100, ordered=100, net_sales=200,
                  total_order_qty=999, total_shipped_qty=0)
        self._agg(months_before=0, filled=80, ordered=100, net_sales=100,
                  total_order_qty=500, total_shipped_qty=320)
        self._agg(months_before=0, filled=80, ordered=100, net_sales=100,
                  state='SECOND-ROW', total_order_qty=100, total_shipped_qty=70)

        result = self._results()[0]

        self.assertEqual(result["outbound_fill_rate"], 65.0)
        self.assertEqual(result["omits_qty"], 210)

    def test_outbound_fill_rate_null_when_nothing_ordered(self):
        self._agg(months_before=1, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=0, filled=80, ordered=100, net_sales=100)

        result = self._results()[0]

        self.assertIsNone(result["outbound_fill_rate"])
        self.assertEqual(result["omits_qty"], 0)

    def test_fallback_to_top_sl_months_when_fewer_than_three_at_95(self):
        self._agg(months_before=1, filled=90, ordered=100, net_sales=200)
        self._agg(months_before=2, filled=80, ordered=100, net_sales=300)
        self._agg(months_before=3, filled=70, ordered=100, net_sales=400)
        self._agg(months_before=0, filled=80, ordered=100, net_sales=100)

        result = self._results()[0]

        self.assertEqual(result["full_supply_qty"], 300)
        self.assertEqual(result["fts_exposure"], 200)

    def test_fewer_than_three_historical_months_averages_available(self):
        self._agg(months_before=1, filled=90, ordered=100, net_sales=200)
        self._agg(months_before=2, filled=80, ordered=100, net_sales=400)
        self._agg(months_before=0, filled=70, ordered=100, net_sales=100)

        result = self._results()[0]

        self.assertEqual(result["full_supply_qty"], 300)
        self.assertEqual(result["fts_exposure"], 200)

    def test_exposure_zero_when_selected_sl_at_or_above_95(self):
        self._agg(months_before=1, filled=100, ordered=100, net_sales=500)
        self._agg(months_before=2, filled=100, ordered=100, net_sales=500)
        self._agg(months_before=3, filled=100, ordered=100, net_sales=500)
        self._agg(months_before=0, filled=95, ordered=100, net_sales=100)

        result = self._results()[0]

        self.assertEqual(result["service_level_pct"], 95)
        self.assertEqual(result["fts_exposure"], 0)

    def test_exposure_never_negative(self):
        self._agg(months_before=1, filled=100, ordered=100, net_sales=100)
        self._agg(months_before=2, filled=100, ordered=100, net_sales=100)
        self._agg(months_before=3, filled=100, ordered=100, net_sales=100)
        self._agg(months_before=0, filled=50, ordered=100, net_sales=500)

        result = self._results()[0]

        self.assertEqual(result["full_supply_qty"], 100)
        self.assertEqual(result["fts_exposure"], 0)

    def test_zero_ordered_lines_month_excluded(self):
        self._agg(months_before=1, filled=0, ordered=0, net_sales=9999)
        self._agg(months_before=2, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=3, filled=100, ordered=100, net_sales=300)
        self._agg(months_before=0, filled=80, ordered=100, net_sales=100)

        result = self._results()[0]

        self.assertEqual(result["full_supply_qty"], 250)

    def test_multiple_materials_same_ndc_are_aggregated(self):
        other = TestDataFactory.create_material(
            vendor=self.vendor,
            ndc=self.material.ndc,
            name="Product A Alt",
        )
        self._agg(months_before=1, filled=50, ordered=50, net_sales=100)
        self._agg(material=other, months_before=1, filled=50, ordered=50, net_sales=100)
        self._agg(months_before=2, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=3, filled=100, ordered=100, net_sales=300)
        self._agg(months_before=0, filled=40, ordered=50, net_sales=50)
        self._agg(material=other, months_before=0, filled=40, ordered=50, net_sales=50)

        results = self._results()
        self.assertEqual(len(results), 1)
        result = results[0]
        self.assertEqual(result["product_ndc"], self.material.ndc)
        self.assertEqual(result["service_level_pct"], 80)
        self.assertEqual(result["net_sales"], 100)
        self.assertEqual(result["full_supply_qty"], 233)

    def _seed_prxo_and_pgen(self):
        for months_before in (1, 2, 3):
            self._agg(months_before=months_before, filled=100, ordered=100, net_sales=200)
            self._agg(
                months_before=months_before,
                filled=100,
                ordered=100,
                net_sales=400,
                sales_group="PGEN",
                state=f"PGEN-{months_before}",
            )
        self._agg(months_before=0, filled=50, ordered=100, net_sales=50)
        self._agg(
            months_before=0,
            filled=25,
            ordered=100,
            net_sales=150,
            sales_group="PGEN",
            state="PGEN-0",
        )

    def test_defaults_to_prxo_sales_group(self):
        self._seed_prxo_and_pgen()

        result = self._results()[0]
        self.assertEqual(result["net_sales"], 50)
        self.assertEqual(result["service_level_pct"], 50)
        self.assertEqual(result["full_supply_qty"], 200)

    def test_pgen_sales_group_returns_its_own_metrics(self):
        self._seed_prxo_and_pgen()

        result = self._results(sales_group="PGEN")[0]
        self.assertEqual(result["net_sales"], 150)
        self.assertEqual(result["service_level_pct"], 25)
        self.assertEqual(result["full_supply_qty"], 400)

    def test_excludes_sales_groups_outside_the_selected_formulary(self):
        self._agg(months_before=1, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=2, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=3, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=0, filled=50, ordered=100, net_sales=50)
        self._agg(
            months_before=0,
            filled=0,
            ordered=100,
            net_sales=9999,
            sales_group="ABDC",
            state="ABDC-ROW",
        )

        result = self._results()[0]
        self.assertEqual(result["net_sales"], 50)
        self.assertEqual(result["service_level_pct"], 50)

    def test_excludes_other_vendor_via_material_subquery(self):
        other_vendor = TestDataFactory.create_vendor()
        other_mat = TestDataFactory.create_material(
            vendor=other_vendor,
            ndc="99999-9999-99",
            name="Other",
        )
        self._agg(months_before=1, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=2, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=3, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=0, filled=50, ordered=100, net_sales=50)
        self._agg(material=other_mat, months_before=1, filled=100, ordered=100, net_sales=900)
        self._agg(material=other_mat, months_before=2, filled=100, ordered=100, net_sales=900)
        self._agg(material=other_mat, months_before=3, filled=100, ordered=100, net_sales=900)
        self._agg(material=other_mat, months_before=0, filled=10, ordered=100, net_sales=10)

        from api.material.models import Material
        subquery = Material.objects.filter(vendor=self.vendor).values_list("mat_nbr", flat=True)
        results = self._results(mat_nbr_subquery=subquery)

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["product_ndc"], self.material.ndc)

    def test_defaults_to_latest_available_month(self):
        self._agg(months_before=1, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=2, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=3, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=0, filled=50, ordered=100, net_sales=50)

        results = OrderTransactionAggregatedService.get_fts_material_exposure()
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["service_level_pct"], 50)

    def test_excludes_products_without_prior_history(self):
        self._agg(months_before=0, filled=50, ordered=100, net_sales=50)

        self.assertEqual(self._results(), [])

    def test_under_95_sorted_before_at_or_above_95(self):
        mat_ok = TestDataFactory.create_material(
            vendor=self.vendor, ndc="00002-0002-02", name="Healthy"
        )
        for months_before, filled, net in [(1, 100, 300), (2, 100, 300), (3, 100, 300)]:
            self._agg(months_before=months_before, filled=filled, ordered=100, net_sales=net)
            self._agg(
                material=mat_ok,
                months_before=months_before,
                filled=filled,
                ordered=100,
                net_sales=net,
            )
        self._agg(months_before=0, filled=50, ordered=100, net_sales=50)
        self._agg(material=mat_ok, months_before=0, filled=100, ordered=100, net_sales=50)

        results = self._results()
        self.assertEqual(len(results), 2)
        self.assertLess(results[0]["service_level_pct"], 95)
        self.assertGreaterEqual(results[1]["service_level_pct"], 95)

    def test_empty_dataset_returns_empty_list(self):
        self.assertEqual(self._results(), [])

    def test_monthly_data_pivot_includes_selected_and_lookback(self):
        self._agg(months_before=1, filled=100, ordered=100, net_sales=200)
        self._agg(months_before=2, filled=95, ordered=100, net_sales=300)
        self._agg(months_before=3, filled=98, ordered=100, net_sales=400)
        self._agg(months_before=0, filled=80, ordered=100, net_sales=100)

        result = self._results()[0]
        monthly = result["monthly_data"]

        self.assertEqual(result["selected_month"], "2026-07")
        self.assertEqual(len(monthly), 7)
        self.assertEqual(
            list(monthly.keys()),
            ["2026-07", "2026-06", "2026-05", "2026-04", "2026-03", "2026-02", "2026-01"],
        )
        self.assertEqual(
            monthly["2026-07"],
            {"service_level_pct": 80, "net_sales": 100},
        )
        self.assertEqual(monthly["2026-07"]["service_level_pct"], result["service_level_pct"])
        self.assertEqual(monthly["2026-07"]["net_sales"], result["net_sales"])
        self.assertEqual(
            monthly["2026-06"],
            {"service_level_pct": 100, "net_sales": 200},
        )
        self.assertIsNone(monthly["2026-01"])


class SalesYtdServiceTest(MVTestCase):
    """Tests for get_sales_ytd using the monthly material MV."""

    def setUp(self):
        self.material = TestDataFactory.create_material()
        today = date.today()
        self.current_year = today.year
        self.previous_year = today.year - 1
        self.current_month = today.month

        for year in (self.previous_year, self.current_year):
            for month in range(1, 13):
                OrderTransactionAggregated.objects.create(
                    year=year,
                    month=month,
                    total_order_qty=100,
                    total_shipped_qty=80,
                    sales_amount=1000,
                    material=self.material,
                )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

    def test_ytd_totals_sum_months_through_current(self):
        result = OrderTransactionAggregatedService.get_sales_ytd()
        months = self.current_month

        self.assertEqual(result['current_ytd']['total_order_qty'], 100 * months)
        self.assertEqual(result['current_ytd']['total_shipped_qty'], 80 * months)
        self.assertEqual(result['current_ytd']['sales_amount'], 1000 * months)
        self.assertEqual(result['previous_ytd']['total_order_qty'], 100 * months)
        self.assertEqual(result['previous_ytd']['total_shipped_qty'], 80 * months)
        self.assertEqual(result['previous_ytd']['sales_amount'], 1000 * months)

    def test_pct_change_is_zero_when_ytd_equal(self):
        result = OrderTransactionAggregatedService.get_sales_ytd()
        self.assertEqual(result['pct_change']['total_order_qty'], 0.0)
        self.assertEqual(result['pct_change']['total_shipped_qty'], 0.0)
        self.assertEqual(result['pct_change']['sales_amount'], 0.0)

    def test_pct_change_null_when_previous_is_zero(self):
        OrderTransactionAggregated.objects.filter(year=self.previous_year).delete()
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        result = OrderTransactionAggregatedService.get_sales_ytd()
        self.assertIsNone(result['pct_change']['total_order_qty'])
        self.assertIsNone(result['pct_change']['total_shipped_qty'])
        self.assertIsNone(result['pct_change']['sales_amount'])

    def test_pct_change_math(self):
        OrderTransactionAggregated.objects.filter(year=self.current_year).delete()
        for month in range(1, self.current_month + 1):
            OrderTransactionAggregated.objects.create(
                year=self.current_year,
                month=month,
                total_order_qty=200,
                total_shipped_qty=160,
                sales_amount=1500,
                material=self.material,
            )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        result = OrderTransactionAggregatedService.get_sales_ytd()
        self.assertEqual(result['pct_change']['total_order_qty'], 100.0)
        self.assertEqual(result['pct_change']['total_shipped_qty'], 100.0)
        self.assertEqual(result['pct_change']['sales_amount'], 50.0)

    def test_trend_length_and_gap_zeros(self):
        OrderTransactionAggregated.objects.filter(
            year=self.current_year, month=1
        ).delete()
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        result = OrderTransactionAggregatedService.get_sales_ytd()
        self.assertEqual(len(result['trend']), self.current_month)
        january = result['trend'][0]
        self.assertEqual(january['month'], 1)
        self.assertEqual(january['total_order_qty'], 0)
        self.assertEqual(january['total_shipped_qty'], 0)
        self.assertEqual(january['sales_amount'], 0)
        if self.current_month >= 2:
            february = result['trend'][1]
            self.assertEqual(february['total_order_qty'], 100)

    def test_material_filter(self):
        other = TestDataFactory.create_material()
        for month in range(1, self.current_month + 1):
            OrderTransactionAggregated.objects.create(
                year=self.current_year,
                month=month,
                total_order_qty=999,
                total_shipped_qty=888,
                sales_amount=777,
                material=other,
            )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        result = OrderTransactionAggregatedService.get_sales_ytd(
            material_ids=[self.material.mat_nbr]
        )
        self.assertEqual(result['current_ytd']['total_order_qty'], 100 * self.current_month)
        self.assertEqual(result['current_ytd']['total_shipped_qty'], 80 * self.current_month)
        self.assertEqual(result['current_ytd']['sales_amount'], 1000 * self.current_month)


class SalesYtdComparisonServiceTest(MVTestCase):
    """
    Tests for the YtD comparison service methods.
    Uses year=2026, through_month=8:
      current period:  Jan-Aug 2026
      baseline period: Jan-Aug 2025
    """

    YEAR = 2026
    THROUGH_MONTH = 8

    def setUp(self):
        self.material = TestDataFactory.create_material(ndc='11111-222-33', federal_cs_ind='2')
        self.other_material = TestDataFactory.create_material(ndc='44444-555-66', federal_cs_ind=None)
        self.customer = TestDataFactory.create_customer_corp_chain()

        # In window: Jan-Aug of both years, split across two sales groups.
        for month in range(1, 9):
            OrderTransactionAggregated.objects.create(
                year=2026, month=month,
                sales_amount=1000, total_order_qty=100, total_shipped_qty=90,
                sales_group='SG01', state='CA',
                material=self.material, cust_corp_chain_nbr=self.customer,
            )
            OrderTransactionAggregated.objects.create(
                year=2026, month=month,
                sales_amount=500, total_order_qty=50, total_shipped_qty=40,
                sales_group='SG02', state='CA',
                material=self.material, cust_corp_chain_nbr=self.customer,
            )
            OrderTransactionAggregated.objects.create(
                year=2025, month=month,
                sales_amount=600, total_order_qty=60, total_shipped_qty=50,
                sales_group='SG01', state='CA',
                material=self.material, cust_corp_chain_nbr=self.customer,
            )

        # Outside the window: later months of both years must not be counted.
        for year, month in [(2025, 10), (2025, 12), (2026, 11)]:
            OrderTransactionAggregated.objects.create(
                year=year, month=month,
                sales_amount=9999, total_order_qty=999, total_shipped_qty=888,
                sales_group='SG01', state='CA',
                material=self.material, cust_corp_chain_nbr=self.customer,
            )

        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

    def _material_row(self):
        rows = list(OrderTransactionAggregatedService.get_sales_ytd_by_material(
            self.YEAR, self.THROUGH_MONTH
        ))
        return next(row for row in rows if row['material_id'] == self.material.mat_nbr)

    def test_by_material_sums_only_months_in_window(self):
        row = self._material_row()

        # Jan-Aug 2026 across both sales groups: (1000 + 500) x 8
        self.assertEqual(row['current_ytd_sales'], 12000)
        self.assertEqual(row['current_ytd_order_qty'], 1200)
        self.assertEqual(row['current_ytd_shipped_qty'], 1040)
        # Jan-Aug 2025: 600 x 8 — excludes Oct and Dec 2025
        self.assertEqual(row['previous_ytd_sales'], 4800)
        self.assertEqual(row['previous_ytd_order_qty'], 480)
        self.assertEqual(row['previous_ytd_shipped_qty'], 400)

    def test_by_material_exposes_ndc_and_federal_cs_ind(self):
        row = self._material_row()
        self.assertEqual(row['material__name'], self.material.name)
        self.assertEqual(row['material__ndc'], '11111-222-33')
        self.assertEqual(row['material__federal_cs_ind'], '2')

    def test_by_material_mat_nbrs_filter(self):
        for month in range(1, 9):
            OrderTransactionAggregated.objects.create(
                year=2026, month=month,
                sales_amount=777, total_order_qty=77, total_shipped_qty=70,
                sales_group='SG01', state='TX',
                material=self.other_material, cust_corp_chain_nbr=self.customer,
            )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        rows = list(OrderTransactionAggregatedService.get_sales_ytd_by_material(
            self.YEAR, self.THROUGH_MONTH, mat_nbrs=[self.material.mat_nbr]
        ))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['material_id'], self.material.mat_nbr)

    def test_by_customer_sums_only_months_in_window(self):
        rows = list(OrderTransactionAggregatedService.get_sales_ytd_by_customer(
            self.YEAR, self.THROUGH_MONTH
        ))

        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row['cust_corp_chain_nbr_id'], self.customer.cust_corp_chain_nbr)
        self.assertEqual(row['cust_corp_chain_nbr__name'], self.customer.name)
        self.assertEqual(row['current_ytd_sales'], 12000)
        self.assertEqual(row['previous_ytd_sales'], 4800)

    def test_by_sales_group_separates_groups(self):
        rows = {
            row['sales_group']: row
            for row in OrderTransactionAggregatedService.get_sales_ytd_by_sales_group(
                self.YEAR, self.THROUGH_MONTH
            )
        }

        self.assertEqual(set(rows), {'SG01', 'SG02'})
        self.assertEqual(rows['SG01']['current_ytd_sales'], 8000)
        self.assertEqual(rows['SG01']['previous_ytd_sales'], 4800)
        self.assertEqual(rows['SG02']['current_ytd_sales'], 4000)
        self.assertEqual(rows['SG02']['previous_ytd_sales'], 0)

    def test_pct_change_math(self):
        row = OrderTransactionAggregatedService.attach_ytd_pct_change(self._material_row())

        # 12000 vs 4800 = +150%, 1200 vs 480 = +150%, 1040 vs 400 = +160%
        self.assertEqual(row['sales_yoy_pct'], 150.0)
        self.assertEqual(row['order_qty_yoy_pct'], 150.0)
        self.assertEqual(row['shipped_qty_yoy_pct'], 160.0)

    def test_pct_change_null_when_baseline_is_zero(self):
        OrderTransactionAggregated.objects.filter(year=2025).delete()
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        row = OrderTransactionAggregatedService.attach_ytd_pct_change(self._material_row())
        self.assertIsNone(row['sales_yoy_pct'])
        self.assertIsNone(row['order_qty_yoy_pct'])
        self.assertIsNone(row['shipped_qty_yoy_pct'])

    def test_breakdown_by_material_groups_by_sales_group(self):
        breakdown = OrderTransactionAggregatedService.get_sales_group_ytd_breakdown(
            self.YEAR, self.THROUGH_MONTH, 'material_id', [self.material.mat_nbr]
        )

        rows = {row['sales_group']: row for row in breakdown[self.material.mat_nbr]}
        self.assertEqual(set(rows), {'SG01', 'SG02'})
        self.assertEqual(rows['SG01']['current_ytd_sales'], 8000)
        self.assertEqual(rows['SG01']['previous_ytd_sales'], 4800)
        self.assertEqual(rows['SG01']['sales_yoy_pct'], 66.67)
        self.assertEqual(rows['SG02']['current_ytd_sales'], 4000)
        self.assertIsNone(rows['SG02']['sales_yoy_pct'])

    def test_breakdown_sums_to_parent_row(self):
        parent = self._material_row()
        breakdown = OrderTransactionAggregatedService.get_sales_group_ytd_breakdown(
            self.YEAR, self.THROUGH_MONTH, 'material_id', [self.material.mat_nbr]
        )

        rows = breakdown[self.material.mat_nbr]
        for metric in ('current_ytd_sales', 'previous_ytd_sales', 'current_ytd_order_qty'):
            self.assertEqual(sum(row[metric] for row in rows), parent[metric])

    def test_breakdown_by_customer_groups_by_sales_group(self):
        breakdown = OrderTransactionAggregatedService.get_sales_group_ytd_breakdown(
            self.YEAR, self.THROUGH_MONTH, 'cust_corp_chain_nbr_id',
            [self.customer.cust_corp_chain_nbr]
        )

        rows = {row['sales_group']: row for row in breakdown[self.customer.cust_corp_chain_nbr]}
        self.assertEqual(set(rows), {'SG01', 'SG02'})
        self.assertEqual(rows['SG01']['current_ytd_sales'], 8000)

    def test_breakdown_with_no_keys_returns_empty(self):
        self.assertEqual(
            OrderTransactionAggregatedService.get_sales_group_ytd_breakdown(
                self.YEAR, self.THROUGH_MONTH, 'material_id', []
            ),
            {},
        )

    def test_no_data_returns_empty(self):
        self.assertEqual(
            list(OrderTransactionAggregatedService.get_sales_ytd_by_sales_group(2020, 8)),
            [],
        )
