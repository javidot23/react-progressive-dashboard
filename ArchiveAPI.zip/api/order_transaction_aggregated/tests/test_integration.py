from datetime import date
import csv
import io
from unittest.mock import MagicMock, patch

from dateutil.relativedelta import relativedelta
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient
from tests.BaseTestCase import BaseAPITestCase, MVAPITestCase

from api.csv_export import DEFAULT_EXPORT_MAX_ROWS
from api.order_transaction_aggregated.models import OrderTransactionAggregated
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


class OrderTransactionAggregatedIntegrationTest(MVAPITestCase):
    """Integration tests for the MV-backed last-two-years and sales-comparison-by-month endpoints."""

    def setUp(self):
        self.client = APIClient()
        self.material = TestDataFactory.create_material()

    def test_sales_comparison_by_month_view(self):
        """Test sales comparison by month endpoint"""
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025,
            end_year=2026,
            total_shipped_qty=1000,
            total_order_qty=1000000,
            material=self.material,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:sales-comparison-by-month')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 12)
        for month_data in response.data:
            self.assertIn('month', month_data)
            self.assertIn('current_year_sales', month_data)
            self.assertIn('last_year_sales', month_data)
            self.assertIn('month_num', month_data)

    def test_aggregated_data_for_current_and_previous_year(self):
        """Test retrieval of aggregated data for current and previous year"""
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025,
            end_year=2026,
            total_shipped_qty=1000,
            total_order_qty=1000000,
            material=self.material,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:last_two_years')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 24)
        for item in response.data:
            self.assertIn('year', item)
            self.assertIn('month', item)
            self.assertIn('total_shipped_qty', item)
            self.assertIn('total_order_qty', item)

    def test_last_two_years_with_material_global_filter(self):
        """Global filter ?material=MAT_NBR returns only that material's data"""
        other_material = TestDataFactory.create_material()

        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=1000, total_order_qty=100,
            material=self.material,
        )
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=9999, total_order_qty=999,
            material=other_material,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:last_two_years')
        response = self.client.get(url, {'material': self.material.mat_nbr})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 24)
        for item in response.data:
            self.assertEqual(item['total_shipped_qty'], 1000)
            self.assertEqual(item['total_order_qty'], 100)

    def test_sales_comparison_by_month_with_material_global_filter(self):
        """Global filter on sales-comparison-by-month returns filtered data"""
        other_material = TestDataFactory.create_material()

        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=500, total_order_qty=50,
            material=self.material,
        )
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=8000, total_order_qty=800,
            material=other_material,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:sales-comparison-by-month')
        response = self.client.get(url, {'material': self.material.mat_nbr})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 12)
        for month_data in response.data:
            self.assertEqual(month_data['last_year_sales'], 500)
            self.assertEqual(month_data['current_year_sales'], 500)

    def test_last_two_years_no_filter_aggregates_all(self):
        """Without global filters, all materials are aggregated"""
        other_material = TestDataFactory.create_material()

        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=1000, total_order_qty=100,
            material=self.material,
        )
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=2000, total_order_qty=200,
            material=other_material,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:last_two_years')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 24)
        for item in response.data:
            self.assertEqual(item['total_shipped_qty'], 3000)
            self.assertEqual(item['total_order_qty'], 300)

    def test_last_two_years_with_supplier_global_filter(self):
        """Global filter ?supplier=<id> narrows to that vendor's materials"""
        vendor_a = TestDataFactory.create_vendor(name="Vendor A")
        vendor_b = TestDataFactory.create_vendor(name="Vendor B")
        mat_a = TestDataFactory.create_material(vendor=vendor_a)
        mat_b = TestDataFactory.create_material(vendor=vendor_b)

        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=100, total_order_qty=10, material=mat_a,
        )
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=9000, total_order_qty=900, material=mat_b,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:last_two_years')
        response = self.client.get(url, {'supplier': vendor_a.id})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 24)
        for item in response.data:
            self.assertEqual(item['total_shipped_qty'], 100)

    def test_last_two_years_with_product_family_global_filter(self):
        """Global filter ?product_family=X narrows to materials in that family"""
        mat_pharma = TestDataFactory.create_material(product_family="Pharma")
        mat_device = TestDataFactory.create_material(product_family="Device")

        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=200, total_order_qty=20, material=mat_pharma,
        )
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=5000, total_order_qty=500, material=mat_device,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:last_two_years')
        response = self.client.get(url, {'product_family': 'Pharma'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 24)
        for item in response.data:
            self.assertEqual(item['total_shipped_qty'], 200)

    def test_sales_comparison_by_month_with_supplier_global_filter(self):
        """Global filter ?supplier=<id> on sales-comparison-by-month"""
        vendor_a = TestDataFactory.create_vendor(name="Vendor A")
        vendor_b = TestDataFactory.create_vendor(name="Vendor B")
        mat_a = TestDataFactory.create_material(vendor=vendor_a)
        mat_b = TestDataFactory.create_material(vendor=vendor_b)

        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=300, total_order_qty=30, material=mat_a,
        )
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=7000, total_order_qty=700, material=mat_b,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:sales-comparison-by-month')
        response = self.client.get(url, {'supplier': vendor_a.id})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        for month_data in response.data:
            self.assertEqual(month_data['last_year_sales'], 300)
            self.assertEqual(month_data['current_year_sales'], 300)

    def test_sales_comparison_by_month_with_federal_cs_ind_filter(self):
        """Global filter ?federal_cs_ind=2 narrows by-month to materials in that CS schedule."""
        mat_cs2 = TestDataFactory.create_material(federal_cs_ind='2')
        mat_cs3 = TestDataFactory.create_material(federal_cs_ind='3')

        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=400, total_order_qty=40, material=mat_cs2,
        )
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=6000, total_order_qty=600, material=mat_cs3,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:sales-comparison-by-month')
        response = self.client.get(url, {'federal_cs_ind': '2'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        for month_data in response.data:
            self.assertEqual(month_data['last_year_sales'], 400)
            self.assertEqual(month_data['current_year_sales'], 400)

    def test_sales_comparison_by_month_with_federal_cs_ind_exclude(self):
        """Global filter ?exclude_federal_cs_ind=2 drops materials in that CS schedule."""
        mat_cs2 = TestDataFactory.create_material(federal_cs_ind='2')
        mat_cs3 = TestDataFactory.create_material(federal_cs_ind='3')

        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=400, total_order_qty=40, material=mat_cs2,
        )
        TestDataFactory.create_order_transaction_aggregated_for_two_years(
            start_year=2025, end_year=2026,
            total_shipped_qty=500, total_order_qty=50, material=mat_cs3,
        )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:sales-comparison-by-month')
        response = self.client.get(url, {'exclude_federal_cs_ind': '2'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        for month_data in response.data:
            self.assertEqual(month_data['last_year_sales'], 500)
            self.assertEqual(month_data['current_year_sales'], 500)


class SalesComparisonEndpointTest(BaseAPITestCase):
    """
    Integration tests for the 4 period comparison endpoints and the timeline endpoint.
    Uses end_year=2025, end_month=6, months=3.
    """

    def setUp(self):
        self.client = APIClient()
        self.material = TestDataFactory.create_material()
        self.customer = TestDataFactory.create_customer_corp_chain()

        # Current period: Apr-Jun 2025
        for month in [4, 5, 6]:
            OrderTransactionAggregated.objects.create(
                year=2025, month=month,
                sales_amount=1000, total_order_qty=100, total_shipped_qty=90,
                sales_group='SG01', state='CA',
                material=self.material, cust_corp_chain_nbr=self.customer,
            )

        # Previous period: Jan-Mar 2025
        for month in [1, 2, 3]:
            OrderTransactionAggregated.objects.create(
                year=2025, month=month,
                sales_amount=600, total_order_qty=60, total_shipped_qty=50,
                sales_group='SG01', state='CA',
                material=self.material, cust_corp_chain_nbr=self.customer,
            )

    def _comparison_params(self):
        return {'end_year': 2025, 'end_month': 6, 'months': 3}

    def _assert_comparison_fields(self, item):
        for field in [
            'current_period_sales', 'previous_period_sales',
            'current_period_order_qty', 'previous_period_order_qty',
            'current_period_shipped_qty', 'previous_period_shipped_qty',
        ]:
            self.assertIn(field, item)

    def test_sales_comparison_by_sales_group(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-sales-group')
        response = self.client.get(url, self._comparison_params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        row = response.data[0]
        self.assertEqual(row['sales_group'], 'SG01')
        self._assert_comparison_fields(row)
        self.assertEqual(float(row['current_period_sales']), 3000)
        self.assertEqual(float(row['previous_period_sales']), 1800)

    def test_sales_comparison_by_state(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-state')
        response = self.client.get(url, self._comparison_params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        row = response.data[0]
        self.assertEqual(row['state'], 'CA')
        self._assert_comparison_fields(row)
        self.assertEqual(float(row['current_period_sales']), 3000)
        self.assertEqual(float(row['previous_period_sales']), 1800)

    def test_sales_comparison_by_material(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-material')
        response = self.client.get(url, self._comparison_params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        row = results[0]
        self.assertEqual(row['mat_nbr'], self.material.mat_nbr)
        self.assertIn('material_name', row)
        self._assert_comparison_fields(row)
        self.assertEqual(float(row['current_period_sales']), 3000)

    def test_sales_comparison_by_material_pagination(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-material')
        response = self.client.get(url, {**self._comparison_params(), 'limit': 1, 'offset': 0})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('count', response.data)
        self.assertIn('results', response.data)
        self.assertEqual(len(response.data['results']), 1)

    def test_sales_comparison_by_customer(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-customer')
        response = self.client.get(url, self._comparison_params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        row = results[0]
        self.assertEqual(row['cust_corp_chain_nbr'], self.customer.cust_corp_chain_nbr)
        self.assertIn('customer_name', row)
        self._assert_comparison_fields(row)
        self.assertEqual(float(row['current_period_sales']), 3000)

    def test_sales_comparison_by_customer_pagination(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-customer')
        response = self.client.get(url, {**self._comparison_params(), 'limit': 1, 'offset': 0})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('count', response.data)
        self.assertIn('results', response.data)

    def test_sales_comparison_no_data_returns_empty(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-sales-group')
        response = self.client.get(url, {'end_year': 2020, 'end_month': 1, 'months': 3})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 0)


class SalesTimelineEndpointTest(MVAPITestCase):
    def setUp(self):
        self.client = APIClient()
        self.material = TestDataFactory.create_material()
        today = date.today()
        for i in range(25):
            d = date(today.year, today.month, 1) - relativedelta(months=24 - i)
            OrderTransactionAggregated.objects.create(
                year=d.year, month=d.month,
                sales_amount=100, total_order_qty=10, total_shipped_qty=9,
                material=self.material,
            )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

    def test_sales_timeline_returns_200(self):
        url = reverse('order-transaction-aggregated:sales-timeline')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_sales_timeline_returns_25_months(self):
        url = reverse('order-transaction-aggregated:sales-timeline')
        response = self.client.get(url)
        self.assertEqual(len(response.data), 25)

    def test_sales_timeline_response_fields(self):
        url = reverse('order-transaction-aggregated:sales-timeline')
        response = self.client.get(url)
        for item in response.data:
            self.assertIn('year', item)
            self.assertIn('month', item)
            self.assertIn('sales_amount', item)
            self.assertIn('total_order_qty', item)
            self.assertIn('total_shipped_qty', item)

    def test_sales_timeline_ends_at_current_month(self):
        today = date.today()
        url = reverse('order-transaction-aggregated:sales-timeline')
        response = self.client.get(url)
        last = response.data[-1]
        self.assertEqual(last['year'], today.year)
        self.assertEqual(last['month'], today.month)

    def test_sales_timeline_no_query_params_accepted(self):
        """Timeline window is fixed -- extra params are ignored and still return 200"""
        url = reverse('order-transaction-aggregated:sales-timeline')
        response = self.client.get(url, {'months': 6})
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class FederalCsIndFilterTest(MVAPITestCase):
    """Integration tests for the federal_cs_ind query param filter."""

    def setUp(self):
        self.client = APIClient()
        self.mat_cs2 = TestDataFactory.create_material(federal_cs_ind='2')
        self.mat_cs3 = TestDataFactory.create_material(federal_cs_ind='3')
        self.mat_none = TestDataFactory.create_material(federal_cs_ind=None)
        self.customer = TestDataFactory.create_customer_corp_chain()

        for mat in [self.mat_cs2, self.mat_cs3, self.mat_none]:
            for month in [4, 5, 6]:
                OrderTransactionAggregated.objects.create(
                    year=2025, month=month,
                    sales_amount=1000, total_order_qty=100, total_shipped_qty=90,
                    sales_group='SG01', state='CA',
                    material=mat, cust_corp_chain_nbr=self.customer,
                )
            for month in [1, 2, 3]:
                OrderTransactionAggregated.objects.create(
                    year=2025, month=month,
                    sales_amount=600, total_order_qty=60, total_shipped_qty=50,
                    sales_group='SG01', state='CA',
                    material=mat, cust_corp_chain_nbr=self.customer,
                )

    def _params(self, **extra):
        return {'end_year': 2025, 'end_month': 6, 'months': 3, **extra}

    def test_by_sales_group_filters_single_value(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-sales-group')
        response = self.client.get(url, self._params(federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(float(response.data[0]['current_period_sales']), 3000)

    def test_by_sales_group_no_filter_returns_all(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-sales-group')
        response = self.client.get(url, self._params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(float(response.data[0]['current_period_sales']), 9000)

    def test_by_state_filters_comma_separated(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-state')
        response = self.client.get(url, self._params(federal_cs_ind='2,3'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(float(response.data[0]['current_period_sales']), 6000)

    def test_by_material_filters(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-material')
        response = self.client.get(url, self._params(federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['mat_nbr'], self.mat_cs2.mat_nbr)

    def test_by_customer_filters(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-customer')
        response = self.client.get(url, self._params(federal_cs_ind='3'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        self.assertEqual(float(results[0]['current_period_sales']), 3000)

    def test_sales_timeline_filters(self):
        today = date.today()
        for mat in [self.mat_cs2, self.mat_none]:
            for i in range(25):
                d = date(today.year, today.month, 1) - relativedelta(months=24 - i)
                OrderTransactionAggregated.objects.create(
                    year=d.year, month=d.month,
                    sales_amount=100, total_order_qty=10, total_shipped_qty=9,
                    material=mat,
                )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:sales-timeline')

        response_all = self.client.get(url)
        response_filtered = self.client.get(url, {'federal_cs_ind': '2'})

        self.assertEqual(response_all.status_code, status.HTTP_200_OK)
        self.assertEqual(response_filtered.status_code, status.HTTP_200_OK)

        total_all = sum(float(r['sales_amount']) for r in response_all.data)
        total_filtered = sum(float(r['sales_amount']) for r in response_filtered.data)
        self.assertGreater(total_all, total_filtered)

    def test_sales_timeline_material_filter(self):
        today = date.today()
        for i in range(25):
            d = date(today.year, today.month, 1) - relativedelta(months=24 - i)
            OrderTransactionAggregated.objects.create(
                year=d.year, month=d.month,
                sales_amount=200, total_order_qty=20, total_shipped_qty=18,
                material=self.mat_cs2,
            )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:sales-timeline')
        response = self.client.get(url, {'material': self.mat_cs2.mat_nbr})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 25)
        self.assertEqual(float(response.data[-1]['sales_amount']), 200.0)

    def test_nonexistent_value_returns_empty(self):
        url = reverse('order-transaction-aggregated:sales-comparison-by-sales-group')
        response = self.client.get(url, self._params(federal_cs_ind='99'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 0)

    def test_exclude_single_value(self):
        """exclude_federal_cs_ind=2 should return data for cs3 and None materials only."""
        url = reverse('order-transaction-aggregated:sales-comparison-by-sales-group')
        response = self.client.get(url, self._params(exclude_federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(float(response.data[0]['current_period_sales']), 6000)

    def test_exclude_comma_separated(self):
        """exclude_federal_cs_ind=2,3 should return data for None material only."""
        url = reverse('order-transaction-aggregated:sales-comparison-by-sales-group')
        response = self.client.get(url, self._params(exclude_federal_cs_ind='2,3'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(float(response.data[0]['current_period_sales']), 3000)

    def test_include_and_exclude_combined(self):
        """federal_cs_ind=2,3 + exclude_federal_cs_ind=3 should return only cs2."""
        url = reverse('order-transaction-aggregated:sales-comparison-by-sales-group')
        response = self.client.get(url, self._params(
            federal_cs_ind='2,3', exclude_federal_cs_ind='3'
        ))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(float(response.data[0]['current_period_sales']), 3000)


class FtsMaterialExposureIntegrationTests(BaseAPITestCase):
    """Integration tests for order-transaction-aggregated fail-to-supply/material-exposure/."""

    def setUp(self):
        self.client = APIClient()
        self.vendor = TestDataFactory.create_vendor()
        self.selected = date(2026, 7, 1)
        self.url = reverse("order-transaction-aggregated:fail-to-supply-material-exposure")
        self.material = TestDataFactory.create_material(
            vendor=self.vendor,
            ndc="10001-1001-01",
            name="Exposure Product",
        )

    def _month(self, months_before: int) -> date:
        return self.selected - relativedelta(months=months_before)

    def _seed(
        self, material=None, months_before=0, filled=95, ordered=100, net_sales=1000, sales_group="PRxO"
    ):
        month_date = self._month(months_before)
        return TestDataFactory.create_order_transaction_aggregated(
            year=month_date.year,
            month=month_date.month,
            material=material or self.material,
            sales_group=sales_group,
            state=(
                f"EXP-{sales_group}-{months_before}-{filled}-{net_sales}"
                f"-{id(material) if material else 0}"
            ),
            sales_less_cred_qty=net_sales,
            fts_lines_fully_filled=filled,
            fts_lines_ordered=ordered,
        )

    def _seed_full_path(self, material=None, selected_filled=50, selected_net=50, sales_group="PRxO"):
        material = material or self.material
        for months_before, net in [(1, 200), (2, 300), (3, 400)]:
            self._seed(
                material=material,
                months_before=months_before,
                filled=100,
                ordered=100,
                net_sales=net,
                sales_group=sales_group,
            )
        self._seed(
            material=material,
            months_before=0,
            filled=selected_filled,
            ordered=100,
            net_sales=selected_net,
            sales_group=sales_group,
        )

    def test_returns_200_with_expected_structure(self):
        self._seed_full_path()

        response = self.client.get(self.url, {"selected_month": "2026-07"})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("count", response.data)
        self.assertIn("results", response.data)
        result = response.data["results"][0]
        for key in (
            "product_ndc",
            "product_description",
            "service_level_pct",
            "net_sales",
            "full_supply_qty",
            "omits_qty",
            "outbound_fill_rate",
            "fts_exposure",
            "selected_month",
            "monthly_data",
        ):
            self.assertIn(key, result)
        self.assertEqual(result["selected_month"], "2026-07")
        self.assertEqual(len(result["monthly_data"]), 7)

    def test_selected_month_drives_metrics(self):
        self._seed_full_path(selected_filled=50, selected_net=50)

        response = self.client.get(self.url, {"selected_month": "2026-07"})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)
        result = response.data["results"][0]
        self.assertEqual(result["service_level_pct"], 50)
        self.assertEqual(result["net_sales"], 50)
        self.assertEqual(result["full_supply_qty"], 300)
        self.assertEqual(result["fts_exposure"], 250)
        self.assertEqual(
            result["monthly_data"]["2026-07"],
            {"service_level_pct": 50, "net_sales": 50},
        )

    def test_invalid_selected_month_returns_400(self):
        response = self.client.get(self.url, {"selected_month": "not-a-month"})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_invalid_ordering_returns_400(self):
        response = self.client.get(self.url, {"ordering": "invalid_field"})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_sales_group_selects_pgen(self):
        self._seed_full_path(selected_filled=50, selected_net=50)
        self._seed_full_path(selected_filled=25, selected_net=150, sales_group="PGEN")

        response = self.client.get(
            self.url, {"selected_month": "2026-07", "sales_group": "PGEN"}
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)
        result = response.data["results"][0]
        self.assertEqual(result["service_level_pct"], 25)
        self.assertEqual(result["net_sales"], 150)

    def test_sales_group_defaults_to_prxo(self):
        self._seed_full_path(selected_filled=50, selected_net=50)
        self._seed_full_path(selected_filled=25, selected_net=150, sales_group="PGEN")

        response = self.client.get(self.url, {"selected_month": "2026-07"})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)
        result = response.data["results"][0]
        self.assertEqual(result["service_level_pct"], 50)
        self.assertEqual(result["net_sales"], 50)

    def test_invalid_sales_group_returns_400(self):
        response = self.client.get(self.url, {"sales_group": "NOPE"})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_pagination_limit_offset(self):
        for i in range(5):
            mat = TestDataFactory.create_material(
                vendor=self.vendor,
                ndc=f"2000{i}-200{i}-0{i}",
                name=f"Product {i}",
            )
            self._seed_full_path(material=mat)

        response_p1 = self.client.get(
            self.url, {"selected_month": "2026-07", "limit": 2, "offset": 0}
        )
        response_p2 = self.client.get(
            self.url, {"selected_month": "2026-07", "limit": 2, "offset": 2}
        )

        self.assertEqual(response_p1.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response_p1.data["results"]), 2)
        ids_p1 = {r["product_ndc"] for r in response_p1.data["results"]}
        ids_p2 = {r["product_ndc"] for r in response_p2.data["results"]}
        self.assertTrue(ids_p1.isdisjoint(ids_p2))

    def test_ordering_by_fts_exposure_desc(self):
        mat_low = TestDataFactory.create_material(
            vendor=self.vendor, ndc="30001-3001-01", name="Low Exp"
        )
        mat_high = TestDataFactory.create_material(
            vendor=self.vendor, ndc="30002-3002-02", name="High Exp"
        )
        self._seed_full_path(material=mat_low, selected_filled=80, selected_net=200)
        self._seed_full_path(material=mat_high, selected_filled=50, selected_net=50)

        response = self.client.get(
            self.url, {"selected_month": "2026-07", "ordering": "-fts_exposure"}
        )

        exposures = [r["fts_exposure"] for r in response.data["results"]]
        self.assertEqual(exposures, sorted(exposures, reverse=True))

    def test_empty_dataset_returns_empty_results(self):
        response = self.client.get(self.url, {"selected_month": "2026-07"})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 0)
        self.assertEqual(response.data["results"], [])

    def test_supplier_nbr_filter_isolates_materials(self):
        other_vendor = TestDataFactory.create_vendor()
        other_mat = TestDataFactory.create_material(
            vendor=other_vendor,
            ndc="40001-4001-01",
            name="Other Vendor Product",
        )
        self._seed_full_path(material=self.material, selected_filled=50, selected_net=50)
        self._seed_full_path(material=other_mat, selected_filled=10, selected_net=10)

        response = self.client.get(
            self.url,
            {
                "selected_month": "2026-07",
                "supplier_nbr": self.vendor.vendor_nbr,
            },
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        ndcs = {r["product_ndc"] for r in response.data["results"]}
        self.assertEqual(ndcs, {self.material.ndc})


class FtsMaterialExposureExportIntegrationTests(BaseAPITestCase):
    """CSV contract tests for Material FTS Quantity Exposure export."""

    SCALAR_HEADERS = [
        "Material NDC",
        "Material Description",
        "Total Service Level",
        "Outbound Fill Rate",
        "Omits",
        "Sales",
        "Full Supply Qty",
        "FTS Exposure",
    ]

    def setUp(self):
        self.client = APIClient()
        self.vendor = TestDataFactory.create_vendor()
        self.selected = date(2026, 7, 1)
        self.url = reverse("order-transaction-aggregated:fail-to-supply-material-exposure-export")
        self.material = TestDataFactory.create_material(
            vendor=self.vendor,
            ndc="10001-1001-01",
            name="Exposure Product",
        )

    def _month(self, months_before: int) -> date:
        return self.selected - relativedelta(months=months_before)

    def _seed(
        self,
        material=None,
        months_before=0,
        filled=95,
        ordered=100,
        net_sales=1000,
        total_order_qty=0,
        total_shipped_qty=0,
    ):
        month_date = self._month(months_before)
        return TestDataFactory.create_order_transaction_aggregated(
            year=month_date.year,
            month=month_date.month,
            material=material or self.material,
            sales_group="PRxO",
            state=f"EXP-{months_before}-{filled}-{net_sales}-{id(material) if material else 0}",
            sales_less_cred_qty=net_sales,
            fts_lines_fully_filled=filled,
            fts_lines_ordered=ordered,
            total_order_qty=total_order_qty,
            total_shipped_qty=total_shipped_qty,
        )

    def _seed_full_path(
        self,
        material=None,
        selected_filled=50,
        selected_net=50,
        total_order_qty=100,
        total_shipped_qty=80,
    ):
        material = material or self.material
        for months_before, net in [(1, 200), (2, 300), (3, 400), (4, 500), (5, 600), (6, 700)]:
            self._seed(material=material, months_before=months_before, filled=100, ordered=100, net_sales=net)
        self._seed(
            material=material,
            months_before=0,
            filled=selected_filled,
            ordered=100,
            net_sales=selected_net,
            total_order_qty=total_order_qty,
            total_shipped_qty=total_shipped_qty,
        )

    @staticmethod
    def _csv_rows(response):
        content = b"".join(response.streaming_content).decode("utf-8")
        return list(csv.reader(io.StringIO(content)))

    def test_export_returns_csv_with_expected_headers_and_row_values(self):
        self._seed_full_path(selected_filled=50, selected_net=50)

        response = self.client.get(
            self.url,
            {"selected_month": "2026-07", "lookback_months": 6, "ordering": "-fts_exposure"},
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response["Content-Type"], "text/csv")
        self.assertIn(
            "material_fts_quantity_exposure_",
            response["Content-Disposition"],
        )
        self.assertEqual(response.get("X-Accel-Buffering"), "no")

        rows = self._csv_rows(response)
        header = rows[0]
        self.assertEqual(header[:8], self.SCALAR_HEADERS)
        self.assertEqual(len(header), 20)
        self.assertEqual(
            header[8:],
            [
                "Line Service Level 2026-06",
                "Net Sales 2026-06",
                "Line Service Level 2026-05",
                "Net Sales 2026-05",
                "Line Service Level 2026-04",
                "Net Sales 2026-04",
                "Line Service Level 2026-03",
                "Net Sales 2026-03",
                "Line Service Level 2026-02",
                "Net Sales 2026-02",
                "Line Service Level 2026-01",
                "Net Sales 2026-01",
            ],
        )

        data = dict(zip(header, rows[1]))
        self.assertEqual(data["Material NDC"], self.material.ndc)
        self.assertEqual(data["Material Description"], "Exposure Product")
        self.assertEqual(data["Total Service Level"], "50")
        self.assertAlmostEqual(float(data["Outbound Fill Rate"]), 80.0, places=4)
        self.assertEqual(data["Omits"], "20")
        self.assertEqual(data["Sales"], "50")
        self.assertEqual(data["Full Supply Qty"], "300")
        self.assertEqual(data["FTS Exposure"], "250")
        self.assertEqual(data["Line Service Level 2026-06"], "100")
        self.assertEqual(data["Net Sales 2026-06"], "200")

    def test_supplier_nbr_filter_narrows_export(self):
        other_vendor = TestDataFactory.create_vendor()
        other_mat = TestDataFactory.create_material(
            vendor=other_vendor,
            ndc="40001-4001-01",
            name="Other Vendor Product",
        )
        self._seed_full_path(material=self.material, selected_filled=50, selected_net=50)
        self._seed_full_path(material=other_mat, selected_filled=10, selected_net=10)

        response = self.client.get(
            self.url,
            {
                "selected_month": "2026-07",
                "supplier_nbr": self.vendor.vendor_nbr,
            },
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        rows = self._csv_rows(response)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[1][0], self.material.ndc)

    def test_export_ignores_limit_and_offset(self):
        for i in range(2):
            mat = TestDataFactory.create_material(
                vendor=self.vendor,
                ndc=f"5000{i}-500{i}-0{i}",
                name=f"Product {i}",
            )
            self._seed_full_path(material=mat)

        response = self.client.get(
            self.url,
            {"selected_month": "2026-07", "limit": 1, "offset": 0},
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        rows = self._csv_rows(response)
        self.assertEqual(len(rows), 3)

    @patch("api.order_transaction_aggregated.views.get_fts_material_exposure_results")
    def test_export_rejects_when_row_count_exceeds_cap(self, mock_get_results):
        mock_get_results.return_value = (
            [{"product_ndc": f"ndc-{i}"} for i in range(DEFAULT_EXPORT_MAX_ROWS + 1)],
            {"lookback_months": 6, "selected_month": date(2026, 7, 1)},
        )

        response = self.client.get(self.url, {"selected_month": "2026-07"})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("Export exceeds the maximum", str(response.data))


class SalesYtdIntegrationTest(MVAPITestCase):
    """Integration tests for the sales-ytd endpoint."""

    def setUp(self):
        self.client = APIClient()
        self.material = TestDataFactory.create_material()
        today = date.today()
        self.current_year = today.year
        self.previous_year = today.year - 1
        self.current_month = today.month

        for year in (self.previous_year, self.current_year):
            for month in range(1, 13):
                OrderTransactionAggregated.objects.create(
                    year=year,
                    month=month,
                    total_order_qty=100,
                    total_shipped_qty=80,
                    sales_amount=1000,
                    material=self.material,
                )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

    def test_sales_ytd_returns_200_and_shape(self):
        url = reverse('order-transaction-aggregated:sales-ytd')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        for key in ('current_ytd', 'previous_ytd', 'pct_change', 'trend'):
            self.assertIn(key, response.data)

        for totals_key in ('current_ytd', 'previous_ytd'):
            for field in ('total_order_qty', 'total_shipped_qty', 'sales_amount'):
                self.assertIn(field, response.data[totals_key])

        for field in ('total_order_qty', 'total_shipped_qty', 'sales_amount'):
            self.assertIn(field, response.data['pct_change'])

        self.assertEqual(len(response.data['trend']), self.current_month)
        for point in response.data['trend']:
            for field in ('year', 'month', 'total_order_qty', 'total_shipped_qty', 'sales_amount'):
                self.assertIn(field, point)

    def test_sales_ytd_with_material_global_filter(self):
        other = TestDataFactory.create_material()
        for month in range(1, self.current_month + 1):
            OrderTransactionAggregated.objects.create(
                year=self.current_year,
                month=month,
                total_order_qty=999,
                total_shipped_qty=888,
                sales_amount=777,
                material=other,
            )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:sales-ytd')
        response = self.client.get(url, {'material': self.material.mat_nbr})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            response.data['current_ytd']['total_order_qty'],
            100 * self.current_month,
        )
        self.assertEqual(
            response.data['current_ytd']['total_shipped_qty'],
            80 * self.current_month,
        )


class SalesYtdComparisonEndpointTest(MVAPITestCase):
    """
    Integration tests for the YtD comparison endpoints.
    Uses year=2026, through_month=8:
      current period:  Jan-Aug 2026
      baseline period: Jan-Aug 2025
    """

    def setUp(self):
        self.client = APIClient()
        self.mat_cs2 = TestDataFactory.create_material(ndc='11111-222-33', federal_cs_ind='2')
        self.mat_cs3 = TestDataFactory.create_material(ndc='44444-555-66', federal_cs_ind='3')
        self.customer = TestDataFactory.create_customer_corp_chain()

        for mat in [self.mat_cs2, self.mat_cs3]:
            for month in range(1, 9):
                OrderTransactionAggregated.objects.create(
                    year=2026, month=month,
                    sales_amount=1000, total_order_qty=100, total_shipped_qty=90,
                    sales_group='SG01', state='CA',
                    material=mat, cust_corp_chain_nbr=self.customer,
                )
                OrderTransactionAggregated.objects.create(
                    year=2026, month=month,
                    sales_amount=500, total_order_qty=50, total_shipped_qty=40,
                    sales_group='SG02', state='CA',
                    material=mat, cust_corp_chain_nbr=self.customer,
                )
                OrderTransactionAggregated.objects.create(
                    year=2025, month=month,
                    sales_amount=600, total_order_qty=60, total_shipped_qty=50,
                    sales_group='SG01', state='CA',
                    material=mat, cust_corp_chain_nbr=self.customer,
                )
            # Outside the window — must not reach the baseline.
            OrderTransactionAggregated.objects.create(
                year=2025, month=12,
                sales_amount=9999, total_order_qty=999, total_shipped_qty=888,
                sales_group='SG01', state='CA',
                material=mat, cust_corp_chain_nbr=self.customer,
            )

        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

    def _params(self, **extra):
        return {'year': 2026, 'through_month': 8, **extra}

    def _parse_export_csv(self, response):
        content = b"".join(response.streaming_content).decode("utf-8")
        rows = list(csv.reader(io.StringIO(content)))
        self.assertGreaterEqual(len(rows), 1)
        return rows[0], rows[1:]

    def _assert_ytd_fields(self, item):
        for field in [
            'current_ytd_sales', 'previous_ytd_sales',
            'current_ytd_order_qty', 'previous_ytd_order_qty',
            'current_ytd_shipped_qty', 'previous_ytd_shipped_qty',
            'sales_yoy_pct', 'order_qty_yoy_pct', 'shipped_qty_yoy_pct',
        ]:
            self.assertIn(field, item)

    def test_by_material_returns_material_identity_and_metrics(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        response = self.client.get(url, self._params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 2)
        row = next(r for r in results if r['mat_nbr'] == self.mat_cs2.mat_nbr)
        self._assert_ytd_fields(row)
        self.assertEqual(row['material_name'], self.mat_cs2.name)
        self.assertEqual(row['ndc'], '11111-222-33')
        self.assertEqual(row['federal_cs_ind'], '2')
        self.assertEqual(float(row['current_ytd_sales']), 12000)
        self.assertEqual(float(row['previous_ytd_sales']), 4800)
        self.assertEqual(row['sales_yoy_pct'], 150.0)

    def test_by_material_carries_sales_group_breakdown(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        response = self.client.get(url, self._params())

        row = response.data['results'][0]
        breakdown = {b['sales_group']: b for b in row['sales_group_breakdown']}
        self.assertEqual(set(breakdown), {'SG01', 'SG02'})
        self._assert_ytd_fields(breakdown['SG01'])
        self.assertEqual(float(breakdown['SG01']['current_ytd_sales']), 8000)
        self.assertEqual(float(breakdown['SG02']['current_ytd_sales']), 4000)
        self.assertEqual(
            sum(float(b['current_ytd_sales']) for b in row['sales_group_breakdown']),
            float(row['current_ytd_sales']),
        )

    def test_by_material_pagination(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        response = self.client.get(url, self._params(limit=1, offset=0))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['count'], 2)
        self.assertEqual(len(response.data['results']), 1)

    def test_by_material_filters_federal_cs_ind(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        response = self.client.get(url, self._params(federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['mat_nbr'], self.mat_cs2.mat_nbr)

    def test_by_material_excludes_federal_cs_ind(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        response = self.client.get(url, self._params(exclude_federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['mat_nbr'], self.mat_cs3.mat_nbr)

    def test_by_material_ordering(self):
        small = TestDataFactory.create_material(ndc='77777-888-99', federal_cs_ind=None)
        for month in range(1, 9):
            OrderTransactionAggregated.objects.create(
                year=2026, month=month,
                sales_amount=100, total_order_qty=10, total_shipped_qty=5,
                sales_group='SG01', state='CA',
                material=small, cust_corp_chain_nbr=self.customer,
            )
        MaterializedViewTestHelper.refresh_single_view('ot_agg_monthly_material_mv')

        url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        response = self.client.get(url, self._params(ordering='current_ytd_sales'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        sales = [float(row['current_ytd_sales']) for row in response.data['results']]
        self.assertEqual(sales, sorted(sales))

    def test_by_material_ignores_unknown_ordering(self):
        """Unknown ordering terms fall back to the default, as on every other list endpoint."""
        url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        response = self.client.get(url, self._params(ordering='sales_yoy_pct'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        sales = [float(row['current_ytd_sales']) for row in response.data['results']]
        self.assertEqual(sales, sorted(sales, reverse=True))

    def test_by_material_export_csv_shape_and_content(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-material-export')
        response = self.client.get(url, self._params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response['Content-Type'], 'text/csv')
        self.assertIn('attachment; filename=', response['Content-Disposition'])
        self.assertIn('sales_ytd_by_material_', response['Content-Disposition'])
        self.assertEqual(response.get('X-Accel-Buffering'), 'no')

        header, data_rows = self._parse_export_csv(response)
        self.assertIn('Product Name', header)
        self.assertIn('Product Id', header)
        self.assertIn('Sales YoY Change', header)
        self.assertGreaterEqual(len(data_rows), 2)

        matching = [row for row in data_rows if row[1] == self.mat_cs2.mat_nbr]
        self.assertEqual(len(matching), 1)
        row = matching[0]
        self.assertEqual(row[0], self.mat_cs2.name)
        self.assertEqual(row[2], '11111-222-33')
        self.assertEqual(row[3], '2')

    def test_by_material_export_values_match_list(self):
        list_url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        list_response = self.client.get(list_url, self._params(limit=100))
        list_row = next(
            row for row in list_response.data['results'] if row['mat_nbr'] == self.mat_cs2.mat_nbr
        )

        export_url = reverse('order-transaction-aggregated:sales-ytd-by-material-export')
        export_response = self.client.get(export_url, self._params())
        _, data_rows = self._parse_export_csv(export_response)
        csv_row = next(row for row in data_rows if row[1] == self.mat_cs2.mat_nbr)

        self.assertEqual(csv_row[0], list_row['material_name'])
        self.assertEqual(csv_row[2], list_row['ndc'])
        self.assertEqual(csv_row[3], list_row['federal_cs_ind'])
        self.assertEqual(float(csv_row[4]), float(list_row['current_ytd_sales']))
        self.assertEqual(float(csv_row[5]), float(list_row['previous_ytd_sales']))
        self.assertEqual(float(csv_row[6]), float(list_row['current_ytd_order_qty']))
        self.assertEqual(float(csv_row[7]), float(list_row['previous_ytd_order_qty']))
        self.assertEqual(float(csv_row[8]), float(list_row['current_ytd_shipped_qty']))
        self.assertEqual(float(csv_row[9]), float(list_row['previous_ytd_shipped_qty']))
        self.assertEqual(float(csv_row[10]), list_row['sales_yoy_pct'])
        self.assertEqual(float(csv_row[11]), list_row['order_qty_yoy_pct'])
        self.assertEqual(float(csv_row[12]), list_row['shipped_qty_yoy_pct'])

    def test_by_material_export_respects_federal_cs_ind(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-material-export')
        response = self.client.get(url, self._params(federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        _, data_rows = self._parse_export_csv(response)
        product_ids = {row[1] for row in data_rows}
        self.assertEqual(product_ids, {self.mat_cs2.mat_nbr})

    def test_by_material_export_respects_ordering(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-material-export')
        response = self.client.get(url, self._params(ordering='current_ytd_sales'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        _, data_rows = self._parse_export_csv(response)
        sales = [float(row[4]) for row in data_rows if row[4]]
        self.assertEqual(sales, sorted(sales))

    def test_by_material_export_ignores_pagination(self):
        list_url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        list_response = self.client.get(list_url, self._params())
        list_count = list_response.data['count']

        export_url = reverse('order-transaction-aggregated:sales-ytd-by-material-export')
        export_response = self.client.get(
            export_url,
            self._params(limit=1, offset=0),
        )

        self.assertEqual(export_response.status_code, status.HTTP_200_OK)
        _, data_rows = self._parse_export_csv(export_response)
        self.assertEqual(len(data_rows), list_count)

    def test_by_material_export_soft_cap(self):
        mock_qs = MagicMock()
        mock_qs.count.return_value = DEFAULT_EXPORT_MAX_ROWS + 1

        with patch(
            'api.order_transaction_aggregated.views.SalesYtdByMaterialExportView.get_filtered_queryset',
            return_value=mock_qs,
        ):
            response = self.client.get(
                reverse('order-transaction-aggregated:sales-ytd-by-material-export'),
                self._params(),
            )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('Export exceeds the maximum', str(response.data['error']))
        mock_qs.iterator.assert_not_called()

    def test_by_customer_export_csv_shape_and_values_match_list(self):
        list_url = reverse('order-transaction-aggregated:sales-ytd-by-customer')
        list_response = self.client.get(list_url, self._params(limit=100))
        list_row = list_response.data['results'][0]

        export_url = reverse('order-transaction-aggregated:sales-ytd-by-customer-export')
        export_response = self.client.get(export_url, self._params())
        self.assertEqual(export_response.status_code, status.HTTP_200_OK)
        self.assertIn('sales_ytd_by_customer_', export_response['Content-Disposition'])

        header, data_rows = self._parse_export_csv(export_response)
        self.assertIn('Customer Name', header)
        self.assertIn('Customer Corp Chain Nbr', header)
        self.assertEqual(len(data_rows), 1)
        csv_row = data_rows[0]
        self.assertEqual(csv_row[0], list_row['customer_name'])
        self.assertEqual(csv_row[1], list_row['cust_corp_chain_nbr'])
        self.assertEqual(float(csv_row[2]), float(list_row['current_ytd_sales']))
        self.assertEqual(float(csv_row[8]), list_row['sales_yoy_pct'])

    def test_by_customer_export_respects_federal_cs_ind(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-customer-export')
        response = self.client.get(url, self._params(federal_cs_ind='2'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        _, data_rows = self._parse_export_csv(response)
        self.assertEqual(len(data_rows), 1)
        self.assertEqual(float(data_rows[0][2]), 12000.0)

    def test_by_sales_group_export_csv_shape_and_values_match_list(self):
        list_url = reverse('order-transaction-aggregated:sales-ytd-by-sales-group')
        list_response = self.client.get(list_url, self._params())
        list_row = next(row for row in list_response.data if row['sales_group'] == 'SG01')

        export_url = reverse('order-transaction-aggregated:sales-ytd-by-sales-group-export')
        export_response = self.client.get(export_url, self._params())
        self.assertEqual(export_response.status_code, status.HTTP_200_OK)
        self.assertIn('sales_ytd_by_sales_group_', export_response['Content-Disposition'])

        header, data_rows = self._parse_export_csv(export_response)
        self.assertIn('Sales Group', header)
        csv_row = next(row for row in data_rows if row[0] == 'SG01')
        self.assertEqual(float(csv_row[1]), float(list_row['current_ytd_sales']))
        self.assertEqual(float(csv_row[7]), list_row['sales_yoy_pct'])

    def test_by_customer_returns_customer_identity_and_breakdown(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-customer')
        response = self.client.get(url, self._params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        row = results[0]
        self._assert_ytd_fields(row)
        self.assertEqual(row['cust_corp_chain_nbr'], self.customer.cust_corp_chain_nbr)
        self.assertEqual(row['customer_name'], self.customer.name)
        self.assertNotIn('ndc', row)
        self.assertNotIn('federal_cs_ind', row)
        # Both materials, both sales groups: (1000 + 500) x 8 x 2
        self.assertEqual(float(row['current_ytd_sales']), 24000)
        self.assertEqual(float(row['previous_ytd_sales']), 9600)
        breakdown = {b['sales_group']: b for b in row['sales_group_breakdown']}
        self.assertEqual(set(breakdown), {'SG01', 'SG02'})

    def test_by_customer_filters_federal_cs_ind(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-customer')
        response = self.client.get(url, self._params(federal_cs_ind='2'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(float(response.data['results'][0]['current_ytd_sales']), 12000)

    def test_by_sales_group_returns_flat_list(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-sales-group')
        response = self.client.get(url, self._params())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        rows = {row['sales_group']: row for row in response.data}
        self.assertEqual(set(rows), {'SG01', 'SG02'})
        self._assert_ytd_fields(rows['SG01'])
        self.assertNotIn('sales_group_breakdown', rows['SG01'])
        self.assertEqual(float(rows['SG01']['current_ytd_sales']), 16000)
        self.assertEqual(float(rows['SG01']['previous_ytd_sales']), 9600)
        self.assertEqual(float(rows['SG02']['current_ytd_sales']), 8000)
        self.assertIsNone(rows['SG02']['sales_yoy_pct'])

    def test_defaults_to_current_year_and_month(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-sales-group')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_rejects_non_integer_year(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-material')
        response = self.client.get(url, {'year': 'oops'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_rejects_out_of_range_through_month(self):
        url = reverse('order-transaction-aggregated:sales-ytd-by-customer')
        response = self.client.get(url, self._params(through_month=13))
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)


class SalesComparisonExportIntegrationTests(MVAPITestCase):
    """CSV export tests for sales-comparison-by-material and by-customer."""

    def setUp(self):
        self.client = APIClient()
        self.material = TestDataFactory.create_material(name="Compare Material")
        self.customer = TestDataFactory.create_customer_corp_chain(name="Compare Customer")

        for month in range(3, 9):
            OrderTransactionAggregated.objects.create(
                year=2026,
                month=month,
                sales_amount=1000,
                total_order_qty=100,
                total_shipped_qty=90,
                sales_group='SG01',
                state='CA',
                material=self.material,
                cust_corp_chain_nbr=self.customer,
            )
            OrderTransactionAggregated.objects.create(
                year=2025,
                month=month,
                sales_amount=500,
                total_order_qty=50,
                total_shipped_qty=40,
                sales_group='SG01',
                state='CA',
                material=self.material,
                cust_corp_chain_nbr=self.customer,
            )

    def _params(self, **extra):
        return {'end_year': 2026, 'end_month': 8, 'months': 6, **extra}

    def _parse_export_csv(self, response):
        content = b"".join(response.streaming_content).decode("utf-8")
        rows = list(csv.reader(io.StringIO(content)))
        return rows[0], rows[1:]

    def test_by_material_export_matches_list(self):
        list_url = reverse('order-transaction-aggregated:sales-comparison-by-material')
        list_row = self.client.get(list_url, self._params(limit=100)).data['results'][0]

        export_url = reverse('order-transaction-aggregated:sales-comparison-by-material-export')
        response = self.client.get(export_url, self._params())
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('sales_comparison_by_material_', response['Content-Disposition'])

        header, data_rows = self._parse_export_csv(response)
        self.assertIn('Product Id', header)
        self.assertEqual(len(data_rows), 1)
        self.assertEqual(data_rows[0][0], list_row['mat_nbr'])
        self.assertEqual(float(data_rows[0][2]), float(list_row['current_period_sales']))

    def test_by_customer_export_matches_list(self):
        list_url = reverse('order-transaction-aggregated:sales-comparison-by-customer')
        list_row = self.client.get(list_url, self._params(limit=100)).data['results'][0]

        export_url = reverse('order-transaction-aggregated:sales-comparison-by-customer-export')
        response = self.client.get(export_url, self._params())
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('sales_comparison_by_customer_', response['Content-Disposition'])

        header, data_rows = self._parse_export_csv(response)
        self.assertIn('Customer Corp Chain Nbr', header)
        self.assertEqual(len(data_rows), 1)
        self.assertEqual(data_rows[0][0], list_row['cust_corp_chain_nbr'])
        self.assertEqual(float(data_rows[0][2]), float(list_row['current_period_sales']))
