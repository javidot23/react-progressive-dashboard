import logging
from datetime import date

from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiParameter, extend_schema, extend_schema_view, inline_serializer
from rest_framework import generics, serializers
from rest_framework.exceptions import ValidationError
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView

from api.csv_export import (
    CsvExportView,
    apply_ordering,
    enforce_export_row_cap_count,
    streaming_csv_response,
)
from api.global_filters import extract_corp_chain_param, get_filtered_material_subquery
from api.pagination import Limit25OffsetPagination, MaxLimitOffsetPagination
from .serializers import (
    FtsMaterialExposureSerializer,
    OrderTransactionAggregatedSerializer,
    SalesComparisonByCustomerSerializer,
    SalesComparisonByMaterialSerializer,
    SalesComparisonBySalesGroupSerializer,
    SalesComparisonByStateSerializer,
    SalesComparisonSerializer,
    SalesTimelineSerializer,
    SalesYtdByCustomerSerializer,
    SalesYtdByMaterialSerializer,
    SalesYtdBySalesGroupSerializer,
    SalesYtdSerializer,
)
from .filters import FederalCsIndFilterMixin
from .services import FTS_SALES_GROUPS, OrderTransactionAggregatedService

logger = logging.getLogger(__name__)

_PERIOD_PARAMS = [
    OpenApiParameter(name='end_year', type=OpenApiTypes.INT, required=False),
    OpenApiParameter(name='end_month', type=OpenApiTypes.INT, required=False),
    OpenApiParameter(name='months', type=OpenApiTypes.INT, required=False),
]

_PAGINATED_SALES_COMPARISON_BY_CUSTOMER_RESPONSE = inline_serializer(
    'PaginatedSalesComparisonByCustomerResponse',
    fields={
        'count': serializers.IntegerField(),
        'next': serializers.URLField(allow_null=True, required=False),
        'previous': serializers.URLField(allow_null=True, required=False),
        'results': SalesComparisonByCustomerSerializer(many=True),
    },
)

_PAGINATED_SALES_COMPARISON_BY_MATERIAL_RESPONSE = inline_serializer(
    'PaginatedSalesComparisonByMaterialResponse',
    fields={
        'count': serializers.IntegerField(),
        'next': serializers.URLField(allow_null=True, required=False),
        'previous': serializers.URLField(allow_null=True, required=False),
        'results': SalesComparisonByMaterialSerializer(many=True),
    },
)

_PAGINATED_FTS_MATERIAL_EXPOSURE_RESPONSE = inline_serializer(
    'PaginatedFtsMaterialExposureResponse',
    fields={
        'count': serializers.IntegerField(),
        'next': serializers.URLField(allow_null=True, required=False),
        'previous': serializers.URLField(allow_null=True, required=False),
        'results': FtsMaterialExposureSerializer(many=True),
    },
)

_YTD_PARAMS = [
    OpenApiParameter(name='year', type=OpenApiTypes.INT, required=False),
    OpenApiParameter(name='through_month', type=OpenApiTypes.INT, required=False),
]

_YTD_METRIC_ORDERING_FIELDS = [
    f'{prefix}_ytd_{name}'
    for prefix in ('current', 'previous')
    for name in ('sales', 'order_qty', 'shipped_qty')
]


def _get_material_ids_from_global_filters(request):
    """
    Extracts material IDs from global filter query params.
    Returns a list of mat_nbr values, or None if no global filters are active.
    """
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)

    if direct_mat_nbr and mat_nbr_subquery is None:
        return [direct_mat_nbr]
    if mat_nbr_subquery is not None:
        ids = list(mat_nbr_subquery)
        if direct_mat_nbr:
            ids = [mid for mid in ids if mid == direct_mat_nbr]
        return ids
    return None


def _parse_period_params(request):
    """
    Extracts and validates end_year, end_month, and months from query params.
    Defaults: end = current month, months = 6.
    """
    today = date.today()
    try:
        end_year = int(request.query_params.get('end_year', today.year))
        end_month = int(request.query_params.get('end_month', today.month))
        months = int(request.query_params.get('months', 6))
    except (TypeError, ValueError):
        end_year = today.year
        end_month = today.month
        months = 6

    months = max(1, min(months, 24))
    return end_year, end_month, months


def _parse_ytd_params(request):
    """
    Extracts and validates year and through_month from query params.
    Defaults to the current year and month.
    """
    today = date.today()
    try:
        year = int(request.query_params.get('year', today.year))
    except (TypeError, ValueError):
        raise ValidationError({'detail': 'Invalid year. Expected an integer.'})

    try:
        through_month = int(request.query_params.get('through_month', today.month))
    except (TypeError, ValueError):
        raise ValidationError({'detail': 'Invalid through_month. Expected an integer.'})

    if not 1 <= through_month <= 12:
        raise ValidationError({'detail': 'Invalid through_month. Expected a value between 1 and 12.'})

    return year, through_month


def _attach_sales_group_breakdown(rows, year, through_month, group_field):
    """
    Stamps year-over-year percent change and a per-sales-group breakdown onto a page of YtD rows.
    The breakdown is fetched with a single query covering the whole page.
    """
    rows = list(rows)
    keys = [row[group_field] for row in rows]
    breakdown = OrderTransactionAggregatedService.get_sales_group_ytd_breakdown(
        year, through_month, group_field, keys
    )
    for row in rows:
        OrderTransactionAggregatedService.attach_ytd_pct_change(row)
        row['sales_group_breakdown'] = breakdown.get(row[group_field], [])
    return rows


@extend_schema_view(
    get=extend_schema(responses=OrderTransactionAggregatedSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OrderTransactionAggregatedListView(APIView):
    """
    API view to retrieve aggregated order transaction data for the current year and the previous year.
    Supports global material filters via query params.
    """
    service = OrderTransactionAggregatedService()

    def get(self, request, *args, **kwargs):
        material_ids = _get_material_ids_from_global_filters(request)
        aggregated_data = self.service.get_aggregated_data_for_current_and_previous_year(
            material_ids=material_ids
        )
        data_list = list(aggregated_data)
        for item in data_list:
            item.setdefault('total_order_qty', 0)
            item.setdefault('total_shipped_qty', 0)
        return Response(data_list)


@extend_schema_view(
    get=extend_schema(responses=SalesComparisonSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonByMonthView(APIView):
    """
    API view to retrieve sales comparison data by month for the current and previous year.
    Supports global material filters via query params.
    """
    service = OrderTransactionAggregatedService()

    def get(self, request, *args, **kwargs):
        material_ids = _get_material_ids_from_global_filters(request)
        comparison_data = self.service.get_sales_comparison_by_month(
            material_ids=material_ids
        )
        serializer = SalesComparisonSerializer(comparison_data, many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=SalesTimelineSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesTimelineView(FederalCsIndFilterMixin, APIView):
    """
    Returns 25 months of monthly aggregated totals (2x12 + 1 lead-in month),
    ending at the current month. Used for the timeline chart with month-over-month change.
    No query params — the window is always fixed.
    """

    def get(self, request, *args, **kwargs):
        data = OrderTransactionAggregatedService.get_sales_timeline()
        data = self.apply_federal_cs_ind_filter(data, request)
        serializer = SalesTimelineSerializer(list(data), many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=SalesYtdSerializer,
        description=(
            "Sales YTD KPI: current vs previous year-to-date totals "
            "(order qty, shipped qty, sales amount), percent change on each field, "
            "and a monthly trend for the current year through the current month. "
            "Supports global material filters."
        ),
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesYtdView(APIView):
    """
    Returns year-to-date sales KPI with YoY comparison and monthly trend.
    Supports global material filters via query params.
    """

    def get(self, request, *args, **kwargs):
        material_ids = _get_material_ids_from_global_filters(request)
        data = OrderTransactionAggregatedService.get_sales_ytd(material_ids=material_ids)
        serializer = SalesYtdSerializer(data)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=SalesComparisonBySalesGroupSerializer(many=True),
        parameters=_PERIOD_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonBySalesGroupView(FederalCsIndFilterMixin, APIView):
    """
    Returns sales comparison (current period vs previous period) grouped by sales_group.

    Query params:
      - end_year  (int, default: current year)
      - end_month (int, default: current month)
      - months    (int 1–24, default: 6)
    """

    def get(self, request, *args, **kwargs):
        end_year, end_month, months = _parse_period_params(request)
        logger.info(
            "SalesComparisonBySalesGroupView: end=%s-%s months=%s",
            end_year, end_month, months
        )
        data = OrderTransactionAggregatedService.get_sales_comparison_by_sales_group(
            end_year, end_month, months
        )
        data = self.apply_federal_cs_ind_filter(data, request)
        serializer = SalesComparisonBySalesGroupSerializer(list(data), many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=SalesComparisonByStateSerializer(many=True),
        parameters=_PERIOD_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonByStateView(FederalCsIndFilterMixin, APIView):
    """
    Returns sales comparison (current period vs previous period) grouped by state.

    Query params:
      - end_year  (int, default: current year)
      - end_month (int, default: current month)
      - months    (int 1–24, default: 6)
    """

    def get(self, request, *args, **kwargs):
        end_year, end_month, months = _parse_period_params(request)
        logger.info(
            "SalesComparisonByStateView: end=%s-%s months=%s",
            end_year, end_month, months
        )
        data = OrderTransactionAggregatedService.get_sales_comparison_by_state(
            end_year, end_month, months
        )
        data = self.apply_federal_cs_ind_filter(data, request)
        serializer = SalesComparisonByStateSerializer(list(data), many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=_PAGINATED_SALES_COMPARISON_BY_CUSTOMER_RESPONSE,
        parameters=_PERIOD_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonByCustomerView(FederalCsIndFilterMixin, APIView):
    """
    Returns paginated sales comparison (current period vs previous period) grouped by customer
    corp chain, ordered by current_period_sales descending.

    Query params:
      - end_year  (int, default: current year)
      - end_month (int, default: current month)
      - months    (int 1–24, default: 6)
      - limit     (int, default: 25, max: 50)
      - offset    (int, default: 0)
    """
    pagination_class = MaxLimitOffsetPagination

    def get(self, request, *args, **kwargs):
        end_year, end_month, months = _parse_period_params(request)
        logger.info(
            "SalesComparisonByCustomerView: end=%s-%s months=%s",
            end_year, end_month, months
        )
        queryset = OrderTransactionAggregatedService.get_sales_comparison_by_customer(
            end_year, end_month, months
        )
        queryset = self.apply_federal_cs_ind_filter(queryset, request)

        paginator = self.pagination_class()
        paginator.default_limit = 25
        page = paginator.paginate_queryset(queryset, request)

        serializer = SalesComparisonByCustomerSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=_PAGINATED_SALES_COMPARISON_BY_MATERIAL_RESPONSE,
        parameters=_PERIOD_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonByMaterialView(FederalCsIndFilterMixin, APIView):
    """
    Returns paginated sales comparison (current period vs previous period) grouped by material,
    ordered by current_period_sales descending.

    Query params:
      - end_year  (int, default: current year)
      - end_month (int, default: current month)
      - months    (int 1–24, default: 6)
      - limit     (int, default: 25, max: 50)
      - offset    (int, default: 0)
    """
    pagination_class = MaxLimitOffsetPagination

    def get(self, request, *args, **kwargs):
        end_year, end_month, months = _parse_period_params(request)
        logger.info(
            "SalesComparisonByMaterialView: end=%s-%s months=%s",
            end_year, end_month, months
        )
        queryset = OrderTransactionAggregatedService.get_sales_comparison_by_material(
            end_year, end_month, months
        )
        queryset = self.apply_federal_cs_ind_filter(queryset, request)

        paginator = self.pagination_class()
        paginator.default_limit = 25
        page = paginator.paginate_queryset(queryset, request)

        serializer = SalesComparisonByMaterialSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


FTS_MATERIAL_EXPOSURE_ALLOWED_ORDERINGS = {
    'product_ndc', '-product_ndc',
    'service_level_pct', '-service_level_pct',
    'net_sales', '-net_sales',
    'full_supply_qty', '-full_supply_qty',
    'omits_qty', '-omits_qty',
    'outbound_fill_rate', '-outbound_fill_rate',
    'fts_exposure', '-fts_exposure',
}

FTS_MATERIAL_EXPOSURE_OPENAPI_PARAMETERS = [
    OpenApiParameter(
        name='selected_month',
        type=OpenApiTypes.STR,
        required=False,
        description='Selected month (YYYY-MM). Defaults to latest available month.',
    ),
    OpenApiParameter(
        name='lookback_months',
        type=OpenApiTypes.INT,
        required=False,
        description='Number of prior months in monthly_data and CSV spread (default: 6).',
    ),
    OpenApiParameter(
        name='ordering',
        type=OpenApiTypes.STR,
        required=False,
        enum=sorted(FTS_MATERIAL_EXPOSURE_ALLOWED_ORDERINGS),
        description='Sort field (prefix with - for descending). Default: under-95 SL first, then exposure desc.',
    ),
    OpenApiParameter(
        name='sales_group',
        type=OpenApiTypes.STR,
        required=False,
        enum=list(FTS_SALES_GROUPS),
        description='Formulary sales group (PRxO or PGEN). Defaults to PRxO.',
    ),
]

FTS_MATERIAL_EXPOSURE_FILENAME_PREFIX = 'material_fts_quantity_exposure'


def parse_fts_material_exposure_params(request):
    selected_month_raw = request.query_params.get('selected_month')
    selected_month = None
    if selected_month_raw:
        try:
            year_str, month_str = selected_month_raw.split('-', 1)
            selected_month = date(int(year_str), int(month_str), 1)
        except (ValueError, TypeError):
            raise ValidationError({'detail': 'Invalid selected_month. Expected YYYY-MM.'})

    lookback_raw = request.query_params.get('lookback_months', '6')
    try:
        lookback_months = int(lookback_raw)
        if lookback_months < 1:
            raise ValueError
    except (ValueError, TypeError):
        raise ValidationError({'detail': 'Invalid lookback_months. Expected a positive integer.'})

    ordering_param = request.query_params.get('ordering')
    if ordering_param is not None and ordering_param not in FTS_MATERIAL_EXPOSURE_ALLOWED_ORDERINGS:
        raise ValidationError({
            'detail': f'Invalid ordering. Allowed: {", ".join(sorted(FTS_MATERIAL_EXPOSURE_ALLOWED_ORDERINGS))}.'
        })

    sales_group = request.query_params.get('sales_group')
    if sales_group is not None and sales_group not in FTS_SALES_GROUPS:
        raise ValidationError({
            'detail': f'Invalid sales_group. Allowed: {", ".join(FTS_SALES_GROUPS)}.'
        })

    corp_chain_nbr = extract_corp_chain_param(request)
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
    return {
        'selected_month': selected_month,
        'lookback_months': lookback_months,
        'ordering_param': ordering_param,
        'sales_group': sales_group,
        'direct_mat_nbr': direct_mat_nbr,
        'mat_nbr_subquery': mat_nbr_subquery,
        'corp_chain_nbr': corp_chain_nbr,
    }


def apply_fts_material_exposure_ordering(results, ordering_param):
    if not ordering_param:
        return results
    reverse = ordering_param.startswith('-')
    field = ordering_param[1:] if reverse else ordering_param
    return sorted(
        results,
        key=lambda r: (r.get(field) is None, r.get(field)),
        reverse=reverse,
    )


def get_fts_material_exposure_results(request):
    params = parse_fts_material_exposure_params(request)
    results = OrderTransactionAggregatedService.get_fts_material_exposure(
        selected_month=params['selected_month'],
        lookback_months=params['lookback_months'],
        direct_mat_nbr=params['direct_mat_nbr'],
        mat_nbr_subquery=params['mat_nbr_subquery'],
        corp_chain_nbr=params['corp_chain_nbr'],
        sales_group=params['sales_group'],
    )
    return apply_fts_material_exposure_ordering(results, params['ordering_param']), params


def resolve_fts_material_exposure_selected_month(results, params):
    if results:
        year_str, month_str = results[0]['selected_month'].split('-', 1)
        return date(int(year_str), int(month_str), 1)
    if params['selected_month']:
        return OrderTransactionAggregatedService._month_start(
            params['selected_month'].year,
            params['selected_month'].month,
        )
    today = date.today()
    return date(today.year, today.month, 1)


@extend_schema_view(get=extend_schema(parameters=_YTD_PARAMS))
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class SalesYtdByMaterialView(FederalCsIndFilterMixin, generics.ListAPIView):
    """
    Returns paginated year-to-date sales comparison grouped by material: months 1..through_month
    of `year` against the same months of the prior year. Each row carries the material's name, NDC
    and federal controlled-substance indicator, the current and previous YtD sales and quantities,
    their year-over-year percent change, and a per-sales-group breakdown of the same metrics.

    Query params:
      - year          (int, default: current year)
      - through_month (int 1–12, default: current month)
      - ordering      (default -current_ytd_sales)
      - limit         (int, default: 25, max: 50)
      - offset        (int, default: 0)
    Supports global material filters. The `*_yoy_pct` fields are computed after pagination and
    are not orderable.
    """
    serializer_class = SalesYtdByMaterialSerializer
    pagination_class = Limit25OffsetPagination
    filter_backends = [OrderingFilter]
    ordering_fields = _YTD_METRIC_ORDERING_FIELDS + ['material_id']
    ordering = ['-current_ytd_sales']

    def get_queryset(self):
        year, through_month = _parse_ytd_params(self.request)
        logger.info(
            "SalesYtdByMaterialView: year=%s through_month=%s",
            year, through_month
        )
        queryset = OrderTransactionAggregatedService.get_sales_ytd_by_material(
            year, through_month, mat_nbrs=_get_material_ids_from_global_filters(self.request)
        )
        return self.apply_federal_cs_ind_filter(queryset, self.request)

    def list(self, request, *args, **kwargs):
        year, through_month = _parse_ytd_params(request)
        page = self.paginate_queryset(self.filter_queryset(self.get_queryset()))
        rows = _attach_sales_group_breakdown(page, year, through_month, 'material_id')
        return self.get_paginated_response(self.get_serializer(rows, many=True).data)


class SalesYtdByMaterialExportView(FederalCsIndFilterMixin, CsvExportView):
    """
    Stream YtD-by-material rows as CSV for all rows matching the list endpoint filters.
    Reuses the list queryset, ordering, and YoY computation; ignores limit/offset.
    """

    filename_prefix = "sales_ytd_by_material"
    ordering_fields = _YTD_METRIC_ORDERING_FIELDS + ['material_id']
    default_ordering = ['-current_ytd_sales']

    @extend_schema(
        operation_id="api_order_transaction_aggregated_sales_ytd_by_material_export",
        parameters=_YTD_PARAMS,
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_base_queryset(self, request):
        year, through_month = _parse_ytd_params(request)
        logger.info(
            "SalesYtdByMaterialExportView: year=%s through_month=%s",
            year, through_month,
        )
        queryset = OrderTransactionAggregatedService.get_sales_ytd_by_material(
            year, through_month, mat_nbrs=_get_material_ids_from_global_filters(request)
        )
        return self.apply_federal_cs_ind_filter(queryset, request)

    def get_filtered_queryset(self, request):
        return apply_ordering(
            self.get_base_queryset(request),
            request,
            self.ordering_fields,
            self.default_ordering,
        )

    def iter_csv_rows(self, queryset):
        return OrderTransactionAggregatedService.iter_sales_ytd_by_material_csv_rows(queryset)


class SalesYtdByCustomerExportView(FederalCsIndFilterMixin, CsvExportView):
    """
    Stream YtD-by-customer rows as CSV for all rows matching the list endpoint filters.
    Reuses the list queryset and ordering; ignores limit/offset.
    """

    filename_prefix = "sales_ytd_by_customer"
    ordering_fields = _YTD_METRIC_ORDERING_FIELDS + ['cust_corp_chain_nbr_id']
    default_ordering = ['-current_ytd_sales']

    @extend_schema(
        operation_id="api_order_transaction_aggregated_sales_ytd_by_customer_export",
        parameters=_YTD_PARAMS,
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_base_queryset(self, request):
        year, through_month = _parse_ytd_params(request)
        logger.info(
            "SalesYtdByCustomerExportView: year=%s through_month=%s",
            year, through_month,
        )
        queryset = OrderTransactionAggregatedService.get_sales_ytd_by_customer(year, through_month)
        return self.apply_federal_cs_ind_filter(queryset, request)

    def get_filtered_queryset(self, request):
        return apply_ordering(
            self.get_base_queryset(request),
            request,
            self.ordering_fields,
            self.default_ordering,
        )

    def iter_csv_rows(self, queryset):
        return OrderTransactionAggregatedService.iter_sales_ytd_by_customer_csv_rows(queryset)


class SalesYtdBySalesGroupExportView(FederalCsIndFilterMixin, CsvExportView):
    """
    Stream YtD-by-sales-group rows as CSV for all rows matching the list endpoint filters.
    Reuses the list queryset and ordering; ignores limit/offset.
    """

    filename_prefix = "sales_ytd_by_sales_group"
    ordering_fields = _YTD_METRIC_ORDERING_FIELDS + ['sales_group']
    default_ordering = ['-current_ytd_sales']

    @extend_schema(
        operation_id="api_order_transaction_aggregated_sales_ytd_by_sales_group_export",
        parameters=_YTD_PARAMS,
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_base_queryset(self, request):
        year, through_month = _parse_ytd_params(request)
        logger.info(
            "SalesYtdBySalesGroupExportView: year=%s through_month=%s",
            year, through_month,
        )
        queryset = OrderTransactionAggregatedService.get_sales_ytd_by_sales_group(year, through_month)
        return self.apply_federal_cs_ind_filter(queryset, request)

    def get_filtered_queryset(self, request):
        return apply_ordering(
            self.get_base_queryset(request),
            request,
            self.ordering_fields,
            self.default_ordering,
        )

    def iter_csv_rows(self, queryset):
        return OrderTransactionAggregatedService.iter_sales_ytd_by_sales_group_csv_rows(queryset)


_SALES_COMPARISON_ORDERING_FIELDS = [
    'current_period_sales',
    'previous_period_sales',
    'current_period_order_qty',
    'previous_period_order_qty',
    'current_period_shipped_qty',
    'previous_period_shipped_qty',
]


class SalesComparisonByMaterialExportView(FederalCsIndFilterMixin, CsvExportView):
    """Stream sales-comparison-by-material rows as CSV; ignores limit/offset."""

    filename_prefix = "sales_comparison_by_material"
    ordering_fields = _SALES_COMPARISON_ORDERING_FIELDS + ['material_id']
    default_ordering = ['-current_period_sales']

    @extend_schema(
        operation_id="api_order_transaction_aggregated_sales_comparison_by_material_export",
        parameters=_PERIOD_PARAMS,
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_base_queryset(self, request):
        end_year, end_month, months = _parse_period_params(request)
        queryset = OrderTransactionAggregatedService.get_sales_comparison_by_material(
            end_year, end_month, months
        )
        return self.apply_federal_cs_ind_filter(queryset, request)

    def get_filtered_queryset(self, request):
        return apply_ordering(
            self.get_base_queryset(request),
            request,
            self.ordering_fields,
            self.default_ordering,
        )

    def iter_csv_rows(self, queryset):
        return OrderTransactionAggregatedService.iter_sales_comparison_by_material_csv_rows(queryset)


class SalesComparisonByCustomerExportView(FederalCsIndFilterMixin, CsvExportView):
    """Stream sales-comparison-by-customer rows as CSV; ignores limit/offset."""

    filename_prefix = "sales_comparison_by_customer"
    ordering_fields = _SALES_COMPARISON_ORDERING_FIELDS + ['cust_corp_chain_nbr_id']
    default_ordering = ['-current_period_sales']

    @extend_schema(
        operation_id="api_order_transaction_aggregated_sales_comparison_by_customer_export",
        parameters=_PERIOD_PARAMS,
        responses={(200, "text/csv"): OpenApiTypes.BINARY},
    )
    def get(self, request):
        return super().get(request)

    def get_base_queryset(self, request):
        end_year, end_month, months = _parse_period_params(request)
        queryset = OrderTransactionAggregatedService.get_sales_comparison_by_customer(
            end_year, end_month, months
        )
        return self.apply_federal_cs_ind_filter(queryset, request)

    def get_filtered_queryset(self, request):
        return apply_ordering(
            self.get_base_queryset(request),
            request,
            self.ordering_fields,
            self.default_ordering,
        )

    def iter_csv_rows(self, queryset):
        return OrderTransactionAggregatedService.iter_sales_comparison_by_customer_csv_rows(queryset)


@extend_schema_view(get=extend_schema(parameters=_YTD_PARAMS))
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class SalesYtdByCustomerView(FederalCsIndFilterMixin, generics.ListAPIView):
    """
    Returns paginated year-to-date sales comparison grouped by customer corp chain: months
    1..through_month of `year` against the same months of the prior year, with year-over-year
    percent change and a per-sales-group breakdown of the same metrics.

    Query params:
      - year          (int, default: current year)
      - through_month (int 1–12, default: current month)
      - ordering      (default -current_ytd_sales)
      - limit         (int, default: 25, max: 50)
      - offset        (int, default: 0)
    The `*_yoy_pct` fields are computed after pagination and are not orderable.
    """
    serializer_class = SalesYtdByCustomerSerializer
    pagination_class = Limit25OffsetPagination
    filter_backends = [OrderingFilter]
    ordering_fields = _YTD_METRIC_ORDERING_FIELDS + ['cust_corp_chain_nbr_id']
    ordering = ['-current_ytd_sales']

    def get_queryset(self):
        year, through_month = _parse_ytd_params(self.request)
        logger.info(
            "SalesYtdByCustomerView: year=%s through_month=%s",
            year, through_month
        )
        queryset = OrderTransactionAggregatedService.get_sales_ytd_by_customer(year, through_month)
        return self.apply_federal_cs_ind_filter(queryset, self.request)

    def list(self, request, *args, **kwargs):
        year, through_month = _parse_ytd_params(request)
        page = self.paginate_queryset(self.filter_queryset(self.get_queryset()))
        rows = _attach_sales_group_breakdown(page, year, through_month, 'cust_corp_chain_nbr_id')
        return self.get_paginated_response(self.get_serializer(rows, many=True).data)


@extend_schema_view(get=extend_schema(parameters=_YTD_PARAMS))
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class SalesYtdBySalesGroupView(FederalCsIndFilterMixin, generics.ListAPIView):
    """
    Returns year-to-date sales comparison grouped by sales group: months 1..through_month of
    `year` against the same months of the prior year, with year-over-year percent change.

    Query params:
      - year          (int, default: current year)
      - through_month (int 1–12, default: current month)
      - ordering      (default -current_ytd_sales)
    The `*_yoy_pct` fields are computed in Python and are not orderable.
    """
    serializer_class = SalesYtdBySalesGroupSerializer
    pagination_class = None
    filter_backends = [OrderingFilter]
    ordering_fields = _YTD_METRIC_ORDERING_FIELDS + ['sales_group']
    ordering = ['-current_ytd_sales']

    def get_queryset(self):
        year, through_month = _parse_ytd_params(self.request)
        logger.info(
            "SalesYtdBySalesGroupView: year=%s through_month=%s",
            year, through_month
        )
        queryset = OrderTransactionAggregatedService.get_sales_ytd_by_sales_group(year, through_month)
        return self.apply_federal_cs_ind_filter(queryset, self.request)

    def list(self, request, *args, **kwargs):
        rows = [
            OrderTransactionAggregatedService.attach_ytd_pct_change(row)
            for row in self.filter_queryset(self.get_queryset())
        ]
        return Response(self.get_serializer(rows, many=True).data)


@extend_schema_view(
    get=extend_schema(
        parameters=FTS_MATERIAL_EXPOSURE_OPENAPI_PARAMETERS,
        responses=_PAGINATED_FTS_MATERIAL_EXPOSURE_RESPONSE,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class FtsMaterialExposureView(APIView):
    """
    Returns paginated per-NDC FTS exposure for one formulary from order_transactions_aggregated:
    - service_level_pct, net_sales, full_supply_qty, omits_qty, outbound_fill_rate, fts_exposure
    - monthly_data: selected month + lookback prior months (SL% and net sales)

    Metrics are computed in the service (full-supply ranking) and then paginated in memory.

    Query params:
      - selected_month (YYYY-MM, default: latest available month for filtered materials)
      - lookback_months (int, default: 6)
      - sales_group (PRxO or PGEN, default: PRxO)
      - ordering (optional; default ranks under-95 first, then exposure desc)
    Supports global material filters.
    """
    pagination_class = MaxLimitOffsetPagination

    def get(self, request):
        results, _params = get_fts_material_exposure_results(request)
        paginator = self.pagination_class()
        paginator.default_limit = 25
        page = paginator.paginate_queryset(results, request)
        serializer = FtsMaterialExposureSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


@extend_schema(
    parameters=FTS_MATERIAL_EXPOSURE_OPENAPI_PARAMETERS,
    responses={(200, 'text/csv'): OpenApiTypes.BINARY},
)
class FtsMaterialExposureExportView(APIView):
    """
    Stream Material FTS Quantity Exposure as CSV.

    Query params match the list endpoint; limit and offset are ignored.
    """

    def get(self, request):
        results, params = get_fts_material_exposure_results(request)
        enforce_export_row_cap_count(len(results))
        selected_month = resolve_fts_material_exposure_selected_month(results, params)
        lookback_month_keys = OrderTransactionAggregatedService.get_fts_exposure_lookback_month_keys(
            selected_month,
            params['lookback_months'],
        )
        return streaming_csv_response(
            OrderTransactionAggregatedService.iter_fts_material_exposure_csv_rows(
                results,
                lookback_month_keys,
            ),
            FTS_MATERIAL_EXPOSURE_FILENAME_PREFIX,
        )
