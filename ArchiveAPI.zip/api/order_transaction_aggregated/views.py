import logging
from datetime import date

from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiParameter, extend_schema, extend_schema_view, inline_serializer
from rest_framework import serializers
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView

from api.global_filters import extract_corp_chain_param, get_filtered_material_subquery
from api.pagination import MaxLimitOffsetPagination
from .serializers import (
    FtsMaterialExposureSerializer,
    OrderTransactionAggregatedSerializer,
    SalesComparisonByCustomerSerializer,
    SalesComparisonByMaterialSerializer,
    SalesComparisonBySalesGroupSerializer,
    SalesComparisonByStateSerializer,
    SalesComparisonSerializer,
    SalesTimelineSerializer,
    SalesYtdSerializer,
)
from .filters import FederalCsIndFilterMixin
from .services import OrderTransactionAggregatedService

logger = logging.getLogger(__name__)

_PERIOD_PARAMS = [
    OpenApiParameter(name='end_year', type=OpenApiTypes.INT, required=False),
    OpenApiParameter(name='end_month', type=OpenApiTypes.INT, required=False),
    OpenApiParameter(name='months', type=OpenApiTypes.INT, required=False),
]

_PAGINATED_SALES_COMPARISON_BY_CUSTOMER_RESPONSE = inline_serializer(
    'PaginatedSalesComparisonByCustomerResponse',
    fields={
        'count': serializers.IntegerField(),
        'next': serializers.URLField(allow_null=True, required=False),
        'previous': serializers.URLField(allow_null=True, required=False),
        'results': SalesComparisonByCustomerSerializer(many=True),
    },
)

_PAGINATED_SALES_COMPARISON_BY_MATERIAL_RESPONSE = inline_serializer(
    'PaginatedSalesComparisonByMaterialResponse',
    fields={
        'count': serializers.IntegerField(),
        'next': serializers.URLField(allow_null=True, required=False),
        'previous': serializers.URLField(allow_null=True, required=False),
        'results': SalesComparisonByMaterialSerializer(many=True),
    },
)


def _get_material_ids_from_global_filters(request):
    """
    Extracts material IDs from global filter query params.
    Returns a list of mat_nbr values, or None if no global filters are active.
    """
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)

    if direct_mat_nbr and mat_nbr_subquery is None:
        return [direct_mat_nbr]
    if mat_nbr_subquery is not None:
        ids = list(mat_nbr_subquery)
        if direct_mat_nbr:
            ids = [mid for mid in ids if mid == direct_mat_nbr]
        return ids
    return None


def _parse_period_params(request):
    """
    Extracts and validates end_year, end_month, and months from query params.
    Defaults: end = current month, months = 6.
    """
    today = date.today()
    try:
        end_year = int(request.query_params.get('end_year', today.year))
        end_month = int(request.query_params.get('end_month', today.month))
        months = int(request.query_params.get('months', 6))
    except (TypeError, ValueError):
        end_year = today.year
        end_month = today.month
        months = 6

    months = max(1, min(months, 24))
    return end_year, end_month, months


@extend_schema_view(
    get=extend_schema(responses=OrderTransactionAggregatedSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OrderTransactionAggregatedListView(APIView):
    """
    API view to retrieve aggregated order transaction data for the current year and the previous year.
    Supports global material filters via query params.
    """
    service = OrderTransactionAggregatedService()

    def get(self, request, *args, **kwargs):
        material_ids = _get_material_ids_from_global_filters(request)
        aggregated_data = self.service.get_aggregated_data_for_current_and_previous_year(
            material_ids=material_ids
        )
        data_list = list(aggregated_data)
        for item in data_list:
            item.setdefault('total_order_qty', 0)
            item.setdefault('total_shipped_qty', 0)
        return Response(data_list)


@extend_schema_view(
    get=extend_schema(responses=SalesComparisonSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonByMonthView(APIView):
    """
    API view to retrieve sales comparison data by month for the current and previous year.
    Supports global material filters via query params.
    """
    service = OrderTransactionAggregatedService()

    def get(self, request, *args, **kwargs):
        material_ids = _get_material_ids_from_global_filters(request)
        comparison_data = self.service.get_sales_comparison_by_month(
            material_ids=material_ids
        )
        serializer = SalesComparisonSerializer(comparison_data, many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(responses=SalesTimelineSerializer(many=True)),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesTimelineView(FederalCsIndFilterMixin, APIView):
    """
    Returns 25 months of monthly aggregated totals (2x12 + 1 lead-in month),
    ending at the current month. Used for the timeline chart with month-over-month change.
    No query params — the window is always fixed.
    """

    def get(self, request, *args, **kwargs):
        data = OrderTransactionAggregatedService.get_sales_timeline()
        data = self.apply_federal_cs_ind_filter(data, request)
        serializer = SalesTimelineSerializer(list(data), many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=SalesYtdSerializer,
        description=(
            "Sales YTD KPI: current vs previous year-to-date totals "
            "(order qty, shipped qty, sales amount), percent change on each field, "
            "and a monthly trend for the current year through the current month. "
            "Supports global material filters."
        ),
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesYtdView(APIView):
    """
    Returns year-to-date sales KPI with YoY comparison and monthly trend.
    Supports global material filters via query params.
    """

    def get(self, request, *args, **kwargs):
        material_ids = _get_material_ids_from_global_filters(request)
        data = OrderTransactionAggregatedService.get_sales_ytd(material_ids=material_ids)
        serializer = SalesYtdSerializer(data)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=SalesComparisonBySalesGroupSerializer(many=True),
        parameters=_PERIOD_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonBySalesGroupView(FederalCsIndFilterMixin, APIView):
    """
    Returns sales comparison (current period vs previous period) grouped by sales_group.

    Query params:
      - end_year  (int, default: current year)
      - end_month (int, default: current month)
      - months    (int 1–24, default: 6)
    """

    def get(self, request, *args, **kwargs):
        end_year, end_month, months = _parse_period_params(request)
        logger.info(
            "SalesComparisonBySalesGroupView: end=%s-%s months=%s",
            end_year, end_month, months
        )
        data = OrderTransactionAggregatedService.get_sales_comparison_by_sales_group(
            end_year, end_month, months
        )
        data = self.apply_federal_cs_ind_filter(data, request)
        serializer = SalesComparisonBySalesGroupSerializer(list(data), many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=SalesComparisonByStateSerializer(many=True),
        parameters=_PERIOD_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonByStateView(FederalCsIndFilterMixin, APIView):
    """
    Returns sales comparison (current period vs previous period) grouped by state.

    Query params:
      - end_year  (int, default: current year)
      - end_month (int, default: current month)
      - months    (int 1–24, default: 6)
    """

    def get(self, request, *args, **kwargs):
        end_year, end_month, months = _parse_period_params(request)
        logger.info(
            "SalesComparisonByStateView: end=%s-%s months=%s",
            end_year, end_month, months
        )
        data = OrderTransactionAggregatedService.get_sales_comparison_by_state(
            end_year, end_month, months
        )
        data = self.apply_federal_cs_ind_filter(data, request)
        serializer = SalesComparisonByStateSerializer(list(data), many=True)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=_PAGINATED_SALES_COMPARISON_BY_CUSTOMER_RESPONSE,
        parameters=_PERIOD_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonByCustomerView(FederalCsIndFilterMixin, APIView):
    """
    Returns paginated sales comparison (current period vs previous period) grouped by customer
    corp chain, ordered by current_period_sales descending.

    Query params:
      - end_year  (int, default: current year)
      - end_month (int, default: current month)
      - months    (int 1–24, default: 6)
      - limit     (int, default: 25, max: 50)
      - offset    (int, default: 0)
    """
    pagination_class = MaxLimitOffsetPagination

    def get(self, request, *args, **kwargs):
        end_year, end_month, months = _parse_period_params(request)
        logger.info(
            "SalesComparisonByCustomerView: end=%s-%s months=%s",
            end_year, end_month, months
        )
        queryset = OrderTransactionAggregatedService.get_sales_comparison_by_customer(
            end_year, end_month, months
        )
        queryset = self.apply_federal_cs_ind_filter(queryset, request)

        paginator = self.pagination_class()
        paginator.default_limit = 25
        page = paginator.paginate_queryset(queryset, request)

        serializer = SalesComparisonByCustomerSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        responses=_PAGINATED_SALES_COMPARISON_BY_MATERIAL_RESPONSE,
        parameters=_PERIOD_PARAMS,
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class SalesComparisonByMaterialView(FederalCsIndFilterMixin, APIView):
    """
    Returns paginated sales comparison (current period vs previous period) grouped by material,
    ordered by current_period_sales descending.

    Query params:
      - end_year  (int, default: current year)
      - end_month (int, default: current month)
      - months    (int 1–24, default: 6)
      - limit     (int, default: 25, max: 50)
      - offset    (int, default: 0)
    """
    pagination_class = MaxLimitOffsetPagination

    def get(self, request, *args, **kwargs):
        end_year, end_month, months = _parse_period_params(request)
        logger.info(
            "SalesComparisonByMaterialView: end=%s-%s months=%s",
            end_year, end_month, months
        )
        queryset = OrderTransactionAggregatedService.get_sales_comparison_by_material(
            end_year, end_month, months
        )
        queryset = self.apply_federal_cs_ind_filter(queryset, request)

        paginator = self.pagination_class()
        paginator.default_limit = 25
        page = paginator.paginate_queryset(queryset, request)

        serializer = SalesComparisonByMaterialSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class FtsMaterialExposureView(APIView):
    """
    Returns paginated per-NDC FTS exposure for PRxO from order_transactions_aggregated:
    - service_level_pct, net_sales, full_supply_qty, fts_exposure

    Metrics are computed in the service (full-supply ranking) and then paginated in memory.

    Query params:
      - selected_month (YYYY-MM, default: latest available month for filtered materials)
      - lookback_months (int, default: 6)
      - ordering (optional; default ranks under-95 first, then exposure desc)
    Supports global material filters.
    """
    pagination_class = MaxLimitOffsetPagination

    ALLOWED_ORDERINGS = {
        'product_ndc', '-product_ndc',
        'service_level_pct', '-service_level_pct',
        'net_sales', '-net_sales',
        'full_supply_qty', '-full_supply_qty',
        'fts_exposure', '-fts_exposure',
    }

    def get(self, request):
        selected_month_raw = request.query_params.get('selected_month')
        selected_month = None
        if selected_month_raw:
            try:
                year_str, month_str = selected_month_raw.split('-', 1)
                selected_month = date(int(year_str), int(month_str), 1)
            except (ValueError, TypeError):
                raise ValidationError({'detail': 'Invalid selected_month. Expected YYYY-MM.'})

        lookback_raw = request.query_params.get('lookback_months', '6')
        try:
            lookback_months = int(lookback_raw)
            if lookback_months < 1:
                raise ValueError
        except (ValueError, TypeError):
            raise ValidationError({'detail': 'Invalid lookback_months. Expected a positive integer.'})

        ordering_param = request.query_params.get('ordering')
        if ordering_param is not None and ordering_param not in self.ALLOWED_ORDERINGS:
            raise ValidationError({
                'detail': f'Invalid ordering. Allowed: {", ".join(sorted(self.ALLOWED_ORDERINGS))}.'
            })

        corp_chain_nbr = extract_corp_chain_param(request)
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request, skip_corp_chain=True)
        results = OrderTransactionAggregatedService.get_fts_material_exposure(
            selected_month=selected_month,
            lookback_months=lookback_months,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            corp_chain_nbr=corp_chain_nbr,
        )

        if ordering_param:
            reverse = ordering_param.startswith('-')
            field = ordering_param[1:] if reverse else ordering_param
            results = sorted(
                results,
                key=lambda r: (r.get(field) is None, r.get(field)),
                reverse=reverse,
            )

        paginator = self.pagination_class()
        paginator.default_limit = 25
        page = paginator.paginate_queryset(results, request)
        serializer = FtsMaterialExposureSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)
