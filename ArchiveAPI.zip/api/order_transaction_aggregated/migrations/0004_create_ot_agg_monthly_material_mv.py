from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('order_transaction_aggregated', '0003_alter_ordertransactionaggregated_unique_together_and_more'),
    ]

    operations = [
        migrations.RunSQL(
            sql="""
DROP MATERIALIZED VIEW IF EXISTS ot_agg_monthly_material_mv CASCADE;

CREATE MATERIALIZED VIEW ot_agg_monthly_material_mv AS
SELECT
    year,
    month,
    mat_nbr,
    SUM(total_order_qty)   AS total_order_qty,
    SUM(total_shipped_qty) AS total_shipped_qty,
    SUM(sales_amount)      AS sales_amount
FROM order_transactions_aggregated
GROUP BY year, month, mat_nbr;

CREATE UNIQUE INDEX idx_ot_agg_mm_pk ON ot_agg_monthly_material_mv (year, month, mat_nbr);
CREATE INDEX idx_ot_agg_mm_mat ON ot_agg_monthly_material_mv (mat_nbr);
CREATE INDEX idx_ot_agg_mm_year_month ON ot_agg_monthly_material_mv (year, month);
            """,
            reverse_sql="""
DROP MATERIALIZED VIEW IF EXISTS ot_agg_monthly_material_mv CASCADE;
            """,
        ),
    ]
