import calendar
import logging
from collections import defaultdict
from datetime import date
from decimal import Decimal

from dateutil.relativedelta import relativedelta
from django.db.models import Case, DecimalField, IntegerField, OuterRef, Q, Subquery, Sum, Value, When
from django.db.models.functions import Coalesce

from api.material.models import Material
from api.order_transaction_aggregated.materialized_view_models import OtAggMonthlyMaterialMV
from api.order_transaction_aggregated.models import OrderTransactionAggregated

logger = logging.getLogger(__name__)

PRXO_SALES_GROUP = 'PRxO'
SERVICE_LEVEL_THRESHOLD = 95
FULL_SUPPLY_MONTH_COUNT = 3


class OrderTransactionAggregatedService:
    """Service class for handling aggregated order transaction operations."""

    @staticmethod
    def _get_period_months(end_year, end_month, months):
        """Returns list of (year, month) tuples for a period ending at end_year/end_month."""
        end_date = date(end_year, end_month, 1)
        return [
            ((end_date - relativedelta(months=i)).year, (end_date - relativedelta(months=i)).month)
            for i in range(months)
        ]

    @staticmethod
    def _build_period_q(months_list):
        """Builds a Q object matching any of the given (year, month) pairs."""
        q = Q()
        for year, month in months_list:
            q |= Q(year=year, month=month)
        return q

    @staticmethod
    def _month_start(year, month):
        return date(year, month, 1)

    @staticmethod
    def _round_service_level(filled, ordered):
        if not ordered:
            return None
        filled = filled or 0
        return int(round(filled * 100.0 / ordered, 0))

    @staticmethod
    def _as_int_rounded(value):
        if value is None:
            return 0
        return int(round(Decimal(value), 0))

    @staticmethod
    def _as_int_trunc(value):
        """Match Databricks CAST(x AS INT) truncation toward zero."""
        if value is None:
            return 0
        return int(Decimal(value))

    @staticmethod
    def get_fts_material_exposure(
        selected_month=None,
        lookback_months=6,
        direct_mat_nbr=None,
        mat_nbr_subquery=None,
        corp_chain_nbr=None,
    ):
        """
        Monthly PRxO FTS service level, full supply qty, and exposure by product NDC.

        Ports the approved DE calculation:
          SL% = ROUND(SUM(fts_lines_fully_filled) / SUM(fts_lines_ordered) * 100, 0)
          Net Sales = SUM(sales_less_cred_qty)
          Full Supply = AVG(net_sales) of up to 3 prior months (95% path or top-SL fallback)
          Exposure = max(0, full_supply - net_sales) when selected-month SL < 95, else 0
        """
        logger.info(
            'Getting FTS material exposure selected_month=%s lookback_months=%s',
            selected_month,
            lookback_months,
        )

        qs = OrderTransactionAggregated.objects.filter(sales_group=PRXO_SALES_GROUP)
        if direct_mat_nbr:
            qs = qs.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            qs = qs.filter(material__mat_nbr__in=mat_nbr_subquery)
        if corp_chain_nbr:
            qs = qs.filter(cust_corp_chain_nbr=corp_chain_nbr)

        qs = qs.exclude(material__ndc__isnull=True).exclude(material__ndc='')

        if selected_month is None:
            latest = (
                qs.exclude(year__isnull=True)
                .exclude(month__isnull=True)
                .order_by('-year', '-month')
                .values('year', 'month')
                .first()
            )
            if not latest:
                return []
            selected_month = OrderTransactionAggregatedService._month_start(
                latest['year'], latest['month']
            )
        else:
            selected_month = OrderTransactionAggregatedService._month_start(
                selected_month.year, selected_month.month
            )

        period_months = OrderTransactionAggregatedService._get_period_months(
            selected_month.year, selected_month.month, lookback_months + 1
        )
        period_q = OrderTransactionAggregatedService._build_period_q(period_months)

        ndc_description = (
            Material.objects.filter(ndc=OuterRef('material__ndc'))
            .order_by('mat_nbr')
            .values('name')[:1]
        )

        monthly_rows = (
            qs.filter(period_q)
            .values('material__ndc', 'year', 'month')
            .annotate(
                filled=Coalesce(Sum('fts_lines_fully_filled'), Value(0), output_field=IntegerField()),
                ordered=Coalesce(Sum('fts_lines_ordered'), Value(0), output_field=IntegerField()),
                net_sales_raw=Sum('sales_less_cred_qty'),
                product_description=Subquery(ndc_description),
            )
            .order_by('material__ndc', 'year', 'month')
        )

        monthly_by_ndc = defaultdict(list)
        descriptions = {}
        for row in monthly_rows:
            ndc = row['material__ndc']
            if ndc not in descriptions:
                descriptions[ndc] = row['product_description']

            month_start = OrderTransactionAggregatedService._month_start(row['year'], row['month'])
            if not row['ordered']:
                continue
            service_level_pct = OrderTransactionAggregatedService._round_service_level(
                row['filled'], row['ordered']
            )
            if service_level_pct is None:
                continue
            net_sales = (
                None if row['net_sales_raw'] is None
                else OrderTransactionAggregatedService._as_int_trunc(row['net_sales_raw'])
            )
            monthly_by_ndc[ndc].append({
                'month_start': month_start,
                'service_level_pct': service_level_pct,
                'net_sales': net_sales,
            })

        results = []
        for product_ndc, months in monthly_by_ndc.items():
            selected = next((m for m in months if m['month_start'] == selected_month), None)
            if selected is None:
                continue

            prior = [
                m for m in months
                if m['month_start'] < selected_month and m['net_sales'] is not None
            ]
            if not prior:
                continue

            at_95 = [m for m in prior if m['service_level_pct'] >= SERVICE_LEVEL_THRESHOLD]
            if len(at_95) >= FULL_SUPPLY_MONTH_COUNT:
                chosen = sorted(at_95, key=lambda m: m['month_start'], reverse=True)[
                    :FULL_SUPPLY_MONTH_COUNT
                ]
            else:
                limit = min(FULL_SUPPLY_MONTH_COUNT, len(prior))
                chosen = sorted(
                    prior,
                    key=lambda m: (m['service_level_pct'], m['month_start']),
                    reverse=True,
                )[:limit]

            if not chosen:
                continue

            full_supply_qty = OrderTransactionAggregatedService._as_int_rounded(
                sum(m['net_sales'] for m in chosen) / len(chosen)
            )
            service_level_pct = selected['service_level_pct']
            net_sales = 0 if selected['net_sales'] is None else selected['net_sales']
            if service_level_pct < SERVICE_LEVEL_THRESHOLD:
                fts_exposure = max(0, full_supply_qty - net_sales)
            else:
                fts_exposure = 0

            results.append({
                'product_ndc': product_ndc,
                'product_description': descriptions.get(product_ndc),
                'service_level_pct': service_level_pct,
                'net_sales': net_sales,
                'full_supply_qty': full_supply_qty,
                'fts_exposure': fts_exposure,
            })

        results.sort(
            key=lambda r: (
                0 if r['service_level_pct'] < SERVICE_LEVEL_THRESHOLD else 1,
                -r['fts_exposure'],
                -r['full_supply_qty'],
                r['product_ndc'] or '',
            )
        )
        return results

    @staticmethod
    def _get_comparison_periods(end_year, end_month, months):
        """
        Returns (current_months, previous_months) lists.
        Current period: `months` months ending at end_year/end_month.
        Previous period: the `months` months immediately before that.
        """
        current_months = OrderTransactionAggregatedService._get_period_months(end_year, end_month, months)
        prev_end = date(end_year, end_month, 1) - relativedelta(months=months)
        previous_months = OrderTransactionAggregatedService._get_period_months(prev_end.year, prev_end.month, months)
        return current_months, previous_months

    @staticmethod
    def get_order_transaction_aggregated_by_year_and_month(year, month):
        """
        Retrieve aggregated order transaction data by year and month.
        Sums quantities across all customers for the given year/month.
        Returns a dictionary with aggregated values or None if no data exists.
        """
        logger.info("Retrieving aggregated order transaction for year: %s, month: %s", year, month)

        aggregated = OrderTransactionAggregated.objects.filter(
            year=year, month=month
        ).aggregate(
            total_order_qty=Sum('total_order_qty'),
            total_shipped_qty=Sum('total_shipped_qty')
        )

        if aggregated['total_order_qty'] is None and aggregated['total_shipped_qty'] is None:
            logger.info("No aggregated data found for %s-%s", year, month)
            return None

        result = {
            'year': year,
            'month': month,
            'total_order_qty': aggregated['total_order_qty'] or 0,
            'total_shipped_qty': aggregated['total_shipped_qty'] or 0
        }

        logger.info("Successfully retrieved aggregated data for %s-%s", year, month)
        return result

    @staticmethod
    def get_aggregated_data_for_current_and_previous_year(material_ids=None):
        """
        Returns aggregated order transaction data for the current year and the previous year.
        Queries the ot_agg_monthly_material_mv materialized view for performance.
        Optionally filters by material_ids for global filter support.
        """
        today = date.today()
        current_year = today.year
        last_year = current_year - 1

        logger.info("Retrieving aggregated data for years: %s and %s", current_year, last_year)

        queryset = OtAggMonthlyMaterialMV.objects.filter(
            Q(year=current_year) | Q(year=last_year)
        )

        if material_ids is not None:
            queryset = queryset.filter(material__in=material_ids)

        queryset = queryset.values('year', 'month').annotate(
            total_order_qty=Sum('total_order_qty'),
            total_shipped_qty=Sum('total_shipped_qty')
        ).order_by('year', 'month')

        count = queryset.count()
        logger.info("Retrieved %s aggregated records for current and previous year", count)
        return queryset

    @staticmethod
    def get_sales_comparison_by_month(material_ids=None):
        """
        Compares total sales for each month of the current year against the same month in the previous year.
        Queries the ot_agg_monthly_material_mv materialized view for performance.
        Optionally filters by material_ids for global filter support.
        """
        today = date.today()
        current_year = today.year
        last_year = current_year - 1

        logger.info("Calculating sales comparison for year %s vs %s", current_year, last_year)

        queryset = OtAggMonthlyMaterialMV.objects.filter(
            year__in=[current_year, last_year]
        )

        if material_ids is not None:
            queryset = queryset.filter(material__in=material_ids)

        aggregated_data = queryset.values('year', 'month').annotate(
            total_shipped_qty=Sum('total_shipped_qty')
        )

        comparison_data = {
            month: {'last_year_sales': 0, 'current_year_sales': 0}
            for month in range(1, 13)
        }

        for item in aggregated_data:
            month = item['month']
            total_shipped = item['total_shipped_qty'] or 0
            if item['year'] == current_year:
                comparison_data[month]['current_year_sales'] = total_shipped
            elif item['year'] == last_year:
                comparison_data[month]['last_year_sales'] = total_shipped

        results = [
            {
                'month': calendar.month_name[month_num],
                'month_num': month_num,
                'last_year_sales': sales['last_year_sales'],
                'current_year_sales': sales['current_year_sales'],
            }
            for month_num, sales in comparison_data.items()
        ]

        logger.info("Completed sales comparison for %s months", len(results))
        return results

    @staticmethod
    def get_sales_comparison_by_sales_group(end_year, end_month, months):
        """
        Returns sales_amount comparison (current vs previous period) grouped by sales_group.
        """
        current_months, previous_months = OrderTransactionAggregatedService._get_comparison_periods(
            end_year, end_month, months
        )
        current_q = OrderTransactionAggregatedService._build_period_q(current_months)
        previous_q = OrderTransactionAggregatedService._build_period_q(previous_months)

        logger.info(
            "Sales comparison by sales_group: current period ends %s-%s, %s months",
            end_year, end_month, months
        )

        return (
            OrderTransactionAggregated.objects
            .filter(current_q | previous_q)
            .values('sales_group')
            .annotate(
                current_period_sales=Sum(
                    Case(When(current_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_sales=Sum(
                    Case(When(previous_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
                ),
                current_period_order_qty=Sum(
                    Case(When(current_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_order_qty=Sum(
                    Case(When(previous_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
                ),
                current_period_shipped_qty=Sum(
                    Case(When(current_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_shipped_qty=Sum(
                    Case(When(previous_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
                ),
            )
            .order_by('sales_group')
        )

    @staticmethod
    def get_sales_comparison_by_state(end_year, end_month, months):
        """
        Returns sales_amount comparison (current vs previous period) grouped by state.
        """
        current_months, previous_months = OrderTransactionAggregatedService._get_comparison_periods(
            end_year, end_month, months
        )
        current_q = OrderTransactionAggregatedService._build_period_q(current_months)
        previous_q = OrderTransactionAggregatedService._build_period_q(previous_months)

        logger.info(
            "Sales comparison by state: current period ends %s-%s, %s months",
            end_year, end_month, months
        )

        return (
            OrderTransactionAggregated.objects
            .filter(current_q | previous_q)
            .values('state')
            .annotate(
                current_period_sales=Sum(
                    Case(When(current_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_sales=Sum(
                    Case(When(previous_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
                ),
                current_period_order_qty=Sum(
                    Case(When(current_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_order_qty=Sum(
                    Case(When(previous_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
                ),
                current_period_shipped_qty=Sum(
                    Case(When(current_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_shipped_qty=Sum(
                    Case(When(previous_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
                ),
            )
            .order_by('state')
        )

    @staticmethod
    def get_sales_comparison_by_material(end_year, end_month, months):
        """
        Returns sales_amount comparison (current vs previous period) grouped by material.
        Returns a queryset suitable for pagination.
        """
        current_months, previous_months = OrderTransactionAggregatedService._get_comparison_periods(
            end_year, end_month, months
        )
        current_q = OrderTransactionAggregatedService._build_period_q(current_months)
        previous_q = OrderTransactionAggregatedService._build_period_q(previous_months)

        logger.info(
            "Sales comparison by material: current period ends %s-%s, %s months",
            end_year, end_month, months
        )

        return (
            OrderTransactionAggregated.objects
            .filter(current_q | previous_q)
            .values('material_id', 'material__name')
            .annotate(
                current_period_sales=Sum(
                    Case(When(current_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_sales=Sum(
                    Case(When(previous_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
                ),
                current_period_order_qty=Sum(
                    Case(When(current_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_order_qty=Sum(
                    Case(When(previous_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
                ),
                current_period_shipped_qty=Sum(
                    Case(When(current_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_shipped_qty=Sum(
                    Case(When(previous_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
                ),
            )
            .order_by('-current_period_sales')
        )

    @staticmethod
    def get_sales_comparison_by_customer(end_year, end_month, months):
        """
        Returns sales comparison (current vs previous period) grouped by customer corp chain.
        Returns a queryset suitable for pagination.
        """
        current_months, previous_months = OrderTransactionAggregatedService._get_comparison_periods(
            end_year, end_month, months
        )
        current_q = OrderTransactionAggregatedService._build_period_q(current_months)
        previous_q = OrderTransactionAggregatedService._build_period_q(previous_months)

        logger.info(
            "Sales comparison by customer: current period ends %s-%s, %s months",
            end_year, end_month, months
        )

        return (
            OrderTransactionAggregated.objects
            .filter(current_q | previous_q)
            .values('cust_corp_chain_nbr_id', 'cust_corp_chain_nbr__name')
            .annotate(
                current_period_sales=Sum(
                    Case(When(current_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_sales=Sum(
                    Case(When(previous_q, then='sales_amount'), default=Value(0), output_field=DecimalField())
                ),
                current_period_order_qty=Sum(
                    Case(When(current_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_order_qty=Sum(
                    Case(When(previous_q, then='total_order_qty'), default=Value(0), output_field=DecimalField())
                ),
                current_period_shipped_qty=Sum(
                    Case(When(current_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
                ),
                previous_period_shipped_qty=Sum(
                    Case(When(previous_q, then='total_shipped_qty'), default=Value(0), output_field=DecimalField())
                ),
            )
            .order_by('-current_period_sales')
        )

    @staticmethod
    def get_sales_timeline():
        """
        Returns monthly aggregated totals for the last 25 months (2x12 + 1 lead-in),
        ordered chronologically. Used for the timeline chart with month-over-month change.
        """
        today = date.today()
        start_date = date(today.year, today.month, 1) - relativedelta(months=24)

        q = Q()
        for i in range(25):
            d = start_date + relativedelta(months=i)
            q |= Q(year=d.year, month=d.month)

        logger.info("Fetching sales timeline from %s-%s to %s-%s", start_date.year, start_date.month, today.year,
                    today.month)

        return (
            OrderTransactionAggregated.objects
            .filter(q)
            .values('year', 'month')
            .annotate(
                sales_amount=Sum('sales_amount'),
                total_order_qty=Sum('total_order_qty'),
                total_shipped_qty=Sum('total_shipped_qty'),
            )
            .order_by('year', 'month')
        )

    @staticmethod
    def _pct_change(current, previous):
        """Return percent change rounded to 2 decimals, or None when previous is zero."""
        if previous == 0:
            return None
        return round((float(current) - float(previous)) / float(previous) * 100, 2)

    @staticmethod
    def get_sales_ytd(material_ids=None):
        """
        Returns year-to-date sales KPI: current vs previous YTD totals, percent change
        on each metric, and a monthly trend for the current year through the current month.
        Queries ot_agg_monthly_material_mv. Optionally filters by material_ids.
        """
        today = date.today()
        current_year = today.year
        previous_year = current_year - 1
        current_month = today.month

        logger.info(
            "Calculating sales YTD for %s months 1-%s vs %s",
            current_year, current_month, previous_year,
        )

        queryset = OtAggMonthlyMaterialMV.objects.filter(
            Q(year=current_year, month__lte=current_month)
            | Q(year=previous_year, month__lte=current_month)
        )

        if material_ids is not None:
            queryset = queryset.filter(material__in=material_ids)

        aggregated = queryset.values('year', 'month').annotate(
            total_order_qty=Sum('total_order_qty'),
            total_shipped_qty=Sum('total_shipped_qty'),
            sales_amount=Sum('sales_amount'),
        )

        empty_totals = {
            'total_order_qty': 0,
            'total_shipped_qty': 0,
            'sales_amount': 0,
        }
        current_ytd = dict(empty_totals)
        previous_ytd = dict(empty_totals)
        by_month = {}

        for row in aggregated:
            order_qty = row['total_order_qty'] or 0
            shipped_qty = row['total_shipped_qty'] or 0
            sales_amount = row['sales_amount'] or 0
            bucket = current_ytd if row['year'] == current_year else previous_ytd
            bucket['total_order_qty'] += order_qty
            bucket['total_shipped_qty'] += shipped_qty
            bucket['sales_amount'] += sales_amount
            if row['year'] == current_year:
                by_month[row['month']] = {
                    'year': current_year,
                    'month': row['month'],
                    'total_order_qty': order_qty,
                    'total_shipped_qty': shipped_qty,
                    'sales_amount': sales_amount,
                }

        trend = [
            by_month.get(month, {
                'year': current_year,
                'month': month,
                'total_order_qty': 0,
                'total_shipped_qty': 0,
                'sales_amount': 0,
            })
            for month in range(1, current_month + 1)
        ]

        pct_change = {
            'total_order_qty': OrderTransactionAggregatedService._pct_change(
                current_ytd['total_order_qty'], previous_ytd['total_order_qty']
            ),
            'total_shipped_qty': OrderTransactionAggregatedService._pct_change(
                current_ytd['total_shipped_qty'], previous_ytd['total_shipped_qty']
            ),
            'sales_amount': OrderTransactionAggregatedService._pct_change(
                current_ytd['sales_amount'], previous_ytd['sales_amount']
            ),
        }

        return {
            'current_ytd': current_ytd,
            'previous_ytd': previous_ytd,
            'pct_change': pct_change,
            'trend': trend,
        }
