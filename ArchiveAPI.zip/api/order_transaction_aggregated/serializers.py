from rest_framework import serializers

from api.order_transaction_aggregated.models import OrderTransactionAggregated


class OrderTransactionAggregatedSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderTransactionAggregated
        fields = '__all__'


class SalesComparisonSerializer(serializers.Serializer):
    """
    Serializer for sales comparison data.
    """
    month = serializers.CharField(max_length=9)
    month_num = serializers.IntegerField()
    last_year_sales = serializers.IntegerField()
    current_year_sales = serializers.IntegerField()


class SalesComparisonBySalesGroupSerializer(serializers.Serializer):
    sales_group = serializers.CharField(allow_null=True)
    current_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)


class SalesComparisonByStateSerializer(serializers.Serializer):
    state = serializers.CharField(allow_null=True)
    current_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)


class SalesTimelineSerializer(serializers.Serializer):
    year = serializers.IntegerField()
    month = serializers.IntegerField()
    sales_amount = serializers.DecimalField(max_digits=20, decimal_places=2, allow_null=True)
    total_order_qty = serializers.IntegerField(allow_null=True)
    total_shipped_qty = serializers.IntegerField(allow_null=True)


class SalesComparisonByCustomerSerializer(serializers.Serializer):
    cust_corp_chain_nbr = serializers.CharField(source='cust_corp_chain_nbr_id')
    customer_name = serializers.CharField(source='cust_corp_chain_nbr__name', allow_null=True)
    current_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)


class SalesComparisonByMaterialSerializer(serializers.Serializer):
    mat_nbr = serializers.CharField(source='material_id')
    material_name = serializers.CharField(source='material__name', allow_null=True)
    current_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_period_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)


class BaseYtdMetricsSerializer(serializers.Serializer):
    """Current/previous YtD totals plus their year-over-year percent change."""
    current_ytd_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_ytd_sales = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_ytd_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_ytd_order_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    current_ytd_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    previous_ytd_shipped_qty = serializers.DecimalField(max_digits=20, decimal_places=2)
    sales_yoy_pct = serializers.FloatField(allow_null=True)
    order_qty_yoy_pct = serializers.FloatField(allow_null=True)
    shipped_qty_yoy_pct = serializers.FloatField(allow_null=True)


class SalesGroupYtdBreakdownSerializer(BaseYtdMetricsSerializer):
    sales_group = serializers.CharField(allow_null=True)


class SalesYtdByMaterialSerializer(BaseYtdMetricsSerializer):
    mat_nbr = serializers.CharField(source='material_id')
    material_name = serializers.CharField(source='material__name', allow_null=True)
    ndc = serializers.CharField(source='material__ndc', allow_null=True)
    federal_cs_ind = serializers.CharField(source='material__federal_cs_ind', allow_null=True)
    sales_group_breakdown = SalesGroupYtdBreakdownSerializer(many=True)


class SalesYtdByCustomerSerializer(BaseYtdMetricsSerializer):
    cust_corp_chain_nbr = serializers.CharField(source='cust_corp_chain_nbr_id')
    customer_name = serializers.CharField(source='cust_corp_chain_nbr__name', allow_null=True)
    sales_group_breakdown = SalesGroupYtdBreakdownSerializer(many=True)


class SalesYtdBySalesGroupSerializer(BaseYtdMetricsSerializer):
    sales_group = serializers.CharField(allow_null=True)


class FtsMonthMetricsSerializer(serializers.Serializer):
    service_level_pct = serializers.IntegerField(allow_null=True)
    net_sales = serializers.IntegerField(allow_null=True)


class FtsMaterialExposureSerializer(serializers.Serializer):
    product_ndc = serializers.CharField()
    product_description = serializers.CharField(allow_null=True)
    service_level_pct = serializers.IntegerField(allow_null=True)
    net_sales = serializers.IntegerField()
    full_supply_qty = serializers.IntegerField()
    omits_qty = serializers.IntegerField()
    outbound_fill_rate = serializers.FloatField(allow_null=True)
    fts_exposure = serializers.IntegerField()
    selected_month = serializers.CharField()
    monthly_data = serializers.DictField(
        child=FtsMonthMetricsSerializer(allow_null=True),
        allow_empty=True,
    )


class SalesYtdTotalsSerializer(serializers.Serializer):
    total_order_qty = serializers.IntegerField()
    total_shipped_qty = serializers.IntegerField()
    sales_amount = serializers.DecimalField(max_digits=20, decimal_places=2)


class SalesYtdPctChangeSerializer(serializers.Serializer):
    total_order_qty = serializers.FloatField(allow_null=True)
    total_shipped_qty = serializers.FloatField(allow_null=True)
    sales_amount = serializers.FloatField(allow_null=True)


class SalesYtdTrendPointSerializer(serializers.Serializer):
    year = serializers.IntegerField()
    month = serializers.IntegerField()
    total_order_qty = serializers.IntegerField()
    total_shipped_qty = serializers.IntegerField()
    sales_amount = serializers.DecimalField(max_digits=20, decimal_places=2)


class SalesYtdSerializer(serializers.Serializer):
    current_ytd = SalesYtdTotalsSerializer()
    previous_ytd = SalesYtdTotalsSerializer()
    pct_change = SalesYtdPctChangeSerializer()
    trend = SalesYtdTrendPointSerializer(many=True)
