from django.db import models

from api.customer_corp_chain.models import CustomerCorpChain
from api.material.models import Material


class OrderTransactionAggregated(models.Model):
    """
    Model to store aggregated order transaction data.
    This model is used to store Order Transaction data aggregated by month for two years.
    """
    year = models.IntegerField(null=True, blank=True)
    month = models.IntegerField(null=True, blank=True)
    total_order_qty = models.IntegerField(default=0, null=True, blank=True)
    total_shipped_qty = models.IntegerField(default=0, null=True, blank=True)
    sales_amount = models.DecimalField(max_digits=20, decimal_places=2, default=0, null=True, blank=True)
    cust_corp_chain_nbr = models.ForeignKey(
        CustomerCorpChain,
        to_field="cust_corp_chain_nbr",
        db_column="cust_corp_chain_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    sales_group = models.CharField(max_length=255, null=True, blank=True)
    state = models.CharField(max_length=255, null=True, blank=True)
    sales_less_cred_qty = models.DecimalField(max_digits=20, decimal_places=3, null=True, blank=True)
    fts_lines_fully_filled = models.IntegerField(null=True, blank=True)
    fts_lines_ordered = models.IntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "order_transactions_aggregated"
        verbose_name = "Order Transaction Aggregated"
        verbose_name_plural = "Order Transactions Aggregated"
        unique_together = ("year", "month", "cust_corp_chain_nbr", "material", "sales_group", "state")
        indexes = [
            models.Index(fields=["year", "month"]),
            models.Index(fields=["material"]),
            models.Index(fields=["sales_group"]),
            models.Index(fields=["state"]),
        ]
