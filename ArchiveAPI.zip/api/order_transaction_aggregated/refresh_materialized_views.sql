-- ============================================================================
-- Refresh Commands (to be run from Databricks)
-- ============================================================================
REFRESH MATERIALIZED VIEW CONCURRENTLY ot_agg_monthly_material_mv;
