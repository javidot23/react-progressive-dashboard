from django.apps import AppConfig


class OrderTransactionAggregatedConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.order_transaction_aggregated'
