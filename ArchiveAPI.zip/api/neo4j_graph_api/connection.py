"""Neo4j connection management layer."""
import logging

from django.conf import settings
from neo4j import GraphDatabase

from .exceptions import Neo4jConnectionError

logger = logging.getLogger(__name__)


class Neo4jConnection:
    """Manages Neo4j database connection and sessions."""

    _driver = None

    @classmethod
    def get_driver(cls):
        """
        Get or create Neo4j driver instance (singleton pattern).

        Returns:
            neo4j.Driver: The Neo4j driver instance

        Raises:
            Neo4jConnectionError: If driver creation fails
        """
        if cls._driver is None:
            try:
                logger.info("Creating Neo4j driver connection")
                cls._driver = GraphDatabase.driver(
                    settings.NEO4J_URI,
                    auth=(settings.NEO4J_USER, settings.NEO4J_PASSWORD)
                )
                cls._driver.verify_connectivity()
                logger.info("Neo4j driver connection established successfully")
            except Exception as e:
                logger.error(f"Failed to create Neo4j driver: {str(e)}")
                raise Neo4jConnectionError(f"Failed to connect to Neo4j: {str(e)}") from e
        return cls._driver

    @classmethod
    def get_session(cls, database=None):
        """
        Get a new session for executing queries.

        Args:
            database (str, optional): Database name. Defaults to settings.NEO4J_DATABASE.

        Returns:
            neo4j.Session: A new session for executing queries

        Raises:
            Neo4jConnectionError: If driver is not available
        """
        try:
            driver = cls.get_driver()
            db = database or settings.NEO4J_DATABASE
            return driver.session(database=db)
        except Exception as e:
            logger.error(f"Failed to create Neo4j session: {str(e)}")
            raise Neo4jConnectionError(f"Failed to create session: {str(e)}") from e

    @classmethod
    def close(cls):
        """Close the driver connection."""
        if cls._driver:
            try:
                logger.info("Closing Neo4j driver connection")
                cls._driver.close()
                cls._driver = None
                logger.info("Neo4j driver connection closed")
            except Exception as e:
                logger.error(f"Error closing Neo4j driver: {str(e)}")

    @classmethod
    def is_connected(cls):
        """
        Check if the driver is connected and healthy.

        Returns:
            bool: True if connected, False otherwise
        """
        if cls._driver is None:
            return False
        try:
            cls._driver.verify_connectivity()
            return True
        except Exception:
            return False
