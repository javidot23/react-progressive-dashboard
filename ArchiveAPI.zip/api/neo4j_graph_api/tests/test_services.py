"""
Tests for Neo4j Graph API service layer.
"""
from unittest.mock import patch, MagicMock

from django.test import TestCase

from api.neo4j_graph_api.services import Neo4jGraphService
from api.neo4j_graph_api.exceptions import Neo4jNodeNotFoundError


class Neo4jGraphServiceTest(TestCase):
    """Test high-level service layer."""

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_plants_with_ids(self, mock_executor):
        """Test getting plants with specific IDs."""
        mock_plant1 = {'id': 'P1', 'name': 'Plant 1', 'properties': {}}
        mock_plant2 = {'id': 'P2', 'name': 'Plant 2', 'properties': {}}

        mock_executor.execute_query.return_value = [
            {'p': mock_plant1},
            {'p': mock_plant2}
        ]

        result = Neo4jGraphService.get_plants(plant_ids=['P1', 'P2'])

        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['id'], 'P1')
        mock_executor.execute_query.assert_called_once()

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_plants_with_filters(self, mock_executor):
        """Test getting plants with additional filters."""
        mock_plant = {'id': 'P1', 'name': 'Plant 1', 'country': 'US', 'properties': {}}

        mock_executor.execute_query.return_value = [
            {'p': mock_plant}
        ]

        result = Neo4jGraphService.get_plants(filters={'country': 'US'})

        self.assertEqual(len(result), 1)
        mock_executor.execute_query.assert_called_once()
        # Verify filter was applied in query
        call_args = mock_executor.execute_query.call_args
        self.assertIn('WHERE', call_args[0][0])

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_supply_chain(self, mock_executor):
        """Test getting material supply chain."""
        mock_path = MagicMock()
        mock_node1 = MagicMock()
        mock_node1.id = 1
        mock_node1.labels = {'Material'}
        mock_node1.items.return_value = []

        mock_node2 = MagicMock()
        mock_node2.id = 2
        mock_node2.labels = {'Plant'}
        mock_node2.items.return_value = []

        mock_rel = MagicMock()
        mock_rel.id = 1
        mock_rel.type = 'SUPPLIES'
        mock_rel.start_node.id = 1
        mock_rel.end_node.id = 2
        mock_rel.items.return_value = []

        mock_path.nodes.return_value = [mock_node1, mock_node2]
        mock_path.relationships.return_value = [mock_rel]

        mock_executor.execute_query.return_value = [
            {
                'path': mock_path,
                'm': mock_node1,
                'related': mock_node2
            }
        ]

        result = Neo4jGraphService.get_material_supply_chain('MAT123', depth=2)

        self.assertEqual(result['material_id'], 'MAT123')
        self.assertIn('nodes', result)
        self.assertIn('relationships', result)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_supply_chain_not_found(self, mock_executor):
        """Test getting supply chain when material not found."""
        mock_executor.execute_query.return_value = []

        result = Neo4jGraphService.get_material_supply_chain('MAT999')

        self.assertEqual(result['material_id'], 'MAT999')
        self.assertEqual(len(result['nodes']), 0)
        self.assertEqual(len(result['relationships']), 0)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_vendor_network(self, mock_executor):
        """Test getting vendor network."""
        mock_path = MagicMock()
        mock_node = MagicMock()
        mock_node.id = 1
        mock_node.labels = {'Vendor'}
        mock_node.items.return_value = []

        mock_path.nodes.return_value = [mock_node]
        mock_path.relationships.return_value = []

        mock_executor.execute_query.return_value = [
            {
                'path': mock_path,
                'v': mock_node,
                'related': mock_node
            }
        ]

        result = Neo4jGraphService.get_vendor_network('VENDOR1', depth=2)

        self.assertEqual(result['vendor_id'], 'VENDOR1')
        self.assertIn('nodes', result)
        self.assertIn('relationships', result)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_related_materials(self, mock_executor):
        """Test getting related materials."""
        mock_material = {'id': 'MAT2', 'name': 'Material 2', 'properties': {}}
        mock_rel = {'id': 1, 'type': 'SUBSTITUTE', 'properties': {}}

        mock_executor.execute_query.return_value = [
            {
                'related': mock_material,
                'r': mock_rel
            }
        ]

        result = Neo4jGraphService.get_related_materials('MAT1', relationship_type='SUBSTITUTE')

        self.assertEqual(len(result), 1)
        self.assertIn('material', result[0])
        self.assertIn('relationship', result[0])

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_plant_capabilities(self, mock_executor):
        """Test getting plant capabilities."""
        mock_plant = {'id': 'P1', 'name': 'Plant 1', 'properties': {}}
        mock_capability = {'id': 'CAP1', 'name': 'Capability 1', 'properties': {}}
        mock_rel = {'id': 1, 'type': 'HAS_CAPABILITY', 'properties': {}}

        mock_executor.execute_query.return_value = [
            {
                'p': mock_plant,
                'capabilities': [
                    {
                        'relationship': mock_rel,
                        'node': mock_capability
                    }
                ]
            }
        ]

        result = Neo4jGraphService.get_plant_capabilities('P1')

        self.assertIn('plant', result)
        self.assertIn('capabilities', result)
        self.assertEqual(len(result['capabilities']), 1)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_plant_capabilities_not_found(self, mock_executor):
        """Test getting plant capabilities when plant not found."""
        mock_executor.execute_query.return_value = []

        with self.assertRaises(Neo4jNodeNotFoundError):
            Neo4jGraphService.get_plant_capabilities('P999')

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_inbound_service_levels_for_plants_for_period_success(self, mock_executor):
        """Test getting InboundServiceLevel data grouped by plant."""
        from datetime import date

        mock_service_level_records = [
            {
                'plant_nbr': '012',
                'date': date(2025, 1, 15),
                'avg_fill_rate': 0.95,
                'total_order_qty': 100.0,
                'total_received_qty': 95.0,
                'in_full_units': 90,
                'on_time_units': 85,
                'on_order_qty': 5,
                'avg_otif_percentage': 0.90,
                'total_omit_qty': 5
            },
            {
                'plant_nbr': '012',
                'date': date(2025, 1, 16),
                'avg_fill_rate': 0.92,
                'total_order_qty': 120.0,
                'total_received_qty': 110.0,
                'in_full_units': 105,
                'on_time_units': 100,
                'on_order_qty': 10,
                'avg_otif_percentage': 0.88,
                'total_omit_qty': 10
            },
            {
                'plant_nbr': '021',
                'date': date(2025, 1, 15),
                'avg_fill_rate': 0.88,
                'total_order_qty': 80.0,
                'total_received_qty': 70.0,
                'in_full_units': 65,
                'on_time_units': 60,
                'on_order_qty': 10,
                'avg_otif_percentage': 0.85,
                'total_omit_qty': 10
            }
        ]

        mock_plant_records = [
            {
                'p': {
                    'id': '012',
                    'labels': ['Plant'],
                    'properties': {'plant': '012', 'plant_name': 'Plant 012'}
                },
                'p_plant': '012',
                'pnbr': None,
                'pid': None
            }
        ]

        def execute_query_side_effect(query, params, database=None):
            if 'InboundServiceLevel' in query:
                return mock_service_level_records
            elif 'Plant' in query:
                return mock_plant_records
            return []

        mock_executor.execute_query.side_effect = execute_query_side_effect

        result = Neo4jGraphService.get_inbound_service_levels_for_plants_for_period(
            start_date='2025-01-01',
            end_date='2025-01-31'
        )

        self.assertEqual(len(result), 2)
        self.assertIn('plant', result[0])
        self.assertIn('service_levels', result[0])
        self.assertEqual(len(result[0]['service_levels']), 2)
        self.assertEqual(result[0]['service_levels'][0]['date'], date(2025, 1, 15))
        self.assertEqual(result[0]['service_levels'][0]['fill_rate'], 0.95)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_inbound_service_levels_with_material_filter(self, mock_executor):
        """Test getting InboundServiceLevel data with material filtering."""
        from datetime import date

        mock_executor.execute_query.return_value = [
            {
                'plant_nbr': '012',
                'date': date(2025, 1, 15),
                'avg_fill_rate': 0.95,
                'total_order_qty': 100.0,
                'total_received_qty': 95.0,
                'in_full_units': 90,
                'on_time_units': 85,
                'on_order_qty': 5,
                'avg_otif_percentage': 0.90,
                'total_omit_qty': 5
            }
        ]

        Neo4jGraphService.get_inbound_service_levels_for_plants_for_period(
            start_date='2025-01-01',
            end_date='2025-01-31',
            mat_nbrs=['MAT001', 'MAT002']
        )

        call_args = mock_executor.execute_query.call_args_list[0]
        query = call_args[0][0]
        params = call_args[0][1]

        self.assertIn('mat_nbr', query)
        self.assertIn('mat_nbrs', params)
        self.assertEqual(params['mat_nbrs'], ['MAT001', 'MAT002'])

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_inbound_service_levels_no_results(self, mock_executor):
        """Test getting InboundServiceLevel data when no results found."""
        mock_executor.execute_query.return_value = []

        result = Neo4jGraphService.get_inbound_service_levels_for_plants_for_period(
            start_date='2025-01-01',
            end_date='2025-01-31'
        )

        self.assertEqual(len(result), 0)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_inbound_service_levels_synthetic_plants(self, mock_executor):
        """Test synthetic plant creation when Plant nodes don't match."""
        from datetime import date

        mock_service_level_records = [
            {
                'plant_nbr': '999',
                'date': date(2025, 1, 15),
                'avg_fill_rate': 0.95,
                'total_order_qty': 100.0,
                'total_received_qty': 95.0,
                'in_full_units': 90,
                'on_time_units': 85,
                'on_order_qty': 5,
                'avg_otif_percentage': 0.90,
                'total_omit_qty': 5
            }
        ]

        def execute_query_side_effect(query, params, database=None):
            if 'InboundServiceLevel' in query:
                return mock_service_level_records
            elif 'Plant' in query:
                return []
            return []

        mock_executor.execute_query.side_effect = execute_query_side_effect

        result = Neo4jGraphService.get_inbound_service_levels_for_plants_for_period(
            start_date='2025-01-01',
            end_date='2025-01-31'
        )

        self.assertEqual(len(result), 1)
        self.assertIn('plant', result[0])
        self.assertEqual(result[0]['plant']['properties']['plant_nbr'], '999')
        self.assertEqual(result[0]['plant']['properties']['name'], 'Plant 999')

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_inbound_service_levels_data_aggregation(self, mock_executor):
        """Test that data is properly aggregated and grouped by plant and date."""
        from datetime import date

        mock_service_level_records = [
            {
                'plant_nbr': '012',
                'date': date(2025, 1, 15),
                'avg_fill_rate': 0.95,
                'total_order_qty': 100.0,
                'total_received_qty': 95.0,
                'in_full_units': 90,
                'on_time_units': 85,
                'on_order_qty': 5,
                'avg_otif_percentage': 0.90,
                'total_omit_qty': 5
            }
        ]

        mock_executor.execute_query.return_value = mock_service_level_records

        result = Neo4jGraphService.get_inbound_service_levels_for_plants_for_period(
            start_date='2025-01-01',
            end_date='2025-01-31'
        )

        self.assertEqual(len(result), 1)
        service_level = result[0]['service_levels'][0]
        self.assertIn('fill_rate', service_level)
        self.assertIn('total_order_qty', service_level)
        self.assertIn('total_received_qty', service_level)
        self.assertIn('in_full_units', service_level)
        self.assertIn('on_time_units', service_level)
        self.assertIn('on_order_qty', service_level)
        self.assertIn('otif_percentage', service_level)
        self.assertIn('total_omit_qty', service_level)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_inbound_service_levels_error_handling(self, mock_executor):
        """Test error handling when Neo4j query fails."""
        from api.neo4j_graph_api.exceptions import Neo4jQueryError

        mock_executor.execute_query.side_effect = Neo4jQueryError("Query failed")

        with self.assertRaises(Neo4jQueryError):
            Neo4jGraphService.get_inbound_service_levels_for_plants_for_period(
                start_date='2025-01-01',
                end_date='2025-01-31'
            )

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_substitutes_count_success(self, mock_executor):
        """Test getting material substitutes count returns count from Neo4j."""
        mock_executor.execute_query.return_value = [{'total': 5}]

        result = Neo4jGraphService.get_material_substitutes_count('MAT123')

        self.assertEqual(result, 5)
        mock_executor.execute_query.assert_called_once()
        call_args = mock_executor.execute_query.call_args
        self.assertIn('mat_nbr', call_args[0][1])
        self.assertEqual(call_args[0][1]['mat_nbr'], 'MAT123')

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_substitutes_count_empty(self, mock_executor):
        """Test get_material_substitutes_count returns 0 when no records."""
        mock_executor.execute_query.return_value = []

        result = Neo4jGraphService.get_material_substitutes_count('MAT999')

        self.assertEqual(result, 0)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_substitutes_count_error(self, mock_executor):
        """Test get_material_substitutes_count propagates Neo4jQueryError."""
        from api.neo4j_graph_api.exceptions import Neo4jQueryError

        mock_executor.execute_query.side_effect = Neo4jQueryError("Connection failed")

        with self.assertRaises(Neo4jQueryError):
            Neo4jGraphService.get_material_substitutes_count('MAT123')

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_substitutes_count_with_formulary(self, mock_executor):
        """Test get_material_substitutes_count with material_formulary uses formulary filter."""
        mock_executor.execute_query.return_value = [{'total': 3}]

        result = Neo4jGraphService.get_material_substitutes_count(
            'MAT123', material_formulary='TEST'
        )

        self.assertEqual(result, 3)
        mock_executor.execute_query.assert_called_once()
        call_args = mock_executor.execute_query.call_args
        query = call_args[0][0]
        params = call_args[0][1]
        self.assertIn('HAS_FORMULARY', query)
        self.assertIn('material_formulary', query)
        self.assertEqual(params.get('material_formulary'), 'TEST')
        self.assertEqual(params.get('mat_nbr'), 'MAT123')

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_substitutes_success(self, mock_executor):
        """Test get_material_substitutes returns list with correct record shape and limit/offset."""
        mock_executor.execute_query.return_value = [
            {
                'mat_nbr': 'MAT001',
                'sub_mat_nbr': 'MAT002',
                'name': 'Substitute Material',
                'dollars_at_risk': 1000.0,
                'market_share': 0.15,
                'forecast_qty_7day': 50.0,
                'saleable_qty_on_hand': 200.0,
                'cost_per_unit': 10.5,
                'vendor_nbr': 'V001',
                'vendor_name': 'Vendor One',
                'substitute_material_rank': 1,
                'material_formularies': [{'mat_nbr': 'MAT002', 'parent_program': 'Program A'}],
                'available_plants_count': 3,
            }
        ]

        result = Neo4jGraphService.get_material_substitutes(
            mat_nbr='MAT001', limit=10, offset=0
        )

        self.assertEqual(len(result), 1)
        record = result[0]
        self.assertEqual(record['mat_nbr'], 'MAT001')
        self.assertEqual(record['sub_mat_nbr'], 'MAT002')
        self.assertEqual(record['name'], 'Substitute Material')
        self.assertEqual(record['dollars_at_risk'], 1000.0)
        self.assertEqual(record['market_share'], 0.15)
        self.assertEqual(record['forecast_qty_7day'], 50.0)
        self.assertEqual(record['saleable_qty_on_hand'], 200.0)
        self.assertEqual(record['cost_per_unit'], 10.5)
        self.assertEqual(record['vendor_nbr'], 'V001')
        self.assertEqual(record['vendor_name'], 'Vendor One')
        self.assertEqual(record['substitute_material_rank'], 1)
        self.assertEqual(record['material_formularies'], [{'mat_nbr': 'MAT002', 'parent_program': 'Program A'}])
        self.assertEqual(record['available_plants_count'], 3)

        mock_executor.execute_query.assert_called_once()
        call_args = mock_executor.execute_query.call_args
        self.assertEqual(call_args[0][1]['mat_nbr'], 'MAT001')
        self.assertEqual(call_args[0][1]['limit'], 10)
        self.assertEqual(call_args[0][1]['offset'], 0)
        self.assertIsNone(call_args[0][1].get('material_formulary'))

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_substitutes_with_formulary(self, mock_executor):
        """Test get_material_substitutes with material_formulary passes param and uses formulary query."""
        mock_executor.execute_query.return_value = [
            {
                'mat_nbr': 'MAT001',
                'sub_mat_nbr': 'MAT002',
                'name': 'Substitute One',
                'dollars_at_risk': None,
                'market_share': None,
                'forecast_qty_7day': None,
                'saleable_qty_on_hand': None,
                'cost_per_unit': None,
                'vendor_nbr': None,
                'vendor_name': None,
                'substitute_material_rank': 1,
                'material_formularies': [{'mat_nbr': 'MAT002', 'parent_program': 'TEST'}],
                'available_plants_count': 0,
            }
        ]

        result = Neo4jGraphService.get_material_substitutes(
            mat_nbr='MAT001', limit=10, offset=0, material_formulary='TEST'
        )

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['material_formularies'][0]['parent_program'], 'TEST')
        mock_executor.execute_query.assert_called_once()
        call_args = mock_executor.execute_query.call_args
        query = call_args[0][0]
        params = call_args[0][1]
        self.assertIn('HAS_FORMULARY', query)
        self.assertIn('material_formulary', query)
        self.assertEqual(params.get('material_formulary'), 'TEST')

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_substitutes_uses_latest_date_for_available_plants_count(self, mock_executor):
        """Cypher uses latest demand date for available_plants_count (Option A), not 90-day window."""
        mock_executor.execute_query.return_value = [
            {
                'mat_nbr': 'MAT001',
                'sub_mat_nbr': 'MAT002',
                'name': 'Sub',
                'dollars_at_risk': None,
                'market_share': None,
                'forecast_qty_7day': None,
                'saleable_qty_on_hand': None,
                'cost_per_unit': None,
                'vendor_nbr': None,
                'vendor_name': None,
                'substitute_material_rank': 1,
                'material_formularies': [],
                'available_plants_count': 1,
            }
        ]
        Neo4jGraphService.get_material_substitutes(mat_nbr='MAT001', limit=10, offset=0)
        call_args = mock_executor.execute_query.call_args
        query = call_args[0][0]
        # Must use latest date per substitute (Option A), not 90-day window
        self.assertIn('dAll:DemandForecast', query)
        self.assertIn('latest_date', query)
        self.assertIn('coalesce(d.saleable_qty_on_hand, 0) > 0', query)
        self.assertNotIn('duration({ days: 90 })', query)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_substitutes_empty(self, mock_executor):
        """Test get_material_substitutes returns empty list when no substitutes."""
        mock_executor.execute_query.return_value = []

        result = Neo4jGraphService.get_material_substitutes(mat_nbr='MAT999')

        self.assertEqual(result, [])

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_substitutes_error_propagation(self, mock_executor):
        """Test get_material_substitutes propagates Neo4jQueryError."""
        from api.neo4j_graph_api.exceptions import Neo4jQueryError

        mock_executor.execute_query.side_effect = Neo4jQueryError("Query failed")

        with self.assertRaises(Neo4jQueryError):
            Neo4jGraphService.get_material_substitutes(mat_nbr='MAT001', limit=10, offset=0)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_inventory_on_each_plant_success(self, mock_executor):
        """Test get_material_inventory_on_each_plant returns list with expected keys."""
        from datetime import date

        mock_executor.execute_query.side_effect = [
            [{'latest_date': date(2025, 1, 15)}],
            [
                {
                    'demand_date': date(2025, 1, 15),
                    'saleable_qty_on_hand': 100,
                    'unrestricted_qty_on_hand': 110,
                    'forecast_qty_7day': 50,
                    'qty_ordered': 10,
                    'shipped_qty': 5,
                    'received_qty': 8,
                    'on_order_qty': 2,
                    'transfer_in_qty': 0,
                    'transfer_out_qty': 0,
                    'plant_nbr': '012',
                }
            ],
            [
                {
                    'p': {
                        'id': 1,
                        'labels': ['Plant'],
                        'properties': {'plant': '012', 'plant_nbr': '012', 'name': 'Plant 012'},
                    },
                    'p_plant': '012',
                    'pnbr': '012',
                    'pid': '012',
                }
            ],
        ]

        result = Neo4jGraphService.get_material_inventory_on_each_plant(mat_nbr='MAT001')

        self.assertEqual(len(result), 1)
        item = result[0]
        self.assertIn('plant', item)
        self.assertEqual(item['demand_date'], date(2025, 1, 15))
        self.assertEqual(item['saleable_qty_on_hand'], 100)
        self.assertEqual(item['unrestricted_qty_on_hand'], 110)
        self.assertEqual(item['plant_nbr'], '012')
        self.assertIn('forecast_qty_7day', item)
        self.assertIn('qty_ordered', item)

        self.assertEqual(mock_executor.execute_query.call_count, 3)
        call_list = mock_executor.execute_query.call_args_list
        self.assertIn('mat_nbr', call_list[0][0][1])
        self.assertEqual(call_list[0][0][1]['mat_nbr'], 'MAT001')
        self.assertEqual(call_list[1][0][1]['latest_date'], date(2025, 1, 15))

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_inventory_on_each_plant_empty_no_latest_date(self, mock_executor):
        """Test get_material_inventory_on_each_plant returns [] when no latest date."""
        mock_executor.execute_query.return_value = []

        result = Neo4jGraphService.get_material_inventory_on_each_plant(mat_nbr='MAT999')

        self.assertEqual(result, [])
        mock_executor.execute_query.assert_called_once()

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_inventory_on_each_plant_empty_no_inventory(self, mock_executor):
        """Test get_material_inventory_on_each_plant returns [] when no inventory records."""
        from datetime import date

        mock_executor.execute_query.side_effect = [
            [{'latest_date': date(2025, 1, 15)}],
            [],
        ]

        result = Neo4jGraphService.get_material_inventory_on_each_plant(mat_nbr='MAT001')

        self.assertEqual(result, [])
        self.assertEqual(mock_executor.execute_query.call_count, 2)

    @patch('api.neo4j_graph_api.services.Neo4jQueryExecutor')
    def test_get_material_inventory_on_each_plant_error_propagation(self, mock_executor):
        """Test get_material_inventory_on_each_plant propagates Neo4jQueryError."""
        from api.neo4j_graph_api.exceptions import Neo4jQueryError

        mock_executor.execute_query.side_effect = Neo4jQueryError("Query failed")

        with self.assertRaises(Neo4jQueryError):
            Neo4jGraphService.get_material_inventory_on_each_plant(mat_nbr='MAT001')
