"""
Tests for Neo4j connection management.
"""
from unittest.mock import patch, MagicMock

from django.test import TestCase

from api.neo4j_graph_api.connection import Neo4jConnection
from api.neo4j_graph_api.exceptions import Neo4jConnectionError


class Neo4jConnectionTest(TestCase):
    """Test connection management layer."""

    def setUp(self):
        """Reset driver before each test."""
        Neo4jConnection._driver = None

    def tearDown(self):
        """Clean up driver after each test."""
        if Neo4jConnection._driver:
            Neo4jConnection.close()

    @patch('api.neo4j_graph_api.connection.GraphDatabase')
    def test_get_driver_creates_driver(self, mock_graph_db):
        """Test that get_driver creates a new driver instance."""
        mock_driver = MagicMock()
        mock_driver.verify_connectivity.return_value = True
        mock_graph_db.driver.return_value = mock_driver

        driver = Neo4jConnection.get_driver()

        self.assertIsNotNone(driver)
        mock_graph_db.driver.assert_called_once()
        mock_driver.verify_connectivity.assert_called_once()

    @patch('api.neo4j_graph_api.connection.GraphDatabase')
    def test_get_driver_singleton(self, mock_graph_db):
        """Test that get_driver returns the same instance (singleton)."""
        mock_driver = MagicMock()
        mock_driver.verify_connectivity.return_value = True
        mock_graph_db.driver.return_value = mock_driver

        driver1 = Neo4jConnection.get_driver()
        driver2 = Neo4jConnection.get_driver()

        self.assertIs(driver1, driver2)
        mock_graph_db.driver.assert_called_once()

    @patch('api.neo4j_graph_api.connection.GraphDatabase')
    def test_get_driver_connection_error(self, mock_graph_db):
        """Test that connection errors are properly handled."""
        mock_graph_db.driver.side_effect = Exception("Connection failed")

        with self.assertRaises(Neo4jConnectionError):
            Neo4jConnection.get_driver()

    @patch('api.neo4j_graph_api.connection.GraphDatabase')
    def test_get_session(self, mock_graph_db):
        """Test that get_session creates a session."""
        mock_driver = MagicMock()
        mock_session = MagicMock()
        mock_driver.verify_connectivity.return_value = True
        mock_driver.session.return_value = mock_session
        mock_graph_db.driver.return_value = mock_driver

        session = Neo4jConnection.get_session()

        self.assertIsNotNone(session)
        mock_driver.session.assert_called_once()

    @patch('api.neo4j_graph_api.connection.GraphDatabase')
    def test_get_session_with_database(self, mock_graph_db):
        """Test that get_session uses custom database name."""
        mock_driver = MagicMock()
        mock_session = MagicMock()
        mock_driver.verify_connectivity.return_value = True
        mock_driver.session.return_value = mock_session
        mock_graph_db.driver.return_value = mock_driver

        session = Neo4jConnection.get_session(database='custom_db')

        self.assertIsNotNone(session)
        mock_driver.session.assert_called_once_with(database='custom_db')

    @patch('api.neo4j_graph_api.connection.GraphDatabase')
    def test_close(self, mock_graph_db):
        """Test that close properly closes the driver."""
        mock_driver = MagicMock()
        mock_driver.verify_connectivity.return_value = True
        mock_graph_db.driver.return_value = mock_driver

        Neo4jConnection.get_driver()
        Neo4jConnection.close()

        mock_driver.close.assert_called_once()
        self.assertIsNone(Neo4jConnection._driver)

    @patch('api.neo4j_graph_api.connection.GraphDatabase')
    def test_is_connected_true(self, mock_graph_db):
        """Test is_connected returns True when connected."""
        mock_driver = MagicMock()
        mock_driver.verify_connectivity.return_value = True
        mock_graph_db.driver.return_value = mock_driver

        Neo4jConnection.get_driver()
        result = Neo4jConnection.is_connected()

        self.assertTrue(result)

    @patch('api.neo4j_graph_api.connection.GraphDatabase')
    def test_is_connected_false(self, mock_graph_db):
        """Test is_connected returns False when not connected."""
        mock_driver = MagicMock()
        mock_driver.verify_connectivity.side_effect = Exception("Not connected")
        mock_graph_db.driver.return_value = mock_driver

        # Set driver directly to avoid exception in get_driver()
        Neo4jConnection._driver = mock_driver
        result = Neo4jConnection.is_connected()

        self.assertFalse(result)

    def test_is_connected_no_driver(self):
        """Test is_connected returns False when driver is None."""
        Neo4jConnection._driver = None
        result = Neo4jConnection.is_connected()

        self.assertFalse(result)
