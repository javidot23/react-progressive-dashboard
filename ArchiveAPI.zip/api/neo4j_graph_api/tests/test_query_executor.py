"""
Tests for Neo4j query executor layer.
"""
from unittest.mock import patch, MagicMock

from django.test import TestCase

from api.neo4j_graph_api.query_executor import Neo4jQueryExecutor
from api.neo4j_graph_api.exceptions import Neo4jQueryError


class Neo4jQueryExecutorTest(TestCase):
    """Test query executor layer."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_session = MagicMock()
        self.mock_result = MagicMock()
        self.mock_record = MagicMock()

    @patch('api.neo4j_graph_api.query_executor.Neo4jConnection')
    def test_execute_query_success(self, mock_connection):
        """Test successful query execution."""
        # Setup mocks
        mock_connection.get_session.return_value = self.mock_session
        self.mock_session.run.return_value = self.mock_result
        self.mock_result.__iter__.return_value = [self.mock_record]
        self.mock_record.items.return_value = [('key1', 'value1'), ('key2', 'value2')]

        result = Neo4jQueryExecutor.execute_query("MATCH (n) RETURN n", {})

        self.assertEqual(len(result), 1)
        self.mock_session.run.assert_called_once_with("MATCH (n) RETURN n", {})
        self.mock_session.close.assert_called_once()

    @patch('api.neo4j_graph_api.query_executor.Neo4jConnection')
    def test_execute_query_with_parameters(self, mock_connection):
        """Test query execution with parameters."""
        mock_connection.get_session.return_value = self.mock_session
        self.mock_session.run.return_value = self.mock_result
        self.mock_result.__iter__.return_value = []

        params = {'id': 123}
        Neo4jQueryExecutor.execute_query("MATCH (n) WHERE n.id = $id RETURN n", params)

        self.mock_session.run.assert_called_once_with("MATCH (n) WHERE n.id = $id RETURN n", params)

    @patch('api.neo4j_graph_api.query_executor.Neo4jConnection')
    def test_execute_query_error(self, mock_connection):
        """Test query execution error handling."""
        mock_connection.get_session.return_value = self.mock_session
        self.mock_session.run.side_effect = Exception("Query failed")

        with self.assertRaises(Neo4jQueryError):
            Neo4jQueryExecutor.execute_query("INVALID QUERY", {})

        self.mock_session.close.assert_called_once()

    @patch('api.neo4j_graph_api.query_executor.Neo4jConnection')
    def test_get_node_by_id_found(self, mock_connection):
        """Test getting node by ID when node exists."""
        mock_node = MagicMock()
        mock_node.id = 123
        mock_node.labels = {'Label'}
        mock_node.items.return_value = [('prop1', 'value1')]

        mock_connection.get_session.return_value = self.mock_session
        self.mock_session.run.return_value = self.mock_result
        self.mock_result.__iter__.return_value = [self.mock_record]
        self.mock_record.items.return_value = [('n', mock_node)]

        result = Neo4jQueryExecutor.get_node_by_id(123)

        self.assertIsNotNone(result)
        self.assertEqual(result['id'], 123)
        self.assertEqual(result['labels'], ['Label'])

    @patch('api.neo4j_graph_api.query_executor.Neo4jConnection')
    def test_get_node_by_id_not_found(self, mock_connection):
        """Test getting node by ID when node doesn't exist."""
        mock_connection.get_session.return_value = self.mock_session
        self.mock_session.run.return_value = self.mock_result
        self.mock_result.__iter__.return_value = []

        result = Neo4jQueryExecutor.get_node_by_id(999)

        self.assertIsNone(result)

    @patch('api.neo4j_graph_api.query_executor.Neo4jConnection')
    def test_get_nodes_by_label(self, mock_connection):
        """Test getting nodes by label."""
        mock_node1 = MagicMock()
        mock_node1.id = 1
        mock_node1.labels = {'Plant'}
        mock_node1.items.return_value = []

        mock_node2 = MagicMock()
        mock_node2.id = 2
        mock_node2.labels = {'Plant'}
        mock_node2.items.return_value = []

        mock_connection.get_session.return_value = self.mock_session
        self.mock_session.run.return_value = self.mock_result
        self.mock_result.__iter__.return_value = [
            MagicMock(items=lambda: [('n', mock_node1)]),
            MagicMock(items=lambda: [('n', mock_node2)])
        ]

        result = Neo4jQueryExecutor.get_nodes_by_label('Plant', limit=10)

        self.assertEqual(len(result), 2)

    @patch('api.neo4j_graph_api.query_executor.Neo4jConnection')
    def test_get_relationships(self, mock_connection):
        """Test getting relationships for a node."""
        mock_rel = MagicMock()
        mock_rel.id = 1
        mock_rel.type = 'SUPPLIES'
        mock_rel.start_node.id = 100
        mock_rel.end_node.id = 200
        mock_rel.items.return_value = []

        mock_node = MagicMock()
        mock_node.id = 200
        mock_node.labels = {'Material'}
        mock_node.items.return_value = []

        mock_connection.get_session.return_value = self.mock_session
        self.mock_session.run.return_value = self.mock_result
        self.mock_result.__iter__.return_value = [
            MagicMock(items=lambda: [('r', mock_rel), ('m', mock_node)])
        ]

        result = Neo4jQueryExecutor.get_relationships(100, relationship_type='SUPPLIES')

        self.assertEqual(len(result), 1)
        self.assertIn('relationship', result[0])
        self.assertIn('related_node', result[0])

    @patch('api.neo4j_graph_api.query_executor.Neo4jConnection')
    def test_find_path(self, mock_connection):
        """Test finding path between nodes."""
        mock_node1 = MagicMock()
        mock_node1.id = 1
        mock_node1.labels = {'Node'}
        mock_node1.items.return_value = []

        mock_node2 = MagicMock()
        mock_node2.id = 2
        mock_node2.labels = {'Node'}
        mock_node2.items.return_value = []

        mock_rel = MagicMock()
        mock_rel.id = 1
        mock_rel.type = 'RELATES_TO'
        mock_rel.start_node.id = 1
        mock_rel.end_node.id = 2
        mock_rel.items.return_value = []

        # Create a proper mock path object with nodes() and relationships() methods
        # Use spec to control which attributes exist - path objects don't have 'id'
        class PathLike:
            def nodes(self):
                return [mock_node1, mock_node2]

            def relationships(self):
                return [mock_rel]

        mock_path = PathLike()

        mock_connection.get_session.return_value = self.mock_session
        self.mock_session.run.return_value = self.mock_result
        # Create a record that returns the path object directly
        # The _convert_record will leave it unchanged since it doesn't have 'id'
        mock_record = MagicMock()
        mock_record.items.return_value = [('path', mock_path)]
        self.mock_result.__iter__.return_value = [mock_record]

        result = Neo4jQueryExecutor.find_path(1, 2, max_depth=5)

        self.assertEqual(len(result), 1)
        self.assertIn('nodes', result[0])
        self.assertIn('relationships', result[0])
        self.assertEqual(len(result[0]['nodes']), 2)
        self.assertEqual(len(result[0]['relationships']), 1)
