"""High-level Neo4j Graph API service layer."""
import logging
from typing import Any, Dict, List, Optional

from .exceptions import Neo4jNodeNotFoundError
from .query_executor import Neo4jQueryExecutor

logger = logging.getLogger(__name__)


class Neo4jGraphService:
    """High-level service for Neo4j graph operations."""

    @staticmethod
    def get_plants(
        plant_ids: Optional[List[str]] = None,
        filters: Optional[Dict[str, Any]] = None,
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get plant nodes from the graph.

        Args:
            plant_ids: Optional list of plant IDs to filter by
            filters: Optional dictionary of additional filters (e.g., {'country': 'US'})
            database: Optional database name

        Returns:
            List[Dict[str, Any]]: List of plant nodes with their properties
        """
        logger.info(f"Fetching plants from Neo4j (ids: {plant_ids})")

        if plant_ids:
            ids_str = ', '.join([f"'{pid}'" for pid in plant_ids])
            query = f"""
            MATCH (p:Plant)
            WHERE p.id IN [{ids_str}]
            RETURN p
            ORDER BY p.id
            """
        else:
            query = "MATCH (p:Plant) RETURN p ORDER BY p.id"

        if filters:
            where_clauses = []
            params = {}
            for key, value in filters.items():
                param_name = f"filter_{key}"
                where_clauses.append(f"p.{key} = ${param_name}")
                params[param_name] = value

            if where_clauses:
                query = query.replace("RETURN p", f"WHERE {' AND '.join(where_clauses)} RETURN p")
        else:
            params = {}

        try:
            records = Neo4jQueryExecutor.execute_query(query, params, database=database)
            plants = [record['p'] for record in records if 'p' in record]
            logger.info(f"Found {len(plants)} plants")
            return plants
        except Exception as e:
            logger.error(f"Failed to get plants: {str(e)}")
            raise

    @staticmethod
    def get_material_supply_chain(
        material_id: str,
        depth: int = 2,
        database: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get supply chain relationships for a material.

        Args:
            material_id: Material identifier
            depth: Maximum depth to traverse (default: 2)
            database: Optional database name

        Returns:
            Dict[str, Any]: Supply chain data including related nodes and relationships
        """
        logger.info(f"Fetching supply chain for material {material_id} (depth: {depth})")

        query = f"""
        MATCH path = (m:Material)-[*1..{depth}]-(related)
        WHERE m.id = $material_id
        RETURN path, m, related
        """

        try:
            records = Neo4jQueryExecutor.execute_query(
                query,
                {'material_id': material_id},
                database=database
            )

            if not records:
                logger.warning(f"No supply chain found for material {material_id}")
                return {
                    'material_id': material_id,
                    'nodes': [],
                    'relationships': []
                }

            nodes = {}
            relationships = []

            for record in records:
                path = record.get('path')
                if path and hasattr(path, 'nodes') and hasattr(path, 'relationships'):
                    for node in path.nodes():
                        if node.id not in nodes:
                            nodes[node.id] = Neo4jQueryExecutor._convert_node(node)
                    for rel in path.relationships():
                        if rel:
                            relationships.append(Neo4jQueryExecutor._convert_relationship(rel))

            result = {
                'material_id': material_id,
                'nodes': list(nodes.values()),
                'relationships': relationships
            }

            logger.info(f"Found {len(result['nodes'])} nodes and {len(result['relationships'])} relationships")
            return result
        except Exception as e:
            logger.error(f"Failed to get supply chain for material {material_id}: {str(e)}")
            raise

    @staticmethod
    def get_vendor_network(
        vendor_id: str,
        depth: int = 2,
        database: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get vendor network up to N degrees of separation.

        Args:
            vendor_id: Vendor identifier
            depth: Maximum depth to traverse (default: 2)
            database: Optional database name

        Returns:
            Dict[str, Any]: Vendor network data
        """
        logger.info(f"Fetching vendor network for vendor {vendor_id} (depth: {depth})")

        query = f"""
        MATCH path = (v:Vendor)-[*1..{depth}]-(related)
        WHERE v.id = $vendor_id
        RETURN path, v, related
        """

        try:
            records = Neo4jQueryExecutor.execute_query(
                query,
                {'vendor_id': vendor_id},
                database=database
            )

            if not records:
                logger.warning(f"No network found for vendor {vendor_id}")
                return {
                    'vendor_id': vendor_id,
                    'nodes': [],
                    'relationships': []
                }

            nodes = {}
            relationships = []

            for record in records:
                path = record.get('path')
                if path and hasattr(path, 'nodes') and hasattr(path, 'relationships'):
                    for node in path.nodes():
                        if node.id not in nodes:
                            nodes[node.id] = Neo4jQueryExecutor._convert_node(node)
                    for rel in path.relationships():
                        if rel:
                            relationships.append(Neo4jQueryExecutor._convert_relationship(rel))

            result = {
                'vendor_id': vendor_id,
                'nodes': list(nodes.values()),
                'relationships': relationships
            }

            logger.info(f"Found {len(result['nodes'])} nodes and {len(result['relationships'])} relationships")
            return result
        except Exception as e:
            logger.error(f"Failed to get vendor network for vendor {vendor_id}: {str(e)}")
            raise

    @staticmethod
    def get_related_materials(
        material_id: str,
        relationship_type: Optional[str] = None,
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get materials related to a given material.

        Args:
            material_id: Material identifier
            relationship_type: Optional relationship type to filter by
            database: Optional database name

        Returns:
            List[Dict[str, Any]]: List of related materials
        """
        logger.info(f"Fetching related materials for {material_id} (relationship: {relationship_type})")

        if relationship_type:
            query = f"""
            MATCH (m:Material)-[r:{relationship_type}]-(related:Material)
            WHERE m.id = $material_id
            RETURN related, r
            """
        else:
            query = """
            MATCH (m:Material)-[r]-(related:Material)
            WHERE m.id = $material_id
            RETURN related, r
            """

        try:
            records = Neo4jQueryExecutor.execute_query(
                query,
                {'material_id': material_id},
                database=database
            )

            materials = [
                {
                    'material': record['related'],
                    'relationship': record.get('r')
                }
                for record in records
                if 'related' in record
            ]

            logger.info(f"Found {len(materials)} related materials")
            return materials
        except Exception as e:
            logger.error(f"Failed to get related materials for {material_id}: {str(e)}")
            raise

    @staticmethod
    def get_plant_capabilities(
        plant_id: str,
        database: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get capabilities and attributes for a plant.

        Args:
            plant_id: Plant identifier
            database: Optional database name

        Returns:
            Dict[str, Any]: Plant capabilities and attributes
        """
        logger.info(f"Fetching capabilities for plant {plant_id}")

        query = """
        MATCH (p:Plant)
        WHERE p.id = $plant_id
        OPTIONAL MATCH (p)-[r]-(capability)
        RETURN p, collect({relationship: r, node: capability}) as capabilities
        """

        try:
            records = Neo4jQueryExecutor.execute_query(
                query,
                {'plant_id': plant_id},
                database=database
            )

            if not records or 'p' not in records[0]:
                logger.warning(f"Plant {plant_id} not found")
                raise Neo4jNodeNotFoundError(f"Plant {plant_id} not found")

            plant = records[0]['p']
            capabilities = records[0].get('capabilities', [])

            result = {
                'plant': plant,
                'capabilities': capabilities
            }

            logger.info(f"Found {len(capabilities)} capabilities for plant {plant_id}")
            return result
        except Neo4jNodeNotFoundError:
            raise
        except Exception as e:
            logger.error(f"Failed to get plant capabilities for {plant_id}: {str(e)}")
            raise

    @staticmethod
    def get_inbound_service_levels_for_plants_for_period(
        start_date: str,
        end_date: str,
        mat_nbrs: Optional[List[str]] = None,
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get InboundServiceLevel data grouped by plant for a specific period.

        Queries InboundServiceLevel nodes from Neo4j, aggregates metrics by plant and date,
        and returns data grouped by plant with daily service level metrics. If Plant nodes
        don't exist in Neo4j matching the plant_nbr values, synthetic plant data is created.

        Args:
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            mat_nbrs: Optional list of material numbers to filter by
            database: Optional Neo4j database name

        Returns:
            List of dictionaries, each containing:
                - "plant": Plant node dictionary from Neo4j (or synthetic if not found)
                - "service_levels": List of daily service level dictionaries with:
                    - date: Date of the service level record
                    - fill_rate: Average fill rate
                    - total_order_qty: Sum of total order quantities
                    - total_received_qty: Sum of total received quantities
                    - in_full_units: Sum of in-full units
                    - on_time_units: Sum of on-time units
                    - on_order_qty: Sum of on-order quantities
                    - otif_percentage: Average OTIF percentage
                    - total_omit_qty: Sum of total omit quantities

        Raises:
            Neo4jQueryError: If the Neo4j query execution fails
        """
        from collections import defaultdict

        logger.info(f"Fetching InboundServiceLevel data for period: {start_date} to {end_date}")

        query = """
        MATCH (isl:InboundServiceLevel)
        WHERE date(isl.date) >= date($start_date)
          AND date(isl.date) <= date($end_date)
        """
        params = {
            'start_date': start_date,
            'end_date': end_date
        }

        if mat_nbrs:
            query += " AND isl.mat_nbr IN $mat_nbrs"
            params['mat_nbrs'] = mat_nbrs

        query += """
        WITH isl.plant_nbr as plant_nbr, isl.date as date,
             avg(COALESCE(toFloat(isl.fill_rate), 0.0)) as avg_fill_rate,
             sum(COALESCE(toInteger(isl.total_order_qty), 0)) as total_order_qty,
             sum(COALESCE(toInteger(isl.total_received_qty), 0)) as total_received_qty,
             sum(COALESCE(toInteger(isl.in_full_units), 0)) as in_full_units,
             sum(COALESCE(toInteger(isl.on_time_units), 0)) as on_time_units,
             sum(COALESCE(toInteger(isl.on_order_qty), 0)) as on_order_qty,
             avg(COALESCE(toFloat(isl.otif_percentage), 0.0)) as avg_otif_percentage,
             sum(COALESCE(toInteger(isl.total_omit_qty), 0)) as total_omit_qty
        WHERE plant_nbr IS NOT NULL
        RETURN plant_nbr, date, avg_fill_rate, total_order_qty, total_received_qty,
               in_full_units, on_time_units, on_order_qty, avg_otif_percentage, total_omit_qty
        ORDER BY plant_nbr, date
        """

        try:
            records = Neo4jQueryExecutor.execute_query(query, params, database=database)

            if not records:
                logger.info("No InboundServiceLevel rows found for period")
                return []

            grouped = defaultdict(list)
            plant_nbrs = set()

            for record in records:
                plant_nbr = record.get('plant_nbr')
                if plant_nbr:
                    plant_nbrs.add(plant_nbr)
                    grouped[plant_nbr].append({
                        "date": record.get('date'),
                        "fill_rate": round(record.get('avg_fill_rate') or 0.0, 3),
                        "total_order_qty": round(record.get('total_order_qty') or 0.0, 2),
                        "total_received_qty": round(record.get('total_received_qty') or 0.0, 2),
                        "in_full_units": int(record.get('in_full_units') or 0),
                        "on_time_units": int(record.get('on_time_units') or 0),
                        "on_order_qty": int(record.get('on_order_qty') or 0),
                        "otif_percentage": round(record.get('avg_otif_percentage') or 0.0, 3),
                        "total_omit_qty": int(record.get('total_omit_qty') or 0),
                    })

            plants = {}
            if plant_nbrs:
                plant_list = list(plant_nbrs)
                plant_query = """
                MATCH (p:Plant)
                WHERE p.plant IN $plant_nbrs
                   OR p.plant_nbr IN $plant_nbrs
                   OR p.id IN $plant_nbrs
                RETURN p, p.plant as p_plant, p.plant_nbr as pnbr, p.id as pid
                ORDER BY p.plant
                """
                plant_records = Neo4jQueryExecutor.execute_query(
                    plant_query,
                    {'plant_nbrs': plant_list},
                    database=database
                )
                plant_nodes = [record['p'] for record in plant_records if 'p' in record]

                if plant_nodes:
                    for record in plant_records:
                        plant_node = record.get('p', {})
                        plant_props = plant_node.get('properties', {}) if isinstance(plant_node, dict) else {}
                        plant_nbr_key = (
                            str(plant_props.get('plant')) or
                            str(plant_props.get('plant_nbr')) or
                            str(plant_props.get('id')) or
                            str(record.get('p_plant')) or
                            str(record.get('pnbr')) or
                            str(record.get('pid'))
                        )
                        if plant_nbr_key:
                            plants[plant_nbr_key] = plant_node

                for plant_nbr in plant_list:
                    if plant_nbr not in plants:
                        plants[plant_nbr] = {
                            'id': plant_nbr,
                            'labels': ['Plant'],
                            'properties': {
                                'plant_nbr': plant_nbr,
                                'id': plant_nbr,
                                'name': f'Plant {plant_nbr}'
                            }
                        }

            result = []
            for plant_nbr, svc_levels in grouped.items():
                if plant_nbr in plants:
                    result.append({
                        "plant": plants[plant_nbr],
                        "service_levels": svc_levels
                    })

            logger.info(f"Retrieved data for {len(result)} plants with service levels")
            return result
        except Exception as e:
            logger.error(f"Failed to get InboundServiceLevel data: {str(e)}")
            raise

    @staticmethod
    def get_material_substitutes_count(
        mat_nbr: str,
        material_formulary: Optional[str] = None,
        database: Optional[str] = None
    ) -> int:
        """
        Get total count of substitute materials for a given material (for pagination).

        Args:
            mat_nbr: Material number
            material_formulary: Optional parent_program to filter substitutes by formulary
            database: Optional Neo4j database name

        Returns:
            int: Total number of substitutes
        """
        if material_formulary:
            query = """
            MATCH (mat:Material {mat_nbr: $mat_nbr})-[:HAS_SUBSTITUTE_MATERIAL]->(n:MaterialSubstitute)
            WHERE n.substitute_material <> $mat_nbr
            WITH n
            MATCH (m:Material {mat_nbr: n.substitute_material})-[:HAS_FORMULARY]->(f:MaterialFormulary)
            WHERE f.parent_program = $material_formulary
            RETURN count(n) AS total
            """
            params = {'mat_nbr': mat_nbr, 'material_formulary': material_formulary}
        else:
            query = """
            MATCH (mat:Material {mat_nbr: $mat_nbr})-[:HAS_SUBSTITUTE_MATERIAL]->(n:MaterialSubstitute)
            WHERE n.substitute_material <> $mat_nbr
            RETURN count(n) as total
            """
            params = {'mat_nbr': mat_nbr}
        try:
            records = Neo4jQueryExecutor.execute_query(query, params, database=database)
            return int(records[0]['total']) if records else 0
        except Exception as e:
            logger.error(f"Failed to get material substitutes count for {mat_nbr}: {str(e)}")
            raise

    @staticmethod
    def get_material_substitutes(
        mat_nbr: str,
        limit: int = 10,
        offset: int = 0,
        material_formulary: Optional[str] = None,
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get substitute materials for a given material from Neo4j.

        Query matches graph developer spec. Raw values returned; formatting (e.g. $, %)
        is done on the frontend.

        Args:
            mat_nbr: Material number
            limit: Maximum number of substitutes to return (default: 10)
            offset: Number of substitutes to skip (for pagination)
            material_formulary: Optional parent_program to filter substitutes by formulary
            database: Optional Neo4j database name

        Returns:
            List[Dict[str, Any]]: List of substitute material dicts with raw fields:
                mat_nbr, sub_mat_nbr, name, dollars_at_risk, market_share,
                forecast_qty_7day, saleable_qty_on_hand, cost_per_unit, vendor_nbr,
                vendor_name, substitute_material_rank, material_formularies,
                available_plants_count

        Raises:
            Neo4jQueryError: If the Neo4j query execution fails
        """
        logger.info(
            f"Fetching substitute materials for mat_nbr: {mat_nbr} "
            f"(limit={limit}, offset={offset}, material_formulary={material_formulary})"
        )

        params = {
            'mat_nbr': mat_nbr,
            'limit': limit,
            'offset': offset
        }

        if material_formulary:
            params['material_formulary'] = material_formulary
            # Filter by formulary before ORDER BY / SKIP / LIMIT so pagination is correct
            query = """
            MATCH (mat:Material {mat_nbr: $mat_nbr})-[:HAS_SUBSTITUTE_MATERIAL]->(n:MaterialSubstitute)
            WHERE n.substitute_material <> $mat_nbr
            WITH mat, n
            MATCH (m:Material {mat_nbr: n.substitute_material})-[:HAS_FORMULARY]->(f:MaterialFormulary)
            WHERE f.parent_program = $material_formulary
            WITH mat, n ORDER BY n.substitute_material_rank
            SKIP $offset
            LIMIT $limit
            WITH n, mat.mat_nbr as mat_nbr
            MATCH (m:Material {mat_nbr: n.substitute_material})
            OPTIONAL MATCH (m)-[:HAS_VENDOR]->(v:Vendor)
            OPTIONAL MATCH (m)-[:HAS_FORMULARY]->(f:MaterialFormulary)
            OPTIONAL MATCH (m)-[:HAS_DEMAND_FORECAST]->(dAll:DemandForecast)
            WITH mat_nbr, m, n, v, f, max(dAll.demand_date) as latest_date
            OPTIONAL MATCH (m)-[:HAS_DEMAND_FORECAST]->(d:DemandForecast)
            WHERE d.demand_date = latest_date AND coalesce(d.saleable_qty_on_hand, 0) > 0
            WITH mat_nbr, m, n, v,
                 collect(distinct {mat_nbr: m.mat_nbr, parent_program: f.parent_program}) as material_formularies,
                 size([p IN collect(distinct d.plant_nbr) WHERE p IS NOT NULL]) as available_plants_count
            RETURN mat_nbr, n.substitute_material as sub_mat_nbr, m.name as name,
                   m.dollars_at_risk as dollars_at_risk,
                   m.market_share as market_share,
                   m.forecast_qty_7day as forecast_qty_7day,
                   m.saleable_qty_on_hand as saleable_qty_on_hand,
                   m.cost_per_unit as cost_per_unit,
                   m.vendor_nbr as vendor_nbr,
                   v.vendor_name as vendor_name,
                   n.substitute_material_rank as substitute_material_rank,
                   material_formularies,
                   available_plants_count
            ORDER BY n.substitute_material_rank
            """
        else:
            # Query from graph developer - raw values, no formatting
            # available_plants_count: absolute latest demand date per substitute, then
            # count plants with stock (Option A; matches
            # get_material_inventory_on_each_plant)
            query = """
            MATCH (mat:Material {mat_nbr: $mat_nbr})-[:HAS_SUBSTITUTE_MATERIAL]->(n:MaterialSubstitute)
            WHERE n.substitute_material <> $mat_nbr
            WITH mat, n ORDER BY n.substitute_material_rank
            SKIP $offset
            LIMIT $limit
            WITH n, mat.mat_nbr as mat_nbr
            MATCH (m:Material {mat_nbr: n.substitute_material})
            OPTIONAL MATCH (m)-[:HAS_VENDOR]->(v:Vendor)
            OPTIONAL MATCH (m)-[:HAS_FORMULARY]->(f:MaterialFormulary)
            OPTIONAL MATCH (m)-[:HAS_DEMAND_FORECAST]->(dAll:DemandForecast)
            WITH mat_nbr, m, n, v, f, max(dAll.demand_date) as latest_date
            OPTIONAL MATCH (m)-[:HAS_DEMAND_FORECAST]->(d:DemandForecast)
            WHERE d.demand_date = latest_date AND coalesce(d.saleable_qty_on_hand, 0) > 0
            WITH mat_nbr, m, n, v,
                 collect(distinct {mat_nbr: m.mat_nbr, parent_program: f.parent_program}) as material_formularies,
                 size([p IN collect(distinct d.plant_nbr) WHERE p IS NOT NULL]) as available_plants_count
            RETURN mat_nbr, n.substitute_material as sub_mat_nbr, m.name as name,
                   m.dollars_at_risk as dollars_at_risk,
                   m.market_share as market_share,
                   m.forecast_qty_7day as forecast_qty_7day,
                   m.saleable_qty_on_hand as saleable_qty_on_hand,
                   m.cost_per_unit as cost_per_unit,
                   m.vendor_nbr as vendor_nbr,
                   v.vendor_name as vendor_name,
                   n.substitute_material_rank as substitute_material_rank,
                   material_formularies,
                   available_plants_count
            ORDER BY n.substitute_material_rank
            """

        try:
            records = Neo4jQueryExecutor.execute_query(query, params, database=database)

            if not records:
                logger.info(f"No substitute materials found for mat_nbr: {mat_nbr}")
                return []

            result = []
            for record in records:
                result.append({
                    'mat_nbr': record.get('mat_nbr'),
                    'sub_mat_nbr': record.get('sub_mat_nbr'),
                    'name': record.get('name'),
                    'dollars_at_risk': record.get('dollars_at_risk'),
                    'market_share': record.get('market_share'),
                    'forecast_qty_7day': record.get('forecast_qty_7day'),
                    'saleable_qty_on_hand': record.get('saleable_qty_on_hand'),
                    'cost_per_unit': record.get('cost_per_unit'),
                    'vendor_nbr': record.get('vendor_nbr'),
                    'vendor_name': record.get('vendor_name'),
                    'substitute_material_rank': record.get('substitute_material_rank'),
                    'material_formularies': record.get('material_formularies') or [],
                    'available_plants_count': record.get('available_plants_count') or 0,
                })

            logger.info(f"Found {len(result)} substitute materials for mat_nbr: {mat_nbr}")
            return result
        except Exception as e:
            logger.error(f"Failed to get material substitutes for {mat_nbr}: {str(e)}")
            raise

    @staticmethod
    def get_material_inventory_on_each_plant(
        mat_nbr: str,
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get inventory of a specific material across all plants from Neo4j.
        Only returns plants where saleable_qty_on_hand > 0 (i.e. where stock is available).

        Args:
            mat_nbr: Material number
            database: Optional Neo4j database name

        Returns:
            List[Dict[str, Any]]: List of inventory records per plant (with stock) with:
                - plant: Plant node dictionary from Neo4j
                - demand_date: Latest demand date
                - saleable_qty_on_hand: Saleable quantity on hand
                - Other DemandForecast properties

        Raises:
            Neo4jQueryError: If the Neo4j query execution fails
        """
        logger.info(f"Fetching inventory for material {mat_nbr} across all plants")

        # First, get the latest demand_date for this material
        latest_date_query = """
        MATCH (m:Material {mat_nbr: $mat_nbr})-[:HAS_DEMAND_FORECAST]->(d:DemandForecast)
        RETURN max(d.demand_date) as latest_date
        """

        try:
            date_records = Neo4jQueryExecutor.execute_query(
                latest_date_query,
                {'mat_nbr': mat_nbr},
                database=database
            )

            if not date_records or not date_records[0].get('latest_date'):
                logger.info(f"No demand forecast data found for mat_nbr: {mat_nbr}")
                return []

            latest_date = date_records[0]['latest_date']

            # Now get inventory data for the latest date (only plants with stock)
            inventory_query = """
            MATCH (m:Material {mat_nbr: $mat_nbr})-[:HAS_DEMAND_FORECAST]->(d:DemandForecast)
            WHERE d.demand_date = $latest_date
              AND coalesce(d.saleable_qty_on_hand, 0) > 0
            OPTIONAL MATCH (d)-[:AT_PLANT]->(p:Plant)
            RETURN d, p, d.demand_date as demand_date,
                   d.saleable_qty_on_hand as saleable_qty_on_hand,
                   d.unrestricted_qty_on_hand as unrestricted_qty_on_hand,
                   d.forecast_qty_7day as forecast_qty_7day,
                   d.qty_ordered as qty_ordered,
                   d.shipped_qty as shipped_qty,
                   d.received_qty as received_qty,
                   d.on_order_qty as on_order_qty,
                   d.transfer_in_qty as transfer_in_qty,
                   d.transfer_out_qty as transfer_out_qty,
                   d.plant_nbr as plant_nbr
            ORDER BY d.plant_nbr
            """

            params = {
                'mat_nbr': mat_nbr,
                'latest_date': latest_date
            }

            records = Neo4jQueryExecutor.execute_query(inventory_query, params, database=database)

            if not records:
                logger.info(f"No inventory data found for mat_nbr: {mat_nbr} on date: {latest_date}")
                return []

            # Get plant nodes for the plant_nbrs found
            plant_nbrs = set()
            for record in records:
                plant_nbr = record.get('plant_nbr')
                if plant_nbr:
                    plant_nbrs.add(plant_nbr)

            plants = {}
            if plant_nbrs:
                plant_list = list(plant_nbrs)
                plant_query = """
                MATCH (p:Plant)
                WHERE p.plant IN $plant_nbrs
                   OR p.plant_nbr IN $plant_nbrs
                   OR p.id IN $plant_nbrs
                RETURN p, p.plant as p_plant, p.plant_nbr as pnbr, p.id as pid
                ORDER BY p.plant
                """
                plant_records = Neo4jQueryExecutor.execute_query(
                    plant_query,
                    {'plant_nbrs': plant_list},
                    database=database
                )

                for record in plant_records:
                    plant_node = record.get('p', {})
                    plant_props = plant_node.get('properties', {}) if isinstance(plant_node, dict) else {}
                    plant_nbr_key = (
                        str(plant_props.get('plant')) or
                        str(plant_props.get('plant_nbr')) or
                        str(plant_props.get('id')) or
                        str(record.get('p_plant')) or
                        str(record.get('pnbr')) or
                        str(record.get('pid'))
                    )
                    if plant_nbr_key:
                        plants[plant_nbr_key] = plant_node

                # Create synthetic plants for any missing ones
                for plant_nbr in plant_list:
                    if plant_nbr not in plants:
                        plants[plant_nbr] = {
                            'id': plant_nbr,
                            'labels': ['Plant'],
                            'properties': {
                                'plant_nbr': plant_nbr,
                                'id': plant_nbr,
                                'name': f'Plant {plant_nbr}'
                            }
                        }

            # Build result list
            result = []
            for record in records:
                plant_nbr = record.get('plant_nbr')
                plant = plants.get(str(plant_nbr)) if plant_nbr else None

                if not plant:
                    # Skip records without plant_nbr or if plant not found
                    continue

                # Extract DemandForecast properties from record
                result.append({
                    'plant': plant,
                    'demand_date': record.get('demand_date'),
                    'saleable_qty_on_hand': record.get('saleable_qty_on_hand') or 0,
                    'unrestricted_qty_on_hand': record.get('unrestricted_qty_on_hand') or 0,
                    'forecast_qty_7day': record.get('forecast_qty_7day') or 0,
                    'qty_ordered': record.get('qty_ordered') or 0,
                    'shipped_qty': record.get('shipped_qty') or 0,
                    'received_qty': record.get('received_qty') or 0,
                    'on_order_qty': record.get('on_order_qty') or 0,
                    'transfer_in_qty': record.get('transfer_in_qty') or 0,
                    'transfer_out_qty': record.get('transfer_out_qty') or 0,
                    'plant_nbr': plant_nbr
                })

            logger.info(f"Found inventory data for {len(result)} plants for mat_nbr: {mat_nbr}")
            return result
        except Exception as e:
            logger.error(f"Failed to get material inventory for {mat_nbr}: {str(e)}")
            raise
