from django.apps import AppConfig


class Neo4jGraphApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.neo4j_graph_api'
    verbose_name = 'Neo4j Graph API'
