"""
Custom exceptions for Neo4j Graph API operations.
"""


class Neo4jGraphAPIError(Exception):
    """Base exception for all Neo4j Graph API errors."""
    pass


class Neo4jConnectionError(Neo4jGraphAPIError):
    """Raised when there are issues connecting to Neo4j database."""
    pass


class Neo4jQueryError(Neo4jGraphAPIError):
    """Raised when a Cypher query execution fails."""
    pass


class Neo4jNodeNotFoundError(Neo4jGraphAPIError):
    """Raised when a requested node is not found in the graph."""
    pass


class Neo4jRelationshipNotFoundError(Neo4jGraphAPIError):
    """Raised when a requested relationship is not found in the graph."""
    pass
