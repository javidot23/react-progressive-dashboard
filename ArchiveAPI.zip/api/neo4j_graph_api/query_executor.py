"""Low-level Neo4j query execution layer."""
import logging
from typing import Any, Dict, List, Optional

from .connection import Neo4jConnection
from .exceptions import Neo4jQueryError

logger = logging.getLogger(__name__)


class Neo4jQueryExecutor:
    """Low-level query executor for Neo4j operations."""

    @staticmethod
    def _convert_node(node) -> Dict[str, Any]:
        """
        Convert a Neo4j node to a Python dictionary.

        Args:
            node: Neo4j node object

        Returns:
            dict: Dictionary with 'id', 'labels', and 'properties' keys
        """
        return {
            'id': node.id,
            'labels': list(node.labels),
            'properties': dict(node.items())
        }

    @staticmethod
    def _convert_relationship(rel) -> Dict[str, Any]:
        """
        Convert a Neo4j relationship to a Python dictionary.

        Args:
            rel: Neo4j relationship object

        Returns:
            dict: Dictionary with relationship type and properties
        """
        return {
            'id': rel.id,
            'type': rel.type,
            'start_node_id': rel.start_node.id,
            'end_node_id': rel.end_node.id,
            'properties': dict(rel.items())
        }

    @staticmethod
    def _convert_record(record) -> Dict[str, Any]:
        """
        Convert a Neo4j record to a Python dictionary.

        Args:
            record: Neo4j record object

        Returns:
            dict: Dictionary with record keys and converted values
        """
        result = {}
        for key, value in record.items():
            if hasattr(value, 'id'):
                if hasattr(value, 'labels'):
                    result[key] = Neo4jQueryExecutor._convert_node(value)
                elif hasattr(value, 'type'):
                    result[key] = Neo4jQueryExecutor._convert_relationship(value)
                else:
                    result[key] = value
            elif isinstance(value, list):
                result[key] = [
                    Neo4jQueryExecutor._convert_node(item) if hasattr(item, 'labels')
                    else Neo4jQueryExecutor._convert_relationship(item) if hasattr(item, 'type')
                    else item
                    for item in value
                ]
            else:
                result[key] = value
        return result

    @classmethod
    def execute_query(
        cls,
        cypher_query: str,
        parameters: Optional[Dict[str, Any]] = None,
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute a generic Cypher query and return results as Python dictionaries.

        Args:
            cypher_query: Cypher query string (use $param_name for parameters)
            parameters: Dictionary of parameters for the query
            database: Optional database name (defaults to settings.NEO4J_DATABASE)

        Returns:
            List[Dict[str, Any]]: List of result records as dictionaries

        Raises:
            Neo4jQueryError: If query execution fails
        """
        parameters = parameters or {}
        session = None

        try:
            logger.debug(f"Executing Cypher query: {cypher_query[:100]}...")
            session = Neo4jConnection.get_session(database=database)
            result = session.run(cypher_query, parameters)
            records = [cls._convert_record(record) for record in result]
            logger.debug(f"Query returned {len(records)} records")
            return records
        except Exception as e:
            logger.error(f"Query execution failed: {str(e)}")
            raise Neo4jQueryError(f"Failed to execute query: {str(e)}") from e
        finally:
            if session:
                session.close()

    @classmethod
    def execute_read_transaction(
        cls,
        query: str,
        parameters: Optional[Dict[str, Any]] = None,
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute a read transaction.

        Args:
            query: Cypher query string
            parameters: Dictionary of parameters for the query
            database: Optional database name

        Returns:
            List[Dict[str, Any]]: List of result records as dictionaries

        Raises:
            Neo4jQueryError: If transaction execution fails
        """
        parameters = parameters or {}
        session = None

        try:
            logger.debug(f"Executing read transaction: {query[:100]}...")
            session = Neo4jConnection.get_session(database=database)

            def work(tx):
                result = tx.run(query, parameters)
                return [cls._convert_record(record) for record in result]

            records = session.execute_read(work)
            logger.debug(f"Transaction returned {len(records)} records")
            return records
        except Exception as e:
            logger.error(f"Transaction execution failed: {str(e)}")
            raise Neo4jQueryError(f"Failed to execute transaction: {str(e)}") from e
        finally:
            if session:
                session.close()

    @classmethod
    def get_node_by_id(
        cls,
        node_id: int,
        label: Optional[str] = None,
        database: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch a single node by its internal ID.

        Args:
            node_id: Internal Neo4j node ID
            label: Optional label to filter by
            database: Optional database name

        Returns:
            Optional[Dict[str, Any]]: Node as dictionary, or None if not found

        Raises:
            Neo4jQueryError: If query execution fails
        """
        if label:
            query = "MATCH (n:" + label + ") WHERE id(n) = $node_id RETURN n"
        else:
            query = "MATCH (n) WHERE id(n) = $node_id RETURN n"

        try:
            records = cls.execute_query(query, {'node_id': node_id}, database=database)
            if records and 'n' in records[0]:
                return records[0]['n']
            return None
        except Exception as e:
            logger.error(f"Failed to get node by ID {node_id}: {str(e)}")
            raise Neo4jQueryError(f"Failed to get node: {str(e)}") from e

    @classmethod
    def get_nodes_by_label(
        cls,
        label: str,
        limit: Optional[int] = None,
        skip: Optional[int] = None,
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Fetch nodes by label with optional pagination.

        Args:
            label: Node label to filter by
            limit: Maximum number of nodes to return
            skip: Number of nodes to skip
            database: Optional database name

        Returns:
            List[Dict[str, Any]]: List of nodes as dictionaries

        Raises:
            Neo4jQueryError: If query execution fails
        """
        query = f"MATCH (n:{label}) RETURN n"

        if skip:
            query += f" SKIP {skip}"
        if limit:
            query += f" LIMIT {limit}"

        try:
            records = cls.execute_query(query, database=database)
            return [record['n'] for record in records if 'n' in record]
        except Exception as e:
            logger.error(f"Failed to get nodes by label {label}: {str(e)}")
            raise Neo4jQueryError(f"Failed to get nodes: {str(e)}") from e

    @classmethod
    def get_relationships(
        cls,
        start_node_id: int,
        relationship_type: Optional[str] = None,
        direction: str = 'outgoing',
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get relationships for a node.

        Args:
            start_node_id: Internal ID of the start node
            relationship_type: Optional relationship type to filter by
            direction: 'outgoing', 'incoming', or 'both'
            database: Optional database name

        Returns:
            List[Dict[str, Any]]: List of relationships as dictionaries

        Raises:
            Neo4jQueryError: If query execution fails
        """
        if direction == 'outgoing':
            rel_type = f":{relationship_type}" if relationship_type else ""
            rel_pattern = f"-[r{rel_type}]->"
        elif direction == 'incoming':
            rel_type = f":{relationship_type}" if relationship_type else ""
            rel_pattern = f"<-[r{rel_type}]-"
        else:
            rel_type = f":{relationship_type}" if relationship_type else ""
            rel_pattern = f"-[r{rel_type}]-"

        query = f"MATCH (n)-{rel_pattern}(m) WHERE id(n) = $node_id RETURN r, m"

        try:
            records = cls.execute_query(query, {'node_id': start_node_id}, database=database)
            return [
                {
                    'relationship': record.get('r'),
                    'related_node': record.get('m')
                }
                for record in records
            ]
        except Exception as e:
            logger.error(f"Failed to get relationships for node {start_node_id}: {str(e)}")
            raise Neo4jQueryError(f"Failed to get relationships: {str(e)}") from e

    @classmethod
    def find_path(
        cls,
        start_id: int,
        end_id: int,
        max_depth: int = 5,
        relationship_type: Optional[str] = None,
        database: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Find shortest path between two nodes.

        Args:
            start_id: Internal ID of the start node
            end_id: Internal ID of the end node
            max_depth: Maximum path depth to search
            relationship_type: Optional relationship type to filter by
            database: Optional database name

        Returns:
            List[Dict[str, Any]]: List of paths (each path contains nodes and relationships)

        Raises:
            Neo4jQueryError: If query execution fails
        """
        rel_filter = f":{relationship_type}" if relationship_type else ""
        query = f"""
        MATCH path = shortestPath((start)-[*1..{max_depth}{rel_filter}]-(end))
        WHERE id(start) = $start_id AND id(end) = $end_id
        RETURN path
        LIMIT 1
        """

        try:
            records = cls.execute_query(
                query,
                {'start_id': start_id, 'end_id': end_id},
                database=database
            )

            if not records:
                return []

            path = records[0].get('path', {})
            result = []

            if hasattr(path, 'nodes') and hasattr(path, 'relationships'):
                nodes = [cls._convert_node(node) for node in path.nodes()]
                relationships = [
                    cls._convert_relationship(rel) if rel else None
                    for rel in path.relationships()
                ]
                result = {
                    'nodes': nodes,
                    'relationships': relationships,
                    'length': len(relationships)
                }

            return [result] if result else []
        except Exception as e:
            logger.error(f"Failed to find path between {start_id} and {end_id}: {str(e)}")
            raise Neo4jQueryError(f"Failed to find path: {str(e)}") from e
