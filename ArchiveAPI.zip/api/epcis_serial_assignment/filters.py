from django_filters.rest_framework import FilterSet, filters

from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV


class OnOrderNoEpcisLineFilter(FilterSet):
    """
    Post-annotation filters for on-order no-EPCIS PO lines.
    Field names match the serializer; numeric ranges use _min/_max.
    """

    po_number = filters.CharFilter(field_name="po_number", lookup_expr="icontains")
    po_line_number = filters.CharFilter(field_name="po_line_number", lookup_expr="iexact")
    material = filters.CharFilter(field_name="material", lookup_expr="iexact")
    material_description = filters.CharFilter(field_name="material_description", lookup_expr="icontains")
    ndc = filters.CharFilter(field_name="ndc", lookup_expr="icontains")
    supplier = filters.CharFilter(field_name="supplier", lookup_expr="icontains")
    dqsa_exempt_flg = filters.CharFilter(field_name="dqsa_exempt_flg", lookup_expr="iexact")
    xplant_mat_stat = filters.CharFilter(field_name="xplant_mat_stat", lookup_expr="iexact")
    plant = filters.CharFilter(field_name="plant", lookup_expr="iexact")

    ordered_date_min = filters.DateFilter(field_name="ordered_date", lookup_expr="gte")
    ordered_date_max = filters.DateFilter(field_name="ordered_date", lookup_expr="lte")
    anticipated_date_min = filters.DateFilter(field_name="anticipated_date", lookup_expr="gte")
    anticipated_date_max = filters.DateFilter(field_name="anticipated_date", lookup_expr="lte")

    expected_delivery_days_min = filters.NumberFilter(field_name="days_to_delivery", lookup_expr="gte")
    expected_delivery_days_max = filters.NumberFilter(field_name="days_to_delivery", lookup_expr="lte")
    original_order_qty_min = filters.NumberFilter(field_name="original_order_qty", lookup_expr="gte")
    original_order_qty_max = filters.NumberFilter(field_name="original_order_qty", lookup_expr="lte")
    received_qty_min = filters.NumberFilter(field_name="received_qty", lookup_expr="gte")
    received_qty_max = filters.NumberFilter(field_name="received_qty", lookup_expr="lte")
    epcis_serial_count_min = filters.NumberFilter(field_name="epcis_serial_count", lookup_expr="gte")
    epcis_serial_count_max = filters.NumberFilter(field_name="epcis_serial_count", lookup_expr="lte")
    outstanding_qty_no_epcis_min = filters.NumberFilter(
        field_name="outstanding_qty_no_epcis", lookup_expr="gte"
    )
    outstanding_qty_no_epcis_max = filters.NumberFilter(
        field_name="outstanding_qty_no_epcis", lookup_expr="lte"
    )
    outstanding_amt_no_epcis_min = filters.NumberFilter(
        field_name="outstanding_amt_no_epcis", lookup_expr="gte"
    )
    outstanding_amt_no_epcis_max = filters.NumberFilter(
        field_name="outstanding_amt_no_epcis", lookup_expr="lte"
    )
    inbound_fill_rate_min = filters.NumberFilter(field_name="inbound_fill_rate", lookup_expr="gte")
    inbound_fill_rate_max = filters.NumberFilter(field_name="inbound_fill_rate", lookup_expr="lte")
    epcis_record_present = filters.BooleanFilter(field_name="epcis_record_present")

    class Meta:
        model = PurchaseOrderLatest90dMV
        fields = []
