from django.apps import AppConfig


class EpcisSerialAssignmentConfig(AppConfig):
    name = 'api.epcis_serial_assignment'
