from django.urls import path

from .views import OnOrderByDaysRangeView, OnOrderNoEpcisKpisView, OnOrderNoEpcisLineView, OnOrderNoEpcisLineExportView

app_name = "epcis_serial_assignment"

urlpatterns = [
    path("on-order-by-days-range/", OnOrderByDaysRangeView.as_view(), name="on-order-by-days-range"),
    path("on-order-no-epcis-kpis/", OnOrderNoEpcisKpisView.as_view(), name="on-order-no-epcis-kpis"),
    path("on-order-no-epcis-lines/export/", OnOrderNoEpcisLineExportView.as_view(),
         name="on-order-no-epcis-lines-export"),
    path("on-order-no-epcis-lines/", OnOrderNoEpcisLineView.as_view(), name="on-order-no-epcis-lines"),
]
