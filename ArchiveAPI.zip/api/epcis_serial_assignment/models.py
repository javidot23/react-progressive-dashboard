from django.db import models

from api.material.models import Material
from api.plant.models import Plant


class EpcisSerialAssignment(models.Model):
    po_material_index = models.CharField(max_length=255, db_column="po_material_index")
    doc_nbr = models.CharField(max_length=255, null=True, blank=True, db_column="doc_nbr")
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    doc_date = models.DateField(
        null=True,
        blank=True,
        db_column="doc_date"
    )
    anticipated_deliv_date = models.DateField(
        null=True,
        blank=True,
        db_column="anticipated_deliv_date"
    )
    order_quantity = models.DecimalField(
        max_digits=10,
        decimal_places=3,
        null=True,
        blank=True,
        db_column="order_quantity"
    )
    epcis_serial_count = models.IntegerField(
        null=True,
        blank=True,
        db_column="epcis_serial_count"
    )
    epcis_flag = models.CharField(
        max_length=50,
        null=True,
        blank=True,
        db_column="epcis_flag"
    )
    order_status_flag_po = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="order_status_flag_po"
    )
    epcis_po_nbr_gtin_uom_q1 = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="epcis_po_nbr_gtin_uom_q1"
    )
    completed_delivery_flg = models.IntegerField(
        null=True,
        blank=True,
        db_column="completed_delivery_flg"
    )
    delivery_status = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="delivery_status"
    )
    min_goods_receipt_date = models.DateField(
        null=True,
        blank=True,
        db_column="min_goods_receipt_date"
    )
    max_goods_receipt_date = models.DateField(
        null=True,
        blank=True,
        db_column="max_goods_receipt_date"
    )
    asn_nbr = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_column="asn_nbr"
    )
    created_date = models.DateField(
        null=True,
        blank=True,
        db_column="created_date"
    )
    created_at = models.DateTimeField(
        auto_now_add=True
    )
    updated_at = models.DateTimeField(
        auto_now=True)
    net_po_value = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        null=True,
        blank=True,
        db_column="net_po_value"
    )

    class Meta:
        db_table = "epcis_serial_assignments"
        verbose_name = "EPCIS Serial Assignment"
        verbose_name_plural = "EPCIS Serial Assignments"
        unique_together = ["po_material_index", "plant"]
        indexes = [
            models.Index(fields=["doc_nbr"]),
            models.Index(fields=["material"]),
            models.Index(fields=["doc_nbr", "material"]),
            models.Index(fields=["anticipated_deliv_date"]),
            models.Index(fields=["plant"]),
        ]
