import logging

from django.db.models import (
    Case, CharField, DecimalField, Exists, F, FloatField, IntegerField, OuterRef, Subquery, Sum,
    Value, When,
)
from django.db.models.expressions import RawSQL
from django.db.models.functions import Cast, Coalesce, Greatest, Least

from api.epcis_serial_assignment.models import EpcisSerialAssignment
from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV

logger = logging.getLogger(__name__)


class EpcisSerialAssignmentService:

    # Days-to-due-date bucket labels, in order. Source of truth for the days_range
    # Case annotation below and for validating the days_range filter on the line endpoint.
    DAYS_RANGE_BUCKETS = ["Overdue", "0-1", "2-3", "4-5", "6-7", "8+"]

    # Open PO lines more than this many days past anticipated_date are excluded from
    # both on-order endpoints — they are treated as non-actionable for EPCIS risk.
    OVERDUE_LOOKBACK_DAYS = 30

    @staticmethod
    def _annotate_days_to_delivery_and_range(qs):
        """
        Assign days_range from live days until anticipated_date.

        Uses (anticipated_date - CURRENT_DATE) so buckets stay current between ETL
        runs. Falls back to the snapshot expected_delivery_days when anticipated_date
        is null.
        """
        live_days = RawSQL(
            "(anticipated_date - CURRENT_DATE)",
            [],
            output_field=IntegerField(),
        )
        days_to_delivery = Coalesce(
            live_days,
            F("expected_delivery_days"),
            output_field=IntegerField(),
        )
        return qs.annotate(
            days_to_delivery=days_to_delivery,
            days_range=Case(
                When(days_to_delivery__lt=0, then=Value("Overdue")),
                When(days_to_delivery__lt=2, then=Value("0-1")),
                When(days_to_delivery__lt=4, then=Value("2-3")),
                When(days_to_delivery__lt=6, then=Value("4-5")),
                When(days_to_delivery__lt=8, then=Value("6-7")),
                default=Value("8+"),
                output_field=CharField(),
            ),
        )

    @staticmethod
    def _apply_overdue_lookback(qs):
        """Drop lines whose due date is more than OVERDUE_LOOKBACK_DAYS in the past."""
        return qs.filter(days_to_delivery__gte=-EpcisSerialAssignmentService.OVERDUE_LOOKBACK_DAYS)

    @staticmethod
    def get_on_order_by_days_range(direct_mat_nbr: str = None, mat_nbr_subquery=None, plant_nbr: str = None):
        """
        Returns on-order unit quantities grouped by material, plant, and days-to-due-date
        range, split between lines with and without EPCIS serial coverage.

        Joins the latest open PO snapshot (PurchaseOrderLatest90dMV) to
        EpcisSerialAssignment on (mat_nbr, po_number) via correlated subqueries,
        and applies the same outstanding-quantity logic as the data team's reference query.

        Scope matches the other EPCIS coverage endpoints: serialization-required
        materials only (dqsa_exempt_flg N/W), excluding discontinued (DB/DM) materials.
        Permanently exempt materials never carry serials and would otherwise inflate the
        no-EPCIS split. See get_on_order_no_epcis_lines for the line-level drill-down.
        """

        epcis_count_sq = (
            EpcisSerialAssignment.objects
            .filter(material=OuterRef("material"), doc_nbr=OuterRef("po_number"))
            .values("material", "doc_nbr")
            .annotate(total=Sum("epcis_serial_count"))
            .values("total")
        )

        epcis_order_qty_sq = (
            EpcisSerialAssignment.objects
            .filter(material=OuterRef("material"), doc_nbr=OuterRef("po_number"))
            .values("material", "doc_nbr")
            .annotate(total=Sum("order_quantity"))
            .values("total")
        )

        epcis_net_po_value_sq = (
            EpcisSerialAssignment.objects
            .filter(material=OuterRef("material"), doc_nbr=OuterRef("po_number"))
            .values("material", "doc_nbr")
            .annotate(total=Sum("net_po_value"))
            .values("total")
        )

        qs = (
            PurchaseOrderLatest90dMV.objects
            .filter(
                completion_date__isnull=True,
                material__dqsa_exempt_flg__in=["N", "W"],
            )
            .exclude(material__xplant_mat_stat__in=["DB", "DM"])
            .exclude(del_ind_flag=True)
            .exclude(delv_complt_no_receipt_flag=True)
            .exclude(br_no_receipt_flag=True)
            .annotate(
                epcis_count=Coalesce(
                    Subquery(epcis_count_sq, output_field=IntegerField()),
                    Value(0),
                ),
                epcis_order_qty=Subquery(epcis_order_qty_sq),
                epcis_net_po_value=Coalesce(
                    Subquery(epcis_net_po_value_sq, output_field=DecimalField(max_digits=15, decimal_places=2)),
                    Value(0),
                    output_field=DecimalField(max_digits=15, decimal_places=2),
                ),
            )
        )
        qs = EpcisSerialAssignmentService._annotate_days_to_delivery_and_range(qs)
        qs = EpcisSerialAssignmentService._apply_overdue_lookback(qs)

        if direct_mat_nbr:
            qs = qs.filter(material=direct_mat_nbr)
        elif mat_nbr_subquery is not None:
            qs = qs.filter(material__in=mat_nbr_subquery)

        if plant_nbr:
            qs = qs.filter(plant=plant_nbr)

        # Compute outstanding quantities per PO row before aggregating.
        # Doing this math after summing across POs is incorrect — a large
        # received_qty from one PO would zero out epcis_count from another.
        zero = Value(0, output_field=IntegerField())
        zero_dec = Value(0, output_field=DecimalField(max_digits=15, decimal_places=2))
        qs = qs.annotate(
            row_outstanding=Greatest(
                zero,
                F("original_order_qty") - F("received_qty"),
                output_field=IntegerField(),
            ),
            row_outstanding_with_epcis=Least(
                Greatest(zero, F("original_order_qty") - F("received_qty")),
                Greatest(zero, F("epcis_count") - F("received_qty")),
                output_field=IntegerField(),
            ),
            row_outstanding_no_epcis=Greatest(
                zero,
                F("original_order_qty") - Greatest(F("received_qty"), F("epcis_count")),
                output_field=IntegerField(),
            ),
        )

        # Dollar amounts: unit_price = net_po_value / original_order_qty,
        # applied proportionally to each outstanding qty split.
        qs = qs.annotate(
            row_outstanding_amt=Case(
                When(original_order_qty__gt=0,
                     then=F("epcis_net_po_value") * F("row_outstanding") / F("original_order_qty")),
                default=zero_dec,
                output_field=DecimalField(max_digits=15, decimal_places=2),
            ),
            row_outstanding_amt_with_epcis=Case(
                When(original_order_qty__gt=0,
                     then=F("epcis_net_po_value") * F("row_outstanding_with_epcis") / F("original_order_qty")),
                default=zero_dec,
                output_field=DecimalField(max_digits=15, decimal_places=2),
            ),
            row_outstanding_amt_no_epcis=Case(
                When(original_order_qty__gt=0,
                     then=F("epcis_net_po_value") * F("row_outstanding_no_epcis") / F("original_order_qty")),
                default=zero_dec,
                output_field=DecimalField(max_digits=15, decimal_places=2),
            ),
        )

        rows = (
            qs.values("days_range")
            .annotate(
                original_qty=Sum("original_order_qty"),
                received_qty=Sum("received_qty"),
                epcis_count=Sum("epcis_count"),
                epcis_order_qty=Sum("epcis_order_qty"),
                epcis_net_po_value=Sum("epcis_net_po_value"),
                outstanding_qty=Sum("row_outstanding"),
                outstanding_qty_with_epcis=Sum("row_outstanding_with_epcis"),
                outstanding_qty_no_epcis=Sum("row_outstanding_no_epcis"),
                outstanding_amt=Sum("row_outstanding_amt"),
                outstanding_amt_with_epcis=Sum("row_outstanding_amt_with_epcis"),
                outstanding_amt_no_epcis=Sum("row_outstanding_amt_no_epcis"),
            )
            .order_by("days_range")
        )

        logger.info("Fetching on-order EPCIS data by days range")

        return [
            {
                "days_range": row["days_range"],
                "original_qty": row["original_qty"] or 0,
                "received_qty": row["received_qty"] or 0,
                "epcis_count": row["epcis_count"] or 0,
                "epcis_order_qty": row["epcis_order_qty"],
                "epcis_net_po_value": row["epcis_net_po_value"],
                "outstanding_qty": row["outstanding_qty"] or 0,
                "outstanding_qty_with_epcis": row["outstanding_qty_with_epcis"] or 0,
                "outstanding_qty_no_epcis": row["outstanding_qty_no_epcis"] or 0,
                "outstanding_amt": row["outstanding_amt"] or 0,
                "outstanding_amt_with_epcis": row["outstanding_amt_with_epcis"] or 0,
                "outstanding_amt_no_epcis": row["outstanding_amt_no_epcis"] or 0,
            }
            for row in rows
        ]

    @staticmethod
    def get_on_order_no_epcis_kpis(direct_mat_nbr: str = None, mat_nbr_subquery=None, plant_nbr: str = None):
        """
        Current outstanding qty/amt without EPCIS — same universe and math as summing
        outstanding_*_no_epcis across get_on_order_by_days_range buckets.
        """
        rows = EpcisSerialAssignmentService.get_on_order_by_days_range(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            plant_nbr=plant_nbr,
        )
        logger.info("Aggregating on-order no-EPCIS KPI totals across %d day-range buckets", len(rows))
        return {
            "outstanding_qty_no_epcis": sum(row["outstanding_qty_no_epcis"] for row in rows),
            "outstanding_amt_no_epcis": sum(
                (row["outstanding_amt_no_epcis"] or 0) for row in rows
            ),
        }

    @staticmethod
    def get_on_order_no_epcis_lines(
        direct_mat_nbr: str = None, mat_nbr_subquery=None, plant_nbr: str = None, days_range: str = None,
    ):
        """
        Drill-down companion to get_on_order_by_days_range: returns the individual
        open PO lines that contribute to outstanding_qty_no_epcis, so the data can
        be validated and made actionable for suppliers.

        Pass days_range (one of DAYS_RANGE_BUCKETS) to restrict to a single bucket —
        e.g. the lines behind the "2-3" bar in the chart.

        Returns a lazy `.values()` queryset (one dict per PO line, keyed to match
        OnOrderNoEpcisLineSerializer) ordered by ordered_date descending, so the
        view can apply MaxLimitOffsetPagination and slice at the DB level.
        """
        epcis_count_sq = (
            EpcisSerialAssignment.objects
            .filter(material=OuterRef("material"), doc_nbr=OuterRef("po_number"))
            .values("material", "doc_nbr")
            .annotate(total=Sum("epcis_serial_count"))
            .values("total")
        )

        epcis_net_po_value_sq = (
            EpcisSerialAssignment.objects
            .filter(material=OuterRef("material"), doc_nbr=OuterRef("po_number"))
            .values("material", "doc_nbr")
            .annotate(total=Sum("net_po_value"))
            .values("total")
        )

        epcis_exists_sq = EpcisSerialAssignment.objects.filter(
            material=OuterRef("material"), doc_nbr=OuterRef("po_number")
        )

        zero = Value(0, output_field=IntegerField())
        zero_dec = Value(0, output_field=DecimalField(max_digits=15, decimal_places=2))

        qs = (
            PurchaseOrderLatest90dMV.objects
            .filter(
                completion_date__isnull=True,
                material__dqsa_exempt_flg__in=["N", "W"],
            )
            .exclude(material__xplant_mat_stat__in=["DB", "DM"])
            .exclude(del_ind_flag=True)
            .exclude(delv_complt_no_receipt_flag=True)
            .exclude(br_no_receipt_flag=True)
            .annotate(
                epcis_count=Coalesce(
                    Subquery(epcis_count_sq, output_field=IntegerField()),
                    Value(0),
                ),
                epcis_net_po_value=Coalesce(
                    Subquery(epcis_net_po_value_sq, output_field=DecimalField(max_digits=15, decimal_places=2)),
                    Value(0),
                    output_field=DecimalField(max_digits=15, decimal_places=2),
                ),
                epcis_record_present=Exists(epcis_exists_sq),
            )
        )
        qs = EpcisSerialAssignmentService._annotate_days_to_delivery_and_range(qs)
        qs = EpcisSerialAssignmentService._apply_overdue_lookback(qs)

        if direct_mat_nbr:
            qs = qs.filter(material=direct_mat_nbr)
        elif mat_nbr_subquery is not None:
            qs = qs.filter(material__in=mat_nbr_subquery)

        if plant_nbr:
            qs = qs.filter(plant=plant_nbr)

        if days_range:
            qs = qs.filter(days_range=days_range)

        qs = qs.annotate(
            outstanding_qty_no_epcis=Greatest(
                zero,
                F("original_order_qty") - Greatest(F("received_qty"), F("epcis_count")),
                output_field=IntegerField(),
            ),
        ).annotate(
            outstanding_amt_no_epcis=Case(
                When(original_order_qty__gt=0,
                     then=F("epcis_net_po_value") * F("outstanding_qty_no_epcis") / F("original_order_qty")),
                default=zero_dec,
                output_field=DecimalField(max_digits=15, decimal_places=2),
            ),
            inbound_fill_rate=Case(
                When(
                    original_order_qty__gt=0,
                    then=Cast(F("received_qty"), FloatField())
                    / Cast(F("original_order_qty"), FloatField()),
                ),
                default=Value(0.0),
                output_field=FloatField(),
            ),
        ).filter(outstanding_qty_no_epcis__gt=0)

        logger.info("Fetching on-order EPCIS no-coverage line detail")

        return qs.values(
            "po_number",
            "po_line_number",
            "material",
            "plant",
            "ordered_date",
            "anticipated_date",
            "days_range",
            "epcis_record_present",
            "outstanding_qty_no_epcis",
            "outstanding_amt_no_epcis",
            "inbound_fill_rate",
            "original_order_qty",
            "received_qty",
            "days_to_delivery",
            material_description=F("material__name"),
            ndc=F("material__ndc"),
            supplier=F("material__vendor__name"),
            dqsa_exempt_flg=F("material__dqsa_exempt_flg"),
            xplant_mat_stat=F("material__xplant_mat_stat"),
            epcis_serial_count=Coalesce(F("epcis_count"), zero),
        ).order_by(F("ordered_date").desc(nulls_last=True), "po_number", "po_line_number")
