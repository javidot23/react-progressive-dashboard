from rest_framework import serializers


class OnOrderByDaysRangeSerializer(serializers.Serializer):
    days_range = serializers.CharField()
    original_qty = serializers.IntegerField()
    received_qty = serializers.IntegerField()
    epcis_count = serializers.IntegerField()
    epcis_order_qty = serializers.DecimalField(max_digits=14, decimal_places=3, allow_null=True)
    epcis_net_po_value = serializers.DecimalField(max_digits=15, decimal_places=2, allow_null=True)
    outstanding_qty = serializers.IntegerField()
    outstanding_qty_no_epcis = serializers.IntegerField()
    outstanding_qty_with_epcis = serializers.IntegerField()
    outstanding_amt = serializers.DecimalField(max_digits=15, decimal_places=2)
    outstanding_amt_no_epcis = serializers.DecimalField(max_digits=15, decimal_places=2)
    outstanding_amt_with_epcis = serializers.DecimalField(max_digits=15, decimal_places=2)


class OnOrderNoEpcisKpisSerializer(serializers.Serializer):
    outstanding_qty_no_epcis = serializers.IntegerField()
    outstanding_amt_no_epcis = serializers.DecimalField(max_digits=15, decimal_places=2)


class OnOrderNoEpcisLineSerializer(serializers.Serializer):
    po_number = serializers.CharField(allow_null=True)
    po_line_number = serializers.CharField(allow_null=True)
    material = serializers.CharField(allow_null=True)
    material_description = serializers.CharField(allow_null=True)
    ndc = serializers.CharField(allow_null=True)
    supplier = serializers.CharField(allow_null=True)
    dqsa_exempt_flg = serializers.CharField(allow_null=True)
    xplant_mat_stat = serializers.CharField(allow_null=True)
    plant = serializers.CharField(allow_null=True)
    expected_delivery_days = serializers.IntegerField(source="days_to_delivery", allow_null=True)
    ordered_date = serializers.DateField(allow_null=True)
    anticipated_date = serializers.DateField(allow_null=True)
    days_range = serializers.CharField()
    original_order_qty = serializers.IntegerField()
    received_qty = serializers.IntegerField()
    epcis_serial_count = serializers.IntegerField()
    epcis_record_present = serializers.BooleanField()
    outstanding_qty_no_epcis = serializers.IntegerField()
    outstanding_amt_no_epcis = serializers.DecimalField(max_digits=15, decimal_places=2)
    inbound_fill_rate = serializers.FloatField()
