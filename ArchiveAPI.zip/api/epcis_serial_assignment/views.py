from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.global_filters import get_filtered_material_subquery
from api.pagination import MaxLimitOffsetPagination
from .serialization import (
    OnOrderByDaysRangeSerializer,
    OnOrderNoEpcisKpisSerializer,
    OnOrderNoEpcisLineSerializer,
)
from .services import EpcisSerialAssignmentService


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OnOrderByDaysRangeView(APIView):
    """
    GET /epcis-serial-assignments/on-order-by-days-range/

    Returns on-order unit quantities grouped by material, plant, and days-to-due-date
    range, split between EPCIS-covered and uncovered outstanding quantities.

    Query params:
        plant_nbr (str, optional): filter to a single plant/DC
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=OnOrderByDaysRangeSerializer(many=True))
    def get(self, request):
        plant_nbr = request.query_params.get("plant_nbr")
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = EpcisSerialAssignmentService.get_on_order_by_days_range(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            plant_nbr=plant_nbr,
        )
        serializer = OnOrderByDaysRangeSerializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OnOrderNoEpcisKpisView(APIView):
    """
    GET /epcis-serial-assignments/on-order-no-epcis-kpis/

    Current outstanding quantity and amount without EPCIS serial coverage (live open
    PO stock). Totals match summing outstanding_*_no_epcis across day-range buckets
    from on-order-by-days-range.

    Query params:
        plant_nbr (str, optional): filter to a single plant/DC
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=OnOrderNoEpcisKpisSerializer)
    def get(self, request):
        plant_nbr = request.query_params.get("plant_nbr")
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = EpcisSerialAssignmentService.get_on_order_no_epcis_kpis(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            plant_nbr=plant_nbr,
        )
        serializer = OnOrderNoEpcisKpisSerializer(data)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OnOrderNoEpcisLineView(APIView):
    """
    GET /epcis-serial-assignments/on-order-no-epcis-lines/

    Drill-down for OnOrderByDaysRangeView: returns the individual open PO lines
    contributing to outstanding_qty_no_epcis, so the at-risk orders can be validated
    and made actionable for suppliers.

    Query params:
        plant_nbr (str, optional): filter to a single plant/DC
        days_range (str, optional): restrict to one days-to-due-date bucket
            (Overdue, 0-1, 2-3, 4-5, 6-7, 8+) — e.g. drilling into a clicked chart bar
        limit / offset (optional): limit/offset pagination (max 50)
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    pagination_class = MaxLimitOffsetPagination

    @extend_schema(responses=OnOrderNoEpcisLineSerializer(many=True))
    def get(self, request):
        plant_nbr = request.query_params.get("plant_nbr")
        days_range = request.query_params.get("days_range")
        if days_range and days_range not in EpcisSerialAssignmentService.DAYS_RANGE_BUCKETS:
            raise ValidationError({
                "days_range": f"Must be one of: {', '.join(EpcisSerialAssignmentService.DAYS_RANGE_BUCKETS)}"
            })
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        queryset = EpcisSerialAssignmentService.get_on_order_no_epcis_lines(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            plant_nbr=plant_nbr,
            days_range=days_range,
        )
        paginator = self.pagination_class()
        page = paginator.paginate_queryset(queryset, request)
        serializer = OnOrderNoEpcisLineSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)
