from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics
from rest_framework.exceptions import ValidationError
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiParameter, extend_schema, extend_schema_view

from api.global_filters import get_filtered_material_subquery
from api.pagination import MaxLimitOffsetPagination
from api.purchase_order.materialized_view_models import PurchaseOrderLatest90dMV
from .filters import OnOrderNoEpcisLineFilter
from .serialization import (
    OnOrderByDaysRangeSerializer,
    OnOrderNoEpcisKpisSerializer,
    OnOrderNoEpcisLineSerializer,
)
from .services import EpcisSerialAssignmentService


class OnOrderNoEpcisLineOrderingFilter(OrderingFilter):
    """API `expected_delivery_days` is live days-to-due; the snapshot column keeps that name."""

    field_map = {"expected_delivery_days": "days_to_delivery"}

    def get_ordering(self, request, queryset, view):
        ordering = super().get_ordering(request, queryset, view)
        if not ordering:
            return ordering
        mapped = []
        for term in ordering:
            descending = term.startswith("-")
            name = self.field_map.get(term.lstrip("-"), term.lstrip("-"))
            mapped.append(f"-{name}" if descending else name)
        return mapped


_ON_ORDER_NO_EPCIS_LINE_ORDERING_FIELDS = [
    "po_number",
    "po_line_number",
    "material",
    "material_description",
    "ndc",
    "supplier",
    "dqsa_exempt_flg",
    "xplant_mat_stat",
    "plant",
    "expected_delivery_days",
    "ordered_date",
    "anticipated_date",
    "days_range",
    "original_order_qty",
    "received_qty",
    "epcis_serial_count",
    "epcis_record_present",
    "outstanding_qty_no_epcis",
    "outstanding_amt_no_epcis",
    "inbound_fill_rate",
]


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OnOrderByDaysRangeView(APIView):
    """
    GET /epcis-serial-assignments/on-order-by-days-range/

    Returns on-order unit quantities grouped by material, plant, and days-to-due-date
    range, split between EPCIS-covered and uncovered outstanding quantities.

    Query params:
        plant_nbr (str, optional): filter to a single plant/DC
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=OnOrderByDaysRangeSerializer(many=True))
    def get(self, request):
        plant_nbr = request.query_params.get("plant_nbr")
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = EpcisSerialAssignmentService.get_on_order_by_days_range(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            plant_nbr=plant_nbr,
        )
        serializer = OnOrderByDaysRangeSerializer(data, many=True)
        return Response(serializer.data)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class OnOrderNoEpcisKpisView(APIView):
    """
    GET /epcis-serial-assignments/on-order-no-epcis-kpis/

    Current outstanding quantity and amount without EPCIS serial coverage (live open
    PO stock). Totals match summing outstanding_*_no_epcis across day-range buckets
    from on-order-by-days-range.

    Query params:
        plant_nbr (str, optional): filter to a single plant/DC
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    @extend_schema(responses=OnOrderNoEpcisKpisSerializer)
    def get(self, request):
        plant_nbr = request.query_params.get("plant_nbr")
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = EpcisSerialAssignmentService.get_on_order_no_epcis_kpis(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            plant_nbr=plant_nbr,
        )
        serializer = OnOrderNoEpcisKpisSerializer(data)
        return Response(serializer.data)


@extend_schema_view(
    get=extend_schema(
        parameters=[
            OpenApiParameter(
                name="plant_nbr",
                type=OpenApiTypes.STR,
                required=False,
                description="Filter to a single plant/DC.",
            ),
            OpenApiParameter(
                name="days_range",
                type=OpenApiTypes.STR,
                required=False,
                enum=list(EpcisSerialAssignmentService.DAYS_RANGE_BUCKETS),
                description="Restrict to one days-to-due-date bucket.",
            ),
            OpenApiParameter(
                name="ordering",
                type=OpenApiTypes.STR,
                required=False,
                enum=[
                    item
                    for field in _ON_ORDER_NO_EPCIS_LINE_ORDERING_FIELDS
                    for item in (field, f"-{field}")
                ],
                description="Sort field (prefix with - for descending). Default: -ordered_date.",
            ),
        ],
    ),
)
@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class OnOrderNoEpcisLineView(generics.ListAPIView):
    """
    GET /epcis-serial-assignments/on-order-no-epcis-lines/

    Drill-down for OnOrderByDaysRangeView: returns the individual open PO lines
    contributing to outstanding_qty_no_epcis, so the at-risk orders can be validated
    and made actionable for suppliers.

    Query params:
        plant_nbr (str, optional): filter to a single plant/DC
        days_range (str, optional): restrict to one days-to-due-date bucket
            (Overdue, 0-1, 2-3, 4-5, 6-7, 8+) — e.g. drilling into a clicked chart bar
        ordering (optional): serializer field, prefix with - for descending
        <field>_min / <field>_max and text filters (po_number, material, supplier, …)
        limit / offset (optional): limit/offset pagination (max 50)
        <global material filters>: supplier, product_family, therapeutic_class, material, etc.
    """

    serializer_class = OnOrderNoEpcisLineSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OnOrderNoEpcisLineOrderingFilter]
    filterset_class = OnOrderNoEpcisLineFilter
    ordering_fields = _ON_ORDER_NO_EPCIS_LINE_ORDERING_FIELDS
    ordering = ["-ordered_date", "po_number", "po_line_number"]

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return PurchaseOrderLatest90dMV.objects.none()
        plant_nbr = self.request.query_params.get("plant_nbr")
        days_range = self.request.query_params.get("days_range")
        if days_range and days_range not in EpcisSerialAssignmentService.DAYS_RANGE_BUCKETS:
            raise ValidationError({
                "days_range": (
                    f"Must be one of: {', '.join(EpcisSerialAssignmentService.DAYS_RANGE_BUCKETS)}"
                )
            })
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        return EpcisSerialAssignmentService.get_on_order_no_epcis_lines(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
            plant_nbr=plant_nbr,
            days_range=days_range,
        )
