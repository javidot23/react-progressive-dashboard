from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import FilterSet, filters, DjangoFilterBackend
from rest_framework import generics
from rest_framework.filters import OrderingFilter

from api.global_filters import get_filtered_material_subquery

from .models import MaterialFormulary
from .serializers import (
    MaterialFormularySerializer,
    MaterialFormularyUniqueSerializer,
    MaterialFormularyProgramDescriptionSerializer,
)
from .services import MaterialFormularyService
from ..pagination import MaxLimitOffsetPagination


class MaterialFormularyFilterSet(FilterSet):
    name = filters.CharFilter(field_name='parent_program', lookup_expr='icontains')
    material = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='exact')

    class Meta:
        model = MaterialFormulary
        fields = ['name', 'material']


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialFormularyListView(generics.ListAPIView):
    serializer_class = MaterialFormularySerializer
    pagination_class = MaxLimitOffsetPagination
    filterset_class = MaterialFormularyFilterSet
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = ['parent_program']
    ordering = ['parent_program']

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return MaterialFormulary.objects.none()
        return MaterialFormularyService.list_material_formularies()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialFormularyUniqueListView(generics.ListAPIView):
    """List unique formularies based on name. Supports global filters for contextual dropdowns."""
    serializer_class = MaterialFormularyUniqueSerializer
    filterset_class = MaterialFormularyFilterSet
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    pagination_class = None

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return MaterialFormulary.objects.none()
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        if direct_mat_nbr is None and mat_nbr_subquery is None:
            return MaterialFormularyService.list_material_formularies_unique()
        if direct_mat_nbr:
            base = MaterialFormulary.objects.filter(material__mat_nbr=direct_mat_nbr)
        else:
            base = MaterialFormulary.objects.filter(material__mat_nbr__in=mat_nbr_subquery)
        return base.values("parent_program").distinct()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialFormularyUniqueProgramDescriptionListView(generics.ListAPIView):
    """List unique formulary program descriptions. Supports global filters for contextual dropdowns."""
    serializer_class = MaterialFormularyProgramDescriptionSerializer
    filterset_class = MaterialFormularyFilterSet
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    pagination_class = None

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return MaterialFormulary.objects.none()
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(self.request)
        if direct_mat_nbr is None and mat_nbr_subquery is None:
            return MaterialFormularyService.list_material_formularies_unique_program_descriptions()
        if direct_mat_nbr:
            base = MaterialFormulary.objects.filter(material__mat_nbr=direct_mat_nbr)
        else:
            base = MaterialFormulary.objects.filter(material__mat_nbr__in=mat_nbr_subquery)
        return (
            base.filter(program_description__isnull=False)
            .order_by("program_description")
            .values("program_description")
            .distinct()
        )
