from django.db import models

from api.material.models import Material


class MaterialFormulary(models.Model):
    """
    Model representing a material formulary.
    """
    parent_program = models.CharField(max_length=255, blank=True, null=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE
    )
    sales_group = models.CharField(max_length=255, blank=True, null=True)
    program = models.CharField(max_length=255, blank=True, null=True)
    program_description = models.CharField(max_length=255, blank=True, null=True)
    contract_number = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "material_formularies"
        verbose_name = "Material Formulary"
        verbose_name_plural = "Material Formularies"
        ordering = ["parent_program"]
        unique_together = ("program", "material", "contract_number")
        indexes = [
            models.Index(fields=["parent_program"]),
            models.Index(fields=["material"])
        ]
