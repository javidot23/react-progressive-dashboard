from django.db import IntegrityError
from tests.BaseTestCase import BaseTestCase

from api.material_formulary.models import MaterialFormulary
from tests.TestDataFactory import TestDataFactory


class MaterialFormularyModelTest(BaseTestCase):
    def setUp(self):
        self.first_material = TestDataFactory.create_material(name='First Material')
        self.second_material = TestDataFactory.create_material(name='Second Material')

    def test_material_formulary_creation(self):
        """Test basic creation of MaterialFormulary."""
        formulary = MaterialFormulary.objects.create(
            material=self.first_material,
            parent_program="TST"
        )
        self.assertEqual(formulary.parent_program, "TST")
        self.assertEqual(formulary.material, self.first_material)
        self.assertIsNotNone(formulary.created_at)
        self.assertIsNotNone(formulary.updated_at)

    def test_unique_name_material(self):
        """Test that name and material must be unique together."""
        MaterialFormulary.objects.create(
            material=self.first_material,
            program="Unique Formulary",
            contract_number="12345"
        )
        with self.assertRaises(IntegrityError):
            MaterialFormulary.objects.create(
                material=self.first_material,
                program="Unique Formulary",
                contract_number="12345"
            )
