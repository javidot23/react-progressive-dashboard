import logging

from .models import MaterialFormulary

logger = logging.getLogger(__name__)


class MaterialFormularyService:
    @staticmethod
    def get_formulary_map(mat_nbrs):
        """
        Maps each material number to its sorted distinct non-empty formulary sales_groups.
        Materials with no formulary entries are absent from the mapping.
        """
        if not mat_nbrs:
            return {}

        rows = (
            MaterialFormulary.objects.filter(material_id__in=mat_nbrs)
            .exclude(sales_group__isnull=True)
            .exclude(sales_group="")
            .order_by("material_id", "sales_group")
            .values_list("material_id", "sales_group")
            .distinct()
        )

        formulary_map = {}
        for mat_nbr, sales_group in rows:
            groups = formulary_map.setdefault(mat_nbr, [])
            if sales_group not in groups:
                groups.append(sales_group)
        return formulary_map

    @staticmethod
    def get_material_formulary_by_id(formulary_id):
        logger.info("Retrieving material formulary by ID: %s", formulary_id)
        try:
            result = MaterialFormulary.objects.get(id=formulary_id)
            logger.info("Successfully retrieved material formulary ID: %s", formulary_id)
            return result
        except MaterialFormulary.DoesNotExist:
            logger.info("Material formulary not found: %s", formulary_id)
            return None

    @staticmethod
    def list_material_formularies():
        logger.info("Retrieving all material formularies with related material data")
        queryset = MaterialFormulary.objects.select_related('material').all()
        count = queryset.count()
        logger.info("Retrieved %s material formularies", count)
        return queryset

    @staticmethod
    def list_material_formularies_unique():
        """
        List unique formularies based on name.
        Used to avoid duplicates in dropdowns for filtering.
        """
        logger.info("Retrieving unique material formulary parent programs")
        queryset = MaterialFormulary.objects.values('parent_program').distinct()
        count = queryset.count()
        logger.info("Retrieved %s unique parent programs", count)
        return queryset

    @staticmethod
    def list_material_formularies_unique_program_descriptions():
        """
        List unique formulary program descriptions.
        Used to populate the formulary_program filter dropdown.
        """
        logger.info("Retrieving unique material formulary program descriptions")

        queryset = (
            MaterialFormulary.objects.filter(program_description__isnull=False)
            .order_by('program_description')
            .values('program_description')
            .distinct()
        )
        count = queryset.count()
        logger.info("Retrieved %s unique program descriptions", count)
        return queryset

    @staticmethod
    def queryset_unique_by_program_description():
        """
        MaterialFormulary rows deduplicated by program_description (one per description).
        For use with Prefetch on Material.materialformulary_set.
        """
        return (
            MaterialFormulary.objects.filter(program_description__isnull=False)
            .order_by('program_description', 'id')
            .distinct('program_description')
        )
