from rest_framework import serializers

from .models import MaterialFormulary


class MaterialFormularySerializer(serializers.ModelSerializer):
    name = serializers.CharField(source='parent_program', read_only=True)
    mat_nbr = serializers.CharField(source='material.mat_nbr', read_only=True)
    created_at = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", read_only=True)
    updated_at = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", read_only=True)

    class Meta:
        model = MaterialFormulary
        fields = '__all__'
        read_only_fields = ('created_at', 'updated_at')


class MaterialFormularyUniqueSerializer(serializers.ModelSerializer):
    name = serializers.CharField(source='parent_program', read_only=True)

    class Meta:
        fields = ['name']
        model = MaterialFormulary


class MaterialFormularyProgramDescriptionSerializer(serializers.ModelSerializer):
    name = serializers.CharField(source='program_description', read_only=True)

    class Meta:
        fields = ['name']
        model = MaterialFormulary
