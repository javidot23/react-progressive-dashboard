from django.urls import path

from .views import (
    MaterialFormularyListView,
    MaterialFormularyUniqueListView,
    MaterialFormularyUniqueProgramDescriptionListView,
)

app_name = 'material_formulary'

urlpatterns = [
    path('', MaterialFormularyListView.as_view(), name='list'),
    path('unique/', MaterialFormularyUniqueListView.as_view(), name='unique-list'),
    path('unique-program-descriptions/',
         MaterialFormularyUniqueProgramDescriptionListView.as_view(),
         name='unique-program-descriptions-list'),
]
