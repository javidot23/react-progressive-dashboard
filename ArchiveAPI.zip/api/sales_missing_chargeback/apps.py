from django.apps import AppConfig


class SalesMissingChargebackConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.sales_missing_chargeback"
