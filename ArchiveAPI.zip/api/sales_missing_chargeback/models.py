from django.db import models

from api.material.models import Material


class SalesMissingChargeback(models.Model):
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    ndc = models.CharField(max_length=255, null=True, blank=True)
    invoice_date = models.DateField(null=True, blank=True)
    invoice_number = models.CharField(max_length=255, null=True, blank=True)
    manufacturer_contract_name = models.CharField(max_length=255, null=True, blank=True)
    contract_sales_and_rebill_qty = models.DecimalField(max_digits=18, decimal_places=3, null=True, blank=True)
    contract_sales_and_rebill_amount = models.DecimalField(max_digits=38, decimal_places=6, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "sales_missing_chargebacks"
        verbose_name = "Sales Missing Chargeback"
        verbose_name_plural = "Sales Missing Chargebacks"
        unique_together = [("invoice_number", "material", "manufacturer_contract_name")]
        indexes = [
            models.Index(fields=["material"]),
            models.Index(fields=["invoice_date"]),
            models.Index(fields=["invoice_number"]),
        ]
