from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class SalesMissingChargebackModelTest(BaseTestCase):

    def test_create_sales_missing_chargeback(self):
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        record = TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor,
            material=material,
            invoice_number="INV123456",
            manufacturer_contract_name="Test Contract",
        )
        self.assertEqual(record.material, material)
        self.assertEqual(record.invoice_number, "INV123456")
        self.assertEqual(record.manufacturer_contract_name, "Test Contract")

    def test_unique_together_vendor_invoice_material(self):
        from django.db import IntegrityError
        vendor = TestDataFactory.create_vendor()
        material = TestDataFactory.create_material(vendor=vendor)
        TestDataFactory.create_sales_missing_chargeback(
            vendor=vendor, material=material, invoice_number="INV999999"
        )
        with self.assertRaises(IntegrityError):
            TestDataFactory.create_sales_missing_chargeback(
                vendor=vendor, material=material, invoice_number="INV999999"
            )
