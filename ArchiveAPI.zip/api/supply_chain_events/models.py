from django.db import models

from api.material.models import Material
from api.plant.models import Plant


class SupplyChainEvent(models.Model):
    """Model to track supply chain events for materials."""

    class EventStatus(models.TextChoices):
        OPEN = "OPEN", "Open"
        CLOSED = "CLOSED", "Closed"

    event_id = models.CharField(
        max_length=255,
        help_text="Business event identifier string",
        unique=True
    )
    type = models.CharField(
        max_length=255,
        help_text="Event type"
    )
    type_description = models.TextField(
        blank=True,
        null=True,
        help_text="Detailed description of the event type"
    )
    status = models.CharField(
        max_length=20,
        choices=EventStatus.choices,
        default=EventStatus.OPEN,
        help_text="Current status of the event"
    )
    start_date = models.DateTimeField(
        help_text="When the event started"
    )
    end_date = models.DateTimeField(
        blank=True,
        null=True,
        help_text="When the event ended (null if ongoing)"
    )
    latitude = models.FloatField(
        blank=True,
        null=True,
        help_text="Latitude coordinate of event location"
    )
    longitude = models.FloatField(
        blank=True,
        null=True,
        help_text="Longitude coordinate of event location"
    )

    mat_nbr = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        related_name="supply_chain_events",
        blank=True,
        null=True,
        help_text=(
            "Associated material, when the event grain includes a material. "
            "Null for material-less grains such as gcn-only, ndc-only or fei-only."
        ),
    )
    fdb_gcn_seq_nbr = models.CharField(max_length=255, blank=True, null=True)
    ndc = models.CharField(max_length=255, blank=True, null=True)
    fei_number = models.CharField(max_length=255, blank=True, null=True)
    hicl = models.CharField(max_length=255, blank=True, null=True)
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
    )
    metadata = models.TextField(
        blank=True,
        null=True,
        help_text="Additional metadata in JSON or text format"
    )
    city = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="City where the event is located"
    )
    state = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="State where the event is located"
    )
    country = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="Country where the event is located"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "supply_chain_events"
        verbose_name = "Supply Chain Event"
        verbose_name_plural = "Supply Chain Events"
        ordering = ["-start_date"]
        indexes = [
            models.Index(fields=["event_id"]),
            models.Index(fields=["mat_nbr"]),
            models.Index(fields=["type"]),
            models.Index(fields=["status"]),
            models.Index(fields=["start_date"]),
            models.Index(fields=["mat_nbr", "status"]),
            models.Index(fields=["latitude", "longitude"]),
        ]

    def __str__(self):
        return f"{self.event_id} - {self.type} ({self.status})"
