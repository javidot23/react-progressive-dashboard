import logging

from django.db.models import Prefetch, F, FloatField, Case, When, Min, Subquery, Q

from .models import SupplyChainEvent
from ..issue.models import Issue
from ..material.models import Material

logger = logging.getLogger(__name__)


class SupplyChainEventService:
    """Service layer for Supply Chain Events business logic."""

    @staticmethod
    def get_events_with_materials():
        """
        Get all supply chain events with related material and vendor data.
        Optimized with select_related.
        """
        return SupplyChainEvent.objects.select_related(
            'mat_nbr__vendor'
        ).all()

    @staticmethod
    def get_events_with_unique_event_ids(base_queryset=None):
        """
        Return one event per event_id (deduplicated). Picks one id per event_id
        via MIN(id). When base_queryset is given, filter first then dedup within that set.
        """
        base = base_queryset if base_queryset is not None else SupplyChainEvent.objects.all()
        one_id_per_event_id = base.values('event_id').annotate(picked_id=Min('id')).values('picked_id')
        return (
            SupplyChainEvent.objects
            .filter(id__in=Subquery(one_id_per_event_id))
            .select_related('mat_nbr__vendor')
            .order_by('-start_date')
        )

    @staticmethod
    def get_event_by_id(event_pk):
        """
        Get a single event by primary key with related data.
        Returns None if not found.
        """
        try:
            return SupplyChainEvent.objects.select_related(
                'mat_nbr__vendor'
            ).get(pk=event_pk)
        except SupplyChainEvent.DoesNotExist:
            logger.warning(f"Event with id {event_pk} not found")
            return None

    @staticmethod
    def get_event_for_issue(issue_id: int):
        """
        Resolve the supply chain event driving an issue via its unique ``event_id``.

        Returns None if the issue exists but has no event_id or no matching event row.
        Raises Issue.DoesNotExist if the issue does not exist.
        """
        issue = Issue.objects.only('event_id').get(pk=issue_id)
        if not issue.event_id:
            return None
        return (
            SupplyChainEvent.objects
            .select_related('mat_nbr__vendor')
            .filter(event_id=issue.event_id)
            .first()
        )

    @staticmethod
    def get_events_for_top_riskiest_materials(limit=4, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get events for materials returned by the top-riskiest-materials endpoint.
        Uses the same logic as IssueService.get_top_riskiest_materials to identify materials.

        Args:
            limit: Number of top materials to consider
            direct_mat_nbr: Direct material number filter
            mat_nbr_subquery: Material subquery for filtering

        Returns:
            Dictionary with 'materials' and 'events' keys
        """

        limit = min(limit, 10)
        logger.info(f"Getting events for top {limit} riskiest materials")

        # Get top riskiest materials (same logic as IssueService.get_top_riskiest_materials)
        risky_materials = Material.objects.filter(
            issue__status=Issue.IssueStatus.OPEN
        ).exclude(xplant_mat_stat__in=['DB', 'DM']).exclude(
            Q(drop_ship_flg=1) | Q(short_date_flg=1)
        )

        # Apply material filters using optimized subquery pattern
        if direct_mat_nbr:
            risky_materials = risky_materials.filter(mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            risky_materials = risky_materials.filter(mat_nbr__in=mat_nbr_subquery)

        risky_materials = risky_materials.prefetch_related(
            Prefetch(
                'issue_set',
                queryset=Issue.objects.filter(status=Issue.IssueStatus.OPEN)
            )
        ).annotate(
            risk_adjusted_value=Case(
                When(
                    risk_rating__isnull=False,
                    dollars_at_risk__isnull=False,
                    then=F('risk_rating') * F('dollars_at_risk')
                ),
                default=0.0,
                output_field=FloatField()
            )
        ).distinct().order_by('-risk_adjusted_value')[:limit]

        # Extract mat_nbr values (risk order preserved)
        material_ids = [material.mat_nbr for material in risky_materials]

        # One OPEN event per material: newest by start_date (then id for ties).
        # Iterate OPEN events newest-first; first seen per mat_nbr wins.
        open_events = (
            SupplyChainEvent.objects.filter(
                mat_nbr__mat_nbr__in=material_ids,
                status=SupplyChainEvent.EventStatus.OPEN,
            )
            .select_related('mat_nbr')
            .order_by('-start_date', '-id')
        )
        newest_open_by_mat = {}
        for event in open_events:
            mat_key = event.mat_nbr.mat_nbr
            if mat_key not in newest_open_by_mat:
                newest_open_by_mat[mat_key] = event

        events = [
            newest_open_by_mat[mid]
            for mid in material_ids
            if mid in newest_open_by_mat
        ]

        logger.info(
            "Found %s risky materials and %s OPEN events (one per material, risk order)",
            len(material_ids),
            len(events),
        )

        return {
            'materials': risky_materials,
            'events': events
        }

    @staticmethod
    def _apply_material_filter(queryset, direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Helper to apply material filters using optimized subquery pattern.
        """
        if direct_mat_nbr:
            queryset = queryset.filter(mat_nbr__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(mat_nbr__mat_nbr__in=mat_nbr_subquery)
        return queryset
