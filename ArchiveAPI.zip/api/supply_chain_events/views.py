import logging
from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page, never_cache
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, status
from rest_framework.exceptions import NotFound
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.issue.models import Issue
from api.issue.granularity import materials_for_event
from api.global_filters import get_filtered_material_subquery
from api.material.serializers import MaterialSerializer
from api.pagination import MaxLimitOffsetPagination
from .filters import SupplyChainEventFilter
from .models import SupplyChainEvent
from .serializers import (
    SupplyChainEventListSerializer,
    SupplyChainEventDetailSerializer,
    TopRiskiestMaterialsEventsSerializer,
)
from .services import SupplyChainEventService

logger = logging.getLogger(__name__)


@method_decorator(
    cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)),
    name='list'
)
class SupplyChainEventListView(generics.ListAPIView):
    """
    List all supply chain events with filtering, ordering, and pagination.
    """
    serializer_class = SupplyChainEventListSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = SupplyChainEventFilter
    ordering_fields = [
        'start_date',
        'end_date',
        'type',
        'status',
        'event_id',
        'mat_nbr__name',
        'mat_nbr__risk_rating',
    ]

    def get_queryset(self):
        """
        Filter first (status, has_location, etc.), then return one event per event_id.
        """
        filterset = SupplyChainEventFilter(
            self.request.query_params,
            queryset=SupplyChainEvent.objects.all(),
            request=self.request,
        )
        queryset = SupplyChainEventService.get_events_with_unique_event_ids(
            base_queryset=filterset.qs
        )
        status_filter = self.request.query_params.get('status', None)
        ordering_param = self.request.query_params.get('ordering', None)
        if status_filter == 'OPEN' and not ordering_param:
            queryset = queryset.order_by('-start_date')
        return queryset


@method_decorator(
    cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)),
    name='retrieve'
)
class SupplyChainEventDetailView(generics.RetrieveAPIView):
    """
    Get details of a single supply chain event by ID.

    Returns:
    - Full event details
    - Related events: Other materials that have the same event_id
    """
    serializer_class = SupplyChainEventDetailSerializer
    lookup_field = 'pk'

    def get_queryset(self):
        return SupplyChainEventService.get_events_with_materials()


@method_decorator(
    cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)),
    name='list'
)
class SupplyChainEventsByMaterialView(generics.ListAPIView):
    """
    List supply chain events for a given material (by mat_nbr).

    Supports SupplyChainEventFilter params (status, start_date, end_date, ...)
    and ordering. Returns 404 if the material does not exist.
    """
    serializer_class = SupplyChainEventListSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = SupplyChainEventFilter
    ordering_fields = ['start_date', 'end_date', 'type', 'status', 'event_id']
    ordering = ['-start_date']

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return SupplyChainEvent.objects.none()
        mat_nbr = self.kwargs['mat_nbr']
        return (
            SupplyChainEvent.objects
            .filter(mat_nbr__mat_nbr=mat_nbr)
            .select_related('mat_nbr__vendor')
        )


@method_decorator(
    cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)),
    name='retrieve'
)
class SupplyChainEventByIssueView(generics.RetrieveAPIView):
    """
    Get the supply chain event linked to an issue.

    Resolves the event using the issue's event_id and material (mat_nbr),
    matching the composite key on supply_chain_events.
    """
    serializer_class = SupplyChainEventDetailSerializer
    lookup_url_kwarg = 'issue_id'

    def get_object(self):
        issue_id = self.kwargs[self.lookup_url_kwarg]
        try:
            event = SupplyChainEventService.get_event_for_issue(issue_id)
        except Issue.DoesNotExist as exc:
            raise NotFound({'error': 'Issue not found'}) from exc

        if event is not None:
            return event

        issue = Issue.objects.only('event_id').get(pk=issue_id)
        if not issue.event_id:
            raise NotFound({'error': 'Issue has no linked event_id'})
        raise NotFound({'error': 'Supply chain event not found for issue'})


@method_decorator(
    cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)),
    name='get'
)
class TopRiskiestMaterialsEventsView(APIView):
    """
    Get events for the top riskiest materials.

    Uses the same material ranking as issue/top-riskiest-materials (open issues,
    risk_adjusted_value).

    Query params:
    - limit: Number of top materials to consider (default: 4, max: 10)
    - All global filters (supplier, product_family, therapeutic_class, etc.)

    Returns:
    - events: At most one OPEN supply chain event per top material (newest
      start_date), in the same order as material risk ranking. CLOSED events
      are omitted.
    """

    @extend_schema(responses=TopRiskiestMaterialsEventsSerializer)
    def get(self, request):
        limit = int(request.query_params.get('limit', 4))
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)

        data = SupplyChainEventService.get_events_for_top_riskiest_materials(
            limit=limit,
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery
        )

        serializer = TopRiskiestMaterialsEventsSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(never_cache, name='dispatch')
class SupplyChainEventImpactedMaterialsView(generics.ListAPIView):
    """Returns all materials impacted by a supply-chain event, resolved at the
    event's grain. Empty for grains with no material mapping (fei)."""
    serializer_class = MaterialSerializer
    pagination_class = MaxLimitOffsetPagination
    lookup_url_kwarg = 'pk'

    def get_queryset(self):
        try:
            event = SupplyChainEvent.objects.only(
                'mat_nbr', 'fdb_gcn_seq_nbr', 'ndc', 'fei_number', 'hicl', 'plant'
            ).get(pk=self.kwargs[self.lookup_url_kwarg])
        except SupplyChainEvent.DoesNotExist as exc:
            raise NotFound({'error': 'Event not found'}) from exc

        return materials_for_event(event).select_related('vendor').order_by('mat_nbr')
