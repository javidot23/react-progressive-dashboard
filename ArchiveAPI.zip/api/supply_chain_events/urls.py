from django.urls import path

from .views import (
    SupplyChainEventListView,
    SupplyChainEventDetailView,
    SupplyChainEventsByMaterialView,
    SupplyChainEventByIssueView,
    TopRiskiestMaterialsEventsView,
    SupplyChainEventImpactedMaterialsView,
)

app_name = "supply_chain_events"

urlpatterns = [
    path('', SupplyChainEventListView.as_view(), name='event-list'),
    path('<int:pk>/', SupplyChainEventDetailView.as_view(), name='event-detail'),
    path(
        '<int:pk>/materials/',
        SupplyChainEventImpactedMaterialsView.as_view(),
        name='event-impacted-materials'
    ),
    path(
        'material/<str:mat_nbr>/',
        SupplyChainEventsByMaterialView.as_view(),
        name='events-by-material'
    ),
    path(
        'issue/<int:issue_id>/',
        SupplyChainEventByIssueView.as_view(),
        name='event-by-issue',
    ),
    path(
        'top-riskiest-materials-events/',
        TopRiskiestMaterialsEventsView.as_view(),
        name='top-riskiest-materials-events'
    ),
]
