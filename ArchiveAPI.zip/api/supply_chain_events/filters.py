from django_filters import filters
from django_filters.rest_framework import FilterSet

from api.global_filters import GlobalFilterForRelatedMaterialMixin
from .models import SupplyChainEvent


class SupplyChainEventFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """
    Filter for Supply Chain Events with global material filters support.
    Inherits global filters: supplier, product_family, therapeutic_class, buyer,
    category_manager, material, gcn, formulary.
    """

    # Custom filters
    event_id = filters.CharFilter(lookup_expr='icontains')
    type = filters.CharFilter(lookup_expr='icontains')
    status = filters.CharFilter(lookup_expr='exact')

    # Date range filters
    start_date_after = filters.DateTimeFilter(field_name='start_date', lookup_expr='gte')
    start_date_before = filters.DateTimeFilter(field_name='start_date', lookup_expr='lte')
    end_date_after = filters.DateTimeFilter(field_name='end_date', lookup_expr='gte')
    end_date_before = filters.DateTimeFilter(field_name='end_date', lookup_expr='lte')

    # ?start_date=...&end_date=... bounds the event's start_date column.
    start_date = filters.DateTimeFilter(field_name='start_date', lookup_expr='gte')
    end_date = filters.DateTimeFilter(field_name='start_date', lookup_expr='lte')

    # Material filters (explicit for clarity, also available through GlobalFilterForRelatedMaterialMixin)
    material = filters.CharFilter(field_name='mat_nbr__mat_nbr', lookup_expr='exact')
    material_name = filters.CharFilter(field_name='mat_nbr__name', lookup_expr='icontains')

    # Location filters
    city = filters.CharFilter(field_name='city', lookup_expr='icontains')
    state = filters.CharFilter(field_name='state', lookup_expr='icontains')
    country = filters.CharFilter(field_name='country', lookup_expr='icontains')
    latitude_min = filters.NumberFilter(field_name='latitude', lookup_expr='gte')
    latitude_max = filters.NumberFilter(field_name='latitude', lookup_expr='lte')
    longitude_min = filters.NumberFilter(field_name='longitude', lookup_expr='gte')
    longitude_max = filters.NumberFilter(field_name='longitude', lookup_expr='lte')

    # Custom boolean filter for location-related events
    has_location = filters.BooleanFilter(method='filter_has_location')

    def filter_has_location(self, queryset, name, value):
        """
        Events with usable map coordinates (not NULL, not NaN/Inf).

        SQL NULL is excluded via __isnull=False. IEEE NaN is not equal to
        itself, so range predicates on lat/lng exclude NaN without backend-specific
        functions. Bounds match WGS84 so only real-world coordinates match.
        Usage: ?has_location=true
        """
        if value:
            return queryset.filter(
                latitude__isnull=False,
                longitude__isnull=False,
                latitude__range=(-90.0, 90.0),
                longitude__range=(-180.0, 180.0),
            )
        return queryset

    class Meta:
        model = SupplyChainEvent
        fields = []
