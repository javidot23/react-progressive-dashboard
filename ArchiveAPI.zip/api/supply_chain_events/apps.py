from django.apps import AppConfig


class SupplyChainEventsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.supply_chain_events'
    verbose_name = 'Supply Chain Events'
