from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory
from api.issue.models import Issue
from api.supply_chain_events.services import SupplyChainEventService


class SupplyChainEventServiceTest(BaseTestCase):
    """Test service layer for Supply Chain Events."""

    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.material = TestDataFactory.create_material(
            vendor=self.vendor,
            risk_rating=0.9,
        )

    def test_get_events_with_materials(self):
        """Test retrieving events with related materials."""
        TestDataFactory.create_supply_chain_event(material=self.material)
        TestDataFactory.create_supply_chain_event(material=self.material)

        events = SupplyChainEventService.get_events_with_materials()

        self.assertEqual(events.count(), 2)
        # Evaluate the queryset first
        events_list = list(events)
        # Verify select_related worked (no additional queries when accessing related objects)
        with self.assertNumQueries(0):
            for event in events_list:
                _ = event.mat_nbr.vendor.name

    def test_get_event_by_id_exists(self):
        """Test retrieving a single event by ID."""
        event = TestDataFactory.create_supply_chain_event(
            material=self.material
        )

        retrieved = SupplyChainEventService.get_event_by_id(event.id)

        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.id, event.id)

    def test_get_event_by_id_not_found(self):
        """Test retrieving non-existent event returns None."""
        retrieved = SupplyChainEventService.get_event_by_id(99999)

        self.assertIsNone(retrieved)

    def test_get_event_for_issue_returns_linked_event(self):
        """Issue event_id + material resolves the matching supply chain event."""
        import uuid
        event_id = f"SVC-ISSUE-{uuid.uuid4().hex[:8]}"
        event = TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_id=event_id,
        )
        issue = TestDataFactory.create_issue(
            material=self.material,
            event_id=event_id,
        )

        retrieved = SupplyChainEventService.get_event_for_issue(issue.id)

        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.id, event.id)

    def test_get_event_for_issue_raises_when_issue_missing(self):
        """Missing issue should raise Issue.DoesNotExist."""
        with self.assertRaises(Issue.DoesNotExist):
            SupplyChainEventService.get_event_for_issue(99999)

    def test_get_event_for_issue_returns_none_without_event_id(self):
        """Issue without event_id should return None."""
        issue = TestDataFactory.create_issue(
            material=self.material,
            event_id=None,
        )

        retrieved = SupplyChainEventService.get_event_for_issue(issue.id)

        self.assertIsNone(retrieved)

    def test_get_events_for_top_riskiest_materials(self):
        """Test getting events for top riskiest materials."""
        # Create issue to make material risky
        TestDataFactory.create_issue(
            material=self.material,
            status='OPEN'
        )

        # Create events for this material
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_type="SHIPMENT_DELAY"
        )
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_type="QUALITY_ISSUE"
        )

        result = SupplyChainEventService.get_events_for_top_riskiest_materials(
            limit=3
        )

        self.assertIn('materials', result)
        self.assertIn('events', result)
        self.assertGreater(len(result['materials']), 0)
        # One OPEN event per material (newest by start_date); two rows collapse to one.
        self.assertEqual(len(result['events']), 1)

    def test_get_events_for_top_riskiest_materials_excludes_drop_ship(self):
        """Drop-ship materials should be excluded from top riskiest materials events."""
        drop_ship_material = TestDataFactory.create_material(
            vendor=self.vendor, risk_rating=0.95, drop_ship_flg=1
        )
        TestDataFactory.create_issue(material=drop_ship_material, status='OPEN')
        TestDataFactory.create_supply_chain_event(material=drop_ship_material)

        TestDataFactory.create_issue(material=self.material, status='OPEN')
        TestDataFactory.create_supply_chain_event(material=self.material)

        result = SupplyChainEventService.get_events_for_top_riskiest_materials(limit=10)
        mat_ids = [m.id for m in result['materials']]
        self.assertNotIn(drop_ship_material.id, mat_ids)
        self.assertIn(self.material.id, mat_ids)

    def test_get_events_for_top_riskiest_materials_excludes_short_date(self):
        """Short-date materials should be excluded from top riskiest materials events."""
        short_date_material = TestDataFactory.create_material(
            vendor=self.vendor, risk_rating=0.95, short_date_flg=1
        )
        TestDataFactory.create_issue(material=short_date_material, status='OPEN')
        TestDataFactory.create_supply_chain_event(material=short_date_material)

        TestDataFactory.create_issue(material=self.material, status='OPEN')
        TestDataFactory.create_supply_chain_event(material=self.material)

        result = SupplyChainEventService.get_events_for_top_riskiest_materials(limit=10)
        mat_ids = [m.id for m in result['materials']]
        self.assertNotIn(short_date_material.id, mat_ids)
        self.assertIn(self.material.id, mat_ids)
