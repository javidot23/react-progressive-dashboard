from django.utils import timezone
from django.test import RequestFactory
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory
from api.supply_chain_events.filters import SupplyChainEventFilter
from api.supply_chain_events.models import SupplyChainEvent


class SupplyChainEventFilterTest(BaseTestCase):
    """Test filters for Supply Chain Events."""

    def setUp(self):
        self.factory = RequestFactory()
        self.vendor = TestDataFactory.create_vendor()
        self.material = TestDataFactory.create_material(vendor=self.vendor)

    def test_filter_by_status(self):
        """Test filtering events by status."""
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            status='OPEN'
        )
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            status='CLOSED'
        )

        request = self.factory.get('/', {'status': 'OPEN'})
        filterset = SupplyChainEventFilter(
            request.GET,
            queryset=SupplyChainEvent.objects.all()
        )

        self.assertEqual(filterset.qs.count(), 1)
        self.assertEqual(filterset.qs.first().status, 'OPEN')

    def test_filter_by_type(self):
        """Test filtering events by type."""
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_type="SHIPMENT_DELAY"
        )
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_type="QUALITY_ISSUE"
        )

        request = self.factory.get('/', {'type': 'SHIPMENT'})
        filterset = SupplyChainEventFilter(
            request.GET,
            queryset=SupplyChainEvent.objects.all()
        )

        self.assertEqual(filterset.qs.count(), 1)
        self.assertIn('SHIPMENT', filterset.qs.first().type)

    def test_filter_has_location_true(self):
        """Test filtering events with location data."""
        # Event with location
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            latitude=40.7128,
            longitude=-74.0060
        )
        # Event without location
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            latitude=None,
            longitude=None
        )

        request = self.factory.get('/', {'has_location': 'true'})
        filterset = SupplyChainEventFilter(
            request.GET,
            queryset=SupplyChainEvent.objects.all()
        )

        self.assertEqual(filterset.qs.count(), 1)
        self.assertIsNotNone(filterset.qs.first().latitude)
        self.assertIsNotNone(filterset.qs.first().longitude)

    def test_filter_has_location_true_excludes_nan_coordinates(self):
        """NaN is not SQL NULL; it must not count as a mappable location."""
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            latitude=float('nan'),
            longitude=float('nan'),
        )
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            latitude=40.7128,
            longitude=-74.0060,
        )

        request = self.factory.get('/', {'has_location': 'true'})
        filterset = SupplyChainEventFilter(
            request.GET,
            queryset=SupplyChainEvent.objects.all(),
        )

        self.assertEqual(filterset.qs.count(), 1)
        self.assertEqual(filterset.qs.first().latitude, 40.7128)

    def test_filter_has_location_false(self):
        """Test that has_location=false returns all events."""
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            latitude=40.7128,
            longitude=-74.0060
        )
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            latitude=None,
            longitude=None
        )

        request = self.factory.get('/', {'has_location': 'false'})
        filterset = SupplyChainEventFilter(
            request.GET,
            queryset=SupplyChainEvent.objects.all()
        )

        # has_location=false returns all events (no filtering)
        self.assertEqual(filterset.qs.count(), 2)

    def test_filter_by_date_range(self):
        """Test filtering events by date range."""
        now = timezone.now()

        # Old event
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            start_date=now - timezone.timedelta(days=10)
        )
        # Recent event
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            start_date=now - timezone.timedelta(days=2)
        )

        cutoff = (now - timezone.timedelta(days=5)).isoformat()
        request = self.factory.get('/', {'start_date_after': cutoff})
        filterset = SupplyChainEventFilter(
            request.GET,
            queryset=SupplyChainEvent.objects.all()
        )

        self.assertEqual(filterset.qs.count(), 1)
