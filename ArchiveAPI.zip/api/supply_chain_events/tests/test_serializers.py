import uuid

from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory
from api.supply_chain_events.serializers import (
    SupplyChainEventListSerializer,
    SupplyChainEventDetailSerializer,
)


class SupplyChainEventSerializerTest(BaseTestCase):
    """Test serializers for Supply Chain Events."""

    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.material = TestDataFactory.create_material(vendor=self.vendor)

    def test_list_serializer_fields(self):
        """Test that list serializer includes all expected fields."""
        event = TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_type="SHIPMENT_DELAY",
            latitude=40.7128,
            longitude=-74.0060
        )

        serializer = SupplyChainEventListSerializer(event)
        data = serializer.data

        expected_fields = {
            'id', 'event_id', 'type', 'type_description', 'status',
            'start_date', 'end_date', 'latitude', 'longitude',
            'city', 'state', 'country',
            'mat_nbr', 'metadata', 'created_at', 'updated_at'
        }

        self.assertEqual(set(data.keys()), expected_fields)
        self.assertIsNotNone(data['mat_nbr'])

    def test_detail_serializer_related_events_empty(self):
        """event_id is now unique, so there are no other events sharing it.

        The related_events field is retained (it will be revisited in the API
        phase) but resolves to an empty list under the new granularity model.
        """
        event_id = f"MULTI-EVENT-{uuid.uuid4().hex[:8]}"

        event1 = TestDataFactory.create_supply_chain_event(
            event_id=event_id,
            material=self.material,
        )

        serializer = SupplyChainEventDetailSerializer(event1)
        data = serializer.data

        self.assertIn('related_events', data)
        self.assertEqual(data['related_events'], [])
