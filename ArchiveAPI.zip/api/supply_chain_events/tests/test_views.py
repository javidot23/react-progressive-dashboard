from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APIClient

from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class SupplyChainEventViewsTest(BaseTestCase):
    """Integration tests for Supply Chain Events API endpoints."""

    def setUp(self):
        self.client = APIClient()
        self.vendor = TestDataFactory.create_vendor()
        self.material = TestDataFactory.create_material(
            vendor=self.vendor,
            risk_rating=0.9
        )

    def test_event_list_view(self):
        """Test listing all events."""
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_type="SHIPMENT_DELAY"
        )
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_type="QUALITY_ISSUE"
        )

        url = reverse('supply_chain_events:event-list')
        response = self.client.get(url, {'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)
        self.assertEqual(len(response.data['results']), 2)

    def test_event_list_view_with_status_filter(self):
        """Test filtering events by status."""
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            status='OPEN'
        )
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            status='CLOSED'
        )

        url = reverse('supply_chain_events:event-list')
        response = self.client.get(url, {'status': 'OPEN'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['results'][0]['status'], 'OPEN')

    def test_event_list_view_with_has_location_filter(self):
        """Test filtering events with location data."""
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            latitude=40.7128,
            longitude=-74.0060
        )
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            latitude=None,
            longitude=None
        )

        url = reverse('supply_chain_events:event-list')
        response = self.client.get(url, {'has_location': 'true'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertIsNotNone(response.data['results'][0]['latitude'])

    def test_event_list_view_ordering_by_start_date(self):
        """Test ordering events by start_date."""
        now = timezone.now()
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            start_date=now - timezone.timedelta(days=2)
        )
        event2 = TestDataFactory.create_supply_chain_event(
            material=self.material,
            start_date=now - timezone.timedelta(days=1)
        )

        url = reverse('supply_chain_events:event-list')
        response = self.client.get(url, {'ordering': '-start_date'})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Most recent first
        self.assertEqual(
            response.data['results'][0]['id'],
            event2.id
        )

    def test_event_detail_view(self):
        """Test retrieving a single event detail."""
        import uuid
        event_id = f"TEST-DETAIL-{uuid.uuid4().hex[:8]}"
        event = TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_id=event_id
        )

        url = reverse('supply_chain_events:event-detail', kwargs={'pk': event.pk})
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['event_id'], event_id)
        self.assertIn('related_events', response.data)

    def test_event_detail_view_related_events_empty(self):
        """event_id is now unique, so the detail view exposes related_events as an
        empty list. The field is retained for the upcoming API-phase rework."""
        import uuid
        event_id = f"SHARED-EVENT-{uuid.uuid4().hex[:8]}"

        event1 = TestDataFactory.create_supply_chain_event(
            event_id=event_id,
            material=self.material
        )

        url = reverse('supply_chain_events:event-detail', kwargs={'pk': event1.pk})
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['related_events'], [])

    def test_event_detail_view_not_found(self):
        """Test retrieving non-existent event returns 404."""
        url = reverse('supply_chain_events:event-detail', kwargs={'pk': 99999})
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_top_riskiest_materials_events_view(self):
        """Test endpoint for events of top riskiest materials."""
        # Create issue to make material risky
        TestDataFactory.create_issue(
            material=self.material,
            status='OPEN'
        )

        # Create events
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_type="SHIPMENT_DELAY"
        )

        url = reverse('supply_chain_events:top-riskiest-materials-events')
        response = self.client.get(url, {'limit': 3})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('events', response.data)
        self.assertEqual(len(response.data['events']), 1)

    def test_top_riskiest_materials_events_excludes_closed(self):
        """CLOSED supply chain events are not returned."""
        TestDataFactory.create_issue(material=self.material, status='OPEN')
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            status='CLOSED',
            event_type="OLD",
        )

        url = reverse('supply_chain_events:top-riskiest-materials-events')
        response = self.client.get(url, {'limit': 3})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['events'], [])

    def test_top_riskiest_materials_events_one_open_per_material(self):
        """Only the newest OPEN event per material is returned."""
        TestDataFactory.create_issue(material=self.material, status='OPEN')
        now = timezone.now()
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_id="SCE-OLDER",
            event_type="A",
            start_date=now - timezone.timedelta(days=5),
        )
        newer = TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_id="SCE-NEWER",
            event_type="B",
            start_date=now - timezone.timedelta(days=1),
        )

        url = reverse('supply_chain_events:top-riskiest-materials-events')
        response = self.client.get(url, {'limit': 3})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['events']), 1)
        self.assertEqual(response.data['events'][0]['id'], newer.id)

    def test_pagination(self):
        """Test that pagination works correctly."""
        # Create more events than default page size
        for i in range(5):
            TestDataFactory.create_supply_chain_event(
                event_id=f"PAGE-TEST-{i:03d}",
                material=self.material
            )

        url = reverse('supply_chain_events:event-list')
        response = self.client.get(url, {'limit': 2})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 2)
        self.assertIn('next', response.data)

    def test_events_by_material_returns_only_that_material(self):
        """Endpoint should return events scoped to the given mat_nbr."""
        other_material = TestDataFactory.create_material(vendor=self.vendor)
        TestDataFactory.create_supply_chain_event(material=self.material)
        TestDataFactory.create_supply_chain_event(material=self.material)
        TestDataFactory.create_supply_chain_event(material=other_material)

        url = reverse(
            'supply_chain_events:events-by-material',
            kwargs={'mat_nbr': self.material.mat_nbr},
        )
        response = self.client.get(url, {'limit': 50})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 2)
        for event in response.data['results']:
            self.assertEqual(event['mat_nbr']['mat_nbr'], self.material.mat_nbr)

    def test_events_by_material_unknown_returns_empty_list(self):
        """Unknown mat_nbr should return 404."""
        url = reverse(
            'supply_chain_events:events-by-material',
            kwargs={'mat_nbr': 'NON-EXISTENT-MAT'},
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 0)

    def test_events_by_material_status_filter(self):
        """Status query param should filter events by status."""
        TestDataFactory.create_supply_chain_event(material=self.material, status='OPEN')
        TestDataFactory.create_supply_chain_event(material=self.material, status='OPEN')
        TestDataFactory.create_supply_chain_event(material=self.material, status='CLOSED')

        url = reverse(
            'supply_chain_events:events-by-material',
            kwargs={'mat_nbr': self.material.mat_nbr},
        )
        response = self.client.get(url, {'status': 'OPEN', 'limit': 50})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 2)
        for event in response.data['results']:
            self.assertEqual(event['status'], 'OPEN')

    def test_events_by_material_date_range_filter(self):
        """start_date and end_date params bound the event's start_date inclusively."""
        now = timezone.now()
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            start_date=now - timezone.timedelta(days=10),
        )
        inside = TestDataFactory.create_supply_chain_event(
            material=self.material,
            start_date=now - timezone.timedelta(days=3),
        )
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            start_date=now + timezone.timedelta(days=1),
        )

        url = reverse(
            'supply_chain_events:events-by-material',
            kwargs={'mat_nbr': self.material.mat_nbr},
        )
        response = self.client.get(
            url,
            {
                'start_date': (now - timezone.timedelta(days=5)).isoformat(),
                'end_date': now.isoformat(),
                'limit': 50,
            },
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['results'][0]['id'], inside.id)

    def test_events_by_material_default_ordering_newest_first(self):
        """Default ordering should return newest event by start_date first."""
        now = timezone.now()
        TestDataFactory.create_supply_chain_event(
            material=self.material,
            start_date=now - timezone.timedelta(days=5),
        )
        newest = TestDataFactory.create_supply_chain_event(
            material=self.material,
            start_date=now - timezone.timedelta(hours=1),
        )

        url = reverse(
            'supply_chain_events:events-by-material',
            kwargs={'mat_nbr': self.material.mat_nbr},
        )
        response = self.client.get(url, {'limit': 50})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['results'][0]['id'], newest.id)

    def test_event_by_issue_returns_linked_event(self):
        """Issue event_id + material should resolve the matching supply chain event."""
        import uuid
        event_id = f"ISSUE-LINK-{uuid.uuid4().hex[:8]}"
        event = TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_id=event_id,
        )
        issue = TestDataFactory.create_issue(
            material=self.material,
            event_id=event_id,
        )

        url = reverse(
            'supply_chain_events:event-by-issue',
            kwargs={'issue_id': issue.id},
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['id'], event.id)
        self.assertEqual(response.data['event_id'], event_id)
        self.assertEqual(response.data['mat_nbr']['mat_nbr'], self.material.mat_nbr)
        self.assertIn('related_events', response.data)

    def test_event_by_issue_includes_related_events(self):
        """Detail response resolves the event for an issue by its unique event_id.

        event_id is now unique, so related_events is empty (retained for the
        upcoming API-phase rework)."""
        import uuid
        event_id = f"SHARED-ISSUE-{uuid.uuid4().hex[:8]}"
        event = TestDataFactory.create_supply_chain_event(
            material=self.material,
            event_id=event_id,
        )
        issue = TestDataFactory.create_issue(
            material=self.material,
            event_id=event_id,
        )

        url = reverse(
            'supply_chain_events:event-by-issue',
            kwargs={'issue_id': issue.id},
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['id'], event.id)
        self.assertEqual(response.data['related_events'], [])

    def test_event_by_issue_unknown_issue_returns_404(self):
        """Unknown issue_id should return 404."""
        url = reverse(
            'supply_chain_events:event-by-issue',
            kwargs={'issue_id': 99999},
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertEqual(response.data['error'], 'Issue not found')

    def test_event_by_issue_without_event_id_returns_404(self):
        """Issue without event_id should return 404."""
        issue = TestDataFactory.create_issue(
            material=self.material,
            event_id=None,
        )

        url = reverse(
            'supply_chain_events:event-by-issue',
            kwargs={'issue_id': issue.id},
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertEqual(response.data['error'], 'Issue has no linked event_id')

    def test_event_by_issue_no_matching_event_returns_404(self):
        """Issue with event_id that has no supply chain row should return 404."""
        issue = TestDataFactory.create_issue(
            material=self.material,
            event_id='NONEXISTENT-EVENT-ID',
        )

        url = reverse(
            'supply_chain_events:event-by-issue',
            kwargs={'issue_id': issue.id},
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertEqual(response.data['error'], 'Supply chain event not found for issue')
