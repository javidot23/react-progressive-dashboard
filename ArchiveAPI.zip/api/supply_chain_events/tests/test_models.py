from django.utils import timezone

from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory
from api.supply_chain_events.models import SupplyChainEvent


class SupplyChainEventModelTest(BaseTestCase):
    """Test SupplyChainEvent model."""

    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.material = TestDataFactory.create_material(vendor=self.vendor)

    def test_create_event_with_required_fields(self):
        """Test creating an event with only required fields."""
        event = SupplyChainEvent.objects.create(
            event_id="TEST-001",
            mat_nbr=self.material,
            type="SHIPMENT_DELAY",
            status=SupplyChainEvent.EventStatus.OPEN,
            start_date=timezone.now()
        )

        self.assertEqual(event.event_id, "TEST-001")
        self.assertEqual(event.type, "SHIPMENT_DELAY")
        self.assertEqual(event.status, SupplyChainEvent.EventStatus.OPEN)
        self.assertIsNotNone(event.created_at)
        self.assertIsNotNone(event.updated_at)

    def test_event_with_location_data(self):
        """Test creating an event with latitude and longitude."""
        event = SupplyChainEvent.objects.create(
            event_id="TEST-002",
            mat_nbr=self.material,
            type="NATURAL_DISASTER",
            status=SupplyChainEvent.EventStatus.OPEN,
            start_date=timezone.now(),
            latitude=40.7128,
            longitude=-74.0060
        )

        self.assertIsNotNone(event.latitude)
        self.assertIsNotNone(event.longitude)
        self.assertEqual(event.latitude, 40.7128)
        self.assertEqual(event.longitude, -74.0060)

    def test_event_string_representation(self):
        """Test the string representation of an event."""
        event = TestDataFactory.create_supply_chain_event(
            event_id="TEST-003",
            material=self.material,
            event_type="QUALITY_ISSUE",
            status="OPEN"
        )

        expected = "TEST-003 - QUALITY_ISSUE (OPEN)"
        self.assertEqual(str(event), expected)

    def test_event_ordering(self):
        """Test that events are ordered by start_date descending."""
        TestDataFactory.create_supply_chain_event(
            event_id="TEST-004",
            material=self.material,
            start_date=timezone.now() - timezone.timedelta(days=2)
        )
        TestDataFactory.create_supply_chain_event(
            event_id="TEST-005",
            material=self.material,
            start_date=timezone.now() - timezone.timedelta(days=1)
        )
        TestDataFactory.create_supply_chain_event(
            event_id="TEST-006",
            material=self.material,
            start_date=timezone.now()
        )

        events = SupplyChainEvent.objects.all()
        self.assertEqual(events[0].event_id, "TEST-006")
        self.assertEqual(events[1].event_id, "TEST-005")
        self.assertEqual(events[2].event_id, "TEST-004")

    def test_event_id_is_unique(self):
        """event_id is now unique: events live at their original granularity and
        are no longer duplicated per material."""
        from django.db.utils import IntegrityError

        TestDataFactory.create_supply_chain_event(
            event_id="SHARED-EVENT",
            material=self.material
        )

        material2 = TestDataFactory.create_material(vendor=self.material.vendor)
        with self.assertRaises(IntegrityError):
            TestDataFactory.create_supply_chain_event(
                event_id="SHARED-EVENT",
                material=material2
            )

    def test_cascade_delete_with_material(self):
        """Test that events are deleted when material is deleted."""
        event = TestDataFactory.create_supply_chain_event(
            material=self.material
        )

        event_id = event.id
        self.material.delete()

        self.assertFalse(
            SupplyChainEvent.objects.filter(id=event_id).exists()
        )
