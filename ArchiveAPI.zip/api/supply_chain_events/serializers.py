from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers
from api.material.serializers import MaterialSerializer
from api.serializer_mixins import NanSafeSerializerMixin
from .models import SupplyChainEvent


class SupplyChainEventListSerializer(NanSafeSerializerMixin, serializers.ModelSerializer):
    """Serializer for list view with nested material data."""
    mat_nbr = MaterialSerializer(read_only=True)

    class Meta:
        model = SupplyChainEvent
        fields = [
            "id",
            "event_id",
            "type",
            "type_description",
            "status",
            "start_date",
            "end_date",
            "latitude",
            "longitude",
            "city",
            "state",
            "country",
            "mat_nbr",
            "metadata",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ("id", "created_at", "updated_at")


class SupplyChainEventDetailSerializer(NanSafeSerializerMixin, serializers.ModelSerializer):
    """
    Serializer for detail view with additional related events for the same event_id.
    """
    mat_nbr = MaterialSerializer(read_only=True)
    related_events = serializers.SerializerMethodField()

    class Meta:
        model = SupplyChainEvent
        fields = [
            "id",
            "event_id",
            "type",
            "type_description",
            "status",
            "start_date",
            "end_date",
            "latitude",
            "longitude",
            "city",
            "state",
            "country",
            "mat_nbr",
            "metadata",
            "created_at",
            "updated_at",
            "related_events",
        ]
        read_only_fields = ("id", "created_at", "updated_at")

    @extend_schema_field(SupplyChainEventListSerializer(many=True))
    def get_related_events(self, obj):
        """Get other materials that have events with the same event_id."""
        related = SupplyChainEvent.objects.filter(
            event_id=obj.event_id
        ).exclude(
            id=obj.id
        ).select_related('mat_nbr__vendor')

        # Use the list serializer for nested representation
        return SupplyChainEventListSerializer(related, many=True).data


class SupplyChainEventMinimalSerializer(NanSafeSerializerMixin, serializers.ModelSerializer):
    """Minimal serializer for events without nested material (just mat_nbr string)."""
    mat_nbr = serializers.CharField(source='mat_nbr.mat_nbr', read_only=True)
    scrm_mat_grp = serializers.CharField(source='mat_nbr.scrm_mat_grp', read_only=True)

    class Meta:
        model = SupplyChainEvent
        fields = [
            "id",
            "event_id",
            "type",
            "type_description",
            "status",
            "start_date",
            "end_date",
            "latitude",
            "longitude",
            "city",
            "state",
            "country",
            "mat_nbr",
            "metadata",
            "created_at",
            "updated_at",
            "scrm_mat_grp"
        ]
        read_only_fields = ("id", "created_at", "updated_at")


class TopRiskiestMaterialsEventsSerializer(NanSafeSerializerMixin, serializers.Serializer):
    """
    Serializer for events related to top riskiest materials.

    Returns OPEN supply chain events with minimal data (mat_nbr as string
    reference): at most one event per top material, newest first.
    """
    events = SupplyChainEventMinimalSerializer(many=True, read_only=True)
