from django.apps import AppConfig


class FilterRangesConfig(AppConfig):
    name = "api.filter_ranges"
    verbose_name = "Filter Ranges"
