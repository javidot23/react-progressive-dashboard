from rest_framework import serializers


class FilterRangeEntrySerializer(serializers.Serializer):
    min = serializers.FloatField()
    max = serializers.FloatField()


class FilterRangesResponseSerializer(serializers.Serializer):
    module = serializers.CharField()
    ranges = serializers.DictField(child=FilterRangeEntrySerializer())
