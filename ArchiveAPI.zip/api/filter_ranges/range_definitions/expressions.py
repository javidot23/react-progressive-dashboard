"""Reusable Django ORM expressions for per-PO purchase-history maxes."""
from django.db.models import Case, ExpressionWrapper, F, FloatField, Value, When
from django.db.models.functions import Coalesce


PO_DEFICIT_EXPR = ExpressionWrapper(
    Coalesce(F("original_order_qty"), Value(0)) - Coalesce(F("received_qty"), Value(0)),
    output_field=FloatField(),
)

PO_INBOUND_FILL_RATE_EXPR = ExpressionWrapper(
    F("received_qty") * 1.0 / F("original_order_qty"),
    output_field=FloatField(),
)

# Project ``received_qty`` only when the matching flag is set; lets the batched
# aggregate filter per-key without pre-filtering the shared queryset.
PO_RECEIVED_QTY_ON_TIME_EXPR = Case(
    When(buffered_ot_flag=True, then=F("received_qty")),
    default=Value(None),
    output_field=FloatField(),
)

PO_RECEIVED_QTY_LATE_EXPR = Case(
    When(buffered_late_flag=True, then=F("received_qty")),
    default=Value(None),
    output_field=FloatField(),
)
