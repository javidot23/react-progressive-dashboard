"""Module + filter-key → max-value calculations for the dynamic range slider endpoint.

Each module page can ask ``/filter-ranges/?module=<name>`` to get the live max
for every range slider on that page. The frontend uses these values to size the
sliders so they always match the data currently shown.

Layout:
    * :mod:`.definition` — ``RangeDefinition`` dataclass + numeric helpers.
    * :mod:`.expressions` — reusable Django ORM expressions.
    * :mod:`.modules` — one file per module; each exports ``DEFINITIONS`` and
      optionally ``AGGREGATE_GROUPS``.
    * :mod:`.registry` — assembles the per-module pieces into the public
      ``MODULE_RANGE_DEFINITIONS`` and ``MODULE_AGGREGATE_GROUPS`` registries.

When you add a new range slider, register it in the relevant ``modules/``
file; do NOT hardcode the max in the frontend.
"""
from .definition import RangeDefinition
from .registry import (
    MODULE_AGGREGATE_GROUPS,
    MODULE_RANGE_DEFINITIONS,
    known_keys,
    known_modules,
)

__all__ = [
    "MODULE_AGGREGATE_GROUPS",
    "MODULE_RANGE_DEFINITIONS",
    "RangeDefinition",
    "known_keys",
    "known_modules",
]
