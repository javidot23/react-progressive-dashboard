"""``RangeDefinition`` dataclass and the small numeric helpers shared by every module."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from django.db.models import Max, QuerySet


@dataclass(frozen=True)
class RangeDefinition:
    """Declarative description of a range slider's max calculation.

    Attributes:
        compute:   Callable that receives the DRF ``request`` and returns the
                   raw max value or ``None`` when no data exists. Always required;
                   doubles as the fallback when a batched aggregate fails.
        cast:      ``"int"`` (default) or ``"float"`` — how the value is exposed
                   in the JSON response. ``int`` is ceil'd so the slider track
                   always reaches the highest data point.
        transform: Optional callable applied after ``compute`` and before
                   ``cast``. Use it to scale percentages from 0–1 → 0–100, etc.
        label:     Human-readable label for documentation/debugging only.
        aggregate_group:
                   Optional batch-aggregate group name. When set on multiple
                   keys in the same module, the service runs a single
                   ``aggregate(...)`` call against the shared queryset (looked
                   up in :data:`MODULE_AGGREGATE_GROUPS`) instead of one query
                   per key. Falls back to ``compute`` per key on any error.
        aggregate_field:
                   Field name or ORM expression used inside ``Max(...)`` for
                   the batched aggregate. Required when ``aggregate_group`` is set.
    """

    compute: Callable[[object], Optional[float]]
    cast: str = "int"
    transform: Optional[Callable[[float], float]] = None
    label: str = ""
    aggregate_group: Optional[str] = None
    aggregate_field: Optional[object] = None

    def __post_init__(self) -> None:
        if self.cast not in {"int", "float"}:
            raise ValueError(f"cast must be 'int' or 'float', got {self.cast!r}")
        if self.aggregate_group is not None and self.aggregate_field is None:
            raise ValueError(
                "aggregate_field is required when aggregate_group is set"
            )


def safe_max(queryset: QuerySet, field_expression) -> Optional[float]:
    """``Max`` over ``queryset`` — ``None`` for empty querysets, NULLs ignored."""
    return queryset.aggregate(_max=Max(field_expression))["_max"]


def scale_percent(value: float) -> float:
    """0–1 fraction → 0–100 percentage (UI sliders use 0–100)."""
    return value * 100


# Reusable preset for percentages stored as 0–1 fractions.
PERCENT_FRACTION = dict(transform=scale_percent, cast="int")
