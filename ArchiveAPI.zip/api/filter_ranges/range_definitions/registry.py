"""Module registries assembled from the per-module files in ``modules/``.

When you add a new range slider in the UI, register it inside the appropriate
``modules/<name>.py`` file (or add a new one) and append it here. Do NOT
hardcode the max in the frontend.
"""
from typing import Callable, Dict

from .definition import RangeDefinition
from .modules import (
    all_issues,
    failed_scans,
    inventory,
    issue,
    issue_impacted_materials,
    material,
    order_issue,
    product_family,
    purchase_history,
    purchase_order,
    quarantine_sgtin,
    vendor_plan,
    vendor_scorecard,
)


MODULE_RANGE_DEFINITIONS: Dict[str, Dict[str, RangeDefinition]] = {
    "issue": issue.DEFINITIONS,
    "all_issues": all_issues.DEFINITIONS,
    "issue_impacted_materials": issue_impacted_materials.DEFINITIONS,
    "material": material.DEFINITIONS,
    "inventory": inventory.DEFINITIONS,
    "purchase_history": purchase_history.DEFINITIONS,
    "purchase_order": purchase_order.DEFINITIONS,
    "purchase_order_failed_scans": failed_scans.DEFINITIONS,
    "quarantine_sgtin": quarantine_sgtin.DEFINITIONS,
    "vendor_scorecard": vendor_scorecard.DEFINITIONS,
    "product_family": product_family.DEFINITIONS,
    "order_issue": order_issue.DEFINITIONS,
    "vendor_plan": vendor_plan.DEFINITIONS,
}


# ``(module, aggregate_group) → request → QuerySet``. The service layer runs a
# single ``Max(...)``-per-key ``.aggregate()`` against the shared queryset
# instead of one round-trip per key. The ``compute`` callable on each
# definition is preserved as a safety fallback if the batch query raises.
MODULE_AGGREGATE_GROUPS: Dict[str, Dict[str, Callable[[object], object]]] = {
    "purchase_order": purchase_order.AGGREGATE_GROUPS,
    "purchase_history": purchase_history.AGGREGATE_GROUPS,
    "purchase_order_failed_scans": failed_scans.AGGREGATE_GROUPS,
    "vendor_scorecard": vendor_scorecard.AGGREGATE_GROUPS,
    "vendor_plan": vendor_plan.AGGREGATE_GROUPS,
}


def known_modules() -> list[str]:
    return sorted(MODULE_RANGE_DEFINITIONS.keys())


def known_keys(module: str) -> list[str]:
    return sorted(MODULE_RANGE_DEFINITIONS.get(module, {}).keys())
