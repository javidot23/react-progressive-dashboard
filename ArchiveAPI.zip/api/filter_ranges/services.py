"""
Service layer for the dynamic filter-range endpoint.

The view is a thin shim around :func:`calculate_filter_ranges`. Tests should
exercise this function directly when possible — it is the canonical surface for
slider sizing.
"""
from __future__ import annotations

import logging
import math
from collections import defaultdict
from typing import Iterable, Optional

from django.db.models import Max

from .range_definitions import (
    MODULE_AGGREGATE_GROUPS,
    MODULE_RANGE_DEFINITIONS,
    RangeDefinition,
)

logger = logging.getLogger(__name__)


class UnknownModuleError(ValueError):
    """Raised when a caller asks for a module that has no registered ranges."""


def _coerce_max(raw: Optional[float], definition: RangeDefinition) -> float | int:
    """Apply the definition's transform/cast rules to a raw aggregated value.

    Centralising this keeps the rounding semantics consistent across modules:
        * money / counts (cast=int) → ``ceil`` so the slider always covers the
          highest data point even when storage uses floats.
        * percentages (cast=int after a 0–1 → 0–100 transform) → ``ceil``
          for the same reason.
        * raw floats (cast=float) preserved as Python floats.
    """
    if raw is None:
        return 0

    value: float = float(raw)
    if definition.transform is not None:
        value = float(definition.transform(value))

    if definition.cast == "int":
        return int(math.ceil(value)) if value > 0 else 0
    return value


def _compute_single(
    module: str,
    key: str,
    definition: RangeDefinition,
    request,
) -> dict[str, float | int]:
    """Run ``definition.compute(request)`` with the standard error envelope.

    Each slider is independent — a failing compute is logged and falls back
    to ``{"min": 0, "max": 0}`` so one bad query never breaks the whole
    page's filter UI.
    """
    try:
        raw = definition.compute(request)
    except Exception:
        logger.exception(
            "Failed to compute filter range max for module=%s key=%s",
            module,
            key,
        )
        return {"min": 0, "max": 0}
    return {"min": 0, "max": _coerce_max(raw, definition)}


def _run_batched_group(
    module: str,
    group: str,
    request,
    grouped_keys: list[tuple[str, RangeDefinition]],
) -> dict[str, dict[str, float | int]]:
    """Run a single ``aggregate(...)`` for all keys sharing ``group``.

    On any exception we log once and fall back to per-key ``compute`` so a
    misconfigured group can never take the whole module down. Per-key
    compute callables continue to provide the same error isolation they
    always had.
    """
    queryset_factory = MODULE_AGGREGATE_GROUPS[module][group]
    try:
        queryset = queryset_factory(request)
        aggregate_kwargs = {
            key: Max(definition.aggregate_field)
            for key, definition in grouped_keys
        }
        aggregated = queryset.aggregate(**aggregate_kwargs)
    except Exception:
        logger.exception(
            "Batched aggregate failed for module=%s group=%s — falling back "
            "to per-key compute callables",
            module,
            group,
        )
        return {
            key: _compute_single(module, key, definition, request)
            for key, definition in grouped_keys
        }

    out: dict[str, dict[str, float | int]] = {}
    for key, definition in grouped_keys:
        out[key] = {
            "min": 0,
            "max": _coerce_max(aggregated.get(key), definition),
        }
    return out


def calculate_filter_ranges(
    module: str,
    request,
    keys: Optional[Iterable[str]] = None,
) -> dict[str, dict[str, float | int]]:
    """Return ``{key: {"min": 0, "max": <value>}}`` for ``module``.

    Args:
        module:  Registered module name in ``MODULE_RANGE_DEFINITIONS``.
        request: DRF request — used for ``query_params`` (global filters,
                 ``threshold``, ``days``…) and ``user`` (custom-list ownership).
        keys:    Optional iterable of keys to compute. ``None`` means "all
                 registered keys for this module". Unknown keys are ignored.

    Raises:
        UnknownModuleError: when ``module`` is not registered. The view turns
                            this into a 400.
    """
    if module not in MODULE_RANGE_DEFINITIONS:
        raise UnknownModuleError(
            f"Unknown module {module!r}. Known modules: "
            f"{sorted(MODULE_RANGE_DEFINITIONS.keys())}"
        )

    definitions = MODULE_RANGE_DEFINITIONS[module]
    if keys is not None:
        requested = {k.strip() for k in keys if k and k.strip()}
        definitions = {k: v for k, v in definitions.items() if k in requested}

    # Split into batched groups + standalone keys so we can run one
    # ``aggregate(...)`` per shared queryset instead of one per key.
    module_groups = MODULE_AGGREGATE_GROUPS.get(module, {})
    batched: dict[str, list[tuple[str, RangeDefinition]]] = defaultdict(list)
    standalone: list[tuple[str, RangeDefinition]] = []
    for key, definition in definitions.items():
        if (
            definition.aggregate_group is not None
            and definition.aggregate_group in module_groups
        ):
            batched[definition.aggregate_group].append((key, definition))
        else:
            standalone.append((key, definition))

    out: dict[str, dict[str, float | int]] = {}
    for group, grouped_keys in batched.items():
        out.update(_run_batched_group(module, group, request, grouped_keys))
    for key, definition in standalone:
        out[key] = _compute_single(module, key, definition, request)

    # Preserve the registry insertion order in the response so the JSON
    # payload stays stable across batched/non-batched paths.
    return {key: out[key] for key in definitions if key in out}
