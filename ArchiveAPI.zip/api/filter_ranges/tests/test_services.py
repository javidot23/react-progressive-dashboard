"""Unit tests for the filter-range calculation service."""
from datetime import date, timedelta
from unittest import mock
from unittest.mock import MagicMock

from django.conf import settings
from django.utils import timezone
from rest_framework.test import APIRequestFactory

from api.filter_ranges import range_definitions as range_defs
from api.filter_ranges.range_definitions import RangeDefinition
from api.filter_ranges.services import (
    UnknownModuleError,
    _coerce_max,
    calculate_filter_ranges,
)
from tests.BaseTestCase import BaseTestCase, MVTestCase
from tests.TestDataFactory import TestDataFactory


class CoerceMaxTests(BaseTestCase):
    """Pure function — no DB required."""

    def test_none_becomes_zero(self):
        defn = RangeDefinition(compute=lambda r: None)
        self.assertEqual(_coerce_max(None, defn), 0)

    def test_int_cast_ceils(self):
        defn = RangeDefinition(compute=lambda r: 0, cast="int")
        self.assertEqual(_coerce_max(12.1, defn), 13)
        self.assertEqual(_coerce_max(12.0, defn), 12)

    def test_float_cast_preserves(self):
        defn = RangeDefinition(compute=lambda r: 0, cast="float")
        self.assertEqual(_coerce_max(12.5, defn), 12.5)

    def test_transform_runs_before_cast(self):
        defn = RangeDefinition(
            compute=lambda r: 0, cast="int", transform=lambda v: v * 100
        )
        # 0.92 → 92.0 → ceil → 92
        self.assertEqual(_coerce_max(0.92, defn), 92)
        # 0.921 → 92.1 → ceil → 93
        self.assertEqual(_coerce_max(0.921, defn), 93)

    def test_negative_int_clamped_to_zero(self):
        defn = RangeDefinition(compute=lambda r: 0, cast="int")
        self.assertEqual(_coerce_max(-5, defn), 0)


class CalculateFilterRangesTests(BaseTestCase):
    """Behaviour tests against real models, using TestDataFactory."""

    def setUp(self) -> None:
        self.factory = APIRequestFactory()

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        # DRF's request wrapper exposes ``query_params``; compute callables
        # only ever read from it, so use a thin shim around the raw GET.
        request.query_params = request.GET
        return request

    def test_unknown_module_raises(self):
        with self.assertRaises(UnknownModuleError):
            calculate_filter_ranges("not_a_module", self._request())

    def test_keys_filter_returns_only_requested(self):
        ranges = calculate_filter_ranges(
            "issue", self._request(), keys=["risk_score"]
        )
        self.assertEqual(set(ranges.keys()), {"risk_score"})

    def test_keys_filter_drops_unknown_silently(self):
        ranges = calculate_filter_ranges(
            "issue", self._request(), keys=["risk_score", "does_not_exist"]
        )
        self.assertEqual(set(ranges.keys()), {"risk_score"})

    def test_no_data_returns_zero_max(self):
        ranges = calculate_filter_ranges("issue", self._request())
        for _key, payload in ranges.items():
            self.assertEqual(payload["min"], 0)
            self.assertEqual(payload["max"], 0)


class IssueModuleRangesTests(BaseTestCase):
    """Issue ranges: risk_adjusted_value, dollars_at_risk, risk_score."""

    def setUp(self) -> None:
        self.factory = APIRequestFactory()

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def test_max_reflects_data(self):
        v1 = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.5, dollars_at_risk=1000.0
        )
        m2 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.92, dollars_at_risk=500.0
        )
        TestDataFactory.create_issue(material=m1)
        TestDataFactory.create_issue(material=m2)

        ranges = calculate_filter_ranges("issue", self._request())

        # risk_score: max(0.5, 0.92) → 92
        self.assertEqual(ranges["risk_score"]["max"], 92)
        # dollars_at_risk: max(1000, 500) → 1000
        self.assertEqual(ranges["dollars_at_risk"]["max"], 1000)
        # risk_adjusted_value: max(0.5*1000, 0.92*500) = max(500, 460) → 500
        self.assertEqual(ranges["risk_adjusted_value"]["max"], 500)

    def test_max_changes_when_data_changes(self):
        v1 = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.5, dollars_at_risk=100.0
        )
        TestDataFactory.create_issue(material=m1)

        first = calculate_filter_ranges(
            "issue", self._request(), keys=["risk_score"]
        )
        self.assertEqual(first["risk_score"]["max"], 50)

        m2 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.95, dollars_at_risk=100.0
        )
        TestDataFactory.create_issue(material=m2)

        second = calculate_filter_ranges(
            "issue", self._request(), keys=["risk_score"]
        )
        self.assertEqual(second["risk_score"]["max"], 95)

    def test_global_filter_applies(self):
        v1 = TestDataFactory.create_vendor()
        v2 = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.4, dollars_at_risk=10000.0
        )
        m2 = TestDataFactory.create_material(
            vendor=v2, risk_rating=0.9, dollars_at_risk=200.0
        )
        TestDataFactory.create_issue(material=m1)
        TestDataFactory.create_issue(material=m2)

        # Without filter: dollars_at_risk max = 10000
        all_ranges = calculate_filter_ranges(
            "issue", self._request(), keys=["dollars_at_risk"]
        )
        self.assertEqual(all_ranges["dollars_at_risk"]["max"], 10000)

        # With supplier filter on v2: only m2's data counts → 200
        v2_only = calculate_filter_ranges(
            "issue",
            self._request({"supplier": str(v2.id)}),
            keys=["dollars_at_risk"],
        )
        self.assertEqual(v2_only["dollars_at_risk"]["max"], 200)

    def test_closed_issues_excluded(self):
        v1 = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.5, dollars_at_risk=10000.0
        )
        from api.issue.models import Issue
        TestDataFactory.create_issue(material=m1, status=Issue.IssueStatus.CLOSED)

        ranges = calculate_filter_ranges(
            "issue", self._request(), keys=["dollars_at_risk"]
        )
        self.assertEqual(ranges["dollars_at_risk"]["max"], 0)

    def test_null_values_dont_break(self):
        v1 = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.5, dollars_at_risk=750.0
        )
        TestDataFactory.create_issue(material=m1)

        # An issue tied to a material with a null risk_rating must not raise.
        # The factory replaces ``None`` with a random value, so null the
        # column out explicitly afterwards.
        m2 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.1, dollars_at_risk=2000.0
        )
        m2.risk_rating = None
        m2.save(update_fields=["risk_rating"])
        TestDataFactory.create_issue(material=m2)

        ranges = calculate_filter_ranges("issue", self._request())
        # risk_adjusted_value uses Case() default 0.0 when risk_rating is null,
        # so the only non-zero value is 0.5 * 750 = 375
        self.assertEqual(ranges["risk_adjusted_value"]["max"], 375)
        self.assertEqual(ranges["dollars_at_risk"]["max"], 2000)


class MaterialModuleRangesTests(BaseTestCase):
    def setUp(self) -> None:
        self.factory = APIRequestFactory()

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def test_dollars_at_risk_max(self):
        v1 = TestDataFactory.create_vendor()
        TestDataFactory.create_material(vendor=v1, dollars_at_risk=1234.5)
        TestDataFactory.create_material(vendor=v1, dollars_at_risk=500.0)

        ranges = calculate_filter_ranges(
            "material", self._request(), keys=["dollars_at_risk"]
        )
        # ceil(1234.5) → 1235
        self.assertEqual(ranges["dollars_at_risk"]["max"], 1235)


class PurchaseOrderFailedScansRangesTests(BaseTestCase):
    """Range maxima for the PO failed-scans page."""

    def setUp(self) -> None:
        self.factory = APIRequestFactory()
        self.now = timezone.now()
        self.material = TestDataFactory.create_material()
        # Two failed scans on PO-A with two distinct scan_status values; one
        # success scan that must be ignored.
        TestDataFactory.create_inbound_serialization_scan(
            material=self.material,
            req_po_nbr="PO-A",
            req_created_date=self.now,
            pass_fail_status="Error",
            scan_status="SGTIN Not Found",
            req_epc_cd="EPC-1",
        )
        TestDataFactory.create_inbound_serialization_scan(
            material=self.material,
            req_po_nbr="PO-A",
            req_created_date=self.now,
            pass_fail_status="Error",
            scan_status="Lot Error",
            req_epc_cd="EPC-2",
        )
        TestDataFactory.create_inbound_serialization_scan(
            material=self.material,
            req_po_nbr="PO-A",
            req_created_date=self.now,
            pass_fail_status="Success",
            scan_status="Serialization Passed",
            req_epc_cd="EPC-3",
        )
        TestDataFactory.create_inbound_serialization_scan(
            material=self.material,
            req_po_nbr="PO-B",
            req_created_date=self.now,
            pass_fail_status="Error",
            scan_status="SGTIN Not Found",
            req_epc_cd="EPC-4",
        )

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def test_total_failed_scans_max(self):
        ranges = calculate_filter_ranges(
            "purchase_order_failed_scans",
            self._request(),
            keys=["total_failed_scans"],
        )
        # PO-A → 2 failed, PO-B → 1 failed, max = 2
        self.assertEqual(ranges["total_failed_scans"]["max"], 2)

    def test_old_records_excluded_with_days_param(self):
        TestDataFactory.create_inbound_serialization_scan(
            material=self.material,
            req_po_nbr="PO-OLD",
            req_created_date=self.now - timedelta(days=200),
            pass_fail_status="Error",
            scan_status="SGTIN Not Found",
            req_epc_cd="EPC-OLD-1",
        )
        TestDataFactory.create_inbound_serialization_scan(
            material=self.material,
            req_po_nbr="PO-OLD",
            req_created_date=self.now - timedelta(days=200),
            pass_fail_status="Error",
            scan_status="Lot Error",
            req_epc_cd="EPC-OLD-2",
        )
        TestDataFactory.create_inbound_serialization_scan(
            material=self.material,
            req_po_nbr="PO-OLD",
            req_created_date=self.now - timedelta(days=200),
            pass_fail_status="Error",
            scan_status="Lot Error",
            req_epc_cd="EPC-OLD-3",
        )

        # default 90-day window: max stays at 2
        default = calculate_filter_ranges(
            "purchase_order_failed_scans",
            self._request(),
            keys=["total_failed_scans"],
        )
        self.assertEqual(default["total_failed_scans"]["max"], 2)

        # Extend window: PO-OLD now has 3 failed scans
        wide = calculate_filter_ranges(
            "purchase_order_failed_scans",
            self._request({"days": "365"}),
            keys=["total_failed_scans"],
        )
        self.assertEqual(wide["total_failed_scans"]["max"], 3)


class QuarantineLeadTimeRangeTests(BaseTestCase):
    def setUp(self) -> None:
        self.factory = APIRequestFactory()

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def test_lead_time_max(self):
        material = TestDataFactory.create_material()
        TestDataFactory.create_quarantine_event(material=material, lead_time=10)
        TestDataFactory.create_quarantine_event(material=material, lead_time=42)
        TestDataFactory.create_quarantine_event(material=material, lead_time=7)

        ranges = calculate_filter_ranges(
            "quarantine_sgtin", self._request(), keys=["lead_time"]
        )
        self.assertEqual(ranges["lead_time"]["max"], 42)


class PurchaseOrderRangesTests(BaseTestCase):
    """Per-material unit-count and fill-rate slider maxima.

    The ``purchase_order`` module now sizes its sliders against the SAME
    per-material 90-day aggregate that ``MaterialOtifSummaryView`` produces
    for the "Purchase Orders by Material" table — so every assertion below
    sums multiple ``ServiceLevel`` rows per material and asserts the max
    falls on the material with the largest aggregate, not the largest
    single row.
    """

    def setUp(self) -> None:
        self.factory = APIRequestFactory()
        self.material_a = TestDataFactory.create_material()
        self.material_b = TestDataFactory.create_material()
        self.today = date.today()

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def _seed_service_level(
        self,
        material,
        *,
        days_ago,
        total_order_qty,
        total_received_qty,
        on_time_units,
        fill_rate,
    ):
        """Helper: insert a single ``ServiceLevel`` row inside the 90-day window.

        Each test seeds two rows per material so the assertions exercise the
        ``Sum``-then-``Max`` pipeline rather than collapsing to a single row.
        """
        return TestDataFactory.create_service_level(
            material=material,
            record_date=self.today - timedelta(days=days_ago),
            total_order_qty=total_order_qty,
            total_received_qty=total_received_qty,
            on_time_units=on_time_units,
            fill_rate=fill_rate,
        )

    def test_units_ordered_and_received_maxes(self):
        # Material A totals: ordered=700, received=580.
        # Material B totals: ordered=300, received=250.
        # Maxes therefore land on material A even though no single row hits
        # 700/580 — proving the slider uses the per-material aggregate.
        self._seed_service_level(
            self.material_a,
            days_ago=10,
            total_order_qty=200,
            total_received_qty=180,
            on_time_units=180,
            fill_rate=0.9,
        )
        self._seed_service_level(
            self.material_a,
            days_ago=20,
            total_order_qty=500,
            total_received_qty=400,
            on_time_units=400,
            fill_rate=0.8,
        )
        self._seed_service_level(
            self.material_b,
            days_ago=15,
            total_order_qty=300,
            total_received_qty=250,
            on_time_units=200,
            fill_rate=0.83,
        )

        ranges = calculate_filter_ranges(
            "purchase_order",
            self._request(),
            keys=["units_ordered", "units_received"],
        )
        self.assertEqual(ranges["units_ordered"]["max"], 700)
        self.assertEqual(ranges["units_received"]["max"], 580)

    def test_units_on_time_late_and_not_received(self):
        # Material A totals → on_time=180, received=300 (late=120),
        # ordered=400 (not_received=100).
        # Material B totals → on_time=350, received=500 (late=150),
        # ordered=900 (not_received=400).
        # The "Late = Received - OnTime" formula is checked implicitly by
        # the assertion against material B's larger 150 vs material A's 120.
        self._seed_service_level(
            self.material_a,
            days_ago=5,
            total_order_qty=200,
            total_received_qty=180,
            on_time_units=120,
            fill_rate=0.9,
        )
        self._seed_service_level(
            self.material_a,
            days_ago=25,
            total_order_qty=200,
            total_received_qty=120,
            on_time_units=60,
            fill_rate=0.6,
        )
        self._seed_service_level(
            self.material_b,
            days_ago=8,
            total_order_qty=400,
            total_received_qty=200,
            on_time_units=150,
            fill_rate=0.5,
        )
        self._seed_service_level(
            self.material_b,
            days_ago=40,
            total_order_qty=500,
            total_received_qty=300,
            on_time_units=200,
            fill_rate=0.6,
        )

        ranges = calculate_filter_ranges(
            "purchase_order",
            self._request(),
            keys=["units_on_time", "units_late", "units_not_received"],
        )
        # Material B has the larger on-time total (350 vs 180) and the
        # larger received-late total (150 vs 120) and the larger deficit
        # (400 vs 100).
        self.assertEqual(ranges["units_on_time"]["max"], 350)
        self.assertEqual(ranges["units_late"]["max"], 150)
        self.assertEqual(ranges["units_not_received"]["max"], 400)

    def test_inbound_fill_rate_scaled_to_percentage(self):
        # Fill-rate values are exact binary fractions so the avg → percent →
        # ceil pipeline lands on whole numbers (decimal-looking values like
        # ``0.85`` round-trip through Postgres as ``0.8500000000000001``
        # and ceil up by 1).
        # Material A avg = (0.5 + 0.75) / 2 = 0.625 → 62.5 → ceil 63.
        # Material B avg = (0.875 + 0.875) / 2 = 0.875 → 87.5 → ceil 88.
        # Max of the per-material averages is 88.
        self._seed_service_level(
            self.material_a,
            days_ago=5,
            total_order_qty=100,
            total_received_qty=50,
            on_time_units=50,
            fill_rate=0.5,
        )
        self._seed_service_level(
            self.material_a,
            days_ago=20,
            total_order_qty=100,
            total_received_qty=75,
            on_time_units=75,
            fill_rate=0.75,
        )
        self._seed_service_level(
            self.material_b,
            days_ago=10,
            total_order_qty=100,
            total_received_qty=87,
            on_time_units=87,
            fill_rate=0.875,
        )
        self._seed_service_level(
            self.material_b,
            days_ago=30,
            total_order_qty=100,
            total_received_qty=87,
            on_time_units=87,
            fill_rate=0.875,
        )

        ranges = calculate_filter_ranges(
            "purchase_order", self._request(), keys=["inbound_fill_rate"]
        )
        self.assertEqual(ranges["inbound_fill_rate"]["max"], 88)

    def test_only_last_90_days_contribute(self):
        """Rows older than 90 days mirror the page's 90-day window and
        must not push the slider max above the visible totals."""
        # In-window contribution: 250.
        self._seed_service_level(
            self.material_a,
            days_ago=10,
            total_order_qty=250,
            total_received_qty=200,
            on_time_units=200,
            fill_rate=0.8,
        )
        # Out-of-window: 9_999 must be ignored.
        self._seed_service_level(
            self.material_a,
            days_ago=200,
            total_order_qty=9_999,
            total_received_qty=9_000,
            on_time_units=9_000,
            fill_rate=0.9,
        )

        ranges = calculate_filter_ranges(
            "purchase_order", self._request(), keys=["units_ordered"]
        )
        self.assertEqual(ranges["units_ordered"]["max"], 250)


class PurchaseHistoryRangesTests(BaseTestCase):
    """``purchase_history`` reuses the same compute callables under PO-history slider keys."""

    def setUp(self) -> None:
        self.factory = APIRequestFactory()
        self.material = TestDataFactory.create_material()

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def test_history_keys_match_po_module_values(self):
        TestDataFactory.create_purchase_order(
            material=self.material, original_order_qty=400, received_qty=350,
            buffered_ot_flag=True,
        )
        TestDataFactory.create_purchase_order(
            material=self.material, original_order_qty=800, received_qty=600,
            buffered_late_flag=True,
        )
        ranges = calculate_filter_ranges(
            "purchase_history",
            self._request(),
            keys=[
                "po_units_ordered",
                "total_units_received",
                "po_units_on_time",
                "po_units_late",
                "po_units_not_received",
            ],
        )
        self.assertEqual(ranges["po_units_ordered"]["max"], 800)
        self.assertEqual(ranges["total_units_received"]["max"], 600)
        self.assertEqual(ranges["po_units_on_time"]["max"], 350)
        self.assertEqual(ranges["po_units_late"]["max"], 600)
        # 800 - 600 = 200 is the largest deficit.
        self.assertEqual(ranges["po_units_not_received"]["max"], 200)


class PerfectOrderLineRangeTests(BaseTestCase):
    def setUp(self) -> None:
        self.factory = APIRequestFactory()

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request


class FailureIsolationTests(BaseTestCase):
    """A failing key must never take the rest of the response down."""

    def setUp(self) -> None:
        self.factory = APIRequestFactory()

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def test_one_failing_compute_falls_back_to_zero(self):
        v1 = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.5, dollars_at_risk=200.0
        )
        TestDataFactory.create_issue(material=m1)

        # Inject a temporarily failing definition for ``risk_score`` so we
        # can prove ``dollars_at_risk`` still resolves correctly.
        original = range_defs.MODULE_RANGE_DEFINITIONS["issue"]["risk_score"]
        boom = RangeDefinition(
            compute=lambda _r: (_ for _ in ()).throw(RuntimeError("boom")),
            cast=original.cast,
            transform=original.transform,
            label=original.label,
        )
        with mock.patch.dict(
            range_defs.MODULE_RANGE_DEFINITIONS["issue"],
            {"risk_score": boom},
            clear=False,
        ):
            ranges = calculate_filter_ranges("issue", self._request())

        self.assertEqual(ranges["risk_score"], {"min": 0, "max": 0})
        self.assertEqual(ranges["dollars_at_risk"]["max"], 200)

    def test_batched_group_failure_falls_back_to_per_key_compute(self):
        """If the batched ``aggregate(...)`` raises, per-key compute callables
        must still produce correct numbers — the optimization is invisible to
        callers when it works and self-healing when it doesn't.
        """
        material = TestDataFactory.create_material()
        # Two ServiceLevel rows for the same material — the per-material sum
        # is what both the batched and the per-key paths must agree on.
        TestDataFactory.create_service_level(
            material=material,
            record_date=date.today() - timedelta(days=5),
            total_order_qty=200,
            total_received_qty=180,
            on_time_units=180,
            fill_rate=0.9,
        )
        TestDataFactory.create_service_level(
            material=material,
            record_date=date.today() - timedelta(days=15),
            total_order_qty=500,
            total_received_qty=400,
            on_time_units=400,
            fill_rate=0.8,
        )

        def _broken_factory(_request):
            class _BadQS:
                def aggregate(self, **_):
                    raise RuntimeError("simulated batch failure")

            return _BadQS()

        with mock.patch.dict(
            range_defs.MODULE_AGGREGATE_GROUPS["purchase_order"],
            {"material_summary": _broken_factory},
        ):
            ranges = calculate_filter_ranges(
                "purchase_order",
                self._request(),
                keys=["units_ordered", "units_received"],
            )
        # Per-key compute fallback yields the same per-material totals
        # (200 + 500 = 700 ordered; 180 + 400 = 580 received).
        self.assertEqual(ranges["units_ordered"]["max"], 700)
        self.assertEqual(ranges["units_received"]["max"], 580)


class BatchedAggregateParityTests(BaseTestCase):
    """The batched ``aggregate(...)`` path must match the per-key path."""

    def setUp(self) -> None:
        self.factory = APIRequestFactory()

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def test_purchase_order_batched_matches_per_key(self):
        material_a = TestDataFactory.create_material()
        material_b = TestDataFactory.create_material()
        # Fill-rate values are deliberately chosen as exact binary fractions
        # (1/8 and 7/8) so the avg → percent → ceil pipeline lands on a
        # whole number. Decimal-looking values like ``0.85`` round-trip
        # through Postgres as ``0.8500000000000001`` and ceil up to 86.
        # Material A: ordered=300, received=240, on_time=180, late=60,
        # not_received=60, fill_rate avg=0.875 → 87.5 → ceil 88.
        TestDataFactory.create_service_level(
            material=material_a,
            record_date=date.today() - timedelta(days=10),
            total_order_qty=100,
            total_received_qty=90,
            on_time_units=70,
            fill_rate=0.875,
        )
        TestDataFactory.create_service_level(
            material=material_a,
            record_date=date.today() - timedelta(days=20),
            total_order_qty=200,
            total_received_qty=150,
            on_time_units=110,
            fill_rate=0.875,
        )
        # Material B: ordered=500, received=350, on_time=300, late=50,
        # not_received=150, fill_rate avg=0.625 → 62.5 → ceil 63.
        TestDataFactory.create_service_level(
            material=material_b,
            record_date=date.today() - timedelta(days=5),
            total_order_qty=500,
            total_received_qty=350,
            on_time_units=300,
            fill_rate=0.625,
        )

        keys = [
            "units_ordered",
            "units_received",
            "units_on_time",
            "units_late",
            "units_not_received",
            "inbound_fill_rate",
        ]
        batched = calculate_filter_ranges(
            "purchase_order", self._request(), keys=keys
        )

        # Disable the batch path so we exercise the per-key compute callables
        # against the same data, then assert the two paths agree.
        with mock.patch.dict(
            range_defs.MODULE_AGGREGATE_GROUPS, {"purchase_order": {}}
        ):
            single = calculate_filter_ranges(
                "purchase_order", self._request(), keys=keys
            )

        self.assertEqual(batched, single)
        # Material B wins ordered/on_time; material A wins late (60 vs 50);
        # material B wins not_received and material A wins fill_rate (avg
        # 0.875 → 87.5 → ceil 88).
        self.assertEqual(batched["units_ordered"]["max"], 500)
        self.assertEqual(batched["units_received"]["max"], 350)
        self.assertEqual(batched["units_on_time"]["max"], 300)
        self.assertEqual(batched["units_late"]["max"], 60)
        self.assertEqual(batched["units_not_received"]["max"], 150)
        self.assertEqual(batched["inbound_fill_rate"]["max"], 88)

    def test_purchase_order_batched_runs_one_query(self):
        """Six keys → a single DB hit on the batched path."""
        material = TestDataFactory.create_material()
        TestDataFactory.create_service_level(
            material=material,
            record_date=date.today() - timedelta(days=5),
            total_order_qty=10,
            total_received_qty=10,
            on_time_units=10,
            fill_rate=1.0,
        )

        keys = [
            "units_ordered",
            "units_received",
            "units_on_time",
            "units_late",
            "units_not_received",
            "inbound_fill_rate",
        ]
        with self.assertNumQueries(1, using=settings.TEST_TENANT_DB_ALIAS):
            calculate_filter_ranges("purchase_order", self._request(), keys=keys)


class AllIssuesModuleRangesTests(MVTestCase):
    """Grain-aware ranges for the /issue/all/ endpoint."""

    def setUp(self) -> None:
        self.factory = APIRequestFactory()
        self.vendor = TestDataFactory.create_vendor()
        self.m1 = TestDataFactory.create_material(
            vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1", risk_rating=0.4, dollars_at_risk=100.0
        )
        self.m2 = TestDataFactory.create_material(
            vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1", risk_rating=0.6, dollars_at_risk=300.0
        )

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def test_effective_maxes_reflect_grain_rollup(self):
        TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1)  # rar 40, count 1
        TestDataFactory.create_issue(issue_nbr="GCN-ISS", fdb_gcn_seq_nbr="GCN-1")  # avg .5*sum 400=200, count 2

        ranges = calculate_filter_ranges("all_issues", self._request())

        self.assertEqual(ranges["effective_risk_adjusted_value"]["max"], 200)
        self.assertEqual(ranges["effective_dollars_at_risk"]["max"], 400)
        self.assertEqual(ranges["effective_risk_rating"]["max"], 50)  # 0.5 -> 50
        self.assertEqual(ranges["impacted_material_count"]["max"], 2)

    def test_granularity_type_param_scopes_ranges(self):
        TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1)  # rar 40
        TestDataFactory.create_issue(issue_nbr="GCN-ISS", fdb_gcn_seq_nbr="GCN-1")  # rar 200

        material_only = calculate_filter_ranges(
            "all_issues",
            self._request({"granularity_type": "material"}),
            keys=["effective_risk_adjusted_value"],
        )
        self.assertEqual(material_only["effective_risk_adjusted_value"]["max"], 40)


class IssueImpactedMaterialsModuleRangesTests(BaseTestCase):
    """Per-issue impacted-materials ranges, scoped by ?issue_id=."""

    def setUp(self) -> None:
        self.factory = APIRequestFactory()
        self.vendor = TestDataFactory.create_vendor()
        self.m1 = TestDataFactory.create_material(
            vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1", risk_rating=0.4, dollars_at_risk=100.0
        )
        self.m2 = TestDataFactory.create_material(
            vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1", risk_rating=0.6, dollars_at_risk=300.0
        )
        self.issue = TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-1")

    def _request(self, params=None):
        request = self.factory.get("/filter-ranges/", params or {})
        request.user = MagicMock(entra_id=None)
        request.query_params = request.GET
        return request

    def test_maxes_over_grain_materials(self):
        ranges = calculate_filter_ranges(
            "issue_impacted_materials", self._request({"issue_id": str(self.issue.id)})
        )
        self.assertEqual(ranges["risk_adjusted_value"]["max"], 180)  # 0.6 * 300
        self.assertEqual(ranges["dollars_at_risk"]["max"], 300)
        self.assertEqual(ranges["risk_score"]["max"], 60)  # 0.6 -> 60

    def test_missing_issue_id_returns_zero(self):
        ranges = calculate_filter_ranges("issue_impacted_materials", self._request())
        for payload in ranges.values():
            self.assertEqual(payload["max"], 0)
