"""Integration tests for the /filter-ranges/ HTTP endpoint."""
from django.urls import reverse
from rest_framework import status

from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class FilterRangesEndpointTests(BaseAPITestCase):
    """Smoke + behavioural tests against the registered URL."""

    def setUp(self) -> None:
        self.url = reverse("filter_ranges:filter-ranges")

    def test_missing_module_returns_400(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("known_modules", response.data)

    def test_unknown_module_returns_400(self):
        response = self.client.get(self.url, {"module": "totally_made_up"})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("known_modules", response.data)

    def test_no_data_returns_zero_max(self):
        response = self.client.get(self.url, {"module": "issue"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["module"], "issue")
        for key, payload in response.data["ranges"].items():
            self.assertEqual(payload["min"], 0, f"min for {key} should be 0")
            self.assertEqual(payload["max"], 0, f"max for {key} should be 0")

    def test_response_shape(self):
        v1 = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.6, dollars_at_risk=100.0
        )
        TestDataFactory.create_issue(material=m1)

        response = self.client.get(self.url, {"module": "issue"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("ranges", response.data)
        self.assertIn("risk_score", response.data["ranges"])
        for payload in response.data["ranges"].values():
            self.assertIn("min", payload)
            self.assertIn("max", payload)
            self.assertEqual(payload["min"], 0)

    def test_keys_param_filters_response(self):
        v1 = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.6, dollars_at_risk=100.0
        )
        TestDataFactory.create_issue(material=m1)

        response = self.client.get(
            self.url, {"module": "issue", "keys": "risk_score"}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(set(response.data["ranges"].keys()), {"risk_score"})
        self.assertEqual(response.data["ranges"]["risk_score"]["max"], 60)

    def test_max_respects_active_filters(self):
        v1 = TestDataFactory.create_vendor()
        v2 = TestDataFactory.create_vendor()
        m1 = TestDataFactory.create_material(
            vendor=v1, risk_rating=0.4, dollars_at_risk=10000.0
        )
        m2 = TestDataFactory.create_material(
            vendor=v2, risk_rating=0.9, dollars_at_risk=200.0
        )
        TestDataFactory.create_issue(material=m1)
        TestDataFactory.create_issue(material=m2)

        unfiltered = self.client.get(
            self.url, {"module": "issue", "keys": "dollars_at_risk"}
        )
        self.assertEqual(unfiltered.data["ranges"]["dollars_at_risk"]["max"], 10000)

        filtered = self.client.get(
            self.url,
            {
                "module": "issue",
                "keys": "dollars_at_risk",
                "supplier": str(v2.id),
            },
        )
        self.assertEqual(filtered.data["ranges"]["dollars_at_risk"]["max"], 200)

    def test_empty_keys_param_returns_no_keys(self):
        # ``?keys=`` (empty) should be treated as "no keys requested" (so
        # we don't accidentally fall back to "all keys").
        response = self.client.get(
            self.url, {"module": "issue", "keys": ""}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["ranges"], {})
