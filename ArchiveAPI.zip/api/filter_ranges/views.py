"""HTTP layer for the dynamic filter-range endpoint.

Parsing and response shaping only — numeric work lives in
:mod:`api.filter_ranges.services`.
"""
from __future__ import annotations

import logging

from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema, extend_schema_view

from .range_definitions import known_modules
from .serializers import FilterRangesResponseSerializer
from .services import UnknownModuleError, calculate_filter_ranges


logger = logging.getLogger(__name__)


@method_decorator(
    cache_page(getattr(settings, "CACHE_MIDDLEWARE_SECONDS", 3600)),
    name="get",
)
@extend_schema_view(
    get=extend_schema(responses=FilterRangesResponseSerializer),
)
class FilterRangesView(APIView):
    """GET /filter-ranges/

    Return ``{"min": 0, "max": <number>}`` for every range slider on the
    requested page so the frontend can size its sliders against the data
    currently being displayed.

    Query params:
        module (required): Registered module name; see ``known_modules()``.
        keys (optional): Comma-separated subset to compute. ``?keys=`` with
            an empty value is treated as "no keys"; omit the param entirely
            to fetch all keys for the module.
        <global filters>: Forwarded to the same helpers the page uses
            (supplier, supplier_nbr, product_family, custom_list, …) so the
            slider max always matches the data on screen.

    Returns 400 when ``module`` is missing or unknown.
    """

    def get(self, request):
        module = request.query_params.get("module")
        if not module:
            return self._bad_request("Missing required query param 'module'.")

        keys = self._parse_keys(request.query_params.get("keys"))

        try:
            ranges = calculate_filter_ranges(module, request, keys=keys)
        except UnknownModuleError as exc:
            logger.warning("Unknown module in filter ranges request: %s", str(exc))
            return self._bad_request("Unknown module.")

        return Response({"module": module, "ranges": ranges})

    @staticmethod
    def _parse_keys(raw: str | None) -> list[str] | None:
        """``None`` means "all keys"; an explicit empty value means "none"."""
        if raw is None:
            return None
        return [key for key in raw.split(",") if key]

    @staticmethod
    def _bad_request(message: str) -> Response:
        return Response(
            {"error": message, "known_modules": known_modules()},
            status=status.HTTP_400_BAD_REQUEST,
        )
