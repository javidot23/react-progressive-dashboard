from django.urls import path

from .views import FilterRangesView

app_name = "filter_ranges"

urlpatterns = [
    path("", FilterRangesView.as_view(), name="filter-ranges"),
]
