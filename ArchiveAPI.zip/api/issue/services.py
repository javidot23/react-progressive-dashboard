import bisect
import logging
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.db.models import (
    Count, Exists, OuterRef, Q, Prefetch, F, FloatField, Case, When, Window,
    IntegerField, Value,
)
from django.db.models.functions import RowNumber, TruncWeek
from django.utils import timezone

from .granularity import annotate_issue_granularity
from .models import Issue
from ..action.models import Action
from ..issue_note.models import IssueNote
from ..material.models import Material
from ..material_value_at_risk_history.models import MaterialValueAtRiskHistory
from ..potential_action.models import PotentialAction
from ..vendor.models import Vendor

logger = logging.getLogger(__name__)


EXCLUDED_MATERIAL_Q = Q(material__drop_ship_flg=1) | Q(material__short_date_flg=1)


class IssueService:
    DEFAULT_TREND_DAYS = 90

    @staticmethod
    def get_weekly_open_issues():
        """Get open issues count for current and previous week."""
        today = timezone.now().date()

        # Calculate current week start (Monday)
        days_since_monday = today.weekday()
        current_week_start = today - timedelta(days=days_since_monday)
        current_week_end = current_week_start + timedelta(days=6)

        # Calculate previous week
        previous_week_start = current_week_start - timedelta(days=7)
        previous_week_end = previous_week_start + timedelta(days=6)

        # Count open issues for current week (distinct issue_nbr)
        current_week_count = Issue.objects.filter(
            status=Issue.IssueStatus.OPEN,
            start_date__gte=current_week_start,
            start_date__lte=current_week_end).exclude(
            material__xplant_mat_stat__in=[
                'DB',
                'DM']).exclude(EXCLUDED_MATERIAL_Q).values('issue_nbr').distinct().count()

        current_week_requires_action_count = (
            Issue.objects.filter(
                Q(status=Issue.IssueStatus.OPEN) &
                Q(start_date__gte=current_week_start) &
                Q(start_date__lte=current_week_end)
            )
            .exclude(material__xplant_mat_stat__in=['DB', 'DM'])
            .exclude(EXCLUDED_MATERIAL_Q)
            .values('issue_nbr')
            .distinct()
            .count()
        )

        # Count open issues for previous week (distinct issue_nbr)
        previous_week_count = Issue.objects.filter(
            status=Issue.IssueStatus.OPEN,
            start_date__gte=previous_week_start,
            start_date__lte=previous_week_end).exclude(
            material__xplant_mat_stat__in=[
                'DB',
                'DM']).exclude(EXCLUDED_MATERIAL_Q).values('issue_nbr').distinct().count()

        logger.info("Current week open issues: %s", current_week_count)
        logger.info("Previous week open issues: %s", previous_week_count)
        logger.info("Current week requires action issues: %s", current_week_requires_action_count)

        return {
            'current_week_count': current_week_count,
            'previous_week_count': previous_week_count,
            'week_start_date': current_week_start,
            'previous_week_start_date': previous_week_start,
            'current_week_requires_action_count': current_week_requires_action_count
        }

    @staticmethod
    def _apply_material_filter(queryset, direct_mat_nbr=None, mat_nbr_subquery=None):
        """Helper to apply material filters using optimized subquery pattern."""
        if direct_mat_nbr:
            queryset = queryset.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbr_subquery)
        return queryset

    @staticmethod
    def get_two_week_issues_summary(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get issues summary for current two weeks and previous two weeks.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        today = timezone.now().date()

        days_since_monday = today.weekday()
        current_period_start = today - timedelta(days=days_since_monday + 13)
        current_period_end = today

        previous_period_start = current_period_start - timedelta(days=14)
        previous_period_end = current_period_start - timedelta(days=1)

        # Current two weeks - total issues
        current_total_queryset = Issue.objects.filter(
            start_date__gte=current_period_start,
            start_date__lte=current_period_end
        ).exclude(material__xplant_mat_stat__in=['DB', 'DM']).exclude(EXCLUDED_MATERIAL_Q)
        current_total_queryset = IssueService._apply_material_filter(current_total_queryset, direct_mat_nbr,
                                                                     mat_nbr_subquery)
        current_total_issues = current_total_queryset.values('issue_nbr').distinct().count()

        # Current two weeks - opened issues
        current_opened_queryset = Issue.objects.filter(
            start_date__gte=current_period_start,
            start_date__lte=current_period_end,
            status=Issue.IssueStatus.OPEN
        ).exclude(material__xplant_mat_stat__in=['DB', 'DM']).exclude(EXCLUDED_MATERIAL_Q)
        current_opened_queryset = IssueService._apply_material_filter(current_opened_queryset, direct_mat_nbr,
                                                                      mat_nbr_subquery)
        current_opened_issues = current_opened_queryset.values('issue_nbr').distinct().count()

        # Current two weeks - closed issues
        current_closed_queryset = Issue.objects.filter(
            start_date__gte=current_period_start,
            start_date__lte=current_period_end,
            status=Issue.IssueStatus.CLOSED
        ).exclude(material__xplant_mat_stat__in=['DB', 'DM']).exclude(EXCLUDED_MATERIAL_Q)
        current_closed_queryset = IssueService._apply_material_filter(current_closed_queryset, direct_mat_nbr,
                                                                      mat_nbr_subquery)
        current_closed_issues = current_closed_queryset.values('issue_nbr').distinct().count()

        # Previous two weeks - total issues
        previous_total_queryset = Issue.objects.filter(
            start_date__gte=previous_period_start,
            start_date__lte=previous_period_end
        ).exclude(material__xplant_mat_stat__in=['DB', 'DM']).exclude(EXCLUDED_MATERIAL_Q)
        previous_total_queryset = IssueService._apply_material_filter(previous_total_queryset, direct_mat_nbr,
                                                                      mat_nbr_subquery)
        previous_total_issues = previous_total_queryset.values('issue_nbr').distinct().count()

        # Previous two weeks - opened issues
        previous_opened_queryset = Issue.objects.filter(
            start_date__gte=previous_period_start,
            start_date__lte=previous_period_end,
            status=Issue.IssueStatus.OPEN
        ).exclude(material__xplant_mat_stat__in=['DB', 'DM']).exclude(EXCLUDED_MATERIAL_Q)
        previous_opened_queryset = IssueService._apply_material_filter(previous_opened_queryset, direct_mat_nbr,
                                                                       mat_nbr_subquery)
        previous_opened_issues = previous_opened_queryset.values('issue_nbr').distinct().count()

        # Previous two weeks - closed issues
        previous_closed_queryset = Issue.objects.filter(
            start_date__gte=previous_period_start,
            start_date__lte=previous_period_end,
            status=Issue.IssueStatus.CLOSED
        ).exclude(material__xplant_mat_stat__in=['DB', 'DM']).exclude(EXCLUDED_MATERIAL_Q)
        previous_closed_queryset = IssueService._apply_material_filter(previous_closed_queryset, direct_mat_nbr,
                                                                       mat_nbr_subquery)
        previous_closed_issues = previous_closed_queryset.values('issue_nbr').distinct().count()

        return {
            'current_total_issues': current_total_issues,
            'current_opened_issues': current_opened_issues,
            'current_closed_issues': current_closed_issues,
            'previous_total_issues': previous_total_issues,
            'previous_opened_issues': previous_opened_issues,
            'previous_closed_issues': previous_closed_issues,
            'current_period_start': current_period_start,
            'current_period_end': current_period_end,
            'previous_period_start': previous_period_start,
            'previous_period_end': previous_period_end
        }

    @staticmethod
    def get_today_issues_snapshot(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get today's snapshot of Open Issues vs. Total Issues for issues that started today.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        today = timezone.now().date()

        # Total issues that started today (distinct issue_nbr)
        total_queryset = Issue.objects.filter(
            start_date=today
        ).exclude(material__xplant_mat_stat__in=['DB', 'DM']).exclude(EXCLUDED_MATERIAL_Q)
        total_queryset = IssueService._apply_material_filter(total_queryset, direct_mat_nbr, mat_nbr_subquery)
        total_issues = total_queryset.values('issue_nbr').distinct().count()

        open_queryset = Issue.objects.filter(
            start_date=today,
            status=Issue.IssueStatus.OPEN
        ).exclude(material__xplant_mat_stat__in=['DB', 'DM']).exclude(EXCLUDED_MATERIAL_Q)
        open_queryset = IssueService._apply_material_filter(open_queryset, direct_mat_nbr, mat_nbr_subquery)
        open_issues = open_queryset.values('issue_nbr').distinct().count()

        logger.info("Today's snapshot - Open issues: %s, Total issues: %s", open_issues, total_issues)

        return {
            'open_issues': open_issues,
            'total_issues': total_issues,
            'snapshot_date': today,
            'kpi_value': open_issues,
            'kpi_total': total_issues,
        }

    @staticmethod
    def get_country_issues():
        """Get countries with open issues and their vendors."""
        logger.info("Getting country-wise open issues data")

        # Get all active vendors with open issues, grouped by country, in a single query
        vendors_with_issues = Vendor.objects.filter(
            is_active=True,
            material__issue__status=Issue.IssueStatus.OPEN
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(
            Q(material__drop_ship_flg=1) | Q(material__short_date_flg=1)
        ).prefetch_related(
            Prefetch(
                'material_set',
                queryset=Material.objects.filter(
                    issue__status=Issue.IssueStatus.OPEN
                ).exclude(xplant_mat_stat__in=['DB', 'DM']).exclude(
                    Q(drop_ship_flg=1) | Q(short_date_flg=1)
                ).prefetch_related('issue_set')
            )
        ).annotate(
            open_issues_count=Count('material__issue__issue_nbr', distinct=True)
        ).exclude(
            country__isnull=True
        ).exclude(
            country=''
        ).distinct()

        # Group by country and collect distinct issue_nbr values
        country_dict = {}
        for vendor in vendors_with_issues:
            country_code = vendor.country

            if country_code not in country_dict:
                country_dict[country_code] = {
                    'country': country_code,
                    'country_name': vendor.country,
                    'issue_nbrs': set(),  # Track distinct issue_nbr values
                    'vendors': []
                }

            country_dict[country_code]['vendors'].append(vendor)
            # Collect distinct issue_nbr values from vendor's materials
            for material in vendor.material_set.all():
                for issue in material.issue_set.all():
                    if issue.status == Issue.IssueStatus.OPEN:
                        country_dict[country_code]['issue_nbrs'].add(issue.issue_nbr)

        # Convert sets to counts
        for country_data in country_dict.values():
            country_data['open_issues_count'] = len(country_data['issue_nbrs'])
            del country_data['issue_nbrs']  # Remove the set, keep only the count

        # Sort by issue count (descending)
        result = sorted(
            country_dict.values(),
            key=lambda x: x['open_issues_count'],
            reverse=True
        )

        logger.info("Returning data for %s countries", len(result))
        return result

    @staticmethod
    def get_top_riskiest_materials(limit=3, direct_mat_nbr=None, mat_nbr_subquery=None):
        """Get top riskiest materials with open issues. Supports global filters."""
        limit = min(limit, 10)
        logger.info("Getting top %s riskiest materials with open issues", limit)

        # Get materials with open issues, ordered by risk adjusted value (highest first)
        risky_materials = Material.objects.filter(
            issue__status=Issue.IssueStatus.OPEN
        ).exclude(xplant_mat_stat__in=['DB', 'DM']).exclude(
            Q(drop_ship_flg=1) | Q(short_date_flg=1)
        )

        # Apply material filters using optimized subquery pattern
        if direct_mat_nbr:
            risky_materials = risky_materials.filter(mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            risky_materials = risky_materials.filter(mat_nbr__in=mat_nbr_subquery)

        risky_materials = risky_materials.select_related('vendor').prefetch_related(
            Prefetch(
                'issue_set',
                queryset=Issue.objects.filter(status=Issue.IssueStatus.OPEN)
            )
        ).annotate(
            risk_adjusted_value=Case(
                When(
                    risk_rating__isnull=False,
                    dollars_at_risk__isnull=False,
                    then=F('risk_rating') * F('dollars_at_risk')
                ),
                default=0.0,
                output_field=FloatField()
            )
        ).distinct().order_by('-risk_adjusted_value')[:limit]

        return {
            'materials': risky_materials
        }

    @staticmethod
    def get_top_riskiest_vendors(limit=3):
        """Get top riskiest vendors with open issues."""
        limit = min(limit, 10)
        logger.info("Getting top %s riskiest vendors with open issues", limit)

        # Get active vendors with open issues, ordered by risk rating (highest first)
        risky_vendors = Vendor.objects.filter(
            is_active=True,
            material__issue__status=Issue.IssueStatus.OPEN
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(
            Q(material__drop_ship_flg=1) | Q(material__short_date_flg=1)
        ).prefetch_related(
            Prefetch(
                'material_set',
                queryset=Material.objects.filter(issue__status=Issue.IssueStatus.OPEN).exclude(
                    xplant_mat_stat__in=['DB', 'DM']).exclude(
                    Q(drop_ship_flg=1) | Q(short_date_flg=1))
            )
        ).exclude(
            risk_rating__isnull=True
        ).distinct().order_by('-risk_rating')[:limit]

        return {
            'vendors': risky_vendors
        }

    @staticmethod
    def _get_issues_with_material_and_actions_queryset(status=None):
        """Build issue queryset enriched with material and action relationships."""
        actions_prefetch = Prefetch(
            'actions',
            queryset=Action.objects.all().select_related(
                'potential_action',
                'material__vendor',
                'substituted_material',
                'substituted_material__vendor',
                'issue__material__vendor'
            ).order_by('-created_at'),
            to_attr='action_list'
        )

        queryset = (
            Issue.objects.all()
            .exclude(material__xplant_mat_stat__in=['DB', 'DM'])
            .exclude(EXCLUDED_MATERIAL_Q)
            .select_related('material__vendor')
            .prefetch_related(actions_prefetch)
            .annotate(
                risk_adjusted_value=Case(
                    When(
                        material__risk_rating__isnull=False,
                        material__dollars_at_risk__isnull=False,
                        then=F('material__risk_rating') *
                        F('material__dollars_at_risk')),
                    default=0.0,
                    output_field=FloatField())
            )
        )

        if status is not None:
            queryset = queryset.filter(status=status)

        return queryset

    @staticmethod
    def get_issues_with_material_and_actions():
        """Get open issues with their related material and actions."""
        logger.info("Getting issues with material and actions")
        return IssueService._get_issues_with_material_and_actions_queryset(
            status=Issue.IssueStatus.OPEN
        )

    @staticmethod
    def get_issue_with_material_and_actions(issue_id: int):
        """Get one issue with the same enrichments as the issue list."""
        logger.info("Getting issue %s with material and actions", issue_id)
        return IssueService._get_issues_with_material_and_actions_queryset().get(
            id=issue_id
        )

    @staticmethod
    def _all_issues_base_queryset():
        return Issue.objects.all().select_related('material__vendor', 'plant')

    @staticmethod
    def annotate_open_priority(queryset):
        """Annotate queryset so OPEN issues sort before non-open issues."""
        return queryset.annotate(
            open_priority=Case(
                When(status=Issue.IssueStatus.OPEN, then=Value(0)),
                default=Value(1),
                output_field=IntegerField(),
            )
        )

    @staticmethod
    def get_all_issues_list_queryset():
        """Issues at their original granularity with has_actions and grain-aware metrics."""
        queryset = IssueService._all_issues_base_queryset().annotate(
            has_actions=Exists(
                Action.objects.filter(issue_id=OuterRef('issue_nbr'))
            ),
        )
        return IssueService.annotate_open_priority(annotate_issue_granularity(queryset))

    @staticmethod
    def distinct_issues_by_material(queryset):
        """Keep one representative issue per material.

        Issues without a material are excluded. The representative issue has the
        highest effective_risk_adjusted_value, then the most recent start_date.
        """
        return queryset.filter(material_id__isnull=False).annotate(
            material_row_num=Window(
                expression=RowNumber(),
                partition_by=[F('material_id')],
                order_by=[
                    F('effective_risk_adjusted_value').desc(),
                    F('start_date').desc(),
                ],
            )
        ).filter(material_row_num=1)

    @staticmethod
    def get_all_issues_queryset():
        """Issues at their original granularity (any grain, any status), annotated
        with granularity_type and grain-aware effective metrics."""
        actions_prefetch = Prefetch(
            'actions',
            queryset=Action.objects.all().select_related(
                'potential_action',
                'material__vendor',
                'substituted_material',
                'substituted_material__vendor',
                'issue__material__vendor',
            ).order_by('-created_at'),
            to_attr='action_list',
        )

        queryset = IssueService._all_issues_base_queryset().prefetch_related(actions_prefetch)
        return annotate_issue_granularity(queryset)

    @staticmethod
    def get_issue_at_granularity(issue_id: int):
        """One issue at its original granularity with the same enrichments as the list."""
        return IssueService.get_all_issues_queryset().get(id=issue_id)

    @staticmethod
    def attach_events_to_issues(issues):
        """Attach the supply-chain event driving each issue (by unique event_id).

        Sets ``issue.driving_event`` (a SupplyChainEvent or None) on each issue in
        a single batched query.
        """
        if not issues:
            return

        from ..supply_chain_events.models import SupplyChainEvent

        event_ids = {issue.event_id for issue in issues if issue.event_id}
        events_by_id = {}
        if event_ids:
            events_by_id = {
                event.event_id: event
                for event in SupplyChainEvent.objects
                .select_related('mat_nbr__vendor')
                .filter(event_id__in=event_ids)
            }

        for issue in issues:
            issue.driving_event = events_by_id.get(issue.event_id) if issue.event_id else None

    @staticmethod
    def attach_potential_actions_to_issues(issues):
        """Manually attach potential actions to a list of issues."""
        if not issues:
            return

        issue_nbrs = [issue.issue_nbr for issue in issues]

        potential_actions = PotentialAction.objects.filter(issue_nbr__in=issue_nbrs)

        # Group by issue_nbr
        pa_dict = {}
        for pa in potential_actions:
            pa_dict.setdefault(pa.issue_nbr_id, []).append(pa)

        # Attach to issues
        for issue in issues:
            issue.potential_action_list = pa_dict.get(issue.issue_nbr, [])

    @staticmethod
    def attach_notes_to_issues(issues):
        """Attach `notes_count` and `last_note` to each issue in a single batch."""
        if not issues:
            return

        issue_ids = [issue.pk for issue in issues]

        counts = dict(
            IssueNote.objects
            .filter(issue_id__in=issue_ids)
            .values_list('issue_id')
            .annotate(n=Count('id'))
            .values_list('issue_id', 'n')
        )

        latest_notes = list(
            IssueNote.objects
            .filter(issue_id__in=issue_ids)
            .order_by('issue_id', '-created_at')
            .distinct('issue_id')
        )
        latest_by_issue = {note.issue_id: note for note in latest_notes}

        for issue in issues:
            issue.notes_count = counts.get(issue.pk, 0)
            issue.last_note = latest_by_issue.get(issue.pk)

    @staticmethod
    def get_user_cache_for_issues(issues):
        """Get user cache for a list of issues (actions and last note authors)."""
        all_user_ids = set()
        for issue in issues:
            for action in getattr(issue, 'action_list', []):
                if action.user_id:
                    all_user_ids.add(action.user_id)
            last_note = getattr(issue, 'last_note', None)
            if last_note is not None and last_note.user_id:
                all_user_ids.add(last_note.user_id)

        if all_user_ids:
            users = get_user_model().objects.only(
                "user_uuid", "first_name", "last_name"
            ).filter(user_uuid__in=all_user_ids)
            user_cache = {
                str(user.pk): {
                    "id": str(user.pk),
                    "first_name": user.first_name,
                    "last_name": user.last_name,
                    "email": user.email,
                }
                for user in users
            }
        else:
            user_cache = {}

        return user_cache

    @staticmethod
    def _week_start(d):
        """Return Monday of the week containing date d."""
        return d - timedelta(days=d.weekday())

    @staticmethod
    def get_value_at_risk_trend(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Calculate Value at Risk trend for last 90 days using weekly aggregation.
        Production MaterialValueAtRiskHistory data is weekly; each point is one week
        (Monday-based) with value from issues opened that week vs actions taken that week.
        """
        logger.info("Calculating Value at Risk trend for last 90 days (weekly)")
        today = timezone.now().date()
        period_start = today - timedelta(days=89)

        issues_queryset = Issue.objects.filter(
            start_date__gte=period_start,
            start_date__lte=today
        ).exclude(
            material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(EXCLUDED_MATERIAL_Q)

        issues_queryset = IssueService._apply_material_filter(
            issues_queryset, direct_mat_nbr, mat_nbr_subquery
        )

        issues = list(issues_queryset.values('material__mat_nbr', 'start_date'))

        actions_queryset = Action.objects.filter(
            created_at__date__gte=period_start,
            created_at__date__lte=today
        ).exclude(
            issue__material__xplant_mat_stat__in=['DB', 'DM']
        ).exclude(
            Q(issue__material__drop_ship_flg=1) | Q(issue__material__short_date_flg=1)
        )

        if direct_mat_nbr:
            actions_queryset = actions_queryset.filter(
                issue__material__mat_nbr=direct_mat_nbr
            )
        if mat_nbr_subquery is not None:
            actions_queryset = actions_queryset.filter(
                issue__material__mat_nbr__in=mat_nbr_subquery
            )

        actions = list(actions_queryset.values('issue__material__mat_nbr', 'created_at'))

        all_material_ids = set()
        for issue in issues:
            all_material_ids.add(issue['material__mat_nbr'])
        for action in actions:
            all_material_ids.add(action['issue__material__mat_nbr'])

        risk_sorted_by_material = {}
        if all_material_ids:
            risk_records = MaterialValueAtRiskHistory.objects.filter(
                material__mat_nbr__in=all_material_ids,
                status_date__gte=period_start,
                status_date__lte=today
            ).exclude(
                material__xplant_mat_stat__in=['DB', 'DM']
            ).exclude(EXCLUDED_MATERIAL_Q).values('material__mat_nbr', 'status_date', 'dollars_at_risk_30_day')
            by_material = {}
            for record in risk_records:
                mat_nbr = record['material__mat_nbr']
                status_date = record['status_date']
                value = record['dollars_at_risk_30_day'] or 0.0
                if mat_nbr not in by_material:
                    by_material[mat_nbr] = []
                by_material[mat_nbr].append((status_date, value))
            for mat_nbr in by_material:
                by_material[mat_nbr].sort(key=lambda p: p[0])
                risk_sorted_by_material[mat_nbr] = by_material[mat_nbr]

        def get_risk_as_of(mat_nbr, as_of_date):
            """Return risk for material as of as_of_date (latest status_date <= as_of_date)."""
            if mat_nbr not in risk_sorted_by_material:
                return 0.0
            lst = risk_sorted_by_material[mat_nbr]
            dates = [p[0] for p in lst]
            idx = bisect.bisect_right(dates, as_of_date) - 1
            if idx < 0:
                return 0.0
            return lst[idx][1]

        opened_issues_by_week = {}
        for issue in issues:
            mat_nbr = issue['material__mat_nbr']
            start_date = issue['start_date']
            week_start = IssueService._week_start(start_date)
            if week_start not in opened_issues_by_week:
                opened_issues_by_week[week_start] = []
            opened_issues_by_week[week_start].append((mat_nbr, start_date))

        mitigated_actions_by_week = {}
        for action in actions:
            mat_nbr = action['issue__material__mat_nbr']
            action_date = action['created_at'].date()
            week_start = IssueService._week_start(action_date)
            if week_start not in mitigated_actions_by_week:
                mitigated_actions_by_week[week_start] = []
            mitigated_actions_by_week[week_start].append((mat_nbr, action_date))

        # Build ordered list of week_start dates covering [period_start, today]
        first_week_start = IssueService._week_start(period_start)
        week_starts = []
        w = first_week_start
        while w <= today:
            week_starts.append(w)
            w += timedelta(days=7)

        trend_data = []
        for week_number, week_start in enumerate(week_starts, start=1):
            value_at_risk = 0.0
            for (mat_nbr, start_date) in opened_issues_by_week.get(week_start, []):
                value_at_risk += get_risk_as_of(mat_nbr, start_date)

            value_mitigated = 0.0
            for (mat_nbr, action_date) in mitigated_actions_by_week.get(week_start, []):
                value_mitigated += get_risk_as_of(mat_nbr, action_date)

            total_value = value_at_risk + value_mitigated
            value_at_risk_pct = (value_at_risk / total_value * 100) if total_value > 0 else 0.0
            value_mitigated_pct = (value_mitigated / total_value * 100) if total_value > 0 else 0.0

            trend_data.append({
                'week': week_number,
                'date': week_start.isoformat(),
                'value_at_risk': round(value_at_risk, 2),
                'value_mitigated': round(value_mitigated, 2),
                'value_at_risk_pct': round(value_at_risk_pct, 2),
                'value_mitigated_pct': round(value_mitigated_pct, 2)
            })

        return trend_data

    @staticmethod
    def get_opened_issues_trend(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Trend of issues opened (start_date) over the last 90 days with weekly aggregation.

        Returns list of dicts: {bucket, open_issues, total_issues}
        where counts are distinct by issue_nbr.
        """
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=IssueService.DEFAULT_TREND_DAYS - 1)

        queryset = (
            Issue.objects.filter(start_date__isnull=False, start_date__gte=start_date, start_date__lte=end_date)
            .exclude(material__xplant_mat_stat__in=["DB", "DM"])
            .exclude(EXCLUDED_MATERIAL_Q)
        )
        queryset = IssueService._apply_material_filter(queryset, direct_mat_nbr, mat_nbr_subquery)

        queryset = queryset.annotate(bucket=TruncWeek("start_date"))

        return list(
            queryset.values("bucket")
            .annotate(
                total_issues=Count("issue_nbr", distinct=True),
                open_issues=Count(
                    "issue_nbr",
                    filter=Q(status=Issue.IssueStatus.OPEN),
                    distinct=True,
                ),
            )
            .order_by("bucket")
        )
