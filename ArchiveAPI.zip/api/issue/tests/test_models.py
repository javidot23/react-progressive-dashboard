from django.core.exceptions import ValidationError
from tests.BaseTestCase import BaseTestCase

from api.issue.models import Issue
from tests.TestDataFactory import TestDataFactory


class IssueModelTest(BaseTestCase):
    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.material = TestDataFactory.create_material(vendor=self.vendor)

    def test_issue_creation(self):
        issue = TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            description="Test issue"
        )
        self.assertEqual(issue.status, Issue.IssueStatus.OPEN)
        self.assertIsNotNone(issue.created_at)
        self.assertIsNotNone(issue.updated_at)

    def test_issue_str_representation(self):
        issue = TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material
        )
        self.assertEqual(issue.issue_nbr, "TEST-001")

    def test_unique_issue_nbr_constraint(self):
        TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material
        )
        with self.assertRaises(ValidationError):
            issue2 = Issue(
                issue_nbr="TEST-001",
                material=self.material
            )
            issue2.full_clean()

    def test_issue_status_choices(self):
        issue = TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.CLOSED
        )
        self.assertEqual(issue.status, Issue.IssueStatus.CLOSED)

    def test_ordering(self):
        older_issue = TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material
        )
        # Create newer issue
        newer_issue = TestDataFactory.create_issue(
            issue_nbr="TEST-002",
            material=self.material
        )
        issues = Issue.objects.all()
        self.assertEqual(issues.first(), newer_issue)
        self.assertEqual(issues.last(), older_issue)
