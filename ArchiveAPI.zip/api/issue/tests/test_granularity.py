from contextlib import contextmanager
from datetime import date

from django.urls import reverse
from rest_framework import status

from api.issue.granularity import (
    annotate_issue_granularity,
    granularity_type_for_issue,
    materials_for_issue,
)
from api.issue.models import Issue
from tests.BaseTestCase import BaseAPITestCase, BaseTestCase, MVAPITestCase
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


ISSUE_EFFECTIVE_METRICS_MV = ["issue_effective_metrics_mv"]
ORDER_TRANSACTION_MATERIAL_90D_MV = ["order_transaction_material_90d_mv"]


def refresh_issue_mvs(view_names=None):
    MaterializedViewTestHelper.refresh_materialized_views(
        view_names or ISSUE_EFFECTIVE_METRICS_MV
    )


@contextmanager
def seed_with_issue_mvs(view_names=None):
    """Defer factory auto-refresh, then refresh only the views this test needs."""
    with MaterializedViewTestHelper.defer_auto_refresh():
        yield
    refresh_issue_mvs(view_names)


class GranularityHelperTest(BaseTestCase):
    """materials_for_issue + granularity_type derivation (Python + DB annotation)."""

    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        # Two materials sharing one gcn/ndc/hicl, a third unrelated.
        self.m1 = TestDataFactory.create_material(
            vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1", ndc="NDC-1", hicl="HICL-1"
        )
        self.m2 = TestDataFactory.create_material(
            vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1", ndc="NDC-1", hicl="HICL-1"
        )
        self.other = TestDataFactory.create_material(
            vendor=self.vendor, fdb_gcn_seq_nbr="GCN-2", ndc="NDC-2", hicl="HICL-2"
        )

    def test_type_material_and_material_plant(self):
        plant = TestDataFactory.create_plant()
        issue = TestDataFactory.create_issue(material=self.m1)
        self.assertEqual(granularity_type_for_issue(issue), "material")
        issue_p = TestDataFactory.create_issue(material=self.m1, plant=plant)
        self.assertEqual(granularity_type_for_issue(issue_p), "material_plant")

    def test_type_gcn_ndc_fei_hicl(self):
        self.assertEqual(
            granularity_type_for_issue(TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-1")),
            "gcn",
        )
        self.assertEqual(
            granularity_type_for_issue(TestDataFactory.create_issue(ndc="NDC-1")), "ndc"
        )
        self.assertEqual(
            granularity_type_for_issue(TestDataFactory.create_issue(fei_number="FEI-1")), "fei"
        )
        self.assertEqual(
            granularity_type_for_issue(TestDataFactory.create_issue(hicl="HICL-1")), "hicl"
        )

    def test_db_annotation_matches_python(self):
        TestDataFactory.create_issue(material=self.m1)
        TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-1")
        TestDataFactory.create_issue(ndc="NDC-1")
        TestDataFactory.create_issue(fei_number="FEI-9")
        TestDataFactory.create_issue(hicl="HICL-1")
        annotated = {
            i.id: i.granularity_type
            for i in annotate_issue_granularity(Issue.objects.all())
        }
        for issue in Issue.objects.all():
            self.assertEqual(annotated[issue.id], granularity_type_for_issue(issue))

    def test_materials_for_issue_material(self):
        issue = TestDataFactory.create_issue(material=self.m1)
        self.assertEqual(
            set(materials_for_issue(issue).values_list("mat_nbr", flat=True)),
            {self.m1.mat_nbr},
        )

    def test_materials_for_issue_gcn_spans_materials(self):
        issue = TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-1")
        self.assertEqual(
            set(materials_for_issue(issue).values_list("mat_nbr", flat=True)),
            {self.m1.mat_nbr, self.m2.mat_nbr},
        )

    def test_materials_for_issue_ndc_and_hicl(self):
        ndc_issue = TestDataFactory.create_issue(ndc="NDC-1")
        self.assertEqual(materials_for_issue(ndc_issue).count(), 2)
        hicl_issue = TestDataFactory.create_issue(hicl="HICL-1")
        self.assertEqual(materials_for_issue(hicl_issue).count(), 2)

    def test_materials_for_issue_fei_is_empty(self):
        issue = TestDataFactory.create_issue(fei_number="FEI-1")
        self.assertEqual(materials_for_issue(issue).count(), 0)

    def test_materials_for_issue_gcn_plant_returns_all_grain_materials(self):
        plant = TestDataFactory.create_plant()
        issue = TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-1", plant=plant)
        self.assertEqual(
            set(materials_for_issue(issue).values_list("mat_nbr", flat=True)),
            {self.m1.mat_nbr, self.m2.mat_nbr},
        )
        self.assertEqual(granularity_type_for_issue(issue), "gcn_plant")


class AllIssuesViewTest(MVAPITestCase):
    """The /issue/all/ endpoint: mixed grains, effective metrics, filters, driving event."""

    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.m1 = TestDataFactory.create_material(
            vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1", risk_rating=0.4, dollars_at_risk=100.0
        )
        self.m2 = TestDataFactory.create_material(
            vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1", risk_rating=0.6, dollars_at_risk=300.0
        )
        self.url = reverse("issue:all-issues")

    def _results(self, response):
        return response.data["results"] if "results" in response.data else response.data

    def test_lists_material_and_coarse_issues(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="GCN-ISS", fdb_gcn_seq_nbr="GCN-1")
        response = self.client.get(self.url, {"limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        by_nbr = {r["issue_nbr"]: r for r in self._results(response)}
        self.assertIn("MAT-1", by_nbr)
        self.assertIn("GCN-ISS", by_nbr)
        self.assertEqual(by_nbr["GCN-ISS"]["granularity_type"], "gcn")
        self.assertIsNone(by_nbr["GCN-ISS"]["material"])

    def test_effective_metrics_aggregate_for_gcn(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="GCN-ISS", fdb_gcn_seq_nbr="GCN-1")
        response = self.client.get(self.url, {"granularity_type": "gcn", "limit": 50})
        row = self._results(response)[0]
        # AVG risk over {0.4, 0.6} = 0.5 ; SUM dollars = 400 ; risk_adjusted = 200
        self.assertAlmostEqual(row["effective_risk_rating"], 0.5, places=4)
        self.assertAlmostEqual(row["effective_dollars_at_risk"], 400.0, places=4)
        self.assertAlmostEqual(row["effective_risk_adjusted_value"], 200.0, places=4)

    def test_impacted_material_count(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="GCN-ISS", fdb_gcn_seq_nbr="GCN-1")
        response = self.client.get(self.url, {"limit": 50})
        by_nbr = {r["issue_nbr"]: r for r in self._results(response)}
        self.assertEqual(by_nbr["MAT-1"]["impacted_material_count"], 1)
        self.assertEqual(by_nbr["GCN-ISS"]["impacted_material_count"], 2)

    def test_impacted_material_count_matches_impacted_materials_for_gcn_plant(self):
        plant = TestDataFactory.create_plant()
        with seed_with_issue_mvs():
            issue = TestDataFactory.create_issue(
                issue_nbr="GCN-PLANT", fdb_gcn_seq_nbr="GCN-1", plant=plant
            )
        list_response = self.client.get(self.url, {"granularity_type": "gcn_plant", "limit": 50})
        row = {r["issue_nbr"]: r for r in self._results(list_response)}["GCN-PLANT"]
        materials_response = self.client.get(
            reverse("issue:issue-impacted-materials", args=[issue.id]), {"limit": 50}
        )
        self.assertEqual(row["impacted_material_count"], len(self._results(materials_response)))

    def test_effective_risk_adjusted_value_range_filter(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1)  # 0.4 * 100 = 40
            TestDataFactory.create_issue(issue_nbr="GCN-ISS", fdb_gcn_seq_nbr="GCN-1")  # 0.5 * 400 = 200
        response = self.client.get(
            self.url, {"effective_risk_adjusted_value_min": 100, "limit": 50}
        )
        nbrs = {r["issue_nbr"] for r in self._results(response)}
        self.assertEqual(nbrs, {"GCN-ISS"})

    def test_impacted_material_count_filter_and_ordering(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1)  # count 1
            TestDataFactory.create_issue(issue_nbr="GCN-ISS", fdb_gcn_seq_nbr="GCN-1")  # count 2
        filtered = self.client.get(self.url, {"impacted_material_count_min": 2, "limit": 50})
        self.assertEqual({r["issue_nbr"] for r in self._results(filtered)}, {"GCN-ISS"})
        ordered = self.client.get(
            self.url, {"ordering": "-impacted_material_count", "limit": 50}
        )
        self.assertEqual(self._results(ordered)[0]["issue_nbr"], "GCN-ISS")

    def test_granularity_type_filter(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="GCN-ISS", fdb_gcn_seq_nbr="GCN-1")
        response = self.client.get(self.url, {"granularity_type": "material", "limit": 50})
        nbrs = {r["issue_nbr"] for r in self._results(response)}
        self.assertEqual(nbrs, {"MAT-1"})

    def test_group_and_persona_filters(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(
                issue_nbr="MATCH", material=self.m1, group="Pharmacy", persona="Buyer"
            )
            TestDataFactory.create_issue(
                issue_nbr="OTHER", material=self.m2, group="Supply Chain", persona="Planner"
            )
        by_group = self.client.get(self.url, {"group": "Pharmacy", "limit": 50})
        self.assertEqual(
            {r["issue_nbr"] for r in self._results(by_group)}, {"MATCH"}
        )
        by_persona = self.client.get(self.url, {"persona": "Planner", "limit": 50})
        self.assertEqual(
            {r["issue_nbr"] for r in self._results(by_persona)}, {"OTHER"}
        )

    def test_includes_all_statuses(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="OPEN-1", material=self.m1, status="OPEN")
            TestDataFactory.create_issue(issue_nbr="CLOSED-1", material=self.m2, status="CLOSED")
        response = self.client.get(self.url, {"limit": 50})
        nbrs = {r["issue_nbr"] for r in self._results(response)}
        self.assertIn("OPEN-1", nbrs)
        self.assertIn("CLOSED-1", nbrs)

    def test_hicl_description_returned_for_hicl_issue(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_material(
                vendor=self.vendor, hicl="HICL-9", hicl_description="Amoxicillin"
            )
            TestDataFactory.create_issue(issue_nbr="HICL-ISS", hicl="HICL-9")
        response = self.client.get(self.url, {"granularity_type": "hicl", "limit": 50})
        row = self._results(response)[0]
        self.assertEqual(row["granularity_type"], "hicl")
        self.assertEqual(row["hicl_description"], "Amoxicillin")

    def test_driving_event_attached(self):
        with seed_with_issue_mvs():
            event = TestDataFactory.create_supply_chain_event(material=self.m1, event_id="EV-1")
            TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1, event_id="EV-1")
        response = self.client.get(self.url, {"limit": 50})
        row = {r["issue_nbr"]: r for r in self._results(response)}["MAT-1"]
        self.assertIsNotNone(row["driving_event"])
        self.assertEqual(row["driving_event"]["event_id"], event.event_id)

    def test_list_response_uses_has_actions_not_action_arrays(self):
        with seed_with_issue_mvs():
            issue = TestDataFactory.create_issue(issue_nbr="WITH-ACT", material=self.m1)
            TestDataFactory.create_action(issue=issue)
            TestDataFactory.create_potential_action(issue=issue)
            TestDataFactory.create_issue(issue_nbr="NO-ACT", material=self.m2)

        response = self.client.get(self.url, {"limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        by_nbr = {r["issue_nbr"]: r for r in self._results(response)}

        self.assertIn("has_actions", by_nbr["WITH-ACT"])
        self.assertTrue(by_nbr["WITH-ACT"]["has_actions"])
        self.assertNotIn("actions", by_nbr["WITH-ACT"])
        self.assertNotIn("potential_actions", by_nbr["WITH-ACT"])

        self.assertFalse(by_nbr["NO-ACT"]["has_actions"])

    def test_distinct_by_material_returns_one_issue_per_material(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="MAT-A-1", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="MAT-A-2", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="MAT-B-1", material=self.m2)

        response = self.client.get(
            self.url, {"distinct_by_material": "true", "limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = self._results(response)
        mat_nbrs = [r["material"]["mat_nbr"] for r in results]
        self.assertEqual(len(mat_nbrs), 2)
        self.assertEqual(len(set(mat_nbrs)), 2)
        self.assertEqual(set(mat_nbrs), {self.m1.mat_nbr, self.m2.mat_nbr})

    def test_distinct_by_material_picks_newest_start_date_for_same_material(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(
                issue_nbr="MAT-OLD",
                material=self.m1,
                start_date=date(2026, 1, 1),
            )
            newer = TestDataFactory.create_issue(
                issue_nbr="MAT-NEW",
                material=self.m1,
                start_date=date(2026, 6, 1),
            )

        response = self.client.get(
            self.url, {"distinct_by_material": "true", "limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = self._results(response)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["issue_nbr"], newer.issue_nbr)

    def test_distinct_by_material_excludes_material_less_issues(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="GCN-ISS", fdb_gcn_seq_nbr="GCN-1")

        response = self.client.get(
            self.url, {"distinct_by_material": "true", "limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        nbrs = {r["issue_nbr"] for r in self._results(response)}
        self.assertEqual(nbrs, {"MAT-1"})

    def test_distinct_by_material_false_returns_all_issues(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(issue_nbr="MAT-A-1", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="MAT-A-2", material=self.m1)

        response = self.client.get(
            self.url, {"distinct_by_material": "false", "limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        nbrs = {r["issue_nbr"] for r in self._results(response)}
        self.assertEqual(nbrs, {"MAT-A-1", "MAT-A-2"})

    def test_distinct_by_material_with_module_and_granularity_filters(self):
        with seed_with_issue_mvs():
            issue = TestDataFactory.create_issue(issue_nbr="REACT-MAT", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="MAT-DUP", material=self.m1)
            other_issue = TestDataFactory.create_issue(issue_nbr="OTHER-MAT", material=self.m2)
            TestDataFactory.create_potential_action(issue=issue, module="React")
            TestDataFactory.create_potential_action(issue=other_issue, module="Manage")

        response = self.client.get(
            self.url,
            {
                "distinct_by_material": "true",
                "granularity_type": "material",
                "module": "React",
                "limit": 50,
            },
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = self._results(response)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["issue_nbr"], issue.issue_nbr)

    def test_ordering_recent_open_date_lists_open_issues_first(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(
                issue_nbr="CLOSED-NEW",
                material=self.m1,
                status="CLOSED",
                start_date=date(2026, 12, 1),
            )
            TestDataFactory.create_issue(
                issue_nbr="OPEN-OLD",
                material=self.m2,
                status="OPEN",
                start_date=date(2026, 1, 1),
            )
            TestDataFactory.create_issue(
                issue_nbr="OPEN-NEW",
                material=self.m2,
                status="OPEN",
                start_date=date(2026, 6, 1),
            )

        response = self.client.get(
            self.url, {"ordering": "-recent_open_date", "limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        nbrs = [r["issue_nbr"] for r in self._results(response)]
        self.assertEqual(nbrs[:2], ["OPEN-NEW", "OPEN-OLD"])
        self.assertEqual(nbrs[2], "CLOSED-NEW")

    def test_ordering_open_priority_then_start_date(self):
        with seed_with_issue_mvs():
            TestDataFactory.create_issue(
                issue_nbr="OPEN-OLD",
                material=self.m1,
                status="OPEN",
                start_date=date(2026, 1, 1),
            )
            TestDataFactory.create_issue(
                issue_nbr="OPEN-NEW",
                material=self.m2,
                status="OPEN",
                start_date=date(2026, 6, 1),
            )

        response = self.client.get(
            self.url, {"ordering": "open_priority,-start_date", "limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        nbrs = [r["issue_nbr"] for r in self._results(response)]
        self.assertEqual(nbrs[:2], ["OPEN-NEW", "OPEN-OLD"])


class IssueImpactedMaterialsViewTest(MVAPITestCase):
    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.m1 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")
        self.m2 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")

    def _results(self, response):
        return response.data["results"] if "results" in response.data else response.data

    def test_gcn_issue_returns_all_grain_materials(self):
        with MaterializedViewTestHelper.defer_auto_refresh():
            issue = TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-1")
        response = self.client.get(
            reverse("issue:issue-impacted-materials", args=[issue.id]), {"limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mat_nbrs = {r["mat_nbr"] for r in self._results(response)}
        self.assertEqual(mat_nbrs, {self.m1.mat_nbr, self.m2.mat_nbr})

    def test_gcn_plant_issue_returns_all_grain_materials(self):
        plant = TestDataFactory.create_plant()
        with MaterializedViewTestHelper.defer_auto_refresh():
            issue = TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-1", plant=plant)
        response = self.client.get(
            reverse("issue:issue-impacted-materials", args=[issue.id]), {"limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mat_nbrs = {r["mat_nbr"] for r in self._results(response)}
        self.assertEqual(mat_nbrs, {self.m1.mat_nbr, self.m2.mat_nbr})

    def test_unfilled_qty_sums_over_corp_chains(self):
        # m1 has two orders across two corp chains: (100-60) + (50-50) = 40 unfilled.
        with seed_with_issue_mvs(ORDER_TRANSACTION_MATERIAL_90D_MV):
            TestDataFactory.create_order_transaction(
                material=self.m1, total_order_qty=100, total_shipped_qty=60
            )
            TestDataFactory.create_order_transaction(
                material=self.m1, total_order_qty=50, total_shipped_qty=50
            )
            issue = TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-1")
        response = self.client.get(
            reverse("issue:issue-impacted-materials", args=[issue.id]), {"limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        rows = {r["mat_nbr"]: r for r in self._results(response)}
        self.assertEqual(rows[self.m1.mat_nbr]["unfilled_qty"], 40)

    def test_unfilled_qty_zero_without_orders(self):
        with MaterializedViewTestHelper.defer_auto_refresh():
            issue = TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-1")
        response = self.client.get(
            reverse("issue:issue-impacted-materials", args=[issue.id]), {"limit": 50}
        )
        rows = {r["mat_nbr"]: r for r in self._results(response)}
        self.assertEqual(rows[self.m2.mat_nbr]["unfilled_qty"], 0)

    def test_fei_issue_returns_empty(self):
        with MaterializedViewTestHelper.defer_auto_refresh():
            issue = TestDataFactory.create_issue(fei_number="FEI-1")
        response = self.client.get(
            reverse("issue:issue-impacted-materials", args=[issue.id]), {"limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(self._results(response), [])

    def test_unknown_issue_404(self):
        response = self.client.get(
            reverse("issue:issue-impacted-materials", args=[999999]), {"limit": 50}
        )
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_order_and_filter_by_risk_adjusted_value(self):
        with MaterializedViewTestHelper.defer_auto_refresh():
            low = TestDataFactory.create_material(
                vendor=self.vendor, fdb_gcn_seq_nbr="GCN-RAR", risk_rating=0.4, dollars_at_risk=100.0
            )  # 40
            high = TestDataFactory.create_material(
                vendor=self.vendor, fdb_gcn_seq_nbr="GCN-RAR", risk_rating=0.6, dollars_at_risk=300.0
            )  # 180
            issue = TestDataFactory.create_issue(fdb_gcn_seq_nbr="GCN-RAR")
        url = reverse("issue:issue-impacted-materials", args=[issue.id])

        resp = self.client.get(url, {"limit": 50})
        rows = self._results(resp)
        self.assertEqual([r["mat_nbr"] for r in rows], [high.mat_nbr, low.mat_nbr])
        self.assertEqual(rows[0]["risk_adjusted_value"], 180.0)

        resp2 = self.client.get(url, {"risk_adjusted_value_min": 100, "limit": 50})
        self.assertEqual({r["mat_nbr"] for r in self._results(resp2)}, {high.mat_nbr})


class EventImpactedMaterialsViewTest(BaseAPITestCase):
    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.m1 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")
        self.m2 = TestDataFactory.create_material(vendor=self.vendor, fdb_gcn_seq_nbr="GCN-1")

    def _results(self, response):
        return response.data["results"] if "results" in response.data else response.data

    def test_gcn_event_returns_grain_materials(self):
        event = TestDataFactory.create_supply_chain_event(
            material=None, event_id="EV-GCN", fdb_gcn_seq_nbr="GCN-1"
        )
        response = self.client.get(
            reverse("supply_chain_events:event-impacted-materials", args=[event.id]),
            {"limit": 50},
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mat_nbrs = {r["mat_nbr"] for r in self._results(response)}
        self.assertEqual(mat_nbrs, {self.m1.mat_nbr, self.m2.mat_nbr})

    def test_material_event_returns_single_material(self):
        event = TestDataFactory.create_supply_chain_event(material=self.m1, event_id="EV-MAT")
        response = self.client.get(
            reverse("supply_chain_events:event-impacted-materials", args=[event.id]),
            {"limit": 50},
        )
        mat_nbrs = {r["mat_nbr"] for r in self._results(response)}
        self.assertEqual(mat_nbrs, {self.m1.mat_nbr})

    def test_unknown_event_404(self):
        response = self.client.get(
            reverse("supply_chain_events:event-impacted-materials", args=[999999]),
            {"limit": 50},
        )
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
