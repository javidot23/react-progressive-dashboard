from datetime import date, timedelta

from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APIClient

from api.issue.models import Issue
from api.issue_note.models import IssueNote
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


ISSUE_EFFECTIVE_METRICS_MV = ["issue_effective_metrics_mv"]


def refresh_issue_mvs(view_names=None):
    """Refresh issue MVs without leaving factory auto-refresh enabled for later tests."""
    was_created = MaterializedViewTestHelper._views_created
    MaterializedViewTestHelper._views_created = True
    try:
        MaterializedViewTestHelper.refresh_materialized_views(
            view_names or ISSUE_EFFECTIVE_METRICS_MV
        )
    finally:
        MaterializedViewTestHelper._views_created = was_created


class IssueViewsIntegrationTest(BaseTestCase):
    def setUp(self):
        self.client = APIClient()
        self.vendor = TestDataFactory.create_vendor(
            name="Test Vendor",
            country="US",
            risk_rating=0.8
        )
        self.material = TestDataFactory.create_material(
            name="Test Material",
            vendor=self.vendor,
            risk_rating=0.9,
        )

    def test_weekly_open_issues_view(self):
        TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=date.today()
        )

        url = reverse('issue:weekly-open-count')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('current_week_count', response.data)
        self.assertIn('previous_week_count', response.data)

    def test_country_issues_view(self):
        TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )

        url = reverse('issue:country-issues')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)

    def test_top_riskiest_materials_view(self):
        TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )

        url = reverse('issue:top-riskiest-materials')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('materials', response.data)

    def test_top_riskiest_materials_view_with_limit(self):
        TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )

        url = reverse('issue:top-riskiest-materials')
        response = self.client.get(url, {'limit': 5})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('materials', response.data)

    def test_top_riskiest_vendors_view(self):
        TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )

        url = reverse('issue:top-riskiest-vendors')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('vendors', response.data)

    def test_top_riskiest_vendors_view_with_limit(self):
        TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )

        url = reverse('issue:top-riskiest-vendors')
        response = self.client.get(url, {'limit': 10})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('vendors', response.data)

    def test_issue_with_action_view(self):
        issue = TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )
        action = TestDataFactory.create_action(
            issue=issue
        )

        url = reverse('issue:issues-with-material-and-actions')
        response = self.client.get(url, {'limit': 1})

        data = response.data["results"]

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(len(data), 0)

        # Verify the issue is in the response
        issue_data = next((item for item in data if item['id'] == issue.id), None)
        self.assertIsNotNone(issue_data)

        # Verify actions are present
        self.assertIn('actions', issue_data)
        self.assertGreater(len(issue_data['actions']), 0)

        # Verify action details
        action_ids = [a['id'] for a in issue_data['actions']]
        self.assertIn(action.id, action_ids)

        # Verify material is present
        self.assertIn('material', issue_data)
        self.assertEqual(issue_data['material']['id'], self.material.id)

    def test_issue_with_action_view_filter_by_module(self):
        issue = TestDataFactory.create_issue(
            issue_nbr="TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )
        TestDataFactory.create_potential_action(
            issue=issue,
            module="Test Module"
        )
        another_issue = TestDataFactory.create_issue(
            issue_nbr="TEST-002",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )
        TestDataFactory.create_potential_action(
            issue=another_issue,
            module="Another Module"
        )
        url = reverse('issue:issues-with-material-and-actions')
        response = self.client.get(url, {'module': 'Test Module'})
        data = response.data["results"]

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(len(data), 0)
        issue_data = next((item for item in data if item['id'] == issue.id), None)
        self.assertIsNotNone(issue_data)

    def test_issue_detail_with_material_actions_returns_enriched_issue(self):
        """Test single issue detail includes the same enrichments as the issue list."""
        user = TestDataFactory.create_test_user(
            entra_id="issue_detail_user",
            email="issue-detail@example.com",
            first_name="Issue",
            last_name="Detail"
        )
        with MaterializedViewTestHelper.defer_auto_refresh():
            issue = TestDataFactory.create_issue(
                issue_nbr="DETAIL-001",
                material=self.material,
                status=Issue.IssueStatus.OPEN
            )
            action = TestDataFactory.create_action(issue=issue, user=user)
            potential_action = TestDataFactory.create_potential_action(
                issue=issue,
                module="React"
            )
            IssueNote.objects.create(
                issue=issue,
                content="Investigating issue",
                user_id=user.entra_id,
                user_data={"first_name": user.first_name, "email": user.email}
            )
        refresh_issue_mvs()

        url = reverse(
            'issue:issue-detail-with-material-and-actions',
            kwargs={'id': issue.id}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['id'], issue.id)
        self.assertEqual(response.data['issue_nbr'], issue.issue_nbr)
        self.assertEqual(response.data['material']['id'], self.material.id)
        self.assertEqual(response.data['granularity_type'], 'material')
        self.assertIn('effective_risk_adjusted_value', response.data)
        self.assertEqual(response.data['impacted_material_count'], 1)
        self.assertEqual(response.data['notes_count'], 1)
        self.assertIsNotNone(response.data['last_note'])

        action_ids = [item['id'] for item in response.data['actions']]
        potential_action_ids = [item['id'] for item in response.data['potential_actions']]
        self.assertIn(action.id, action_ids)
        self.assertIn(potential_action.id, potential_action_ids)

    def test_issue_detail_returns_closed_issue(self):
        """Test single issue detail supports closed issues."""
        issue = TestDataFactory.create_issue(
            issue_nbr="DETAIL-CLOSED-001",
            material=self.material,
            status=Issue.IssueStatus.CLOSED
        )

        url = reverse(
            'issue:issue-detail-with-material-and-actions',
            kwargs={'id': issue.id}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['id'], issue.id)
        self.assertEqual(response.data['status'], Issue.IssueStatus.CLOSED)

    def test_issue_detail_returns_issue_regardless_of_material_quality(self):
        """The granularity detail returns issues as recorded, without the legacy
        material-quality exclusions (xplant_mat_stat in DB/DM, drop_ship, short_date)."""
        excluded_material = TestDataFactory.create_material(
            vendor=self.vendor,
            xplant_mat_stat='DB'
        )
        issue = TestDataFactory.create_issue(
            issue_nbr="DETAIL-EXCLUDED-001",
            material=excluded_material,
            status=Issue.IssueStatus.OPEN
        )

        url = reverse(
            'issue:issue-detail-with-material-and-actions',
            kwargs={'id': issue.id}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['id'], issue.id)

    def test_issue_detail_not_found(self):
        """Test single issue detail returns 404 for unknown issue ids."""
        url = reverse(
            'issue:issue-detail-with-material-and-actions',
            kwargs={'id': 999999}
        )
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_issue_detail_requires_authentication(self):
        """Test single issue detail uses the global authenticated API policy."""
        issue = TestDataFactory.create_issue(
            issue_nbr="DETAIL-AUTH-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )

        self.client.force_authenticate(user=None)
        url = reverse(
            'issue:issue-detail-with-material-and-actions',
            kwargs={'id': issue.id}
        )
        response = self.client.get(url, HTTP_X_DISABLE_TEST_AUTH='1')

        self.assertIn(
            response.status_code,
            [status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN]
        )

    def test_two_week_issues_summary_view(self):
        """Test two-week issues summary view"""
        from datetime import timedelta
        from django.utils import timezone

        today = timezone.now().date()
        days_since_monday = today.weekday()
        current_period_start = today - timedelta(days=days_since_monday + 13)

        # Create issues in current period
        TestDataFactory.create_issue(
            issue_nbr="VIEW-TEST-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=current_period_start + timedelta(days=1)
        )
        TestDataFactory.create_issue(
            issue_nbr="VIEW-TEST-002",
            material=self.material,
            status=Issue.IssueStatus.CLOSED,
            start_date=current_period_start + timedelta(days=2)
        )

        url = reverse('issue:two-week-summary')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('current_total_issues', response.data)
        self.assertIn('current_opened_issues', response.data)
        self.assertIn('current_closed_issues', response.data)
        self.assertIn('previous_total_issues', response.data)
        self.assertIn('previous_opened_issues', response.data)
        self.assertIn('previous_closed_issues', response.data)
        self.assertIn('current_period_start', response.data)
        self.assertIn('current_period_end', response.data)
        self.assertIn('previous_period_start', response.data)
        self.assertIn('previous_period_end', response.data)

        # Verify data types
        self.assertIsInstance(response.data['current_total_issues'], int)
        self.assertIsInstance(response.data['current_opened_issues'], int)
        self.assertIsInstance(response.data['current_closed_issues'], int)
        self.assertIsInstance(response.data['previous_total_issues'], int)
        self.assertIsInstance(response.data['previous_opened_issues'], int)
        self.assertIsInstance(response.data['previous_closed_issues'], int)

    def test_two_week_issues_summary_view_with_filters(self):
        """Test two-week issues summary view with global filters"""
        from datetime import timedelta
        from django.utils import timezone

        today = timezone.now().date()
        days_since_monday = today.weekday()
        current_period_start = today - timedelta(days=days_since_monday + 13)

        # Create another vendor and material
        vendor2 = TestDataFactory.create_vendor(
            name="Filtered Vendor",
            country="US",
            risk_rating=0.7
        )
        material2 = TestDataFactory.create_material(
            name="Filtered Material",
            vendor=vendor2,
            risk_rating=0.8
        )

        # Create issues with different materials
        TestDataFactory.create_issue(
            issue_nbr="FILTERED-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=current_period_start + timedelta(days=1)
        )
        TestDataFactory.create_issue(
            issue_nbr="NOT-FILTERED-001",
            material=material2,
            status=Issue.IssueStatus.OPEN,
            start_date=current_period_start + timedelta(days=1)
        )

        # Test with supplier filter
        url = reverse('issue:two-week-summary')
        response = self.client.get(url, {'supplier': self.vendor.id})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('current_total_issues', response.data)
        # Should only count issues from the filtered vendor
        self.assertGreaterEqual(response.data['current_total_issues'], 1)

        # Test with material filter
        response = self.client.get(url, {'material': self.material.mat_nbr})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(response.data['current_total_issues'], 1)

    def test_today_issues_snapshot_view(self):
        """Test today's issues snapshot view"""
        from datetime import timedelta
        from django.utils import timezone

        today = timezone.now().date()

        # Create issues that started today
        TestDataFactory.create_issue(
            issue_nbr="TODAY-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today
        )
        TestDataFactory.create_issue(
            issue_nbr="TODAY-OPEN-002",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today
        )
        TestDataFactory.create_issue(
            issue_nbr="TODAY-CLOSED-001",
            material=self.material,
            status=Issue.IssueStatus.CLOSED,
            start_date=today
        )

        # Create issues that started yesterday (should not be counted)
        TestDataFactory.create_issue(
            issue_nbr="YESTERDAY-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today - timedelta(days=1)
        )

        url = reverse('issue:today-issues-snapshot')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('open_issues', response.data)
        self.assertIn('total_issues', response.data)
        self.assertIn('snapshot_date', response.data)

        # Verify data types
        self.assertIsInstance(response.data['open_issues'], int)
        self.assertIsInstance(response.data['total_issues'], int)
        self.assertEqual(response.data['snapshot_date'], today.isoformat())

        # Verify values (should only count issues that started today)
        self.assertEqual(response.data['total_issues'], 3)  # 2 open + 1 closed
        self.assertEqual(response.data['open_issues'], 2)  # 2 open
        self.assertEqual(response.data['snapshot_date'], today.isoformat())

    def test_today_issues_snapshot_view_no_data(self):
        """Test today's issues snapshot view when there are no issues today"""

        today = timezone.now().date()

        # Create issues that started yesterday (should not be counted)
        TestDataFactory.create_issue(
            issue_nbr="YESTERDAY-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today - timedelta(days=1)
        )

        url = reverse('issue:today-issues-snapshot')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('open_issues', response.data)
        self.assertIn('total_issues', response.data)
        self.assertIn('snapshot_date', response.data)

        # Should return zero counts
        self.assertEqual(response.data['total_issues'], 0)
        self.assertEqual(response.data['open_issues'], 0)
        self.assertEqual(response.data['snapshot_date'], today.isoformat())

    def test_today_issues_snapshot_view_with_filters(self):
        """Test today's issues snapshot view with global filters"""

        today = timezone.now().date()

        # Create another vendor and material
        vendor2 = TestDataFactory.create_vendor(
            name="Filtered Vendor",
            country="US",
            risk_rating=0.7
        )
        material2 = TestDataFactory.create_material(
            name="Filtered Material",
            vendor=vendor2,
            risk_rating=0.8
        )

        # Create issues with different materials that started today
        TestDataFactory.create_issue(
            issue_nbr="FILTERED-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today
        )
        TestDataFactory.create_issue(
            issue_nbr="FILTERED-CLOSED-001",
            material=self.material,
            status=Issue.IssueStatus.CLOSED,
            start_date=today
        )
        TestDataFactory.create_issue(
            issue_nbr="NOT-FILTERED-001",
            material=material2,
            status=Issue.IssueStatus.OPEN,
            start_date=today
        )

        # Test with supplier filter
        url = reverse('issue:today-issues-snapshot')
        response = self.client.get(url, {'supplier': self.vendor.id})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Should only count issues from the filtered vendor
        self.assertEqual(response.data['total_issues'], 2)
        self.assertEqual(response.data['open_issues'], 1)

        # Test with material filter
        response = self.client.get(url, {'material': self.material.mat_nbr})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['total_issues'], 2)
        self.assertEqual(response.data['open_issues'], 1)

    def test_value_at_risk_trend_view(self):
        """Test value at risk trend view"""
        today = timezone.now().date()
        issue_date = today - timedelta(days=10)

        # Create issue
        issue = TestDataFactory.create_issue(
            issue_nbr="TREND-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )

        # Create MaterialValueAtRiskHistory
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=issue_date,
            dollars_at_risk_30_day=15000.0
        )

        # Create action
        action_date = today - timedelta(days=5)
        action = TestDataFactory.create_action(issue=issue)
        action.created_at = timezone.make_aware(
            timezone.datetime.combine(action_date, timezone.datetime.min.time())
        )
        action.save()

        # Create MaterialValueAtRiskHistory for action date
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=action_date,
            dollars_at_risk_30_day=12000.0
        )

        url = reverse('issue:value-at-risk-trend')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertGreaterEqual(len(response.data), 12)
        self.assertLessEqual(len(response.data), 14)

        # Find week containing issue_date and action_date
        week_start_issue = issue_date - timedelta(days=issue_date.weekday())
        week_start_action = action_date - timedelta(days=action_date.weekday())
        week_issue = next((r for r in response.data if r['date'] == week_start_issue.isoformat()), None)
        week_action = next((r for r in response.data if r['date'] == week_start_action.isoformat()), None)
        self.assertIsNotNone(week_issue)
        self.assertIsNotNone(week_action)
        self.assertEqual(week_issue['value_at_risk'], 15000.0)
        self.assertEqual(week_action['value_mitigated'], 12000.0)

    def test_value_at_risk_trend_view_with_material_filter(self):
        """Test value at risk trend view with material filter"""
        today = timezone.now().date()
        issue_date = today - timedelta(days=8)

        # Create another material
        material2 = TestDataFactory.create_material(
            name="Material 2",
            vendor=self.vendor
        )

        # Create issue for first material
        TestDataFactory.create_issue(
            issue_nbr="FILTER-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=issue_date,
            dollars_at_risk_30_day=20000.0
        )

        # Create issue for second material (should be filtered out)
        TestDataFactory.create_issue(
            issue_nbr="FILTER-002",
            material=material2,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=material2,
            status_date=issue_date,
            dollars_at_risk_30_day=10000.0
        )

        # Test with material filter
        url = reverse('issue:value-at-risk-trend')
        response = self.client.get(url, {'material': self.material.mat_nbr})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)

        # Should only count first material
        total_value_at_risk = sum(w['value_at_risk'] for w in response.data)
        self.assertEqual(total_value_at_risk, 20000.0)

    def test_value_at_risk_trend_view_with_vendor_filter(self):
        """Test value at risk trend view with vendor filter"""
        today = timezone.now().date()
        issue_date = today - timedelta(days=6)

        # Create another vendor and material
        vendor2 = TestDataFactory.create_vendor(name="Vendor 2")
        material2 = TestDataFactory.create_material(
            name="Material 2",
            vendor=vendor2
        )

        # Create issue for first vendor
        TestDataFactory.create_issue(
            issue_nbr="VENDOR-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=issue_date,
            dollars_at_risk_30_day=18000.0
        )

        # Create issue for second vendor (should be filtered out)
        TestDataFactory.create_issue(
            issue_nbr="VENDOR-002",
            material=material2,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=material2,
            status_date=issue_date,
            dollars_at_risk_30_day=9000.0
        )

        # Test with vendor filter
        url = reverse('issue:value-at-risk-trend')
        response = self.client.get(url, {'supplier': self.vendor.id})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)

        # Should only count first vendor's materials
        total_value_at_risk = sum(w['value_at_risk'] for w in response.data)
        self.assertEqual(total_value_at_risk, 18000.0)

    def test_value_at_risk_trend_view_empty_data(self):
        """Test value at risk trend view returns valid structure with no data"""
        url = reverse('issue:value-at-risk-trend')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data, list)
        self.assertGreaterEqual(len(response.data), 12)
        self.assertLessEqual(len(response.data), 14)

        # All weeks should have zero values
        for week_data in response.data:
            self.assertEqual(week_data['value_at_risk'], 0.0)
            self.assertEqual(week_data['value_mitigated'], 0.0)

    def test_value_at_risk_trend_view_multiple_materials_same_day(self):
        """Test view with multiple issues on same day"""
        today = timezone.now().date()
        issue_date = today - timedelta(days=3)

        # Create multiple materials
        material2 = TestDataFactory.create_material(
            name="Material 2",
            vendor=self.vendor
        )
        material3 = TestDataFactory.create_material(
            name="Material 3",
            vendor=self.vendor
        )

        # Create multiple issues on same day
        TestDataFactory.create_issue(
            issue_nbr="MULTI-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_issue(
            issue_nbr="MULTI-002",
            material=material2,
            status=Issue.IssueStatus.CLOSED,
            start_date=issue_date
        )
        TestDataFactory.create_issue(
            issue_nbr="MULTI-003",
            material=material3,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )

        # Create MaterialValueAtRiskHistory for all three
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=issue_date,
            dollars_at_risk_30_day=5000.0
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=material2,
            status_date=issue_date,
            dollars_at_risk_30_day=3000.0
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=material3,
            status_date=issue_date,
            dollars_at_risk_30_day=7000.0
        )

        url = reverse('issue:value-at-risk-trend')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Find week containing issue_date
        week_start = issue_date - timedelta(days=issue_date.weekday())
        week_entry = next((r for r in response.data if r['date'] == week_start.isoformat()), None)
        self.assertIsNotNone(week_entry)
        # Should sum all three materials
        self.assertEqual(week_entry['value_at_risk'], 15000.0)


class IssueFilterUnitTest(BaseTestCase):
    def test_issue_filter_exposes_ean_n4_and_global_ndc(self):
        from api.global_filters import CharInFilter
        from api.issue.models import Issue
        from api.issue.views import IssueFilter

        filter_instance = IssueFilter(queryset=Issue.objects.none())
        self.assertIn('ean_n4_nbr_11', filter_instance.filters)
        self.assertEqual(
            filter_instance.filters['ean_n4_nbr_11'].field_name,
            'material__ean_n4_nbr_11',
        )
        self.assertIn('ndc', filter_instance.filters)
        self.assertIsInstance(filter_instance.filters['ndc'], CharInFilter)
        self.assertEqual(filter_instance.filters['ndc'].field_name, 'material__ndc')
