from datetime import timedelta

from django.utils import timezone

from api.issue.models import Issue
from api.issue.services import IssueService
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class IssueServiceTest(BaseTestCase):
    def setUp(self):
        self.vendor = TestDataFactory.create_vendor(
            name="Test Vendor",
            country="US",
            risk_rating=0.8
        )
        # Note: risk_rating is stored as decimal (0.0-1.0), not percentage (0-100)
        self.material = TestDataFactory.create_material(
            name="Test Material",
            vendor=self.vendor,
            risk_rating=0.9,
            dollars_at_risk=1000.0
        )

    def test_get_weekly_open_issues_current_week(self):
        """Test weekly open issues"""
        # Get current date and calculate week boundaries
        today = timezone.now().date()

        # Calculate current week start (Monday)
        current_week_start = today - timedelta(days=today.weekday())

        # Calculate previous week start
        previous_week_start = current_week_start - timedelta(days=7)

        # Create current week issue
        TestDataFactory.create_issue(
            issue_nbr="CURRENT-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=current_week_start
        )

        # Create previous week issue
        TestDataFactory.create_issue(
            issue_nbr="PREVIOUS-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=previous_week_start
        )

        result = IssueService.get_weekly_open_issues()

        self.assertGreaterEqual(result['current_week_count'], 1)
        self.assertGreaterEqual(result['previous_week_count'], 0)
        self.assertEqual(result['week_start_date'], current_week_start)

    def test_get_weekly_open_issues_with_action_required(self):
        """Test weekly issues with action required dates"""
        today = timezone.now().date()
        current_week_start = today - timedelta(days=today.weekday())

        # Create issue with action required this week
        TestDataFactory.create_issue(
            issue_nbr="ACTION-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=current_week_start,
            act_required_date=current_week_start + timedelta(days=2)
        )

        result = IssueService.get_weekly_open_issues()

        self.assertGreaterEqual(result['current_week_requires_action_count'], 1)

    def test_get_country_issues(self):
        """Test country issues aggregation"""
        # Create issue
        TestDataFactory.create_issue(
            issue_nbr="COUNTRY-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )

        result = IssueService.get_country_issues()

        self.assertGreater(len(result), 0)
        us_country = next((item for item in result if item['country'] == 'US'), None)
        self.assertIsNotNone(us_country)
        self.assertGreaterEqual(us_country['open_issues_count'], 1)

    def test_get_top_riskiest_materials(self):
        """Test top riskiest materials"""
        # Create multiple materials with different risk ratings
        # Note: risk_rating is stored as decimal (0.0-1.0), not percentage (0-100)
        material2 = TestDataFactory.create_material(
            name="Low Risk Material",
            vendor=self.vendor,
            risk_rating=0.3,
            dollars_at_risk=1000.0
        )

        TestDataFactory.create_issue(
            issue_nbr="HIGH-RISK-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )
        TestDataFactory.create_issue(
            issue_nbr="LOW-RISK-001",
            material=material2,
            status=Issue.IssueStatus.OPEN
        )

        result = IssueService.get_top_riskiest_materials(limit=2)

        self.assertGreaterEqual(len(result['materials']), 1)
        # Should be ordered by risk_adjusted_value (highest first)
        # self.material: 0.9 * 1000 = 900
        # material2: 0.3 * 1000 = 300
        # So self.material should be first
        self.assertEqual(result['materials'][0], self.material)

    def test_get_top_riskiest_vendors(self):
        """Test top riskiest vendors"""
        vendor2 = TestDataFactory.create_vendor(
            name="Low Risk Vendor",
            country="CA",
            risk_rating=0.2
        )
        material2 = TestDataFactory.create_material(
            name="Material 2",
            vendor=vendor2
        )

        TestDataFactory.create_issue(
            issue_nbr="MANUF-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )
        TestDataFactory.create_issue(
            issue_nbr="MANUF-002",
            material=material2,
            status=Issue.IssueStatus.OPEN
        )

        result = IssueService.get_top_riskiest_vendors(limit=2)

        self.assertGreaterEqual(len(result['vendors']), 1)
        # Should be ordered by risk rating (highest first)
        self.assertEqual(result['vendors'][0], self.vendor)

    def test_get_top_riskiest_vendors_excludes_inactive(self):
        """Test that inactive vendors are excluded from top riskiest vendors."""
        inactive_vendor = TestDataFactory.create_vendor(
            name="Inactive High Risk",
            risk_rating=1.0,
            is_active=False
        )
        inactive_material = TestDataFactory.create_material(
            name="Inactive Material",
            vendor=inactive_vendor
        )
        TestDataFactory.create_issue(
            material=self.material,
            status=Issue.IssueStatus.OPEN
        )
        TestDataFactory.create_issue(
            material=inactive_material,
            status=Issue.IssueStatus.OPEN
        )

        result = IssueService.get_top_riskiest_vendors(limit=10)
        vendor_ids = [v.id for v in result['vendors']]
        self.assertNotIn(inactive_vendor.id, vendor_ids)

    def test_get_issue_with_action(self):
        """
        Test getting issues with actions
        """
        self.issue = TestDataFactory.create_issue(
            issue_nbr="ACTION-002",
            status=Issue.IssueStatus.OPEN,
            act_required_date=timezone.now().date() + timedelta(days=3)
        )
        self.action = TestDataFactory.create_action(
            issue=self.issue
        )
        issues_queryset = IssueService.get_issues_with_material_and_actions()

        # Convert QuerySet to list to check if issue is present
        issues_list = list(issues_queryset)
        self.assertGreater(len(issues_list), 0)
        self.assertIn(self.issue, issues_list)

        # Get the specific issue from the result and check its actions
        issue_from_result = next(issue for issue in issues_list if issue.id == self.issue.id)
        self.assertIn(self.action, issue_from_result.actions.all())

        user_cache = IssueService.get_user_cache_for_issues(issues_list)
        self.assertIsInstance(user_cache, dict)

    def test_get_two_week_issues_summary(self):
        """
        Test getting two-week issues summary
        """
        today = timezone.now().date()
        days_since_monday = today.weekday()
        current_period_start = today - timedelta(days=days_since_monday + 13)
        previous_period_start = current_period_start - timedelta(days=14)
        previous_period_end = current_period_start - timedelta(days=1)

        # Create issues in the current two-week period
        TestDataFactory.create_issue(
            issue_nbr="CURRENT-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=current_period_start + timedelta(days=1)
        )
        TestDataFactory.create_issue(
            issue_nbr="CURRENT-OPEN-002",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=current_period_start + timedelta(days=5)
        )
        TestDataFactory.create_issue(
            issue_nbr="CURRENT-CLOSED-001",
            material=self.material,
            status=Issue.IssueStatus.CLOSED,
            start_date=current_period_start + timedelta(days=3)
        )

        # Create issues in the previous two-week period
        TestDataFactory.create_issue(
            issue_nbr="PREVIOUS-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=previous_period_start + timedelta(days=2)
        )
        TestDataFactory.create_issue(
            issue_nbr="PREVIOUS-CLOSED-001",
            material=self.material,
            status=Issue.IssueStatus.CLOSED,
            start_date=previous_period_start + timedelta(days=5)
        )
        TestDataFactory.create_issue(
            issue_nbr="PREVIOUS-CLOSED-002",
            material=self.material,
            status=Issue.IssueStatus.CLOSED,
            start_date=previous_period_start + timedelta(days=10)
        )

        result = IssueService.get_two_week_issues_summary()

        # Current period assertions
        self.assertGreaterEqual(result['current_total_issues'], 3)
        self.assertGreaterEqual(result['current_opened_issues'], 2)
        self.assertGreaterEqual(result['current_closed_issues'], 1)

        # Previous period assertions
        self.assertGreaterEqual(result['previous_total_issues'], 3)
        self.assertGreaterEqual(result['previous_opened_issues'], 1)
        self.assertGreaterEqual(result['previous_closed_issues'], 2)

        # Period date assertions
        self.assertEqual(result['current_period_start'], current_period_start)
        self.assertEqual(result['previous_period_start'], previous_period_start)
        self.assertEqual(result['previous_period_end'], previous_period_end)

    def test_get_two_week_issues_summary_with_filters(self):
        """
        Test getting two-week issues summary with global filters
        """
        today = timezone.now().date()
        days_since_monday = today.weekday()
        current_period_start = today - timedelta(days=days_since_monday + 13)

        # Create another vendor and material
        vendor2 = TestDataFactory.create_vendor(
            name="Another Vendor",
            country="CA",
            risk_rating=0.5
        )
        material2 = TestDataFactory.create_material(
            name="Another Material",
            vendor=vendor2,
            risk_rating=0.6
        )

        # Create issues with first material in current period
        TestDataFactory.create_issue(
            issue_nbr="FILTERED-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=current_period_start + timedelta(days=1)
        )
        TestDataFactory.create_issue(
            issue_nbr="FILTERED-CLOSED-001",
            material=self.material,
            status=Issue.IssueStatus.CLOSED,
            start_date=current_period_start + timedelta(days=2)
        )

        # Create issues with second material in current period (should be filtered out)
        TestDataFactory.create_issue(
            issue_nbr="NOT-FILTERED-001",
            material=material2,
            status=Issue.IssueStatus.OPEN,
            start_date=current_period_start + timedelta(days=1)
        )

        # Test with supplier filter using subquery pattern
        from api.material.models import Material
        mat_nbr_subquery = Material.objects.filter(vendor__id=self.vendor.id).values_list('mat_nbr', flat=True)
        result = IssueService.get_two_week_issues_summary(mat_nbr_subquery=mat_nbr_subquery)

        # Should only count issues from the filtered vendor
        self.assertGreaterEqual(result['current_total_issues'], 2)
        self.assertGreaterEqual(result['current_opened_issues'], 1)
        self.assertGreaterEqual(result['current_closed_issues'], 1)

        # Test with material filter
        result = IssueService.get_two_week_issues_summary(direct_mat_nbr=self.material.mat_nbr)

        # Should only count issues from the filtered material
        self.assertGreaterEqual(result['current_total_issues'], 2)
        self.assertGreaterEqual(result['current_opened_issues'], 1)
        self.assertGreaterEqual(result['current_closed_issues'], 1)

    def test_get_today_issues_snapshot(self):
        """
        Test getting today's issues snapshot
        """
        today = timezone.now().date()

        # Create issues that started today
        TestDataFactory.create_issue(
            issue_nbr="TODAY-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today
        )
        TestDataFactory.create_issue(
            issue_nbr="TODAY-OPEN-002",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today
        )
        TestDataFactory.create_issue(
            issue_nbr="TODAY-CLOSED-001",
            material=self.material,
            status=Issue.IssueStatus.CLOSED,
            start_date=today
        )

        # Create issues that started yesterday (should not be counted)
        TestDataFactory.create_issue(
            issue_nbr="YESTERDAY-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today - timedelta(days=1)
        )

        result = IssueService.get_today_issues_snapshot()

        # Should only count issues that started today
        self.assertEqual(result['total_issues'], 3)  # 2 open + 1 closed
        self.assertEqual(result['open_issues'], 2)  # 2 open
        self.assertEqual(result['snapshot_date'], today)

    def test_get_today_issues_snapshot_no_data(self):
        """
        Test getting today's issues snapshot when there are no issues today
        """
        today = timezone.now().date()

        # Create issues that started yesterday (should not be counted)
        TestDataFactory.create_issue(
            issue_nbr="YESTERDAY-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today - timedelta(days=1)
        )

        result = IssueService.get_today_issues_snapshot()

        # Should return zero counts
        self.assertEqual(result['total_issues'], 0)
        self.assertEqual(result['open_issues'], 0)
        self.assertEqual(result['snapshot_date'], today)

    def test_get_today_issues_snapshot_with_filter_params(self):
        """
        Test getting today's issues snapshot with global filters
        """
        today = timezone.now().date()

        # Create another vendor and material
        vendor2 = TestDataFactory.create_vendor(
            name="Another Vendor",
            country="CA",
            risk_rating=0.5
        )
        material2 = TestDataFactory.create_material(
            name="Another Material",
            vendor=vendor2,
            risk_rating=0.6
        )

        # Create issues with first material that started today
        TestDataFactory.create_issue(
            issue_nbr="FILTERED-OPEN-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=today
        )
        TestDataFactory.create_issue(
            issue_nbr="FILTERED-CLOSED-001",
            material=self.material,
            status=Issue.IssueStatus.CLOSED,
            start_date=today
        )

        # Create issues with second material that started today (should be filtered out)
        TestDataFactory.create_issue(
            issue_nbr="NOT-FILTERED-001",
            material=material2,
            status=Issue.IssueStatus.OPEN,
            start_date=today
        )

        # Test with supplier filter using subquery pattern
        from api.material.models import Material
        mat_nbr_subquery = Material.objects.filter(vendor__id=self.vendor.id).values_list('mat_nbr', flat=True)
        result = IssueService.get_today_issues_snapshot(mat_nbr_subquery=mat_nbr_subquery)

        # Should only count issues from the filtered vendor
        self.assertEqual(result['total_issues'], 2)
        self.assertEqual(result['open_issues'], 1)
        self.assertEqual(result['snapshot_date'], today)

        # Test with material filter
        result = IssueService.get_today_issues_snapshot(direct_mat_nbr=self.material.mat_nbr)

        # Should only count issues from the filtered material
        self.assertEqual(result['total_issues'], 2)
        self.assertEqual(result['open_issues'], 1)
        self.assertEqual(result['snapshot_date'], today)

    def test_get_value_at_risk_trend_basic(self):
        """Test basic value at risk trend calculation (weekly aggregation)"""
        today = timezone.now().date()

        # Use dates in different weeks so each week has one risk value (no overwrite)
        issue_date = today - timedelta(days=10)
        action_date = today - timedelta(days=3)
        issue = TestDataFactory.create_issue(
            issue_nbr="TREND-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )

        # Create MaterialValueAtRiskHistory for issue's week
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=issue_date,
            dollars_at_risk_30_day=10000.0
        )

        action = TestDataFactory.create_action(issue=issue)
        action.created_at = timezone.make_aware(
            timezone.datetime.combine(action_date, timezone.datetime.min.time())
        )
        action.save()

        # Create MaterialValueAtRiskHistory for action's week (different week)
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=action_date,
            dollars_at_risk_30_day=8000.0
        )

        result = IssueService.get_value_at_risk_trend()

        # Check it returns a list of weekly buckets (~13 weeks in 90 days)
        self.assertIsInstance(result, list)
        self.assertGreaterEqual(len(result), 12)
        self.assertLessEqual(len(result), 14)

        week_start_issue = issue_date - timedelta(days=issue_date.weekday())
        week_start_action = action_date - timedelta(days=action_date.weekday())
        week_issue = next((r for r in result if r['date'] == week_start_issue.isoformat()), None)
        week_action = next((r for r in result if r['date'] == week_start_action.isoformat()), None)
        self.assertIsNotNone(week_issue)
        self.assertIsNotNone(week_action)
        self.assertEqual(week_issue['value_at_risk'], 10000.0)
        self.assertEqual(week_action['value_mitigated'], 8000.0)

    def test_get_value_at_risk_trend_multiple_issues_same_day(self):
        """Test trend when multiple issues open on same day"""
        today = timezone.now().date()
        issue_date = today - timedelta(days=10)

        # Create two materials with different risk values
        material2 = TestDataFactory.create_material(
            name="Material 2",
            vendor=self.vendor
        )

        # Create two issues on same day
        TestDataFactory.create_issue(
            issue_nbr="MULTI-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_issue(
            issue_nbr="MULTI-002",
            material=material2,
            status=Issue.IssueStatus.CLOSED,
            start_date=issue_date
        )

        # Create MaterialValueAtRiskHistory for both
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=issue_date,
            dollars_at_risk_30_day=5000.0
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=material2,
            status_date=issue_date,
            dollars_at_risk_30_day=3000.0
        )

        result = IssueService.get_value_at_risk_trend()

        # Find week containing issue_date
        week_start = issue_date - timedelta(days=issue_date.weekday())
        week_entry = next((r for r in result if r['date'] == week_start.isoformat()), None)
        self.assertIsNotNone(week_entry)
        self.assertEqual(week_entry['value_at_risk'], 8000.0)  # 5000 + 3000

    def test_get_value_at_risk_trend_no_material_risk_data(self):
        """Test trend when issues exist but no MaterialValueAtRiskHistory data"""
        today = timezone.now().date()
        issue_date = today - timedelta(days=3)

        # Create issue but NO MaterialValueAtRiskHistory
        TestDataFactory.create_issue(
            issue_nbr="NO-RISK-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )

        result = IssueService.get_value_at_risk_trend()

        # All weeks should have 0 value
        for week_data in result:
            self.assertEqual(week_data['value_at_risk'], 0.0)
            self.assertEqual(week_data['value_mitigated'], 0.0)

    def test_get_value_at_risk_trend_with_material_filter(self):
        """Test trend with material filter"""
        today = timezone.now().date()
        issue_date = today - timedelta(days=7)

        # Create another material and issue
        vendor2 = TestDataFactory.create_vendor(name="Vendor 2")
        material2 = TestDataFactory.create_material(
            name="Material 2",
            vendor=vendor2
        )

        # Create issue for first material
        TestDataFactory.create_issue(
            issue_nbr="FILTERED-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=issue_date,
            dollars_at_risk_30_day=6000.0
        )

        # Create issue for second material (should be filtered out)
        TestDataFactory.create_issue(
            issue_nbr="NOT-FILTERED-001",
            material=material2,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=material2,
            status_date=issue_date,
            dollars_at_risk_30_day=4000.0
        )

        # Test with direct material filter
        result = IssueService.get_value_at_risk_trend(direct_mat_nbr=self.material.mat_nbr)

        # Should only count first material's risk (one week has the issue)
        total_value_at_risk = sum(w['value_at_risk'] for w in result)
        self.assertEqual(total_value_at_risk, 6000.0)

    def test_get_value_at_risk_trend_with_vendor_filter(self):
        """Test trend with vendor filter using subquery"""
        today = timezone.now().date()
        issue_date = today - timedelta(days=4)

        # Create another vendor and material
        vendor2 = TestDataFactory.create_vendor(name="Vendor 2")
        material2 = TestDataFactory.create_material(
            name="Material 2",
            vendor=vendor2
        )

        # Create issue for first vendor
        TestDataFactory.create_issue(
            issue_nbr="VENDOR-FILTER-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=issue_date,
            dollars_at_risk_30_day=7000.0
        )

        # Create issue for second vendor (should be filtered out)
        TestDataFactory.create_issue(
            issue_nbr="VENDOR-FILTER-002",
            material=material2,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=material2,
            status_date=issue_date,
            dollars_at_risk_30_day=5000.0
        )

        # Test with vendor subquery filter
        from api.material.models import Material
        mat_nbr_subquery = Material.objects.filter(
            vendor__id=self.vendor.id
        ).values_list('mat_nbr', flat=True)

        result = IssueService.get_value_at_risk_trend(mat_nbr_subquery=mat_nbr_subquery)

        # Should only count first vendor's materials
        total_value_at_risk = sum(w['value_at_risk'] for w in result)
        self.assertEqual(total_value_at_risk, 7000.0)

    def test_get_value_at_risk_trend_percentage_calculation(self):
        """Test that percentages are calculated correctly"""
        today = timezone.now().date()
        issue_date = today - timedelta(days=1)
        action_date = today - timedelta(days=1)

        issue = TestDataFactory.create_issue(
            issue_nbr="PCT-001",
            material=self.material,
            status=Issue.IssueStatus.OPEN,
            start_date=issue_date
        )

        action = TestDataFactory.create_action(issue=issue)
        action.created_at = timezone.make_aware(
            timezone.datetime.combine(action_date, timezone.datetime.min.time())
        )
        action.save()

        # Create MaterialValueAtRiskHistory
        TestDataFactory.create_material_value_at_risk_history(
            material=self.material,
            status_date=issue_date,
            dollars_at_risk_30_day=3000.0
        )

        result = IssueService.get_value_at_risk_trend()

        # Week containing issue_date/action_date (same day => same week)
        week_start = issue_date - timedelta(days=issue_date.weekday())
        week_entry = next((r for r in result if r['date'] == week_start.isoformat()), None)
        self.assertIsNotNone(week_entry)
        # Same material same week: value_at_risk = 3000, value_mitigated = 3000, 50/50
        self.assertEqual(week_entry['value_at_risk'], 3000.0)
        self.assertEqual(week_entry['value_mitigated'], 3000.0)
        self.assertEqual(week_entry['value_at_risk_pct'], 50.0)
        self.assertEqual(week_entry['value_mitigated_pct'], 50.0)

    def test_get_value_at_risk_trend_empty_data(self):
        """Test trend with no data at all"""
        result = IssueService.get_value_at_risk_trend()

        # Should still return weekly buckets (~13) of zeros
        self.assertGreaterEqual(len(result), 12)
        self.assertLessEqual(len(result), 14)
        for week_data in result:
            self.assertEqual(week_data['value_at_risk'], 0.0)
            self.assertEqual(week_data['value_mitigated'], 0.0)


class IssueServiceDropShipShortDateFilterTest(BaseTestCase):
    """Tests that drop-ship and short-date flagged materials are excluded from issue queries."""

    def setUp(self):
        self.vendor = TestDataFactory.create_vendor(name="Test Vendor", country="US", risk_rating=0.8)
        self.normal_material = TestDataFactory.create_material(
            vendor=self.vendor, risk_rating=0.9, dollars_at_risk=1000.0
        )
        self.drop_ship_material = TestDataFactory.create_material(
            vendor=self.vendor, risk_rating=0.8, dollars_at_risk=2000.0, drop_ship_flg=1
        )
        self.short_date_material = TestDataFactory.create_material(
            vendor=self.vendor, risk_rating=0.7, dollars_at_risk=3000.0, short_date_flg=1
        )

    def test_weekly_open_issues_excludes_flagged(self):
        """Weekly open issues should not count issues on flagged materials."""
        today = timezone.now().date()
        current_week_start = today - timedelta(days=today.weekday())

        TestDataFactory.create_issue(
            issue_nbr="NORMAL-001", material=self.normal_material,
            status=Issue.IssueStatus.OPEN, start_date=current_week_start
        )
        TestDataFactory.create_issue(
            issue_nbr="DROP-001", material=self.drop_ship_material,
            status=Issue.IssueStatus.OPEN, start_date=current_week_start
        )
        TestDataFactory.create_issue(
            issue_nbr="SHORT-001", material=self.short_date_material,
            status=Issue.IssueStatus.OPEN, start_date=current_week_start
        )

        result = IssueService.get_weekly_open_issues()
        self.assertEqual(result['current_week_count'], 1)

    def test_today_issues_snapshot_excludes_flagged(self):
        """Today's snapshot should exclude issues on flagged materials."""
        today = timezone.now().date()

        TestDataFactory.create_issue(
            issue_nbr="TODAY-NORMAL", material=self.normal_material,
            status=Issue.IssueStatus.OPEN, start_date=today
        )
        TestDataFactory.create_issue(
            issue_nbr="TODAY-DROP", material=self.drop_ship_material,
            status=Issue.IssueStatus.OPEN, start_date=today
        )

        result = IssueService.get_today_issues_snapshot()
        self.assertEqual(result['total_issues'], 1)
        self.assertEqual(result['open_issues'], 1)

    def test_top_riskiest_materials_excludes_flagged(self):
        """Top riskiest materials should not include flagged materials."""
        TestDataFactory.create_issue(
            issue_nbr="RISKY-NORMAL", material=self.normal_material,
            status=Issue.IssueStatus.OPEN
        )
        TestDataFactory.create_issue(
            issue_nbr="RISKY-DROP", material=self.drop_ship_material,
            status=Issue.IssueStatus.OPEN
        )

        result = IssueService.get_top_riskiest_materials(limit=10)
        mat_ids = [m.id for m in result['materials']]
        self.assertIn(self.normal_material.id, mat_ids)
        self.assertNotIn(self.drop_ship_material.id, mat_ids)

    def test_issues_with_material_and_actions_excludes_flagged(self):
        """Open issues list should exclude issues on flagged materials."""
        TestDataFactory.create_issue(
            issue_nbr="OPEN-NORMAL", material=self.normal_material,
            status=Issue.IssueStatus.OPEN
        )
        TestDataFactory.create_issue(
            issue_nbr="OPEN-SHORT", material=self.short_date_material,
            status=Issue.IssueStatus.OPEN
        )

        queryset = IssueService.get_issues_with_material_and_actions()
        issue_mat_ids = [i.material_id for i in queryset]
        self.assertIn(self.normal_material.mat_nbr, issue_mat_ids)
        self.assertNotIn(self.short_date_material.mat_nbr, issue_mat_ids)
