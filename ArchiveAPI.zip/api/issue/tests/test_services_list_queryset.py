from api.issue.services import IssueService
from tests.BaseTestCase import BaseTestCase, MVTestCase
from tests.TestDataFactory import TestDataFactory
from tests.test_mv_setup import MaterializedViewTestHelper


ISSUE_EFFECTIVE_METRICS_MV = ["issue_effective_metrics_mv"]


def refresh_issue_mvs(view_names=None):
    MaterializedViewTestHelper.refresh_materialized_views(
        view_names or ISSUE_EFFECTIVE_METRICS_MV
    )


class AllIssuesListQuerysetTest(BaseTestCase):
    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.material = TestDataFactory.create_material(vendor=self.vendor)

    def test_list_queryset_annotates_has_actions(self):
        issue_with_action = TestDataFactory.create_issue(
            issue_nbr="HAS-ACT",
            material=self.material,
        )
        TestDataFactory.create_action(issue=issue_with_action)
        TestDataFactory.create_issue(issue_nbr="NO-ACT", material=self.material)

        rows = {
            row.issue_nbr: row.has_actions
            for row in IssueService.get_all_issues_list_queryset()
        }
        self.assertTrue(rows["HAS-ACT"])
        self.assertFalse(rows["NO-ACT"])


class DistinctIssuesByMaterialTest(MVTestCase):
    def setUp(self):
        self.vendor = TestDataFactory.create_vendor()
        self.m1 = TestDataFactory.create_material(vendor=self.vendor)
        self.m2 = TestDataFactory.create_material(vendor=self.vendor)

    def test_distinct_issues_by_material_keeps_one_per_material(self):
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_issue(issue_nbr="A-1", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="A-2", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="B-1", material=self.m2)
        refresh_issue_mvs()

        rows = list(
            IssueService.distinct_issues_by_material(
                IssueService.get_all_issues_list_queryset()
            )
        )
        self.assertEqual(len(rows), 2)
        mat_nbrs = {row.material_id for row in rows}
        self.assertEqual(mat_nbrs, {self.m1.mat_nbr, self.m2.mat_nbr})

    def test_distinct_issues_by_material_excludes_material_less_issues(self):
        with MaterializedViewTestHelper.defer_auto_refresh():
            TestDataFactory.create_issue(issue_nbr="MAT-1", material=self.m1)
            TestDataFactory.create_issue(issue_nbr="GCN-1", fdb_gcn_seq_nbr="GCN-X")
        refresh_issue_mvs()

        rows = IssueService.distinct_issues_by_material(
            IssueService.get_all_issues_list_queryset()
        )
        self.assertEqual({row.issue_nbr for row in rows}, {"MAT-1"})
