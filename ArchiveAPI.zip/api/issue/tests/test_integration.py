from api.issue.models import Issue
from api.issue.services import IssueService
from tests.BaseTestCase import BaseTestCase
from tests.TestDataFactory import TestDataFactory


class IssueServiceIntegrationTest(BaseTestCase):
    """Integration tests that test the full service layer with database interactions."""

    @classmethod
    def setUpTestData(cls):
        cls.vendor = TestDataFactory.create_vendor()
        cls.material = TestDataFactory.create_material(
            vendor=cls.vendor
        )

    def test_full_workflow_country_issues(self):
        """Test the complete workflow from model creation to service response."""

        vendor_ca = TestDataFactory.create_vendor(country="CA")
        material_ca = TestDataFactory.create_material(
            vendor=vendor_ca
        )

        self.issue_1 = TestDataFactory.create_issue(
            issue_nbr="US-001",
            material=self.material
        )
        self.issue_2 = TestDataFactory.create_issue(
            issue_nbr="CA-002",
            material=self.material,
        )

        self.issue_3 = TestDataFactory.create_issue(
            material=material_ca
        )
        result = IssueService.get_country_issues()

        self.assertEqual(len(result), 2)
        us_data = next((item for item in result if item['country'] == 'US'), None)
        ca_data = next((item for item in result if item['country'] == 'CA'), None)

        self.assertIsNotNone(us_data)
        self.assertIsNotNone(ca_data)
        self.assertEqual(us_data['open_issues_count'], 2)
        self.assertEqual(ca_data['open_issues_count'], 1)

    def test_database_constraints_and_relationships(self):
        """Test that database relationships and constraints work correctly."""

        issue = TestDataFactory.create_issue(material=self.material)

        # Test relationship
        self.assertEqual(issue.material.vendor, self.vendor)

        # Test cascade delete
        material_id = self.material.id
        self.material.delete()

        # Issue should be deleted due to CASCADE
        self.assertFalse(Issue.objects.filter(material_id=material_id).exists())
