from datetime import date

from tests.BaseTestCase import BaseTestCase

from api.issue.serializers import (
    WeeklyIssueCountSerializer,
    CountryIssueSerializer,
    RiskiestMaterialsSerializer,
    RiskiestVendorsSerializer,
    TwoWeekIssuesSummarySerializer
)
from tests.TestDataFactory import TestDataFactory


class IssueSerializerTest(BaseTestCase):
    def test_weekly_issue_count_serializer(self):
        data = {
            'current_week_count': 5,
            'previous_week_count': 3,
            'week_start_date': date(2024, 1, 8),
            'previous_week_start_date': date(2024, 1, 1),
            'current_week_requires_action_count': 2
        }
        serializer = WeeklyIssueCountSerializer(data)
        self.assertEqual(serializer.data['current_week_count'], 5)
        self.assertEqual(serializer.data['previous_week_count'], 3)

    def test_country_issue_serializer(self):
        vendor = TestDataFactory.create_vendor(
            name="Test Vendor",
            country="US"
        )
        data = {
            'country': 'US',
            'country_name': 'United States',
            'open_issues_count': 10,
            'vendors': [vendor]
        }
        serializer = CountryIssueSerializer(data)
        self.assertEqual(serializer.data['country'], 'US')
        self.assertEqual(serializer.data['open_issues_count'], 10)

    def test_riskiest_materials_serializer(self):
        vendor = TestDataFactory.create_vendor(
            name="Test Vendor",
            country="US"
        )
        material = TestDataFactory.create_material(
            name="Test Material",
            vendor=vendor
        )
        data = {'materials': [material]}
        serializer = RiskiestMaterialsSerializer(data)
        self.assertEqual(len(serializer.data['materials']), 1)

    def test_riskiest_vendors_serializer(self):
        vendor = TestDataFactory.create_vendor(
            name="Test Vendor",
            country="US"
        )
        data = {'vendors': [vendor]}
        serializer = RiskiestVendorsSerializer(data)
        self.assertEqual(len(serializer.data['vendors']), 1)

    def test_two_week_issues_summary_serializer(self):
        data = {
            'current_total_issues': 10,
            'current_opened_issues': 6,
            'current_closed_issues': 4,
            'previous_total_issues': 8,
            'previous_opened_issues': 5,
            'previous_closed_issues': 3,
            'current_period_start': date(2024, 1, 8),
            'current_period_end': date(2024, 1, 21),
            'previous_period_start': date(2023, 12, 25),
            'previous_period_end': date(2024, 1, 7)
        }
        serializer = TwoWeekIssuesSummarySerializer(data)
        self.assertEqual(serializer.data['current_total_issues'], 10)
        self.assertEqual(serializer.data['current_opened_issues'], 6)
        self.assertEqual(serializer.data['current_closed_issues'], 4)
        self.assertEqual(serializer.data['previous_total_issues'], 8)
        self.assertEqual(serializer.data['previous_opened_issues'], 5)
        self.assertEqual(serializer.data['previous_closed_issues'], 3)
