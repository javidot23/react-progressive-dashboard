from datetime import timedelta

from django.urls import reverse
from django.utils import timezone
from rest_framework import status

from api.issue.models import Issue
from tests.BaseTestCase import BaseAPITestCase
from tests.TestDataFactory import TestDataFactory


class IssueKpiTrendIntegrationTests(BaseAPITestCase):
    def test_opened_issues_trend_weekly(self):
        today = timezone.now().date()
        this_week_start = today - timedelta(days=today.weekday())
        last_week_start = this_week_start - timedelta(days=7)

        material = TestDataFactory.create_material()

        # Last week: 2 total, 1 open
        TestDataFactory.create_issue(
            issue_nbr="W1-OPEN",
            material=material,
            status=Issue.IssueStatus.OPEN,
            start_date=last_week_start,
        )
        TestDataFactory.create_issue(
            issue_nbr="W1-CLOSED",
            material=material,
            status=Issue.IssueStatus.CLOSED,
            start_date=last_week_start,
        )

        # This week: 1 total, 1 open
        TestDataFactory.create_issue(
            issue_nbr="W2-OPEN",
            material=material,
            status=Issue.IssueStatus.OPEN,
            start_date=this_week_start,
        )

        url = reverse("issue:today-issues-snapshot")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("trend", response.data)
        self.assertEqual(response.data["trend"]["kpi"], "opened_issues")
        self.assertEqual(response.data["trend"]["unit"], "count")
        self.assertIsInstance(response.data["trend"]["points"], list)

        points_by_start = {p["period_start"]: p for p in response.data["trend"]["points"]}
        self.assertIn(last_week_start, points_by_start)
        self.assertIn(this_week_start, points_by_start)

        last_week_point = points_by_start[last_week_start]
        self.assertEqual(last_week_point["value"], 1.0)
        self.assertEqual(last_week_point["metrics"]["total_issues"], 2)

        this_week_point = points_by_start[this_week_start]
        self.assertEqual(this_week_point["value"], 1.0)
        self.assertEqual(this_week_point["metrics"]["total_issues"], 1)

    def test_value_at_risk_trend(self):
        today = timezone.now().date()
        this_week_start = today - timedelta(days=today.weekday())
        last_week_start = this_week_start - timedelta(days=7)

        material = TestDataFactory.create_material()

        # Last week issue + risk
        TestDataFactory.create_issue(
            issue_nbr="VAR-W1",
            material=material,
            status=Issue.IssueStatus.OPEN,
            start_date=last_week_start,
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=material,
            status_date=last_week_start,
            dollars_at_risk_30_day=2000.0,
        )

        # This week issue + risk
        TestDataFactory.create_issue(
            issue_nbr="VAR-W2",
            material=material,
            status=Issue.IssueStatus.OPEN,
            start_date=this_week_start,
        )
        TestDataFactory.create_material_value_at_risk_history(
            material=material,
            status_date=this_week_start,
            dollars_at_risk_30_day=1000.0,
        )

        url = reverse("issue:value-at-risk-trend")
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        self.assertIsInstance(resp.data, list)
        self.assertGreaterEqual(len(resp.data), 12)
        self.assertLessEqual(len(resp.data), 14)  # weekly buckets over 90 days

        # Check structure of data points (weekly)
        for point in resp.data:
            self.assertIn("week", point)
            self.assertIn("date", point)
            self.assertIn("value_at_risk", point)
            self.assertIn("value_mitigated", point)
            self.assertIn("value_at_risk_pct", point)
            self.assertIn("value_mitigated_pct", point)
