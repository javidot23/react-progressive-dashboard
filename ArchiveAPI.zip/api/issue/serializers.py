from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from api.action.serializers import ActionSerializer
from api.issue.models import Issue
from api.issue_note.serializers import IssueNoteSerializer
from api.material.serializers import MaterialSerializer, MaterialWithVendorSerializer
from api.potential_action.serializers import PotentialActionSerializer
from api.supply_chain_events.serializers import SupplyChainEventMinimalSerializer
from api.vendor.serializers import VendorSerializer


class WeeklyIssueCountSerializer(serializers.Serializer):
    current_week_count = serializers.IntegerField()
    previous_week_count = serializers.IntegerField()
    week_start_date = serializers.DateField()
    previous_week_start_date = serializers.DateField()
    current_week_requires_action_count = serializers.IntegerField()


class TwoWeekIssuesSummarySerializer(serializers.Serializer):
    current_total_issues = serializers.IntegerField()
    current_opened_issues = serializers.IntegerField()
    current_closed_issues = serializers.IntegerField()
    previous_total_issues = serializers.IntegerField()
    previous_opened_issues = serializers.IntegerField()
    previous_closed_issues = serializers.IntegerField()
    current_period_start = serializers.DateField()
    current_period_end = serializers.DateField()
    previous_period_start = serializers.DateField()
    previous_period_end = serializers.DateField()


class TodayIssuesSnapshotSerializer(serializers.Serializer):
    open_issues = serializers.IntegerField()
    total_issues = serializers.IntegerField()
    snapshot_date = serializers.DateField()
    kpi_value = serializers.IntegerField()
    kpi_total = serializers.IntegerField()
    trend = serializers.DictField(required=False)


class DailyValueAtRiskSerializer(serializers.Serializer):
    day = serializers.IntegerField()
    date = serializers.CharField()
    value_at_risk = serializers.FloatField()
    value_mitigated = serializers.FloatField()
    value_at_risk_pct = serializers.FloatField()
    value_mitigated_pct = serializers.FloatField()


class WeeklyValueAtRiskSerializer(serializers.Serializer):
    week = serializers.IntegerField()
    date = serializers.CharField()
    value_at_risk = serializers.FloatField()
    value_mitigated = serializers.FloatField()
    value_at_risk_pct = serializers.FloatField()
    value_mitigated_pct = serializers.FloatField()


class CountryIssueSerializer(serializers.Serializer):
    country = serializers.CharField()
    country_name = serializers.CharField()
    open_issues_count = serializers.IntegerField()
    vendors = VendorSerializer(many=True, read_only=True)


class RiskiestMaterialsSerializer(serializers.Serializer):
    materials = MaterialSerializer(many=True, read_only=True)


class RiskiestVendorsSerializer(serializers.Serializer):
    vendors = VendorSerializer(many=True, read_only=True)


class IssueWithMaterialAndActionsSerializer(serializers.ModelSerializer):
    actions = ActionSerializer(many=True, source='action_list')
    potential_actions = PotentialActionSerializer(many=True, source='potential_action_list')
    material = MaterialWithVendorSerializer()
    risk_adjusted_value = serializers.FloatField(read_only=True)
    notes_count = serializers.IntegerField(read_only=True, default=0)
    last_note = serializers.SerializerMethodField()

    class Meta:
        model = Issue
        fields = "__all__"

    @extend_schema_field(IssueNoteSerializer(allow_null=True))
    def get_last_note(self, obj):
        last_note = getattr(obj, 'last_note', None)
        if last_note is None:
            return None
        data = IssueNoteSerializer(last_note, context=self.context).data
        data.pop('user', None)
        return data


class _IssueAtGranularityBaseSerializer(serializers.ModelSerializer):
    material = MaterialWithVendorSerializer(allow_null=True)
    granularity_type = serializers.CharField(read_only=True)
    hicl_description = serializers.CharField(read_only=True)
    impacted_material_count = serializers.IntegerField(read_only=True)
    effective_risk_rating = serializers.FloatField(read_only=True)
    effective_dollars_at_risk = serializers.FloatField(read_only=True)
    effective_risk_adjusted_value = serializers.FloatField(read_only=True)
    driving_event = serializers.SerializerMethodField()
    notes_count = serializers.IntegerField(read_only=True, default=0)
    last_note = serializers.SerializerMethodField()

    class Meta:
        model = Issue
        fields = "__all__"

    @extend_schema_field(IssueNoteSerializer(allow_null=True))
    def get_last_note(self, obj):
        last_note = getattr(obj, 'last_note', None)
        if last_note is None:
            return None
        data = IssueNoteSerializer(last_note, context=self.context).data
        data.pop('user', None)
        return data

    @extend_schema_field(SupplyChainEventMinimalSerializer(allow_null=True))
    def get_driving_event(self, obj):
        event = getattr(obj, 'driving_event', None)
        if event is None:
            return None
        return SupplyChainEventMinimalSerializer(event, context=self.context).data


class IssueAtGranularityListSerializer(_IssueAtGranularityBaseSerializer):
    has_actions = serializers.BooleanField(read_only=True)


class IssueAtGranularitySerializer(_IssueAtGranularityBaseSerializer):
    """Issue presented at its original granularity (material / gcn / ndc / fei / hicl),
    with the derived granularity_type, grain-aware effective_* metrics, and the
    supply-chain event driving the issue."""
    actions = ActionSerializer(many=True, source='action_list')
    potential_actions = PotentialActionSerializer(many=True, source='potential_action_list')


class IssueImpactedMaterialSerializer(MaterialSerializer):
    """Material representation for an issue's impacted-materials endpoint."""
    unfilled_qty = serializers.IntegerField(read_only=True)
    risk_adjusted_value = serializers.FloatField(read_only=True)
