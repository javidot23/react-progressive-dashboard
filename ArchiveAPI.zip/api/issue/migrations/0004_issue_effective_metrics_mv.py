from django.db import migrations

CREATE_SQL = """
DROP MATERIALIZED VIEW IF EXISTS issue_effective_metrics_mv CASCADE;

CREATE MATERIALIZED VIEW issue_effective_metrics_mv AS
WITH gcn_agg AS (
    SELECT fdb_gcn_seq_nbr AS grain,
           AVG(risk_rating)     AS avg_rr,
           SUM(dollars_at_risk) AS sum_dar,
           COUNT(*)             AS material_count
    FROM materials
    WHERE fdb_gcn_seq_nbr IS NOT NULL AND fdb_gcn_seq_nbr <> ''
    GROUP BY fdb_gcn_seq_nbr
),
ndc_agg AS (
    SELECT ndc AS grain,
           AVG(risk_rating)     AS avg_rr,
           SUM(dollars_at_risk) AS sum_dar,
           COUNT(*)             AS material_count
    FROM materials
    WHERE ndc IS NOT NULL AND ndc <> ''
    GROUP BY ndc
),
hicl_agg AS (
    SELECT hicl AS grain,
           AVG(risk_rating)      AS avg_rr,
           SUM(dollars_at_risk)  AS sum_dar,
           COUNT(*)              AS material_count,
           MIN(hicl_description) AS hicl_description
    FROM materials
    WHERE hicl IS NOT NULL AND hicl <> ''
    GROUP BY hicl
),
eff AS (
    SELECT
        i.id AS issue_id,
        CASE
            WHEN i.mat_nbr IS NOT NULL THEN m.risk_rating
            WHEN i.fdb_gcn_seq_nbr IS NOT NULL AND i.fdb_gcn_seq_nbr <> '' THEN g.avg_rr
            WHEN i.ndc IS NOT NULL AND i.ndc <> '' THEN n.avg_rr
            WHEN i.hicl IS NOT NULL AND i.hicl <> '' THEN h.avg_rr
        END AS eff_rr,
        CASE
            WHEN i.mat_nbr IS NOT NULL THEN m.dollars_at_risk
            WHEN i.fdb_gcn_seq_nbr IS NOT NULL AND i.fdb_gcn_seq_nbr <> '' THEN g.sum_dar
            WHEN i.ndc IS NOT NULL AND i.ndc <> '' THEN n.sum_dar
            WHEN i.hicl IS NOT NULL AND i.hicl <> '' THEN h.sum_dar
        END AS eff_dar,
        CASE
            WHEN i.mat_nbr IS NOT NULL THEN 1
            WHEN i.fdb_gcn_seq_nbr IS NOT NULL AND i.fdb_gcn_seq_nbr <> '' THEN g.material_count
            WHEN i.ndc IS NOT NULL AND i.ndc <> '' THEN n.material_count
            WHEN i.hicl IS NOT NULL AND i.hicl <> '' THEN h.material_count
            ELSE 0
        END AS impacted_material_count,
        CASE
            WHEN i.hicl IS NOT NULL AND i.hicl <> '' THEN h.hicl_description
        END AS hicl_description
    FROM issue i
    LEFT JOIN materials m ON i.mat_nbr = m.mat_nbr
    LEFT JOIN gcn_agg  g ON i.fdb_gcn_seq_nbr = g.grain
    LEFT JOIN ndc_agg  n ON i.ndc = n.grain
    LEFT JOIN hicl_agg h ON i.hicl = h.grain
)
SELECT
    issue_id,
    COALESCE(eff_rr, 0.0)  AS effective_risk_rating,
    COALESCE(eff_dar, 0.0) AS effective_dollars_at_risk,
    COALESCE(eff_rr, 0.0) * COALESCE(eff_dar, 0.0) AS effective_risk_adjusted_value,
    COALESCE(impacted_material_count, 0) AS impacted_material_count,
    hicl_description
FROM eff;

CREATE UNIQUE INDEX idx_issue_eff_metrics_pk  ON issue_effective_metrics_mv (issue_id);
CREATE INDEX idx_issue_eff_metrics_rr  ON issue_effective_metrics_mv (effective_risk_rating DESC NULLS LAST);
CREATE INDEX idx_issue_eff_metrics_dar ON issue_effective_metrics_mv (effective_dollars_at_risk DESC NULLS LAST);
CREATE INDEX idx_issue_eff_metrics_rav ON issue_effective_metrics_mv (effective_risk_adjusted_value DESC NULLS LAST);
CREATE INDEX idx_issue_eff_metrics_imc ON issue_effective_metrics_mv (impacted_material_count DESC NULLS LAST);
"""

DROP_SQL = "DROP MATERIALIZED VIEW IF EXISTS issue_effective_metrics_mv CASCADE;"


class Migration(migrations.Migration):

    dependencies = [
        ('issue', '0003_alter_issue_unique_together_issue_date_identified_and_more'),
        ('material', '0013_material_hicl_description'),
    ]

    operations = [
        migrations.RunSQL(sql=CREATE_SQL, reverse_sql=DROP_SQL),
    ]
