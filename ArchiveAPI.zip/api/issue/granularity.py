"""Granularity helpers for issues and supply-chain events.

Issues and events are stored at the grain they were recorded at: material, gcn
(fdb_gcn_seq_nbr), ndc, fei (fei_number), or hicl, optionally scoped to a plant.
The granularity type is derived by precedence (material -> gcn -> ndc -> fei ->
hicl), with a ``_plant`` suffix for the material/gcn cases when a plant is set.

material / gcn / ndc / hicl resolve to ``Material`` rows; ``fei`` has no Material
column and resolves to nothing.
"""
from django.db.models import (
    BigIntegerField,
    Case,
    CharField,
    F,
    OuterRef,
    Q,
    Subquery,
    Sum,
    Value,
    When,
)
from django.db.models.functions import Coalesce


def _present(field, is_fk=False):
    cond = Q(**{f"{field}__isnull": False})
    if not is_fk:
        cond &= ~Q(**{field: ""})
    return cond


GRANULARITY_TYPE_EXPR = Case(
    When(_present("material_id", is_fk=True) & _present("plant_id", is_fk=True), then=Value("material_plant")),
    When(_present("material_id", is_fk=True), then=Value("material")),
    When(_present("fdb_gcn_seq_nbr") & _present("plant_id", is_fk=True), then=Value("gcn_plant")),
    When(_present("fdb_gcn_seq_nbr"), then=Value("gcn")),
    When(_present("ndc"), then=Value("ndc")),
    When(_present("fei_number"), then=Value("fei")),
    When(_present("hicl"), then=Value("hicl")),
    default=Value("unknown"),
    output_field=CharField(),
)


def granularity_type_for_issue(issue):
    if issue.material_id:
        return "material_plant" if issue.plant_id else "material"
    if issue.fdb_gcn_seq_nbr:
        return "gcn_plant" if issue.plant_id else "gcn"
    if issue.ndc:
        return "ndc"
    if issue.fei_number:
        return "fei"
    if issue.hicl:
        return "hicl"
    return "unknown"


def resolve_materials(*, material_id=None, fdb_gcn_seq_nbr=None, ndc=None, hicl=None):
    """Resolve the ``Material`` queryset for a grain, honoring precedence.

    Returns an empty queryset for grains with no material mapping (fei) or that
    resolve to nothing.
    """
    from api.material.models import Material

    if material_id:
        return Material.objects.filter(mat_nbr=material_id)
    if fdb_gcn_seq_nbr:
        return Material.objects.filter(fdb_gcn_seq_nbr=fdb_gcn_seq_nbr)
    if ndc:
        return Material.objects.filter(ndc=ndc)
    if hicl:
        return Material.objects.filter(hicl=hicl)
    return Material.objects.none()


def materials_for_issue(issue):
    return resolve_materials(
        material_id=issue.material_id,
        fdb_gcn_seq_nbr=issue.fdb_gcn_seq_nbr,
        ndc=issue.ndc,
        hicl=issue.hicl,
    )


def materials_for_event(event):
    return resolve_materials(
        material_id=event.mat_nbr_id,
        fdb_gcn_seq_nbr=event.fdb_gcn_seq_nbr,
        ndc=event.ndc,
        hicl=event.hicl,
    )


def with_unfilled_qty(material_qs):
    """Annotate a ``Material`` queryset with ``unfilled_qty``.

    Unfilled quantity is the trailing-90-day total ordered minus total shipped,
    summed across corporate chains for each material; it is ``0`` for materials
    with no order history in the window.
    """
    from api.order_transaction.materialized_view_models import (
        OrderTransactionMaterial90dMV,
    )

    unfilled_sq = (
        OrderTransactionMaterial90dMV.objects
        .filter(material_id=OuterRef("mat_nbr"))
        .values("material_id")
        .annotate(unfilled=Sum("total_order_qty") - Sum("total_shipped_qty"))
        .values("unfilled")
    )
    return material_qs.annotate(
        unfilled_qty=Coalesce(
            Subquery(unfilled_sq, output_field=BigIntegerField()),
            Value(0),
            output_field=BigIntegerField(),
        )
    )


def annotate_issue_granularity(queryset):
    """Annotate an Issue queryset with ``granularity_type`` and the effective
    (grain-aware) ``risk_rating`` / ``dollars_at_risk`` / ``risk_adjusted_value``,
    ``impacted_material_count`` and ``hicl_description``.

    ``granularity_type`` is derived from the issue's own grain columns; the
    effective metrics are read from ``issue_effective_metrics_mv`` (the
    ``effective_metrics`` relation), which precomputes AVG risk_rating, SUM
    dollars_at_risk, their product, the impacted material count and the hicl
    description across the grain's materials.
    """
    return queryset.annotate(
        granularity_type=GRANULARITY_TYPE_EXPR,
        effective_risk_rating=F("effective_metrics__effective_risk_rating"),
        effective_dollars_at_risk=F("effective_metrics__effective_dollars_at_risk"),
        effective_risk_adjusted_value=F("effective_metrics__effective_risk_adjusted_value"),
        impacted_material_count=F("effective_metrics__impacted_material_count"),
        hicl_description=F("effective_metrics__hicl_description"),
    )
