from django.urls import path

from .views import (
    WeeklyOpenIssuesView, CountryIssuesView, TopRiskiestMaterialsView,
    TopRiskiestVendorsView, IssueDetailWithMaterialAndActionsView,
    IssuesWithMaterialAndActionsView, TwoWeekIssuesSummaryView, TodayIssuesSnapshotView,
    ValueAtRiskTrendView, AllIssuesView, IssueImpactedMaterialsView,
)

app_name = 'issue'

urlpatterns = [
    path('',
         IssuesWithMaterialAndActionsView.as_view(), name='issues-with-material-and-actions'),
    path('all/', AllIssuesView.as_view(), name='all-issues'),
    path('weekly-open-count/', WeeklyOpenIssuesView.as_view(), name='weekly-open-count'),
    path('two-week-summary/', TwoWeekIssuesSummaryView.as_view(), name='two-week-summary'),
    path('today-snapshot/', TodayIssuesSnapshotView.as_view(), name='today-issues-snapshot'),
    path('value-at-risk-trend/', ValueAtRiskTrendView.as_view(), name='value-at-risk-trend'),
    path('country-issues/', CountryIssuesView.as_view(), name='country-issues'),  # TODO: Remove as not used
    path('top-riskiest-materials/', TopRiskiestMaterialsView.as_view(), name='top-riskiest-materials'),
    path('top-riskiest-vendors/',
         TopRiskiestVendorsView.as_view(), name='top-riskiest-vendors'),
    path(
        '<int:id>/',
        IssueDetailWithMaterialAndActionsView.as_view(),
        name='issue-detail-with-material-and-actions'
    ),
    path(
        '<int:id>/materials/',
        IssueImpactedMaterialsView.as_view(),
        name='issue-impacted-materials'
    ),
]
