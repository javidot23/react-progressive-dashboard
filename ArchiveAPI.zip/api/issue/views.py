from datetime import datetime

from django.conf import settings
from django.db.models import OuterRef, Exists, Case, When, F, FloatField
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page, never_cache
from django_filters.rest_framework import FilterSet, filters, DjangoFilterBackend
from rest_framework import generics
from rest_framework import status
from rest_framework.exceptions import NotFound
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.global_filters import GlobalFilterForRelatedMaterialMixin, get_filtered_material_subquery
from api.kpi_trends import build_kpi_trend_response
from api.material.models import Material
from .granularity import materials_for_issue, with_unfilled_qty
from .models import Issue
from .serializers import (
    WeeklyIssueCountSerializer, CountryIssueSerializer, RiskiestMaterialsSerializer,
    RiskiestVendorsSerializer, IssueWithMaterialAndActionsSerializer, TwoWeekIssuesSummarySerializer,
    TodayIssuesSnapshotSerializer, WeeklyValueAtRiskSerializer,
    IssueAtGranularitySerializer, IssueAtGranularityListSerializer,
    IssueImpactedMaterialSerializer,
)
from .services import IssueService
from ..potential_action.models import PotentialAction


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyOpenIssuesView(APIView):
    """Returns the count of open issues for current week and previous week."""

    @extend_schema(responses=WeeklyIssueCountSerializer)
    def get(self, request):
        data = IssueService.get_weekly_open_issues()
        serializer = WeeklyIssueCountSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class TwoWeekIssuesSummaryView(APIView):
    """
    Returns a summary of issues for the current and previous two weeks.
    Supports global filters.
    """

    @extend_schema(responses=TwoWeekIssuesSummarySerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = IssueService.get_two_week_issues_summary(direct_mat_nbr, mat_nbr_subquery)
        serializer = TwoWeekIssuesSummarySerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class TodayIssuesSnapshotView(APIView):
    """
    Returns today's snapshot of Open Issues vs. Total Issues for issues that started today.
    Includes trend data for the last 90 days.
    Supports global filters.
    """

    @extend_schema(responses=TodayIssuesSnapshotSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = IssueService.get_today_issues_snapshot(direct_mat_nbr, mat_nbr_subquery)

        rows = IssueService.get_opened_issues_trend(
            direct_mat_nbr=direct_mat_nbr,
            mat_nbr_subquery=mat_nbr_subquery,
        )

        bucket_to_payload = {}
        for row in rows:
            bucket = row["bucket"]
            if isinstance(bucket, datetime):
                bucket = bucket.date()
            bucket_to_payload[bucket] = {
                "value": row["open_issues"],
                "open_issues": row["open_issues"],
                "total_issues": row["total_issues"],
            }

        data["trend"] = build_kpi_trend_response(
            kpi="opened_issues",
            unit="count",
            bucket_to_payload=bucket_to_payload,
            default_value=0.0,
        )

        serializer = TodayIssuesSnapshotSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class ValueAtRiskTrendView(APIView):
    """
    Returns Value at Risk trend data for the last 90 days (weekly buckets).
    Production MaterialValueAtRiskHistory is weekly; supports global filters.
    """

    @extend_schema(responses=WeeklyValueAtRiskSerializer(many=True))
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = IssueService.get_value_at_risk_trend(direct_mat_nbr, mat_nbr_subquery)
        serializer = WeeklyValueAtRiskSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class CountryIssuesView(APIView):
    """Returns countries with open issues, issue count per country, and vendors."""

    @extend_schema(responses=CountryIssueSerializer(many=True))
    def get(self, request):
        data = IssueService.get_country_issues()
        serializer = CountryIssueSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class TopRiskiestMaterialsView(APIView):
    """Returns the top riskiest materials that have open issues. Supports global filters."""

    @extend_schema(responses=RiskiestMaterialsSerializer)
    def get(self, request):
        limit = int(request.query_params.get('limit', 3))
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = IssueService.get_top_riskiest_materials(limit, direct_mat_nbr, mat_nbr_subquery)
        serializer = RiskiestMaterialsSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class TopRiskiestVendorsView(APIView):
    """Returns the top riskiest vendors that have open issues."""

    @extend_schema(responses=RiskiestVendorsSerializer)
    def get(self, request):
        limit = int(request.query_params.get('limit', 3))
        data = IssueService.get_top_riskiest_vendors(limit)
        serializer = RiskiestVendorsSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


class IssueFilter(GlobalFilterForRelatedMaterialMixin, FilterSet):
    """
    Filter set for issues with global filters support.
    Includes global filters: supplier, product_family, therapeutic_class, buyer,
    category_manager, material, gcn, and formulary.
    """
    status = filters.CharFilter(field_name='status', lookup_expr='exact')
    group = filters.CharFilter(field_name='group', lookup_expr='exact')
    persona = filters.CharFilter(field_name='persona', lookup_expr='exact')
    # Note: 'material' filter is provided by GlobalFilterForRelatedMaterialMixin (filters by mat_nbr)
    # Explicitly override it here to ensure mat_nbr filtering
    material = filters.CharFilter(field_name='material__mat_nbr', lookup_expr='exact')

    name = filters.CharFilter(lookup_expr='icontains', field_name='material__name')
    mat_nbr_filter = filters.CharFilter(lookup_expr='icontains', field_name='material__mat_nbr')

    risk_rating = filters.NumberFilter(field_name='material__risk_rating')
    risk_rating_min = filters.NumberFilter(field_name='material__risk_rating', lookup_expr='gte')
    risk_rating_max = filters.NumberFilter(field_name='material__risk_rating', lookup_expr='lte')

    dollars_at_risk = filters.NumberFilter()
    dollars_at_risk_min = filters.NumberFilter(field_name='material__dollars_at_risk', lookup_expr='gte')
    dollars_at_risk_max = filters.NumberFilter(field_name='material__dollars_at_risk', lookup_expr='lte')

    risk_adjusted_value_min = filters.NumberFilter(field_name='risk_adjusted_value', lookup_expr='gte')
    risk_adjusted_value_max = filters.NumberFilter(field_name='risk_adjusted_value', lookup_expr='lte')

    driving_risk = filters.CharFilter(lookup_expr='icontains', field_name='material__driving_risk')
    ndc = filters.CharFilter(lookup_expr='icontains', field_name='material__ean_n4_nbr_11')

    # Vendor filtering (also covered by GlobalFilterForRelatedMaterialMixin but kept for backward compatibility)
    vendor_name = filters.CharFilter(lookup_expr='icontains', field_name='material__vendor__name')

    has_no_actions = filters.BooleanFilter(method='filter_no_actions')

    has_potential_actions = filters.BooleanFilter(method='filter_has_potential_actions')

    module = filters.CharFilter(method='filter_by_module')

    def filter_by_module(self, queryset, name, value):
        potential_actions = PotentialAction.objects.filter(
            module=value,
            issue_nbr=OuterRef('issue_nbr'),
        )

        return queryset.filter(
            Exists(potential_actions)
        ).distinct()

    def filter_no_actions(self, queryset, name, value):
        if value is None:
            # Filter not provided, return all issues
            return queryset
        elif value:
            # Filter issues that have no actions
            return queryset.filter(
                status='OPEN'
            ).exclude(
                actions__isnull=False
            ).distinct()
        else:
            # Filter issues that have actions
            return queryset.filter(
                status='OPEN',
                actions__isnull=False
            ).distinct()

    def filter_has_potential_actions(self, queryset, name, value):
        if value:
            potential_actions = PotentialAction.objects.filter(
                issue_nbr=OuterRef('issue_nbr'),
            )

            return queryset.filter(
                Exists(potential_actions)
            ).distinct()
        return queryset


class AllIssueFilter(IssueFilter):
    """Filters for the all-issues list: granularity_type, the issue's own grain
    identifier columns, and range filters over the effective_* metrics."""
    granularity_type = filters.CharFilter(field_name='granularity_type', lookup_expr='exact')

    gcn = filters.CharFilter(field_name='fdb_gcn_seq_nbr', lookup_expr='exact')
    fdb_gcn_seq_nbr = filters.CharFilter(field_name='fdb_gcn_seq_nbr', lookup_expr='exact')
    ndc = filters.CharFilter(field_name='ndc', lookup_expr='exact')
    fei_number = filters.CharFilter(field_name='fei_number', lookup_expr='exact')
    hicl = filters.CharFilter(field_name='hicl', lookup_expr='exact')
    plant = filters.CharFilter(field_name='plant__plant_nbr', lookup_expr='exact')

    effective_risk_rating_min = filters.NumberFilter(field_name='effective_risk_rating', lookup_expr='gte')
    effective_risk_rating_max = filters.NumberFilter(field_name='effective_risk_rating', lookup_expr='lte')
    effective_dollars_at_risk_min = filters.NumberFilter(field_name='effective_dollars_at_risk', lookup_expr='gte')
    effective_dollars_at_risk_max = filters.NumberFilter(field_name='effective_dollars_at_risk', lookup_expr='lte')
    effective_risk_adjusted_value_min = filters.NumberFilter(
        field_name='effective_risk_adjusted_value', lookup_expr='gte')
    effective_risk_adjusted_value_max = filters.NumberFilter(
        field_name='effective_risk_adjusted_value', lookup_expr='lte')

    impacted_material_count_min = filters.NumberFilter(
        field_name='impacted_material_count', lookup_expr='gte')
    impacted_material_count_max = filters.NumberFilter(
        field_name='impacted_material_count', lookup_expr='lte')

    distinct_by_material = filters.BooleanFilter(method='filter_distinct_by_material')

    def filter_distinct_by_material(self, queryset, name, value):
        if not value:
            return queryset
        return IssueService.distinct_issues_by_material(queryset)

    # The inherited risk_adjusted_value / dollars_at_risk filters reference
    # annotations that only exist on the legacy list; repoint them to this
    # endpoint's grain-aware annotations so they resolve here.
    dollars_at_risk = filters.NumberFilter(field_name='effective_dollars_at_risk')
    risk_adjusted_value_min = filters.NumberFilter(
        field_name='effective_risk_adjusted_value', lookup_expr='gte')
    risk_adjusted_value_max = filters.NumberFilter(
        field_name='effective_risk_adjusted_value', lookup_expr='lte')


class AllIssuesOrderingFilter(OrderingFilter):
    """Ordering filter for AllIssuesView.

    Supports ``recent_open_date``: ongoing (OPEN) issues first, then by
    start_date. Use ``-recent_open_date`` for newest open date first.
    """

    def filter_queryset(self, request, queryset, view):
        ordering = self.get_ordering(request, queryset, view)
        if not ordering:
            return queryset

        expanded = []
        for field in ordering:
            bare = field.lstrip('-')
            if bare == 'recent_open_date':
                expanded.append('open_priority')
                expanded.append('-start_date' if field.startswith('-') else 'start_date')
            else:
                expanded.append(field)

        return queryset.order_by(*expanded)


@method_decorator(never_cache, name='dispatch')
class IssuesWithMaterialAndActionsView(generics.ListAPIView):
    """Returns open issues with their related material and actions."""
    serializer_class = IssueWithMaterialAndActionsSerializer
    filterset_class = IssueFilter
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    ordering_fields = [
        'material__name', 'material__mat_nbr', 'material__risk_rating',
        'material__dollars_at_risk', 'material__driving_risk',
        'material__ean_n4_nbr_11', 'status', 'group', 'persona', 'risk_adjusted_value'
    ]
    ordering = ['-material__dollars_at_risk']

    def get_queryset(self):
        return IssueService.get_issues_with_material_and_actions()

    def list(self, request, *args, **kwargs):
        # Get filtered queryset
        queryset = self.filter_queryset(self.get_queryset())

        # Paginate if needed
        page = self.paginate_queryset(queryset)
        if page is not None:
            IssueService.attach_potential_actions_to_issues(page)
            IssueService.attach_notes_to_issues(page)
            user_cache = IssueService.get_user_cache_for_issues(page)
            serializer = self.get_serializer(page, many=True, context={'user_cache': user_cache})
            return self.get_paginated_response(serializer.data)

        # No pagination
        issues = list(queryset)
        IssueService.attach_potential_actions_to_issues(issues)
        IssueService.attach_notes_to_issues(issues)
        user_cache = IssueService.get_user_cache_for_issues(issues)
        serializer = self.get_serializer(issues, many=True, context={'user_cache': user_cache})
        return Response(serializer.data)


@method_decorator(never_cache, name='dispatch')
class IssueDetailWithMaterialAndActionsView(generics.RetrieveAPIView):
    """Returns one issue at its original granularity with its material, actions,
    notes, potential actions, and the driving event."""
    serializer_class = IssueAtGranularitySerializer
    lookup_url_kwarg = 'id'

    def get_object(self):
        try:
            issue = IssueService.get_issue_at_granularity(
                self.kwargs[self.lookup_url_kwarg]
            )
        except Issue.DoesNotExist as exc:
            raise NotFound({'error': 'Issue not found'}) from exc

        IssueService.attach_potential_actions_to_issues([issue])
        IssueService.attach_notes_to_issues([issue])
        IssueService.attach_events_to_issues([issue])
        return issue

    def retrieve(self, request, *args, **kwargs):
        issue = self.get_object()
        user_cache = IssueService.get_user_cache_for_issues([issue])
        serializer = self.get_serializer(issue, context={'user_cache': user_cache})
        return Response(serializer.data)


@method_decorator(never_cache, name='dispatch')
class AllIssuesView(generics.ListAPIView):
    """Returns issues at their original granularity (material/gcn/ndc/fei/hicl),
    any status, with grain-aware aggregated metrics and the driving event."""
    serializer_class = IssueAtGranularityListSerializer
    filterset_class = AllIssueFilter
    filter_backends = [DjangoFilterBackend, AllIssuesOrderingFilter]
    ordering_fields = [
        'status', 'start_date', 'date_identified', 'granularity_type',
        'group', 'persona', 'open_priority', 'recent_open_date',
        'effective_risk_rating', 'effective_dollars_at_risk', 'effective_risk_adjusted_value',
        'impacted_material_count', 'material__name', 'material__mat_nbr',
    ]
    ordering = ['-effective_dollars_at_risk']

    def get_queryset(self):
        return IssueService.get_all_issues_list_queryset()

    def _enrich(self, issues):
        IssueService.attach_notes_to_issues(issues)
        IssueService.attach_events_to_issues(issues)
        return IssueService.get_user_cache_for_issues(issues)

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            user_cache = self._enrich(page)
            serializer = self.get_serializer(page, many=True, context={'user_cache': user_cache})
            return self.get_paginated_response(serializer.data)

        issues = list(queryset)
        user_cache = self._enrich(issues)
        serializer = self.get_serializer(issues, many=True, context={'user_cache': user_cache})
        return Response(serializer.data)


class IssueImpactedMaterialFilter(FilterSet):
    """Range filters for the impacted-materials list."""
    risk_adjusted_value_min = filters.NumberFilter(field_name='risk_adjusted_value', lookup_expr='gte')
    risk_adjusted_value_max = filters.NumberFilter(field_name='risk_adjusted_value', lookup_expr='lte')
    risk_rating_min = filters.NumberFilter(field_name='risk_rating', lookup_expr='gte')
    risk_rating_max = filters.NumberFilter(field_name='risk_rating', lookup_expr='lte')
    dollars_at_risk_min = filters.NumberFilter(field_name='dollars_at_risk', lookup_expr='gte')
    dollars_at_risk_max = filters.NumberFilter(field_name='dollars_at_risk', lookup_expr='lte')


@method_decorator(never_cache, name='dispatch')
class IssueImpactedMaterialsView(generics.ListAPIView):
    """Returns all materials impacted by an issue, resolved at the issue's grain.

    Empty for grains with no material mapping (fei) or that resolve to nothing.
    """
    serializer_class = IssueImpactedMaterialSerializer
    lookup_url_kwarg = 'id'
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = IssueImpactedMaterialFilter
    ordering_fields = ['risk_adjusted_value', 'risk_rating', 'dollars_at_risk', 'name', 'mat_nbr']
    ordering = ['-risk_adjusted_value']

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return Material.objects.none()
        try:
            issue = Issue.objects.only(
                'material_id', 'fdb_gcn_seq_nbr', 'ndc', 'fei_number', 'hicl', 'plant_id'
            ).get(pk=self.kwargs[self.lookup_url_kwarg])
        except Issue.DoesNotExist as exc:
            raise NotFound({'error': 'Issue not found'}) from exc

        return with_unfilled_qty(
            materials_for_issue(issue).select_related('vendor')
        ).annotate(
            risk_adjusted_value=Case(
                When(
                    risk_rating__isnull=False,
                    dollars_at_risk__isnull=False,
                    then=F('risk_rating') * F('dollars_at_risk'),
                ),
                default=0.0,
                output_field=FloatField(),
            )
        )
