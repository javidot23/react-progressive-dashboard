from django.db import models

from api.material.models import Material
from api.plant.models import Plant


class Issue(models.Model):
    class IssueStatus(models.TextChoices):
        OPEN = "OPEN", "Open"
        CLOSED = "CLOSED", "Closed"

    issue_nbr = models.CharField(max_length=255, unique=True)
    material = models.ForeignKey(
        Material,
        to_field="mat_nbr",
        db_column="mat_nbr",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text=(
            "Material the issue is at, when the issue grain includes a material "
            "(e.g. material or material+plant). Null for material-less grains "
            "such as gcn-only, ndc-only or fei-only."
        ),
    )
    event_id = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        help_text=(
            "Natural key into supply_chain_events (event_id is unique there)."
        ),
    )
    status = models.CharField(
        max_length=10,
        choices=IssueStatus.choices,
        default=IssueStatus.OPEN,
        blank=True,
        null=True,
    )
    date_identified = models.DateField(blank=True, null=True)
    status_date = models.DateField(blank=True, null=True)
    start_date = models.DateField(blank=True, null=True)
    group = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="Cencora org the issue is assigned to.",
    )
    persona = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="Cencora business role associated with the issue.",
    )
    fdb_gcn_seq_nbr = models.CharField(max_length=255, blank=True, null=True)
    ndc = models.CharField(max_length=255, blank=True, null=True)
    fei_number = models.CharField(max_length=255, blank=True, null=True)
    hicl = models.CharField(max_length=255, blank=True, null=True)
    plant = models.ForeignKey(
        Plant,
        to_field="plant_nbr",
        db_column="plant_nbr",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "issue"
        verbose_name = "Issue"
        verbose_name_plural = "Issues"
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["issue_nbr"]),
            models.Index(fields=["material"]),
            models.Index(fields=["status"]),
            models.Index(fields=["material", "status"]),
            models.Index(fields=["material", "start_date"]),
            models.Index(fields=["material", "status", "start_date"]),
            models.Index(fields=["event_id"]),
            models.Index(fields=["material", "event_id"]),
        ]


class IssueEffectiveMetricsMV(models.Model):
    """Grain-aware effective metrics per issue.

    Materialized view ``issue_effective_metrics_mv``, keyed by issue id. Each row
    carries the issue's grain-resolved risk_rating (AVG), dollars_at_risk (SUM),
    risk_adjusted_value, impacted material count, and hicl description.
    """
    issue = models.OneToOneField(
        Issue,
        db_column="issue_id",
        on_delete=models.DO_NOTHING,
        related_name="effective_metrics",
        primary_key=True,
    )
    effective_risk_rating = models.FloatField(null=True, blank=True)
    effective_dollars_at_risk = models.FloatField(null=True, blank=True)
    effective_risk_adjusted_value = models.FloatField(null=True, blank=True)
    impacted_material_count = models.IntegerField(null=True, blank=True)
    hicl_description = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        managed = False
        db_table = "issue_effective_metrics_mv"
        verbose_name = "Issue Effective Metrics (Materialized View)"
        verbose_name_plural = "Issue Effective Metrics (Materialized View)"
