from django.db import models

from api.customer_company.models import CustomerCompany


class CustomerBusinessUnit(models.Model):
    cust_bus_unit_nbr = models.CharField(max_length=255, unique=True)  # Customer Business Unit number from DBX
    name = models.CharField(max_length=255)
    cust_company_nbr = models.ForeignKey(
        CustomerCompany,
        to_field="cust_company_nbr",
        db_column="cust_company_nbr",
        on_delete=models.CASCADE,
        null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "customer_business_units"
        verbose_name = "Customer Business Unit"
        verbose_name_plural = "Customer Business Units"
        indexes = [
            models.Index(fields=["cust_bus_unit_nbr"]),
            models.Index(fields=["cust_company_nbr"])
        ]
