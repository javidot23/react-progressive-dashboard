from django.apps import AppConfig


class CustomerBusinessUnitConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.customer_business_unit'
