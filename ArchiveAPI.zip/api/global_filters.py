import logging
import uuid

from django_filters import BaseInFilter, filters

logger = logging.getLogger(__name__)


class NumberInFilter(BaseInFilter, filters.NumberFilter):
    """NumberFilter that accepts comma-separated values, e.g. ?supplier=1,2,3"""
    pass


class CharInFilter(BaseInFilter, filters.CharFilter):
    """CharFilter that accepts comma-separated values, e.g. ?xplant_mat_stat=A,B"""
    pass


def _split_param(params, key):
    """Split a comma-separated query param into a list. Returns None if not present or empty."""
    value = params.get(key)
    if not value:
        return None
    parts = [v.strip() for v in value.split(',') if v.strip()]
    return parts or None


def get_custom_list_entity_ids(list_id_str, user_id, max_items=10000):
    """
    Get entity IDs from a custom list with security and performance checks.

    Args:
        list_id_str: UUID string of the custom list
        user_id: Owner user ID for authorization check
        max_items: Maximum number of items to return (performance limit)

    Returns:
        list of entity_id strings, or None if list not found/invalid
    """
    if not list_id_str or not user_id:
        return None

    try:
        # Validate UUID format
        list_id = uuid.UUID(list_id_str)
    except (ValueError, TypeError, AttributeError):
        logger.warning("Invalid UUID format for custom_list filter: %s", list_id_str)
        return None

    try:
        from api.custom_lists.models import CustomList, CustomListItem

        # Only allow owner to use their lists
        custom_list = CustomList.objects.filter(
            id=list_id,
            owner_user_id=user_id,
            is_archived=False,
        ).first()

        if not custom_list:
            return None

        # Get entity IDs with limit for performance
        entity_ids = list(
            CustomListItem.objects.filter(custom_list=custom_list)
            .values_list('entity_id', flat=True)[:max_items]
        )

        if len(entity_ids) >= max_items:
            logger.warning(
                "Custom list %s has %d+ items, limiting to %d for performance",
                list_id, len(entity_ids), max_items
            )

        return entity_ids if entity_ids else None

    except Exception as e:
        logger.error("Error retrieving custom list entity IDs: %s", str(e), exc_info=True)
        return None


def get_corp_chain_material_ids(corp_chain_nbr, max_items=10000):
    """
    Get material mat_nbr values ordered by a corp chain (last 90 days).
    Uses the corp_chain_materials_90d_mv materialized view.

    Args:
        corp_chain_nbr: The corporate chain number to look up
        max_items: Maximum number of items to return (performance limit)

    Returns:
        list of mat_nbr strings, or None if corp chain not found/has no orders
    """
    if not corp_chain_nbr:
        return None

    try:
        from config.tenant_db import get_tenant_connection

        with get_tenant_connection().cursor() as cursor:
            cursor.execute(
                "SELECT mat_nbrs FROM corp_chain_materials_90d_mv WHERE cust_corp_chain_nbr = %s",
                [corp_chain_nbr]
            )
            row = cursor.fetchone()

            if not row or not row[0]:
                return None

            mat_nbrs = row[0]

            if len(mat_nbrs) > max_items:
                logger.warning(
                    "Corp chain %s has %d materials, limiting to %d for performance",
                    corp_chain_nbr, len(mat_nbrs), max_items
                )
                return mat_nbrs[:max_items]
            return mat_nbrs if mat_nbrs else None

    except Exception as e:
        logger.error("Error retrieving corp chain materials: %s", str(e), exc_info=True)
        return None


class CustomListFilter(filters.CharFilter):
    """Filter by all materials in a custom list (owner only)."""

    def filter(self, qs, value):
        if not value:
            return qs

        # Get user from request
        user = None
        if hasattr(self, 'parent') and self.parent:
            request = getattr(self.parent, 'request', None)
            user = getattr(request, 'user', None) if request else None
        user_id = getattr(user, 'entra_id', None) if user else None

        # Explicit check for unauthenticated users
        if not user_id:
            return qs.none()

        entity_ids = get_custom_list_entity_ids(value, user_id)
        if not entity_ids:
            return qs.none()

        return qs.filter(**{f'{self.field_name}__in': entity_ids})


class CorpChainFilter(filters.CharFilter):
    """Filter by all materials ordered by a corporate chain (last 90 days)."""

    def filter(self, qs, value):
        if not value:
            return qs

        mat_nbrs = get_corp_chain_material_ids(value)
        if not mat_nbrs:
            return qs.none()

        return qs.filter(**{f'{self.field_name}__in': mat_nbrs})


class DirectCorpChainFilter(filters.CharFilter):
    """
    Filter by direct FK to corporate chain.
    """

    def filter(self, qs, value):
        if not value:
            return qs

        return qs.filter(**{self.field_name: value})


GLOBAL_MATERIAL_FILTERS = {
    # Custom List filter
    'custom_list': CustomListFilter(field_name='mat_nbr'),

    # Corp Chain filter (materials ordered by customer)
    'cust_corp_chain': CorpChainFilter(field_name='mat_nbr'),

    # Supplier filters (technical + aliases)
    'supplier': NumberInFilter(lookup_expr='in', field_name='vendor__id'),
    'supplier_nbr': CharInFilter(lookup_expr='in', field_name='vendor__vendor_nbr'),
    'supplier_name': filters.CharFilter(lookup_expr='icontains', field_name='vendor__name'),

    # Supplier Parent filter
    'supplier_parent': CharInFilter(lookup_expr='in', field_name='vendor__vendor_parent_id'),

    # Product Category filters
    'product_family': filters.CharFilter(lookup_expr='icontains', field_name='product_family'),
    'product_category': filters.CharFilter(lookup_expr='icontains', field_name='material_group'),

    # Therapeutic Class filters
    'hic3_therapy_class': filters.CharFilter(lookup_expr='icontains', field_name='hic3_therapy_class'),
    'therapeutic_class': filters.CharFilter(lookup_expr='icontains', field_name='hic3_therapy_class'),

    # Buyer filters
    'buyer_name': filters.CharFilter(lookup_expr='icontains', field_name='buyer_name'),
    'buyer_cd': CharInFilter(lookup_expr='in', field_name='buyer_cd'),
    'buyer': filters.CharFilter(lookup_expr='icontains', field_name='buyer_name'),

    # Category Manager filters
    'cat_mgr_name': filters.CharFilter(lookup_expr='icontains', field_name='cat_mgr_name'),
    'cat_mgr_nbr': CharInFilter(lookup_expr='in', field_name='cat_mgr_nbr'),
    'category_manager': filters.CharFilter(lookup_expr='icontains', field_name='cat_mgr_name'),

    # Material filters
    'material': CharInFilter(lookup_expr='in', field_name='mat_nbr'),
    'material_id': NumberInFilter(lookup_expr='in', field_name='id'),
    'material_name': filters.CharFilter(lookup_expr='icontains', field_name='name'),

    # GCN filters
    'fdb_gcn_seq_nbr': filters.CharFilter(lookup_expr='icontains', field_name='fdb_gcn_seq_nbr'),
    'gcn': filters.CharFilter(lookup_expr='icontains', field_name='fdb_gcn_seq_nbr'),

    # XPlant Material Status filters
    'xplant_mat_stat': CharInFilter(lookup_expr='in', field_name='xplant_mat_stat'),

    # Formulary / Parent Program filters
    'materialformulary__parent_program': filters.CharFilter(lookup_expr='icontains',
                                                            field_name='materialformulary__parent_program'),
    'formulary': filters.CharFilter(lookup_expr='icontains', field_name='materialformulary__parent_program'),
    'parent_program': filters.CharFilter(lookup_expr='icontains', field_name='materialformulary__parent_program'),

    # Formulary Program (program_description) filters
    'materialformulary__program_description': filters.CharFilter(
        lookup_expr='icontains', field_name='materialformulary__program_description'),
    'formulary_program': filters.CharFilter(lookup_expr='icontains',
                                            field_name='materialformulary__program_description'),
    'program_description': filters.CharFilter(lookup_expr='icontains',
                                              field_name='materialformulary__program_description'),

    # Injectable filter
    'injectable': NumberInFilter(lookup_expr='in', field_name='inj_flg'),

    # WHO Essential filter
    'who_essential': NumberInFilter(lookup_expr='in', field_name='who_essential_flg'),

    # Fee for Service filter
    'fee_for_service': NumberInFilter(lookup_expr='in', field_name='fee_for_service_flg'),
}


class GlobalFilterMixin:
    """
    Dynamically injects reusable global filters for the Material model.
    Use this in your FilterSet classes like:
        class MyMaterialFilterSet(GlobalFilterMixin, filters.FilterSet):
            ...
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        import copy
        for name, filter_obj in GLOBAL_MATERIAL_FILTERS.items():
            if name not in self.filters:
                filter_copy = copy.deepcopy(filter_obj)
                filter_copy.parent = self
                self.filters[name] = filter_copy


GLOBAL_RELATED_MATERIAL_FILTERS = {
    # Custom List filter
    'custom_list': CustomListFilter(field_name='material'),

    # Corp Chain filter (materials ordered by customer)
    'cust_corp_chain': CorpChainFilter(field_name='material'),

    # Supplier filters
    'supplier': NumberInFilter(lookup_expr='in', field_name='material__vendor__id'),
    'supplier_nbr': CharInFilter(lookup_expr='in', field_name='material__vendor__vendor_nbr'),
    'supplier_name': filters.CharFilter(lookup_expr='icontains', field_name='material__vendor__name'),

    # Supplier Parent filter
    'supplier_parent': CharInFilter(lookup_expr='in', field_name='material__vendor__vendor_parent_id'),

    # Product Category filters
    'material__product_family': filters.CharFilter(lookup_expr='icontains', field_name='material__product_family'),
    'product_family': filters.CharFilter(lookup_expr='icontains', field_name='material__product_family'),
    'product_category': filters.CharFilter(lookup_expr='icontains', field_name='material__material_group'),

    # Therapeutic Class filters
    'material__hic3_therapy_class': filters.CharFilter(lookup_expr='icontains',
                                                       field_name='material__hic3_therapy_class'),
    'therapeutic_class': filters.CharFilter(lookup_expr='icontains', field_name='material__hic3_therapy_class'),

    # Buyer filters
    'material__buyer_name': filters.CharFilter(lookup_expr='icontains', field_name='material__buyer_name'),
    'material__buyer_cd': CharInFilter(lookup_expr='in', field_name='material__buyer_cd'),
    'buyer': filters.CharFilter(lookup_expr='icontains', field_name='material__buyer_name'),

    # Category Manager filters
    'material__cat_mgr_name': filters.CharFilter(lookup_expr='icontains', field_name='material__cat_mgr_name'),
    'material__cat_mgr_nbr': CharInFilter(lookup_expr='in', field_name='material__cat_mgr_nbr'),
    'category_manager': filters.CharFilter(lookup_expr='icontains', field_name='material__cat_mgr_name'),

    # Material filters
    'material': CharInFilter(lookup_expr='in', field_name='material'),
    'material_id': NumberInFilter(lookup_expr='in', field_name='material__id'),
    'material_name': filters.CharFilter(lookup_expr='icontains', field_name='material__name'),

    # GCN filters
    'material__fdb_gcn_seq_nbr': filters.CharFilter(lookup_expr='icontains', field_name='material__fdb_gcn_seq_nbr'),
    'gcn': filters.CharFilter(lookup_expr='icontains', field_name='material__fdb_gcn_seq_nbr'),

    # XPlant Material Status filters
    'material__xplant_mat_stat': CharInFilter(lookup_expr='in', field_name='material__xplant_mat_stat'),
    'xplant_mat_stat': CharInFilter(lookup_expr='in', field_name='material__xplant_mat_stat'),

    # Formulary / Parent Program filters
    'material__materialformulary__parent_program': filters.CharFilter(
        lookup_expr='icontains',
        field_name='material__materialformulary__parent_program'
    ),
    'formulary': filters.CharFilter(lookup_expr='icontains', field_name='material__materialformulary__parent_program'),
    'parent_program': filters.CharFilter(lookup_expr='icontains',
                                         field_name='material__materialformulary__parent_program'),

    # Formulary Program (program_description) filters
    'material__materialformulary__program_description': filters.CharFilter(
        lookup_expr='icontains',
        field_name='material__materialformulary__program_description'
    ),
    'formulary_program': filters.CharFilter(
        lookup_expr='icontains', field_name='material__materialformulary__program_description'),
    'program_description': filters.CharFilter(
        lookup_expr='icontains', field_name='material__materialformulary__program_description'),

    # Injectable filter
    'injectable': NumberInFilter(lookup_expr='in', field_name='material__inj_flg'),

    # WHO Essential filter
    'who_essential': NumberInFilter(lookup_expr='in', field_name='material__who_essential_flg'),

    # Fee for Service filter
    'fee_for_service': NumberInFilter(lookup_expr='in', field_name='material__fee_for_service_flg'),
}


class GlobalFilterForRelatedMaterialMixin:
    """
    Dynamically injects reusable filters for models with a ForeignKey to Material.
    Use this in your FilterSet classes like:
        class MyRelatedFilterSet(GlobalFilterForRelatedMaterialMixin, filters.FilterSet):
            ...
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        import copy
        for name, filter_obj in GLOBAL_RELATED_MATERIAL_FILTERS.items():
            if name not in self.filters:
                filter_copy = copy.deepcopy(filter_obj)
                filter_copy.parent = self
                self.filters[name] = filter_copy


def get_global_filters_with_direct_corp_chain(corp_chain_field_name):
    """
    Filter dict with DirectCorpChainFilter instead of CorpChainFilter.

    Args:
        corp_chain_field_name: The field name for direct FK to CustomerCorpChain
                               (e.g., 'cust_corp_chain_nbr' or 'customer_corp_chain')

    Returns:
        dict of filters with direct corp chain filter
    """
    filters_dict = dict(GLOBAL_RELATED_MATERIAL_FILTERS)
    filters_dict['cust_corp_chain'] = DirectCorpChainFilter(field_name=corp_chain_field_name)
    return filters_dict


class GlobalFilterWithDirectCorpChainMixin:
    """
    Mixin for models with both a ForeignKey to Material AND a direct FK to CustomerCorpChain.

    For the cust_corp_chain filter, this mixin uses DirectCorpChainFilter to filter
    by the direct FK relationship instead of filtering through materials.

    Configure the corp chain field name by setting corp_chain_field_name class attribute:
        class MyFilterSet(GlobalFilterWithDirectCorpChainMixin, FilterSet):
            corp_chain_field_name = 'cust_corp_chain_nbr'  # or 'customer_corp_chain'
            ...
    """
    corp_chain_field_name = 'cust_corp_chain_nbr'  # Default field name

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        import copy
        filters_dict = get_global_filters_with_direct_corp_chain(self.corp_chain_field_name)
        for name, filter_obj in filters_dict.items():
            if name not in self.filters:
                filter_copy = copy.deepcopy(filter_obj)
                filter_copy.parent = self
                self.filters[name] = filter_copy


def apply_global_filters(queryset, request):
    """
    Utility function to manually apply global filters to a queryset.

    Use this for APIView or custom views that don't use FilterSet.

    Args:
        queryset: Django QuerySet to filter
        request: Django request object containing query parameters

    Returns:
        Filtered QuerySet
    """
    params = request.query_params

    # Custom List filter
    custom_list_id = params.get('custom_list')
    if custom_list_id:
        user_id = getattr(request.user, 'entra_id', None) if hasattr(request, 'user') and request.user else None
        if user_id:
            entity_ids = get_custom_list_entity_ids(custom_list_id, user_id)
            if entity_ids:
                queryset = queryset.filter(mat_nbr__in=entity_ids)
            else:
                queryset = queryset.none()
        else:
            queryset = queryset.none()

    # Corp Chain filter
    cust_corp_chain = params.get('cust_corp_chain')
    if cust_corp_chain:
        mat_nbrs = get_corp_chain_material_ids(cust_corp_chain)
        if mat_nbrs:
            queryset = queryset.filter(mat_nbr__in=mat_nbrs)
        else:
            queryset = queryset.none()

    # Supplier filters
    if vals := _split_param(params, 'supplier'):
        queryset = queryset.filter(vendor__id__in=vals)
    if vals := _split_param(params, 'supplier_nbr'):
        queryset = queryset.filter(vendor__vendor_nbr__in=vals)
    if params.get('supplier_name'):
        queryset = queryset.filter(vendor__name__icontains=params.get('supplier_name'))

    # Supplier Parent filter
    if vals := _split_param(params, 'supplier_parent'):
        queryset = queryset.filter(vendor__vendor_parent_id__in=vals)

    # Product Category filters
    if params.get('product_family'):
        queryset = queryset.filter(product_family__icontains=params.get('product_family'))
    if params.get('product_category'):
        queryset = queryset.filter(material_group__icontains=params.get('product_category'))

    # Therapeutic Class filter
    if params.get('hic3_therapy_class'):
        queryset = queryset.filter(hic3_therapy_class__icontains=params.get('hic3_therapy_class'))

    # XPlant Material Status filter
    if vals := _split_param(params, 'xplant_mat_stat'):
        queryset = queryset.filter(xplant_mat_stat__in=vals)

    # Buyer filters
    if params.get('buyer_name'):
        queryset = queryset.filter(buyer_name__icontains=params.get('buyer_name'))
    if vals := _split_param(params, 'buyer_cd'):
        queryset = queryset.filter(buyer_cd__in=vals)

    # Category Manager filters
    if params.get('cat_mgr_name'):
        queryset = queryset.filter(cat_mgr_name__icontains=params.get('cat_mgr_name'))
    if vals := _split_param(params, 'cat_mgr_nbr'):
        queryset = queryset.filter(cat_mgr_nbr__in=vals)

    # Material filters
    if vals := _split_param(params, 'material'):
        queryset = queryset.filter(mat_nbr__in=vals)
    if vals := _split_param(params, 'material_id'):
        queryset = queryset.filter(id__in=vals)
    if params.get('material_name'):
        queryset = queryset.filter(name__icontains=params.get('material_name'))

    # GCN filter
    if params.get('fdb_gcn_seq_nbr'):
        queryset = queryset.filter(fdb_gcn_seq_nbr__icontains=params.get('fdb_gcn_seq_nbr'))

    # Formulary (Parent Program) filter
    if params.get('materialformulary__parent_program'):
        queryset = queryset.filter(
            materialformulary__parent_program__icontains=params.get('materialformulary__parent_program'))

    # Formulary Program (program_description) filter
    if params.get('materialformulary__program_description') or params.get('formulary_program') or params.get(
            'program_description'):
        value = params.get('formulary_program') or params.get('program_description') or params.get(
            'materialformulary__program_description')
        queryset = queryset.filter(materialformulary__program_description__icontains=value)

    # Injectable filter
    if vals := _split_param(params, 'injectable'):
        queryset = queryset.filter(inj_flg__in=vals)

    # WHO Essential filter
    if vals := _split_param(params, 'who_essential'):
        queryset = queryset.filter(who_essential_flg__in=vals)

    # Fee for Service filter
    if vals := _split_param(params, 'fee_for_service'):
        queryset = queryset.filter(fee_for_service_flg__in=vals)

    return queryset


def get_material_option_queryset(request, values_fields, filter_field=None):
    """
    Build a Material-derived option queryset (e.g. for dropdowns) with global filters applied.
    Use for contextual filter dropdowns: only options that exist for the current filter scope.

    Args:
        request: Django request (query_params used for global filters).
        values_fields: Sequence of field names for .values() (e.g. ["material_group"]).
        filter_field: Optional field name; if set, rows with null/empty that field are excluded.

    Returns:
        QuerySet of .values(*values_fields).distinct() from filtered Material.
    """
    from api.material.models import Material

    base = apply_global_filters(Material.objects.all(), request)
    if filter_field:
        base = base.filter(**{f"{filter_field}__isnull": False}).exclude(**{filter_field: ""})
    return base.values(*values_fields).distinct()


def apply_global_filters_for_aggregated_material(queryset, request):
    """
    Utility function to apply global filters to aggregated querysets grouped by material FK.

    Use this for aggregated querysets that use .values('material').annotate(...)
    where 'material' is a ForeignKey to the Material model.

    Args:
        queryset: Aggregated Django QuerySet grouped by material FK
        request: Django request object containing query parameters

    Returns:
        Filtered QuerySet
    """
    params = request.query_params

    # Custom List filter
    custom_list_id = params.get('custom_list')
    if custom_list_id:
        user_id = getattr(request.user, 'entra_id', None) if hasattr(request, 'user') and request.user else None
        if user_id:
            entity_ids = get_custom_list_entity_ids(custom_list_id, user_id)
            if entity_ids:
                queryset = queryset.filter(material__mat_nbr__in=entity_ids)
            else:
                queryset = queryset.none()
        else:
            queryset = queryset.none()

    # Corp Chain filter
    cust_corp_chain = params.get('cust_corp_chain')
    if cust_corp_chain:
        mat_nbrs = get_corp_chain_material_ids(cust_corp_chain)
        if mat_nbrs:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbrs)
        else:
            queryset = queryset.none()

    # Material filters
    if vals := _split_param(params, 'material'):
        queryset = queryset.filter(material__in=vals)
    if vals := _split_param(params, 'material_id'):
        queryset = queryset.filter(material__id__in=vals)
    if params.get('material_name'):
        queryset = queryset.filter(material__name__icontains=params.get('material_name'))

    # Supplier filters
    if vals := _split_param(params, 'supplier'):
        queryset = queryset.filter(material__vendor__id__in=vals)
    if vals := _split_param(params, 'supplier_nbr'):
        queryset = queryset.filter(material__vendor__vendor_nbr__in=vals)
    if params.get('supplier_name'):
        queryset = queryset.filter(material__vendor__name__icontains=params.get('supplier_name'))

    # Supplier Parent filter
    if vals := _split_param(params, 'supplier_parent'):
        queryset = queryset.filter(material__vendor__vendor_parent_id__in=vals)

    # Product Category filters
    if params.get('product_family'):
        queryset = queryset.filter(material__product_family__icontains=params.get('product_family'))
    if params.get('product_category'):
        queryset = queryset.filter(material__material_group__icontains=params.get('product_category'))

    # Therapeutic Class filter
    if params.get('hic3_therapy_class') or params.get('therapeutic_class'):
        value = params.get('therapeutic_class') or params.get('hic3_therapy_class')
        queryset = queryset.filter(material__hic3_therapy_class__icontains=value)

    # XPlant Material Status filter
    if vals := _split_param(params, 'xplant_mat_stat'):
        queryset = queryset.filter(material__xplant_mat_stat__in=vals)

    # Buyer filters
    if params.get('buyer_name') or params.get('buyer'):
        value = params.get('buyer') or params.get('buyer_name')
        queryset = queryset.filter(material__buyer_name__icontains=value)
    if vals := _split_param(params, 'buyer_cd'):
        queryset = queryset.filter(material__buyer_cd__in=vals)

    # Category Manager filters
    if params.get('cat_mgr_name') or params.get('category_manager'):
        value = params.get('category_manager') or params.get('cat_mgr_name')
        queryset = queryset.filter(material__cat_mgr_name__icontains=value)
    if vals := _split_param(params, 'cat_mgr_nbr'):
        queryset = queryset.filter(material__cat_mgr_nbr__in=vals)

    # GCN filter
    if params.get('fdb_gcn_seq_nbr') or params.get('gcn'):
        value = params.get('gcn') or params.get('fdb_gcn_seq_nbr')
        queryset = queryset.filter(material__fdb_gcn_seq_nbr__icontains=value)

    # Formulary filter
    if params.get('materialformulary__parent_program') or params.get('formulary') or params.get('parent_program'):
        value = params.get('formulary') or params.get('parent_program') or params.get(
            'materialformulary__parent_program')
        queryset = queryset.filter(material__materialformulary__parent_program__icontains=value)

    # Formulary Program (program_description) filter
    if params.get('materialformulary__program_description') or params.get('formulary_program') or params.get(
            'program_description'):
        value = params.get('formulary_program') or params.get('program_description') or params.get(
            'materialformulary__program_description')
        queryset = queryset.filter(material__materialformulary__program_description__icontains=value)

    # Injectable filter
    if vals := _split_param(params, 'injectable'):
        queryset = queryset.filter(material__inj_flg__in=vals)

    # WHO Essential filter
    if vals := _split_param(params, 'who_essential'):
        queryset = queryset.filter(material__who_essential_flg__in=vals)

    # Fee for Service filter
    if vals := _split_param(params, 'fee_for_service'):
        queryset = queryset.filter(material__fee_for_service_flg__in=vals)

    return queryset


def apply_global_filters_for_related_material(queryset, request):
    """
    Utility function to manually apply global filters to a queryset with related Material model.

    Use this for APIView or custom views that don't use FilterSet and have material as ForeignKey.

    Args:
        queryset: Django QuerySet to filter
        request: Django request object containing query parameters

    Returns:
        Filtered QuerySet
    """
    params = request.query_params

    # Custom List filter
    custom_list_id = params.get('custom_list')
    if custom_list_id:
        user_id = getattr(request.user, 'entra_id', None) if hasattr(request, 'user') and request.user else None
        if user_id:
            entity_ids = get_custom_list_entity_ids(custom_list_id, user_id)
            if entity_ids:
                queryset = queryset.filter(material__mat_nbr__in=entity_ids)
            else:
                queryset = queryset.none()
        else:
            queryset = queryset.none()

    # Corp Chain filter
    cust_corp_chain = params.get('cust_corp_chain')
    if cust_corp_chain:
        mat_nbrs = get_corp_chain_material_ids(cust_corp_chain)
        if mat_nbrs:
            queryset = queryset.filter(material__mat_nbr__in=mat_nbrs)
        else:
            queryset = queryset.none()

    # Supplier filters
    if vals := _split_param(params, 'supplier'):
        queryset = queryset.filter(material__vendor__id__in=vals)
    if vals := _split_param(params, 'supplier_nbr'):
        queryset = queryset.filter(material__vendor__vendor_nbr__in=vals)
    if params.get('supplier_name'):
        queryset = queryset.filter(material__vendor__name__icontains=params.get('supplier_name'))

    # Supplier Parent filter
    if vals := _split_param(params, 'supplier_parent'):
        queryset = queryset.filter(material__vendor__vendor_parent_id__in=vals)

    # Product Category filters
    if params.get('material__product_family'):
        queryset = queryset.filter(material__product_family__icontains=params.get('material__product_family'))
    if params.get('product_family'):
        queryset = queryset.filter(material__product_family__icontains=params.get('product_family'))
    if params.get('product_category'):
        queryset = queryset.filter(material__material_group__icontains=params.get('product_category'))

    # Therapeutic Class filter
    if params.get('material__hic3_therapy_class'):
        queryset = queryset.filter(material__hic3_therapy_class__icontains=params.get('material__hic3_therapy_class'))

    # XPlant Material Status filter
    if params.get('material__xplant_mat_stat'):
        queryset = queryset.filter(material__xplant_mat_stat__iexact=params.get('material__xplant_mat_stat'))
    if vals := _split_param(params, 'xplant_mat_stat'):
        queryset = queryset.filter(material__xplant_mat_stat__in=vals)

    # Buyer filters
    if params.get('material__buyer_name'):
        queryset = queryset.filter(material__buyer_name__icontains=params.get('material__buyer_name'))
    if params.get('material__buyer_cd'):
        queryset = queryset.filter(material__buyer_cd__exact=params.get('material__buyer_cd'))

    # Category Manager filters
    if params.get('material__cat_mgr_name'):
        queryset = queryset.filter(material__cat_mgr_name__icontains=params.get('material__cat_mgr_name'))
    if params.get('material__cat_mgr_nbr'):
        queryset = queryset.filter(material__cat_mgr_nbr__exact=params.get('material__cat_mgr_nbr'))

    # Material filters
    if vals := _split_param(params, 'material'):
        queryset = queryset.filter(material__in=vals)
    if vals := _split_param(params, 'material_id'):
        queryset = queryset.filter(material__id__in=vals)
    if params.get('material_name'):
        queryset = queryset.filter(material__name__icontains=params.get('material_name'))

    # GCN filter
    if params.get('material__fdb_gcn_seq_nbr'):
        queryset = queryset.filter(material__fdb_gcn_seq_nbr__icontains=params.get('material__fdb_gcn_seq_nbr'))

    # Formulary (Parent Program) filter
    if params.get('material__materialformulary__parent_program'):
        queryset = queryset.filter(material__materialformulary__parent_program__icontains=params.get(
            'material__materialformulary__parent_program'))

    # Formulary Program (program_description) filter
    if params.get('material__materialformulary__program_description'):
        queryset = queryset.filter(material__materialformulary__program_description__icontains=params.get(
            'material__materialformulary__program_description'))

    # Injectable filter
    if vals := _split_param(params, 'injectable'):
        queryset = queryset.filter(material__inj_flg__in=vals)

    # WHO Essential filter
    if vals := _split_param(params, 'who_essential'):
        queryset = queryset.filter(material__who_essential_flg__in=vals)

    # Fee for Service filter
    if vals := _split_param(params, 'fee_for_service'):
        queryset = queryset.filter(material__fee_for_service_flg__in=vals)

    return queryset


def extract_global_filter_params(request):
    """
    Extract global filter parameters from request query params.
    Returns filters with 'material__' prefix for related model queries.

    For better performance on large datasets, use get_filtered_material_subquery() instead.
    """
    params = request.query_params
    result = {}

    # Multi-select params — values are lists, use __in lookups
    multi_select_mapping = {
        'supplier': 'material__vendor__id__in',
        'supplier_nbr': 'material__vendor__vendor_nbr__in',
        'supplier_parent': 'material__vendor__vendor_parent_id__in',
        'xplant_mat_stat': 'material__xplant_mat_stat__in',
        'material': 'material__mat_nbr__in',
        'material_id': 'material__id__in',
        'buyer_cd': 'material__buyer_cd__in',
        'cat_mgr_nbr': 'material__cat_mgr_nbr__in',
        'injectable': 'material__inj_flg__in',
        'who_essential': 'material__who_essential_flg__in',
        'fee_for_service': 'material__fee_for_service_flg__in',
    }

    for param, django_filter in multi_select_mapping.items():
        vals = _split_param(params, param)
        if vals:
            result[django_filter] = vals

    # Single-value params — icontains / exact text searches
    single_value_mapping = {
        'supplier_name': 'material__vendor__name__icontains',
        'product_family': 'material__product_family__icontains',
        'product_category': 'material__material_group__icontains',
        'therapeutic_class': 'material__hic3_therapy_class__icontains',
        'buyer': 'material__buyer_name__icontains',
        'category_manager': 'material__cat_mgr_name__icontains',
        'material_name': 'material__name__icontains',
        'gcn': 'material__fdb_gcn_seq_nbr__icontains',
        'formulary': 'material__materialformulary__parent_program__icontains',
        'parent_program': 'material__materialformulary__parent_program__icontains',
        'formulary_program': 'material__materialformulary__program_description__icontains',
        'program_description': 'material__materialformulary__program_description__icontains',
    }

    for param, django_filter in single_value_mapping.items():
        value = params.get(param)
        if value:
            result[django_filter] = value

    old_style_mapping = {
        'material__vendor__id': 'material__vendor__id',
        'material__vendor__name': 'material__vendor__name__icontains',
        'material__vendor_nbr': 'material__vendor__vendor_nbr__exact',
        'material__product_family': 'material__product_family__icontains',
        'material__material_group': 'material__material_group__icontains',
        'material__hic3_therapy_class': 'material__hic3_therapy_class__icontains',
        'hic3_therapy_class': 'hic3_therapy_class__icontains',
        'material__xplant_mat_stat': 'material__xplant_mat_stat__iexact',
        'xplant_mat_stat': 'xplant_mat_stat__iexact',
        'material__buyer_name': 'material__buyer_name__icontains',
        'buyer_name': 'buyer_name__icontains',
        'material__buyer_cd': 'material__buyer_cd__exact',
        'buyer_cd': 'buyer_cd__exact',
        'material__cat_mgr_name': 'material__cat_mgr_name__icontains',
        'cat_mgr_name': 'cat_mgr_name__icontains',
        'material__cat_mgr_nbr': 'material__cat_mgr_nbr__exact',
        'cat_mgr_nbr': 'cat_mgr_nbr__exact',
        'material__id': 'material__id',
        'material__name': 'material__name__icontains',
        'material__fdb_gcn_seq_nbr': 'material__fdb_gcn_seq_nbr__icontains',
        'fdb_gcn_seq_nbr': 'fdb_gcn_seq_nbr__icontains',
        'material__materialformulary__parent_program': 'material__materialformulary__parent_program__icontains',
        'materialformulary__parent_program': 'materialformulary__parent_program__icontains',
        'material__materialformulary__program_description': (
            'material__materialformulary__program_description__icontains'
        ),
        'materialformulary__program_description': 'materialformulary__program_description__icontains',
    }

    for old_param, django_filter in old_style_mapping.items():
        value = params.get(old_param)
        if value:
            result[django_filter] = value

    return result


def extract_corp_chain_param(request):
    """Return the raw cust_corp_chain query param value, or None if not present."""
    return request.query_params.get('cust_corp_chain') or None


def get_filtered_material_subquery(request, skip_corp_chain=False):
    """
    Get a subquery of mat_nbr values matching global filters.
    Uses the Material model directly to avoid expensive JOINs in aggregation queries.

    Args:
        request: Django request object
        skip_corp_chain: When True, the cust_corp_chain param is NOT resolved via the
            materialized view and is excluded from the returned subquery. Use this for
            views that query OrderTransaction directly and can apply the corp chain filter
            via a direct FK (cust_corp_chain_nbr). Call extract_corp_chain_param(request)
            separately to get the raw value and pass it to the service.

    Returns:
        tuple: (direct_mat_nbr, material_subquery)
            - direct_mat_nbr: str or None - if filtering by exact mat_nbr
            - material_subquery: QuerySet of mat_nbr values, or None if no filters
    """
    from api.material.models import Material

    params = request.query_params
    mat_vals = _split_param(params, 'material')
    direct_mat_nbr = mat_vals[0] if mat_vals and len(mat_vals) == 1 else None
    material_filters = {}

    federal_cs_exclude = _split_param(params, 'exclude_federal_cs_ind')

    def _material_qs():
        qs = Material.objects.filter(**material_filters)
        if federal_cs_exclude:
            qs = qs.exclude(federal_cs_ind__in=federal_cs_exclude)
        return qs

    # Multiple material values go into material_filters like any other multi-select param
    if mat_vals and len(mat_vals) > 1:
        material_filters['mat_nbr__in'] = mat_vals

    # Custom List filter - handle separately as it requires user authentication
    custom_list_id = params.get('custom_list')
    custom_list_mat_nbrs = None
    if custom_list_id:
        user_id = getattr(request.user, 'entra_id', None) if hasattr(request, 'user') and request.user else None
        if user_id:
            entity_ids = get_custom_list_entity_ids(custom_list_id, user_id)
            if entity_ids:
                # If we have a custom list filter, we need to intersect with other filters
                custom_list_mat_nbrs = set(entity_ids)
            # If entity_ids is None (invalid/not found), we'll return empty result later
        # If no user_id, we'll return empty result later

    # Corp Chain filter - handle separately as it uses materialized view.
    # Skipped when the caller handles it via a direct FK (skip_corp_chain=True).
    cust_corp_chain = None if skip_corp_chain else params.get('cust_corp_chain')
    corp_chain_mat_nbrs = None
    if cust_corp_chain:
        mat_nbrs = get_corp_chain_material_ids(cust_corp_chain)
        if mat_nbrs:
            corp_chain_mat_nbrs = set(mat_nbrs)
        # If mat_nbrs is None (not found), we'll return empty result later

    # Multi-select params — build __in filters with list values
    multi_select_param_to_field = {
        'supplier': 'vendor__id__in',
        'supplier_nbr': 'vendor__vendor_nbr__in',
        'supplier_parent': 'vendor__vendor_parent_id__in',
        'xplant_mat_stat': 'xplant_mat_stat__in',
        'material_id': 'id__in',
        'buyer_cd': 'buyer_cd__in',
        'cat_mgr_nbr': 'cat_mgr_nbr__in',
        'injectable': 'inj_flg__in',
        'who_essential': 'who_essential_flg__in',
        'fee_for_service': 'fee_for_service_flg__in',
        'federal_cs_ind': 'federal_cs_ind__in',
    }

    for param, field in multi_select_param_to_field.items():
        vals = _split_param(params, param)
        if vals:
            material_filters[field] = vals

    # Single-value params
    single_param_to_field = {
        'supplier_name': 'vendor__name__icontains',
        'product_family': 'product_family__icontains',
        'product_category': 'material_group__icontains',
        'therapeutic_class': 'hic3_therapy_class__icontains',
        'buyer': 'buyer_name__icontains',
        'category_manager': 'cat_mgr_name__icontains',
        'material_name': 'name__icontains',
        'gcn': 'fdb_gcn_seq_nbr__icontains',
        'formulary': 'materialformulary__parent_program__icontains',
        'parent_program': 'materialformulary__parent_program__icontains',
        'formulary_program': 'materialformulary__program_description__icontains',
        'program_description': 'materialformulary__program_description__icontains',
    }

    for param, field in single_param_to_field.items():
        value = params.get(param)
        if value:
            material_filters[field] = value

    old_style_to_material = {
        'material__vendor__id': 'vendor__id',
        'material__vendor__name': 'vendor__name__icontains',
        'material__product_family': 'product_family__icontains',
        'material__material_group': 'material_group__icontains',
        'material__hic3_therapy_class': 'hic3_therapy_class__icontains',
        'material__xplant_mat_stat': 'xplant_mat_stat__iexact',
        'material__buyer_name': 'buyer_name__icontains',
        'material__buyer_cd': 'buyer_cd__exact',
        'material__cat_mgr_name': 'cat_mgr_name__icontains',
        'material__cat_mgr_nbr': 'cat_mgr_nbr__exact',
        'material__id': 'id',
        'material__name': 'name__icontains',
        'material__fdb_gcn_seq_nbr': 'fdb_gcn_seq_nbr__icontains',
        'material__materialformulary__parent_program': 'materialformulary__parent_program__icontains',
        'material__materialformulary__program_description': 'materialformulary__program_description__icontains',
    }

    for old_param, field in old_style_to_material.items():
        value = params.get(old_param)
        if value:
            material_filters[field] = value

    # Handle special filters (custom_list, cust_corp_chain) that provide mat_nbr sets
    # These need to be intersected with each other and with material_filters

    # Check for invalid/empty special filters first
    if custom_list_id and custom_list_mat_nbrs is None:
        # Invalid list or unauthorized - return empty result
        return None, Material.objects.none().values_list('mat_nbr', flat=True)

    if cust_corp_chain and corp_chain_mat_nbrs is None:
        # Corp chain has no orders in last 90 days - return empty result
        return None, Material.objects.none().values_list('mat_nbr', flat=True)

    # Build the final mat_nbr set by intersecting all applicable filters
    has_special_filters = custom_list_mat_nbrs is not None or corp_chain_mat_nbrs is not None

    if has_special_filters:
        # Start with the first available special filter set
        if custom_list_mat_nbrs is not None and corp_chain_mat_nbrs is not None:
            # Intersect both special filters
            final_mat_nbrs = custom_list_mat_nbrs & corp_chain_mat_nbrs
        elif custom_list_mat_nbrs is not None:
            final_mat_nbrs = custom_list_mat_nbrs
        else:
            final_mat_nbrs = corp_chain_mat_nbrs

        # Intersect with material_filters / federal_cs exclude if present
        if material_filters or federal_cs_exclude:
            filtered_mat_nbrs = set(
                _material_qs().values_list('mat_nbr', flat=True)
            )
            final_mat_nbrs = final_mat_nbrs & filtered_mat_nbrs

        # Handle direct_mat_nbr
        if direct_mat_nbr and direct_mat_nbr in final_mat_nbrs:
            return direct_mat_nbr, None
        elif final_mat_nbrs:
            return None, Material.objects.filter(mat_nbr__in=final_mat_nbrs).values_list('mat_nbr', flat=True)
        else:
            return None, Material.objects.none().values_list('mat_nbr', flat=True)

    # No special filters - original logic
    if not material_filters and not direct_mat_nbr and not federal_cs_exclude:
        return None, None

    if material_filters or federal_cs_exclude:
        return direct_mat_nbr, _material_qs().values_list('mat_nbr', flat=True)

    return direct_mat_nbr, None


def apply_global_filters_for_vendor(queryset, request):
    """
    Apply all global filters to a Vendor queryset.

    Handles:
      - `supplier_parent` directly on the vendor (vendor_parent_id__in).
      - All other material-scoped global filters (supplier_nbr, buyer, product_category,
        therapeutic_class, gcn, xplant_mat_stat, cust_corp_chain, custom_list,
        formulary, injectable, who_essential, fee_for_service, material, etc.) by narrowing the
        vendor list to those whose materials match, via get_filtered_material_subquery.

    Note: Material.vendor uses to_field="vendor_nbr", so FK values are vendor_nbr strings.
    """
    from api.material.models import Material

    params = request.query_params

    # Vendor-level filter: supplier_parent
    if vals := _split_param(params, 'supplier_parent'):
        queryset = queryset.filter(vendor_parent_id__in=vals)

    # Material-scoped filters -> narrow vendors via their materials
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
    if direct_mat_nbr is None and mat_nbr_subquery is None:
        return queryset

    if direct_mat_nbr:
        vendor_nbrs = Material.objects.filter(mat_nbr=direct_mat_nbr).values_list(
            "vendor_id", flat=True
        ).distinct()
    else:
        vendor_nbrs = Material.objects.filter(
            mat_nbr__in=mat_nbr_subquery
        ).values_list("vendor_id", flat=True).distinct()

    vendor_nbrs = list(vendor_nbrs)
    if not vendor_nbrs:
        return queryset.none()
    return queryset.filter(vendor_nbr__in=vendor_nbrs)


def apply_optimized_material_filter(queryset, request, material_field='material'):
    """
    Apply global filters to a queryset using optimized subquery pattern.
    Avoids expensive JOINs by first getting matching mat_nbr values.
    """
    direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)

    if direct_mat_nbr:
        queryset = queryset.filter(**{material_field: direct_mat_nbr})

    if mat_nbr_subquery is not None:
        queryset = queryset.filter(**{f'{material_field}__in': mat_nbr_subquery})

    return queryset


class FederalCsIndFilterMixin:
    """Mixin that adds federal_cs_ind and exclude_federal_cs_ind query param filtering to a view."""

    @staticmethod
    def _parse_csv_param(request, param_name):
        value = request.query_params.get(param_name)
        if not value:
            return None
        values = [v.strip() for v in value.split(',') if v.strip()]
        return values or None

    def apply_federal_cs_ind_filter(self, queryset, request):
        include = self._parse_csv_param(request, 'federal_cs_ind')
        if include:
            queryset = queryset.filter(material__federal_cs_ind__in=include)

        exclude = self._parse_csv_param(request, 'exclude_federal_cs_ind')
        if exclude:
            queryset = queryset.exclude(material__federal_cs_ind__in=exclude)

        return queryset
