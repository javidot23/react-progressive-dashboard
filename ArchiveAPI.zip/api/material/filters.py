from django.db import models
from django_filters.rest_framework import FilterSet, filters

from api.global_filters import GlobalFilterMixin
from api.material.models import Material


class MaterialFilter(GlobalFilterMixin, FilterSet):
    mat_nbr = filters.CharFilter(lookup_expr='icontains', field_name='mat_nbr')
    name = filters.CharFilter(lookup_expr='icontains')
    search = filters.CharFilter(method='filter_search')
    vendor_id = filters.NumberFilter(field_name='vendor__id')
    vendor_nbr = filters.CharFilter(lookup_expr='icontains', field_name='vendor__vendor_nbr')
    vendor_name = filters.CharFilter(lookup_expr='icontains', field_name='vendor__name')
    risk_rating_min = filters.NumberFilter(field_name='risk_rating', lookup_expr='gte')
    risk_rating_max = filters.NumberFilter(field_name='risk_rating', lookup_expr='lte')
    dollars_at_risk_min = filters.NumberFilter(field_name='dollars_at_risk', lookup_expr='gte')
    dollars_at_risk_max = filters.NumberFilter(field_name='dollars_at_risk', lookup_expr='lte')
    forecast_qty_7day_min = filters.NumberFilter(field_name='forecast_qty_7day', lookup_expr='gte')
    forecast_qty_7day_max = filters.NumberFilter(field_name='forecast_qty_7day', lookup_expr='lte')
    cost_per_unit_min = filters.NumberFilter(field_name='cost_per_unit', lookup_expr='gte')
    cost_per_unit_max = filters.NumberFilter(field_name='cost_per_unit', lookup_expr='lte')
    market_share_min = filters.NumberFilter(field_name='market_share', lookup_expr='gte')
    market_share_max = filters.NumberFilter(field_name='market_share', lookup_expr='lte')

    def filter_search(self, queryset, name, value):
        """
        Search across key identification fields: mat_nbr, name, ndc, and fdb_gcn_seq_nbr.
        """
        if value:
            return queryset.filter(
                models.Q(mat_nbr__icontains=value) |
                models.Q(name__icontains=value) |
                models.Q(ndc__icontains=value) |
                models.Q(fdb_gcn_seq_nbr__icontains=value) |
                models.Q(vendor__name__icontains=value) |
                models.Q(vendor__vendor_nbr__icontains=value)
            )
        return queryset

    class Meta:
        model = Material
        fields = []


class MaterialsWithIssuesFilter(GlobalFilterMixin, FilterSet):
    """Filter for materials with issues."""
    name = filters.CharFilter(lookup_expr='icontains')

    risk_rating = filters.NumberFilter()
    risk_rating_min = filters.NumberFilter(field_name='risk_rating', lookup_expr='gte')
    risk_rating_max = filters.NumberFilter(field_name='risk_rating', lookup_expr='lte')

    dollars_at_risk = filters.NumberFilter()
    dollars_at_risk_min = filters.NumberFilter(field_name='dollars_at_risk', lookup_expr='gte')
    dollars_at_risk_max = filters.NumberFilter(field_name='dollars_at_risk', lookup_expr='lte')

    driving_risk = filters.CharFilter(lookup_expr='icontains')

    # Vendor filtering (also covered by GlobalFilterMixin but kept for backward compatibility)
    vendor_name = filters.CharFilter(lookup_expr='icontains', field_name='vendor__name')

    has_no_actions = filters.BooleanFilter(method='filter_no_actions')

    def filter_no_actions(self, queryset, name, value):
        if value:
            # Filter materials that have open issues with no actions
            return queryset.filter(
                issue__status='OPEN'
            ).exclude(
                issue__actions__isnull=False
            ).distinct()
        return queryset

    class Meta:
        model = Material
        fields = []


class MaterialProductFamilyScorecardFilter(FilterSet):
    """
    Filter for material product family scorecard view.

    Note: Global filters not applied here as this is an aggregated view by product family.
    Filters would need to be applied before aggregation in the service layer.
    """
    vendor_id = filters.NumberFilter(field_name='vendor__id')
    product_family = filters.CharFilter(lookup_expr='icontains', field_name='product_family')
    po_quantity_min = filters.NumberFilter(field_name='po_quantity', lookup_expr='gte')
    po_quantity_max = filters.NumberFilter(field_name='po_quantity', lookup_expr='lte')
    average_otif_min = filters.NumberFilter(field_name='average_otif', lookup_expr='gte')
    average_otif_max = filters.NumberFilter(field_name='average_otif', lookup_expr='lte')
    average_delivery_deviation_min = filters.NumberFilter(field_name='average_delivery_deviation', lookup_expr='gte')
    average_delivery_deviation_max = filters.NumberFilter(field_name='average_delivery_deviation', lookup_expr='lte')
    average_outbound_fill_rate_min = filters.NumberFilter(field_name='average_outbound_fill_rate',
                                                          lookup_expr='gte')
    average_outbound_fill_rate_max = filters.NumberFilter(field_name='average_outbound_fill_rate',
                                                          lookup_expr='lte')


class MaterialGcnFilter(FilterSet):
    """Filter for material GCN list view."""
    fdb_gcn_seq_nbr = filters.CharFilter(lookup_expr='icontains', field_name='fdb_gcn_seq_nbr')

    class Meta:
        model = Material
        fields = []


class MaterialTherapyClassFilter(FilterSet):
    """Filter for material therapy class list view."""
    hic3_therapy_class = filters.CharFilter(lookup_expr='icontains', field_name='hic3_therapy_class')

    class Meta:
        model = Material
        fields = []


class MaterialBuyerFilter(FilterSet):
    """Filter for material buyer list view."""
    buyer_name = filters.CharFilter(lookup_expr='icontains', field_name='buyer_name')
    buyer_cd = filters.CharFilter(lookup_expr='icontains', field_name='buyer_cd')

    class Meta:
        model = Material
        fields = []


class MaterialCategoryManagerFilter(FilterSet):
    """Filter for material category manager list view."""
    cat_mgr_name = filters.CharFilter(lookup_expr='icontains', field_name='cat_mgr_name')
    cat_mgr_nbr = filters.CharFilter(lookup_expr='icontains', field_name='cat_mgr_nbr')

    class Meta:
        model = Material
        fields = []


class MaterialGroupFilter(FilterSet):
    """Filter for material group list view."""
    material_group = filters.CharFilter(lookup_expr='icontains', field_name='material_group')

    class Meta:
        model = Material
        fields = []


class MaterialProductFamilyFilter(FilterSet):
    """Filter for material product family list view."""
    product_family = filters.CharFilter(lookup_expr='icontains', field_name='product_family')
    vendor_id = filters.NumberFilter(field_name='vendor__id')

    class Meta:
        model = Material
        fields = []


class MaterialXplantMatStatFilter(FilterSet):
    """Filter for material xplant mat stat list view."""
    xplant_mat_stat = filters.CharFilter(lookup_expr='iexact', field_name='xplant_mat_stat')

    class Meta:
        model = Material
        fields = []


class MaterialFederalCsIndicatorFilter(FilterSet):
    """Filter for material federal cs indicator list view."""
    federal_cs_ind = filters.CharFilter(lookup_expr='iexact', field_name='federal_cs_ind')

    class Meta:
        model = Material
        fields = []
