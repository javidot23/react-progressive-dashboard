from django.urls import path

from .views import WeeklyRiskAnalysisView, ForecastedDemandView, MaterialsWithIssuesView, MaterialListView, \
    MaterialDrivingRiskView, MaterialGroupedByFamilyScorecardView, MaterialProductFamilyListView, MaterialGcnListView, \
    MaterialTherapyClassListView, MaterialBuyerListView, MaterialCategoryManagerListView, MaterialGroupListView, \
    MaterialXplantMatStatListView, MaterialFederalCsIndicatorListView

app_name = "material"

urlpatterns = [
    path("", MaterialListView.as_view(), name="material-list"),
    path(
        "weekly-risk-analysis/",
        WeeklyRiskAnalysisView.as_view(),
        name="weekly-risk-analysis",
    ),
    path(
        "forecasted-demand/", ForecastedDemandView.as_view(), name="forecasted-demand"
    ),
    path(
        "materials-with-issues/",
        MaterialsWithIssuesView.as_view(),
        name="materials-with-issues",
    ),
    path("driving-risk/", MaterialDrivingRiskView.as_view(), name="driving-isk-list"),
    path("product-family/", MaterialProductFamilyListView.as_view(), name="product-family"),
    path("product-family/scorecard/", MaterialGroupedByFamilyScorecardView.as_view(),
         name="material-family-scorecard"),
    path("gcn/", MaterialGcnListView.as_view(), name="gcn-list"),
    path("therapy-class/", MaterialTherapyClassListView.as_view(), name="therapy-class-list"),
    path("buyer/", MaterialBuyerListView.as_view(), name="buyer-list"),
    path("category-manager/", MaterialCategoryManagerListView.as_view(), name="category-manager-list"),
    path("group/", MaterialGroupListView.as_view(), name="material-group-list"),
    path("xplant-mat-stat/", MaterialXplantMatStatListView.as_view(), name="xplant-mat-stat-list"),
    path("federal-cs-indicator/", MaterialFederalCsIndicatorListView.as_view(), name="federal-cs-indicator-list")
]
