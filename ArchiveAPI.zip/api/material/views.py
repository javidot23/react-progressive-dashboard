import logging

from django.conf import settings
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics
from rest_framework import status
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema

from api.global_filters import get_filtered_material_subquery, get_material_option_queryset
from .filters import MaterialProductFamilyScorecardFilter, MaterialsWithIssuesFilter, MaterialFilter, \
    MaterialBuyerFilter, MaterialCategoryManagerFilter, MaterialGroupFilter, MaterialTherapyClassFilter, \
    MaterialGcnFilter, MaterialProductFamilyFilter, MaterialXplantMatStatFilter, MaterialFederalCsIndicatorFilter
from .serializers import RiskWeeklyComparisonSerializer, ForecastedDemandSerializer, MaterialWithIssuesSerializer, \
    MaterialSerializer, DrivingRiskSerializer, MaterialGroupedByFamilyForScorecardSerializer, \
    MaterialFamilyListSerializer, MaterialGcnSerializer, MaterialTherapyClassSerializer, MaterialBuyerSerializer, \
    MaterialCategoryManagerSerializer, MaterialGroupSerializer, MaterialXplantMatStatSerializer, \
    MaterialFederalCsIndicatorSerializer
from .services import MaterialService
from ..pagination import MaxLimitOffsetPagination

logger = logging.getLogger(__name__)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class WeeklyRiskAnalysisView(APIView):
    """
    Returns aggregate risk score and dollars at risk for products ordered this week.
    Supports global filters.
    """

    @extend_schema(responses=RiskWeeklyComparisonSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = MaterialService.get_weekly_risk_analysis(direct_mat_nbr, mat_nbr_subquery)
        serializer = RiskWeeklyComparisonSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='get')
class ForecastedDemandView(APIView):
    """
    Returns forecasted demand for all materials.
    Supports global filters.
    """

    @extend_schema(responses=ForecastedDemandSerializer)
    def get(self, request):
        direct_mat_nbr, mat_nbr_subquery = get_filtered_material_subquery(request)
        data = MaterialService.get_forecasted_demand(direct_mat_nbr, mat_nbr_subquery)
        serializer = ForecastedDemandSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialsWithIssuesView(generics.ListAPIView):
    serializer_class = MaterialWithIssuesSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialsWithIssuesFilter
    ordering_fields = [
        'name', 'mat_nbr', 'risk_rating', 'dollars_at_risk', 'driving_risk',
        'ndc', 'description', 'forecast_qty_7day', 'created_at',
        'updated_at', 'vendor__name'
    ]
    ordering = ['-risk_rating']

    def get_queryset(self):
        # Service returns \(`queryset`, `user_cache`\) for tests; view needs only the queryset.
        result = MaterialService.get_materials_with_opened_issues()
        return result[0] if isinstance(result, tuple) else result

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            # Build user cache for the current page only (single evaluation)
            user_cache = MaterialService.build_user_cache_for_materials(page)
            context = self.get_serializer_context()
            context['user_cache'] = user_cache
            serializer = self.get_serializer(page, many=True)
            serializer.context.update(context)
            return self.get_paginated_response(serializer.data)

        materials = list(queryset)
        user_cache = MaterialService.build_user_cache_for_materials(materials)
        context = self.get_serializer_context()
        context['user_cache'] = user_cache
        serializer = self.get_serializer(materials, many=True)
        serializer.context.update(context)
        return Response(serializer.data, status=status.HTTP_200_OK)


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialListView(generics.ListAPIView):
    serializer_class = MaterialSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialFilter
    ordering_fields = ['name', 'risk_rating', 'risk_adjusted_value']
    ordering = ['-risk_rating']

    def get_queryset(self):
        return MaterialService.get_materials()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialDrivingRiskView(generics.ListAPIView):
    serializer_class = DrivingRiskSerializer
    pagination_class = None

    def get_queryset(self):
        return MaterialService.get_material_driving_risk()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialGroupedByFamilyScorecardView(generics.ListAPIView):
    serializer_class = MaterialGroupedByFamilyForScorecardSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialProductFamilyScorecardFilter
    ordering_fields = [
        'product_family',
        'po_quantity',
        'average_otif',
        'average_delivery_deviation',
        'average_outbound_fill_rate'
    ]
    ordering = ['-po_quantity']

    def get_queryset(self):
        return MaterialService.get_materials_grouped_by_family_scorecard()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialProductFamilyListView(generics.ListAPIView):
    serializer_class = MaterialFamilyListSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialProductFamilyFilter
    ordering_fields = ['product_family']
    ordering = ['product_family']

    def get_queryset(self):
        return MaterialService.get_material_product_families()


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialGcnListView(generics.ListAPIView):
    serializer_class = MaterialGcnSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialGcnFilter
    ordering_fields = ['fdb_gcn_seq_nbr']
    ordering = ['fdb_gcn_seq_nbr']

    def get_queryset(self):
        return get_material_option_queryset(
            self.request, ["fdb_gcn_seq_nbr"], filter_field="fdb_gcn_seq_nbr"
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialTherapyClassListView(generics.ListAPIView):
    serializer_class = MaterialTherapyClassSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialTherapyClassFilter
    ordering_fields = ['hic3_therapy_class']
    ordering = ['hic3_therapy_class']

    def get_queryset(self):
        return get_material_option_queryset(
            self.request, ["hic3_therapy_class"], filter_field="hic3_therapy_class"
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialBuyerListView(generics.ListAPIView):
    serializer_class = MaterialBuyerSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialBuyerFilter
    ordering_fields = ['buyer_name', 'buyer_cd']
    ordering = ['buyer_name']

    def get_queryset(self):
        return get_material_option_queryset(
            self.request, ["buyer_name", "buyer_cd"], filter_field="buyer_name"
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialCategoryManagerListView(generics.ListAPIView):
    serializer_class = MaterialCategoryManagerSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialCategoryManagerFilter
    ordering_fields = ['cat_mgr_name', 'cat_mgr_nbr']
    ordering = ['cat_mgr_name']

    def get_queryset(self):
        return get_material_option_queryset(
            self.request, ["cat_mgr_name", "cat_mgr_nbr"], filter_field="cat_mgr_name"
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialGroupListView(generics.ListAPIView):
    serializer_class = MaterialGroupSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialGroupFilter
    ordering_fields = ['material_group']
    ordering = ['material_group']

    def get_queryset(self):
        return get_material_option_queryset(
            self.request, ["material_group"], filter_field="material_group"
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialXplantMatStatListView(generics.ListAPIView):
    serializer_class = MaterialXplantMatStatSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialXplantMatStatFilter
    ordering_fields = ['xplant_mat_stat']
    ordering = ['xplant_mat_stat']

    def get_queryset(self):
        return get_material_option_queryset(
            self.request, ["xplant_mat_stat"], filter_field="xplant_mat_stat"
        )


@method_decorator(cache_page(getattr(settings, 'CACHE_MIDDLEWARE_SECONDS', 3600)), name='list')
class MaterialFederalCsIndicatorListView(generics.ListAPIView):
    serializer_class = MaterialFederalCsIndicatorSerializer
    pagination_class = MaxLimitOffsetPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = MaterialFederalCsIndicatorFilter
    ordering_fields = ['federal_cs_ind']
    ordering = ['federal_cs_ind']

    def get_queryset(self):
        return get_material_option_queryset(
            self.request, ["federal_cs_ind"], filter_field="federal_cs_ind"
        )
