from django.db import models

from api.vendor.models import Vendor


class Material(models.Model):
    class MaterialGroup(models.TextChoices):
        GENERIC = "Generic"
        BRAND = "Brand"
        OTC = "OTC"
        CONSUMER = "Consumer"

    mat_nbr = models.CharField(max_length=255, unique=True)  # Material number from DBX
    name = models.CharField(max_length=255, null=True, blank=True)
    vendor = models.ForeignKey(
        Vendor,
        to_field="vendor_nbr",
        db_column="vendor_nbr",
        on_delete=models.CASCADE
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    risk_rating = models.FloatField(default=0.0, blank=True, null=True)
    driving_risk = models.CharField(max_length=255, blank=True, null=True)
    dollars_at_risk = models.FloatField(default=0.0, blank=True, null=True)
    ndc = models.CharField(
        max_length=255, blank=True, null=True
    )  # National Drug Code
    saleable_qty_on_hand = models.IntegerField(default=0, blank=True, null=True)
    unrestricted_qty_on_hand = models.IntegerField(default=0, blank=True, null=True)
    forecast_qty_7day = models.IntegerField(default=0, blank=True, null=True)
    cost_per_unit = models.FloatField(default=0.0, blank=True, null=True)
    market_share = models.FloatField(default=0.0, blank=True, null=True)
    material_group = models.CharField(
        max_length=255,
        choices=MaterialGroup.choices,
        default=MaterialGroup.GENERIC,
    )
    cat_mgr_name = models.CharField(max_length=255, blank=True, null=True)  # Category Manager
    cat_mgr_nbr = models.CharField(max_length=50, blank=True, null=True)  # Category Manager Number
    buyer_name = models.CharField(max_length=255, blank=True, null=True)  # buyer_name
    buyer_cd = models.CharField(max_length=50, blank=True, null=True)  # buyer_name Code
    product_family = models.CharField(max_length=255, blank=True, null=True)
    otif_percentage = models.FloatField(default=0.0, blank=True, null=True)
    delivery_deviation = models.FloatField(default=0.0, blank=True, null=True)  # negative is early, positive is late
    outbound_fill_rate = models.FloatField(default=0.0, blank=True, null=True)
    fdb_gcn_seq_nbr = models.CharField(max_length=255, blank=True, null=True)  # First Data Bank Generic Code Number
    hicl = models.CharField(max_length=255, blank=True, null=True)  # Hierarchical Ingredient Code List
    hicl_description = models.CharField(max_length=255, blank=True, null=True)
    hic3_therapy_class = models.CharField(max_length=255, blank=True, null=True)
    dollars_at_risk_this_week = models.FloatField(default=0.0, blank=True, null=True)
    dollars_at_risk_prev_week = models.FloatField(default=0.0, blank=True, null=True)
    xplant_mat_stat = models.CharField(max_length=255, blank=True, null=True)
    scrm_mat_grp = models.CharField(max_length=255, blank=True, null=True)
    product_group = models.CharField(max_length=255, blank=True, null=True)
    mat_nbr6 = models.CharField(max_length=255, blank=True, null=True)
    mfr_part_nbr = models.CharField(max_length=255, blank=True, null=True)
    drop_ship_flg = models.IntegerField(default=0)
    short_date_flg = models.IntegerField(default=0)
    inj_flg = models.IntegerField(default=0)
    who_essential_flg = models.IntegerField(default=0)
    dqsa_exempt_flg = models.CharField(max_length=10, null=True, blank=True, db_column="dqsa_exempt_flg")
    mnftr_avail_note_cd = models.CharField(max_length=255, blank=True, null=True)
    mnftr_avail_note_desc = models.CharField(max_length=255, blank=True, null=True)
    unit_strength_type_cd = models.CharField(max_length=255, blank=True, null=True)
    route_cd_interpretation = models.CharField(max_length=255, blank=True, null=True)
    multiple_product_ind = models.CharField(max_length=255, blank=True, null=True)
    multi_product_desc = models.CharField(max_length=255, blank=True, null=True)
    temp_cond_ind = models.CharField(max_length=255, null=True, blank=True)
    temp_cond_desc = models.CharField(max_length=255, null=True, blank=True)
    api = models.CharField(max_length=255, blank=True, null=True)
    form_cd = models.CharField(max_length=255, blank=True, null=True)
    unit_strength_qty = models.CharField(max_length=255, blank=True, null=True)
    federal_cs_ind = models.CharField(max_length=255, null=True, blank=True, db_column="federal_cs_ind")
    buyer_comment_notes = models.TextField(null=True, blank=True)
    fee_for_service_flg = models.IntegerField(default=0, blank=True, null=True)
    avg_shortage_duration = models.IntegerField(default=0, blank=True, null=True)

    class Meta:
        db_table = "materials"
        verbose_name = "Material"
        verbose_name_plural = "Materials"
        indexes = [
            models.Index(fields=["mat_nbr"]),
            models.Index(fields=["vendor"]),
            models.Index(fields=["material_group"]),
            models.Index(fields=["risk_rating"]),
            models.Index(fields=["dollars_at_risk"]),
            models.Index(fields=["driving_risk"]),
            models.Index(fields=["ndc"]),
            models.Index(fields=["fdb_gcn_seq_nbr"]),
            models.Index(fields=["hicl"]),
            models.Index(
                fields=['mat_nbr'],
                include=['name'],
                name='mat_nbr_name_covering_idx'
            ),
            models.Index(fields=["drop_ship_flg"], name="materials_drop_sh_idx"),
            models.Index(fields=["short_date_flg"], name="materials_short_d_idx"),
            models.Index(fields=["inj_flg"], name="materials_inj_flg_idx"),
            models.Index(fields=["who_essential_flg"], name="materials_who_ess_idx"),
        ]
