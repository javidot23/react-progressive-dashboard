import logging
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.db.models import Avg, Sum, Count, Q, F, FloatField, Case, When
from django.db.models.functions import Coalesce, Trim
from django.db.models.query import Prefetch
from django.utils import timezone

from api.material.models import Material
from ..action.models import Action
from ..issue.models import Issue
from ..purchase_order.models import PurchaseOrder

logger = logging.getLogger(__name__)


class MaterialService:

    @staticmethod
    def get_materials():
        """Retrieve all materials with their related data. Retreive also vendor name and vendor number only """
        return Material.objects.all().select_related('vendor').annotate(
            risk_adjusted_value=Case(
                When(
                    risk_rating__isnull=False,
                    dollars_at_risk__isnull=False,
                    then=F('risk_rating') * F('dollars_at_risk')
                ),
                default=0.0,
                output_field=FloatField()
            )
        )

    @staticmethod
    def get_weekly_risk_analysis(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get aggregate risk metrics for products ordered this week.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting weekly risk analysis data")
        now = timezone.now()

        current_week_start = now - timedelta(days=now.weekday())
        current_week_start = current_week_start.replace(
            hour=0, minute=0, second=0, microsecond=0
        )

        current_week_orders = PurchaseOrder.objects.filter(
            ordered_date__gte=current_week_start.date(), ordered_date__lte=now.date()
        ).select_related("material")

        if direct_mat_nbr:
            current_week_orders = current_week_orders.filter(material__mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            current_week_orders = current_week_orders.filter(material__mat_nbr__in=mat_nbr_subquery)

        risk_metrics = current_week_orders.aggregate(
            avg_risk_score=Avg("material__risk_rating"),
            total_dollars_at_risk=Sum("material__dollars_at_risk"),
            products_count=Count("material", distinct=True),
        )

        aggregate_risk_score = max(0.0, min(1.0, risk_metrics["avg_risk_score"] or 0.0))
        total_dollars_at_risk = risk_metrics["total_dollars_at_risk"] or 0.0
        products_count = risk_metrics["products_count"] or 0

        logger.info(
            "Weekly risk analysis: risk_score=%.3f, dollars_at_risk=%.2f, products=%d",
            aggregate_risk_score,
            total_dollars_at_risk,
            products_count,
        )

        return {
            "aggregate_risk_score": round(aggregate_risk_score, 3),
            "total_dollars_at_risk": round(total_dollars_at_risk, 2),
            "products_count": products_count,
            "period": {
                "week_start": current_week_start.date().isoformat(),
                "week_end": now.date().isoformat(),
                "analysis_date": now.date().isoformat(),
            },
        }

    @staticmethod
    def get_forecasted_demand(direct_mat_nbr=None, mat_nbr_subquery=None):
        """
        Get forecasted demand for all materials.
        Uses optimized subquery pattern to avoid expensive JOINs.
        """
        logger.info("Getting forecasted demand data")

        queryset = Material.objects.all()

        if direct_mat_nbr:
            queryset = queryset.filter(mat_nbr=direct_mat_nbr)
        if mat_nbr_subquery is not None:
            queryset = queryset.filter(mat_nbr__in=mat_nbr_subquery)

        forecast_qty_7day = (
            queryset.aggregate(
                total_forecast_qty_7day=Avg("forecast_qty_7day")
            )["total_forecast_qty_7day"]
            or 0.0
        )
        logger.info("Forecasted demand: %.2f", forecast_qty_7day)
        return {"forecast_qty_7day": round(forecast_qty_7day, 0)}

    @staticmethod
    def get_materials_with_opened_issues():
        """Return a tuple.

        - `queryset`: Materials having open issues with issues/actions prefetched.
        - `user_cache`: empty dict placeholder for tests; views build it per page.
        """
        logger.info("Getting materials with open issues")

        actions_prefetch = Prefetch(
            "actions",
            queryset=(
                Action.objects
                .select_related(
                    "potential_action",
                    "substituted_material",
                    "material",
                    "substituted_material__vendor",
                    "material__vendor",
                )
                .order_by("-created_at")
            ),
            to_attr="action_list",
        )

        issues_prefetch = Prefetch(
            "issue_set",
            queryset=Issue.objects.filter(status=Issue.IssueStatus.OPEN).prefetch_related(actions_prefetch),
            to_attr="open_issues",
        )

        queryset = (
            Material.objects.filter(issue__status=Issue.IssueStatus.OPEN)
            .prefetch_related(issues_prefetch, "vendor")
            .distinct()
        )

        # Tests only assert dict type and emptiness in some cases.
        user_cache = {}

        return queryset, user_cache

    @staticmethod
    def build_user_cache_for_materials(materials):
        """Build user cache from an already-paginated list of materials."""
        all_user_ids = set()
        for material in materials:
            for issue in getattr(material, "open_issues", []):
                for action in getattr(issue, "action_list", []):
                    if action.user_id:
                        all_user_ids.add(action.user_id)

        if not all_user_ids:
            return {}

        users = (
            get_user_model()
            .objects.only("user_uuid", "first_name", "last_name")
            .filter(user_uuid__in=all_user_ids)
        )
        return {
            str(u.pk): {"id": str(u.pk), "first_name": u.first_name, "last_name": u.last_name}
            for u in users
        }

    @staticmethod
    def get_material_driving_risk():
        return (
            Material.objects.filter(driving_risk__isnull=False)
            .exclude(driving_risk="")
            .values("driving_risk")
            .distinct()
        )

    @staticmethod
    def get_materials_grouped_by_family_scorecard():
        logger.info("Getting materials grouped by family for scorecard")
        thirty_days_ago = timezone.now().date() - timedelta(days=30)

        return (
            Material.objects.filter(product_family__isnull=False)
            .exclude(product_family="")
            .annotate(_product_family_trimmed=Trim("product_family"))
            .exclude(_product_family_trimmed="")
            .values("product_family")
            .annotate(
                po_quantity=Coalesce(
                    Sum("servicelevel__total_order_qty",
                        filter=Q(servicelevel__date__gte=thirty_days_ago)
                        ),
                    0
                ),
                average_otif=Avg("otif_percentage"),
                average_delivery_deviation=Avg("delivery_deviation"),
                average_outbound_fill_rate=Avg("outbound_fill_rate"),
            )
            .order_by("product_family")
        )

    @staticmethod
    def get_material_product_families():
        return (
            Material.objects.filter(product_family__isnull=False)
            .exclude(product_family="")
            .annotate(_product_family_trimmed=Trim("product_family"))
            .exclude(_product_family_trimmed="")
            .values("product_family")
            .distinct()
        )

    @staticmethod
    def get_material_gcns():
        return (
            Material.objects.filter(fdb_gcn_seq_nbr__isnull=False)
            .exclude(fdb_gcn_seq_nbr="")
            .values("fdb_gcn_seq_nbr")
            .distinct()
        )

    @staticmethod
    def get_material_therapy_classes():
        return (
            Material.objects.filter(hic3_therapy_class__isnull=False)
            .exclude(hic3_therapy_class="")
            .values("hic3_therapy_class")
            .distinct()
        )

    @staticmethod
    def get_material_buyers():
        return (
            Material.objects.filter(buyer_name__isnull=False)
            .exclude(buyer_name="")
            .values("buyer_name", "buyer_cd")
            .distinct()
        )

    @staticmethod
    def get_material_category_managers():
        return (
            Material.objects.filter(cat_mgr_name__isnull=False)
            .exclude(cat_mgr_name="")
            .values("cat_mgr_name", "cat_mgr_nbr")
            .distinct()
        )

    @staticmethod
    def get_material_groups():
        return (
            Material.objects.filter(material_group__isnull=False)
            .exclude(material_group="")
            .values("material_group")
            .distinct()
        )

    @staticmethod
    def get_material_xplant_mat_stats():
        return (
            Material.objects.filter(xplant_mat_stat__isnull=False)
            .exclude(xplant_mat_stat="")
            .values("xplant_mat_stat")
            .distinct()
        )

    @staticmethod
    def get_material_federal_cs_indicators():
        return (
            Material.objects.filter(federal_cs_ind__isnull=False)
            .exclude(federal_cs_ind="")
            .values("federal_cs_ind")
            .distinct()
        )
