from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from api.action.serializers import ActionSerializer
from api.issue.models import Issue
from api.issue_note.serializers import IssueNoteSerializer
from api.material.models import Material
from api.potential_action.serializers import PotentialActionSerializer
from api.serializer_mixins import NanSafeSerializerMixin
from api.vendor.serializers import VendorSerializer


class SimpleMaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Material
        fields = ['id', 'name', 'mat_nbr']
        read_only_fields = ("created_at", "updated_at")


class MaterialSerializer(NanSafeSerializerMixin, serializers.ModelSerializer):
    vendor = serializers.CharField(source="vendor.name")
    vendor_nbr = serializers.CharField(source="vendor.vendor_nbr")

    class Meta:
        model = Material
        fields = "__all__"
        read_only_fields = ("created_at", "updated_at")


class RiskWeeklyPeriodSerializer(serializers.Serializer):
    week_start = serializers.DateField()
    week_end = serializers.DateField()
    analysis_date = serializers.DateField()


class RiskWeeklyComparisonSerializer(serializers.Serializer):
    aggregate_risk_score = serializers.FloatField()
    total_dollars_at_risk = serializers.FloatField()
    products_count = serializers.IntegerField()
    period = RiskWeeklyPeriodSerializer()


class ForecastedDemandSerializer(serializers.Serializer):
    forecast_qty_7day = serializers.IntegerField()


class IssueWithActionSerializer(serializers.ModelSerializer):
    actions = ActionSerializer(many=True, source="action_list")
    potential_actions = serializers.SerializerMethodField()
    notes_count = serializers.IntegerField(read_only=True, default=0)
    last_note = serializers.SerializerMethodField()

    class Meta:
        model = Issue
        fields = "__all__"

    @extend_schema_field(PotentialActionSerializer(many=True))
    def get_potential_actions(self, obj):
        # Import here to avoid circular import
        from api.potential_action.serializers import PotentialActionSerializer
        potential_action_list = getattr(obj, 'potential_action_list', [])
        return PotentialActionSerializer(potential_action_list, many=True).data

    @extend_schema_field(IssueNoteSerializer(allow_null=True))
    def get_last_note(self, obj):
        last_note = getattr(obj, 'last_note', None)
        if last_note is None:
            return None
        data = IssueNoteSerializer(last_note, context=self.context).data
        data.pop('user', None)
        return data

    def get_serializer_context(self):
        # Pass through the user_cache from parent context
        return self.context


class MaterialWithIssuesSerializer(NanSafeSerializerMixin, serializers.ModelSerializer):
    open_issues = IssueWithActionSerializer(many=True)
    vendor = VendorSerializer()

    class Meta:
        model = Material
        fields = "__all__"
        read_only_fields = ('id', 'name', 'open_issues')


class MaterialWithVendorSerializer(NanSafeSerializerMixin, serializers.ModelSerializer):
    vendor = VendorSerializer()

    class Meta:
        model = Material
        fields = "__all__"
        read_only_fields = ('id', 'name', 'vendor')


class DrivingRiskSerializer(serializers.Serializer):
    driving_risk = serializers.CharField()

    class Meta:
        ref_name = 'MaterialDrivingRisk'


class MaterialGroupedByFamilyForScorecardSerializer(NanSafeSerializerMixin, serializers.Serializer):
    product_family = serializers.CharField()
    po_quantity = serializers.IntegerField()
    average_otif = serializers.FloatField()
    average_delivery_deviation = serializers.FloatField()
    average_outbound_fill_rate = serializers.FloatField()


class MaterialFamilyListSerializer(serializers.Serializer):
    product_family = serializers.CharField()


class MaterialGcnSerializer(serializers.Serializer):
    fdb_gcn_seq_nbr = serializers.CharField()


class MaterialTherapyClassSerializer(serializers.Serializer):
    hic3_therapy_class = serializers.CharField()


class MaterialBuyerSerializer(serializers.Serializer):
    buyer_name = serializers.CharField()
    buyer_cd = serializers.CharField()


class MaterialCategoryManagerSerializer(serializers.Serializer):
    cat_mgr_name = serializers.CharField()
    cat_mgr_nbr = serializers.CharField()


class MaterialGroupSerializer(serializers.Serializer):
    material_group = serializers.CharField()


class MaterialXplantMatStatSerializer(serializers.Serializer):
    xplant_mat_stat = serializers.CharField()


class MaterialFederalCsIndicatorSerializer(serializers.Serializer):
    federal_cs_ind = serializers.CharField()
