"""
Gunicorn runtime configuration.

Values are tunable via environment so they can track the Kubernetes pod's
CPU/memory requests (see helm values `gunicorn.workers`/`gunicorn.threads`)
without rebuilding the image.
"""

import os

bind = "0.0.0.0:8000"
workers = int(os.environ.get("GUNICORN_WORKERS", 4))
threads = int(os.environ.get("GUNICORN_THREADS", 4))

# Heartbeat file must live on tmpfs, not a disk-backed FS - required for
# readOnlyRootFilesystem and prevents random worker freezes under K8s.
worker_tmp_dir = "/dev/shm"

# Gunicorn 25 opens a Unix control socket, defaulting to a path relative to CWD
# (/home/app/.gunicorn/gunicorn.ctl). /home/app is intentionally root-owned and the
# container runs with readOnlyRootFilesystem, so this fails with EROFS on every
# start. We do not use the control interface - a socket that can restart workers is
# attack surface with no operational benefit here - so disable it outright rather
# than granting a writable path.
control_socket_disable = True

timeout = int(os.environ.get("GUNICORN_TIMEOUT", 75))
graceful_timeout = int(os.environ.get("GUNICORN_GRACEFUL_TIMEOUT", 30))
keepalive = int(os.environ.get("GUNICORN_KEEPALIVE", 5))
max_requests = int(os.environ.get("GUNICORN_MAX_REQUESTS", 1000))
max_requests_jitter = int(os.environ.get("GUNICORN_MAX_REQUESTS_JITTER", 100))

preload_app = True
accesslog = "-"
errorlog = "-"

# AGIC is the only network path to this pod; safe to trust its X-Forwarded-* headers.
forwarded_allow_ips = "*"
