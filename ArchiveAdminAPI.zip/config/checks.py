import inspect

from django.core.checks import Error, Tags, register
from django.middleware.cache import CacheMiddleware, FetchFromCacheMiddleware
from django.urls import URLPattern, URLResolver, get_resolver
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView

# Endpoints intentionally reachable without authentication.
PUBLIC_VIEWS = {
    "api.info.views.InfoAPIView",
    "api.identity.views.LoginStartView",
    "api.identity.views.LoginView",
}


def dotted_path(view_cls):
    return f"{view_cls.__module__}.{view_cls.__qualname__}"


def _view_class(callback):
    return getattr(callback, "cls", getattr(callback, "view_class", None))


def _effective_attr(callback, view_cls, attr):
    initkwargs = getattr(callback, "initkwargs", {})
    return initkwargs.get(attr, getattr(view_cls, attr, None))


def iter_api_views(patterns=None, prefix=""):
    """Yield ``(route, view_cls, callback)`` for every DRF view in the URLconf."""
    if patterns is None:
        patterns = get_resolver().url_patterns
    for entry in patterns:
        if isinstance(entry, URLResolver):
            yield from iter_api_views(entry.url_patterns, prefix + str(entry.pattern))
        elif isinstance(entry, URLPattern):
            view_cls = _view_class(entry.callback)
            if view_cls is not None and issubclass(view_cls, APIView):
                yield prefix + str(entry.pattern), view_cls, entry.callback


def auth_problems(view_cls, callback):
    """Return the reasons a view disables authentication (empty means it is protected)."""
    problems = []
    if not _effective_attr(callback, view_cls, "authentication_classes"):
        problems.append("authentication_classes is empty")
    perms = _effective_attr(callback, view_cls, "permission_classes")
    if not perms:
        problems.append("permission_classes is empty")
    elif any(perm is AllowAny for perm in perms):
        problems.append("permission_classes contains AllowAny")
    return problems


def caches_before_authentication(view_cls, _fn=None, _depth=0, _seen=None):
    """True if the view's ``dispatch`` is wrapped by the cache-fetch middleware.

    ``cache_page`` on ``dispatch`` runs the cache lookup before DRF authenticates,
    so a cache hit is served to anyone. Applied to a handler (``get``/``list``/
    ``retrieve``) instead, authentication runs first. This walks the decorator
    chain method_decorator builds around ``dispatch`` looking for the middleware.
    """
    if _fn is None:
        _fn = view_cls.__dict__.get("dispatch")
        _seen = set()
    if _fn is None or id(_fn) in _seen or _depth > 12:
        return False
    _seen.add(id(_fn))
    for cell in getattr(_fn, "__closure__", None) or []:
        try:
            value = cell.cell_contents
        except ValueError:
            continue
        for obj in value if isinstance(value, (list, tuple)) else [value]:
            if inspect.isclass(obj) and issubclass(obj, (CacheMiddleware, FetchFromCacheMiddleware)):
                return True
            if callable(obj) and caches_before_authentication(view_cls, obj, _depth + 1, _seen):
                return True
    wrapped = getattr(_fn, "__wrapped__", None)
    return caches_before_authentication(view_cls, wrapped, _depth + 1, _seen) if wrapped else False


@register(Tags.security)
def check_endpoint_authentication(app_configs, **kwargs):
    errors = []
    for route, view_cls, callback in iter_api_views():
        dotted = dotted_path(view_cls)
        if dotted in PUBLIC_VIEWS:
            continue
        problems = auth_problems(view_cls, callback)
        if problems:
            errors.append(Error(
                f"Endpoint '/{route}' ({dotted}) disables authentication: "
                + "; ".join(problems) + ".",
                hint="Remove the override so the view inherits the authenticated "
                     "defaults, or add it to config.checks.PUBLIC_VIEWS if it is public.",
                id="security.E001",
            ))
    return errors


@register(Tags.security)
def check_cache_before_authentication(app_configs, **kwargs):
    errors = []
    for route, view_cls, _ in iter_api_views():
        dotted = dotted_path(view_cls)
        if dotted in PUBLIC_VIEWS:
            continue
        if caches_before_authentication(view_cls):
            errors.append(Error(
                f"Endpoint '/{route}' ({dotted}) caches on 'dispatch', so a cache "
                "hit is served without authentication.",
                hint="Apply cache_page to the handler method instead: "
                     "@method_decorator(cache_page(...), name='list'|'retrieve'|'get').",
                id="security.E002",
            ))
    return errors
