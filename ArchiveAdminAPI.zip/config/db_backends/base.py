import os

from django.db.backends.postgresql.base import DatabaseWrapper as PostgresDatabaseWrapper

_credential = None


def _get_credential():
    global _credential
    if _credential is None:
        from azure.identity import WorkloadIdentityCredential
        # tenant_id / client_id / token_file_path are injected onto the pod by the AKS
        # workload identity webhook (triggered by the azure.workload.identity/use label +
        # a ServiceAccount annotated with azure.workload.identity/client-id).
        _credential = WorkloadIdentityCredential(
            tenant_id=os.environ['AZURE_TENANT_ID'],
            client_id=os.environ['AZURE_CLIENT_ID'],
            token_file_path=os.environ['AZURE_FEDERATED_TOKEN_FILE'],
        )
    return _credential


class DatabaseWrapper(PostgresDatabaseWrapper):
    def get_connection_params(self):
        params = super().get_connection_params()
        if os.environ.get('DB_USE_MANAGED_IDENTITY', '').lower() == 'true':
            token = _get_credential().get_token(
                "https://ossrdbms-aad.database.windows.net/.default"
            )
            params['password'] = token.token
        return params
