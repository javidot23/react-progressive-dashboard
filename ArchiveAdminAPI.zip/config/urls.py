from django.conf import settings
from django.http import JsonResponse
from django.urls import include
from django.urls import path
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView,
    SpectacularSwaggerView,
)


def custom_404_handler(request, exception=None):
    return JsonResponse({'error': 'Not found'}, status=404)


def custom_500_handler(request):
    return JsonResponse({'error': 'Internal server error'}, status=500)


if not settings.DEBUG:
    handler404 = custom_404_handler
    handler500 = custom_500_handler

API_ROUTES = [
    path("", include("api.identity.urls")),
    path("auth/", include("api.user.urls")),
    path("tenants/", include("api.tenant.urls")),
    path("users/", include("api.user.management_urls")),
    path("authz/", include("api.authz.urls")),
    path("audit/", include("api.audit.urls")),
    path("user-setting/", include("api.user_setting.urls")),
    path("user-feedback/", include("api.user_feedback.urls")),
    path("info/", include("api.info.urls")),
    path("schema/", SpectacularAPIView.as_view(), name="schema"),
    path(
        "schema/swagger-ui/",
        SpectacularSwaggerView.as_view(url_name="schema"),
        name="swagger-ui",
    ),
    path(
        "schema/redoc/",
        SpectacularRedocView.as_view(url_name="schema"),
        name="redoc",
    ),
]

api_route_prefix = (
    f"{settings.API_PATH_PREFIX}/" if settings.API_PATH_PREFIX else ""
)

urlpatterns = [
    path(api_route_prefix, include(API_ROUTES)),
    path("info/", include("api.info.urls")),
]
