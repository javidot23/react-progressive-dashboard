"""Django CACHES builders for production Sentinel Redis and local LocMem."""


def build_sentinel_cache(
    *,
    key_prefix,
    timeout,
    password,
    master,
    sentinel_hosts,
    sentinel_port=26379,
):
    if not password:
        raise ValueError("REDIS_PASSWORD is required for Sentinel cache")

    sentinels = [(host, sentinel_port) for host in sentinel_hosts]

    return {
        "default": {
            "BACKEND": "django_redis.cache.RedisCache",
            "LOCATION": f"redis://{master}/0",
            "TIMEOUT": timeout,
            "KEY_PREFIX": key_prefix,
            "OPTIONS": {
                "CLIENT_CLASS": "django_redis.client.SentinelClient",
                "CONNECTION_FACTORY": "django_redis.pool.SentinelConnectionFactory",
                "SENTINELS": sentinels,
                "SENTINEL_KWARGS": {"password": password},
                "CONNECTION_POOL_CLASS": "redis.sentinel.SentinelConnectionPool",
                "CONNECTION_POOL_KWARGS": {"max_connections": 100},
                "PASSWORD": password,
                "IGNORE_EXCEPTIONS": True,
                "SOCKET_CONNECT_TIMEOUT": 5,
                "SOCKET_TIMEOUT": 5,
            },
        }
    }


def build_locmem_cache(*, key_prefix, timeout, max_entries=1000):
    return {
        "default": {
            "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
            "LOCATION": "unique-snowflake",
            "TIMEOUT": timeout,
            "KEY_PREFIX": key_prefix,
            "OPTIONS": {
                "MAX_ENTRIES": max_entries,
            },
        }
    }
