# ruff: noqa: E501
from corsheaders.defaults import default_headers

from config.cache import build_locmem_cache

from .base import *  # noqa: F403, F401
from .base import CACHE_MIDDLEWARE_KEY_PREFIX
from .base import INSTALLED_APPS
from .base import MIDDLEWARE
from .base import env

# GENERAL
# ------------------------------------------------------------------------------
READ_DOT_ENV_FILE = env.bool("DJANGO_READ_DOT_ENV_FILE", default=True)

DEBUG = True

SECRET_KEY = env(
    "DJANGO_SECRET_KEY",
    default="2nPe1ow3JyyoO6ruwbTRTGO93g0zJBb5eBOXr8GDMuSD5CeX7o17Vi9otWACfhCt",
)

CACHES = build_locmem_cache(
    key_prefix=CACHE_MIDDLEWARE_KEY_PREFIX,
    timeout=env.int("API_CACHE_TIMEOUT", 3600),
)

ALLOWED_HOSTS = env.list(
    "DJANGO_ALLOWED_HOSTS",
    default=[
        "localhost",
        "0.0.0.0",
        "127.0.0.1",
        "airedale-adjusted-hopefully.ngrok-free.app",
        "speed-test-silk.vercel.app",
        "172.16.102.117",
        "calligraphical-chas-micrographically.ngrok-free.dev"
    ]
)

# When CORS_ALLOW_CREDENTIALS is True, you cannot use CORS_ALLOW_ALL_ORIGINS
# Must specify exact origins instead
CORS_ORIGIN_ALLOW_ALL = env.bool("CORS_ORIGIN_ALLOW_ALL", default=False)
CORS_ALLOW_ALL_ORIGINS = env.bool("CORS_ALLOW_ALL_ORIGINS", default=False)

CORS_ALLOWED_ORIGINS = env.list(
    "CORS_ALLOWED_ORIGINS",
    default=[
        "https://calligraphical-chas-micrographically.ngrok-free.dev",
        "http://calligraphical-chas-micrographically.ngrok-free.dev",
        "http://localhost:5173",
        "http://localhost:3000",
    ]
)

CORS_ALLOW_CREDENTIALS = env.bool("CORS_ALLOW_CREDENTIALS", default=True)

CORS_ALLOW_HEADERS = list(default_headers) + [
    'authorization',
    'Authorization',
    'ngrok-skip-browser-warning',
]

INTERNAL_IPS = env.list("INTERNAL_IPS", default=["127.0.0.1", "10.0.2.2"])

# Optional: only installed via requirements-dev.txt. The production image (Dockerfile)
# installs requirements.txt only, so config.settings.local stills boot inside that image
# (e.g. for local docker-compose testing) without this dev-only package present.
try:
    import django_extensions  # noqa: F401
except ImportError:
    pass
else:
    INSTALLED_APPS += ["django_extensions"]

ENABLE_QUERY_COUNTER = env.bool('ENABLE_QUERY_COUNTER', False)

if ENABLE_QUERY_COUNTER:
    MIDDLEWARE.insert(0, 'query_counter.middleware.DjangoQueryCounterMiddleware')
    INSTALLED_APPS += ["query_counter"]
