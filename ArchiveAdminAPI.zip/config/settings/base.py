# ruff: noqa: ERA001, E501
"""Base settings to build other settings files upon."""

import logging
import sys
from pathlib import Path

import environ
from rest_framework.settings import reload_api_settings

BASE_DIR = Path(__file__).resolve(strict=True).parent.parent.parent
logger = logging.getLogger(__name__)

APPS_DIR = BASE_DIR / "api"
env = environ.Env()

READ_DOT_ENV_FILE = env.bool("DJANGO_READ_DOT_ENV_FILE", default=True)
if READ_DOT_ENV_FILE:
    for env_file in ["local.env", ".env"]:
        env_path = BASE_DIR / env_file
        if env_path.exists():
            logger.info(f"Loading environment from {env_file}")
            env.read_env(str(env_path))
            break

# GENERAL
# ------------------------------------------------------------------------------

DEBUG = env.bool("DJANGO_DEBUG", False)
# Local time zone. Choices are
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# though not all of them may be available with every OS.
# In Windows, this must be set to your system time zone.
TIME_ZONE = "UTC"

LANGUAGE_CODE = "en-us"

USE_I18N = True

USE_TZ = True

LOCALE_PATHS = [str(BASE_DIR / "locale")]

# DATABASES
# ------------------------------------------------------------------------------

DATABASES = {
    'default': {
        'ENGINE': 'config.db_backends',
        'NAME': env.str('POSTGRES_DB_NAME', "stratium_users"),
        'USER': env.str('POSTGRES_USER', ''),
        'PASSWORD': env.str('POSTGRES_PASSWORD', ''),
        'HOST': env.str('POSTGRES_HOST', ''),
        'PORT': env.str('POSTGRES_PORT', 5432),
        'OPTIONS': {
            'options': '-c search_path=' + env.str('POSTGRES_DB_SCHEMA', 'public')
        }
    }
}

DATABASES["default"]["ATOMIC_REQUESTS"] = True

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# URLS
# ------------------------------------------------------------------------------

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"


def normalize_api_path_prefix(value):
    return (value or "").strip().strip("/")


API_PATH_PREFIX = normalize_api_path_prefix(env.str("API_PATH_PREFIX", default=""))

# APPS
# ------------------------------------------------------------------------------
DJANGO_APPS = [
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.staticfiles",
    "django.forms",
]
THIRD_PARTY_APPS = [
    "rest_framework",
    "corsheaders",
    "drf_standardized_errors",
    "drf_spectacular",
    "django_countries",
    "django_filters",
]

LOCAL_APPS = [
    "api.tenant",
    "api.user",
    "api.identity",
    "api.authz",
    "api.audit",
    "api.user_setting",
    "api.custom_lists",
    "api.user_feedback",
    "api.info",
]

INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS

# AUTHENTICATION
# ------------------------------------------------------------------------------

AUTH_USER_MODEL = "user.User"

# PASSWORDS
# ------------------------------------------------------------------------------

PASSWORD_HASHERS = [

    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2SHA1PasswordHasher",
    "django.contrib.auth.hashers.BCryptSHA256PasswordHasher",
]

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# MIDDLEWARE
# ------------------------------------------------------------------------------

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "api.cache_middleware.NoCacheMiddleware",
    "api.audit.middleware.AuditLogMiddleware",
    "api.apm_middleware.NewRelicCorrelationMiddleware",
]

# STATIC
# ------------------------------------------------------------------------------

STATIC_ROOT = str(BASE_DIR / "staticfiles")

STATIC_URL = "/static/"

STATICFILES_DIRS = [str(APPS_DIR / "static")]

STATICFILES_FINDERS = [
    "django.contrib.staticfiles.finders.FileSystemFinder",
    "django.contrib.staticfiles.finders.AppDirectoriesFinder",
]

# MEDIA
# ------------------------------------------------------------------------------

MEDIA_ROOT = str(APPS_DIR / "media")

MEDIA_URL = "/media/"

# TEMPLATES
# ------------------------------------------------------------------------------

TEMPLATES = [
    {

        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [str(APPS_DIR / "templates")],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.template.context_processors.i18n",
                "django.template.context_processors.media",
                "django.template.context_processors.static",
                "django.template.context_processors.tz",
            ],
        },
    },
]

FORM_RENDERER = "django.forms.renderers.TemplatesSetting"

# FIXTURES
# ------------------------------------------------------------------------------
FIXTURE_DIRS = (str(APPS_DIR / "fixtures"),)

# SECURITY
# ------------------------------------------------------------------------------
SESSION_COOKIE_HTTPONLY = True
# SPA reads this to echo as X-CSRFToken. The session cookie (the real secret) stays HttpOnly.
CSRF_COOKIE_HTTPONLY = False
X_FRAME_OPTIONS = "DENY"

# LOGGING
# ------------------------------------------------------------------------------

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "{levelname:<8} {asctime} {module} {name} {funcName} {message}",
            "style": "{",
        },
        "colored": {
            "()": "colorlog.ColoredFormatter",
            "format": "{log_color}{levelname:<8} {asctime} {module} {name} {funcName} {reset}{bold_blue}{message}",
            "style": "{",
            "log_colors": {
                "DEBUG": "cyan",
                "INFO": "green",
                "WARNING": "yellow",
                "ERROR": "red",
                "CRITICAL": "bold_red",
            },
        },
    },
    "handlers": {
        "console": {
            "level": "DEBUG",
            "class": "logging.StreamHandler",
            "formatter": "colored" if sys.stdout.isatty() else "verbose",
            "stream": sys.stderr if env.bool("NO_COLOR", default=False) else sys.stdout,
        },
    },
    "root": {
        "level": "INFO",
        "handlers": ["console"],
    },
    # Log Django's SQL queries in debug mode
    "loggers": {
        # "django.db.backends": {
        #     "level": "DEBUG",
        #     "handlers": ["console"],
        #     "propagate": False,
        # },
        "environ.environ": {
            "level": "INFO",
            "handlers": ["console"],
            "propagate": False,
        },
    },
}

# DRF STANDARDIZED_ERRORS
# -------------------------------------------------------------------------------

_API_ERROR_SCHEMA = "api.schema.error_serializers.ApiErrorResponseSerializer"

DRF_STANDARDIZED_ERRORS = {
    "EXCEPTION_FORMATTER_CLASS": "api.exception_formatter.ExceptionFormatter",
    "ENABLE_IN_DEBUG_FOR_UNHANDLED_EXCEPTIONS": True,
    "ERROR_SCHEMAS": {
        "400": _API_ERROR_SCHEMA,
        "401": _API_ERROR_SCHEMA,
        "403": _API_ERROR_SCHEMA,
        "404": _API_ERROR_SCHEMA,
        "405": _API_ERROR_SCHEMA,
        "406": _API_ERROR_SCHEMA,
        "415": _API_ERROR_SCHEMA,
        "429": _API_ERROR_SCHEMA,
        "500": _API_ERROR_SCHEMA,
    },
}

# django-rest-framework
# -------------------------------------------------------------------------------

_AUTH_CLASS = "api.identity.authentication_session.CookieSessionAuthentication"
_PERMISSION_CLASS = "api.identity.permissions.IsPlatformAdmin"

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (_AUTH_CLASS,),
    "EXCEPTION_HANDLER": "drf_standardized_errors.handler.exception_handler",
    "DEFAULT_RENDERER_CLASSES": ("api.success_json_response.SuccessJsonResponse",),
    "DEFAULT_PERMISSION_CLASSES": (_PERMISSION_CLASS,),  # Admin portal: platform admins only
    "DEFAULT_PAGINATION_CLASS": "api.pagination.MaxLimitOffsetPagination",
    "DEFAULT_SCHEMA_CLASS": "api.schema.openapi.EnvelopeAwareAutoSchema",
    "URL_FORMAT_OVERRIDE": None,
}

reload_api_settings(setting='REST_FRAMEWORK')

# drf-spectacular (OpenAPI)
# -------------------------------------------------------------------------------

SPECTACULAR_SETTINGS = {
    "TITLE": "Stratium Admin Portal API",
    "DESCRIPTION": (
        "Platform-admin API for the shared core database (tenants, users, authz, audit).\n\n"
        "**Authentication:** Cookie-session BFF via Entra ID OIDC. "
        "Start at `GET /login/start/`, complete the IdP redirect at `GET /login/`, "
        "then send the session cookie on subsequent requests.\n\n"
        "**Response envelopes:** Successful JSON responses are "
        '`{"success": true, "data": ...}`. Errors are '
        '`{"success": false, "type", "code", "error"}` '
        "(validation errors for a field use `\"<field>: <message>\"`)."
    ),
    "VERSION": env.str("API_VERSION", default="0.1.0"),
    "SERVE_INCLUDE_SCHEMA": False,
    "SERVE_AUTHENTICATION": [_AUTH_CLASS],
    "SERVE_PERMISSIONS": [_PERMISSION_CLASS],
    "ENUM_NAME_OVERRIDES": {
        "ValidationErrorEnum": "drf_standardized_errors.openapi_serializers.ValidationErrorEnum.choices",
        "ClientErrorEnum": "drf_standardized_errors.openapi_serializers.ClientErrorEnum.choices",
        "ServerErrorEnum": "drf_standardized_errors.openapi_serializers.ServerErrorEnum.choices",
        "ErrorCode401Enum": "drf_standardized_errors.openapi_serializers.ErrorCode401Enum.choices",
        "ErrorCode403Enum": "drf_standardized_errors.openapi_serializers.ErrorCode403Enum.choices",
        "ErrorCode404Enum": "drf_standardized_errors.openapi_serializers.ErrorCode404Enum.choices",
        "ErrorCode405Enum": "drf_standardized_errors.openapi_serializers.ErrorCode405Enum.choices",
        "ErrorCode406Enum": "drf_standardized_errors.openapi_serializers.ErrorCode406Enum.choices",
        "ErrorCode415Enum": "drf_standardized_errors.openapi_serializers.ErrorCode415Enum.choices",
        "ErrorCode429Enum": "drf_standardized_errors.openapi_serializers.ErrorCode429Enum.choices",
        "ErrorCode500Enum": "drf_standardized_errors.openapi_serializers.ErrorCode500Enum.choices",
        "UserStatusEnum": "api.user.choices.UserStatus.choices",
        "FeedbackStatusEnum": "api.user_feedback.choices.FeedbackStatus.choices",
    },
    "POSTPROCESSING_HOOKS": [
        "api.schema.hooks.wrap_success_response_envelope",
        "drf_standardized_errors.openapi_hooks.postprocess_schema_enums",
    ],
}


# Entra ID (OIDC) — platform-admin authentication.
ENTRA_TENANT_ID = env.str("ENTRA_TENANT_ID", default=None)
ENTRA_CLIENT_ID = env.str("ENTRA_CLIENT_ID", default=None)
ENTRA_CLIENT_SECRET = env.str("ENTRA_CLIENT_SECRET", default=None)
ENTRA_METADATA_URL = env.str(
    "ENTRA_METADATA_URL",
    default=(
        f"https://login.microsoftonline.com/{ENTRA_TENANT_ID}/v2.0/.well-known/openid-configuration"
        if ENTRA_TENANT_ID else None
    ),
)
ENTRA_JWKS_URI = env.str("ENTRA_JWKS_URI", default=None)
ENTRA_AUTHORIZE_URL = env.str("ENTRA_AUTHORIZE_URL", default=None)
ENTRA_TOKEN_URL = env.str("ENTRA_TOKEN_URL", default=None)
ENTRA_END_SESSION_URL = env.str("ENTRA_END_SESSION_URL", default=None)

# Security-group membership required to use the admin portal. Verified at login
# (token groups claim, with a Graph checkMemberGroups fallback on overage). Unset
# disables the check (dev/test); production.py requires it. Belts-and-suspenders
# over the Entra app-registration group assignment.
ENTRA_REQUIRED_GROUP_ID = env.str("ENTRA_REQUIRED_GROUP_ID", default=None)

FRONTEND_URL = env.str('FRONTEND_URL', default="http://localhost:5173")

OIDC_CALLBACK_URL = env.str('OIDC_CALLBACK_URL', default=None)

SESSION_COOKIE_AGE = 30 * 60
SESSION_IDLE_TIMEOUT_SECONDS = SESSION_COOKIE_AGE
SESSION_ABSOLUTE_TIMEOUT_SECONDS = 8 * 60 * 60
SESSION_SAVE_EVERY_REQUEST = True
SESSION_EXPIRE_AT_BROWSER_CLOSE = False
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SECURE = env.bool('SESSION_COOKIE_SECURE', False)
SESSION_COOKIE_SAMESITE = 'Lax'
SESSION_ENGINE = 'django.contrib.sessions.backends.cache'
SESSION_CACHE_ALIAS = 'default'

CSRF_COOKIE_SECURE = env.bool('CSRF_COOKIE_SECURE', False)
CSRF_COOKIE_SAMESITE = 'Lax'
CSRF_TRUSTED_ORIGINS = env.list('CSRF_TRUSTED_ORIGINS', default=[FRONTEND_URL])

# Calculate cache key prefix (includes API version for isolation between deployments)
CACHE_MIDDLEWARE_SECONDS = env.int("CACHE_MIDDLEWARE_SECONDS", 3600)
CACHE_MIDDLEWARE_KEY_PREFIX = (env.str("CACHE_MIDDLEWARE_KEY_PREFIX", "stratium")
                               + "_" + env.str("API_VERSION", "0.0.1"))

DJANGO_REDIS_LOG_IGNORED_EXCEPTIONS = env.bool(
    "DJANGO_REDIS_LOG_IGNORED_EXCEPTIONS", default=True
)
