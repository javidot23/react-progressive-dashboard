# ruff: noqa: E501
from corsheaders.defaults import default_headers
from django.core.exceptions import ImproperlyConfigured

from config.cache import build_sentinel_cache

from .base import *  # noqa: F403, F401
from .base import CACHE_MIDDLEWARE_KEY_PREFIX
from .base import DATABASES
from .base import ENTRA_REQUIRED_GROUP_ID
from .base import env

CACHES = build_sentinel_cache(
    key_prefix=CACHE_MIDDLEWARE_KEY_PREFIX,
    timeout=env.int("API_CACHE_TIMEOUT", 3600),
    password=env.str("REDIS_PASSWORD"),
    master=env.str("REDIS_SENTINEL_MASTER"),
    sentinel_hosts=env.list("REDIS_SENTINEL_HOSTS"),
    sentinel_port=env.int("REDIS_SENTINEL_PORT", default=26379),
)


if not ENTRA_REQUIRED_GROUP_ID:
    raise ImproperlyConfigured(
        "ENTRA_REQUIRED_GROUP_ID must be set in production so admin-portal login "
        "enforces security-group membership."
    )

if not DATABASES["default"]["HOST"]:
    raise ImproperlyConfigured(
        "POSTGRES_HOST must be set in production. When empty, libpq silently falls "
        "back to a local Unix socket and every request fails with an opaque 500 at "
        "runtime instead of the pod failing fast at startup."
    )

# GENERAL
# ------------------------------------------------------------------------------

SECRET_KEY = env("DJANGO_SECRET_KEY")

# Host/origin allowlists must be provided via env in production (no baked-in defaults).
ALLOWED_HOSTS = env.list("DJANGO_ALLOWED_HOSTS", default=[])

CORS_ALLOWED_ORIGINS = env.list("CORS_ALLOWED_ORIGINS", default=[])
CSRF_TRUSTED_ORIGINS = env.list("CSRF_TRUSTED_ORIGINS", default=[])

CORS_ORIGIN_ALLOW_ALL = env.bool("CORS_ORIGIN_ALLOW_ALL", default=False)
CORS_ALLOW_ALL_ORIGINS = env.bool("CORS_ALLOW_ALL_ORIGINS", default=False)
CORS_ALLOW_CREDENTIALS = True

CORS_ALLOW_HEADERS = list(default_headers)

# Cookie-session BFF: require Secure cookies on HTTPS deployments.
SESSION_COOKIE_SECURE = env.bool("SESSION_COOKIE_SECURE", default=True)
CSRF_COOKIE_SECURE = env.bool("CSRF_COOKIE_SECURE", default=True)

# TLS terminates at the proxy (nginx / ACA); tell Django the original scheme.
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
SECURE_HSTS_SECONDS = env.int("SECURE_HSTS_SECONDS", default=31536000)
SECURE_HSTS_INCLUDE_SUBDOMAINS = env.bool("SECURE_HSTS_INCLUDE_SUBDOMAINS", default=True)
SECURE_HSTS_PRELOAD = env.bool("SECURE_HSTS_PRELOAD", default=False)
# Opt-in only — proxy already redirects HTTP→HTTPS; enabling this can break probes.
SECURE_SSL_REDIRECT = env.bool("SECURE_SSL_REDIRECT", default=False)

# DATABASES
# ------------------------------------------------------------------------------
DATABASES["default"]["CONN_MAX_AGE"] = env.int("CONN_MAX_AGE", default=60)
DATABASES["default"]["CONN_HEALTH_CHECKS"] = True

# LOGGING
# ------------------------------------------------------------------------------
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "filters": {"require_debug_false": {"()": "django.utils.log.RequireDebugFalse"}},
    "formatters": {
        "verbose": {
            "format": "{levelname:<8} {asctime} {module} {name} {funcName} {message}",
            "style": "{",
        },
        "simple": {
            "format": "{levelname} {message}",
            "style": "{",
        },
    },
    "handlers": {
        "console": {
            "level": "DEBUG",
            "class": "logging.StreamHandler",
            "formatter": "verbose",
        },
    },
    "root": {"level": "INFO", "handlers": ["console"]},
    "loggers": {
        # Silence noisy Azure SDK token refresh logs
        "azure.identity": {
            "level": "WARNING",
            "handlers": ["console"],
            "propagate": False,
        },
        "azure.core": {
            "level": "WARNING",
            "handlers": ["console"],
            "propagate": False,
        },
    },
}

DEBUG = False
