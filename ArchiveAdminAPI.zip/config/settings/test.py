"""
With these settings, tests run faster.
"""

from .base import *  # noqa: F403, F401
from .base import TEMPLATES
from rest_framework.settings import reload_api_settings
from .base import env

SECRET_KEY = env(
    "DJANGO_SECRET_KEY",
    default="1b5yX8xq6lmjjYXUaB3sojBgltrMDYbTjMe9cNbD9zVGYuAwbH27AU3LweRWylDl",
)

# TestAutoAuthentication is rejected at boot when DEBUG=False.
DEBUG = True

TEST_RUNNER = "django.test.runner.DiscoverRunner"

# Mirror the deployed routing so generated URLs/OpenAPI paths are /api/... in tests.
API_PATH_PREFIX = "api"

PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]

EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"

TEMPLATES[0]["OPTIONS"]["debug"] = True  # type: ignore[index]

MEDIA_URL = "http://media.testserver/"

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "api.identity.authentication_session.CookieSessionAuthentication",
        "tests.authentication.TestAutoAuthentication",
    ),
    "EXCEPTION_HANDLER": "drf_standardized_errors.handler.exception_handler",
    "DEFAULT_RENDERER_CLASSES": ("api.success_json_response.SuccessJsonResponse",),
    "DEFAULT_PERMISSION_CLASSES": ("api.identity.permissions.IsPlatformAdmin",),
    "DEFAULT_PAGINATION_CLASS": "api.pagination.MaxLimitOffsetPagination",
    "DEFAULT_SCHEMA_CLASS": "api.schema.openapi.EnvelopeAwareAutoSchema",
    "PAGE_SIZE": 1,
    "URL_FORMAT_OVERRIDE": None,
}

CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.dummy.DummyCache",
    }
}

# Cookie-signed sessions need no cache/table, so tests can persist a session across
# requests without the (removed) django_session table or a real cache backend.
SESSION_ENGINE = "django.contrib.sessions.backends.signed_cookies"

reload_api_settings(setting='REST_FRAMEWORK')
