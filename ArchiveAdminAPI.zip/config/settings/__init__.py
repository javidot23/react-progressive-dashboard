import os
import sys
from pathlib import Path


def get_settings_module():
    # If DJANGO_SETTINGS_MODULE is explicitly set and points to a specific file, use it
    settings_module = os.environ.get('DJANGO_SETTINGS_MODULE', '')
    if settings_module and settings_module != 'config.settings':
        print("Using explicit DJANGO_SETTINGS_MODULE:", settings_module)
        return settings_module.split('.')[-1]

    base_dir = Path(__file__).parent.parent.parent
    # Check if we're in development
    if (
        os.path.exists(base_dir / "local.env") or
        os.getenv("ENVIRONMENT") == "local" or
        os.getenv("DEBUG") == "True"
    ):
        print("Using LOCAL settings")
        return "local"

    print("Using PRODUCTION settings")
    return "production"


# Only import if we haven't already been imported
if not hasattr(sys.modules[__name__], '_settings_loaded'):
    settings_env = get_settings_module()
    if settings_env == "local":
        from .local import *  # noqa
    elif settings_env == "test":
        from .test import *  # noqa
    else:
        from .production import *  # noqa

    # Mark that we've loaded settings
    _settings_loaded = True
