# Stratium Admin Portal API

Django REST API that owns and manages the **shared "core" database** — tenants, users, tenant
memberships, roles, permissions, entitlements, and audit — for a single-tenant-aware SaaS
deployment. It is the admin portal used by internal platform admins (authenticated via **Entra
ID**) to provision and manage those objects. The customer-facing product API is a separate
project that consumes this same database read-mostly (`managed=False` mirror models) plus a
narrow provisioning write path.

## Architecture

```
Entra ID / BFF cookie ──▶ Admin portal (THIS PROJECT) ──▶ shared core DB (owns all migrations)
SAP CDC  / BFF cookie ──▶ Product API service          ──▶ shared core DB (managed=false reads + narrow writes)
                                                        └─▶ per-tenant app DBs
```

- **Single PostgreSQL database** (`stratium_users` locally). No database router.
- **Entra ID (OIDC)** platform-admin auth via a cookie-session BFF; admins are JIT-provisioned on
  first login. Tenant end-users are never auto-created here — they are invited (pending) and
  linked by the product API on their first SAP-CDC login.
- **Catalog vs assignment split** (the core invariant): `Role`/`Permission`/`RolePermission` are
  a developer-owned catalog — their existence, codes, and grants are seeded via data migrations
  (no create/delete, no grant editing). Ops may only PATCH presentation fields + `is_active` on
  existing roles/permissions/resources. `UserRole`/`EntitlementResource`/`TenantMembership` are the
  ops-owned CRUD surface.

## Local setup

Requires Python 3.12 and a local PostgreSQL. Redis is optional.

```bash
# 1. Dependencies
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. Local Postgres + Redis (compose has no app container — you run Django on the host)
docker compose up -d
createdb stratium_users            # or: psql -U postgres -c "CREATE DATABASE stratium_users;"

# 3. Env — copy the template and fill it in, then load it
cp example.env dev.env
source dev.env

# 4. Schema + mock data
python manage.py migrate
./scripts/dev/fake_data.sh          # tenants, users, authz catalog, settings

# 5. Run
python manage.py runserver
```

`source dev.env` (or having a `local.env` file) is required before any `manage.py` command —
it provides the DB credentials and settings module.

## Database

A single PostgreSQL database holds the entire schema (locally `stratium_users`). There is **no
database router** — every app's models live in `default`. Beyond the domain tables it contains only
`django_migrations` and Django's stock `auth`/`contenttypes` metadata; `admin`, `sessions` (cache
backend), `sites`, and `authtoken` tables are intentionally absent.

**Managed identity in Azure:** `config/db_backends` is a thin Postgres backend that, when
`DB_USE_MANAGED_IDENTITY=true`, fetches an AAD access token via a User Managed Identity
(`AZURE_DB_MANAGED_IDENTITY_CLIENT_ID`) and uses it as the DB password — so no DB password is stored
in production. Locally, leave `DB_USE_MANAGED_IDENTITY` unset and use `POSTGRES_PASSWORD`.

### Local development database

    docker compose up -d                      # Postgres only
    docker compose --profile cache up -d      # + Redis
    docker compose --profile tools up -d      # + pgAdmin on http://localhost:5050

Export the matching settings before running the test suite:

    export POSTGRES_DB_NAME=stratium_users
    export POSTGRES_USER=postgres
    export POSTGRES_PASSWORD=admin
    export POSTGRES_HOST=localhost
    export POSTGRES_PORT=5432
    export POSTGRES_DB_SCHEMA=public
    export DJANGO_READ_DOT_ENV_FILE=false

    pytest

`POSTGRES_HOST` must be set. When empty, psycopg falls back to a local Unix
socket and every test fails with `connection to server on socket
"/tmp/.s.PGSQL.5432" failed`.

Tear down, including data:

    docker compose --profile cache --profile tools down -v

## Authentication & sessions

Cookie-session BFF auth via **Entra ID (OIDC)** (`api/identity/`):

1. `GET /login/start/` redirects the browser to Entra.
2. Entra returns to `GET /login/` (must match `OIDC_CALLBACK_URL` on the app registration).
3. Group membership is verified (`ENTRA_REQUIRED_GROUP_ID`) and the platform admin is
   **JIT-provisioned** (`User(is_platform_admin=True)` + `UserIdentity(auth_provider="entra_id")`).
4. A Django session cookie is set; the SPA sends it on every request. Entra tokens are dropped
   (only `id_token` is kept for RP-initiated logout via `POST /logout/`).

**Access gate:** the Entra app registration must require security-group assignment (only members
get a token). As defense-in-depth, login also verifies `ENTRA_REQUIRED_GROUP_ID` against the token
`groups` claim, with a Microsoft Graph `checkMemberGroups` fallback on a groups overage
(`api/identity/groups.py`). This setting is **required in production** (the server refuses to boot
without it) and unset in dev/test. Every endpoint additionally requires `IsPlatformAdmin`.

**Session lifecycle** — two independent timers:
- **Idle timeout: 30 minutes** (`SESSION_COOKIE_AGE`), sliding — each authenticated request resets
  it (`SESSION_SAVE_EVERY_REQUEST`). 30 min with no requests → 401 → SPA redirects to login.
- **Absolute cap: 8 hours** (`SESSION_ABSOLUTE_TIMEOUT_SECONDS`), fixed at login, enforced in
  `CookieSessionAuthentication` regardless of activity.

A user stays logged in until 30 min of inactivity or 8 hours total, whichever comes first.

**Tests:** `tests.authentication.TestAutoAuthentication` (test settings only; rejected at boot
when `DEBUG=False`) bypasses the IdP and authenticates as a deterministic platform admin. Send
header `X-Disable-Test-Auth: 1` to exercise unauthenticated (401) flows.

## RBAC, entitlements & the catalog

Two independent access-control axes, both stored here and enforced by the **product API** at
request time (this portal only manages the data):

- **RBAC (per user, per tenant):** `User → UserRole (in a tenant) → Role → RolePermission →
  Permission → Resource`.
- **Entitlement (per tenant, by tier):** `Tenant.entitlement_tier → EntitlementResource →
  Resource`. Gates which resources a tenant has unlocked at all.

Effective access requires **both** to agree.

**Catalog is seed-only.** `Role`, `Permission`, `RolePermission`, and `Resource` — their existence,
`*_code`s, and role→permission grants — are created **only** via data migrations, shipped in lockstep
with the product-API release that enforces them (`api/authz/migrations/0002_seed_catalog.py`). There
are no create/delete endpoints and no grant editing. To add a role or resource:

```python
# api/authz/migrations/0003_seed_<something>.py  (RunPython, idempotent)
def seed(apps, schema_editor):
    Role = apps.get_model("authz", "Role")
    Resource = apps.get_model("authz", "Resource")
    Permission = apps.get_model("authz", "Permission")
    RolePermission = apps.get_model("authz", "RolePermission")

    res, _ = Resource.objects.update_or_create(
        resource_code="orders_page",
        defaults={"resource_name": "Orders", "resource_type": "page"},
    )
    perm, _ = Permission.objects.update_or_create(
        permission_code="orders.manage",
        defaults={"resource": res, "permission_type": "manage", "permission_name": "Manage orders"},
    )
    role = Role.objects.get(role_code="tenant_admin")
    RolePermission.objects.update_or_create(role=role, permission=perm, defaults={"is_active": True})
```

Then `python manage.py makemigrations`/`migrate`. The `*_code` values are the cross-repo contract —
coordinate them with the product API.

**What ops CAN do via the API:**
- Manage *presentation* of existing catalog entries: `PATCH /authz/roles|permissions|resources/{uuid}/`
  edits only display fields + `is_active` (codes and grants stay locked; a system role can't be
  deactivated).
- Assign roles: `POST /authz/user-roles/` (a picker over existing `Role`s — never free text).
- Remap entitlements: `POST /authz/entitlement-resources/` (tier → existing resource).
- Manage tenant memberships and tenant plain fields (including `entitlement_tier`, `is_federated`).
- Grant all-tenant access (`User.tenant_access_scope`); eligibility domains are
  `INTERNAL_EMAIL_DOMAINS` in `api/user/choices.py`.

## Auditing

`AuditLog` (`api/audit/`) is the durable, high-signal trail of security-relevant facts. It is
**shared with the product API** — both services write to it, tagged by `source`.

**What is audited:** security-relevant *changes* and auth/access decisions — login success/failure,
role assign/revoke, membership and entitlement changes, user status changes, tenant config changes.
**What is not:** routine reads / GETs / list traffic (that belongs in app logs / APM, not the audit
table — auditing every fetch would bury the signal and hurt write throughput).

**How it's written — two paths:**
- **Middleware** (`AuditLogMiddleware`): a coarse backstop. It logs only *successful mutating*
  requests (POST/PUT/PATCH/DELETE, 2xx/3xx); reads are skipped entirely. It classifies a request
  into an `AuditEventType` via `_PATH_EVENTS` (a small `path-prefix → event` map in
  `api/audit/services.py`) — because `audit_event_type` is a bounded enum, a request that doesn't
  match a known prefix is **not** logged.
- **Explicit** (`AuditService.record(...)`): precise events emitted at the call site with actor,
  tenant, `target_entity`, and before/after state — e.g. login events in `LoginView`. This is the
  preferred path for high-value events; the middleware map is a low-fidelity catch-all.

`AuditService` is the single write path; nothing else inserts into `audit_log`. Failures there are
caught and logged, never breaking the underlying request.

## Tests & lint

```bash
pytest .                                            # pytest.ini sets config.settings.test
DJANGO_SETTINGS_MODULE=config.settings.test pytest api/tenant/
flake8 api config tests                             # max-line-length 120
```

The test runner creates its own DB and runs migrations (including the catalog seed) automatically.

## Migrations

Schema is deployed through the ORM — `manage.py migrate` runs in every environment (no raw SQL):

```bash
python manage.py makemigrations <app>
python manage.py migrate
```

## Endpoint map

Paths are relative to `API_PATH_PREFIX`. The default is **empty** (so `/login/`,
`/tenants/`, ...); deployments set it explicitly — the Helm chart defaults it to
`api`, giving `/api/...`.

`/info/` is additionally mounted *outside* the prefix and always resolves at
`/info/` regardless of configuration. This is what the Kubernetes liveness,
readiness and startup probes target, so it must not be moved or made
prefix-dependent.

```
/api/                                        # Base endpoint
    └── login/start/                         # Endpoint
    └── login/                               # Endpoint
    └── logout/                              # Endpoint
/api/auth/                                   # Base endpoint
        └── me/                              # Endpoint
        └── active-tenant/                   # Endpoint
/api/tenants/                                # Base endpoint
        └── [root]                           # Endpoint
        └── <uuid:tenant_uuid>/              # Endpoint
        └── <uuid:tenant_uuid>/memberships/  # Endpoint
        └── <uuid:tenant_uuid>/memberships/<uuid:membership_uuid>/  # Endpoint
        └── <uuid:tenant_uuid>/domains/      # Endpoint
        └── <uuid:tenant_uuid>/domains/<uuid:domain_uuid>/  # Endpoint
/api/users/                                  # Base endpoint
        └── [root]                           # Endpoint
        └── invite/                          # Endpoint
        └── internal/                        # Endpoint
        └── <uuid:user_uuid>/                # Endpoint
        └── <uuid:user_uuid>/tenant-access-scope/  # Endpoint
        └── <uuid:user_uuid>/memberships/    # Endpoint
/api/authz/                                  # Base endpoint
        └── roles/                           # Endpoint
        └── roles/<uuid:role_uuid>/          # Endpoint
        └── permissions/                     # Endpoint
        └── permissions/<uuid:permission_uuid>/  # Endpoint
        └── resources/                       # Endpoint
        └── resources/<uuid:resource_uuid>/  # Endpoint
        └── user-roles/                      # Endpoint
        └── user-roles/<uuid:user_role_uuid>/  # Endpoint
        └── entitlement-resources/           # Endpoint
        └── entitlement-resources/<int:entitlement_resource_id>/  # Endpoint
/api/audit/                                  # Base endpoint
        └── logs/                            # Endpoint
/api/user-setting/                           # Base endpoint
        └── me/                              # Endpoint
/api/user-feedback/                          # Base endpoint
        └── [root]                           # Endpoint
        └── filters/                         # Endpoint
        └── <int:feedback_id>/               # Endpoint
/api/info/                                   # Base endpoint
        └── [root]                           # Endpoint
        └── diagnostics/                     # Endpoint
    └── schema/                              # Endpoint
    └── schema/swagger-ui/                   # Endpoint
    └── schema/redoc/                        # Endpoint
/info/                                       # Base endpoint
    └── [root]                               # Endpoint
    └── diagnostics/                         # Endpoint
```

## Postman collection

`postman/` contains a ready-to-use collection and environment:
- `Stratium Admin Portal API.postman_collection.json` — requests grouped by area.
- `Local.postman_environment.json` — variables (e.g. `base_url`) for local runs.

Import both into Postman and select the **Local** environment. Auth is cookie-session: hit the
login flow in a browser (Postman follows redirects to Entra), or run tests against a server started
with `config.settings.test` where `TestAutoAuthentication` authenticates automatically. CSRF is
enforced on writes — send the `X-CSRFToken` header (value from the `csrftoken` cookie) on
POST/PUT/PATCH/DELETE.

## Environment variables

| Var | Purpose |
|---|---|
| `POSTGRES_DB_NAME` / `POSTGRES_USER` / `POSTGRES_PASSWORD` / `POSTGRES_HOST` / `POSTGRES_PORT` / `POSTGRES_DB_SCHEMA` | Shared core database |
| `DB_USE_MANAGED_IDENTITY` / `AZURE_DB_MANAGED_IDENTITY_CLIENT_ID` | Use an Azure UMI (not a password) for DB auth in production |
| `ENTRA_TENANT_ID` / `ENTRA_CLIENT_ID` / `ENTRA_CLIENT_SECRET` | Entra ID OIDC client |
| `ENTRA_METADATA_URL` / `ENTRA_JWKS_URI` / `ENTRA_END_SESSION_URL` | OIDC discovery / logout (optional; metadata defaults from tenant id) |
| `ENTRA_REQUIRED_GROUP_ID` | Security group required to log in; verified at login (Graph fallback on overage). **Required in production**, unset disables the check (dev/test) |
| `OIDC_CALLBACK_URL` | Must match the Entra redirect allowlist (e.g. `http://localhost:8000/api/login/`) |
| `FRONTEND_URL` | SPA origin for post-login/logout redirect |
| `REDIS_PASSWORD` | Required in production for Sentinel Redis (sessions/cache) |
| `REDIS_SENTINEL_MASTER` / `REDIS_SENTINEL_HOSTS` | Sentinel master set name and sentinel hosts. **Required in production** (no defaults — a wrong value fails discovery silently) |
| `REDIS_SENTINEL_PORT` | Sentinel port (default `26379`) |
| `DJANGO_ALLOWED_HOSTS` / `CORS_ALLOWED_ORIGINS` / `CSRF_TRUSTED_ORIGINS` | Host/origin allowlists (required in production) |
| `API_PATH_PREFIX` / `API_VERSION` / `API_COMMIT_SHA` / `API_ENV` | Routing prefix and info endpoint metadata |

## Response format

Success payloads are wrapped as `{"success": true, "data": ...}`; errors as
`{"success": false, "type", "code", "error"}`. Every endpoint requires authentication + platform
admin by default (a system check enforces auth is not disabled; public exceptions are listed in
`config/checks.py`).

OpenAPI docs (same envelopes) are at `/api/schema/`, `/api/schema/swagger-ui/`, and
`/api/schema/redoc/` (paths respect `API_PATH_PREFIX`). Schema and UI endpoints require a
platform-admin session cookie.
