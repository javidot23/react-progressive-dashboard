from django_filters import rest_framework as filters

from .models import AuditLog


class AuditLogFilter(filters.FilterSet):
    event_timestamp_after = filters.IsoDateTimeFilter(field_name="event_timestamp", lookup_expr="gte")
    event_timestamp_before = filters.IsoDateTimeFilter(field_name="event_timestamp", lookup_expr="lte")

    class Meta:
        model = AuditLog
        fields = ["tenant", "actor_user", "audit_event_type"]
