from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics
from rest_framework.filters import OrderingFilter

from .filters import AuditLogFilter
from .models import AuditLog
from .serializers import AuditLogSerializer


class AuditLogListView(generics.ListAPIView):
    serializer_class = AuditLogSerializer
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = AuditLogFilter
    ordering_fields = ["event_timestamp", "audit_event_type"]
    ordering = ["-event_timestamp"]

    def get_queryset(self):
        return (
            AuditLog.objects
            .select_related("tenant", "actor_user")
            .prefetch_related("actor_user__identities")
            .order_by("-event_timestamp")
        )
