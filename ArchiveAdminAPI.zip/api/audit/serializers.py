from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from api.tenant.models import Tenant
from api.user.models import User

from .models import AuditLog


class AuditActorSerializer(serializers.ModelSerializer):
    email = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ["user_uuid", "display_name", "first_name", "last_name", "email"]

    @extend_schema_field(serializers.EmailField(allow_null=True))
    def get_email(self, obj) -> str | None:
        primary = None
        first = None
        for identity in obj.identities.all():
            if first is None:
                first = identity
            if identity.is_primary:
                primary = identity
                break
        chosen = primary or first
        return chosen.email if chosen else None


class AuditTenantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tenant
        fields = ["tenant_uuid", "tenant_code", "tenant_name"]


class AuditLogSerializer(serializers.ModelSerializer):
    actor_user = AuditActorSerializer(read_only=True, allow_null=True)
    tenant = AuditTenantSerializer(read_only=True, allow_null=True)

    class Meta:
        model = AuditLog
        fields = [
            "audit_log_uuid", "tenant", "actor_user", "audit_event_type",
            "trace_id", "source", "reason_code", "request_id", "source_ip",
            "target_entity", "action", "metadata", "before_state", "after_state",
            "event_timestamp",
        ]
