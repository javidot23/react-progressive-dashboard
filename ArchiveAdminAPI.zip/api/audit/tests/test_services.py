from django.urls import reverse
from rest_framework import status

from api.audit.choices import AuditEventType
from api.audit.models import AuditLog
from api.audit.services import AuditService
from tests.BaseTestCase import BaseAPITestCase, BaseTestCase
from tests.factories import create_admin_user, create_tenant


class AuditServiceTest(BaseTestCase):
    def test_record_creates_row(self):
        user = create_admin_user()
        log = AuditService.record(AuditEventType.LOGIN_SUCCESS, actor_user=user, source="admin_portal")
        self.assertEqual(AuditLog.objects.count(), 1)
        self.assertEqual(log.actor_user, user)
        self.assertEqual(log.audit_event_type, AuditEventType.LOGIN_SUCCESS)


class AuditLogListTest(BaseAPITestCase):
    def test_list_nests_actor_and_tenant(self):
        user = create_admin_user(email="auditor@cencora.com")
        tenant = create_tenant()
        AuditService.record(
            AuditEventType.LOGIN_SUCCESS,
            actor_user=user,
            tenant=tenant,
            source="admin_portal",
        )
        self.client.force_authenticate(user=user, token="test")

        response = self.client.get(reverse("audit:audit-log-list"))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json().get("data", response.json())
        row = data["results"][0]
        self.assertEqual(row["actor_user"]["user_uuid"], str(user.pk))
        self.assertEqual(row["actor_user"]["display_name"], user.display_name)
        self.assertEqual(row["actor_user"]["email"], "auditor@cencora.com")
        self.assertEqual(row["tenant"]["tenant_uuid"], str(tenant.pk))
        self.assertEqual(row["tenant"]["tenant_code"], tenant.tenant_code)


class AuditMiddlewareTest(BaseAPITestCase):
    def test_mutating_request_is_recorded(self):
        user = create_admin_user()
        self.client.force_authenticate(user=user, token="test")
        create_tenant()  # give the list something, though POST is what we audit

        resp = self.client.post(
            reverse("tenant:tenant-list"),
            {"tenant_code": "AUD-1", "tenant_name": "Audited", "tenant_type": "customer"},
            format="json",
        )
        self.assertEqual(resp.status_code, status.HTTP_201_CREATED)
        self.assertTrue(
            AuditLog.objects.filter(audit_event_type=AuditEventType.TENANT_UPDATED).exists()
        )
