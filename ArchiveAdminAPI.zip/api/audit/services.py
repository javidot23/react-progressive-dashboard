import logging
from typing import Optional

from django.conf import settings

from .choices import AuditEventType
from .models import AuditLog

logger = logging.getLogger(__name__)

_PATH_EVENTS = [
    ("tenants", AuditEventType.TENANT_UPDATED),
    ("users", AuditEventType.USER_UPDATED),
    ("authz/user-roles", AuditEventType.ROLE_ASSIGNED),
]


class AuditService:
    """Single write path for the ``audit_log`` table."""

    @staticmethod
    def record(
        audit_event_type: str,
        actor_user=None,
        tenant=None,
        *,
        source: str = "",
        reason_code: str = "",
        request_id: str = "",
        trace_id: str = "",
        source_ip: Optional[str] = None,
        target_entity: Optional[dict] = None,
        action: Optional[dict] = None,
        metadata: Optional[dict] = None,
        before_state: Optional[dict] = None,
        after_state: Optional[dict] = None,
    ) -> AuditLog:
        return AuditLog.objects.create(
            audit_event_type=audit_event_type,
            actor_user=actor_user,
            tenant=tenant,
            source=source,
            reason_code=reason_code,
            request_id=request_id,
            trace_id=trace_id,
            source_ip=source_ip,
            target_entity=target_entity or {},
            action=action or {},
            metadata=metadata or {},
            before_state=before_state or {},
            after_state=after_state or {},
        )

    @staticmethod
    def _client_ip(request) -> Optional[str]:
        forwarded = request.META.get("HTTP_X_FORWARDED_FOR", "")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR")

    @staticmethod
    def _event_for(request) -> Optional[str]:
        path = request.path.strip("/")
        prefix = getattr(settings, "API_PATH_PREFIX", "")
        if prefix and path.startswith(f"{prefix}/"):
            path = path[len(prefix) + 1:]
        if request.method == "DELETE" and path.startswith("authz/user-roles"):
            return AuditEventType.ROLE_REVOKED
        for segment, event in _PATH_EVENTS:
            if path.startswith(segment):
                return event
        return None

    @classmethod
    def record_request(cls, request, response) -> Optional[AuditLog]:
        event = cls._event_for(request)
        if event is None:
            return None

        actor = getattr(request, "user", None)
        if actor is None or not getattr(actor, "is_authenticated", False) or not hasattr(actor, "user_uuid"):
            actor = None

        tenant = None
        tenant_uuid = getattr(request, "session", {}) and request.session.get("active_tenant_uuid")
        if tenant_uuid:
            from api.tenant.models import Tenant
            tenant = Tenant.objects.filter(pk=tenant_uuid).first()

        return cls.record(
            event,
            actor_user=actor,
            tenant=tenant,
            source="admin_portal",
            request_id=request.META.get("HTTP_X_REQUEST_ID", ""),
            trace_id=request.META.get("HTTP_X_TRACE_ID", ""),
            source_ip=cls._client_ip(request),
            action={"method": request.method, "path": request.path, "status": response.status_code},
        )
