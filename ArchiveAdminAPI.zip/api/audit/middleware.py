import logging

logger = logging.getLogger(__name__)


class AuditLogMiddleware:
    """Records mutating admin-portal requests to the ``audit_log`` table.

    Reads flow through untouched; state-changing requests (POST/PUT/PATCH/DELETE)
    that resolve to an authenticated actor are recorded via ``AuditService``.
    """

    SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "TRACE"})

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        if request.method in self.SAFE_METHODS:
            return response
        if not (200 <= response.status_code < 400):
            return response

        try:
            from .services import AuditService
            AuditService.record_request(request, response)
        except Exception:
            logger.exception("Failed to write audit log for %s %s", request.method, request.path)

        return response
