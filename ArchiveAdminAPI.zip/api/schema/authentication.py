from django.conf import settings

from drf_spectacular.extensions import OpenApiAuthenticationExtension


class CookieSessionAuthenticationScheme(OpenApiAuthenticationExtension):
    target_class = "api.identity.authentication_session.CookieSessionAuthentication"
    name = "cookieAuth"

    def get_security_definition(self, auto_schema):
        return {
            "type": "apiKey",
            "in": "cookie",
            "name": settings.SESSION_COOKIE_NAME,
            "description": (
                "Django session cookie established by the Entra ID OIDC BFF login "
                "flow (GET /login/start/ → IdP → GET /login/)."
            ),
        }


class TestAutoAuthenticationScheme(OpenApiAuthenticationExtension):
    """Documented as unused; present so test settings do not warn on schema generation."""

    target_class = "tests.authentication.TestAutoAuthentication"
    name = "testAutoAuth"

    def get_security_definition(self, auto_schema):
        return {
            "type": "apiKey",
            "in": "header",
            "name": "X-Disable-Test-Auth",
            "description": (
                "Test-only authenticator. Send header value `1` to disable it and "
                "exercise unauthenticated flows."
            ),
        }
