"""Attach Stratium build context to New Relic APM transactions.

The admin portal's browser agent and this service are separate New Relic
entities. Distributed tracing already links a browser interaction to the API
transaction it triggered; these custom attributes make both sides filterable by
the same build and environment, which is what turns that link into usable
full-stack visibility.

Every agent call here is a no-op when no transaction is active. Local runs,
tests, management commands and the Helm migration Job all start without the
``newrelic-admin`` wrapper, so this middleware costs nothing when APM is off.
"""

from __future__ import annotations

import os

from newrelic.agent import add_custom_attributes, set_user_id

# Constant for the life of the process: these are baked in as image build args.
#
# The environment comes from NEW_RELIC_ENVIRONMENT rather than API_ENV so it
# always matches the `environment` label on the entity. API_ENV is not a
# reliable source: the nonprod cluster inherited API_ENV=test from the release
# kit, so filtering on it would not line up with the New Relic entity at all.
_BUILD_ATTRIBUTES: list[tuple[str, str]] = [
    ("stratium.service", "stratium-admin-api"),
    ("stratium.environment", os.environ.get("NEW_RELIC_ENVIRONMENT", "")),
    ("stratium.version", os.environ.get("API_VERSION", "")),
    ("stratium.commitSha", os.environ.get("API_COMMIT_SHA", "")),
]


class NewRelicCorrelationMiddleware:
    """Record build and environment context on the current transaction."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        add_custom_attributes(_BUILD_ATTRIBUTES)

        # The primary key only, never an email or a name. This is enough to
        # follow one operator from a browser session into the API transactions
        # it produced, without putting personal data into New Relic.
        user = getattr(request, "user", None)
        if user is not None and getattr(user, "is_authenticated", False):
            set_user_id(str(user.pk))

        return self.get_response(request)
