import unittest
from decimal import Decimal

from api.user_setting.serializers import UserSettingSerializer


class TestUserSettingSerializer(unittest.TestCase):
    def test_accepts_null_values(self):
        serializer = UserSettingSerializer(data={
            "inbound_service_level_target": None,
            "products_omit_goal": None,
            "risk_threshold": None,
            "days_on_hand": None,
            "inventory_low_range_threshold": None,
            "inventory_high_range_threshold": None,
        })
        self.assertTrue(serializer.is_valid(), serializer.errors)
        self.assertIsNone(serializer.validated_data["inbound_service_level_target"])
        self.assertIsNone(serializer.validated_data["products_omit_goal"])
        self.assertIsNone(serializer.validated_data["risk_threshold"])
        self.assertIsNone(serializer.validated_data["days_on_hand"])
        self.assertIsNone(serializer.validated_data["inventory_low_range_threshold"])
        self.assertIsNone(serializer.validated_data["inventory_high_range_threshold"])

    def test_accepts_bounds_0_to_100(self):
        for field, value in [
            ("inbound_service_level_target", Decimal("0")),
            ("inbound_service_level_target", Decimal("100")),
            ("products_omit_goal", Decimal("0")),
            ("products_omit_goal", Decimal("100")),
            ("days_on_hand", Decimal("0")),
            ("days_on_hand", Decimal("100")),
        ]:
            with self.subTest(field=field, value=value):
                serializer = UserSettingSerializer(data={field: value})
                self.assertTrue(serializer.is_valid(), serializer.errors)

    def test_rejects_out_of_range(self):
        for field, value in [
            ("inbound_service_level_target", Decimal("-1")),
            ("inbound_service_level_target", Decimal("101")),
            ("products_omit_goal", Decimal("-0.1")),
            ("products_omit_goal", Decimal("100.01")),
            ("days_on_hand", Decimal("-0.1")),
            ("days_on_hand", Decimal("100.01")),
        ]:
            with self.subTest(field=field, value=value):
                serializer = UserSettingSerializer(data={field: value})
                self.assertFalse(serializer.is_valid())
                self.assertIn(field, serializer.errors)

    def test_risk_threshold_accepts_valid_values(self):
        for value in [Decimal("0"), Decimal("100"), Decimal("1000000.50")]:
            with self.subTest(value=value):
                serializer = UserSettingSerializer(data={"risk_threshold": value})
                self.assertTrue(serializer.is_valid(), serializer.errors)
                self.assertEqual(
                    serializer.validated_data["risk_threshold"],
                    value
                )

    def test_risk_threshold_rejects_negative(self):
        serializer = UserSettingSerializer(data={"risk_threshold": Decimal("-1")})
        self.assertFalse(serializer.is_valid())
        self.assertIn("risk_threshold", serializer.errors)
