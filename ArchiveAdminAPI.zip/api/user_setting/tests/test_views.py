from django.urls import reverse
from rest_framework import status

from api.user_setting.models import UserSetting
from tests.BaseTestCase import BaseAPITestCase
from tests.factories import create_admin_user


class TestUserSettingView(BaseAPITestCase):
    def setUp(self):
        super().setUp()
        self.url = reverse("user_setting:my-settings")
        self.user = create_admin_user()
        self.client.force_authenticate(user=self.user, token="test-token")

    def test_get_creates_defaults(self):
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        data = resp.json().get("data", resp.json())
        self.assertIn("inbound_service_level_target", data)
        self.assertIn("products_omit_goal", data)
        self.assertIn("risk_threshold", data)
        self.assertIn("days_on_hand", data)
        self.assertIn("inventory_low_range_threshold", data)
        self.assertIn("inventory_high_range_threshold", data)
        self.assertTrue(UserSetting.objects.filter(user_id=self.user).exists())

    def test_put_updates_values(self):
        payload = {"inbound_service_level_target": 25, "products_omit_goal": 35, "days_on_hand": 55,
                   "inventory_low_range_threshold": 11, "inventory_high_range_threshold": 60}
        resp = self.client.put(self.url, payload, content_type="application/json")
        self.assertEqual(resp.status_code, status.HTTP_200_OK)

        settings = UserSetting.objects.get(user_id=self.user)
        self.assertEqual(int(settings.inbound_service_level_target), 25)
        self.assertEqual(int(settings.products_omit_goal), 35)
        self.assertEqual(int(settings.days_on_hand), 55)
        self.assertEqual(int(settings.inventory_low_range_threshold), 11)
        self.assertEqual(int(settings.inventory_high_range_threshold), 60)

    def test_patch_accepts_null(self):
        self.client.put(self.url, {"inbound_service_level_target": 10, "products_omit_goal": 10},
                        content_type="application/json")
        resp = self.client.patch(self.url, {"inbound_service_level_target": None}, content_type="application/json")
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        settings = UserSetting.objects.get(user_id=self.user)
        self.assertIsNone(settings.inbound_service_level_target)
        self.assertEqual(int(settings.products_omit_goal), 10)

    def test_validation_errors(self):
        resp = self.client.put(self.url, {"inbound_service_level_target": 150}, content_type="application/json")
        self.assertEqual(resp.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("inbound_service_level_target", resp.content.decode())

    def test_put_updates_risk_threshold(self):
        payload = {"inbound_service_level_target": 90, "products_omit_goal": 85, "risk_threshold": 50000.50}
        resp = self.client.put(self.url, payload, content_type="application/json")
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        settings = UserSetting.objects.get(user_id=self.user)
        self.assertEqual(float(settings.risk_threshold), 50000.50)

    def test_risk_threshold_rejects_negative(self):
        resp = self.client.put(self.url, {"risk_threshold": -100}, content_type="application/json")
        self.assertEqual(resp.status_code, status.HTTP_400_BAD_REQUEST)
