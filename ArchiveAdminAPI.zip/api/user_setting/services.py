import logging

from django.core.cache import cache

from .models import UserSetting

logger = logging.getLogger(__name__)

CACHE_TIMEOUT_SECONDS = 900


class UserSettingService:
    """Single access point for a user's settings row, with a user-scoped cache."""

    @staticmethod
    def cache_key(user) -> str:
        return f"user_settings:{user.user_uuid}"

    @staticmethod
    def get_or_create(user) -> UserSetting:
        settings_obj, _ = UserSetting.objects.get_or_create(user_id=user)
        return settings_obj

    @classmethod
    def get_cached_data(cls, user):
        return cache.get(cls.cache_key(user))

    @classmethod
    def set_cached_data(cls, user, data) -> None:
        cache.set(cls.cache_key(user), data, timeout=CACHE_TIMEOUT_SECONDS)

    @classmethod
    def invalidate_cache(cls, user) -> None:
        cache.delete(cls.cache_key(user))
        logger.debug("Invalidated user settings cache for user: %s", user.user_uuid)
