import random

from django.core.management.base import BaseCommand

from api.user.models import User
from api.user_setting.models import UserSetting


class Command(BaseCommand):
    help = "Generate fake user settings for users that don't have them yet"

    def add_arguments(self, parser):
        parser.add_argument("--count", type=int, default=20, help="Max users to settle (default: 20)")

    def handle(self, *args, **options):
        count = options["count"]
        created = 0

        for user in User.objects.filter(settings__isnull=True)[:count]:
            UserSetting.objects.create(
                user_id=user,
                is_dark_mode=random.choice([True, False]),
                inbound_service_level_target=random.randint(80, 99),
                products_omit_goal=random.randint(70, 95),
                risk_threshold=random.randint(50, 90),
                days_on_hand=random.randint(60, 120),
            )
            created += 1

        self.stdout.write(self.style.SUCCESS(f"Created settings for {created} users."))
