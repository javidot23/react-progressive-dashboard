import logging

from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.decorators.vary import vary_on_headers
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import UserSettingSerializer
from .services import UserSettingService

logger = logging.getLogger(__name__)


@method_decorator(never_cache, name='dispatch')
@method_decorator(vary_on_headers('Cookie'), name='dispatch')
@extend_schema_view(
    get=extend_schema(responses=UserSettingSerializer),
    put=extend_schema(request=UserSettingSerializer, responses=UserSettingSerializer),
    patch=extend_schema(request=UserSettingSerializer, responses=UserSettingSerializer),
)
class MyUserSettingView(APIView):
    """Retrieve and update the authenticated user's settings."""

    def get(self, request):
        user = request.user

        cached_settings = UserSettingService.get_cached_data(user)
        if cached_settings:
            return Response(cached_settings, status=status.HTTP_200_OK)

        settings_obj = UserSettingService.get_or_create(user)
        settings_data = UserSettingSerializer(settings_obj).data
        UserSettingService.set_cached_data(user, settings_data)
        return Response(settings_data, status=status.HTTP_200_OK)

    def _update(self, request, partial):
        user = request.user
        settings_obj = UserSettingService.get_or_create(user)
        serializer = UserSettingSerializer(
            instance=settings_obj, data=request.data, partial=partial
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        UserSettingService.invalidate_cache(user)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request):
        return self._update(request, partial=False)

    def patch(self, request):
        return self._update(request, partial=True)
