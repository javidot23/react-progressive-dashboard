from django.urls import path

from .views import (
    TenantDetailView,
    TenantDomainDetailView,
    TenantDomainListCreateView,
    TenantListCreateView,
    TenantMembershipDetailView,
    TenantMembershipListCreateView,
)

app_name = "tenant"

urlpatterns = [
    path("", TenantListCreateView.as_view(), name="tenant-list"),
    path("<uuid:tenant_uuid>/", TenantDetailView.as_view(), name="tenant-detail"),
    path(
        "<uuid:tenant_uuid>/memberships/",
        TenantMembershipListCreateView.as_view(),
        name="tenant-membership-list",
    ),
    path(
        "<uuid:tenant_uuid>/memberships/<uuid:membership_uuid>/",
        TenantMembershipDetailView.as_view(),
        name="tenant-membership-detail",
    ),
    path(
        "<uuid:tenant_uuid>/domains/",
        TenantDomainListCreateView.as_view(),
        name="tenant-domain-list",
    ),
    path(
        "<uuid:tenant_uuid>/domains/<uuid:domain_uuid>/",
        TenantDomainDetailView.as_view(),
        name="tenant-domain-detail",
    ),
]
