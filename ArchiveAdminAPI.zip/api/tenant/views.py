from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.utils import OpenApiResponse, extend_schema, extend_schema_view
from rest_framework import generics, status
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView

from .filters import TenantFilter
from .serializers import (
    TenantDomainCreateSerializer,
    TenantDomainSerializer,
    TenantMembershipCreateSerializer,
    TenantMembershipSerializer,
    TenantSerializer,
)
from .services import TenantDomainService, TenantMembershipService, TenantService


class TenantListCreateView(generics.ListCreateAPIView):
    serializer_class = TenantSerializer
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = TenantFilter
    ordering_fields = [
        "tenant_code", "tenant_name", "entitlement_tier", "user_count", "created_at", "updated_at",
    ]
    ordering = ["tenant_code"]

    def get_queryset(self):
        return TenantService.list()

    def perform_create(self, serializer):
        domains = TenantDomainCreateSerializer(
            data=self.request.data.get("domains", []), many=True
        )
        domains.is_valid(raise_exception=True)
        serializer.instance = TenantService.create(
            domains=domains.validated_data, **serializer.validated_data
        )


@extend_schema_view(
    get=extend_schema(responses=TenantSerializer),
    patch=extend_schema(request=TenantSerializer, responses=TenantSerializer),
    delete=extend_schema(responses={204: OpenApiResponse(description="No content")}),
)
class TenantDetailView(APIView):
    def get(self, request, tenant_uuid):
        return Response(TenantSerializer(TenantService.get(tenant_uuid)).data)

    def patch(self, request, tenant_uuid):
        serializer = TenantSerializer(
            TenantService.get(tenant_uuid), data=request.data, partial=True
        )
        serializer.is_valid(raise_exception=True)
        tenant = TenantService.update(tenant_uuid, **serializer.validated_data)
        return Response(TenantSerializer(tenant).data)

    def delete(self, request, tenant_uuid):
        TenantService.soft_delete(tenant_uuid)
        return Response(status=status.HTTP_204_NO_CONTENT)


class TenantMembershipListCreateView(generics.GenericAPIView):
    serializer_class = TenantMembershipSerializer

    def get_queryset(self):
        return TenantMembershipService.list_for_tenant(self.kwargs["tenant_uuid"])

    def get(self, request, tenant_uuid):
        page = self.paginate_queryset(self.get_queryset())
        return self.get_paginated_response(TenantMembershipSerializer(page, many=True).data)

    def post(self, request, tenant_uuid):
        serializer = TenantMembershipCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        membership = TenantMembershipService.add(
            tenant_uuid,
            created_by=request.user,
            **serializer.validated_data,
        )
        return Response(
            TenantMembershipSerializer(membership).data, status=status.HTTP_201_CREATED
        )


@extend_schema_view(
    delete=extend_schema(responses={204: OpenApiResponse(description="No content")}),
)
class TenantMembershipDetailView(APIView):
    def delete(self, request, tenant_uuid, membership_uuid):
        TenantMembershipService.remove(tenant_uuid, membership_uuid)
        return Response(status=status.HTTP_204_NO_CONTENT)


class TenantDomainListCreateView(generics.GenericAPIView):
    serializer_class = TenantDomainSerializer

    def get_queryset(self):
        return TenantDomainService.list_for_tenant(self.kwargs["tenant_uuid"])

    def get(self, request, tenant_uuid):
        page = self.paginate_queryset(self.get_queryset())
        return self.get_paginated_response(TenantDomainSerializer(page, many=True).data)

    def post(self, request, tenant_uuid):
        serializer = TenantDomainCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        domain = TenantDomainService.add(tenant_uuid, **serializer.validated_data)
        return Response(TenantDomainSerializer(domain).data, status=status.HTTP_201_CREATED)


@extend_schema_view(
    delete=extend_schema(responses={204: OpenApiResponse(description="No content")}),
)
class TenantDomainDetailView(APIView):
    def delete(self, request, tenant_uuid, domain_uuid):
        TenantDomainService.remove(tenant_uuid, domain_uuid)
        return Response(status=status.HTTP_204_NO_CONTENT)
