import random

from django.core.management.base import BaseCommand
from faker import Faker

from api.tenant.choices import EntitlementTier, TenantType
from api.tenant.models import Tenant, TenantDomain


class Command(BaseCommand):
    help = "Generate fake tenants"

    def add_arguments(self, parser):
        parser.add_argument("--count", type=int, default=10, help="Number of tenants (default: 10)")

    def handle(self, *args, **options):
        fake = Faker()
        count = options["count"]
        self.stdout.write(f"Creating {count} fake tenants...")

        for _ in range(count):
            name = fake.unique.company()
            tenant = Tenant.objects.create(
                tenant_code=fake.unique.bothify(text="TEN-#####"),
                tenant_name=name,
                tenant_type=random.choice(TenantType.values),
                entitlement_tier=random.choice(EntitlementTier.values),
                database_host=fake.domain_name(),
                database_name=fake.unique.bothify(text="tenant_?????").lower(),
                database_username=fake.unique.bothify(text="dbuser_?????").lower(),
                database_managed_identity_client_id=str(fake.uuid4()),
                is_federated=random.choice([True, False]),
            )
            for _ in range(random.randint(1, 2)):
                TenantDomain.objects.create(tenant=tenant, domain=fake.unique.domain_name())
            self.stdout.write(f"Created tenant: {tenant.tenant_code} ({tenant.tenant_name})")

        self.stdout.write(self.style.SUCCESS(f"Successfully created {count} tenants."))
