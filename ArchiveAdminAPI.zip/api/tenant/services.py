from django.db import transaction
from django.db.models import Count, Q, QuerySet
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework.exceptions import PermissionDenied, ValidationError

from .models import Tenant, TenantDomain, TenantMembership

ACTIVE_TENANT_SESSION_KEY = "active_tenant_uuid"


class TenantService:
    """Single access point for tenant reads and writes."""

    @staticmethod
    def list() -> QuerySet:
        return (
            Tenant.objects.filter(is_deleted=False)
            .annotate(user_count=Count("memberships", filter=Q(memberships__is_active=True)))
            .prefetch_related("domains")
            .order_by("tenant_code")
        )

    @staticmethod
    def get(tenant_uuid) -> Tenant:
        return get_object_or_404(
            Tenant.objects.annotate(
                user_count=Count("memberships", filter=Q(memberships__is_active=True))
            ).prefetch_related("domains"),
            pk=tenant_uuid,
            is_deleted=False,
        )

    @staticmethod
    @transaction.atomic
    def create(domains=None, **data) -> Tenant:
        tenant = Tenant.objects.create(**data)
        seen = set()
        for entry in (domains or []):
            name = (entry.get("domain") or "").strip().lower()
            if name in seen:
                raise ValidationError(f"domains: '{name}' is duplicated.")
            seen.add(name)
            TenantDomain.objects.create(tenant=tenant, domain=name)
        return tenant

    @staticmethod
    def update(tenant_uuid, **data) -> Tenant:
        tenant = TenantService.get(tenant_uuid)
        for field, value in data.items():
            setattr(tenant, field, value)
        tenant.save()
        return tenant

    @staticmethod
    def assert_email_domain_allowed(tenant, email) -> None:
        """Reject unless the email's domain is one of the tenant's allowed domains.

        Requires the tenant to have at least one domain configured.
        """
        allowed = set(tenant.domains.values_list("domain", flat=True))
        if not allowed:
            raise ValidationError(
                "tenant: no allowed domains configured; add a domain before adding users."
            )
        domain = (email or "").rsplit("@", 1)[-1].strip().lower()
        if not domain or domain not in allowed:
            raise ValidationError(f"email: domain '{domain}' is not allowed for this tenant.")

    @staticmethod
    def soft_delete(tenant_uuid) -> None:
        tenant = TenantService.get(tenant_uuid)
        tenant.is_deleted = True
        tenant.is_active = False
        tenant.deleted_at = timezone.now()
        tenant.save(update_fields=["is_deleted", "is_active", "deleted_at", "updated_at"])


class TenantMembershipService:
    """Membership reads/writes plus the session-scoped active-tenant selection."""

    @staticmethod
    def has_all_tenant_access(user) -> bool:
        from api.user.choices import TenantAccessScope

        return user.tenant_access_scope == TenantAccessScope.ALL_TENANTS

    @staticmethod
    def can_access(user, tenant) -> bool:
        if tenant is None or tenant.is_deleted or not tenant.is_active:
            return False
        if TenantMembershipService.has_all_tenant_access(user):
            return True
        return TenantMembership.objects.filter(
            tenant=tenant, user=user, is_active=True
        ).exists()

    @staticmethod
    def list_tenants_for_user(user) -> list:
        if TenantMembershipService.has_all_tenant_access(user):
            return list(
                Tenant.objects.filter(is_deleted=False, is_active=True).order_by("tenant_code")
            )
        return list(
            Tenant.objects.filter(
                is_deleted=False,
                memberships__user=user,
                memberships__is_active=True,
            )
            .distinct()
            .order_by("tenant_code")
        )

    @staticmethod
    def users_with_access(tenant) -> QuerySet:
        from api.user.choices import TenantAccessScope
        from api.user.models import User

        return User.objects.filter(
            Q(
                tenant_memberships__tenant=tenant,
                tenant_memberships__is_active=True,
            )
            | Q(tenant_access_scope=TenantAccessScope.ALL_TENANTS),
            is_deleted=False,
        ).distinct()

    @staticmethod
    def list_for_tenant(tenant_uuid) -> QuerySet:
        return (
            TenantMembership.objects
            .filter(tenant_id=tenant_uuid)
            .select_related("tenant", "user")
            .order_by("-created_at")
        )

    @staticmethod
    def list_for_user(user_uuid) -> QuerySet:
        return (
            TenantMembership.objects
            .filter(user_id=user_uuid)
            .select_related("tenant", "user")
            .order_by("-created_at")
        )

    @staticmethod
    def add(tenant_uuid, user_uuid, created_by=None, **data) -> TenantMembership:
        from api.user.choices import TenantAccessScope
        from api.user.models import User, UserIdentity

        tenant = TenantService.get(tenant_uuid)
        user = get_object_or_404(User, pk=user_uuid, is_deleted=False)
        if user.tenant_access_scope == TenantAccessScope.ALL_TENANTS:
            raise ValidationError("user: all-tenant access; membership not applicable.")
        if TenantMembership.objects.filter(tenant=tenant, user_id=user_uuid).exists():
            raise ValidationError("user: already a member of this tenant.")
        identity = (
            UserIdentity.objects.filter(user_id=user_uuid, is_primary=True).first()
            or UserIdentity.objects.filter(user_id=user_uuid).first()
        )
        TenantService.assert_email_domain_allowed(tenant, identity.email if identity else "")
        return TenantMembership.objects.create(
            tenant=tenant, user_id=user_uuid, created_by=created_by, **data
        )

    @staticmethod
    def remove(tenant_uuid, membership_uuid) -> None:
        from api.user.choices import TenantAccessScope

        membership = get_object_or_404(
            TenantMembership, pk=membership_uuid, tenant_id=tenant_uuid
        )
        if membership.user.tenant_access_scope == TenantAccessScope.ALL_TENANTS:
            raise ValidationError("user: all-tenant access; membership not applicable.")
        membership.delete()

    @staticmethod
    def get_active(user, session):
        tenant_uuid = session.get(ACTIVE_TENANT_SESSION_KEY)
        if not tenant_uuid:
            return None
        tenant = (
            Tenant.objects.filter(pk=tenant_uuid, is_deleted=False)
            .prefetch_related("domains")
            .first()
        )
        if tenant is None or not TenantMembershipService.can_access(user, tenant):
            return None
        return tenant

    @staticmethod
    def set_active(user, session, tenant_uuid) -> Tenant:
        tenant = Tenant.objects.filter(pk=tenant_uuid, is_deleted=False).first()
        if tenant is None:
            raise ValidationError("tenant_uuid: unknown tenant.")
        if not TenantMembershipService.can_access(user, tenant):
            raise PermissionDenied("You are not a member of the requested tenant.")
        session[ACTIVE_TENANT_SESSION_KEY] = str(tenant.pk)
        return tenant


class TenantDomainService:
    """Reads/writes of a tenant's allowed email domains."""

    @staticmethod
    def list_for_tenant(tenant_uuid) -> QuerySet:
        return TenantDomain.objects.filter(tenant_id=tenant_uuid).order_by("domain")

    @staticmethod
    def add(tenant_uuid, domain) -> TenantDomain:
        tenant = TenantService.get(tenant_uuid)
        normalized = (domain or "").strip().lower()
        if TenantDomain.objects.filter(tenant=tenant, domain=normalized).exists():
            raise ValidationError("domain: already registered for this tenant.")
        return TenantDomain.objects.create(tenant=tenant, domain=normalized)

    @staticmethod
    def remove(tenant_uuid, tenant_domain_uuid) -> None:
        tenant_domain = get_object_or_404(
            TenantDomain, pk=tenant_domain_uuid, tenant_id=tenant_uuid
        )
        tenant_domain.delete()
