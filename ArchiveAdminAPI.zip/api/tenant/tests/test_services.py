from rest_framework.exceptions import PermissionDenied, ValidationError

from api.tenant.choices import TenantType
from api.tenant.models import TenantDomain, TenantMembership
from api.tenant.services import (
    ACTIVE_TENANT_SESSION_KEY,
    TenantDomainService,
    TenantMembershipService,
    TenantService,
)
from api.user.choices import TenantAccessScope
from api.user.filters import UserFilter
from api.user.services import UserService
from tests.BaseTestCase import BaseTestCase
from tests.factories import (
    add_domain,
    add_membership,
    create_admin_user,
    create_tenant,
)


class TenantServiceTest(BaseTestCase):
    def test_create_and_get(self):
        tenant = TenantService.create(
            tenant_code="T1", tenant_name="One", tenant_type=TenantType.CUSTOMER
        )
        self.assertEqual(TenantService.get(tenant.pk).tenant_code, "T1")

    def test_is_federated_defaults_false_and_is_settable(self):
        default = TenantService.create(
            tenant_code="T-DEF", tenant_name="Default", tenant_type=TenantType.CUSTOMER
        )
        self.assertFalse(default.is_federated)

        federated = TenantService.create(
            tenant_code="T-FED", tenant_name="Fed", tenant_type=TenantType.CUSTOMER,
            is_federated=True,
        )
        self.assertTrue(federated.is_federated)

    def test_create_with_inline_domains(self):
        tenant = TenantService.create(
            tenant_code="T2", tenant_name="Two", tenant_type=TenantType.CUSTOMER,
            domains=[{"domain": "Two.COM"}, {"domain": "two.io"}],
        )
        domains = {d.domain for d in tenant.domains.all()}
        self.assertEqual(domains, {"two.com", "two.io"})

    def test_create_with_duplicate_inline_domains_rejected(self):
        with self.assertRaises(ValidationError):
            TenantService.create(
                tenant_code="T3", tenant_name="Three", tenant_type=TenantType.CUSTOMER,
                domains=[{"domain": "dup.com"}, {"domain": "DUP.com"}],
            )
        self.assertFalse(TenantService.list().filter(tenant_code="T3").exists())

    def test_list_prefetches_domains(self):
        first = create_tenant(code="T-A")
        second = create_tenant(code="T-B")
        add_domain(first, "a.com")
        add_domain(second, "b.com")
        tenants = list(TenantService.list())
        with self.assertNumQueries(0):
            for tenant in tenants:
                list(tenant.domains.all())

    def test_soft_delete_hides_from_list(self):
        tenant = create_tenant()
        TenantService.soft_delete(tenant.pk)
        tenant.refresh_from_db()
        self.assertTrue(tenant.is_deleted)
        self.assertFalse(tenant.is_active)
        self.assertNotIn(tenant, list(TenantService.list()))

    def test_user_count_counts_active_memberships_only(self):
        tenant = create_tenant()
        active_user = create_admin_user(email="active@cencora.com", subject="s-active")
        inactive_user = create_admin_user(email="inactive@cencora.com", subject="s-inactive")
        add_membership(active_user, tenant, is_active=True)
        add_membership(inactive_user, tenant, is_active=False)

        listed = TenantService.list().get(pk=tenant.pk)
        fetched = TenantService.get(tenant.pk)
        self.assertEqual(listed.user_count, 1)
        self.assertEqual(fetched.user_count, 1)


class TenantMembershipServiceTest(BaseTestCase):
    def setUp(self):
        self.user = create_admin_user(email="staff@cencora.com")
        self.tenant = create_tenant()
        add_domain(self.tenant, "cencora.com")

    def test_add_and_duplicate_rejected(self):
        TenantMembershipService.add(self.tenant.pk, self.user.pk)
        self.assertEqual(TenantMembership.objects.count(), 1)
        with self.assertRaises(ValidationError):
            TenantMembershipService.add(self.tenant.pk, self.user.pk)

    def test_add_rejected_when_user_domain_not_allowed(self):
        outsider = create_admin_user(email="x@notallowed.com", subject="s2")
        with self.assertRaises(ValidationError):
            TenantMembershipService.add(self.tenant.pk, outsider.pk)

    def test_add_rejected_for_all_tenants_user(self):
        internal = create_admin_user(
            email="ops@genpact.com",
            subject="s-ops",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )
        with self.assertRaises(ValidationError):
            TenantMembershipService.add(self.tenant.pk, internal.pk)

    def test_set_active_requires_membership(self):
        session = {}
        with self.assertRaises(PermissionDenied):
            TenantMembershipService.set_active(self.user, session, self.tenant.pk)

        add_membership(self.user, self.tenant)
        tenant = TenantMembershipService.set_active(self.user, session, self.tenant.pk)
        self.assertEqual(tenant.pk, self.tenant.pk)
        self.assertEqual(session[ACTIVE_TENANT_SESSION_KEY], str(self.tenant.pk))

    def test_set_active_allows_all_tenants_user_without_membership(self):
        internal = create_admin_user(
            email="ops@genpact.com",
            subject="s-ops",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )
        session = {}
        tenant = TenantMembershipService.set_active(internal, session, self.tenant.pk)
        self.assertEqual(tenant.pk, self.tenant.pk)

    def test_set_active_unknown_tenant(self):
        import uuid
        with self.assertRaises(ValidationError):
            TenantMembershipService.set_active(self.user, {}, uuid.uuid4())

    def test_users_with_access_includes_all_tenants_scope(self):
        add_membership(self.user, self.tenant)
        internal = create_admin_user(
            email="ops@genpact.com",
            subject="s-ops",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )
        users = list(TenantMembershipService.users_with_access(self.tenant))
        self.assertIn(self.user, users)
        self.assertIn(internal, users)


class TenantDomainServiceTest(BaseTestCase):
    def setUp(self):
        self.tenant = create_tenant(code="T-A")
        self.other = create_tenant(code="T-B")

    def test_add_normalizes_and_lists(self):
        TenantDomainService.add(self.tenant.pk, "Acme.COM")
        domains = TenantDomainService.list_for_tenant(self.tenant.pk)
        self.assertEqual([d.domain for d in domains], ["acme.com"])

    def test_duplicate_within_tenant_rejected(self):
        TenantDomainService.add(self.tenant.pk, "acme.com")
        with self.assertRaises(ValidationError):
            TenantDomainService.add(self.tenant.pk, "acme.com")

    def test_same_domain_allowed_across_tenants(self):
        TenantDomainService.add(self.tenant.pk, "shared.com")
        TenantDomainService.add(self.other.pk, "shared.com")
        self.assertEqual(TenantDomain.objects.filter(domain="shared.com").count(), 2)


class UserTenantFilterTest(BaseTestCase):
    def test_filter_tenant_includes_all_tenants_users(self):
        tenant = create_tenant()
        member = create_admin_user(email="m@cencora.com", subject="s-m")
        add_membership(member, tenant)
        internal = create_admin_user(
            email="ops@genpact.com",
            subject="s-ops",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )
        outsider = create_admin_user(email="x@other.com", subject="s-x")

        qs = UserFilter({"tenant": str(tenant.pk)}, queryset=UserService.list()).qs
        self.assertIn(member, qs)
        self.assertIn(internal, qs)
        self.assertNotIn(outsider, qs)
