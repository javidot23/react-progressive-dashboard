import uuid

from django.db import models

from api.common.models import TimestampedModel

from .choices import EntitlementTier, TenantType


class Tenant(TimestampedModel):
    tenant_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant_code = models.CharField(max_length=50, unique=True)
    tenant_name = models.CharField(max_length=255)
    tenant_type = models.CharField(max_length=20, choices=TenantType.choices)
    entitlement_tier = models.CharField(
        max_length=20, choices=EntitlementTier.choices, default=EntitlementTier.STANDARD
    )
    metadata = models.JSONField(default=dict, blank=True)
    database_host = models.CharField(max_length=255, blank=True)
    database_name = models.CharField(max_length=255, blank=True)
    database_port = models.PositiveIntegerField(default=5432)
    database_schema = models.CharField(max_length=255, default="public")
    database_username = models.CharField(max_length=255, blank=True)
    database_managed_identity_client_id = models.CharField(max_length=255, blank=True)
    is_federated = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "tenant"
        constraints = [
            models.CheckConstraint(condition=models.Q(tenant_type__in=TenantType.values), name="tenant_type_valid"),
            models.CheckConstraint(
                condition=models.Q(entitlement_tier__in=EntitlementTier.values), name="tenant_entitlement_tier_valid"
            ),
        ]

    def __str__(self):
        return self.tenant_code


class TenantMembership(TimestampedModel):
    tenant_membership_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        "user.User", on_delete=models.CASCADE, related_name="tenant_memberships", db_column="user_uuid"
    )
    tenant = models.ForeignKey(
        Tenant, on_delete=models.CASCADE, related_name="memberships", db_column="tenant_uuid"
    )
    effective_from = models.DateTimeField(null=True, blank=True)
    effective_to = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(
        "user.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+", db_column="created_by_user_uuid",
    )

    class Meta:
        db_table = "tenant_membership"
        constraints = [
            models.UniqueConstraint(fields=["user", "tenant"], name="tenant_membership_user_tenant_unique"),
        ]

    def __str__(self):
        return f"{self.user_id} @ {self.tenant_id}"


class TenantDomain(TimestampedModel):
    tenant_domain_uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey(
        Tenant, on_delete=models.CASCADE, related_name="domains", db_column="tenant_uuid"
    )
    domain = models.CharField(max_length=255)

    class Meta:
        db_table = "tenant_domain"
        constraints = [
            models.UniqueConstraint(fields=["tenant", "domain"], name="tenant_domain_unique_per_tenant"),
        ]

    def __str__(self):
        return f"{self.domain} @ {self.tenant_id}"
