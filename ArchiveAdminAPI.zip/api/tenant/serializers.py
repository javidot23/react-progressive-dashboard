from rest_framework import serializers

from .models import Tenant, TenantDomain, TenantMembership


class TenantDomainSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenantDomain
        fields = ["tenant_domain_uuid", "domain", "created_at"]
        read_only_fields = ["tenant_domain_uuid", "created_at"]


class TenantDomainCreateSerializer(serializers.Serializer):
    domain = serializers.CharField(max_length=255)


class TenantSerializer(serializers.ModelSerializer):
    domains = TenantDomainSerializer(many=True, read_only=True)
    user_count = serializers.IntegerField(read_only=True, default=0)

    class Meta:
        model = Tenant
        fields = [
            "tenant_uuid", "tenant_code", "tenant_name", "tenant_type",
            "entitlement_tier", "metadata", "database_host", "database_name",
            "database_port", "database_schema", "database_username",
            "database_managed_identity_client_id", "is_federated", "domains",
            "user_count", "is_active", "created_at", "updated_at",
        ]
        read_only_fields = ["tenant_uuid", "user_count", "created_at", "updated_at"]


class TenantMembershipSerializer(serializers.ModelSerializer):
    tenant_code = serializers.CharField(source="tenant.tenant_code", read_only=True)

    class Meta:
        model = TenantMembership
        fields = [
            "tenant_membership_uuid", "tenant", "tenant_code", "user",
            "effective_from", "effective_to", "is_active", "created_at",
        ]
        read_only_fields = ["tenant_membership_uuid", "tenant", "created_at"]


class TenantMembershipCreateSerializer(serializers.Serializer):
    user_uuid = serializers.UUIDField()
    effective_from = serializers.DateTimeField(required=False, allow_null=True)
    effective_to = serializers.DateTimeField(required=False, allow_null=True)
    is_active = serializers.BooleanField(required=False, default=True)


class ActiveTenantSerializer(serializers.Serializer):
    tenant_uuid = serializers.UUIDField()
