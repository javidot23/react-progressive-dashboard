from rest_framework import serializers


class InfoSerializer(serializers.Serializer):
    version = serializers.CharField(allow_null=True, required=False)
    environment = serializers.CharField(allow_null=True, required=False)


class DiagnosticsSerializer(serializers.Serializer):
    version = serializers.CharField(allow_null=True, required=False)
    environment = serializers.CharField(allow_null=True, required=False)
    database_schema = serializers.CharField(allow_null=True, required=False)
    redis_enabled = serializers.BooleanField()
    redis_connection = serializers.CharField()
    cache_backend = serializers.CharField()
    cache_ttl_seconds = serializers.IntegerField(allow_null=True)
    cache_key_prefix = serializers.CharField()
    commit_sha = serializers.CharField(allow_null=True, required=False)
