from django.apps import AppConfig


class InfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.info'

    def ready(self):
        # Registers the platform-wide endpoint-auth system checks (config/checks.py).
        from config import checks  # noqa: F401
