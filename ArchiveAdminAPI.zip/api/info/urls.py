from django.urls import path
from django.db import transaction

from .views import DiagnosticsAPIView, InfoAPIView

urlpatterns = [
    # ATOMIC_REQUESTS (config/settings/base.py) wraps every view in a transaction,
    # which opens a database connection BEFORE the view body runs. InfoAPIView reads
    # only environment variables, but without this exemption a database outage makes
    # it return 500 - failing liveness, readiness and startup probes on every pod at
    # once and turning a recoverable DB incident into a full outage.
    # This endpoint must stay answerable while dependencies are down.
    path('', transaction.non_atomic_requests(InfoAPIView.as_view()), name='api_info'),
    path('diagnostics/', DiagnosticsAPIView.as_view(), name='api_diagnostics'),
]
