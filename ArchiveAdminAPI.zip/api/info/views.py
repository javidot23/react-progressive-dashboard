import os

from django.conf import settings
from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import DiagnosticsSerializer, InfoSerializer


@method_decorator(never_cache, name='get')
@extend_schema_view(get=extend_schema(auth=[], responses=InfoSerializer))
class InfoAPIView(APIView):
    """Public liveness probe — API version and environment only."""

    authentication_classes = []
    permission_classes = []

    def get(self, request):
        return Response({
            "version": os.environ.get("API_VERSION"),
            "environment": os.environ.get("API_ENV"),
        })


@method_decorator(never_cache, name='get')
@extend_schema_view(get=extend_schema(responses=DiagnosticsSerializer))
class DiagnosticsAPIView(APIView):
    """Authenticated diagnostics — database schema and cache/redis status."""

    def get(self, request):
        schema_name = None
        if 'default' in settings.DATABASES:
            options = settings.DATABASES['default'].get('OPTIONS', {})
            search_path = options.get('options', '')
            if 'search_path=' in search_path:
                schema_name = search_path.split('search_path=')[1]

        redis_status = self._get_redis_status()
        cache_info = self._get_cache_info()

        return Response({
            "version": os.environ.get("API_VERSION"),
            "environment": os.environ.get("API_ENV"),
            "database_schema": schema_name,
            "redis_enabled": redis_status['enabled'],
            "redis_connection": redis_status['connection'],
            "cache_backend": cache_info['backend'],
            "cache_ttl_seconds": cache_info['ttl'],
            "cache_key_prefix": cache_info['key_prefix'],
            "commit_sha": os.environ.get("API_COMMIT_SHA"),
        })

    def _get_redis_status(self):
        """Check if Redis is enabled and accessible."""
        cache_backend = settings.CACHES['default']['BACKEND']

        if 'redis' not in cache_backend.lower():
            return {'enabled': False, 'connection': 'N/A'}

        try:
            cache.set('health_check', 'ok', 30)
            test_value = cache.get('health_check')
            cache.delete('health_check')

            return {
                'enabled': True,
                'connection': 'connected' if test_value == 'ok' else 'error'
            }
        except Exception:
            return {'enabled': True, 'connection': 'error'}

    def _get_cache_info(self):
        """Get cache configuration details."""
        cache_config = settings.CACHES['default']
        default_timeout = cache_config.get('TIMEOUT', 300)

        return {
            'backend': cache_config['BACKEND'].split('.')[-1],
            'ttl': default_timeout,
            'key_prefix': getattr(settings, 'CACHE_MIDDLEWARE_KEY_PREFIX', 'N/A'),
        }
