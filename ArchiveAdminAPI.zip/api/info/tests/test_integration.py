from unittest import mock
from django.urls import resolve
from django.urls import reverse
from rest_framework import status
from django.db import connections
from django.db.utils import OperationalError
from tests.BaseTestCase import BaseAPITestCase


class InfoIntegrationTestCase(BaseAPITestCase):
    def test_info_endpoint(self):
        """
        The public /info endpoint returns only version and environment.
        """
        url = reverse('api_info')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('version', response.data)
        self.assertIn('environment', response.data)
        self.assertNotIn('database_schema', response.data)
        self.assertNotIn('commit_sha', response.data)

    def test_info_endpoint_is_public(self):
        """The public /info endpoint is reachable without authentication."""
        url = reverse('api_info')
        response = self.client.get(url, HTTP_X_DISABLE_TEST_AUTH='1')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_diagnostics_endpoint_returns_details_when_authenticated(self):
        """The diagnostics endpoint exposes infrastructure details to authenticated callers."""
        url = reverse('api_diagnostics')
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('database_schema', response.data)
        self.assertIn('redis_connection', response.data)
        self.assertIn('cache_backend', response.data)
        self.assertIn('commit_sha', response.data)

    def test_diagnostics_endpoint_requires_authentication(self):
        """The diagnostics endpoint rejects unauthenticated requests."""
        url = reverse('api_diagnostics')
        response = self.client.get(url, HTTP_X_DISABLE_TEST_AUTH='1')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)


class InfoProbeResilienceTestCase(BaseAPITestCase):
    """The /info/ endpoint backs all three Kubernetes probes.

    It must answer 200 while the database is unreachable. ATOMIC_REQUESTS is
    enabled globally (config/settings/base.py), which opens a database connection
    before any view body runs, so the info route is explicitly exempted in
    api/info/urls.py. Removing that exemption would make a Postgres outage fail
    liveness, readiness AND startup probes on every pod simultaneously, turning a
    recoverable database incident into a full outage with a restart storm.
    """

    def test_info_route_is_exempt_from_atomic_requests(self):
        view = resolve(reverse('api_info')).func
        self.assertIn(
            'default',
            getattr(view, '_non_atomic_requests', set()),
            "api/info/urls.py must wrap InfoAPIView in transaction.non_atomic_requests - "
            "see the class docstring for why.",
        )

    def test_info_endpoint_responds_when_database_is_unreachable(self):
        with mock.patch.object(
            connections['default'],
            'ensure_connection',
            side_effect=OperationalError('simulated database outage'),
        ):
            response = self.client.get(reverse('api_info'), HTTP_X_DISABLE_TEST_AUTH='1')

        self.assertEqual(response.status_code, status.HTTP_200_OK)
