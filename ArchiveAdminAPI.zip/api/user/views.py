import logging

from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.decorators.vary import vary_on_headers
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework import generics, status
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView

from api.tenant.serializers import (
    ActiveTenantSerializer,
    TenantMembershipSerializer,
    TenantSerializer,
)
from api.tenant.services import TenantMembershipService

from .filters import UserFilter
from .serializers import (
    InternalUserCreateSerializer,
    TenantAccessScopeUpdateSerializer,
    UserInviteSerializer,
    UserMeSerializer,
    UserSerializer,
    UserUpdateSerializer,
)
from .services import UserService

logger = logging.getLogger(__name__)


@method_decorator(never_cache, name='dispatch')
@method_decorator(vary_on_headers('Cookie'), name='dispatch')
@extend_schema_view(get=extend_schema(responses=UserMeSerializer))
class UserProfileView(APIView):
    """GET /auth/me/ — the cookie-authenticated user plus identities, memberships,
    active tenant, and roles for the active tenant."""

    def get(self, request):
        return Response(UserService.get_me(request.user, request.session))


@method_decorator(never_cache, name='dispatch')
@extend_schema_view(
    get=extend_schema(responses=TenantSerializer),
    put=extend_schema(request=ActiveTenantSerializer, responses=TenantSerializer),
)
class ActiveTenantView(APIView):
    """GET/PUT /auth/active-tenant/ — read or switch the session's active tenant."""

    def get(self, request):
        tenant = TenantMembershipService.get_active(request.user, request.session)
        return Response(TenantSerializer(tenant).data if tenant else None)

    def put(self, request):
        serializer = ActiveTenantSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        tenant = TenantMembershipService.set_active(
            request.user, request.session, serializer.validated_data["tenant_uuid"]
        )
        return Response(TenantSerializer(tenant).data)


class UserListView(generics.ListAPIView):
    serializer_class = UserSerializer
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class = UserFilter
    ordering_fields = ["created_at", "display_name", "last_login", "status"]
    ordering = ["-created_at"]

    def get_queryset(self):
        return UserService.list()


@extend_schema_view(
    post=extend_schema(request=UserInviteSerializer, responses={201: UserSerializer}),
)
class UserInviteView(APIView):
    def post(self, request):
        serializer = UserInviteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = UserService.invite(created_by=request.user, **serializer.validated_data)
        return Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)


@extend_schema_view(
    post=extend_schema(request=InternalUserCreateSerializer, responses={201: UserSerializer}),
)
class InternalUserCreateView(APIView):
    def post(self, request):
        serializer = InternalUserCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = UserService.create_internal_user(
            created_by=request.user, **serializer.validated_data
        )
        return Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)


@extend_schema_view(
    get=extend_schema(responses=UserSerializer),
    patch=extend_schema(request=UserUpdateSerializer, responses=UserSerializer),
)
class UserDetailView(APIView):
    def get(self, request, user_uuid):
        return Response(UserSerializer(UserService.get(user_uuid)).data)

    def patch(self, request, user_uuid):
        serializer = UserUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = UserService.update(user_uuid, **serializer.validated_data)
        return Response(UserSerializer(user).data)


@extend_schema_view(
    put=extend_schema(
        request=TenantAccessScopeUpdateSerializer, responses={200: UserSerializer}
    ),
)
class UserTenantAccessScopeView(APIView):
    def put(self, request, user_uuid):
        serializer = TenantAccessScopeUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = UserService.set_tenant_access_scope(
            user_uuid,
            scope=serializer.validated_data["tenant_access_scope"],
            tenant_uuids=serializer.validated_data.get("tenant_uuids"),
            created_by=request.user,
        )
        return Response(UserSerializer(user).data)


class UserMembershipsView(generics.ListAPIView):
    serializer_class = TenantMembershipSerializer

    def get_queryset(self):
        return TenantMembershipService.list_for_user(self.kwargs["user_uuid"])
