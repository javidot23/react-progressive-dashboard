"""User provisioning/management URL configuration (mounted at ``users/``)."""
from django.urls import path

from . import views

app_name = "user_management"

urlpatterns = [
    path("", views.UserListView.as_view(), name="user-list"),
    path("invite/", views.UserInviteView.as_view(), name="user-invite"),
    path("internal/", views.InternalUserCreateView.as_view(), name="user-internal-create"),
    path("<uuid:user_uuid>/", views.UserDetailView.as_view(), name="user-detail"),
    path(
        "<uuid:user_uuid>/tenant-access-scope/",
        views.UserTenantAccessScopeView.as_view(),
        name="user-tenant-access-scope",
    ),
    path("<uuid:user_uuid>/memberships/", views.UserMembershipsView.as_view(), name="user-memberships"),
]
