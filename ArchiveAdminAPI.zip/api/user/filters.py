from django.db.models import Q
from django_filters import rest_framework as filters

from .choices import TenantAccessScope, UserStatus
from .models import User


class UserFilter(filters.FilterSet):
    status = filters.ChoiceFilter(choices=UserStatus.choices)
    is_platform_admin = filters.BooleanFilter()
    tenant_access_scope = filters.ChoiceFilter(choices=TenantAccessScope.choices)
    tenant = filters.UUIDFilter(method="filter_tenant")
    search = filters.CharFilter(method="filter_search")

    class Meta:
        model = User
        fields = ["status", "is_platform_admin", "tenant_access_scope", "tenant"]

    def filter_tenant(self, queryset, name, value):
        return queryset.filter(
            Q(tenant_memberships__tenant_id=value)
            | Q(tenant_access_scope=TenantAccessScope.ALL_TENANTS)
        ).distinct()

    def filter_search(self, queryset, name, value):
        return queryset.filter(
            Q(display_name__icontains=value)
            | Q(first_name__icontains=value)
            | Q(last_name__icontains=value)
            | Q(identities__email__icontains=value)
        ).distinct()
