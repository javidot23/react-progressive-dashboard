from unittest.mock import patch

from rest_framework.exceptions import ValidationError

from api.tenant.models import TenantMembership
from api.user.choices import AuthProvider, TenantAccessScope, UserStatus
from api.user.models import UserIdentity
from api.user.services import UserService
from tests.BaseTestCase import BaseTestCase
from tests.factories import add_domain, add_membership, create_admin_user, create_tenant


class UserInviteServiceTest(BaseTestCase):
    def setUp(self):
        self.tenant = create_tenant()
        add_domain(self.tenant, "cencora.com")

    def test_invite_rejected_when_domain_not_allowed(self):
        with self.assertRaises(ValidationError):
            UserService.invite("outsider@evil.com", self.tenant.pk)

    def test_invite_rejected_when_tenant_has_no_domains(self):
        bare = create_tenant(code="T-BARE")
        with self.assertRaises(ValidationError):
            UserService.invite("someone@cencora.com", bare.pk)

    def test_invite_creates_pending_sap_identity_and_membership(self):
        user = UserService.invite("new.user@cencora.com", self.tenant.pk)

        self.assertEqual(user.status, UserStatus.PENDING_VERIFICATION)
        self.assertFalse(user.is_active)
        self.assertEqual(user.tenant_access_scope, TenantAccessScope.TENANT)

        identity = UserIdentity.objects.get(user=user)
        self.assertEqual(identity.auth_provider, AuthProvider.SAP_CDC)
        self.assertIsNone(identity.auth_subject)
        self.assertTrue(TenantMembership.objects.filter(user=user, tenant=self.tenant).exists())

    def test_invite_duplicate_email_rejected(self):
        UserService.invite("dupe@cencora.com", self.tenant.pk)
        with self.assertRaises(ValidationError):
            UserService.invite("dupe@cencora.com", self.tenant.pk)

    def test_two_pending_invites_do_not_collide_on_null_subject(self):
        UserService.invite("a@cencora.com", self.tenant.pk)
        UserService.invite("b@cencora.com", self.tenant.pk)
        self.assertEqual(
            UserIdentity.objects.filter(
                auth_provider=AuthProvider.SAP_CDC, auth_subject__isnull=True
            ).count(),
            2,
        )


class ScopeForEmailTest(BaseTestCase):
    def test_unknown_domain_is_tenant(self):
        self.assertEqual(
            UserService.scope_for_email("a@customer.com"), TenantAccessScope.TENANT
        )

    @patch("api.user.services.INTERNAL_EMAIL_DOMAINS", frozenset({"genpact.com"}))
    def test_configured_internal_domain(self):
        self.assertEqual(
            UserService.scope_for_email("a@Genpact.COM"), TenantAccessScope.ALL_TENANTS
        )

    @patch("api.user.services.INTERNAL_EMAIL_DOMAINS", frozenset())
    def test_empty_list_is_tenant(self):
        self.assertEqual(
            UserService.scope_for_email("a@genpact.com"), TenantAccessScope.TENANT
        )


@patch("api.user.services.INTERNAL_EMAIL_DOMAINS", frozenset({"genpact.com"}))
class InternalUserServiceTest(BaseTestCase):
    def test_create_internal_user(self):
        user = UserService.create_internal_user("ops@genpact.com")
        self.assertEqual(user.tenant_access_scope, TenantAccessScope.ALL_TENANTS)
        self.assertEqual(user.status, UserStatus.ACTIVE)
        self.assertEqual(TenantMembership.objects.filter(user=user).count(), 0)
        identity = UserIdentity.objects.get(user=user)
        self.assertEqual(identity.auth_provider, AuthProvider.SAP_CDC)
        self.assertIsNone(identity.auth_subject)

    def test_create_internal_rejects_non_internal_domain(self):
        with self.assertRaises(ValidationError):
            UserService.create_internal_user("ops@customer.com")

    def test_create_internal_duplicate_email_rejected(self):
        UserService.create_internal_user("ops@genpact.com")
        with self.assertRaises(ValidationError):
            UserService.create_internal_user("ops@genpact.com")


class TenantAccessScopeServiceTest(BaseTestCase):
    def setUp(self):
        self.tenant_a = create_tenant(code="A")
        self.tenant_b = create_tenant(code="B")
        add_domain(self.tenant_a, "cencora.com")
        self.user = create_admin_user(email="staff@cencora.com")
        add_membership(self.user, self.tenant_a)

    def test_promote_deletes_memberships(self):
        user = UserService.set_tenant_access_scope(
            self.user.pk, TenantAccessScope.ALL_TENANTS
        )
        self.assertEqual(user.tenant_access_scope, TenantAccessScope.ALL_TENANTS)
        self.assertEqual(TenantMembership.objects.filter(user=self.user).count(), 0)

    def test_demote_requires_tenant_uuids(self):
        UserService.set_tenant_access_scope(self.user.pk, TenantAccessScope.ALL_TENANTS)
        with self.assertRaises(ValidationError):
            UserService.set_tenant_access_scope(self.user.pk, TenantAccessScope.TENANT)

    def test_demote_creates_keep_memberships(self):
        UserService.set_tenant_access_scope(self.user.pk, TenantAccessScope.ALL_TENANTS)
        user = UserService.set_tenant_access_scope(
            self.user.pk,
            TenantAccessScope.TENANT,
            tenant_uuids=[self.tenant_a.pk, self.tenant_b.pk],
        )
        self.assertEqual(user.tenant_access_scope, TenantAccessScope.TENANT)
        self.assertEqual(
            set(
                TenantMembership.objects.filter(user=self.user).values_list(
                    "tenant_id", flat=True
                )
            ),
            {self.tenant_a.pk, self.tenant_b.pk},
        )


class UserUpdateServiceTest(BaseTestCase):
    def setUp(self):
        self.user = create_admin_user(email="staff@cencora.com")

    def test_update_names_and_optional_fields(self):
        user = UserService.update(
            self.user.pk,
            first_name="Jane",
            last_name="Doe",
            job_title="Analyst",
            department="Ops",
        )
        self.assertEqual(user.first_name, "Jane")
        self.assertEqual(user.last_name, "Doe")
        self.assertEqual(user.job_title, "Analyst")
        self.assertEqual(user.department, "Ops")
        self.assertEqual(user.display_name, "Jane Doe")

    def test_update_status_only(self):
        user = UserService.update(self.user.pk, status=UserStatus.SUSPENDED)
        self.assertEqual(user.status, UserStatus.SUSPENDED)
        self.assertEqual(user.first_name, "Admin")

    def test_update_rejects_empty_payload(self):
        with self.assertRaises(ValidationError):
            UserService.update(self.user.pk)


class GetMeAllTenantsTest(BaseTestCase):
    def test_get_me_lists_all_active_tenants_for_all_tenants_scope(self):
        create_tenant(code="Z")
        create_tenant(code="A")
        inactive = create_tenant(code="I", is_active=False)
        user = create_admin_user(
            email="ops@genpact.com",
            subject="s-ops",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )
        payload = UserService.get_me(user, {})
        codes = [m["tenant_code"] for m in payload["memberships"]]
        self.assertEqual(codes, ["A", "Z"])
        self.assertNotIn(inactive.tenant_code, codes)
        self.assertEqual(
            payload["user"]["tenant_access_scope"], TenantAccessScope.ALL_TENANTS
        )
