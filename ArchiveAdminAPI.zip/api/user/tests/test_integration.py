from django.urls import reverse
from rest_framework import status

from api.user.choices import TenantAccessScope
from tests.BaseTestCase import BaseAPITestCase
from tests.factories import add_membership, create_admin_user, create_tenant


class UserProfileTest(BaseAPITestCase):
    def setUp(self):
        self.user = create_admin_user(email="john.doe@cencora.com")
        self.client.force_authenticate(user=self.user, token="test")
        self.url = reverse("user:user-profile")

    def test_unauthenticated(self):
        self.client.force_authenticate(user=None)
        response = self.client.get(self.url, HTTP_X_DISABLE_TEST_AUTH="1")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_me_returns_structure(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json().get("data", response.json())
        self.assertIn("user", data)
        self.assertIn("identities", data)
        self.assertIn("memberships", data)
        self.assertIn("roles", data)
        self.assertEqual(data["user"]["display_name"], self.user.display_name)


class UserListPaginationTest(BaseAPITestCase):
    def test_users_list_is_paginated(self):
        self.client.force_authenticate(user=create_admin_user(), token="test")
        create_admin_user(email="b@cencora.com", subject="s-b")

        response = self.client.get(reverse("user_management:user-list"))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json().get("data", response.json())
        # LimitOffset envelope, not a bare list.
        self.assertIn("count", data)
        self.assertIn("results", data)
        self.assertGreaterEqual(data["count"], 2)

    def test_list_includes_membership_tenants_but_not_for_all_tenants_users(self):
        admin = create_admin_user()
        self.client.force_authenticate(user=admin, token="test")
        tenant_a = create_tenant(code="A", name="Alpha")
        tenant_b = create_tenant(code="B", name="Beta")
        member = create_admin_user(email="member@cencora.com", subject="s-m")
        add_membership(member, tenant_a)
        add_membership(member, tenant_b)
        internal = create_admin_user(
            email="ops@cencora.com",
            subject="s-ops",
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )

        response = self.client.get(reverse("user_management:user-list"), {"limit": 50})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        rows = {row["user_uuid"]: row for row in response.json()["data"]["results"]}

        member_tenants = rows[str(member.pk)]["tenants"]
        self.assertEqual(
            [t["tenant_code"] for t in member_tenants],
            ["A", "B"],
        )
        self.assertEqual(rows[str(internal.pk)]["tenants"], [])


class ActiveTenantSwitchTest(BaseAPITestCase):
    def setUp(self):
        self.user = create_admin_user()
        self.client.force_authenticate(user=self.user, token="test")
        self.tenant = create_tenant()
        self.url = reverse("user:active-tenant")

    def test_switch_rejected_when_not_member(self):
        response = self.client.put(self.url, {"tenant_uuid": str(self.tenant.pk)}, format="json")
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_switch_allowed_when_member(self):
        add_membership(self.user, self.tenant)
        response = self.client.put(self.url, {"tenant_uuid": str(self.tenant.pk)}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
