import logging

from django.db import transaction
from django.db.models import Prefetch, QuerySet, prefetch_related_objects
from django.shortcuts import get_object_or_404
from rest_framework.exceptions import ValidationError

from api.authz.models import Role, UserRole
from api.tenant.models import TenantMembership
from api.tenant.services import TenantMembershipService, TenantService

from .choices import INTERNAL_EMAIL_DOMAINS, AuthProvider, TenantAccessScope, UserStatus
from .models import User, UserIdentity

logger = logging.getLogger(__name__)


class UserService:
    """Single access point for user reads, provisioning, and status changes."""

    @staticmethod
    def _queryset() -> QuerySet:
        return (
            User.objects.filter(is_deleted=False)
            .prefetch_related(
                "identities",
                Prefetch(
                    "tenant_memberships",
                    queryset=(
                        TenantMembership.objects.filter(is_active=True)
                        .select_related("tenant")
                        .order_by("tenant__tenant_code")
                    ),
                ),
            )
        )

    @staticmethod
    def list() -> QuerySet:
        return UserService._queryset().order_by("-created_at")

    @staticmethod
    def get(user_uuid) -> User:
        return get_object_or_404(UserService._queryset(), pk=user_uuid)

    @staticmethod
    def scope_for_email(email) -> str:
        parts = (email or "").rsplit("@", 1)
        if len(parts) != 2:
            return TenantAccessScope.TENANT
        domain = parts[-1].strip().lower()
        if domain and domain in INTERNAL_EMAIL_DOMAINS:
            return TenantAccessScope.ALL_TENANTS
        return TenantAccessScope.TENANT

    @staticmethod
    def get_me(user, session) -> dict:
        from api.tenant.serializers import TenantSerializer

        from .serializers import UserIdentitySerializer, UserSerializer

        prefetch_related_objects(
            [user],
            Prefetch(
                "identities",
                queryset=UserIdentity.objects.filter(is_deleted=False),
            ),
        )
        identities = user.identities.all()
        tenants = TenantMembershipService.list_tenants_for_user(user)
        active_tenant = TenantMembershipService.get_active(user, session)

        roles_qs = UserRole.objects.filter(user=user, is_active=True).select_related("role")
        if active_tenant is not None:
            roles_qs = roles_qs.filter(tenant=active_tenant)

        return {
            "user": UserSerializer(user).data,
            "identities": UserIdentitySerializer(identities, many=True).data,
            "memberships": [
                {"tenant_uuid": str(t.pk), "tenant_code": t.tenant_code}
                for t in tenants
            ],
            "active_tenant": TenantSerializer(active_tenant).data if active_tenant else None,
            "roles": sorted({ur.role.role_code for ur in roles_qs}),
        }

    @staticmethod
    @transaction.atomic
    def invite(email, tenant_uuid, role_uuid=None, created_by=None) -> User:
        """Provision a pending tenant end-user (SAP CDC), to be linked on first login.

        Deliberately separate from the Entra JIT path in
        ``api.identity.authentication`` — this never sets an ``auth_subject`` and
        never marks the user active.
        """
        email = (email or "").strip().lower()
        if UserIdentity.objects.filter(email=email).exists():
            raise ValidationError("email: a user with this email already exists.")

        tenant = TenantService.get(tenant_uuid)
        TenantService.assert_email_domain_allowed(tenant, email)
        role = None
        if role_uuid:
            role = get_object_or_404(Role, pk=role_uuid, is_active=True)

        user = User.objects.create_user(
            display_name=email,
            status=UserStatus.PENDING_VERIFICATION,
            tenant_access_scope=TenantAccessScope.TENANT,
        )
        UserIdentity.objects.create(
            user=user,
            email=email,
            auth_provider=AuthProvider.SAP_CDC,
            auth_subject=None,
            is_primary=True,
        )
        TenantMembership.objects.create(tenant=tenant, user=user, created_by=created_by)
        if role is not None:
            UserRole.objects.create(
                tenant=tenant, user=user, role=role, created_by=created_by
            )
        logger.info("Invited tenant user %s into tenant %s", user.user_uuid, tenant.pk)
        return user

    @staticmethod
    @transaction.atomic
    def create_internal_user(email, created_by=None) -> User:
        email = (email or "").strip().lower()
        if UserIdentity.objects.filter(email=email).exists():
            raise ValidationError("email: a user with this email already exists.")

        scope = UserService.scope_for_email(email)
        if scope != TenantAccessScope.ALL_TENANTS:
            raise ValidationError("Domain is not an internal email domain.", code="not_internal_domain")

        user = User.objects.create_user(
            display_name=email,
            status=UserStatus.ACTIVE,
            tenant_access_scope=TenantAccessScope.ALL_TENANTS,
        )
        UserIdentity.objects.create(
            user=user,
            email=email,
            auth_provider=AuthProvider.SAP_CDC,
            auth_subject=None,
            is_primary=True,
        )
        logger.info("Created internal user %s", user.user_uuid)
        return user

    @staticmethod
    @transaction.atomic
    def set_tenant_access_scope(user_uuid, scope, tenant_uuids=None, created_by=None) -> User:
        user = UserService.get(user_uuid)

        if scope == TenantAccessScope.ALL_TENANTS:
            TenantMembership.objects.filter(user=user).delete()
            user.tenant_access_scope = TenantAccessScope.ALL_TENANTS
            user.save(update_fields=["tenant_access_scope", "updated_at"])
            return user

        if scope != TenantAccessScope.TENANT:
            raise ValidationError(f"tenant_access_scope: invalid value '{scope}'.")

        keep = list(tenant_uuids or [])
        if not keep:
            raise ValidationError("tenant_uuids: required when scope is tenant.")

        tenants = []
        seen = set()
        for tenant_uuid in keep:
            if tenant_uuid in seen:
                continue
            seen.add(tenant_uuid)
            tenants.append(TenantService.get(tenant_uuid))

        TenantMembership.objects.filter(user=user).delete()
        TenantMembership.objects.bulk_create(
            [
                TenantMembership(user=user, tenant=tenant, created_by=created_by)
                for tenant in tenants
            ]
        )
        user.tenant_access_scope = TenantAccessScope.TENANT
        user.save(update_fields=["tenant_access_scope", "updated_at"])
        return user

    @staticmethod
    def update(user_uuid, **data) -> User:
        user = UserService.get(user_uuid)
        allowed = ("first_name", "last_name", "job_title", "department", "status")
        updates = [field for field in allowed if field in data]
        if not updates:
            raise ValidationError(
                "Provide at least one of: first_name, last_name, job_title, department, status."
            )
        for field in updates:
            setattr(user, field, data[field])
        if "first_name" in data or "last_name" in data:
            display = f"{user.first_name} {user.last_name}".strip()
            if display:
                user.display_name = display
                updates.append("display_name")
        user.save(update_fields=[*updates, "updated_at"])
        return user
