"""Auth/session URL configuration (mounted at ``auth/``)."""
from django.urls import path

from . import views

app_name = 'user'

urlpatterns = [
    path('me/', views.UserProfileView.as_view(), name='user-profile'),
    path('active-tenant/', views.ActiveTenantView.as_view(), name='active-tenant'),
]
