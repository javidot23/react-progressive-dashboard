from django.db import models


class UserStatus(models.TextChoices):
    ACTIVE = "active", "Active"
    PENDING_VERIFICATION = "pending_verification", "Pending verification"
    SUSPENDED = "suspended", "Suspended"
    INACTIVE = "inactive", "Inactive"
    DISABLED = "disabled", "Disabled"
    DELETED = "deleted", "Deleted"


class AuthProvider(models.TextChoices):
    SAP_CDC = "sap_cdc", "SAP CDC"
    ENTRA_ID = "entra_id", "Entra ID"


class TenantAccessScope(models.TextChoices):
    TENANT = "tenant", "Scoped to memberships"
    ALL_TENANTS = "all_tenants", "All tenants"


INTERNAL_EMAIL_DOMAINS = frozenset({
    "cencorapr.com",
    "cencora.com",
    "amerisourcebergen.com",
    "stratium.com",
})
