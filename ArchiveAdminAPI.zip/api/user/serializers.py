from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from api.tenant.serializers import TenantSerializer

from .choices import TenantAccessScope, UserStatus
from .models import User, UserIdentity


class UserIdentitySerializer(serializers.ModelSerializer):
    class Meta:
        model = UserIdentity
        fields = [
            "user_identity_uuid", "email", "auth_provider", "is_primary",
            "is_active", "last_login_at", "created_at",
        ]


class UserTenantSerializer(serializers.Serializer):
    tenant_uuid = serializers.UUIDField()
    tenant_code = serializers.CharField()
    tenant_name = serializers.CharField()


class UserSerializer(serializers.ModelSerializer):
    email = serializers.SerializerMethodField()
    tenants = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            "user_uuid", "status", "display_name", "first_name", "last_name",
            "email", "job_title", "department", "is_platform_admin",
            "tenant_access_scope", "tenants", "last_login", "created_at", "updated_at",
        ]

    @extend_schema_field(serializers.EmailField(allow_null=True))
    def get_email(self, obj) -> str | None:
        primary = None
        first = None
        for identity in obj.identities.all():
            if first is None:
                first = identity
            if identity.is_primary:
                primary = identity
                break
        chosen = primary or first
        return chosen.email if chosen else None

    @extend_schema_field(UserTenantSerializer(many=True))
    def get_tenants(self, obj) -> list[dict]:
        if obj.tenant_access_scope == TenantAccessScope.ALL_TENANTS:
            return []
        return [
            {
                "tenant_uuid": str(membership.tenant_id),
                "tenant_code": membership.tenant.tenant_code,
                "tenant_name": membership.tenant.tenant_name,
            }
            for membership in obj.tenant_memberships.all()
        ]


class UserInviteSerializer(serializers.Serializer):
    email = serializers.EmailField()
    tenant_uuid = serializers.UUIDField()
    role_uuid = serializers.UUIDField(required=False, allow_null=True)


class InternalUserCreateSerializer(serializers.Serializer):
    email = serializers.EmailField()


class TenantAccessScopeUpdateSerializer(serializers.Serializer):
    tenant_access_scope = serializers.ChoiceField(choices=TenantAccessScope.choices)
    tenant_uuids = serializers.ListField(
        child=serializers.UUIDField(),
        required=False,
        allow_empty=False,
    )


class UserUpdateSerializer(serializers.Serializer):
    first_name = serializers.CharField(max_length=150, required=False, allow_blank=True)
    last_name = serializers.CharField(max_length=150, required=False, allow_blank=True)
    job_title = serializers.CharField(max_length=150, required=False, allow_blank=True)
    department = serializers.CharField(max_length=100, required=False, allow_blank=True)
    status = serializers.ChoiceField(choices=UserStatus.choices, required=False)

    def validate(self, attrs):
        if not attrs:
            raise serializers.ValidationError(
                "Provide at least one of: first_name, last_name, job_title, department, status."
            )
        return attrs


class MeMembershipSerializer(serializers.Serializer):
    tenant_uuid = serializers.UUIDField()
    tenant_code = serializers.CharField()


class UserMeSerializer(serializers.Serializer):
    """Response shape for GET /auth/me/."""

    user = UserSerializer()
    identities = UserIdentitySerializer(many=True)
    memberships = MeMembershipSerializer(many=True)
    active_tenant = TenantSerializer(allow_null=True)
    roles = serializers.ListField(child=serializers.CharField())
