import random

from django.core.management.base import BaseCommand
from faker import Faker

from api.user.choices import AuthProvider, UserStatus
from api.user.models import User, UserIdentity


class Command(BaseCommand):
    help = "Generate fake users, each with a primary identity"

    def add_arguments(self, parser):
        parser.add_argument("--count", type=int, default=20, help="Number of users (default: 20)")

    def handle(self, *args, **options):
        fake = Faker()
        count = options["count"]
        self.stdout.write(f"Creating {count} fake users...")

        for _ in range(count):
            first = fake.first_name()
            last = fake.last_name()
            is_admin = random.random() < 0.3
            provider = AuthProvider.ENTRA_ID if is_admin else AuthProvider.SAP_CDC
            status = UserStatus.ACTIVE if is_admin else UserStatus.PENDING_VERIFICATION

            user = User.objects.create_user(
                display_name=f"{first} {last}",
                first_name=first,
                last_name=last,
                job_title=fake.job()[:150],
                department=fake.bs()[:100],
                is_platform_admin=is_admin,
                status=status,
            )
            UserIdentity.objects.create(
                user=user,
                email=fake.unique.email(),
                auth_provider=provider,
                auth_subject=(fake.uuid4() if is_admin else None),
                is_primary=True,
            )
            self.stdout.write(f"Created user: {user.display_name} ({provider})")

        self.stdout.write(self.style.SUCCESS(f"Successfully created {count} users."))
