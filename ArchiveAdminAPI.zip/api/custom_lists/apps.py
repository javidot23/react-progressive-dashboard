from django.apps import AppConfig


class CustomListsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.custom_lists"
