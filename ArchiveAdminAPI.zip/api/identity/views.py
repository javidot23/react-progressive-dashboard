from __future__ import annotations

import logging
import time
from urllib.parse import urlencode

from django.conf import settings
from django.contrib.auth import login as django_login
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from drf_spectacular.utils import OpenApiResponse, extend_schema, extend_schema_view
from rest_framework import status
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from api.audit.choices import AuditEventType
from api.audit.services import AuditService

from .authentication import provision_platform_admin_from_entra_claims
from .authentication_session import CookieSessionAuthentication
from .oidc import get_end_session_endpoint, get_oidc_client
from .serializers import LogoutResponseSerializer

logger = logging.getLogger(__name__)


def _callback_url(request) -> str:
    """OIDC redirect_uri — must match the IdP allowlist (e.g. /api/login/)."""
    override = getattr(settings, 'OIDC_CALLBACK_URL', None)
    if override:
        return override
    return request.build_absolute_uri(reverse('identity:login'))


@method_decorator(never_cache, name='dispatch')
@extend_schema_view(
    get=extend_schema(
        auth=[],
        responses={302: OpenApiResponse(description="Redirect to Entra ID authorize URL")},
    ),
)
class LoginStartView(APIView):
    """GET /login/start/ — begin OIDC; redirect the browser to the IdP."""

    authentication_classes: list = []
    permission_classes = [AllowAny]

    def get(self, request):
        logger.info("OIDC login start")
        _, client = get_oidc_client()
        return client.authorize_redirect(request, _callback_url(request))


@method_decorator(never_cache, name='dispatch')
@extend_schema_view(
    get=extend_schema(
        auth=[],
        responses={
            302: OpenApiResponse(
                description="Redirect to FRONTEND_URL after session is established"
            ),
            400: OpenApiResponse(description="OIDC callback or ID token failure"),
            403: OpenApiResponse(description="Login rejected (e.g. group membership)"),
        },
    ),
)
class LoginView(APIView):
    """
    GET /login/ — OIDC callback (IdP return URL).

    Exchanges the authorization code, creates/updates the user, and establishes
    the Django session cookie. Must match the IdP allowlisted redirect_uri
    (e.g. http://localhost:8000/api/login/).
    """

    authentication_classes: list = []
    permission_classes = [AllowAny]

    def get(self, request):
        logger.info("OIDC login callback")
        idp, client = get_oidc_client()
        try:
            token = client.authorize_access_token(request)
        except Exception as e:
            logger.warning("OIDC token exchange failed: %s", e)
            return Response(
                {'detail': 'oidc_callback_failed'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        claims = token.get('userinfo') or {}
        if not claims:
            try:
                claims = client.parse_id_token(request, token) or {}
            except Exception as e:
                logger.warning("ID token parse failed: %s", e)
                return Response(
                    {'detail': 'invalid_id_token'},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        try:
            userinfo = token.get('userinfo') or {}
            user = provision_platform_admin_from_entra_claims(claims, userinfo)
        except AuthenticationFailed as e:
            logger.info("Login callback rejected: %s", e.detail)
            AuditService.record(
                AuditEventType.LOGIN_FAILURE,
                reason_code=str(getattr(e, 'get_codes', lambda: '')() or ''),
                source="admin_portal",
                source_ip=AuditService._client_ip(request),
            )
            return Response({'detail': str(e.detail)}, status=status.HTTP_403_FORBIDDEN)

        user.backend = 'django.contrib.auth.backends.ModelBackend'
        django_login(request, user)

        AuditService.record(
            AuditEventType.LOGIN_SUCCESS,
            actor_user=user,
            source="admin_portal",
            source_ip=AuditService._client_ip(request),
        )

        request.session['idp'] = idp
        # Kept for RP-initiated logout (id_token_hint). Access/refresh tokens
        # are intentionally dropped — no IdP calls after this point.
        request.session['id_token'] = token.get('id_token')
        request.session['claims'] = claims
        request.session['absolute_expiry'] = int(
            time.time() + settings.SESSION_ABSOLUTE_TIMEOUT_SECONDS
        )
        request.session.set_expiry(settings.SESSION_IDLE_TIMEOUT_SECONDS)

        return redirect(settings.FRONTEND_URL)


@method_decorator(never_cache, name='dispatch')
@extend_schema_view(
    post=extend_schema(request=None, responses=LogoutResponseSerializer),
)
class LogoutView(APIView):
    authentication_classes = [CookieSessionAuthentication]

    def post(self, request):
        session = request.session
        id_token = session.get('id_token')
        idp = session.get('idp')

        end_session_url = None
        if idp and id_token:
            base = get_end_session_endpoint(idp)
            if base:
                params = {
                    'id_token_hint': id_token,
                    'post_logout_redirect_uri': settings.FRONTEND_URL,
                }
                sep = '&' if '?' in base else '?'
                end_session_url = f"{base}{sep}{urlencode(params)}"

        session.flush()

        response = Response({'end_session_url': end_session_url})
        response.delete_cookie(
            settings.SESSION_COOKIE_NAME,
            path=settings.SESSION_COOKIE_PATH,
            domain=settings.SESSION_COOKIE_DOMAIN,
        )
        response.delete_cookie(
            settings.CSRF_COOKIE_NAME,
            path=settings.CSRF_COOKIE_PATH,
            domain=settings.CSRF_COOKIE_DOMAIN,
        )
        return response
