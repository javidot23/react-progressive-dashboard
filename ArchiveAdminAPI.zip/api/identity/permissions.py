from rest_framework.permissions import BasePermission


class IsPlatformAdmin(BasePermission):
    """Allow only authenticated platform administrators.

    The admin portal is for internal platform admins only. Requiring the
    ``is_platform_admin`` flag (not merely authentication) keeps a non-admin
    ``User`` in the shared core DB — e.g. an invited tenant end-user — from ever
    reaching the admin surface if a session for one somehow resolves here.
    """

    message = "Platform administrator access required."

    def has_permission(self, request, view):
        user = getattr(request, "user", None)
        return bool(
            user
            and user.is_authenticated
            and getattr(user, "is_platform_admin", False)
        )
