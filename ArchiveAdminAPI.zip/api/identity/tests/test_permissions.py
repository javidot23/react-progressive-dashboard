from django.urls import reverse
from rest_framework import status

from api.user.choices import UserStatus
from api.user.models import User
from tests.BaseTestCase import BaseAPITestCase
from tests.factories import create_admin_user


class IsPlatformAdminTest(BaseAPITestCase):
    def setUp(self):
        self.url = reverse("tenant:tenant-list")

    def test_platform_admin_allowed(self):
        self.client.force_authenticate(user=create_admin_user(), token="test")
        self.assertEqual(self.client.get(self.url).status_code, status.HTTP_200_OK)

    def test_non_admin_forbidden(self):
        non_admin = User.objects.create_user(
            display_name="Tenant User", is_platform_admin=False, status=UserStatus.ACTIVE
        )
        self.client.force_authenticate(user=non_admin, token="test")
        self.assertEqual(self.client.get(self.url).status_code, status.HTTP_403_FORBIDDEN)
