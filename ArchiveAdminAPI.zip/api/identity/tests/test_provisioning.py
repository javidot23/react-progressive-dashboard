from unittest.mock import patch

from rest_framework.exceptions import AuthenticationFailed

from api.identity.authentication import provision_platform_admin_from_entra_claims
from api.user.choices import AuthProvider, TenantAccessScope, UserStatus
from api.user.models import User, UserIdentity
from tests.BaseTestCase import BaseTestCase


class EntraProvisioningTest(BaseTestCase):
    CLAIMS = {
        "oid": "entra-oid-123",
        "email": "jane.admin@cencora.com",
        "given_name": "Jane",
        "family_name": "Admin",
        "name": "Jane Admin",
    }

    @patch("api.user.services.INTERNAL_EMAIL_DOMAINS", frozenset())
    def test_jit_creates_active_platform_admin(self):
        user = provision_platform_admin_from_entra_claims(self.CLAIMS)

        self.assertTrue(user.is_platform_admin)
        self.assertEqual(user.status, UserStatus.ACTIVE)
        self.assertTrue(user.is_active)
        self.assertEqual(user.tenant_access_scope, TenantAccessScope.TENANT)

        identity = UserIdentity.objects.get(user=user)
        self.assertEqual(identity.auth_provider, AuthProvider.ENTRA_ID)
        self.assertEqual(identity.auth_subject, "entra-oid-123")
        self.assertIsNotNone(identity.last_login_at)

    @patch("api.user.services.INTERNAL_EMAIL_DOMAINS", frozenset({"cencora.com"}))
    def test_jit_stamps_all_tenants_when_domain_configured(self):
        user = provision_platform_admin_from_entra_claims(self.CLAIMS)
        self.assertEqual(user.tenant_access_scope, TenantAccessScope.ALL_TENANTS)

    @patch("api.user.services.INTERNAL_EMAIL_DOMAINS", frozenset())
    def test_second_login_does_not_rewrite_scope(self):
        user1 = provision_platform_admin_from_entra_claims(self.CLAIMS)
        self.assertEqual(user1.tenant_access_scope, TenantAccessScope.TENANT)
        with patch("api.user.services.INTERNAL_EMAIL_DOMAINS", frozenset({"cencora.com"})):
            user2 = provision_platform_admin_from_entra_claims(self.CLAIMS)
        self.assertEqual(user1.pk, user2.pk)
        self.assertEqual(user2.tenant_access_scope, TenantAccessScope.TENANT)

    def test_second_login_is_idempotent_and_updates_last_login(self):
        user1 = provision_platform_admin_from_entra_claims(self.CLAIMS)
        first_login = UserIdentity.objects.get(user=user1).last_login_at

        user2 = provision_platform_admin_from_entra_claims(self.CLAIMS)
        self.assertEqual(user1.pk, user2.pk)
        self.assertEqual(User.objects.count(), 1)
        self.assertGreaterEqual(UserIdentity.objects.get(user=user2).last_login_at, first_login)

    def test_missing_subject_is_rejected(self):
        with self.assertRaises(AuthenticationFailed):
            provision_platform_admin_from_entra_claims({"email": "jane@cencora.com"})
        self.assertEqual(User.objects.count(), 0)
