from django.core.exceptions import ImproperlyConfigured
from django.test import SimpleTestCase, override_settings

from api.identity.apps import assert_test_auto_auth_not_enabled_in_production


class TestAutoAuthBootGuardTest(SimpleTestCase):
    @override_settings(
        DEBUG=False,
        REST_FRAMEWORK={
            "DEFAULT_AUTHENTICATION_CLASSES": (
                "tests.authentication.TestAutoAuthentication",
            ),
        },
    )
    def test_rejects_test_auth_when_debug_false(self):
        with self.assertRaises(ImproperlyConfigured) as ctx:
            assert_test_auto_auth_not_enabled_in_production()
        self.assertIn("TestAutoAuthentication", str(ctx.exception))

    @override_settings(
        DEBUG=True,
        REST_FRAMEWORK={
            "DEFAULT_AUTHENTICATION_CLASSES": (
                "tests.authentication.TestAutoAuthentication",
            ),
        },
    )
    def test_allows_test_auth_when_debug_true(self):
        assert_test_auto_auth_not_enabled_in_production()
