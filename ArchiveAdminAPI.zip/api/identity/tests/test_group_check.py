from unittest.mock import patch

from django.test import SimpleTestCase, override_settings
from rest_framework.exceptions import AuthenticationFailed

from api.identity.groups import enforce_group_membership

GROUP = "11111111-1111-1111-1111-111111111111"


class GroupCheckTest(SimpleTestCase):
    def test_disabled_when_setting_unset(self):
        # ENTRA_REQUIRED_GROUP_ID defaults to None in test settings.
        enforce_group_membership({"oid": "x"})  # no raise

    @override_settings(ENTRA_REQUIRED_GROUP_ID=GROUP)
    def test_allowed_when_group_in_claim(self):
        enforce_group_membership({"oid": "x", "groups": [GROUP, "other"]})  # no raise

    @override_settings(ENTRA_REQUIRED_GROUP_ID=GROUP)
    def test_rejected_when_group_absent_from_claim(self):
        with self.assertRaises(AuthenticationFailed):
            enforce_group_membership({"oid": "x", "groups": ["other"]})

    @override_settings(ENTRA_REQUIRED_GROUP_ID=GROUP)
    def test_rejected_when_no_groups_and_no_overage(self):
        with self.assertRaises(AuthenticationFailed):
            enforce_group_membership({"oid": "x"})

    @override_settings(ENTRA_REQUIRED_GROUP_ID=GROUP)
    @patch("api.identity.groups._graph_is_member", return_value=True)
    def test_overage_falls_back_to_graph_allowed(self, mock_graph):
        enforce_group_membership({"oid": "x", "_claim_names": {"groups": "src1"}})  # no raise
        mock_graph.assert_called_once()

    @override_settings(ENTRA_REQUIRED_GROUP_ID=GROUP)
    @patch("api.identity.groups._graph_is_member", return_value=False)
    def test_overage_falls_back_to_graph_rejected(self, mock_graph):
        with self.assertRaises(AuthenticationFailed):
            enforce_group_membership({"oid": "x", "hasgroups": True})
        mock_graph.assert_called_once()
