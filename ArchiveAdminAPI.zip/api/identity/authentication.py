import logging
from typing import Optional

from django.utils import timezone
from rest_framework.exceptions import AuthenticationFailed

from api.user.choices import AuthProvider, UserStatus
from api.user.models import User, UserIdentity

from .groups import enforce_group_membership

logger = logging.getLogger(__name__)


def _split_name(claims: dict, userinfo: Optional[dict]) -> tuple[str, str]:
    src = userinfo or {}
    given = (src.get('given_name') or claims.get('given_name') or '').strip()
    family = (src.get('family_name') or claims.get('family_name') or '').strip()
    if not given and not family:
        full = (src.get('name') or claims.get('name') or '').strip()
        if full:
            parts = full.split()
            given = parts[0]
            family = ' '.join(parts[1:])
    return given, family


def provision_platform_admin_from_entra_claims(
    claims: dict,
    userinfo: Optional[dict] = None,
) -> User:
    """
    JIT-provision an internal platform admin from Entra ID claims.
    """
    subject = (claims.get('oid') or claims.get('sub') or '').strip()
    if not subject:
        raise AuthenticationFailed('invalid_token')

    enforce_group_membership(claims)

    email = (
        (userinfo or {}).get('email')
        or claims.get('email')
        or claims.get('preferred_username')
        or ''
    ).strip()

    given_name, family_name = _split_name(claims, userinfo)
    display_name = (claims.get('name') or (userinfo or {}).get('name') or email or subject).strip()
    now = timezone.now()

    identity = (
        UserIdentity.objects
        .select_related('user')
        .filter(auth_provider=AuthProvider.ENTRA_ID, auth_subject=subject)
        .first()
    )

    if identity is not None:
        user = identity.user
        updates = []
        if email and identity.email != email:
            identity.email = email
        if given_name and user.first_name != given_name:
            user.first_name = given_name
            updates.append('first_name')
        if family_name and user.last_name != family_name:
            user.last_name = family_name
            updates.append('last_name')
        if updates:
            user.save(update_fields=updates)
        identity.last_login_at = now
        identity.save(update_fields=['email', 'last_login_at'])
        return user

    from api.user.services import UserService

    user = User.objects.create_user(
        display_name=display_name or 'Unknown',
        first_name=given_name,
        last_name=family_name,
        is_platform_admin=True,
        status=UserStatus.ACTIVE,
        tenant_access_scope=UserService.scope_for_email(email),
    )
    UserIdentity.objects.create(
        user=user,
        email=email,
        auth_provider=AuthProvider.ENTRA_ID,
        auth_subject=subject,
        is_primary=True,
        last_login_at=now,
    )
    logger.info("JIT-provisioned platform admin %s (%s)", user.user_uuid, email)
    return user
