from __future__ import annotations

from typing import Tuple

from authlib.integrations.django_client import OAuth
from django.conf import settings

_oauth = OAuth()

IDP_NAME = 'entra_id'


def _register_clients() -> None:
    explicit_authorize = getattr(settings, 'ENTRA_AUTHORIZE_URL', None)
    explicit_token = getattr(settings, 'ENTRA_TOKEN_URL', None)
    use_explicit = bool(explicit_authorize and explicit_token)

    metadata_url = getattr(settings, 'ENTRA_METADATA_URL', None)
    jwks_uri = getattr(settings, 'ENTRA_JWKS_URI', None)

    entra_kwargs = dict(
        name=IDP_NAME,
        client_id=settings.ENTRA_CLIENT_ID,
        client_secret=getattr(settings, 'ENTRA_CLIENT_SECRET', None),
        client_kwargs={
            'scope': 'openid profile email',
            'code_challenge_method': 'S256',
        },
    )

    # Attach discovery/JWKS so ID-token signatures are verified even when the
    # authorize/token URLs are provided explicitly.
    if metadata_url:
        entra_kwargs['server_metadata_url'] = metadata_url
    elif jwks_uri:
        entra_kwargs['jwks_uri'] = jwks_uri
    else:
        raise ValueError(
            "Entra ID OIDC requires ENTRA_METADATA_URL, ENTRA_TENANT_ID, or "
            "ENTRA_JWKS_URI so ID tokens can be signature-verified."
        )

    if use_explicit:
        entra_kwargs['authorize_url'] = explicit_authorize
        entra_kwargs['access_token_url'] = explicit_token

    if IDP_NAME in _oauth._registry:
        del _oauth._registry[IDP_NAME]
        _oauth._clients.pop(IDP_NAME, None)
    _oauth.register(**entra_kwargs)


def get_oidc_client() -> Tuple[str, object]:
    _register_clients()
    return IDP_NAME, getattr(_oauth, IDP_NAME)


def get_end_session_endpoint(idp_name: str = IDP_NAME) -> str | None:
    _register_clients()
    override = getattr(settings, 'ENTRA_END_SESSION_URL', None)
    if override:
        return override

    client = getattr(_oauth, idp_name, None)
    if client is None:
        return None
    try:
        metadata = client.load_server_metadata()
    except Exception:
        return None
    return metadata.get('end_session_endpoint')
