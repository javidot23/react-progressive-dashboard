import logging

import requests
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from rest_framework.exceptions import AuthenticationFailed

logger = logging.getLogger(__name__)

GRAPH_CHECK_MEMBER_GROUPS_URL = "https://graph.microsoft.com/v1.0/users/{oid}/checkMemberGroups"
GRAPH_TOKEN_URL = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
GRAPH_SCOPE = "https://graph.microsoft.com/.default"


def enforce_group_membership(claims: dict) -> None:
    """Reject the login unless the user belongs to ``ENTRA_REQUIRED_GROUP_ID``.

    Defense-in-depth over the app-registration group assignment. No-op when the
    setting is unset (dev/test). Reads the token ``groups`` claim, and falls back
    to a Microsoft Graph check only when Entra signals a groups overage (a user in
    more groups than fit in the token).
    """
    required = getattr(settings, "ENTRA_REQUIRED_GROUP_ID", None)
    if not required:
        return

    groups = claims.get("groups")
    if groups is not None:
        if required in groups:
            return
        raise AuthenticationFailed(_("Access denied"), code="not_in_required_group")

    if _has_groups_overage(claims) and _graph_is_member(claims, required):
        return

    raise AuthenticationFailed(_("Access denied"), code="not_in_required_group")


def _has_groups_overage(claims: dict) -> bool:
    """True when Entra omitted the groups claim and pointed at Graph instead."""
    if claims.get("hasgroups"):
        return True
    return "groups" in (claims.get("_claim_names") or {})


def _graph_is_member(claims: dict, required_group_id: str) -> bool:
    oid = (claims.get("oid") or claims.get("sub") or "").strip()
    if not oid:
        return False
    token = _graph_app_token()
    if not token:
        return False
    try:
        resp = requests.post(
            GRAPH_CHECK_MEMBER_GROUPS_URL.format(oid=oid),
            headers={"Authorization": f"Bearer {token}"},
            json={"groupIds": [required_group_id]},
            timeout=10,
        )
        if resp.status_code != 200:
            logger.warning("Graph checkMemberGroups failed: %s %s", resp.status_code, resp.text)
            return False
        return required_group_id in (resp.json().get("value") or [])
    except Exception:
        logger.exception("Graph checkMemberGroups request error")
        return False


def _graph_app_token() -> str | None:
    """App-only Graph token via client credentials (needs GroupMember.Read.All)."""
    tenant = getattr(settings, "ENTRA_TENANT_ID", None)
    client_id = getattr(settings, "ENTRA_CLIENT_ID", None)
    client_secret = getattr(settings, "ENTRA_CLIENT_SECRET", None)
    if not (tenant and client_id and client_secret):
        logger.warning("Graph fallback needs ENTRA_TENANT_ID/CLIENT_ID/CLIENT_SECRET")
        return None
    try:
        resp = requests.post(
            GRAPH_TOKEN_URL.format(tenant=tenant),
            data={
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
                "scope": GRAPH_SCOPE,
            },
            timeout=10,
        )
        if resp.status_code != 200:
            logger.warning("Graph app-token request failed: %s %s", resp.status_code, resp.text)
            return None
        return resp.json().get("access_token")
    except Exception:
        logger.exception("Graph app-token request error")
        return None
