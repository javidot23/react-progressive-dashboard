from __future__ import annotations

import time
import logging
from rest_framework.authentication import SessionAuthentication
from rest_framework.exceptions import AuthenticationFailed

logger = logging.getLogger(__name__)


class CookieSessionAuthentication(SessionAuthentication):
    def authenticate_header(self, request):
        # Returning a string makes DRF respond 401 instead of 403 on failure,
        # which the SPA uses as the signal to redirect to /login/start/.
        return 'Session realm="api"'

    def authenticate(self, request):
        result = super().authenticate(request)
        if result is None:
            return None

        user, _ = result
        session = request.session

        absolute_expiry = session.get('absolute_expiry')
        if absolute_expiry is not None and time.time() > absolute_expiry:
            session.flush()
            logger.info("Session expired for user %s", user.user_uuid)
            raise AuthenticationFailed('session_expired_absolute')

        return (user, None)
