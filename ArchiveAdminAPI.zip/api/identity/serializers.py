from rest_framework import serializers


class LogoutResponseSerializer(serializers.Serializer):
    end_session_url = serializers.URLField(allow_null=True, required=False)
