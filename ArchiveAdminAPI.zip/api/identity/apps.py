from django.apps import AppConfig
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured


def assert_test_auto_auth_not_enabled_in_production():
    """Refuse to boot if TestAutoAuthentication is configured while DEBUG is False."""
    if settings.DEBUG:
        return
    for path in settings.REST_FRAMEWORK.get("DEFAULT_AUTHENTICATION_CLASSES", ()):
        if "TestAutoAuthentication" in path:
            raise ImproperlyConfigured(
                f"{path} is test-only and must not be enabled when DEBUG=False."
            )


class IdentityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.identity'
    label = 'identity'

    def ready(self):
        # Register OpenAPI authentication extension for CookieSessionAuthentication.
        import api.schema.authentication  # noqa: F401

        assert_test_auto_auth_not_enabled_in_production()
