from django_filters import rest_framework as filters

from .models import EntitlementResource, Permission, Resource, UserRole


class PermissionFilter(filters.FilterSet):
    class Meta:
        model = Permission
        fields = ["resource", "permission_type"]


class ResourceFilter(filters.FilterSet):
    class Meta:
        model = Resource
        fields = ["resource_type", "parent_resource"]


class UserRoleFilter(filters.FilterSet):
    class Meta:
        model = UserRole
        fields = ["tenant", "user", "role"]


class EntitlementResourceFilter(filters.FilterSet):
    class Meta:
        model = EntitlementResource
        fields = ["entitlement_tier", "resource"]
