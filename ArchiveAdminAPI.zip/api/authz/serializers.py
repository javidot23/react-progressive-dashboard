from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from api.tenant.choices import EntitlementTier

from .models import (
    EntitlementResource,
    Permission,
    Resource,
    Role,
    UserRole,
)


class PermissionSerializer(serializers.ModelSerializer):
    resource_code = serializers.CharField(source="resource.resource_code", read_only=True)

    class Meta:
        model = Permission
        fields = [
            "permission_uuid", "permission_code", "permission_name", "permission_type",
            "action_code", "resource", "resource_code", "is_active",
        ]


class ResourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Resource
        fields = [
            "resource_uuid", "resource_code", "resource_name", "resource_description",
            "resource_type", "parent_resource", "display_order", "is_active",
        ]


class RoleSerializer(serializers.ModelSerializer):
    permissions = serializers.SerializerMethodField()

    class Meta:
        model = Role
        fields = [
            "role_uuid", "role_code", "role_name", "role_description",
            "is_system_role", "is_active", "permissions",
        ]

    @extend_schema_field(serializers.ListField(child=serializers.CharField()))
    def get_permissions(self, obj) -> list[str]:
        return [
            rp.permission.permission_code
            for rp in obj.role_permissions.all()
            if rp.is_active
        ]


class RoleUpdateSerializer(serializers.Serializer):
    """Editable presentation + availability of an existing role. role_code,
    is_system_role and grants are intentionally not editable."""
    role_name = serializers.CharField(max_length=255, required=False)
    role_description = serializers.CharField(required=False, allow_blank=True)
    is_active = serializers.BooleanField(required=False)


class PermissionUpdateSerializer(serializers.Serializer):
    permission_name = serializers.CharField(max_length=255, required=False)
    permission_description = serializers.CharField(required=False, allow_blank=True)
    is_active = serializers.BooleanField(required=False)


class ResourceUpdateSerializer(serializers.Serializer):
    resource_name = serializers.CharField(max_length=255, required=False)
    resource_description = serializers.CharField(required=False, allow_blank=True)
    display_order = serializers.IntegerField(required=False)
    is_active = serializers.BooleanField(required=False)


class UserRoleSerializer(serializers.ModelSerializer):
    role_code = serializers.CharField(source="role.role_code", read_only=True)

    class Meta:
        model = UserRole
        fields = [
            "user_role_uuid", "tenant", "user", "role", "role_code",
            "assignment_source", "is_active", "created_at",
        ]


class UserRoleCreateSerializer(serializers.Serializer):
    tenant_uuid = serializers.UUIDField()
    user_uuid = serializers.UUIDField()
    role_uuid = serializers.UUIDField()


class EntitlementResourceSerializer(serializers.ModelSerializer):
    resource_code = serializers.CharField(source="resource.resource_code", read_only=True)

    class Meta:
        model = EntitlementResource
        fields = ["id", "entitlement_tier", "resource", "resource_code", "is_active"]


class EntitlementResourceCreateSerializer(serializers.Serializer):
    entitlement_tier = serializers.ChoiceField(choices=EntitlementTier.choices)
    resource_uuid = serializers.UUIDField()
