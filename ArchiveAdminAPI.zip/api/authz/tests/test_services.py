from rest_framework.exceptions import ValidationError

from api.authz.choices import PermissionType, ResourceType
from api.authz.models import Permission, Resource, Role, UserRole
from api.authz.serializers import RoleUpdateSerializer
from api.authz.services import (
    EntitlementResourceService,
    PermissionService,
    ResourceService,
    RoleService,
    UserRoleService,
)
from api.tenant.choices import EntitlementTier
from tests.BaseTestCase import BaseTestCase
from tests.factories import create_admin_user, create_tenant, tenant_admin_role


class UserRoleServiceTest(BaseTestCase):
    def setUp(self):
        self.user = create_admin_user()
        self.tenant = create_tenant()
        self.role = tenant_admin_role()

    def test_assign_picker_over_existing_role(self):
        user_role = UserRoleService.assign(self.tenant.pk, self.user.pk, self.role.pk)
        self.assertEqual(user_role.role, self.role)
        self.assertEqual(UserRole.objects.count(), 1)

    def test_duplicate_assignment_rejected(self):
        UserRoleService.assign(self.tenant.pk, self.user.pk, self.role.pk)
        with self.assertRaises(ValidationError):
            UserRoleService.assign(self.tenant.pk, self.user.pk, self.role.pk)


class EntitlementResourceServiceTest(BaseTestCase):
    def setUp(self):
        self.resource = Resource.objects.create(
            resource_code="dashboard", resource_name="Dashboard", resource_type=ResourceType.PAGE
        )

    def test_map_and_duplicate_rejected(self):
        link = EntitlementResourceService.map(EntitlementTier.PREMIUM, self.resource.pk)
        self.assertEqual(link.resource, self.resource)
        with self.assertRaises(ValidationError):
            EntitlementResourceService.map(EntitlementTier.PREMIUM, self.resource.pk)


class CatalogManageTest(BaseTestCase):
    def test_role_presentation_and_is_active_editable(self):
        role = Role.objects.create(role_code="editor", role_name="Editor", is_system_role=False)
        updated = RoleService.update(role.role_uuid, role_name="Editor v2", is_active=False)
        self.assertEqual(updated.role_name, "Editor v2")
        self.assertFalse(updated.is_active)

    def test_system_role_cannot_be_deactivated(self):
        role = tenant_admin_role()
        with self.assertRaises(ValidationError):
            RoleService.update(role.role_uuid, is_active=False)

    def test_system_role_presentation_still_editable(self):
        role = tenant_admin_role()
        updated = RoleService.update(role.role_uuid, role_description="Full tenant admin")
        self.assertEqual(updated.role_description, "Full tenant admin")

    def test_update_serializer_locks_code(self):
        serializer = RoleUpdateSerializer(
            data={"role_code": "hacked", "role_name": "ok"}, partial=True
        )
        serializer.is_valid(raise_exception=True)
        self.assertNotIn("role_code", serializer.validated_data)
        self.assertIn("role_name", serializer.validated_data)

    def test_permission_presentation_editable(self):
        res = Resource.objects.create(
            resource_code="pr", resource_name="PR", resource_type=ResourceType.PAGE
        )
        perm = Permission.objects.create(
            resource=res, permission_type=PermissionType.VIEW,
            permission_code="pr.view", permission_name="View",
        )
        updated = PermissionService.update(perm.permission_uuid, permission_name="View 2", is_active=False)
        self.assertEqual(updated.permission_name, "View 2")
        self.assertFalse(updated.is_active)

    def test_resource_presentation_editable(self):
        res = Resource.objects.create(
            resource_code="rc", resource_name="RC", resource_type=ResourceType.PAGE
        )
        updated = ResourceService.update(res.resource_uuid, resource_name="RC2", display_order=5)
        self.assertEqual(updated.resource_name, "RC2")
        self.assertEqual(updated.display_order, 5)
