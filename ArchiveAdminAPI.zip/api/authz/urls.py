from django.urls import path

from .views import (
    EntitlementResourceDetailView,
    EntitlementResourceListCreateView,
    PermissionDetailView,
    PermissionListView,
    ResourceDetailView,
    ResourceListView,
    RoleDetailView,
    RoleListView,
    UserRoleDetailView,
    UserRoleListCreateView,
)

app_name = "authz"

urlpatterns = [
    # Catalog (read-only)
    path("roles/", RoleListView.as_view(), name="role-list"),
    path("roles/<uuid:role_uuid>/", RoleDetailView.as_view(), name="role-detail"),
    path("permissions/", PermissionListView.as_view(), name="permission-list"),
    path("permissions/<uuid:permission_uuid>/", PermissionDetailView.as_view(), name="permission-detail"),
    path("resources/", ResourceListView.as_view(), name="resource-list"),
    path("resources/<uuid:resource_uuid>/", ResourceDetailView.as_view(), name="resource-detail"),
    # Assignment (CRUD)
    path("user-roles/", UserRoleListCreateView.as_view(), name="user-role-list"),
    path("user-roles/<uuid:user_role_uuid>/", UserRoleDetailView.as_view(), name="user-role-detail"),
    path("entitlement-resources/", EntitlementResourceListCreateView.as_view(), name="entitlement-resource-list"),
    path(
        "entitlement-resources/<int:entitlement_resource_id>/",
        EntitlementResourceDetailView.as_view(),
        name="entitlement-resource-detail",
    ),
]
