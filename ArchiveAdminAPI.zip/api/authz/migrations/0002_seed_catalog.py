from django.db import migrations

# Developer-owned catalog seeded in lockstep with the API service's enforcement
# release. Only the base tenant_admin role ships today; Resource / Permission /
# RolePermission rows are added here as the API service ships enforcement for them.
ROLES = [
    {
        "role_code": "tenant_admin",
        "role_name": "Tenant Administrator",
        "role_description": "Full administrative access within a single tenant.",
        "is_system_role": True,
    },
]


def seed_catalog(apps, schema_editor):
    Role = apps.get_model("authz", "Role")
    for role in ROLES:
        Role.objects.update_or_create(
            role_code=role["role_code"],
            defaults={
                "role_name": role["role_name"],
                "role_description": role["role_description"],
                "is_system_role": role["is_system_role"],
                "is_active": True,
            },
        )


def unseed_catalog(apps, schema_editor):
    Role = apps.get_model("authz", "Role")
    Role.objects.filter(role_code__in=[r["role_code"] for r in ROLES]).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("authz", "0001_initial"),
    ]

    operations = [
        migrations.RunPython(seed_catalog, unseed_catalog),
    ]
