import random

from django.core.management.base import BaseCommand
from faker import Faker

from api.authz.choices import PermissionType, ResourceType
from api.authz.models import Permission, Resource, Role, UserRole
from api.tenant.models import TenantMembership


class Command(BaseCommand):
    help = "Generate fake authz catalog (resources/permissions) and role assignments"

    def add_arguments(self, parser):
        parser.add_argument("--count", type=int, default=8, help="Number of resources (default: 8)")

    def handle(self, *args, **options):
        fake = Faker()
        count = options["count"]

        self.stdout.write(f"Creating {count} fake resources with permissions...")
        for _ in range(count):
            code = fake.unique.bothify(text="res_#####")
            resource = Resource.objects.create(
                resource_code=code,
                resource_name=fake.catch_phrase()[:255],
                resource_type=random.choice(ResourceType.values),
                display_order=random.randint(0, 100),
            )
            for ptype in random.sample(PermissionType.values, k=random.randint(1, 3)):
                Permission.objects.create(
                    resource=resource,
                    permission_type=ptype,
                    permission_code=f"{code}.{ptype}",
                    permission_name=f"{ptype.title()} {resource.resource_name}"[:255],
                )

        assigned = 0
        role = Role.objects.filter(role_code="tenant_admin").first()
        if role is not None:
            for membership in TenantMembership.objects.select_related("tenant", "user")[:count]:
                _, created = UserRole.objects.get_or_create(
                    tenant=membership.tenant, user=membership.user, role=role
                )
                assigned += int(created)

        self.stdout.write(self.style.SUCCESS(
            f"Created {count} resources; assigned tenant_admin to {assigned} memberships."
        ))
