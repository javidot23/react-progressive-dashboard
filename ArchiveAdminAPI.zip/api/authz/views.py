from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.utils import OpenApiResponse, extend_schema, extend_schema_view
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .filters import (
    EntitlementResourceFilter,
    PermissionFilter,
    ResourceFilter,
    UserRoleFilter,
)
from .serializers import (
    EntitlementResourceCreateSerializer,
    EntitlementResourceSerializer,
    PermissionSerializer,
    PermissionUpdateSerializer,
    ResourceSerializer,
    ResourceUpdateSerializer,
    RoleSerializer,
    RoleUpdateSerializer,
    UserRoleCreateSerializer,
    UserRoleSerializer,
)
from .services import (
    EntitlementResourceService,
    PermissionService,
    ResourceService,
    RoleService,
    UserRoleService,
)


# --- Catalog: read-only (seeded via migration, never authored through the API) ---

class RoleListView(generics.ListAPIView):
    serializer_class = RoleSerializer

    def get_queryset(self):
        return RoleService.list()


@extend_schema_view(
    get=extend_schema(responses=RoleSerializer),
    patch=extend_schema(request=RoleUpdateSerializer, responses=RoleSerializer),
)
class RoleDetailView(APIView):
    """Read a role, and manage its presentation + availability. role_code,
    is_system_role, and permission grants stay seed-only (read-only)."""

    def get(self, request, role_uuid):
        return Response(RoleSerializer(RoleService.get(role_uuid)).data)

    def patch(self, request, role_uuid):
        serializer = RoleUpdateSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        role = RoleService.update(role_uuid, **serializer.validated_data)
        return Response(RoleSerializer(role).data)


class PermissionListView(generics.ListAPIView):
    serializer_class = PermissionSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = PermissionFilter

    def get_queryset(self):
        return PermissionService.list()


@extend_schema_view(
    get=extend_schema(responses=PermissionSerializer),
    patch=extend_schema(request=PermissionUpdateSerializer, responses=PermissionSerializer),
)
class PermissionDetailView(APIView):
    """Read a permission, and manage its presentation + availability.
    permission_code, permission_type, and resource stay seed-only."""

    def get(self, request, permission_uuid):
        return Response(PermissionSerializer(PermissionService.get(permission_uuid)).data)

    def patch(self, request, permission_uuid):
        serializer = PermissionUpdateSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        permission = PermissionService.update(permission_uuid, **serializer.validated_data)
        return Response(PermissionSerializer(permission).data)


class ResourceListView(generics.ListAPIView):
    serializer_class = ResourceSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = ResourceFilter

    def get_queryset(self):
        return ResourceService.list()


@extend_schema_view(
    get=extend_schema(responses=ResourceSerializer),
    patch=extend_schema(request=ResourceUpdateSerializer, responses=ResourceSerializer),
)
class ResourceDetailView(APIView):
    """Read a resource, and manage its presentation + availability.
    resource_code, resource_type, and parent_resource stay seed-only."""

    def get(self, request, resource_uuid):
        return Response(ResourceSerializer(ResourceService.get(resource_uuid)).data)

    def patch(self, request, resource_uuid):
        serializer = ResourceUpdateSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        resource = ResourceService.update(resource_uuid, **serializer.validated_data)
        return Response(ResourceSerializer(resource).data)


# --- Assignment: CRUD over existing catalog rows only ---

class UserRoleListCreateView(generics.ListAPIView):
    serializer_class = UserRoleSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = UserRoleFilter

    def get_queryset(self):
        return UserRoleService.list()

    def post(self, request):
        serializer = UserRoleCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user_role = UserRoleService.assign(created_by=request.user, **serializer.validated_data)
        return Response(UserRoleSerializer(user_role).data, status=status.HTTP_201_CREATED)


@extend_schema_view(
    delete=extend_schema(responses={204: OpenApiResponse(description="No content")}),
)
class UserRoleDetailView(APIView):
    def delete(self, request, user_role_uuid):
        UserRoleService.revoke(user_role_uuid)
        return Response(status=status.HTTP_204_NO_CONTENT)


class EntitlementResourceListCreateView(generics.ListAPIView):
    serializer_class = EntitlementResourceSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = EntitlementResourceFilter

    def get_queryset(self):
        return EntitlementResourceService.list()

    def post(self, request):
        serializer = EntitlementResourceCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        link = EntitlementResourceService.map(**serializer.validated_data)
        return Response(EntitlementResourceSerializer(link).data, status=status.HTTP_201_CREATED)


@extend_schema_view(
    delete=extend_schema(responses={204: OpenApiResponse(description="No content")}),
)
class EntitlementResourceDetailView(APIView):
    def delete(self, request, entitlement_resource_id):
        EntitlementResourceService.unmap(entitlement_resource_id)
        return Response(status=status.HTTP_204_NO_CONTENT)
