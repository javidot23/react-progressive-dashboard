from django.db.models import QuerySet
from django.shortcuts import get_object_or_404
from rest_framework.exceptions import ValidationError

from .models import (
    EntitlementResource,
    Permission,
    Resource,
    Role,
    UserRole,
)


def _apply_updates(instance, data):
    """Set only the provided fields on a catalog instance and save those columns.

    Callers pass a serializer's validated_data, which is already restricted to the
    editable (presentation + is_active) fields — codes and grants are never here.
    """
    fields = list(data.keys())
    if not fields:
        return instance
    for field, value in data.items():
        setattr(instance, field, value)
    instance.save(update_fields=fields + ["updated_at"])
    return instance


class RoleService:
    @staticmethod
    def list() -> QuerySet:
        return Role.objects.filter(is_deleted=False).order_by("role_code")

    @staticmethod
    def get(role_uuid) -> Role:
        return get_object_or_404(
            Role.objects.prefetch_related("role_permissions__permission"),
            pk=role_uuid, is_deleted=False,
        )

    @staticmethod
    def update(role_uuid, **data) -> Role:
        role = get_object_or_404(Role, pk=role_uuid, is_deleted=False)
        if role.is_system_role and data.get("is_active") is False:
            raise ValidationError("is_active: a system role cannot be deactivated.")
        return _apply_updates(role, data)


class PermissionService:
    @staticmethod
    def list() -> QuerySet:
        return (
            Permission.objects.filter(is_deleted=False)
            .select_related("resource")
            .order_by("permission_code")
        )

    @staticmethod
    def get(permission_uuid) -> Permission:
        return get_object_or_404(
            Permission.objects.select_related("resource"),
            pk=permission_uuid, is_deleted=False,
        )

    @staticmethod
    def update(permission_uuid, **data) -> Permission:
        return _apply_updates(PermissionService.get(permission_uuid), data)


class ResourceService:
    @staticmethod
    def list() -> QuerySet:
        return Resource.objects.filter(is_deleted=False).order_by("display_order", "resource_code")

    @staticmethod
    def get(resource_uuid) -> Resource:
        return get_object_or_404(Resource, pk=resource_uuid, is_deleted=False)

    @staticmethod
    def update(resource_uuid, **data) -> Resource:
        return _apply_updates(ResourceService.get(resource_uuid), data)


class UserRoleService:
    @staticmethod
    def list() -> QuerySet:
        return (
            UserRole.objects.filter(is_deleted=False)
            .select_related("tenant", "user", "role")
            .order_by("-created_at")
        )

    @staticmethod
    def assign(tenant_uuid, user_uuid, role_uuid, created_by=None) -> UserRole:
        from api.tenant.models import Tenant
        from api.user.models import User

        tenant = get_object_or_404(Tenant, pk=tenant_uuid, is_deleted=False)
        user = get_object_or_404(User, pk=user_uuid, is_deleted=False)
        role = get_object_or_404(Role, pk=role_uuid, is_active=True, is_deleted=False)

        if UserRole.objects.filter(tenant=tenant, user=user, role=role).exists():
            raise ValidationError("role: already assigned to this user in this tenant.")

        return UserRole.objects.create(
            tenant=tenant, user=user, role=role, created_by=created_by
        )

    @staticmethod
    def revoke(user_role_uuid) -> None:
        user_role = get_object_or_404(UserRole, pk=user_role_uuid)
        user_role.delete()


class EntitlementResourceService:
    @staticmethod
    def list() -> QuerySet:
        return (
            EntitlementResource.objects.select_related("resource")
            .order_by("entitlement_tier")
        )

    @staticmethod
    def map(entitlement_tier, resource_uuid) -> EntitlementResource:
        resource = get_object_or_404(Resource, pk=resource_uuid, is_deleted=False)
        if EntitlementResource.objects.filter(
            entitlement_tier=entitlement_tier, resource=resource
        ).exists():
            raise ValidationError("resource: already mapped to this tier.")
        return EntitlementResource.objects.create(
            entitlement_tier=entitlement_tier, resource=resource
        )

    @staticmethod
    def unmap(entitlement_resource_id) -> None:
        link = get_object_or_404(EntitlementResource, pk=entitlement_resource_id)
        link.delete()
