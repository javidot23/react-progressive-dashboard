from rest_framework import serializers

from api.user.models import User
from api.user_feedback.choices import FeedbackStatus
from api.user_feedback.models import UserFeedback


class UserFeedbackSerializer(serializers.ModelSerializer):
    """Serializer for reading user feedback."""

    user = serializers.SerializerMethodField()

    class Meta:
        model = UserFeedback
        fields = [
            'id', 'user', 'feedback', 'module', 'page', 'subtab',
            'status', 'screenshot', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'user', 'created_at', 'updated_at']

    def get_user(self, obj) -> dict | None:
        if obj.user:
            return {
                'id': str(obj.user.user_uuid),
                'first_name': obj.user.first_name,
                'last_name': obj.user.last_name,
            }
        return None


class UserFeedbackStatusUpdateSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=FeedbackStatus.choices)


class FeedbackUserOptionSerializer(serializers.ModelSerializer):
    id = serializers.CharField(source='user_uuid')

    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name']


class UserFeedbackFilterOptionsSerializer(serializers.Serializer):
    users = FeedbackUserOptionSerializer(many=True)
    statuses = serializers.ListField(child=serializers.CharField())
    modules = serializers.ListField(child=serializers.CharField())
    pages = serializers.ListField(child=serializers.CharField())
