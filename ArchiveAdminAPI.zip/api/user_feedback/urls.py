from django.urls import path

from api.user_feedback.views import (
    UserFeedbackDetailView,
    UserFeedbackFilterOptionsView,
    UserFeedbackListView,
)

app_name = 'user_feedback'

urlpatterns = [
    path('', UserFeedbackListView.as_view(), name='list'),
    path('filters/', UserFeedbackFilterOptionsView.as_view(), name='filter-options'),
    path('<int:feedback_id>/', UserFeedbackDetailView.as_view(), name='detail'),
]
