from django.urls import reverse
from rest_framework import status

from api.user_feedback.choices import FeedbackStatus
from api.user_feedback.models import UserFeedback
from tests.BaseTestCase import BaseAPITestCase
from tests.factories import create_admin_user


class UserFeedbackTest(BaseAPITestCase):
    def setUp(self):
        self.user = create_admin_user()
        self.client.force_authenticate(user=self.user, token="test")
        self.feedback = UserFeedback.objects.create(
            user=self.user,
            feedback="Great tool",
            module="orders",
            page="list",
            status=FeedbackStatus.OPEN,
        )

    def test_list(self):
        resp = self.client.get(reverse("user_feedback:list"))
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        data = resp.json().get("data", resp.json())
        self.assertIn("results", data)
        self.assertEqual(len(data["results"]), 1)
        self.assertEqual(data["results"][0]["id"], self.feedback.id)

    def test_create_not_allowed(self):
        resp = self.client.post(
            reverse("user_feedback:list"),
            {"feedback": "Nope", "module": "orders", "page": "list"},
            format="json",
        )
        self.assertEqual(resp.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)

    def test_retrieve(self):
        resp = self.client.get(
            reverse("user_feedback:detail", kwargs={"feedback_id": self.feedback.id}),
        )
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        data = resp.json().get("data", resp.json())
        self.assertEqual(data["id"], self.feedback.id)
        self.assertEqual(data["feedback"], "Great tool")

    def test_patch_status(self):
        resp = self.client.patch(
            reverse("user_feedback:detail", kwargs={"feedback_id": self.feedback.id}),
            {"status": FeedbackStatus.IN_PROGRESS},
            format="json",
        )
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        data = resp.json().get("data", resp.json())
        self.assertEqual(data["status"], FeedbackStatus.IN_PROGRESS)
        self.feedback.refresh_from_db()
        self.assertEqual(self.feedback.status, FeedbackStatus.IN_PROGRESS)

    def test_delete_not_allowed(self):
        resp = self.client.delete(
            reverse("user_feedback:detail", kwargs={"feedback_id": self.feedback.id}),
        )
        self.assertEqual(resp.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)
        self.assertTrue(UserFeedback.objects.filter(id=self.feedback.id).exists())

    def test_filter_options_resolves_user_by_uuid(self):
        resp = self.client.get(reverse("user_feedback:filter-options"))
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        data = resp.json().get("data", resp.json())
        self.assertEqual(data["users"][0]["id"], str(self.user.user_uuid))
        self.assertIn("orders", data["modules"])
