from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.utils import extend_schema, extend_schema_view
from rest_framework import generics
from rest_framework.exceptions import NotFound
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView

from api.user_feedback.models import UserFeedback
from api.user_feedback.serializers import (
    UserFeedbackFilterOptionsSerializer,
    UserFeedbackSerializer,
    UserFeedbackStatusUpdateSerializer,
)
from api.user_feedback.services import UserFeedbackService


class UserFeedbackListView(generics.ListAPIView):
    """GET: List all feedback entries for platform-admin triage."""

    serializer_class = UserFeedbackSerializer
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_fields = ['status', 'module', 'page', 'user']
    ordering_fields = ['created_at', 'updated_at', 'status']
    ordering = ['-created_at']

    def get_queryset(self):
        return UserFeedback.objects.select_related('user').all()


@extend_schema_view(
    get=extend_schema(responses=UserFeedbackSerializer),
    patch=extend_schema(
        request=UserFeedbackStatusUpdateSerializer,
        responses=UserFeedbackSerializer,
    ),
)
class UserFeedbackDetailView(APIView):
    """
    GET: Retrieve a single feedback entry.
    PATCH: Update feedback status for triage.
    """

    def get(self, request, feedback_id):
        instance = UserFeedbackService.get(feedback_id)
        if not instance:
            raise NotFound("Feedback not found")
        return Response(UserFeedbackSerializer(instance).data)

    def patch(self, request, feedback_id):
        instance = UserFeedbackService.get(feedback_id)
        if not instance:
            raise NotFound("Feedback not found")

        serializer = UserFeedbackStatusUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        instance = UserFeedbackService.update_status(
            instance=instance,
            status=serializer.validated_data['status'],
        )
        return Response(UserFeedbackSerializer(instance).data)


@extend_schema_view(get=extend_schema(responses=UserFeedbackFilterOptionsSerializer))
class UserFeedbackFilterOptionsView(APIView):
    """
    GET: Return distinct filter option values derived from existing feedback records,
    intended for populating frontend dropdown filters.
    """

    def get(self, request, *args, **kwargs):
        data = UserFeedbackService.get_filter_options()
        serializer = UserFeedbackFilterOptionsSerializer(data)
        return Response(serializer.data)
