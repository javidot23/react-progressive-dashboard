import logging

from api.user.models import User
from api.user_feedback.models import UserFeedback

logger = logging.getLogger(__name__)


class UserFeedbackService:

    @staticmethod
    def get_filter_options() -> dict:
        qs = UserFeedback.objects.all()

        statuses = list(
            qs.exclude(status__isnull=True)
            .exclude(status='')
            .values_list('status', flat=True)
            .distinct()
            .order_by('status')
        )

        modules = list(
            qs.exclude(module__isnull=True)
            .exclude(module='')
            .values_list('module', flat=True)
            .distinct()
            .order_by('module')
        )

        pages = list(
            qs.exclude(page__isnull=True)
            .exclude(page='')
            .values_list('page', flat=True)
            .distinct()
            .order_by('page')
        )

        user_ids = qs.values_list('user_id', flat=True).distinct()
        users = list(
            User.objects.filter(user_uuid__in=user_ids)
            .order_by('first_name', 'last_name')
        )

        return {
            'users': users,
            'statuses': statuses,
            'modules': modules,
            'pages': pages,
        }

    @staticmethod
    def get(feedback_id: int) -> UserFeedback | None:
        return UserFeedback.objects.filter(id=feedback_id).select_related('user').first()

    @staticmethod
    def update_status(instance: UserFeedback, status: str) -> UserFeedback:
        instance.status = status
        instance.save(update_fields=['status', 'updated_at'])
        logger.info("Updated feedback %s status to %s", instance.id, status)
        return instance
