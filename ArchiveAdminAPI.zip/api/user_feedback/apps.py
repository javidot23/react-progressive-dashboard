from django.apps import AppConfig


class UserFeedbackConfig(AppConfig):
    name = 'api.user_feedback'
