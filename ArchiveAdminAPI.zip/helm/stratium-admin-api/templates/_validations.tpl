{{/* config.settings.production builds a Sentinel-backed Redis cache
     (config/cache.py build_sentinel_cache) and raises at import time if
     REDIS_PASSWORD is missing - unconditionally, regardless of
     replicaCount/workers/autoscaling. Fail the render rather than let this
     reach production silently. config.settings.local uses LocMemCache and
     needs no Redis at all. */}}
{{- define "stratium-admin-api.validateRedis" -}}
{{- $usesSentinelRedis := ne .Values.config.djangoSettingsModule "config.settings.local" -}}
{{- if and $usesSentinelRedis (not .Values.secrets.redisPassword) (not .Values.secrets.existingSecret) -}}
{{- fail "secrets.redisPassword is required unless config.djangoSettingsModule=config.settings.local (config.settings.production builds a Redis Sentinel cache backend that requires REDIS_PASSWORD unconditionally). If secrets.existingSecret is used instead, confirm it contains REDIS_PASSWORD yourself - this check cannot see inside it." -}}
{{- end -}}
{{- end -}}

{{/* Without either a password or Managed Identity, Postgres auth has no credential at all. */}}
{{- define "stratium-admin-api.validatePostgresAuth" -}}
{{- if and (not .Values.config.dbUseManagedIdentity) (not .Values.secrets.postgresPassword) (not .Values.secrets.existingSecret) -}}
{{- fail "secrets.postgresPassword is required unless config.dbUseManagedIdentity=true or secrets.existingSecret is set" -}}
{{- end -}}
{{- end -}}
