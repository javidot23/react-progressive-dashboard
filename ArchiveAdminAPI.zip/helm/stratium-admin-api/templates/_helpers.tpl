{{- define "stratium-admin-api.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "stratium-admin-api.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "stratium-admin-api.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "stratium-admin-api.labels" -}}
helm.sh/chart: {{ include "stratium-admin-api.chart" . }}
{{ include "stratium-admin-api.selectorLabels" . }}
app.kubernetes.io/version: {{ .Values.config.apiVersion | default .Chart.AppVersion | replace "+" "_" | trunc 63 | trimSuffix "-" | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: stratium-admin-portal
{{- end -}}

{{/* Selector labels MUST stay immutable across upgrades - never add version/chart here. */}}
{{- define "stratium-admin-api.selectorLabels" -}}
app.kubernetes.io/name: {{ include "stratium-admin-api.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "stratium-admin-api.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "stratium-admin-api.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "stratium-admin-api.image" -}}
{{- if .Values.image.digest -}}
{{- printf "%s@%s" .Values.image.repository .Values.image.digest -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository (.Values.image.tag | default .Chart.AppVersion) -}}
{{- end -}}
{{- end -}}

{{- define "stratium-admin-api.secretName" -}}
{{- .Values.secrets.existingSecret | default (printf "%s-secret" (include "stratium-admin-api.fullname" .)) -}}
{{- end -}}

{{/* Only used by the migration Job. When existingSecret is set, that Secret is
     managed OUTSIDE this release (created before `helm upgrade` runs), so it is
     already present at install time and needs no hook-scoped copy. When Helm
     renders the Secret itself, the app's copy is a normal (non-hook) resource
     and is NOT guaranteed to exist yet on `helm install` - the migration Job
     must use its own hook-scoped copy instead (see job-migrate-env.yaml). */}}
{{- define "stratium-admin-api.migrateSecretName" -}}
{{- .Values.secrets.existingSecret | default (printf "%s-migrate-env" (include "stratium-admin-api.fullname" .)) -}}
{{- end -}}

{{/* Mirrors migrateSecretName's reasoning: if serviceAccount.create=false the
     app uses an externally-managed SA that already exists pre-install, so the
     migration Job can safely share it. Only the chart-managed SA needs a
     dedicated hook-scoped copy. */}}
{{- define "stratium-admin-api.migrateServiceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- printf "%s-migrate" (include "stratium-admin-api.fullname" .) -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{/* ---- Host / URL derivation: single source of truth so environments only
     set hosts.api / hosts.frontend. Explicit config.* always overrides. ---- */}}

{{- define "stratium-admin-api.probePath" -}}
{{- $prefix := .Values.config.apiPathPrefix | trimAll "/" -}}
{{- if $prefix -}}
{{- printf "/%s/info/" $prefix -}}
{{- else -}}
{{- print "/info/" -}}
{{- end -}}
{{- end -}}

{{- define "stratium-admin-api.ingressPath" -}}
{{- $prefix := .Values.config.apiPathPrefix | trimAll "/" -}}
{{- if $prefix -}}
{{- printf "/%s" $prefix -}}
{{- else -}}
{{- print "/" -}}
{{- end -}}
{{- end -}}

{{- define "stratium-admin-api.frontendHost" -}}
{{- .Values.hosts.frontend | default .Values.hosts.api -}}
{{- end -}}

{{- define "stratium-admin-api.allowedHosts" -}}
{{- .Values.config.djangoAllowedHosts | default .Values.hosts.api -}}
{{- end -}}

{{- define "stratium-admin-api.corsAllowedOrigins" -}}
{{- .Values.config.corsAllowedOrigins | default (printf "https://%s" (include "stratium-admin-api.frontendHost" .)) -}}
{{- end -}}

{{- define "stratium-admin-api.csrfTrustedOrigins" -}}
{{- .Values.config.csrfTrustedOrigins | default (printf "https://%s" .Values.hosts.api) -}}
{{- end -}}

{{- define "stratium-admin-api.frontendUrl" -}}
{{- .Values.config.frontendUrl | default (printf "https://%s" (include "stratium-admin-api.frontendHost" .)) -}}
{{- end -}}

{{- define "stratium-admin-api.oidcCallbackUrl" -}}
{{- $prefix := .Values.config.apiPathPrefix | trimAll "/" -}}
{{- $path := "/login/" -}}
{{- if $prefix -}}{{- $path = printf "/%s/login/" $prefix -}}{{- end -}}
{{- .Values.config.oidcCallbackUrl | default (printf "https://%s%s" .Values.hosts.api $path) -}}
{{- end -}}

{{/* ---- Shared env body: rendered once, consumed by BOTH the app
     ConfigMap/Secret and the migration-hook ConfigMap/Secret so the two
     can never drift out of sync. ---- */}}

{{- define "stratium-admin-api.appEnv" -}}
DJANGO_SETTINGS_MODULE: {{ .Values.config.djangoSettingsModule | quote }}
DJANGO_READ_DOT_ENV_FILE: "false"
API_ENV: {{ .Values.config.apiEnv | quote }}
API_VERSION: {{ .Values.config.apiVersion | default .Chart.AppVersion | quote }}
API_COMMIT_SHA: {{ .Values.config.apiCommitSha | quote }}
API_PATH_PREFIX: {{ .Values.config.apiPathPrefix | quote }}
DJANGO_ALLOWED_HOSTS: {{ include "stratium-admin-api.allowedHosts" . | quote }}
CORS_ALLOWED_ORIGINS: {{ include "stratium-admin-api.corsAllowedOrigins" . | quote }}
CSRF_TRUSTED_ORIGINS: {{ include "stratium-admin-api.csrfTrustedOrigins" . | quote }}
FRONTEND_URL: {{ include "stratium-admin-api.frontendUrl" . | quote }}
OIDC_CALLBACK_URL: {{ include "stratium-admin-api.oidcCallbackUrl" . | quote }}
POSTGRES_HOST: {{ required "config.postgresHost is required" .Values.config.postgresHost | quote }}
POSTGRES_PORT: {{ .Values.config.postgresPort | quote }}
POSTGRES_DB_NAME: {{ .Values.config.postgresDbName | quote }}
POSTGRES_DB_SCHEMA: {{ .Values.config.postgresDbSchema | quote }}
POSTGRES_USER: {{ required "config.postgresUser is required" .Values.config.postgresUser | quote }}
DB_USE_MANAGED_IDENTITY: {{ .Values.config.dbUseManagedIdentity | default false | quote }}
ENTRA_TENANT_ID: {{ required "config.entraTenantId is required" .Values.config.entraTenantId | quote }}
ENTRA_CLIENT_ID: {{ required "config.entraClientId is required" .Values.config.entraClientId | quote }}
ENTRA_REQUIRED_GROUP_ID: {{ required "config.entraRequiredGroupId is required" .Values.config.entraRequiredGroupId | quote }}
CONN_MAX_AGE: {{ .Values.config.connMaxAge | quote }}
SECURE_HSTS_SECONDS: {{ .Values.config.secureHstsSeconds | quote }}
GUNICORN_WORKERS: {{ .Values.gunicorn.workers | quote }}
GUNICORN_THREADS: {{ .Values.gunicorn.threads | quote }}
{{- if ne .Values.config.djangoSettingsModule "config.settings.local" }}
{{- if contains "CHANGEME" (printf "%s %s" .Values.config.redisSentinelMaster (.Values.config.redisSentinelHosts | join ",")) }}
{{- fail "config.redisSentinelMaster/redisSentinelHosts still say CHANGEME - required() accepts that placeholder, and a wrong Sentinel host fails silently because cache.py sets IGNORE_EXCEPTIONS" }}
{{- end }}
REDIS_SENTINEL_MASTER: {{ required "config.redisSentinelMaster is required unless config.djangoSettingsModule=config.settings.local" .Values.config.redisSentinelMaster | quote }}
REDIS_SENTINEL_HOSTS: {{ required "config.redisSentinelHosts is required unless config.djangoSettingsModule=config.settings.local - name the Sentinel release (e.g. stratium-redis), not a standalone Redis release" (.Values.config.redisSentinelHosts | join ",") | quote }}
REDIS_SENTINEL_PORT: {{ .Values.config.redisSentinelPort | quote }}
{{- end }}
{{- if .Values.config.newRelicEnvironment }}
{{- $sections := list "onprem-nonprod" "onprem-stage" "onprem-prod" "azure-dev" "azure-test" "azure-stage" "azure-prod" "local" }}
{{- if not (has .Values.config.newRelicEnvironment $sections) }}
{{- fail (printf "config.newRelicEnvironment %q has no [newrelic:%s] section in the image's newrelic.ini. The agent falls back to the base section and reports nothing, with no error - keep this list in step with that file. Known: %s" .Values.config.newRelicEnvironment .Values.config.newRelicEnvironment (join ", " $sections)) }}
{{- end }}
NEW_RELIC_ENVIRONMENT: {{ .Values.config.newRelicEnvironment | quote }}
{{- end }}
{{- end -}}

{{- define "stratium-admin-api.appSecretEnv" -}}
DJANGO_SECRET_KEY: {{ required "secrets.djangoSecretKey is required" .Values.secrets.djangoSecretKey | quote }}
{{- if not .Values.config.dbUseManagedIdentity }}
POSTGRES_PASSWORD: {{ required "secrets.postgresPassword is required when config.dbUseManagedIdentity is false" .Values.secrets.postgresPassword | quote }}
{{- end }}
ENTRA_CLIENT_SECRET: {{ required "secrets.entraClientSecret is required" .Values.secrets.entraClientSecret | quote }}
{{- if ne .Values.config.djangoSettingsModule "config.settings.local" }}
REDIS_PASSWORD: {{ required "secrets.redisPassword is required when config.djangoSettingsModule is not config.settings.local" .Values.secrets.redisPassword | quote }}
{{- end }}
{{- if .Values.secrets.newRelicLicenseKey }}
NEW_RELIC_LICENSE_KEY: {{ .Values.secrets.newRelicLicenseKey | quote }}
{{- end }}
{{- end -}}
