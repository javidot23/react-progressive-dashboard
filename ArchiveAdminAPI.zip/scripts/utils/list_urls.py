import os
import sys
from pathlib import Path

import django
from django.urls import URLPattern, URLResolver, get_resolver

# Ensure project root is on path when running this script directly
_project_root = Path(__file__).resolve().parent.parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.local")
django.setup()

COMMENT_COLUMN = 45


def _format_line(label, comment):
    if len(label) + 2 > COMMENT_COLUMN:
        return f"{label}  {comment}"
    return f"{label.ljust(COMMENT_COLUMN)}{comment}"


def format_url_tree(urlpatterns, prefix="", depth=0):
    output = []

    for pattern in urlpatterns:
        path = str(pattern.pattern).strip("^$")  # Clean up regex remnants

        if isinstance(pattern, URLResolver):
            full_path = f"{prefix}{path}"

            # An empty-path resolver (e.g. the configurable API prefix when unset)
            # is transparent: fold its children into the current level.
            if path == "":
                output.extend(format_url_tree(pattern.url_patterns, prefix=full_path, depth=depth))
                continue

            normalized = "/" + full_path.rstrip("/") + "/"
            output.append(_format_line(normalized, "# Base endpoint"))
            output.extend(format_url_tree(pattern.url_patterns, prefix=full_path, depth=depth + 1))

        elif isinstance(pattern, URLPattern):
            indent = "    " * depth
            sub_path = path or "[root]"  # If empty, it's the root route of that include
            output.append(_format_line(f"{indent}└── {sub_path}", "# Endpoint"))

    return output


if __name__ == "__main__":
    resolver = get_resolver()
    url_tree = format_url_tree(resolver.url_patterns)
    for line in url_tree:
        print(line)
