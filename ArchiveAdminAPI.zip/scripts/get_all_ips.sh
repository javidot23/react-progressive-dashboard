#!/bin/bash


az config set extension.use_dynamic_install=yes_without_prompt
sudo apt-get install jq -y
HOSTSJSON=$(az vm list-ip-addresses -g ${RESOURCE_GROUP} --subscription ${SUBSCRIPTION_ID} --query '[].{name:virtualMachine.name, ip:virtualMachine.network.privateIpAddresses[0]}' -o json)
OSTYPEJSON=$(az graph query -q "Resources | where type =~ 'Microsoft.Compute/virtualMachines' | project name, properties.storageProfile.osDisk.osType")
echo $HOSTSJSON > ipaddress.json
echo $OSTYPEJSON | jq '."data"' > ostype.json
cat ostype.json | jq '.[] | select(.properties_storageProfile_osDisk_osType=="Windows")' | jq -r '.name' > windows
echo "[windows]" > hosts
LINES=$(cat windows)
for LINE in $LINES
do
    ipline=$(cat ipaddress.json | jq '.[] | select(.name=='\"$LINE\"')' | jq -r '.ip' )
    if [ -n "$ipline" ]
    then
        echo "${ipline} ansible_user=abc ansible_password= ansible_connection=winrm ansible_winrm_server_cert_validation=ignore" >> hosts
    fi
done
cat ostype.json | jq '.[] | select(.properties_storageProfile_osDisk_osType=="Linux")' | jq -r '.name' > linux
echo "[linux]" >> hosts
LINESL=$(cat linux)
for LINEL in $LINESL
do
    iplineL=$(cat ipaddress.json | jq '.[] | select(.name=='\"$LINEL\"')' | jq -r '.ip' )
    if [ -n "$iplineL" ]
    then
        echo "${iplineL} anisble_ssh_user=abc" >> hosts
    fi
done
mkdir inventories
mv hosts inventories/hosts
ls
cat inventories/hosts
