#!/bin/bash
echo $VM_NAME
az config set extension.use_dynamic_install=yes_without_prompt
sudo apt-get install jq -y
if [ "$IP_TYPE" == "public" ]
then
    HOSTSJSON=$(az vm list-ip-addresses -g ${RESOURCE_GROUP_NAME} --subscription ${SUBSCRIPTION_ID} --query '[].{name:virtualMachine.name, ip:virtualMachine.network.publicIpAddresses[0].ipAddress}' -o json)
elif [ "$IP_TYPE" == "private" ]
then
    HOSTSJSON=$(az vm list-ip-addresses -g ${RESOURCE_GROUP_NAME} --subscription ${SUBSCRIPTION_ID} --query '[].{name:virtualMachine.name, ip:virtualMachine.network.privateIpAddresses[0]}' -o json)
else
    echo "IP_TYPE var is not valid. Please specific 'public' or 'private'"
fi
OSTYPEJSON=$(az graph query -q "Resources | where type =~ 'Microsoft.Compute/virtualMachines' | project name, properties.storageProfile.osDisk.osType")
echo $HOSTSJSON > ipaddress.json
echo $OSTYPEJSON | jq '."data"' > ostype.json
cat ostype.json | jq '.[] | select(.properties_storageProfile_osDisk_osType=="Windows")' | jq -r '.name' > windows
cat ostype.json | jq '.[] | select(.properties_storageProfile_osDisk_osType=="Linux")' | jq -r '.name' > linux

LINES=$(cat windows)

for LINE in $LINES
do
    if [ $LINE = "${VM_NAME}" ]
    then

        ipline=$(cat ipaddress.json | jq '.[] | select(.name=='\"$LINE\"')' | jq -r '.ip' )
        if [ -n "$ipline" ]
        then
            echo "[windows]" > hosts
            echo "${ipline} ansible_connection=winrm ansible_user=$ADMIN_USER ansible_password= ansible_winrm_client_cert_validation=ignore" >> hosts
        fi
    fi
done


LINESL=$(cat linux)
for LINEL in $LINESL
do
    if [ $LINEL = "${VM_NAME}" ]
    then

        iplineL=$(cat ipaddress.json | jq '.[] | select(.name=='\"$LINEL\"')' | jq -r '.ip' )
        if [ -n "$iplineL" ]
        then
            echo "[linux]" >> hosts
            echo "${iplineL} ansible_ssh_user=$ADMIN_USER" >> hosts
        fi
    fi
done
mkdir inventories
mv hosts inventories/hosts
cat inventories/hosts
