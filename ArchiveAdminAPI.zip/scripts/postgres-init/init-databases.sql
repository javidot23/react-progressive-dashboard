-- Executed once, only when the postgres_data volume is first initialised.
-- POSTGRES_DB (stratium_users) is created by the image itself; this adds the
-- database the test suite and CI expect. See .github/workflows/ci.yaml.
CREATE DATABASE test_stratium_users_db;
