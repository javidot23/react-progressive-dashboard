#!/bin/bash
# Change to project root directory
cd "$(dirname "$0")/../.." || exit 1

python3 manage.py migrate
