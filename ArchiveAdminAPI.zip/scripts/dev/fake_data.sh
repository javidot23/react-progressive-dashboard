#!/bin/bash
# Seed the shared core DB with mock data for local development.
# Order matters: tenants and users first, then memberships/roles, then settings.
cd "$(dirname "$0")/../.." || exit 1

python3 manage.py fake_tenants --count 10
python3 manage.py fake_users --count 20
python3 manage.py fake_authz --count 8          # resources/permissions + tenant_admin assignments
python3 manage.py fake_user_settings --count 20
