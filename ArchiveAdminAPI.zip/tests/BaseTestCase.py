"""Base test classes for the shared core database."""
from django.test import TestCase, TransactionTestCase
from rest_framework.test import APITestCase


class BaseTestCase(TestCase):
    """Base test case for the single shared core database."""
    databases = ['default']


class BaseAPITestCase(APITestCase):
    """Base API test case for the single shared core database."""
    databases = ['default']


class BaseTransactionTestCase(TransactionTestCase):
    """Base transaction test case for the single shared core database."""
    databases = ['default']
