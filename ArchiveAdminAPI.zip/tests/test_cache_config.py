from unittest import TestCase

from config.cache import build_sentinel_cache


class SentinelCacheConfigTests(TestCase):
    def test_builds_authenticated_sentinel_cache(self):
        caches = build_sentinel_cache(
            key_prefix="stratium_1.0",
            timeout=3600,
            password="secret",
            master="stratium-master",
            sentinel_hosts=["stratium-redis", "stratium-redis-backup"],
        )

        cache = caches["default"]
        options = cache["OPTIONS"]

        self.assertEqual(cache["LOCATION"], "redis://stratium-master/0")
        self.assertNotIn("KEY_FUNCTION", cache)
        self.assertEqual(
            options["SENTINELS"],
            [("stratium-redis", 26379), ("stratium-redis-backup", 26379)],
        )
        self.assertEqual(options["SENTINEL_KWARGS"], {"password": "secret"})
        self.assertEqual(options["PASSWORD"], "secret")
        self.assertTrue(options["IGNORE_EXCEPTIONS"])
        self.assertNotIn("IGNORE_EXCEPTIONS", cache)

    def test_rejects_missing_password(self):
        with self.assertRaisesRegex(
            ValueError,
            "REDIS_PASSWORD is required for Sentinel cache",
        ):
            build_sentinel_cache(
                key_prefix="stratium_1.0",
                timeout=3600,
                password="",
                master="stratium-master",
                sentinel_hosts=["stratium-redis"],
            )
