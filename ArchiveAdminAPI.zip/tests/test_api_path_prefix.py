import importlib

from django.conf import settings
from django.test import SimpleTestCase
from django.test import override_settings
from django.urls import clear_url_caches
from django.urls import reverse

from config.settings.base import normalize_api_path_prefix


class ApiPathPrefixTests(SimpleTestCase):
    def tearDown(self):
        self._reload_urls(settings.API_PATH_PREFIX)
        super().tearDown()

    @staticmethod
    def _reload_urls(api_path_prefix):
        with override_settings(API_PATH_PREFIX=api_path_prefix):
            import config.urls

            importlib.reload(config.urls)
            clear_url_caches()

    def test_normalizes_api_path_prefix(self):
        self.assertEqual(normalize_api_path_prefix(None), "")
        self.assertEqual(normalize_api_path_prefix(""), "")
        self.assertEqual(normalize_api_path_prefix("/"), "")
        self.assertEqual(normalize_api_path_prefix(" /api/acme/ "), "api/acme")

    def test_default_api_path_prefix(self):
        self._reload_urls("api")

        self.assertEqual(
            reverse("tenant:tenant-list"),
            "/api/tenants/",
        )

    def test_empty_api_path_prefix(self):
        self._reload_urls("")

        self.assertEqual(
            reverse("tenant:tenant-list"),
            "/tenants/",
        )

    def test_extended_api_path_prefix(self):
        self._reload_urls("api/acme")

        self.assertEqual(
            reverse("tenant:tenant-list"),
            "/api/acme/tenants/",
        )
