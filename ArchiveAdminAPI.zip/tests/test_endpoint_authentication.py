from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework.response import Response
from rest_framework.test import APIRequestFactory
from rest_framework.views import APIView

from config.checks import (
    PUBLIC_VIEWS,
    caches_before_authentication,
    check_cache_before_authentication,
    check_endpoint_authentication,
    dotted_path,
    iter_api_views,
)
from tests.BaseTestCase import BaseAPITestCase

UNAUTHENTICATED = {"HTTP_X_DISABLE_TEST_AUTH": "1"}


@method_decorator(cache_page(60), name="dispatch")
class _CacheOnDispatch(APIView):
    def get(self, request):
        return Response({})


@method_decorator(cache_page(60), name="get")
class _CacheOnHandler(APIView):
    def get(self, request):
        return Response({})


class EndpointAuthenticationTest(BaseAPITestCase):
    def test_no_endpoint_disables_authentication(self):
        errors = check_endpoint_authentication(app_configs=None)
        self.assertEqual(errors, [], "\n".join(str(e) for e in errors))

    def test_no_endpoint_caches_before_authentication(self):
        errors = check_cache_before_authentication(app_configs=None)
        self.assertEqual(errors, [], "\n".join(str(e) for e in errors))

    def test_allowlist_has_no_dead_entries(self):
        routed = {dotted_path(view_cls) for _, view_cls, _ in iter_api_views()}
        self.assertEqual(PUBLIC_VIEWS - routed, set())

    def test_cache_detector_distinguishes_dispatch_from_handler(self):
        self.assertTrue(caches_before_authentication(_CacheOnDispatch))
        self.assertFalse(caches_before_authentication(_CacheOnHandler))

    def test_unauthenticated_requests_are_rejected(self):
        factory = APIRequestFactory()
        for route, view_cls, callback in iter_api_views():
            dotted = dotted_path(view_cls)
            if dotted in PUBLIC_VIEWS:
                continue
            response = callback(factory.get("/", **UNAUTHENTICATED))
            self.assertIn(
                response.status_code,
                (401, 403),
                f"/{route} ({dotted}) accepted an unauthenticated request "
                f"(status {response.status_code})",
            )
