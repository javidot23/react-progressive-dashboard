"""Test-only authentication support. Must not be enabled when DEBUG=False."""

from rest_framework.authentication import BaseAuthentication

from api.user.choices import AuthProvider, UserStatus
from api.user.models import User, UserIdentity


class TestAutoAuthentication(BaseAuthentication):
    """
    Test-only authentication backend that auto-authenticates requests.

    - Returns None (no auth) when header "X-Disable-Test-Auth: 1" is present so
      tests can explicitly exercise 401 flows.
    - Otherwise authenticates as a deterministic platform-admin test user.

    Enabled only via config.settings.test. IdentityConfig.ready() refuses to boot
    if this class is configured while DEBUG is False.
    """

    def authenticate(self, request):
        disable_header = request.META.get("HTTP_X_DISABLE_TEST_AUTH")
        if disable_header and str(disable_header).lower() in {"1", "true", "yes"}:
            return None

        subject = "test-entra-subject"
        identity = (
            UserIdentity.objects
            .select_related('user')
            .filter(auth_provider=AuthProvider.ENTRA_ID, auth_subject=subject)
            .first()
        )
        if identity is not None:
            return (identity.user, "test")

        user = User.objects.create_user(
            display_name="Test User",
            first_name="Test",
            last_name="User",
            is_platform_admin=True,
            status=UserStatus.ACTIVE,
        )
        UserIdentity.objects.create(
            user=user,
            email="test.user@example.com",
            auth_provider=AuthProvider.ENTRA_ID,
            auth_subject=subject,
            is_primary=True,
        )
        return (user, "test")
