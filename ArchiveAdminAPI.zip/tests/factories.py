"""Lightweight object factories for the shared core database tests."""
from api.authz.models import Role
from api.tenant.choices import EntitlementTier, TenantType
from api.tenant.models import Tenant, TenantDomain, TenantMembership
from api.user.choices import AuthProvider, UserStatus
from api.user.models import User, UserIdentity


def create_admin_user(email="admin@cencora.com", subject="entra-subject-1", **kwargs):
    """Create an active platform-admin User with a primary Entra identity."""
    user = User.objects.create_user(
        display_name=kwargs.pop("display_name", "Admin User"),
        first_name=kwargs.pop("first_name", "Admin"),
        last_name=kwargs.pop("last_name", "User"),
        is_platform_admin=True,
        status=UserStatus.ACTIVE,
        **kwargs,
    )
    UserIdentity.objects.create(
        user=user,
        email=email,
        auth_provider=AuthProvider.ENTRA_ID,
        auth_subject=subject,
        is_primary=True,
    )
    return user


def create_tenant(code="TEN-001", name="Acme", tenant_type=TenantType.CUSTOMER,
                  tier=EntitlementTier.STANDARD, **kwargs):
    return Tenant.objects.create(
        tenant_code=code, tenant_name=name, tenant_type=tenant_type,
        entitlement_tier=tier, **kwargs,
    )


def add_membership(user, tenant, **kwargs):
    return TenantMembership.objects.create(user=user, tenant=tenant, **kwargs)


def add_domain(tenant, domain):
    return TenantDomain.objects.create(tenant=tenant, domain=domain)


def tenant_admin_role():
    return Role.objects.get(role_code="tenant_admin")
