import "./InputSizeMediumDefaultHasValueFalseStateDefault.css";
import { Calendar } from "../Calendar/Calendar.jsx";
import { CdsIconMediumStrokeSizeXl20Px } from "../CdsIconMediumStrokeSizeXl20Px/CdsIconMediumStrokeSizeXl20Px.jsx";
import { CdsButtonIconActionSecondaryDefaultAppearanceInlineButtonSizeMediumDefaultIconSizeMinimumDefaultStateDefault } from "../CdsButtonIconActionSecondaryDefaultAppearanceInlineButtonSizeMediumDefaultIconSizeMinimumDefaultStateDefault/CdsButtonIconActionSecondaryDefaultAppearanceInlineButtonSizeMediumDefaultIconSizeMinimumDefaultStateDefault.jsx";

export const InputSizeMediumDefaultHasValueFalseStateDefault = ({
  hasButtonIcon = true,
  hasIconLeft = true,
  hasIconRight = true,
  hasPlaceholder = true,
  placeholderText = "Text placeholder",
  valueText = "Text value",
  size = "medium-default",
  hasValue = "false",
  state = "default",
  className,
  ...props
}) => {
  const variantsClassName =
    "size-" + size + " has-value-" + hasValue + " state-" + state;

  return (
    <div
      className={
        "input-size-medium-default-has-value-false-state-default " +
        className +
        " " +
        variantsClassName
      }
    >
      <div className="layout-left">
        {hasIconLeft && (
          <>
            <CdsIconMediumStrokeSizeXl20Px
              icon={<Calendar className="svg-instance" />}
              size="xl-20-px"
              className="icon-left-instance"
            ></CdsIconMediumStrokeSizeXl20Px>
          </>
        )}
        {hasPlaceholder && (
          <>
            <div className="placeholder">
              <div className="string">{placeholderText} </div>
            </div>
          </>
        )}
      </div>
      {hasIconRight && (
        <>
          <CdsIconMediumStrokeSizeXl20Px
            icon={<Calendar className="svg-instance" />}
            size="xl-20-px"
            className="icon-right-instance"
          ></CdsIconMediumStrokeSizeXl20Px>
        </>
      )}
      {hasButtonIcon && (
        <>
          <CdsButtonIconActionSecondaryDefaultAppearanceInlineButtonSizeMediumDefaultIconSizeMinimumDefaultStateDefault
            appearance="inline"
            className="button-icon-instance"
          ></CdsButtonIconActionSecondaryDefaultAppearanceInlineButtonSizeMediumDefaultIconSizeMinimumDefaultStateDefault>
        </>
      )}
    </div>
  );
};
