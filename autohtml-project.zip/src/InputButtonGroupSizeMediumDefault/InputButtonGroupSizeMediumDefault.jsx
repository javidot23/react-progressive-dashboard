import "./InputButtonGroupSizeMediumDefault.css";
import { InputSizeMediumDefaultHasValueFalseStateDefault } from "../InputSizeMediumDefaultHasValueFalseStateDefault/InputSizeMediumDefaultHasValueFalseStateDefault.jsx";
import { CdsButtonActionPrimaryAppearanceFillSizeMediumDefaultStateDefault } from "../CdsButtonActionPrimaryAppearanceFillSizeMediumDefaultStateDefault/CdsButtonActionPrimaryAppearanceFillSizeMediumDefaultStateDefault.jsx";

export const InputButtonGroupSizeMediumDefault = ({
  size = "medium-default",
  className,
  ...props
}) => {
  const variantsClassName = "size-" + size;

  return (
    <div
      className={
        "input-button-group-size-medium-default " +
        className +
        " " +
        variantsClassName
      }
    >
      <InputSizeMediumDefaultHasValueFalseStateDefault className="input-instance"></InputSizeMediumDefaultHasValueFalseStateDefault>
      <CdsButtonActionPrimaryAppearanceFillSizeMediumDefaultStateDefault
        label="Submit"
        action="primary"
        appearance="fill"
        className="submit-button-instance"
      ></CdsButtonActionPrimaryAppearanceFillSizeMediumDefaultStateDefault>
    </div>
  );
};
