import "./CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected.css";
import { Calendar } from "../Calendar/Calendar.jsx";
import { CdsIconMediumStrokeSizeXl20Px } from "../CdsIconMediumStrokeSizeXl20Px/CdsIconMediumStrokeSizeXl20Px.jsx";
import { CdsBadgeVariantNeutralDefaultAppearanceLightDefaultSizeSmallPulseFalse } from "../CdsBadgeVariantNeutralDefaultAppearanceLightDefaultSizeSmallPulseFalse/CdsBadgeVariantNeutralDefaultAppearanceLightDefaultSizeSmallPulseFalse.jsx";
import { InformationCircle } from "../InformationCircle/InformationCircle.jsx";
import { CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault } from "../CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault/CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault.jsx";
import { ArrowDown1 } from "../ArrowDown1/ArrowDown1.jsx";
import { CdsIconMediumStrokeSizeMd16Px } from "../CdsIconMediumStrokeSizeMd16Px/CdsIconMediumStrokeSizeMd16Px.jsx";

export const CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected =
  ({
    hasIconLeft = false,
    hasBadgeLeft = false,
    hasBadgeRight = false,
    label = "Tab label",
    hasTooltip = false,
    hasSubmenu = false,
    hasLabel = true,
    hasBadge = false,
    type = "secondary-default",
    placement = "top-default",
    layout = "inline-default",
    state = "default",
    className,
    ...props
  }) => {
    const variantsClassName =
      "type-" +
      type +
      " placement-" +
      placement +
      " layout-" +
      layout +
      " state-" +
      state;

    return (
      <div
        className={
          "cds-tab-item-type-secondary-default-placement-top-default-layout-inline-default-state-active-selected " +
          className +
          " " +
          variantsClassName
        }
      >
        {hasIconLeft && (
          <>
            <CdsIconMediumStrokeSizeXl20Px
              icon={<Calendar className="svg-instance" />}
              size="xl-20-px"
              className="icon-left-instance"
            ></CdsIconMediumStrokeSizeXl20Px>
          </>
        )}
        {hasBadgeLeft && (
          <>
            <CdsBadgeVariantNeutralDefaultAppearanceLightDefaultSizeSmallPulseFalse
              size="small"
              className="badge-left-instance"
            ></CdsBadgeVariantNeutralDefaultAppearanceLightDefaultSizeSmallPulseFalse>
          </>
        )}
        {hasLabel && (
          <>
            <div className="tab-label">{label} </div>
          </>
        )}
        {hasBadgeRight && (
          <>
            <CdsBadgeVariantNeutralDefaultAppearanceLightDefaultSizeSmallPulseFalse
              size="small"
              className="badge-right-instance"
            ></CdsBadgeVariantNeutralDefaultAppearanceLightDefaultSizeSmallPulseFalse>
          </>
        )}
        {hasTooltip && (
          <>
            <CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault
              action="primary"
              appearance="inline"
              buttonSize="small"
              iconsvg={
                <InformationCircle className="information-circle-instance" />
              }
              className="tooltip-icon-instance"
            ></CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault>
          </>
        )}
        {hasSubmenu && (
          <>
            <CdsIconMediumStrokeSizeMd16Px
              icon={<ArrowDown1 className="svg-instance2" />}
              size="md-16-px"
              className="submenu-icon-instance"
            ></CdsIconMediumStrokeSizeMd16Px>
          </>
        )}
      </div>
    );
  };
