import "./Helper.css";
import { AlertDiamond } from "../AlertDiamond/AlertDiamond.jsx";
import { CdsIconMediumStrokeSizeMd16Px } from "../CdsIconMediumStrokeSizeMd16Px/CdsIconMediumStrokeSizeMd16Px.jsx";
import { Check1 } from "../Check1/Check1.jsx";

export const Helper = ({
  hasErrorStatus = false,
  hasSuccessStatus = false,
  hasHelperInfo = true,
  helperInfo = "Helper text",
  successInfo = "Success text",
  errorInfo = "Error text",
  hasStatusIcon = true,
  className,
  ...props
}) => {
  return (
    <div className={"helper " + className}>
      {hasErrorStatus && (
        <>
          <div className="error">
            {hasStatusIcon && (
              <>
                <CdsIconMediumStrokeSizeMd16Px
                  icon={<AlertDiamond className="alert-diamond-instance" />}
                  size="md-16-px"
                  className="error-icon-instance"
                ></CdsIconMediumStrokeSizeMd16Px>
              </>
            )}
            <div className="error-text">{errorInfo} </div>
          </div>
        </>
      )}
      {hasSuccessStatus && (
        <>
          <div className="success">
            {hasStatusIcon && (
              <>
                <CdsIconMediumStrokeSizeMd16Px
                  icon={<Check1 className="check-1-instance" />}
                  size="md-16-px"
                  className="success-icon-instance"
                ></CdsIconMediumStrokeSizeMd16Px>
              </>
            )}
            <div className="success-text">{successInfo} </div>
          </div>
        </>
      )}
      {hasHelperInfo && (
        <>
          <div className="helper2">
            <div className="helper-text">{helperInfo} </div>
          </div>
        </>
      )}
    </div>
  );
};
