import "./CdsBadgeVariantNeutralDefaultAppearanceLightDefaultSizeSmallPulseFalse.css";
import { AlarmBell } from "../AlarmBell/AlarmBell.jsx";
import { CdsIconSemiboldStrokeSize2Xs12Px } from "../CdsIconSemiboldStrokeSize2Xs12Px/CdsIconSemiboldStrokeSize2Xs12Px.jsx";

export const CdsBadgeVariantNeutralDefaultAppearanceLightDefaultSizeSmallPulseFalse =
  ({
    hasIconLeft = false,
    hasIconRight = false,
    smallLabel = "1",
    label = "Badge label",
    variant = "neutral-default",
    appearance = "light-default",
    size = "medium-default",
    pulse = "false",
    className,
    ...props
  }) => {
    const variantsClassName =
      "variant-" +
      variant +
      " appearance-" +
      appearance +
      " size-" +
      size +
      " pulse-" +
      pulse;

    return (
      <div
        className={
          "cds-badge-variant-neutral-default-appearance-light-default-size-small-pulse-false " +
          className +
          " " +
          variantsClassName
        }
      >
        {hasIconLeft && (
          <>
            <CdsIconSemiboldStrokeSize2Xs12Px
              icon={<AlarmBell className="alarm-bell-instance" />}
              size="2-xs-12-px"
              className="icon-left-instance"
            ></CdsIconSemiboldStrokeSize2Xs12Px>
          </>
        )}
        <div className="badge-label">{smallLabel} </div>
        {hasIconRight && (
          <>
            <CdsIconSemiboldStrokeSize2Xs12Px
              icon={<AlarmBell className="alarm-bell-instance" />}
              size="2-xs-12-px"
              className="icon-right-instance"
            ></CdsIconSemiboldStrokeSize2Xs12Px>
          </>
        )}
      </div>
    );
  };
