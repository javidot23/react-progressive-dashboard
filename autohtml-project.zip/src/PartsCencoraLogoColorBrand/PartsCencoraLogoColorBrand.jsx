import "./PartsCencoraLogoColorBrand.css";

export const PartsCencoraLogoColorBrand = ({
  color = "brand",
  className,
  ...props
}) => {
  const variantsClassName = "color-" + color;

  return (
    <div
      className={
        "parts-cencora-logo-color-brand " + className + " " + variantsClassName
      }
    >
      <img className="cencora-logo" src="cencora-logo0.svg" />
    </div>
  );
};
