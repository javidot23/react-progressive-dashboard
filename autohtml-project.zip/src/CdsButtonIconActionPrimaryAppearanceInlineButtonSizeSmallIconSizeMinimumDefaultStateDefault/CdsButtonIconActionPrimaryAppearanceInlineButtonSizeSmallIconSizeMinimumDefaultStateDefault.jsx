import "./CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault.css";
import { Calendar2 } from "../Calendar2/Calendar2.jsx";
import { CdsIconStrokeSize416PxStrokeWidthMediumDefault } from "../CdsIconStrokeSize416PxStrokeWidthMediumDefault/CdsIconStrokeSize416PxStrokeWidthMediumDefault.jsx";

export const CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault =
  ({
    action = "secondary-default",
    appearance = "clear-default",
    buttonSize = "medium-default",
    iconSize = "minimum-default",
    state = "default",
    className,
    ...props
  }) => {
    const variantsClassName =
      "action-" +
      action +
      " appearance-" +
      appearance +
      " button-size-" +
      buttonSize +
      " icon-size-" +
      iconSize +
      " state-" +
      state;

    return (
      <div
        className={
          "cds-button-icon-action-primary-appearance-inline-button-size-small-icon-size-minimum-default-state-default " +
          className +
          " " +
          variantsClassName
        }
      >
        <CdsIconStrokeSize416PxStrokeWidthMediumDefault
          svg={<Calendar2 className="svg-instance" />}
          className="icon-instance"
        ></CdsIconStrokeSize416PxStrokeWidthMediumDefault>
      </div>
    );
  };
