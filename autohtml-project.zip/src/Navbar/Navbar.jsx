import "./Navbar.css";
import { CdsTabsTypeSecondaryDefaultPlacementTopDefaultTabLayoutInlineDefault } from "../CdsTabsTypeSecondaryDefaultPlacementTopDefaultTabLayoutInlineDefault/CdsTabsTypeSecondaryDefaultPlacementTopDefaultTabLayoutInlineDefault.jsx";
import { PartsSearchWidthFill } from "../PartsSearchWidthFill/PartsSearchWidthFill.jsx";
import { CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault } from "../CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault/CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault.jsx";
import { PartsCencoraLogoColorBrand } from "../PartsCencoraLogoColorBrand/PartsCencoraLogoColorBrand.jsx";
import { PartsHamburgerMenuShowCloseFalse } from "../PartsHamburgerMenuShowCloseFalse/PartsHamburgerMenuShowCloseFalse.jsx";
import { CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault } from "../CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault/CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault.jsx";
import { CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected } from "../CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected/CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected.jsx";

export const Navbar = ({
  hamburgerMenu = false,
  brandLogo = true,
  brandName = false,
  brandLabel = "[Name]",
  navigation = true,
  navigationSlot = (
    <CdsTabsTypeSecondaryDefaultPlacementTopDefaultTabLayoutInlineDefault
      className="cds-tabs-instance"
      hasDivider={false}
    />
  ),
  search = true,
  searchSlot = <PartsSearchWidthFill className="parts-search-instance" />,
  utilities = true,
  actionSlot1 = (
    <CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault
      className="cds-button-stacked-instance"
      label="Alerts"
      appearance="text"
      size="small"
    />
  ),
  actionSlot2 = (
    <CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault
      className="cds-button-stacked-instance"
      label="Account"
      appearance="text"
      size="small"
    />
  ),
  actionSlot3 = (
    <CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault
      className="cds-button-stacked-instance"
      label="Cart"
      appearance="text"
      size="small"
    />
  ),
  actionSlot4 = (
    <CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault
      className="cds-button-stacked-instance"
      label="Support"
      appearance="text"
      size="small"
    />
  ),
  brandLogoSlot = (
    <PartsCencoraLogoColorBrand className="brand-logo-slot-instance" />
  ),
  actionSlot5 = (
    <CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault
      className="cds-button-stacked-instance"
      label="Settings"
      appearance="text"
      size="small"
    />
  ),
  actionSlot6 = (
    <CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault
      className="cds-button-stacked-instance"
      label="More"
      appearance="text"
      size="small"
    />
  ),
  showAction1 = true,
  showAction2 = true,
  showAction3 = true,
  showAction4 = false,
  showAction5 = false,
  showAction6 = false,
  className,
  ...props
}) => {
  return (
    <div className={"navbar " + className}>
      <div className="content">
        {hamburgerMenu && (
          <>
            <PartsHamburgerMenuShowCloseFalse className="parts-hamburger-menu-instance"></PartsHamburgerMenuShowCloseFalse>
          </>
        )}
        {brandLogo && (
          <>
            <div className="logo-hyperlink">{brandLogoSlot}</div>
          </>
        )}
        {brandName && (
          <>
            <div className="name-hyperlink">
              <div className="name">{brandLabel} </div>
            </div>
          </>
        )}
        {navigation && (
          <>
            <div className="navigation">{navigationSlot}</div>
          </>
        )}
        {search && <>{searchSlot}</>}
        {utilities && (
          <>
            <div className="utilities">
              {showAction1 && <>{actionSlot1}</>}
              {showAction2 && <>{actionSlot2}</>}
              {showAction3 && <>{actionSlot3}</>}
              {showAction4 && <>{actionSlot4}</>}
              {showAction5 && <>{actionSlot5}</>}
              {showAction6 && <>{actionSlot6}</>}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
