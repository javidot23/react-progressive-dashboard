import "./Search.css";

export const Search = ({ className, ...props }) => {
  return (
    <div className={"search " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
