import "./ArrowDown1.css";

export const ArrowDown1 = ({ className, ...props }) => {
  return (
    <div className={"arrow-down-1 " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
