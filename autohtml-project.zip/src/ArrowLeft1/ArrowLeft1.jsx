import "./ArrowLeft1.css";

export const ArrowLeft1 = ({ className, ...props }) => {
  return (
    <div className={"arrow-left-1 " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
