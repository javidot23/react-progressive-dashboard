import "./InformationCircle.css";

export const InformationCircle = ({ className, ...props }) => {
  return (
    <div className={"information-circle " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
