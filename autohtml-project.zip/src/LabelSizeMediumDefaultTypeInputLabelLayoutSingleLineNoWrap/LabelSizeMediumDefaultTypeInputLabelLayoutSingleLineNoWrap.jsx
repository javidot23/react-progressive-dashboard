import "./LabelSizeMediumDefaultTypeInputLabelLayoutSingleLineNoWrap.css";
import { InformationCircle } from "../InformationCircle/InformationCircle.jsx";
import { CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault } from "../CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault/CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault.jsx";

export const LabelSizeMediumDefaultTypeInputLabelLayoutSingleLineNoWrap = ({
  labelText = "Input label",
  isRequired = false,
  hasTooltip = false,
  labelContent = "Check label",
  size = "medium-default",
  type = "input-label",
  layout = "single-line-no-wrap",
  className,
  ...props
}) => {
  const variantsClassName =
    "size-" + size + " type-" + type + " layout-" + layout;

  return (
    <div
      className={
        "label-size-medium-default-type-input-label-layout-single-line-no-wrap " +
        className +
        " " +
        variantsClassName
      }
    >
      <div className="label">
        {isRequired && (
          <>
            <div className="label-required">
              <div className="label-required2">* </div>
            </div>
          </>
        )}
        <div className="label-value">{labelText} </div>
      </div>
      {hasTooltip && (
        <>
          <CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault
            action="primary"
            appearance="inline"
            buttonSize="small"
            iconsvg={
              <InformationCircle className="information-circle-instance" />
            }
            className="label-tooltip-instance"
          ></CdsButtonIconActionPrimaryAppearanceInlineButtonSizeSmallIconSizeMinimumDefaultStateDefault>
        </>
      )}
    </div>
  );
};
