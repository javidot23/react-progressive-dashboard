import "./AlertDiamond.css";

export const AlertDiamond = ({ className, ...props }) => {
  return (
    <div className={"alert-diamond " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
