import "./Calendar2.css";

export const Calendar2 = ({ className, ...props }) => {
  return (
    <div className={"calendar-2 " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
