import "./CdsIconMediumStrokeSizeXl20Px.css";
import { Calendar } from "../Calendar/Calendar.jsx";

export const CdsIconMediumStrokeSizeXl20Px = ({
  icon = <Calendar className="svg-instance" />,
  size = "2-xl-24-px",
  className,
  ...props
}) => {
  const variantsClassName = "size-" + size;

  return (
    <div
      className={
        "cds-icon-medium-stroke-size-xl-20-px " +
        className +
        " " +
        variantsClassName
      }
    >
      {icon}
    </div>
  );
};
