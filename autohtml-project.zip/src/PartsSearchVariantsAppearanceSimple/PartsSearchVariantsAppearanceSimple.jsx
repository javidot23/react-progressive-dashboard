import "./PartsSearchVariantsAppearanceSimple.css";
import { Search } from "../Search/Search.jsx";
import { CdsInputInputTypeSearchSizeMediumDefaultHasValueFalseHasSubmitButtonTrue } from "../CdsInputInputTypeSearchSizeMediumDefaultHasValueFalseHasSubmitButtonTrue/CdsInputInputTypeSearchSizeMediumDefaultHasValueFalseHasSubmitButtonTrue.jsx";

export const PartsSearchVariantsAppearanceSimple = ({
  appearance = "simple",
  className,
  ...props
}) => {
  const variantsClassName = "appearance-" + appearance;

  return (
    <div
      className={
        "parts-search-variants-appearance-simple " +
        className +
        " " +
        variantsClassName
      }
    >
      <CdsInputInputTypeSearchSizeMediumDefaultHasValueFalseHasSubmitButtonTrue
        hasLabel={false}
        inputType="search"
        hasSubmitButton="true"
        iconsvg={<Search className="search-instance" />}
        iconsize="5-20-px"
        className="search-input-instance"
      ></CdsInputInputTypeSearchSizeMediumDefaultHasValueFalseHasSubmitButtonTrue>
    </div>
  );
};
