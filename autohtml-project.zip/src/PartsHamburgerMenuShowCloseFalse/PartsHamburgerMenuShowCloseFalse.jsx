import "./PartsHamburgerMenuShowCloseFalse.css";
import { NavigationMenu } from "../NavigationMenu/NavigationMenu.jsx";
import { CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeMediumDefaultIconSizeMaximumStateDefault } from "../CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeMediumDefaultIconSizeMaximumStateDefault/CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeMediumDefaultIconSizeMaximumStateDefault.jsx";

export const PartsHamburgerMenuShowCloseFalse = ({
  showClose = "false",
  className,
  ...props
}) => {
  const variantsClassName = "show-close-" + showClose;

  return (
    <div
      className={
        "parts-hamburger-menu-show-close-false " +
        className +
        " " +
        variantsClassName
      }
    >
      <CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeMediumDefaultIconSizeMaximumStateDefault
        iconSize="maximum"
        iconsvg={<NavigationMenu className="navigation-menu-instance" />}
        iconsize="6-24-px"
        className="cds-button-icon-instance"
      ></CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeMediumDefaultIconSizeMaximumStateDefault>
    </div>
  );
};
