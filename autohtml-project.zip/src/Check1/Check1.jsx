import "./Check1.css";

export const Check1 = ({ className, ...props }) => {
  return (
    <div className={"check-1 " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
