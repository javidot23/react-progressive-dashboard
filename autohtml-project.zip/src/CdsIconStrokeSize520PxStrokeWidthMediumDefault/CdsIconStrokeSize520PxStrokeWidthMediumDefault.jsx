import "./CdsIconStrokeSize520PxStrokeWidthMediumDefault.css";
import { Calendar2 } from "../Calendar2/Calendar2.jsx";

export const CdsIconStrokeSize520PxStrokeWidthMediumDefault = ({
  svg = <Calendar2 className="svg-instance" />,
  size = "4-16-px",
  strokeWidth = "medium-default",
  className,
  ...props
}) => {
  const variantsClassName = "size-" + size + " stroke-width-" + strokeWidth;

  return (
    <div
      className={
        "cds-icon-stroke-size-520-px-stroke-width-medium-default " +
        className +
        " " +
        variantsClassName
      }
    >
      {svg}
    </div>
  );
};
