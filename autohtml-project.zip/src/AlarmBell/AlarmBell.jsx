import "./AlarmBell.css";

export const AlarmBell = ({ className, ...props }) => {
  return (
    <div className={"alarm-bell " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
