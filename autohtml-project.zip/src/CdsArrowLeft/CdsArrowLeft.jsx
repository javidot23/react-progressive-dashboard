import "./CdsArrowLeft.css";

export const CdsArrowLeft = ({ className, ...props }) => {
  return (
    <div className={"cds-arrow-left " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
