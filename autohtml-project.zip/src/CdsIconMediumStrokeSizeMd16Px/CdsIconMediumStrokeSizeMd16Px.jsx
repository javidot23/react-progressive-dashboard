import "./CdsIconMediumStrokeSizeMd16Px.css";
import { Calendar } from "../Calendar/Calendar.jsx";

export const CdsIconMediumStrokeSizeMd16Px = ({
  icon = <Calendar className="svg-instance" />,
  size = "2-xl-24-px",
  className,
  ...props
}) => {
  const variantsClassName = "size-" + size;

  return (
    <div
      className={
        "cds-icon-medium-stroke-size-md-16-px " +
        className +
        " " +
        variantsClassName
      }
    >
      {icon}
    </div>
  );
};
