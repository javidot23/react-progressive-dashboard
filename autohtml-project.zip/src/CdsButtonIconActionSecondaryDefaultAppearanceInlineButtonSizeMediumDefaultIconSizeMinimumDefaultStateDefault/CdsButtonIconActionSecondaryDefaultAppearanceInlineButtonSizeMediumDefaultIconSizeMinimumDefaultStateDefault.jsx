import "./CdsButtonIconActionSecondaryDefaultAppearanceInlineButtonSizeMediumDefaultIconSizeMinimumDefaultStateDefault.css";
import { Calendar2 } from "../Calendar2/Calendar2.jsx";
import { CdsIconStrokeSize520PxStrokeWidthMediumDefault } from "../CdsIconStrokeSize520PxStrokeWidthMediumDefault/CdsIconStrokeSize520PxStrokeWidthMediumDefault.jsx";

export const CdsButtonIconActionSecondaryDefaultAppearanceInlineButtonSizeMediumDefaultIconSizeMinimumDefaultStateDefault =
  ({
    action = "secondary-default",
    appearance = "clear-default",
    buttonSize = "medium-default",
    iconSize = "minimum-default",
    state = "default",
    className,
    ...props
  }) => {
    const variantsClassName =
      "action-" +
      action +
      " appearance-" +
      appearance +
      " button-size-" +
      buttonSize +
      " icon-size-" +
      iconSize +
      " state-" +
      state;

    return (
      <div
        className={
          "cds-button-icon-action-secondary-default-appearance-inline-button-size-medium-default-icon-size-minimum-default-state-default " +
          className +
          " " +
          variantsClassName
        }
      >
        <CdsIconStrokeSize520PxStrokeWidthMediumDefault
          svg={<Calendar2 className="svg-instance" />}
          size="5-20-px"
          className="icon-instance"
        ></CdsIconStrokeSize520PxStrokeWidthMediumDefault>
      </div>
    );
  };
