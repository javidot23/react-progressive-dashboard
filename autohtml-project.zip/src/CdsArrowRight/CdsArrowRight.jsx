import "./CdsArrowRight.css";

export const CdsArrowRight = ({ className, ...props }) => {
  return (
    <div className={"cds-arrow-right " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
