import "./CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault.css";
import { Calendar } from "../Calendar/Calendar.jsx";
import { CdsIconMediumStrokeSizeXl20Px } from "../CdsIconMediumStrokeSizeXl20Px/CdsIconMediumStrokeSizeXl20Px.jsx";

export const CdsButtonStackedActionSecondaryDefaultAppearanceTextSizeSmallStateDefault =
  ({
    label = "Button label",
    action = "secondary-default",
    appearance = "outline-default",
    size = "medium-default",
    state = "default",
    className,
    ...props
  }) => {
    const variantsClassName =
      "action-" +
      action +
      " appearance-" +
      appearance +
      " size-" +
      size +
      " state-" +
      state;

    return (
      <div
        className={
          "cds-button-stacked-action-secondary-default-appearance-text-size-small-state-default " +
          className +
          " " +
          variantsClassName
        }
      >
        <CdsIconMediumStrokeSizeXl20Px
          icon={<Calendar className="svg-instance" />}
          size="xl-20-px"
          className="icon-instance"
        ></CdsIconMediumStrokeSizeXl20Px>
        <div className="button-label">{label} </div>
      </div>
    );
  };
