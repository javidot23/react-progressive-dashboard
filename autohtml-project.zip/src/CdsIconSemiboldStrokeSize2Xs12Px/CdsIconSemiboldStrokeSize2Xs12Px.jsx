import "./CdsIconSemiboldStrokeSize2Xs12Px.css";
import { Calendar } from "../Calendar/Calendar.jsx";

export const CdsIconSemiboldStrokeSize2Xs12Px = ({
  icon = <Calendar className="svg-instance" />,
  size = "2-xl-24-px",
  className,
  ...props
}) => {
  const variantsClassName = "size-" + size;

  return (
    <div
      className={
        "cds-icon-semibold-stroke-size-2-xs-12-px " +
        className +
        " " +
        variantsClassName
      }
    >
      {icon}
    </div>
  );
};
