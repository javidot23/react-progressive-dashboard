import "./CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeMediumDefaultIconSizeMaximumStateDefault.css";
import { Calendar2 } from "../Calendar2/Calendar2.jsx";
import { CdsIconStrokeSize624PxStrokeWidthMediumDefault } from "../CdsIconStrokeSize624PxStrokeWidthMediumDefault/CdsIconStrokeSize624PxStrokeWidthMediumDefault.jsx";

export const CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeMediumDefaultIconSizeMaximumStateDefault =
  ({
    action = "secondary-default",
    appearance = "clear-default",
    buttonSize = "medium-default",
    iconSize = "minimum-default",
    state = "default",
    className,
    ...props
  }) => {
    const variantsClassName =
      "action-" +
      action +
      " appearance-" +
      appearance +
      " button-size-" +
      buttonSize +
      " icon-size-" +
      iconSize +
      " state-" +
      state;

    return (
      <div
        className={
          "cds-button-icon-action-secondary-default-appearance-clear-default-button-size-medium-default-icon-size-maximum-state-default " +
          className +
          " " +
          variantsClassName
        }
      >
        <CdsIconStrokeSize624PxStrokeWidthMediumDefault
          svg={<Calendar2 className="svg-instance" />}
          size="6-24-px"
          className="icon-instance"
        ></CdsIconStrokeSize624PxStrokeWidthMediumDefault>
      </div>
    );
  };
