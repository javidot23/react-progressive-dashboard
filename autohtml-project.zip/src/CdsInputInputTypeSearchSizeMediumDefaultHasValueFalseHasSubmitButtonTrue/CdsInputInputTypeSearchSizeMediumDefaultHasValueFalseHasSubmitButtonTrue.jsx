import "./CdsInputInputTypeSearchSizeMediumDefaultHasValueFalseHasSubmitButtonTrue.css";
import { LabelSizeMediumDefaultTypeInputLabelLayoutSingleLineNoWrap } from "../LabelSizeMediumDefaultTypeInputLabelLayoutSingleLineNoWrap/LabelSizeMediumDefaultTypeInputLabelLayoutSingleLineNoWrap.jsx";
import { InputButtonGroupSizeMediumDefault } from "../InputButtonGroupSizeMediumDefault/InputButtonGroupSizeMediumDefault.jsx";
import { Helper } from "../Helper/Helper.jsx";

export const CdsInputInputTypeSearchSizeMediumDefaultHasValueFalseHasSubmitButtonTrue =
  ({
    hasHelperText = false,
    hasLabel = true,
    inputType = "text",
    size = "medium-default",
    hasValue = "false",
    hasSubmitButton = "false",
    className,
    ...props
  }) => {
    const variantsClassName =
      "input-type-" +
      inputType +
      " size-" +
      size +
      " has-value-" +
      hasValue +
      " has-submit-button-" +
      hasSubmitButton;

    return (
      <div
        className={
          "cds-input-input-type-search-size-medium-default-has-value-false-has-submit-button-true " +
          className +
          " " +
          variantsClassName
        }
      >
        {hasLabel && (
          <>
            <LabelSizeMediumDefaultTypeInputLabelLayoutSingleLineNoWrap
              labelText="Search input label"
              className="label-instance"
            ></LabelSizeMediumDefaultTypeInputLabelLayoutSingleLineNoWrap>
          </>
        )}
        <InputButtonGroupSizeMediumDefault
          submitButton9Label="Search"
          submitButton9Action="primary"
          submitButton9Appearance="fill"
          className="input-button-group-instance"
        ></InputButtonGroupSizeMediumDefault>
        {hasHelperText && (
          <>
            <Helper className="helper-instance"></Helper>
          </>
        )}
      </div>
    );
  };
