import "./NavigationMenu.css";

export const NavigationMenu = ({ className, ...props }) => {
  return (
    <div className={"navigation-menu " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
