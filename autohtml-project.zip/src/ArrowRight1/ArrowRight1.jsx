import "./ArrowRight1.css";

export const ArrowRight1 = ({ className, ...props }) => {
  return (
    <div className={"arrow-right-1 " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
