import "./CdsButtonActionPrimaryAppearanceFillSizeMediumDefaultStateDefault.css";
import { CdsArrowLeft } from "../CdsArrowLeft/CdsArrowLeft.jsx";
import { CdsIconMediumStrokeSizeXl20Px } from "../CdsIconMediumStrokeSizeXl20Px/CdsIconMediumStrokeSizeXl20Px.jsx";
import { CdsArrowRight } from "../CdsArrowRight/CdsArrowRight.jsx";

export const CdsButtonActionPrimaryAppearanceFillSizeMediumDefaultStateDefault =
  ({
    hasIconRight = false,
    label = "Button label",
    hasIconLeft = false,
    action = "secondary-default",
    appearance = "outline-default",
    size = "medium-default",
    state = "default",
    className,
    ...props
  }) => {
    const variantsClassName =
      "action-" +
      action +
      " appearance-" +
      appearance +
      " size-" +
      size +
      " state-" +
      state;

    return (
      <div
        className={
          "cds-button-action-primary-appearance-fill-size-medium-default-state-default " +
          className +
          " " +
          variantsClassName
        }
      >
        {hasIconLeft && (
          <>
            <CdsIconMediumStrokeSizeXl20Px
              icon={<CdsArrowLeft className="svg-instance" />}
              size="xl-20-px"
              className="icon-left-instance"
            ></CdsIconMediumStrokeSizeXl20Px>
          </>
        )}
        <div className="button-label">{label} </div>
        {hasIconRight && (
          <>
            <CdsIconMediumStrokeSizeXl20Px
              icon={<CdsArrowRight className="svg-instance" />}
              size="xl-20-px"
              className="icon-right-instance"
            ></CdsIconMediumStrokeSizeXl20Px>
          </>
        )}
      </div>
    );
  };
