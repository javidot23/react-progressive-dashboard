import "./PartsSearchWidthFill.css";
import { PartsSearchVariantsAppearanceSimple } from "../PartsSearchVariantsAppearanceSimple/PartsSearchVariantsAppearanceSimple.jsx";

export const PartsSearchWidthFill = ({
  width = "fill",
  className,
  ...props
}) => {
  const variantsClassName = "width-" + width;

  return (
    <div
      className={
        "parts-search-width-fill " + className + " " + variantsClassName
      }
    >
      <PartsSearchVariantsAppearanceSimple className="parts-search-variants-instance"></PartsSearchVariantsAppearanceSimple>
    </div>
  );
};
