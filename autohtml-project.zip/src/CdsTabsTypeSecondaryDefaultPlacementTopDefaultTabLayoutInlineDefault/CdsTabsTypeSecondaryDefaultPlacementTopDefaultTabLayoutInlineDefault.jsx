import "./CdsTabsTypeSecondaryDefaultPlacementTopDefaultTabLayoutInlineDefault.css";
import { CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected } from "../CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected/CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected.jsx";
import { CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault } from "../CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault/CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault.jsx";
import { ArrowLeft1 } from "../ArrowLeft1/ArrowLeft1.jsx";
import { CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeSmallIconSizeMinimumDefaultStateDefault } from "../CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeSmallIconSizeMinimumDefaultStateDefault/CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeSmallIconSizeMinimumDefaultStateDefault.jsx";
import { ArrowRight1 } from "../ArrowRight1/ArrowRight1.jsx";

export const CdsTabsTypeSecondaryDefaultPlacementTopDefaultTabLayoutInlineDefault =
  ({
    hasScrollLeft = false,
    hasScrollRight = false,
    hasDivider = true,
    type = "secondary-default",
    placement = "top-default",
    tabLayout = "inline-default",
    className,
    ...props
  }) => {
    const variantsClassName =
      "type-" + type + " placement-" + placement + " tab-layout-" + tabLayout;

    return (
      <div
        className={
          "cds-tabs-type-secondary-default-placement-top-default-tab-layout-inline-default " +
          className +
          " " +
          variantsClassName
        }
      >
        <CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected
          state="active-selected"
          className="tab-item-instance"
        ></CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateActiveSelected>
        <CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault className="tab-item-instance"></CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault>
        <CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault className="tab-item-instance"></CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault>
        <CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault className="tab-item-instance"></CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault>
        <CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault className="tab-item-instance"></CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault>
        <CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault className="tab-item-instance"></CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault>
        <CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault className="tab-item-instance"></CdsTabItemTypeSecondaryDefaultPlacementTopDefaultLayoutInlineDefaultStateDefault>
        {hasScrollLeft && (
          <>
            <CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeSmallIconSizeMinimumDefaultStateDefault
              buttonSize="small"
              iconsvg={<ArrowLeft1 className="arrow-left-1-instance" />}
              className="scroll-button-left-instance"
            ></CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeSmallIconSizeMinimumDefaultStateDefault>
          </>
        )}
        {hasScrollRight && (
          <>
            <CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeSmallIconSizeMinimumDefaultStateDefault
              buttonSize="small"
              iconsvg={<ArrowRight1 className="arrow-right-1-instance" />}
              className="scroll-button-right-instance"
            ></CdsButtonIconActionSecondaryDefaultAppearanceClearDefaultButtonSizeSmallIconSizeMinimumDefaultStateDefault>
          </>
        )}
        {hasDivider && (
          <>
            <div className="divider"></div>
          </>
        )}
      </div>
    );
  };
