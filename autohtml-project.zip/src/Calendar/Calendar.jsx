import "./Calendar.css";

export const Calendar = ({ className, ...props }) => {
  return (
    <div className={"calendar " + className}>
      <img className="group" src="group0.svg" />
    </div>
  );
};
