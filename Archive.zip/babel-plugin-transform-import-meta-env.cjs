// Correct + minimal transform for Jest
module.exports = ({ types: t }) => ({
  name: "transform-import-meta-env",
  visitor: {
    MemberExpression(path) {
      const { node } = path;

      if (
        t.isMemberExpression(node.object) &&
        t.isMetaProperty(node.object.object) &&
        node.object.object.meta.name === "import" &&
        node.object.object.property.name === "meta" &&
        node.object.property.name === "env"
      ) {
        path.replaceWith(t.memberExpression(t.memberExpression(t.identifier("process"), t.identifier("env")), node.property));
      }
    },
  },
});
