import dotenv from "dotenv";

dotenv.config();

// TODO: Revisit date-only semantics and remove this fixed timezone after date comparisons are timezone-safe.
process.env.TZ = "UTC";

export default {
  testEnvironment: "jsdom",
  setupFilesAfterEnv: ["<rootDir>/src/testSetup.ts"],
  setupFiles: ["<rootDir>/jest.env.js"],
  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/src/$1",
    // Mock react-leaflet to avoid ES module parsing issues
    "^react-leaflet$": "<rootDir>/src/__tests__/mocks/reactLeafletMock.js",
    // Mock leaflet CSS
    "^leaflet/dist/leaflet.css$": "<rootDir>/src/__tests__/mocks/styleMock.js",
    // Mock SVG files to avoid parsing issues
    "\\.svg$": "<rootDir>/src/__tests__/mocks/fileMock.js",
    "\\.svg\\?react$": "<rootDir>/src/__tests__/mocks/fileMock.js",
    "\\.svg\\?url$": "<rootDir>/src/__tests__/mocks/fileMock.js",
    // Mock other image files
    "\\.(png|jpg|jpeg|gif|webp)$": "<rootDir>/src/__tests__/mocks/fileMock.js",
    // Style mocks
    "\\.(css|less|scss|sass)$": "<rootDir>/src/__tests__/mocks/styleMock.js",
    "\\.(css|scss|sass)$": "identity-obj-proxy",
  },
  transform: {
    "^.+\\.(ts|tsx|js|jsx)$": "babel-jest",
    "\\.(svg|png|jpe?g|gif|webp)$": "jest-transform-stub", // handles SVG/XML
  },
  transformIgnorePatterns: ["node_modules/(?!(msw|until-async|flatbush|flatqueue|react-leaflet|leaflet)/)"],
  moduleFileExtensions: ["ts", "tsx", "js", "jsx", "json"],
  // macOS / Linux (original):
  // testMatch: ["<rootDir>/src/**/?(*.)+(spec|test).[tj]s?(x)"],
  // Windows: Jest turns `/` into `\` in the pattern above and the `?(*.)` extglob
  // matches nothing (0 tests). Use this form locally on Windows; swap comments if needed.
  testMatch: ["**/src/**/*.(spec|test).[tj]s?(x)"],
  collectCoverageFrom: ["src/**/*.{ts,tsx}", "!src/**/*.d.ts", "!src/main.tsx", "!src/testSetup.ts"],
  coverageReporters: ["text", "lcov", "html", "json-summary"],
  reporters: ["default", ["jest-junit", { outputName: "results.xml" }]],
  testTimeout: 10000,
  extensionsToTreatAsEsm: [".ts", ".tsx"],
  moduleDirectories: ["node_modules", "src"],
  testEnvironmentOptions: {
    customExportConditions: ["node", "node-addons"],
  },
  // Ensure SVG files are properly mocked
  modulePathIgnorePatterns: ["<rootDir>/dist/", "<rootDir>/build/"],
  // Add this to ensure proper module resolution
  roots: ["<rootDir>/src"],
  // Ensure mocks are loaded before tests
  testPathIgnorePatterns: ["<rootDir>/node_modules/", "<rootDir>/dist/", "<rootDir>/build/"],
};
