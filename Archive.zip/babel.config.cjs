module.exports = {
  presets: [
    ['@babel/preset-env', {
      targets: { node: 'current' },
      modules: 'commonjs' // Transform ES modules to CommonJS for Jest
    }],
    ['@babel/preset-react', { runtime: 'automatic' }],
    '@babel/preset-typescript'
  ],
  plugins: [
    "./babel-plugin-transform-import-meta-env.cjs"
  ]
};
