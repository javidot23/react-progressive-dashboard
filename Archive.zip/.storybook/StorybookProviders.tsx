import type { ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MemoryRouter } from "react-router-dom";

import { PageFiltersProvider } from "@/contexts/PageFiltersContext";

interface StorybookProvidersProps {
  children: ReactNode;
}

export function StorybookProviders({ children }: StorybookProvidersProps) {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: Infinity,
      },
      mutations: {
        retry: false,
      },
    },
  });

  return (
    <QueryClientProvider client={queryClient}>
      <MemoryRouter>
        <PageFiltersProvider>{children}</PageFiltersProvider>
      </MemoryRouter>
    </QueryClientProvider>
  );
}
