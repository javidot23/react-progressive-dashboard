import type { ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter } from 'react-router-dom';

import { PageFiltersProvider } from '@/contexts/PageFiltersContext';
import { TenantConfigProvider } from '@/tenant';
import type { TenantId } from '@/tenant/types';

interface StorybookProvidersProps {
  children: ReactNode;
  tenantId?: TenantId;
}

export function StorybookProviders({
  children,
  tenantId = 'stratium',
}: StorybookProvidersProps) {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: Infinity,
      },
      mutations: {
        retry: false,
      },
    },
  });

  return (
    <QueryClientProvider client={queryClient}>
      <MemoryRouter>
        <TenantConfigProvider forceTenantId={tenantId}>
          <PageFiltersProvider>{children}</PageFiltersProvider>
        </TenantConfigProvider>
      </MemoryRouter>
    </QueryClientProvider>
  );
}
