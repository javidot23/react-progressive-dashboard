import type { StorybookConfig } from "@storybook/react-vite";
import type { PluginOption } from "vite";
import remarkGfm from "remark-gfm";

/**
 * Storybook's Vite builder loads the app's `vite.config.ts` with mode "production",
 * so `cspPlugin` injects `script-src 'self'` into the preview `iframe.html`.
 * Storybook bootstraps that iframe with inline scripts, which the policy blocks —
 * every story renders blank in a served static build, while the build itself still
 * succeeds. Drop only that plugin here; the application build keeps its CSP.
 */
const EXCLUDED_VITE_PLUGINS = ["stratium-html-csp"];

function dropExcludedPlugins(plugin: PluginOption): PluginOption {
  if (Array.isArray(plugin)) {
    return plugin.map(dropExcludedPlugins);
  }

  if (plugin && typeof plugin === "object" && "name" in plugin) {
    return EXCLUDED_VITE_PLUGINS.includes(plugin.name) ? false : plugin;
  }

  return plugin;
}

const config: StorybookConfig = {
  stories: ["../src/**/*.mdx", "../src/**/*.stories.@(js|jsx|mjs|ts|tsx)"],
  addons: [
    {
      name: "@storybook/addon-essentials",
      options: {
        docs: false,
      },
    },
    {
      name: "@storybook/addon-docs",
      options: {
        mdxPluginOptions: {
          mdxCompileOptions: {
            remarkPlugins: [remarkGfm],
          },
        },
      },
    },
    "@storybook/addon-a11y",
    "@chromatic-com/storybook",
  ],
  staticDirs: ["../public"],
  framework: {
    name: "@storybook/react-vite",
    options: {},
  },
  viteFinal: viteConfig => ({
    ...viteConfig,
    plugins: (viteConfig.plugins ?? []).map(dropExcludedPlugins),
  }),
};
export default config;
