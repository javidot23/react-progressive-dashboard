import "../src/index.css";
import "./preview.css";
import type { Decorator, Preview } from "@storybook/react";
import { StorybookProviders } from "./StorybookProviders";
import { initialize, mswLoader } from "msw-storybook-addon";
import { handlers } from "../src/__tests__/mocks/handlers";

initialize();

const withProviders: Decorator = Story => {
  return (
    <StorybookProviders>
      <Story />
    </StorybookProviders>
  );
};

const preview: Preview = {
  decorators: [withProviders],
  loaders: [mswLoader],
  parameters: {
    layout: "centered",
    options: {
      storySort: {
        order: [
          "Foundations",
          ["Welcome", "Design Tokens", "Accessibility", "Component MDX Template"],
          "Atoms",
          "Molecules",
          "Organisms",
          "*",
        ],
      },
    },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
    docs: {
      toc: true,
    },
    a11y: {
      test: "error",
    },
    msw: {
      handlers: handlers,
    },
  },
  tags: ["autodocs"],
};

export default preview;
