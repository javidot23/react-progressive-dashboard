import "../src/index.css";
import "./preview.css";
import type { Decorator, Preview } from "@storybook/react";
import { StorybookProviders } from "./StorybookProviders";
import type { TenantId } from "../src/tenant/types";
import { initialize, mswLoader } from "msw-storybook-addon";
import { handlers } from "../src/__tests__/mocks/handlers";

initialize();

const withProviders: Decorator = (Story, context) => {
  const tenantId = (context.parameters.tenant as TenantId | undefined) ?? (context.globals.tenant as TenantId);
  return (
    <StorybookProviders tenantId={tenantId}>
      <Story />
    </StorybookProviders>
  );
};

const preview: Preview = {
  decorators: [withProviders],
  loaders: [mswLoader],
  globalTypes: {
    tenant: {
      description: "Select the tenant for the story",
      defaultValue: "scrm",
      toolbar: {
        icon: "globe",
        dynamicTitle: true,
        items: [
          { value: "scrm", title: "SCRM" },
          { value: "scv.customer.vendor", title: "SCV Customer Vendor" },
          { value: "scv.customer", title: "SCV Customer" },
          { value: "scv.vendor", title: "SCV Vendor" },
        ],
      },
    },
  },
  parameters: {
    layout: "centered",
    options: {
      storySort: {
        order: [
          "Foundations",
          ["Welcome", "Design Tokens", "Accessibility", "Component MDX Template"],
          "Atoms",
          "Molecules",
          "Organisms",
          "*",
        ],
      },
    },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
    docs: {
      toc: true,
    },
    a11y: {
      test: "error",
    },
    msw: {
      handlers: handlers,
    },
  },
  tags: ["autodocs"],
};

export default preview;
