# Stratium Frontend

A modern React-based frontend application for the Stratium (Supply Chain Risk Management) platform, delivering a performant, scalable, and enterprise-grade user interface for managing supply chain operations.

## Table of Contents
- [Getting Started](#getting-started)
- [Docker Setup](#docker-setup)
- [Project Structure](#project-structure)
- [Architecture](#architecture)
- [State Management](#state-management)
- [API Integration](#api-integration)
- [Authentication](#authentication)
- [Security](#security)
- [Routing](#routing)
- [Development](#development)
- [Storybook](#storybook)
- [Testing](#testing)
- [Deployment](#deployment)
- [Code Quality](#code-quality)
- [Performance](#performance)

## Getting Started

### Prerequisites
- Node.js 20.x or higher
- npm 10.x or higher
- Docker (for containerized setup)
- Git

### Local Development Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd stratium-frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Configuration**
   Copy the example environment file and configure it for your environment:
   ```bash
   cp .env.example .env.development
   ```

   Then edit `.env.development` and update the values:
   ```env
   # API Configuration (include /api suffix if your Django mount uses it)
   VITE_API_BASE_URL=http://localhost:8000/api

   # Optional UI branding: entra | sap_cdc
   VITE_AUTH_PROVIDER=entra
   ```

   **Note**: `VITE_API_BASE_URL` is required. OIDC runs server-side (BFF); see `.env.example` and [docs/FRONTEND_AUTHENTICATION.md](./docs/FRONTEND_AUTHENTICATION.md).

4. **Start development server**
   ```bash
   npm run dev
   ```

   The application will be available at `http://localhost:5173`

## Docker Setup

### Build and Run with Docker

1. **Build the Docker image**
   ```bash
   docker build -t stratium-frontend .
   ```

2. **Run in development mode**
   ```bash
   docker run -p 5173:5173 \
     -e VITE_API_BASE_URL=http://localhost:8000 \
     -e NODE_ENV=development \
     stratium-frontend
   ```

### Docker Compose (Recommended)

The project includes a multi-stage Dockerfile supporting development and production environments:

```yaml
# Default: Development mode
docker-compose up

# Production build
DOCKER_TARGET=production BUILD_ENV=production docker-compose up
```

Environment variables can be configured in a `.env` file:

```env
# Docker Configuration
DOCKER_TARGET=development
BUILD_ENV=development
APP_PORT=5173
INTERNAL_PORT=5173
NODE_ENV=development

# API Configuration (Required)
VITE_API_BASE_URL=http://localhost:8000/api

# UI branding only (IdP selection is server-side): entra | sap_cdc
VITE_AUTH_PROVIDER=entra

# Volume Configuration (optional)
VOLUMES_MOUNT=.
HEALTH_CHECK_CMD=curl -f http://localhost:5173 || exit 1
```

### Production Docker Setup

For production deployments:

```bash
docker build --target production --build-arg BUILD_ENV=production -t stratium-frontend:prod .
docker run -p 80:80 stratium-frontend:prod
```

The production build uses NGINX as a web server with optimized configuration for serving static assets.

## Project Structure

```
stratium-frontend/
├── src/
│   ├── components/          # React components
│   │   ├── atoms/           # Basic UI elements (buttons, inputs, badges)
│   │   ├── molecules/       # Composite components (forms, cards)
│   │   ├── organisms/       # Complex components (tables, dashboards)
│   │   ├── templates/       # Page layouts and templates
│   │   └── manage/          # Business-specific components
│   ├── pages/               # Route-level page components
│   │   ├── manage/          # Management pages
│   │   └── profile/         # User profile pages
│   ├── hooks/               # Custom React hooks
│   ├── stores/              # Zustand state management
│   │   └── slices/          # State slices by domain
│   ├── services/            # API service layer
│   ├── lib/                 # Utilities and helpers
│   │   ├── api.ts           # API client configuration
│   │   ├── apiClient.ts     # Axios instance setup
│   │   ├── apiServices.ts   # API endpoint definitions
│   │   ├── types.ts         # TypeScript type definitions
│   │   └── utils.ts         # Utility functions
│   ├── contexts/            # React context providers
│   ├── routes/              # Route configuration
│   ├── assets/              # Static assets (images, icons)
│   └── types/               # Global TypeScript definitions
├── public/                  # Public static files
├── lib/                     # External libraries and design tokens
│   └── cds-tokens-web/      # Design tokens (colors, typography)
├── Dockerfile               # Multi-stage Docker configuration
├── docker-compose.yml       # Docker Compose setup
├── nginx.conf               # NGINX configuration for production
├── vite.config.ts           # Vite bundler configuration
├── tailwind.config.js       # Tailwind CSS configuration
├── tsconfig.json            # TypeScript configuration
└── package.json             # Project dependencies
```

### Component Architecture

The project follows **Atomic Design** principles:

- **Atoms**: Basic building blocks (Button, Input, Badge)
- **Molecules**: Simple combinations of atoms (SearchBar, DatePicker)
- **Organisms**: Complex UI components (DataTable, NavigationBar, Dashboard)
- **Templates**: Page-level layouts combining organisms
- **Pages**: Specific instances of templates with real data

## Architecture

### Technology Stack

- **Frontend Framework**: React 19.0
- **Language**: TypeScript 5.7
- **Build Tool**: Vite 6.2
- **Styling**: Tailwind CSS 3.4
- **UI Components**:
  - Material-UI (MUI) 7.1
  - Radix UI primitives
  - Custom Cencora Design System (CDS)
- **Charts**: MUI X Charts 8.5
- **Maps**: Leaflet 1.9, React Leaflet 5.0
- **Icons**: Lucide React, React Icons
- **HTTP Client**: Axios 1.10
- **Routing**: React Router v7.6
- **State Management**: Zustand 5.0
- **Testing**: Jest 30.0, React Testing Library 16.3
- **Mocking**: MSW (Mock Service Worker) 2.10
- **Deployment**: Docker, NGINX

### Design Patterns

1. **Service Layer Pattern**: API calls isolated in service modules
2. **Custom Hooks**: Business logic encapsulated in reusable hooks
3. **Compound Components**: Complex components with subcomponents
4. **Render Props**: Flexible component composition
5. **Higher-Order Components**: For authentication and authorization

## State Management

### Zustand (Primary State Management)

The application uses **Zustand** for state management, providing a lightweight and flexible solution for managing application state.

#### Store Architecture

```typescript
// Store Structure
stores/
├── useStore.ts              # Main store with middleware
├── useDashboardStore.ts     # Dashboard-specific state
├── slices/                  # Domain-specific state slices
│   ├── issues.ts            # Issue management state
│   ├── initialState.ts      # Initial state definitions
│   ├── types.ts             # State type definitions
│   └── actions/             # State actions by domain
│       ├── vendors.ts
│       ├── serviceLevel.ts
│       ├── otifData.ts
│       └── ...
└── index.ts                 # Store exports
```

#### Middleware Configuration

The store uses multiple middleware for enhanced functionality:

- **immer**: Immutable state updates with mutable syntax
- **devtools**: Redux DevTools integration for debugging
- **subscribeWithSelector**: Selective state subscription for performance

Example store implementation:

```typescript
import { create } from 'zustand';
import { devtools, subscribeWithSelector } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';

export const useAppStore = create<AppStore>()(
  devtools(
    subscribeWithSelector(
      immer((set, get) => ({
        // State and actions
      }))
    ),
    { name: 'Cencora Stratium Store' }
  )
);
```


### State Management Strategy

- **Local UI State**: React `useState` and `useReducer`
- **Global Application State**: Zustand stores
- **Form State**: React Hook Form (if applicable)
- **URL State**: React Router search params

## API Integration

### Axios HTTP Client

The application uses **Axios** as the HTTP client for API communication, providing robust request/response handling with interceptors for authentication and error management.

#### API Client Configuration

```typescript
// lib/apiClient.ts
import axios from 'axios';

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for authentication
apiClient.interceptors.request.use(
  (config) => {
    // Add authentication token
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle errors globally
    return Promise.reject(error);
  }
);
```

#### API Service Layer

API calls are organized in service modules:

```
services/
├── materialService.ts       # Material-related API calls
├── vendorService.ts         # Vendor-related API calls
├── profileService.ts        # User profile API calls
└── userSettingsService.ts   # User settings API calls
```

Example service implementation:

```typescript
// services/vendorService.ts
import { apiClient } from '@/lib/apiClient';

export const vendorService = {
  getVendorList: async (params) => {
    const response = await apiClient.get('/vendor/', { params });
    return response.data;
  },

  getVendorDetails: async (vendorId) => {
    const response = await apiClient.get(`/vendor/${vendorId}/`);
    return response.data;
  },
};
```

### API Response Format

The API follows a standardized response format:

#### Success Response
```json
{
  "success": true,
  "data": {
    // Response data
  }
}
```

#### Error Response
```json
{
  "success": false,
  "type": "validation_error",
  "code": "invalid",
  "error": "Error message"
}
```

### Environment Variables

API and authentication configuration is managed through environment variables. See `.env.example` in the project root for the complete list.

#### Required
- **`VITE_API_BASE_URL`**: Base URL for API requests (e.g., `http://localhost:8000/api`)
  - Include the `/api` suffix when the Django API is mounted there
  - The application will throw an error if this variable is not set

#### Optional (auth branding)
- **`VITE_AUTH_PROVIDER`**: UI branding only — `entra` (default) or `sap_cdc` (IdP selection is server-side)
- **`VITE_CDC_DOMAIN`**: SAP AaaS profile page link (`sap_cdc` builds only)


## Authentication

The SPA uses a **BFF cookie session** (no browser OIDC). The Django API performs login; the browser holds `sessionid` (HttpOnly) and `csrftoken`. All requests use `withCredentials: true`; unsafe methods send `X-CSRFToken`.

**Full architecture:** **[docs/FRONTEND_AUTHENTICATION.md](./docs/FRONTEND_AUTHENTICATION.md)**

**Quick facts:**

- Bootstrap: `GET /auth/me/` on load; session 401 → full-page redirect to `{VITE_API_BASE_URL}/auth/login/`
- Login button: `window.location` to server `/auth/login/` (never axios)
- Logout: `POST /auth/logout/` then optional IdP `end_session_url`
- `isAuthenticated`: successful `/auth/me/` profile (`AuthContext`)
- Protected routes: `src/components/ProtectedRoute.tsx` in `AppRoutes`

## Security

See **[docs/FRONTEND_AUTHENTICATION.md](./docs/FRONTEND_AUTHENTICATION.md)** for:

- Cookie session threat model (XSS, CSRF, logout)
- Baseline Content-Security-Policy (injected on `npm run build`; dev server unchanged)
- Deploy-time CSP tuning for API and IdP origins

## Routing

### React Router v7

The application uses React Router v7 for client-side routing.

#### Route Structure

```typescript
routes/
├── ProtectedRoute.tsx       # Authentication wrapper
└── // Additional route configurations
```

#### Main Routes

```
/                            # Login page (public)
/overview                    # Dashboard overview (protected)
/plan                        # Planning page (protected)
/react                       # React/response page (protected)
/manage                      # Management section (protected)
    ├── /materials           # Materials management
    ├── /vendors             # Vendor management
    ├── /issues              # Issue tracking
    ├── /orders              # Order management
    └── /analytics           # Analytics dashboards
/profile                     # User profile (protected)
/info                        # System information (protected)
*                           # 404 Not Found page
```

#### Protected Routes

Routes are protected using the `ProtectedRoute` component with authentication context:

```typescript
<Route
  path="/overview"
  element={
    <ProtectedRoute>
      <OverviewPage />
    </ProtectedRoute>
  }
/>
```

### Navigation Structure

The application uses a hierarchical navigation structure:
- **Primary Navigation**: Main sections (Overview, Plan, React, Manage)
- **Secondary Navigation**: Subsections within each main section
- **Breadcrumbs**: Contextual navigation for deep page hierarchies

## Development

### Available Scripts

```bash
# Development
npm run dev                  # Start development server (local environment)
npm run dev:staging          # Start with staging environment
npm run production           # Start with production environment

# Building
npm run build                # Build for production
npm run build:dev            # Build for development
npm run build:staging        # Build for staging
npm run build:prod           # Build for production

# Code Quality
npm run lint                 # Run ESLint
npm run format               # Format code with Prettier
npm run format:check         # Check code formatting

# Testing
npm run test                 # Run tests in watch mode

# Preview
npm run preview              # Preview production build locally
npm run preview:staging      # Preview staging build
npm run preview:prod         # Preview production build
```

### Environment Modes

The application supports multiple environment modes:

- **development**: Local development with hot module replacement
- **staging**: Staging environment for QA testing
- **production**: Production-optimized build

Environment-specific configuration is loaded from `.env.[mode]` files:

```
.env.development             # Development environment variables
.env.staging                 # Staging environment variables
.env.production              # Production environment variables
```

Each environment file should contain all required variables:
- `VITE_API_BASE_URL` - Backend API endpoint (include `/api` when mounted there)
- `VITE_AUTH_PROVIDER` - UI branding (`entra` or `sap_cdc`) when needed
- Any environment-specific optional variables

### Branching Strategy

- **`main`**: Production-ready code
- **`staging`**: Staging environment for QA
- **`dev`**: Active development branch
- **Feature branches**: `feature/<feature-name>`
- **Bug fixes**: `bugfix/<bug-id>`
- **Hotfixes**: `hotfix/<issue-id>`

All pull requests should target the `dev` branch for review before merging to `staging` and `main`.

### Development Workflow

1. Create feature branch from `dev`
2. Implement changes with tests
3. Run linting and formatting: `npm run lint && npm run format`
4. Run tests: `npm run test`
5. Commit changes with descriptive messages
6. Create pull request to `dev`
7. Address review feedback
8. Merge after approval

### Path Aliases

The project uses TypeScript path aliases for cleaner imports:

```typescript
import { Button } from '@/components/atoms/Button';
import { useApi } from '@/hooks/useApi';
import { apiClient } from '@/lib/apiClient';
import { HomePage } from '@/pages/HomePage';
```

Configured aliases:
- `@/*` → `src/*`
- `@/components/*` → `src/components/*`
- `@/lib/*` → `src/lib/*`
- `@/hooks/*` → `src/hooks/*`
- `@/pages/*` → `src/pages/*`
- `@/types/*` → `src/lib/types/*`

## Testing

### Testing Stack

- **Test Runner**: Jest 30.0
- **React Testing**: React Testing Library 16.3
- **User Interactions**: Testing Library User Event 14.6
- **API Mocking**: MSW (Mock Service Worker) 2.10
- **Type Support**: @types/jest 30.0

### Test Organization

```
src/__tests__/
├── api/                     # API integration tests
├── components/              # Component unit tests
├── pages/                   # Page integration tests
├── utils/                   # Utility function tests
├── mocks/                   # Test data and mocks
├── setup/                   # Test configuration
└── *.test.tsx               # Test files
```

### Running Tests

```bash
# Run all tests in watch mode
npm run test

# Run tests once (CI mode)
npm run test -- --watchAll=false

# Run tests with coverage
npm run test -- --coverage

# Run specific test file
npm run test -- src/__tests__/components/Button.test.tsx
```

### Writing Tests

#### Component Test Example

```typescript
import { render, screen } from '@testing-library/react';
import { Button } from '@/components/atoms/Button';

describe('Button', () => {
  it('renders button with text', () => {
    render(<Button>Click me</Button>);
    expect(screen.getByText('Click me')).toBeInTheDocument();
  });

  it('calls onClick handler when clicked', () => {
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>Click me</Button>);

    screen.getByText('Click me').click();
    expect(handleClick).toHaveBeenCalledTimes(1);
  });
});
```

#### API Mocking with MSW

```typescript
// __tests__/mocks/handlers.ts
import { http, HttpResponse } from 'msw';

export const handlers = [
  http.get('/api/vendors', () => {
    return HttpResponse.json({
      success: true,
      data: [
        { id: 1, name: 'Vendor A' },
        { id: 2, name: 'Vendor B' },
      ],
    });
  }),
];
```

### Test Configuration

Test setup is configured in:
- `jest.config.mjs`: Jest configuration
- `src/testSetup.ts`: Global test setup
- `src/__tests__/mocks/`: Mock implementations (fileMock.js, styleMock.js, server.ts, handlers.ts, apiMocks.ts)

## Deployment

### Production Build

```bash
# Build optimized production bundle
npm run build:prod

# Output directory: dist/
```

### Docker Deployment

#### Multi-stage Build

The Dockerfile supports multi-stage builds:

1. **base**: Install dependencies
2. **development**: Development environment with hot reload
3. **builder**: Build optimized production bundle
4. **production**: NGINX server with static files

```bash
# Build production image
docker build --target production -t stratium-frontend:prod .

# Run production container
docker run -p 80:80 stratium-frontend:prod
```

### NGINX Configuration

The production deployment uses NGINX with:

- **Gzip compression**: For reduced payload sizes
- **Cache headers**: For static asset caching
- **SPA routing**: All routes redirect to index.html
- **Security headers**: XSS protection, content type options
- **Health check endpoint**: `/health` for container orchestration

```nginx
# Key NGINX configuration
location / {
    try_files $uri $uri/ /index.html;
}

# Static asset caching
location ~* \.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

### Environment Variables in Production

**Important**: Vite embeds environment variables at build time. Ensure all required variables are set before building:

```bash
# Set environment variables before building
export VITE_API_BASE_URL=https://api.production.com/api
export VITE_AUTH_PROVIDER=entra

# Build with environment variables
npm run build:prod
```

Alternatively, use an `.env.production` file in the project root:

```env
# .env.production
# API Configuration
VITE_API_BASE_URL=https://api.production.com/api
VITE_AUTH_PROVIDER=entra
```

For Docker deployments, use build arguments:

```bash
docker build \
  --target production \
  --build-arg BUILD_ENV=production \
  -t stratium-frontend:prod .
```

### Health Checks

The production container includes health check configuration:

```dockerfile
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD curl -f http://localhost/health || exit 1
```

### Deployment Checklist

- [ ] Create `.env.production` file with required variables
- [ ] Set `VITE_API_BASE_URL` to production API base (include `/api` suffix if used)
- [ ] Set `VITE_AUTH_PROVIDER` if using SAP CDC branding (SCV)
- [ ] Run production build: `npm run build:prod`
- [ ] Test build locally: `npm run preview:prod`
- [ ] Verify API connectivity and cookie session login/logout (see [docs/FRONTEND_AUTHENTICATION.md](./docs/FRONTEND_AUTHENTICATION.md))
- [ ] Build Docker image with production target
- [ ] Test Docker container locally
- [ ] Configure health checks in orchestration platform
- [ ] Set up monitoring and logging
- [ ] Configure CDN for static assets (optional)

## Storybook

### Commands

- `npm run storybook`: start Storybook locally.
- `npm run typecheck:storybook`: validate Storybook TypeScript.
- `npm run build-storybook`: create the production static bundle.

### Story Placement

Place `Component.stories.tsx` beside `Component.tsx`. Use Atomic Design
categories such as `Atoms`, `Molecules`, `Organisms`, and `Templates`.
Foundation documentation belongs under `src/stories/foundations`.

### Required Metadata

Use `satisfies Meta<typeof Component>`, define `component`, `title`, and
`tags: ['autodocs']`, and derive stories with `StoryObj<typeof meta>`.

### Required Coverage

Document the default state, meaningful variants, loading, empty, error,
disabled, and interactive states where applicable. Avoid stories that only
duplicate another story at a different arbitrary value.

### Storybook Providers

All stories are automatically wrapped by the shared `StorybookProviders` decorator configured in `.storybook/preview.tsx`.

The provider supplies:

- `MemoryRouter` for components using React Router.
- `QueryClientProvider` for components using TanStack Query.
- `TenantConfigProvider` for tenant-specific features and configuration.
- `PageFiltersProvider` for components using page-filter context.

Stories normally **do not need to import or render `StorybookProviders` directly**.

#### Using global providers

A component that depends on one of the supported contexts can use a regular story:

```tsx
import type { Meta, StoryObj } from '@storybook/react';

import { TenantSummary } from './TenantSummary';

const meta = {
  title: 'Molecules/Tenant Summary',
  component: TenantSummary,
  tags: ['autodocs'],
} satisfies Meta<typeof TenantSummary>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
```

If `TenantSummary` calls `useTenantConfig()`, it receives the tenant selected from the Storybook toolbar automatically.

#### Selecting a tenant

Use the tenant toolbar to render stories as one of the supported tenants:

- `scrm`
- `scv.customer.vendor`
- `scv.customer`
- `scv.vendor`

Changing the toolbar value rerenders all stories using the selected tenant.

#### Locking a story to one tenant

A story can override the toolbar selection with the `tenant` parameter:

```tsx
export const VendorTenant: Story = {
  parameters: {
    tenant: 'scv.vendor',
  },
};
```

The provider resolves the tenant in this order:

1. The story-level `parameters.tenant` value.
2. The tenant selected in the Storybook toolbar.
3. The `scrm` default configured by `StorybookProviders`.

Use a story-level override when a component state or feature is only available for a specific tenant. Otherwise, allow the toolbar to control the tenant.

#### React Router example

Components using `Link`, `NavLink`, `useNavigate`, or other React Router APIs work without an additional router:

```tsx
function UserProfileLink() {
  return <Link to="/profile">View profile</Link>;
}

export const Default: Story = {};
```

The global provider supplies `MemoryRouter`, so the story does not modify the browser’s real URL.

#### TanStack Query example

Components using `useQuery` or `useMutation` receive a Storybook-specific query client:

```tsx
function UserName() {
  const { data, isLoading } = useQuery({
    queryKey: ['storybook-user'],
    queryFn: async () => ({ name: 'Jane Carter' }),
  });

  if (isLoading) {
    return <span>Loading...</span>;
  }

  return <span>{data?.name}</span>;
}
```

The Storybook query client disables automatic retries and is separate from the application’s production client. Stories that call backend endpoints should use mocked data or MSW handlers rather than contacting a real service.

#### Adding a story-specific provider

When a component needs context that is not part of `StorybookProviders`, add a local decorator:

```tsx
export const WithSpecialContext: Story = {
  decorators: [
    (Story) => (
      <SpecialContextProvider value="example">
        <Story />
      </SpecialContextProvider>
    ),
  ],
};
```

Local decorators are composed with the global providers; they do not replace them.

#### Authentication

Do not add the production authentication provider to the global Storybook configuration. It may trigger OIDC redirects, token handling, and backend requests.

Auth-dependent stories should use a story-specific mock provider:

```tsx
export const Authenticated: Story = {
  decorators: [
    (Story) => (
      <MockAuthProvider
        user={{
          firstName: 'Jane',
          lastName: 'Carter',
          email: 'jane.carter@example.com',
        }}
      >
        <Story />
      </MockAuthProvider>
    ),
  ],
};
```

This keeps stories deterministic, isolated, and safe to run locally or in CI.

### Assets

Import source assets as ES modules. Do not use paths such as
`src/assets/image.png` as runtime URLs.

### Providers and Data

Use global Storybook providers for routing, query context, page filters, and
tenant configuration. Never use the production auth provider in stories.
Use story-level mocks or MSW handlers for authentication and API data.

### Design Tokens

Use semantic CSS tokens from `src/index.css` and the CDS token package.
Do not copy token values into component styles or Storybook-only constants.

### Accessibility

Every interactive control must have an accessible name. Images must have
appropriate alt text. Resolve serious accessibility-panel violations before
merging.

### Review Checklist

- [ ] The component renders independently.
- [ ] Public variants and failure states are represented.
- [ ] Controls match the public API.
- [ ] Assets and tokens use application-supported imports.
- [ ] Stories do not perform real authentication or production API requests.
- [ ] Keyboard and accessibility behavior has been checked.
- [ ] `typecheck:storybook` and `build-storybook` pass.

## Code Quality

### ESLint

The project uses ESLint with TypeScript support:

```bash
# Run linting
npm run lint

# Fix auto-fixable issues
npm run lint -- --fix
```

Configuration: `eslint.config.js`

### Prettier

Code formatting is enforced with Prettier:

```bash
# Format all files
npm run format

# Check formatting
npm run format:check
```

Configuration: `.prettierrc` (if present) or default settings

### TypeScript

TypeScript strict mode is enabled for type safety:

```json
{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitAny": true
  }
}
```

### Code Standards

- **Component Naming**: PascalCase for components, camelCase for utilities
- **File Naming**: Match component name (Button.tsx), camelCase for utilities
- **Exports**: Named exports for utilities, default exports for pages
- **Type Definitions**: Explicit types for function parameters and return values
- **Comments**: JSDoc for public APIs, inline comments for complex logic
- **Imports**: Absolute imports using path aliases

### Pre-commit Hooks

Consider adding Husky for pre-commit hooks:

```bash
# Example pre-commit workflow
- Run TypeScript compiler (tsc --noEmit)
- Run ESLint (npm run lint)
- Run Prettier (npm run format:check)
- Run tests (npm run test -- --watchAll=false)
```

## Performance

### Build Optimization

Vite provides several optimizations out of the box:

- **Code Splitting**: Automatic chunk splitting for vendor and app code
- **Tree Shaking**: Dead code elimination
- **Minification**: Terser for JavaScript, CSS minification
- **Asset Optimization**: Image optimization and lazy loading

### Runtime Performance

#### Code Splitting

```typescript
// Lazy load routes for smaller initial bundle
const OverviewPage = lazy(() => import('@/pages/OverviewPage'));
const ManagePage = lazy(() => import('@/pages/manage/ManagePage'));

<Route
  path="/overview"
  element={
    <Suspense fallback={<LoadingSpinner />}>
      <OverviewPage />
    </Suspense>
  }
/>
```

#### Memoization

```typescript
// Use React.memo for expensive components
export const ExpensiveComponent = React.memo(({ data }) => {
  // Component logic
});

// Use useMemo for expensive calculations
const sortedData = useMemo(() => {
  return data.sort((a, b) => a.value - b.value);
}, [data]);

// Use useCallback for stable function references
const handleClick = useCallback(() => {
  // Handler logic
}, [dependency]);
```

#### Virtual Scrolling

For large lists, consider implementing virtual scrolling:

```typescript
import { FixedSizeList } from 'react-window';

<FixedSizeList
  height={600}
  itemCount={items.length}
  itemSize={50}
  width="100%"
>
  {({ index, style }) => (
    <div style={style}>{items[index]}</div>
  )}
</FixedSizeList>
```

### Bundle Analysis

Analyze bundle size to identify optimization opportunities:

```bash
# Build with bundle analysis
npm run build -- --mode production

# Vite outputs chunk size information by default
```

### Performance Monitoring

Consider integrating performance monitoring:

- **Web Vitals**: Core Web Vitals tracking (LCP, FID, CLS)
- **Lighthouse**: Regular Lighthouse audits in CI/CD
- **Performance API**: Custom performance marks and measures
- **Error Tracking**: Integration with Sentry or similar

### Best Practices

- **Lazy Load Images**: Use native lazy loading or intersection observer
- **Debounce Input**: Debounce search inputs and filters
- **Optimize Re-renders**: Use React DevTools Profiler to identify bottlenecks
- **Reduce Dependencies**: Regularly audit and remove unused dependencies
- **CDN for Assets**: Serve static assets from CDN in production

---

## Additional Resources

### Documentation
- [React Documentation](https://react.dev/)
- [Vite Documentation](https://vitejs.dev/)
- [Zustand Documentation](https://docs.pmnd.rs/zustand/)
- [React Router Documentation](https://reactrouter.com/)
- [Tailwind CSS Documentation](https://tailwindcss.com/)

### Design System
- Custom Cencora Design System (CDS) located in `lib/`
- Design tokens: `lib/cds-tokens-web/`

### API Documentation
- Backend API documentation: See `apireadme.md`
- API base URL: Configured via `VITE_API_BASE_URL`

---

For additional support or questions, please contact the development team or refer to the project wiki.
