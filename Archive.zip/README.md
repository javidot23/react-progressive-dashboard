# Stratium Frontend

React frontend for the Stratium / SCV supply-chain platform.

All tenants use one frontend deployment and one API. The authenticated session determines the active tenant; the frontend adapts UI from that context, and the API routes data to the correct database.

## Table of Contents

- [Getting Started](#getting-started)
- [Multi-Tenancy](#multi-tenancy)
- [Docker Setup](#docker-setup)
- [Project Structure](#project-structure)
- [Architecture](#architecture)
- [API Integration](#api-integration)
- [Authentication](#authentication)
- [Security](#security)
- [Routing](#routing)
- [Development](#development)
- [CI/CD & Deployment](#cicd--deployment)
- [Storybook](#storybook)
- [Testing](#testing)
- [Code Quality](#code-quality)
- [Performance](#performance)

## Getting Started

### Prerequisites

- Node.js 20.x or higher
- npm 10.x or higher
- Docker (optional, for containerized setup)
- Git

### Local Development Setup

1. **Clone and install**

   ```bash
   git clone <repository-url>
   cd stratium-frontend
   npm install
   ```

2. **Environment configuration**

   ```bash
   cp .env.example .env.development
   ```

   Minimal `.env.development`:

   ```env
   # Include /api when the Django API is mounted there
   VITE_API_BASE_URL=http://localhost:8000/api

   # SAP AaaS profile page link (optional)
   VITE_CDC_DOMAIN=https://tst.aaas.cencora.com
   ```

   `VITE_API_BASE_URL` is required. OIDC runs server-side (BFF); see [Authentication](#authentication).

3. **Start the dev server**

   ```bash
   npm run dev
   ```

   App: `http://localhost:5173`

## Multi-Tenancy

Tenants share a single frontend and API. After login, the app loads tenant context from the API and maps `tenant_type` to portal flags that control routes, navigation, and UI variants. The frontend does not send a tenant id on requests; the backend session selects the tenant and database.

### Bootstrap flow

```
App mount
  → GET /auth/me/          (cookie session)
  → if authenticated: prefetch GET /tenants/context/
  → map tenant_type → portal flags (features / modules)
  → AppRoutes / Manage nav / charts read those flags
```

| File                                  | Role                                             |
| ------------------------------------- | ------------------------------------------------ |
| `src/tenant/tenantContextQuery.ts`    | Fetches `/tenants/context/`, React Query options |
| `src/tenant/model.ts`                 | Types + `getTenantPortalFlags(tenant_type)`      |
| `src/tenant/useTenantContextQuery.ts` | Auth-aware hook                                  |
| `src/contexts/AuthContext.tsx`        | Prefetches tenant context after login            |
| `src/routes/AppRoutes.tsx`            | Registers routes from portal flags               |
| `src/constants/manageRoutes.ts`       | Manage nav filtered by `tenant_type`             |

### Tenant context API

**`GET /tenants/context/`** (authenticated, cookie session)

Success:

```json
{
  "success": true,
  "data": {
    "tenant_uuid": "…",
    "tenant_code": "kaiser",
    "tenant_name": "Kaiser",
    "tenant_type": "customer",
    "entitlement_tier": "standard",
    "is_federated": false
  }
}
```

`tenant_type` values:

| Type              | Portal role       | Typical UI                                                          |
| ----------------- | ----------------- | ------------------------------------------------------------------- |
| `customer`        | Downstream        | Manage Orders; customer-oriented modules                            |
| `vendor`          | Upstream          | Custom Lists, Inventory, FTS, Chargebacks, SSC, and related modules |
| `customer_vendor` | Upstream (hybrid) | Custom Lists, Inventory, Forecast Comparison, and related modules   |

If the session has no active tenant, the API may return **403** with `code: "tenant_required"`. A tenant picker UI is not implemented yet (`TODO` in `AuthContext`).

### Portal flags

`getTenantPortalFlags(tenant_type)` returns the capability object used across the app:

```ts
import { selectTenantPortalFlags, useTenantContextQuery } from "@/tenant";

function Example() {
  const { data: flags } = useTenantContextQuery(selectTenantPortalFlags);

  if (!flags?.isReady) return null;

  return (
    <>
      {flags.features.customLists && <CustomListsLink />}
      {flags.modules.manageInventory && <InventoryNav />}
      {flags.isUpstream && <UpstreamDemandCharts />}
    </>
  );
}
```

Useful fields:

- Identity: `tenantType`, `isCustomer`, `isVendor`, `isCustomerVendor`, `isUpstream`, `isDownstream`, `isReady`
- Features: `features.customLists`, `features.corporateChainSales`
- Modules: `modules.manageOrders`, `manageInventory`, `manageFTS`, `manageChargebacks`, …

Exact matrix: `src/tenant/model.ts` (unit tests in `src/tenant/__tests__/`).

### Gating routes and navigation

- **Routes** — `AppRoutes` registers paths from flags (e.g. `/custom-lists`, chargebacks, forecast comparison).
- **Manage primary sections** — `getAvailableManagePrimaryRoutes(flags)` includes Inventory only when `manageInventory` is true.
- **Manage nav** — items may set `types: "vendor"` or `types: ["vendor", "customer_vendor"]` and are filtered with `matchesTenantType`.

To add a capability, extend the flags map in `model.ts`, then gate routes/UI with those flags. Prefer flags over hard-coded `tenant_type` checks when a flag already exists.

### Build vs runtime

Vite `VITE_*` values configure the **deployment environment** (API URL, CDC domain, New Relic, app version). Tenant type and module visibility come from `/tenants/context/` at runtime. The shared bundle includes lazy page chunks; `AppRoutes` registers only the routes allowed for the active tenant.

## Docker Setup

### Build and run

```bash
# Production image (BUILD_ENV must match a package.json script: prod | staging | dev)
docker build --target production --build-arg BUILD_ENV=prod \
  --build-arg VITE_API_BASE_URL=https://api.example.com/api \
  --build-arg VITE_CDC_DOMAIN=https://tst.aaas.cencora.com \
  -t stratium-frontend:prod .

docker run -p 80:80 stratium-frontend:prod
```

### Docker Compose

```bash
docker-compose up
```

Configure via `.env` / compose env. `BUILD_ENV` defaults in compose may need `prod` / `dev` to match `npm run build:*` scripts (see `Dockerfile`).

## Project Structure

```
stratium-frontend/
├── src/
│   ├── components/          # Atomic Design UI
│   ├── pages/               # Route-level pages
│   ├── tenant/              # Runtime multi-tenancy (context API + flags)
│   ├── contexts/            # Auth, filters, etc.
│   ├── routes/              # pages.ts (lazy imports) + AppRoutes.tsx
│   ├── lib/                 # apiClient, auth URLs, helpers
│   ├── stores/              # Zustand
│   ├── hooks/
│   └── __tests__/           # Jest + MSW mocks (includes /tenants/context/)
├── .github/workflows/       # PR CI + ACR image build
├── Dockerfile               # Multi-stage: development | builder | production
├── nginx.conf
└── package.json
```

## Architecture

### Technology stack

- React 19, TypeScript, Vite
- Tailwind CSS + Cencora Design System tokens
- TanStack Query (server state, including tenant context)
- Zustand (client/UI state)
- React Router v7
- Axios (`withCredentials` cookie session)
- Jest + Testing Library + MSW
- Docker + NGINX (production static hosting)

### Design patterns

1. **Service / API layer** — Axios client + domain helpers
2. **Runtime tenant flags** — single map from API `tenant_type` to UI capability
3. **Custom hooks** — encapsulate query + domain logic
4. **Lazy routes** — code-split pages; feature availability enforced in `AppRoutes`

## API Integration

### Client

- Base URL: `import.meta.env.VITE_API_BASE_URL`
- Cookies: `withCredentials: true`
- CSRF: unsafe methods send `X-CSRFToken`
- **No tenant header** — backend session selects tenant / DB

### Standard response shape

```json
{ "success": true, "data": {} }
```

```json
{
  "success": false,
  "type": "validation_error",
  "code": "invalid",
  "error": "Error message"
}
```

Tenant context uses the same envelope (`TenantContextResponse` in `src/tenant/model.ts`).

### Environment variables

See `.env.example`.

| Variable            | Required                     | Purpose                                            |
| ------------------- | ---------------------------- | -------------------------------------------------- |
| `VITE_API_BASE_URL` | Yes                          | API / BFF base (include `/api` when mounted there) |
| `VITE_CDC_DOMAIN`   | Recommended in deployed envs | SAP AaaS profile link                              |
| `VITE_NEW_RELIC_*`  | Optional                     | Browser agent                                      |
| `VITE_APP_VERSION`  | Optional                     | Shown in UI / Info page                            |

## Authentication

SPA uses a **BFF cookie session** (no browser OIDC). Django performs login; the browser holds `sessionid` (HttpOnly) and `csrftoken`.

- Bootstrap: `GET /auth/me/` on load
- Unauthenticated (non-public path): full-page redirect to `{API}/login/start/`
- Login: top-level navigation only (never axios)
- Logout: `POST` logout, then optional IdP `end_session_url`
- After auth: prefetch `GET /tenants/context/`
- Protected routes: `ProtectedRoute` in `AppRoutes`

Key files: `src/contexts/AuthContext.tsx`, `src/lib/authUrls.ts`, `src/lib/apiClient.ts`.

## Security

- Cookie session: HttpOnly `sessionid`; CSRF via `csrftoken` / `X-CSRFToken` on unsafe methods
- Login uses full-page navigation to the BFF (`/login/start/`), not XHR
- Production Vite builds inject a baseline Content-Security-Policy; tune deploy-time CSP for API and IdP origins as needed

## Routing

Lazy imports live in `src/routes/pages.ts` (always available as chunks). **Registration** is runtime in `src/routes/AppRoutes.tsx` using tenant portal flags.

Typical paths:

```
/login, /disclaimer, /glossary, /info
/overview
/react, /react/product/:issueId, …
/plan, /plan/vendor/:vendorId
/manage/summary | inventory | demand | supply | sales   (primary; inventory flag-gated)
/manage/...                                              (secondary; many flag-gated)
/custom-lists                                            (feature flag)
/disruptions-map                                         (when tenant context is ready)
/profile, /export-actions
```

## Development

### Scripts

```bash
npm run dev                  # Vite development
npm run dev:staging          # Vite staging mode
npm run build                # production (default)
npm run build:dev
npm run build:staging
npm run build:prod
npm run build:analyze
npm run lint
npm run format
npm run test                 # Jest watch
npm run test:all             # Jest once (CI)
npm run preview / preview:staging / preview:prod
npm run storybook
npm run typecheck:storybook
npm run build-storybook
```

### Environment modes

Vite loads `.env.[mode]`:

- `development` → `npm run dev` / `build:dev`
- `staging` → `dev:staging` / `build:staging`
- `production` → `build` / `build:prod`

### Branching (promotion)

```
feature/*  →  dev  →  test  →  stage  →  main (prod)
```

Pushes to `dev` / `test` / `stage` / `main` trigger the build-and-deploy workflow for that environment. See [.github/workflows/README.MD](./.github/workflows/README.MD).

### Path aliases

- `@/*` → `src/*`

## CI/CD & Deployment

### PR checks — `ci.yaml`

On pull requests: pre-commit, dependency review, lint/format/typecheck, Jest coverage,
`build`, Storybook build, a hardened Docker build with Trivy scans, and Helm
lint/template/kubeconform across six values overlays (`dev`, `test`, `stage`,
`prod`, `nkp-test`, `nkp-stage`).

Local parity command:

```bash
set -euo pipefail
: > rendered.yaml
for VALUES_FILE in \
  values-dev.yaml values-test.yaml values-stage.yaml values-prod.yaml \
  values-nkp-test.yaml values-nkp-stage.yaml; do
  helm lint helm/stratium-frontend \
    -f "helm/stratium-frontend/${VALUES_FILE}" \
    --set image.repository=example.azurecr.io/ci-scan/stratium-frontend \
    --set image.digest=sha256:0000000000000000000000000000000000000000000000000000000000000000

  helm template stratium-frontend helm/stratium-frontend \
    -f "helm/stratium-frontend/${VALUES_FILE}" \
    --set image.repository=example.azurecr.io/ci-scan/stratium-frontend \
    --set image.digest=sha256:0000000000000000000000000000000000000000000000000000000000000000 \
    >> rendered.yaml
done
```

### Build & deploy — `build-deploy.yaml`

Builds one frontend image per environment and deploys it via `helm upgrade --atomic`
against [helm/stratium-frontend](./helm/stratium-frontend):

| Branch  | Env   | Example image tag |
| ------- | ----- | ----------------- |
| `dev`   | dev   | `1.0.42-dev`      |
| `test`  | test  | `1.0.42-test`     |
| `stage` | stage | `1.0.42-stage`    |
| `main`  | prod  | `1.0.42-prod`     |

GitHub Environment: **`{env}`** (`dev`/`test`/`stage`/`prod`).

Required vars:

- `VITE_API_BASE_URL`
- `VITE_CDC_DOMAIN`
- `ACR_NAME`, `IMAGE_REPOSITORY`, `AKS_RESOURCE_GROUP`, `AKS_CLUSTER_NAME`, `K8S_NAMESPACE`, `HELM_RELEASE_NAME`, `HELM_CHART_PATH`, `APP_VERSION_PREFIX`

Plus Azure OIDC vars for ACR/AKS, optional New Relic secrets.

Manual run:

```bash
gh workflow run build-deploy.yaml --ref test
```

Deployment to AKS happens inside this workflow (self-hosted runners), not in a separate
repo. Tenant identity and feature flags are resolved by the browser at runtime via
`/tenants/context/` - one image/release serves every tenant per environment.

### Azure Dev routing

The Azure `dev` overlay serves `https://stratium.az.dev.cencorapr.com/` through the
private Application Gateway using HTTP between Front Door, Application Gateway, and
AKS. The chart owns the `/` route and restricts workload ingress to the Application
Gateway subnet `10.157.176.0/23`; public TLS terminates at Front Door, so the Kubernetes
Ingress has no TLS configuration or SSL redirect. These settings apply only to Azure
Dev and do not change the OnPrem/NKP overlays.

### Production build locally

```bash
export VITE_API_BASE_URL=https://api.example.com/api
export VITE_CDC_DOMAIN=https://…

npm run build:prod
npm run preview:prod
```

Docker:

```bash
docker build --target runtime \
  --build-arg BUILD_ENV=prod \
  --build-arg VITE_API_BASE_URL=https://api.example.com/api \
  --build-arg VITE_CDC_DOMAIN=https://… \
  -t stratium-frontend:prod .
```

Vite embeds `VITE_*` at image build time (API URL, observability, version). The CSP
connect-src/frame-src origins are also derived from these same build args and rendered
into nginx's response headers at build time (see `nginx-security-headers.conf.template`
and `scripts/generate-nginx-security-headers.mjs`) - not injected as an HTML `<meta>` tag.
Tenant capabilities still come from `/tenants/context/` after login.

### Checklist

- [ ] `VITE_API_BASE_URL` points at the API for that env
- [ ] `VITE_CDC_DOMAIN` set if profile links are needed
- [ ] Cookie session login/logout works against the BFF
- [ ] `/tenants/context/` returns the expected `tenant_type` after login
- [ ] UI modules match flags for that type
- [ ] Image tagged `{version}-{env}` (e.g. `1.0.42-dev`)

## Storybook

### Commands

- `npm run storybook`
- `npm run typecheck:storybook`
- `npm run build-storybook`

Published Storybook: see [.github/workflows/README.MD](./.github/workflows/README.MD) (GitHub Pages from `dev`).

### Providers

Global wrapper: `.storybook/StorybookProviders.tsx` — QueryClient, MemoryRouter, PageFilters.

MSW handlers in `src/__tests__/mocks/handlers.ts` mock `GET /tenants/context/` (default `tenant_type: "customer_vendor"`). Override that handler in a story when you need another type:

```ts
parameters: {
  msw: {
    handlers: [
      http.get(/.*\/tenants\/context\/($|\?)/, () =>
        HttpResponse.json({
          success: true,
          data: {
            tenant_uuid: "…",
            tenant_code: "vendor-demo",
            tenant_name: "Vendor Demo",
            tenant_type: "vendor",
            entitlement_tier: "standard",
            is_federated: false,
          },
        })
      ),
    ],
  },
},
```

Or mock `@/tenant` / return a fixed `selectTenantPortalFlags` result in unit tests.

Do **not** mount production `AuthProvider` in Storybook (OIDC redirects). Use story-level mocks.

## Testing

```bash
npm run test        # watch
npm run test:all    # CI
```

Tenant unit tests: `src/tenant/__tests__/`.

When components call `useTenantContextQuery`, either:

1. Wrap with QueryClient + MSW `/tenants/context/`, or
2. Mock the hook / `@/tenant` module and return flags from `getTenantPortalFlags("vendor")`.

## Code Quality

```bash
npm run lint
npm run format
npm run format:check
```

TypeScript strict mode; prefer `@/` imports; PascalCase components.

## Performance

- Lazy-loaded route chunks in `pages.ts`
- Route registration and UI visibility follow portal flags for the active tenant
- Prefer flags over duplicating large trees when adding tenant-specific UI

Bundle analysis: `npm run build:analyze`

---

## Additional resources

- CI/CD details: [.github/workflows/README.MD](./.github/workflows/README.MD)
- Tenant flag matrix: [`src/tenant/model.ts`](./src/tenant/model.ts)
- Auth implementation: `src/contexts/AuthContext.tsx`, `src/lib/authUrls.ts`, `src/lib/apiClient.ts`

For support, contact the development team.
