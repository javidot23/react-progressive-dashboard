// Jest environment setup for environment variables
const { TextEncoder, TextDecoder } = require('util');
const fs = require('fs');
const path = require('path');

// Manually read and parse .env.development file
try {
  const envPath = path.resolve(__dirname, '.env.development');
  if (fs.existsSync(envPath)) {
    const envContent = fs.readFileSync(envPath, 'utf8');
    const envLines = envContent.split('\n');

    envLines.forEach(line => {
      const trimmedLine = line.trim();
      if (trimmedLine && !trimmedLine.startsWith('#') && trimmedLine.includes('=')) {
        const [key, ...valueParts] = trimmedLine.split('=');
        const value = valueParts.join('=').trim();
        process.env[key.trim()] = value;
      }
    });
  }
} catch (error) {
  console.warn('Could not load .env.development file:', error.message);
}

// Set up polyfills before anything else
global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;

// Polyfill Web Streams API for MSW
if (typeof global.TransformStream === 'undefined') {
  const { TransformStream, ReadableStream, WritableStream } = require('stream/web');
  global.TransformStream = TransformStream;
  global.ReadableStream = ReadableStream;
  global.WritableStream = WritableStream;
}

// Polyfill Response for MSW
if (typeof global.Response === 'undefined') {
  global.Response = class Response {
    constructor(body, init) {
      this.body = body;
      this.init = init;
    }
    body = null;
    init = {};
    ok = true;
    status = 200;
    statusText = 'OK';
    headers = new Map();
    url = '';
    type = 'default';
    redirected = false;
    bodyUsed = false;
    async text() { return this.body || ''; }
    async json() { return JSON.parse(this.body || '{}'); }
    clone() { return new Response(this.body, this.init); }
  };
}

// Polyfill BroadcastChannel
if (typeof global.BroadcastChannel === 'undefined') {
  global.BroadcastChannel = class BroadcastChannel {
    constructor(name) { this.name = name; }
    postMessage() {}
    close() {}
    addEventListener() {}
    removeEventListener() {}
    dispatchEvent() { return true; }
  };
}

// Mock localStorage globally
const mockLocalStorage = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
  key: jest.fn(),
  length: 0,
};
Object.defineProperty(global, 'localStorage', { value: mockLocalStorage, writable: true });

// Don't mock location globally - handle it in individual tests if needed

// Mock Image to prevent empty src warnings
global.Image = class {
  constructor() {
    this._src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
    this.alt = '';
    this.onload = null;
    this.onerror = null;
  }
  set src(value) {
    // Always use a valid data URI to prevent empty string warnings
    this._src = value || 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  }
  get src() {
    return this._src;
  }
};

// Mock HTMLImageElement for React components
if (typeof global.HTMLImageElement === 'undefined') {
  global.HTMLImageElement = global.Image;
}

// Environment variables - dotenv has already loaded VITE_API_BASE_URL from .env.development
// Just set the test-specific environment variables
process.env.NODE_ENV = 'test';
process.env.DEV = 'false';
process.env.PROD = 'true';

// Build-time tenant globals — injected by the Vite plugin in production builds.
// Tests default to 'stratium' (full feature set) so existing full-tenant tests keep passing.
// Use TenantConfigProvider with forceTenantId in tests that need a specific tenant.
global.__TENANT__ = 'stratium';
global.__TENANT_CONFIG__ = {
  id: 'stratium',
  name: 'stratium',
  displayName: 'Stratium',
  description: 'Supply Chain Risk Management',
  branding: {
    title: 'Stratium | Supply Chain Risk Management',
    logoVariant: 'stratium',
    primaryColor: '#0057B8',
  },
  features: {
    customLists: true,
    disruptionsMap: true,
    exportActions: true,
    glossary: true,
    productSubstitutionAnalysis: true,
    corporateChainSales: true,
    modifyGoal: true,
  },
  modules: {
    overview: true,
    react: true,
    plan: true,
    manage: true,
    profile: true,
    manageOverview: true,
    manageDemand: true,
    manageSupply: true,
    manageSales: true,
    manageInventory: true,
    manageSupplyManagement: true,
    manageOrders: true,
    manageDistribution: false,
    manageFTS: false,
    manageChargebacks: false,
    manageFormularyChangeTracking: false,
    manageSecureSupplyChain: false,
    manageCSSalesChangeTracking: false,
    manageForecastComparison: false,
  },
};
