import js from "@eslint/js";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import tseslint from "typescript-eslint";
import { defineConfig } from "eslint/config";

export default defineConfig(
  // Must be its own entry: `ignores` alongside `files` is scoped to that block only,
  // so build artifacts would still be linted by the recommended configs below.
  { ignores: ["dist", "storybook-static", "coverage"] },
  js.configs.recommended,
  tseslint.configs.recommended,
  {
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    plugins: {
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
    },
    rules: {
      "no-console": ["error", { allow: ["warn", "error"] }],
      ...reactHooks.configs.recommended.rules,
      // Predates lint running in CI (previously commented out) - ratchet these back to
      // "error" incrementally as each is cleaned up, rather than blocking on the backlog.
      "@typescript-eslint/no-explicit-any": "warn",
      "@typescript-eslint/no-unused-vars": "warn",
      "@typescript-eslint/no-require-imports": "warn",
      "@typescript-eslint/no-empty-object-type": "warn",
      "no-var": "warn",
      "prefer-const": "warn",
      "no-empty": "warn",
      "no-unsafe-finally": "warn",
      "react-hooks/rules-of-hooks": "warn",
    },
  },
  {
    // Node-executed config/build files, not part of the browser bundle - CommonJS and
    // Jest globals, distinct from the browser globals used by application source.
    files: ["**/*.{js,cjs,mjs}"],
    languageOptions: {
      ecmaVersion: 2020,
      globals: { ...globals.node, ...globals.jest },
    },
    rules: {
      // Same ratchet as the ts/tsx block - these scripts predate lint running in CI.
      "@typescript-eslint/no-require-imports": "warn",
      "@typescript-eslint/no-unused-vars": "warn",
    },
  }
);
