#!/usr/bin/env node
// Renders nginx-security-headers.conf.template at Docker build time, computing the CSP
// connect-src/frame-src origins the same way vite-plugins/csp-plugin.ts used to.
import { readFileSync, writeFileSync } from "node:fs";

function originFromUrl(raw) {
  if (!raw?.trim()) return undefined;
  try {
    return new URL(raw.trim()).origin;
  } catch {
    return undefined;
  }
}

function joinOrigins(origins) {
  return [...new Set(origins.filter(Boolean))].join(" ");
}

const [templatePath, outputPath] = process.argv.slice(2);
if (!templatePath || !outputPath) {
  console.error("Usage: generate-nginx-security-headers.mjs <template> <output>");
  process.exit(1);
}

const apiOrigin = originFromUrl(process.env.VITE_API_BASE_URL);
const cdcOrigin = originFromUrl(process.env.VITE_CDC_DOMAIN);

const connectSrc = joinOrigins(["'self'", apiOrigin, cdcOrigin, "https://bam.nr-data.net", "https://*.nr-data.net"]);
const frameSrc = joinOrigins(["'self'", cdcOrigin]);

const template = readFileSync(templatePath, "utf8");
const rendered = template.replaceAll("__CONNECT_SRC__", connectSrc).replaceAll("__FRAME_SRC__", frameSrc);

writeFileSync(outputPath, rendered);
