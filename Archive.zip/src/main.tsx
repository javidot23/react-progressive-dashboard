import { BrowserAgent } from "@newrelic/browser-agent/loaders/browser-agent";
import { Ajax } from "@newrelic/browser-agent/features/ajax";
import { JSErrors } from "@newrelic/browser-agent/features/jserrors";
import { Metrics } from "@newrelic/browser-agent/features/metrics";
import { GenericEvents } from "@newrelic/browser-agent/features/generic_events";
import { PageViewEvent } from "@newrelic/browser-agent/features/page_view_event";
import { PageViewTiming } from "@newrelic/browser-agent/features/page_view_timing";
import { SessionReplay } from "@newrelic/browser-agent/features/session_replay";
import { SessionTrace } from "@newrelic/browser-agent/features/session_trace";
import { SoftNav } from "@newrelic/browser-agent/features/soft_navigations";
import { Logging } from "@newrelic/browser-agent/features/logging";

import React from "react";
import ReactDOM from "react-dom/client";
import App from "@/App";
import "@/index.css";
import { BrowserRouter } from "react-router-dom";
import { QueryProvider } from "@/providers/queryProvider";
import { TableSettingsProvider } from "@/components/atoms";
import ScrollToTop from "@/lib/ScrollToTop";

// New Relic Browser Agent Configuration
const newRelicOptions = {
  init: {
    session_replay: {
      enabled: true,
      block_selector: "",
      mask_text_selector: "",
      sampling_rate: 100.0,
      error_sampling_rate: 100.0,
      mask_all_inputs: false,
      collect_fonts: true,
      inline_images: false,
      inline_stylesheet: true,
      fix_stylesheets: true,
      preload: false,
      mask_input_options: {},
    },
    distributed_tracing: { enabled: true },
    performance: { capture_measures: true },
    browser_consent_mode: { enabled: false },
    privacy: { cookies_enabled: true },
    ajax: { deny_list: ["bam.nr-data.net"], capture_payloads: "off" },
  },
  info: {
    beacon: "bam.nr-data.net",
    errorBeacon: "bam.nr-data.net",
    licenseKey: import.meta.env.VITE_NEW_RELIC_LICENSE_KEY || "",
    applicationID: import.meta.env.VITE_NEW_RELIC_APP_ID || "",
    sa: 1,
  },
  loader_config: {
    accountID: import.meta.env.VITE_NEW_RELIC_ACCOUNT_ID || "",
    trustKey: import.meta.env.VITE_NEW_RELIC_TRUST_KEY || "",
    agentID: import.meta.env.VITE_NEW_RELIC_AGENT_ID || "",
    licenseKey: import.meta.env.VITE_NEW_RELIC_LICENSE_KEY || "",
    applicationID: import.meta.env.VITE_NEW_RELIC_APP_ID || "",
  },
  features: [
    Ajax,
    JSErrors,
    Metrics,
    GenericEvents,
    PageViewEvent,
    PageViewTiming,
    SessionReplay,
    SessionTrace,
    SoftNav,
    Logging,
  ],
};

// Initialize New Relic Browser Agent
new BrowserAgent(newRelicOptions);

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <QueryProvider>
      <TableSettingsProvider>
        <BrowserRouter>
          <ScrollToTop />
          <App />
        </BrowserRouter>
      </TableSettingsProvider>
    </QueryProvider>
  </React.StrictMode>
);
