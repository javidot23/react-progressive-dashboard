import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";

export function useMedalliaPageView() {
  const { pathname } = useLocation();
  const isFirst = useRef(true);

  useEffect(() => {
    if (isFirst.current) {
      isFirst.current = false;
      return;
    }

    window.KAMPYLE_ONSITE_SDK?.updatePageView?.();
  }, [pathname]);
}
