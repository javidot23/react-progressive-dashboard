export type KampyleOnsiteSdk = {
  updatePageView?: () => void;
};

declare global {
  interface Window {
    KAMPYLE_EMBED?: unknown;
    KAMPYLE_ONSITE_SDK?: KampyleOnsiteSdk;
  }
}
