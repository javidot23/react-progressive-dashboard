/**
 * Shared forecast comparison week query helpers (backend: current_week, previous_week as YYYY-MM-DD).
 */

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

export function isIsoDateString(value: string): boolean {
  const s = value.trim();
  if (!ISO_DATE.test(s)) return false;
  const t = new Date(`${s}T12:00:00`).getTime();
  return Number.isFinite(t) && !Number.isNaN(t);
}

/** Both weeks are non-empty valid ISO dates and must be different weeks (two distinct Mondays). */
export function areForecastComparisonWeeksReady(currentWeek: string, previousWeek: string): boolean {
  const c = currentWeek?.trim() ?? "";
  const p = previousWeek?.trim() ?? "";
  return Boolean(c) && Boolean(p) && c !== p && isIsoDateString(c) && isIsoDateString(p);
}
