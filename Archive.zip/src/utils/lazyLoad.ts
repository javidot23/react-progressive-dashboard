import { lazy, ComponentType } from "react";

export function lazyNamed<T extends ComponentType<any>>(
  importFn: () => Promise<{ [key: string]: T }>,
  exportName: string
): React.LazyExoticComponent<T> {
  return lazy(() =>
    retryImport(importFn)
      .then(module => {
        if (!module || !(exportName in module)) {
          throw new Error(
            `Export "${exportName}" not found in module. Available exports: ${Object.keys(module || {}).join(", ")}`
          );
        }

        const component = module[exportName];

        if (typeof component !== "function" && typeof component !== "object") {
          throw new Error(`Export "${exportName}" is not a valid React component (got ${typeof component})`);
        }

        return { default: component as T };
      })
      .catch(error => {
        if (import.meta.env.DEV) {
          console.error(`Failed to load component "${exportName}":`, error);
        }

        throw error;
      })
  );
}

export async function preloadComponent<T>(importFn: () => Promise<T>): Promise<void> {
  await importFn();
}

export function retryImport<T>(importFn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
  return new Promise((resolve, reject) => {
    importFn()
      .then(resolve)
      .catch(error => {
        if (retries === 0) {
          reject(error);
          return;
        }

        setTimeout(() => {
          retryImport(importFn, retries - 1, delay * 2)
            .then(resolve)
            .catch(reject);
        }, delay);
      });
  });
}
