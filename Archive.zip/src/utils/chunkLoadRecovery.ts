const CHUNK_PATTERNS: ReadonlyArray<RegExp> = [
  /Failed to fetch dynamically imported module/i,
  /Loading chunk \d+ failed/i,
  /Importing a module script failed/i,
  /error loading dynamically imported module/i,
  /Failed to load module script/i,
  /dynamically imported module/i,
  /ChunkLoadError/i,
];

export function isChunkLoadError(err: unknown): boolean {
  if (err == null) return false;

  const e = err as { name?: string; message?: string };
  if (e.name === "ChunkLoadError") return true;

  const msg = e.message ?? (typeof err === "string" ? err : "");
  const name = e.name ?? "";

  return CHUNK_PATTERNS.some(p => p.test(msg) || p.test(name));
}
