/** Local calendar date as YYYY-MM-DD (for FTS API `from_date` / `to_date`). */
export function ftsFirstDayOfCurrentMonthIso(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}

export function ftsTodayIso(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/** Sales amount with grouping + 2 decimals, no currency symbol (API e.g. `"89050.87"`). */
export function formatFtsSalesAmount(salesAmount: string | number | null | undefined): string {
  const raw = salesAmount == null || salesAmount === "" ? "" : String(salesAmount);
  const n = Number.parseFloat(raw.replace(/[^0-9.-]/g, ""));
  if (!Number.isFinite(n)) return "—";
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(n);
}

export type FtsPlantsRangeFieldKey =
  | "prxo_missed_lines_min"
  | "prxo_missed_lines_max"
  | "pgen_missed_lines_min"
  | "pgen_missed_lines_max"
  | "total_missed_lines_min"
  | "total_missed_lines_max"
  | "total_missed_lines_pct_min"
  | "total_missed_lines_pct_max"
  | "outbound_fill_rate_min"
  | "outbound_fill_rate_max"
  | "service_level_min"
  | "service_level_max"
  | "omit_qty_min"
  | "omit_qty_max"
  | "demand_qty_min"
  | "demand_qty_max"
  | "ordered_lines_min"
  | "ordered_lines_max";

export const EMPTY_FTS_PLANTS_RANGE_DRAFT: Record<FtsPlantsRangeFieldKey, string> = {
  prxo_missed_lines_min: "",
  prxo_missed_lines_max: "",
  pgen_missed_lines_min: "",
  pgen_missed_lines_max: "",
  total_missed_lines_min: "",
  total_missed_lines_max: "",
  total_missed_lines_pct_min: "",
  total_missed_lines_pct_max: "",
  outbound_fill_rate_min: "",
  outbound_fill_rate_max: "",
  service_level_min: "",
  service_level_max: "",
  omit_qty_min: "",
  omit_qty_max: "",
  demand_qty_min: "",
  demand_qty_max: "",
  ordered_lines_min: "",
  ordered_lines_max: "",
};

/** Append parsed numeric min/max pairs to API params (omit empty / invalid). */
export function mergeFtsPlantsRangeParams(
  target: Record<string, string | number>,
  draft: Record<FtsPlantsRangeFieldKey, string>
): void {
  const tryNum = (s: string): number | undefined => {
    const t = s.trim();
    if (t === "") return undefined;
    const n = Number(t);
    return Number.isFinite(n) ? n : undefined;
  };

  (Object.keys(draft) as FtsPlantsRangeFieldKey[]).forEach(key => {
    const n = tryNum(draft[key]);
    if (n !== undefined) target[key] = n;
  });
}
