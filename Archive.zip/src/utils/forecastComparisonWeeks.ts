import { dateToISO, startOfWeek, subWeeks } from "@/lib/dateUtils";

const DAYS_LOOKBACK = 90;

/**
 * Returns Mondays (week-start dates) in the last 90 days as YYYY-MM-DD.
 * Most recent Monday first.
 */
export function getMondaysInLast90Days(): string[] {
  const today = new Date();
  const mostRecentMonday = startOfWeek(today);
  const mondays: string[] = [];
  const cutoff = new Date(today);
  cutoff.setDate(cutoff.getDate() - DAYS_LOOKBACK);

  let d = new Date(mostRecentMonday);
  while (d >= cutoff) {
    mondays.push(dateToISO(d));
    d = subWeeks(d, 1);
  }

  return mondays;
}

/**
 * Default pair: calendar **current week** (Monday of the week containing today) and the **prior** Monday.
 * Both must fall in the last-90-days window when possible; otherwise falls back to the newest two Mondays in range.
 */
export function getDefaultForecastComparisonWeeks(): { current_week: string; previous_week: string } {
  const mondays = getMondaysInLast90Days();
  const thisMonday = dateToISO(startOfWeek(new Date()));
  const priorMonday = dateToISO(subWeeks(startOfWeek(new Date()), 1));

  if (mondays.includes(thisMonday) && mondays.includes(priorMonday)) {
    return { current_week: thisMonday, previous_week: priorMonday };
  }

  const current_week = mondays[0] ?? thisMonday;
  const previous_week = mondays[1] ?? priorMonday;
  return { current_week, previous_week };
}

/**
 * Ensures previous_week and current_week are allowed Mondays with previous_week < current_week (strict).
 * `mondays` is newest-first from {@link getMondaysInLast90Days}.
 */
export function alignForecastComparisonWeeks(
  previous_week: string,
  current_week: string,
  mondays: string[],
  def: { previous_week: string; current_week: string }
): { previous_week: string; current_week: string } {
  if (mondays.length === 0) return def;
  let np = mondays.includes(previous_week) ? previous_week : def.previous_week;
  let nc = mondays.includes(current_week) ? current_week : def.current_week;
  const i = mondays.indexOf(nc);
  if (i < 0) return def;
  if (np >= nc) {
    if (i + 1 < mondays.length) {
      np = mondays[i + 1];
    } else {
      return def;
    }
  }
  if (np >= nc) return def;
  return { previous_week: np, current_week: nc };
}
