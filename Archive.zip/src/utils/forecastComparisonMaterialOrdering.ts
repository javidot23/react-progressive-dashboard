/** Django `ordering` query param values for weekly-material-forecast-comparison. */
export const MATERIAL_FORECAST_COMPARISON_ORDER_FIELDS = ["total_forecast_change", "total_forecast_change_pct"] as const;

export type MaterialForecastComparisonOrderField = (typeof MATERIAL_FORECAST_COMPARISON_ORDER_FIELDS)[number];

export const DEFAULT_MATERIAL_FORECAST_COMPARISON_ORDERING = "-total_forecast_change_pct";

export function normalizeMaterialForecastComparisonOrdering(raw: string | null | undefined): string {
  const trimmed = (raw ?? "").trim();
  if (!trimmed) return DEFAULT_MATERIAL_FORECAST_COMPARISON_ORDERING;
  const desc = trimmed.startsWith("-");
  const field = (desc ? trimmed.slice(1) : trimmed) as string;
  const allowed = (MATERIAL_FORECAST_COMPARISON_ORDER_FIELDS as readonly string[]).includes(field);
  if (!allowed) return DEFAULT_MATERIAL_FORECAST_COMPARISON_ORDERING;
  return desc ? `-${field}` : field;
}
