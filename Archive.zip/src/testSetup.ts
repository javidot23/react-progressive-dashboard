// Test setup file
import "whatwg-fetch";
import "@testing-library/jest-dom";
/// <reference types="@testing-library/jest-dom" />

// Import MSW server - polyfills are already set up in jest.env.js
import { server } from "@/__tests__/mocks/server";

// Suppress console.error for empty src attributes in tests
const originalConsoleError = console.error;

// MSW server setup and console error suppression
beforeAll(() => {
  // Setup console error suppression
  console.error = (...args: any[]) => {
    if (
      typeof args[0] === "string" &&
      (args[0].includes('An empty string ("") was passed to the src attribute') ||
        args[0].includes("Error: Not implemented: navigation"))
    ) {
      return; // Suppress these specific warnings
    }
    // Don't call originalConsoleError to avoid the recursion issue
    // originalConsoleError.call(console, ...args);
  };

  // Start MSW server
  server.listen();
});

afterEach(() => server.resetHandlers());

afterAll(() => {
  // Restore original console.error
  console.error = originalConsoleError;
  // Close MSW server
  server.close();
});
