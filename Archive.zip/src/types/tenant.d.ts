// Build-time globals injected by vite-plugins/tenant-plugin.ts.
// Full types come from src/tenant/ — declared here for use outside that module.

export {};

declare global {
  // The active tenant ID — matches TenantId in src/tenant/types.ts
  const __TENANT__:
    | 'stratium'
    | 'stratium.customer.vendor'
    | 'stratium.customer'
    | 'stratium.vendor';
  // The full tenant config object — matches TenantBaseConfig in src/tenant/config/types.ts
  const __TENANT_CONFIG__: import('../tenant/config/types').TenantBaseConfig;
}
