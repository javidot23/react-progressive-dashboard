/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE_URL: string;
  readonly VITE_CDC_DOMAIN?: string;
  readonly VITE_TENANT?: import('../tenant/types').TenantId;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

declare global {
  interface Window {
    __VITE_ENV__?: ImportMetaEnv;
  }
}
