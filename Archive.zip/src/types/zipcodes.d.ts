declare module 'zipcodes' {
  interface ZipCodeData {
    zip: string;
    latitude: number;
    longitude: number;
    city: string;
    state: string;
    country: string;
  }

  function lookup(zipCode: string): ZipCodeData | undefined;
  function lookupByName(city: string, state: string): ZipCodeData[];
  function lookupByCoords(latitude: number, longitude: number): ZipCodeData[];
  function distance(zip1: string, zip2: string): number;
  function radius(zipCode: string, miles: number): ZipCodeData[];

  export = {
    lookup,
    lookupByName,
    lookupByCoords,
    distance,
    radius
  };
}
