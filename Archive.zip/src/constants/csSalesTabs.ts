export const CS_SALES_PATH = "/manage/sales/cs-sales-change-tracking";

export const CS_SALES_DATA_TABS = [
  { id: "historical" as const, label: "Historical Data" },
  { id: "current" as const, label: "Current" },
] as const;

export type CSalesTab = "historical" | "current";

export function getCSalesTabFromParams(searchParams: URLSearchParams): CSalesTab {
  const tab = searchParams.get("tab");
  return tab === "current" ? "current" : "historical";
}
