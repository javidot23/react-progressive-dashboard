import type { TenantId } from '@/tenant';
import { matchesTenant } from '@/tenant';

export interface ManageDropdownItem {
  label: string;
  path: string;
  tenant?: TenantId | readonly TenantId[];
  [key: string]: unknown;
}

export const DROPDOWN_SUBPAGES: Record<string, ManageDropdownItem[]> = {
  Supply: [
    { label: "Overview", path: "/manage/supply/overview" },
    { label: "Supplier Performance", path: "/manage/supply/scorecard", tenant: "stratium" as TenantId },
  ],
  Orders: [
    { label: "Overview", path: "/manage/orders/overview" },
    { label: "Alt Serve", path: "/manage/orders/alt-serve", tenant: ["stratium", "stratium.vendor"] as const },
  ],
  Sales: [
    { label: "Overview", path: "/manage/sales/overview" },
    { label: "Sales Change Tracking", path: "/manage/sales/cs-sales-change-tracking", tenant: "stratium.vendor" as TenantId },
    { label: "Forecast Comparison", path: "/manage/sales/forecast-comparison", tenant: ["stratium.vendor", "stratium.customer.vendor"] as const },
  ],
  Inventory: [{ label: "Overview", path: "/manage/inventory/overview" }],
  // Vendor-only
  FTS: [
    { label: "Mitigation", path: "/manage/fts/mitigation" },
    // FTS Validation temporarily disabled — restore when route is re-enabled in AppRoutes
    // { label: "Validation", path: "/manage/fts/validation" },
  ],
  Chargebacks: [
    { label: "Overview", path: "/manage/chargebacks/overview" },
    { label: "DCO", path: "/manage/chargebacks/dco" },
    { label: "Validation", path: "/manage/chargebacks/validation" },
  ],
  "Secure Supply Chain": [
    { label: "Inbound Scans", path: "/manage/secure-supply-chain/inbound-scans" },
    { label: "Quarantine", path: "/manage/secure-supply-chain/quarantine" },
    { label: "Serialization", path: "/manage/secure-supply-chain/serialization" },
  ],
};

export const MANAGE_SECTION_MAP: Record<string, string> = {
  supply: "Supply",
  demand: "Demand",
  distribution: "Distribution",
  orders: "Orders",
  sales: "Sales",
  inventory: "Inventory",
  "supply-management": "Supply Management",
  // Vendor-only sections
  fts: "FTS",
  chargebacks: "Chargebacks",
  "formulary-change-tracking": "Formulary Change Tracking",
  "secure-supply-chain": "Secure Supply Chain",
} as const;

export const MANAGE_ROUTE_MAP: Record<string, string> = {
  Overview: "/manage/overview",
  Demand: "/manage/demand/overview",
  Supply: "/manage/supply/overview",
  Orders: "/manage/orders/overview",
  Sales: "/manage/sales/overview",
  Inventory: "/manage/inventory/overview",
  "Supply Management": "/manage/supply-management",
  // Vendor-only
  FTS: "/manage/fts",
  Chargebacks: "/manage/chargebacks",
  "Formulary Change Tracking": "/manage/formulary-change-tracking",
  "Secure Supply Chain": "/manage/secure-supply-chain/inbound-scans",
} as const;

export const NAVIGATION_ITEMS = [
  { name: "Overview", hasDropdown: false },
  { name: "Supply Management", hasDropdown: false, tenant: "stratium" as TenantId },
  { name: "Demand", hasDropdown: true },
  { name: "Orders", hasDropdown: true, tenant: ["stratium", "stratium.customer"] as const },
  { name: "Supply", hasDropdown: true },
  { name: "Inventory", hasDropdown: false, tenant: ["stratium", "stratium.vendor", "stratium.customer.vendor"] as const },
  { name: "Sales", hasDropdown: true },
  // Vendor-only tabs
  { name: "FTS", hasDropdown: true, tenant: "stratium.vendor" as TenantId },
  { name: "Chargebacks", hasDropdown: true, tenant: "stratium.vendor" as TenantId },
  { name: "Formulary Change Tracking", hasDropdown: false, tenant: "stratium.vendor" as TenantId },
  { name: "Secure Supply Chain", hasDropdown: true, tenant: "stratium.vendor" as TenantId },
] as const;

export const OVERVIEW_PATHS = new Set([
  "/manage",
  "/manage/overview",
  "/manage/demand/overview",
  "/manage/supply/overview",
  "/manage/supply-management",
  "/manage/orders/overview",
  "/manage/sales/overview",
  "/manage/inventory/overview",
]);

export const VALID_MANAGE_SECTIONS = new Set([
  "overview",
  "demand",
  "supply",
  "supply-management",
  "orders",
  "sales",
  "inventory",
  "distribution",
  // Vendor-only
  "fts",
  "chargebacks",
  "formulary-change-tracking",
  "secure-supply-chain",
]);

// Per-path tenant requirements — used by isManagePathAllowedForTenant
// to check whether a route is accessible for the active tenant.
const PATH_TENANT_REQUIREMENTS: Array<{ prefix: string; required: TenantId | readonly TenantId[] }> = [
  { prefix: '/manage/supply-management', required: 'stratium' },
  { prefix: '/manage/supply/scorecard', required: 'stratium' },
  { prefix: '/manage/sales/cs-sales-change-tracking', required: 'stratium.vendor' },
  { prefix: '/manage/sales/forecast-comparison', required: ['stratium.vendor', 'stratium.customer.vendor'] as const },
  { prefix: '/manage/fts', required: 'stratium.vendor' as TenantId },
  { prefix: '/manage/chargebacks', required: 'stratium.vendor' },
  { prefix: '/manage/formulary-change-tracking', required: 'stratium.vendor' },
  { prefix: '/manage/secure-supply-chain', required: 'stratium.vendor' },
  { prefix: '/manage/inventory', required: ['stratium', 'stratium.vendor', 'stratium.customer.vendor'] as const },
  { prefix: '/manage/orders/alt-serve', required: ['stratium', 'stratium.vendor'] as const },
];

// Cache path → required tenant to avoid re-scanning on every render.
const pathTenantCache = new Map<string, TenantId | readonly TenantId[] | null>();

export function getTenantRequirementForManagePath(pathname: string): TenantId | readonly TenantId[] | null {
  if (pathTenantCache.has(pathname)) return pathTenantCache.get(pathname)!;
  const match = PATH_TENANT_REQUIREMENTS.find((r) => pathname.startsWith(r.prefix));
  const result = match ? match.required : null;
  pathTenantCache.set(pathname, result);
  return result;
}

/**
 * Returns true if the given pathname is accessible for the active tenant.
 * Used by navigation guards to redirect disallowed manage paths.
 */
export function isManagePathAllowedForTenant(pathname: string, tenantId: TenantId): boolean {
  const required = getTenantRequirementForManagePath(pathname);
  if (!required) return true;
  return matchesTenant(required, tenantId);
}

export type ManageSection = keyof typeof MANAGE_SECTION_MAP | "overview";
export type NavigationItemName = (typeof NAVIGATION_ITEMS)[number]["name"];
