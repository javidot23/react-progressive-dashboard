import type { TenantType } from "@/tenant";

export interface ManageDropdownItem {
  label: string;
  path: string;
  types?: TenantType | readonly TenantType[];
  [key: string]: unknown;
}

export const DROPDOWN_SUBPAGES: Record<string, ManageDropdownItem[]> = {
  Supply: [{ label: "Overview", path: "/manage/supply/overview" }],
  Orders: [
    { label: "Overview", path: "/manage/orders/overview", types: "customer" },
    { label: "Alt Serve", path: "/manage/orders/alt-serve", types: "vendor" },
  ],
  Sales: [
    { label: "Overview", path: "/manage/sales/overview" },
    { label: "Sales Change Tracking", path: "/manage/sales/cs-sales-change-tracking", types: "vendor" },
    { label: "Forecast Comparison", path: "/manage/sales/forecast-comparison", types: ["vendor", "customer_vendor"] },
  ],
  Inventory: [{ label: "Overview", path: "/manage/inventory/overview", types: ["vendor", "customer_vendor"] }],
  FTS: [
    { label: "Mitigation", path: "/manage/fts/mitigation", types: "vendor" },
    // FTS Validation temporarily disabled — restore when route is re-enabled in AppRoutes
    // { label: "Validation", path: "/manage/fts/validation" },
  ],
  Chargebacks: [
    { label: "Overview", path: "/manage/chargebacks/overview", types: "vendor" },
    { label: "DCO", path: "/manage/chargebacks/dco", types: "vendor" },
    { label: "Validation", path: "/manage/chargebacks/validation", types: "vendor" },
  ],
  "Secure Supply Chain": [
    { label: "Inbound Scans", path: "/manage/secure-supply-chain/inbound-scans", types: "vendor" },
    { label: "Quarantine", path: "/manage/secure-supply-chain/quarantine", types: "vendor" },
    { label: "Serialization", path: "/manage/secure-supply-chain/serialization", types: "vendor" },
  ],
};

export const MANAGE_SECTION_MAP: Record<string, string> = {
  supply: "Supply",
  demand: "Demand",
  distribution: "Distribution",
  orders: "Orders",
  sales: "Sales",
  inventory: "Inventory",
  fts: "FTS",
  chargebacks: "Chargebacks",
  "formulary-change-tracking": "Formulary Change Tracking",
  "secure-supply-chain": "Secure Supply Chain",
} as const;

export const MANAGE_ROUTE_MAP: Record<string, string> = {
  Overview: "/manage/overview",
  Demand: "/manage/demand/overview",
  Supply: "/manage/supply/overview",
  Orders: "/manage/orders/overview",
  Sales: "/manage/sales/overview",
  Inventory: "/manage/inventory/overview",
  FTS: "/manage/fts",
  Chargebacks: "/manage/chargebacks",
  "Formulary Change Tracking": "/manage/formulary-change-tracking",
  "Secure Supply Chain": "/manage/secure-supply-chain/inbound-scans",
} as const;

export const NAVIGATION_ITEMS: ReadonlyArray<{
  name: string;
  hasDropdown: boolean;
  types?: TenantType | readonly TenantType[];
}> = [
  { name: "Overview", hasDropdown: false },
  { name: "Demand", hasDropdown: true },
  { name: "Orders", hasDropdown: true, types: ["customer", "vendor"] },
  { name: "Supply", hasDropdown: true },
  { name: "Inventory", hasDropdown: false, types: ["vendor", "customer_vendor"] },
  { name: "Sales", hasDropdown: true },
  { name: "FTS", hasDropdown: true, types: "vendor" },
  { name: "Chargebacks", hasDropdown: true, types: "vendor" },
  { name: "Formulary Change Tracking", hasDropdown: false, types: "vendor" },
  { name: "Secure Supply Chain", hasDropdown: true, types: "vendor" },
];

export const OVERVIEW_PATHS = new Set([
  "/manage",
  "/manage/overview",
  "/manage/demand/overview",
  "/manage/supply/overview",
  "/manage/orders/overview",
  "/manage/sales/overview",
  "/manage/inventory/overview",
]);

export const VALID_MANAGE_SECTIONS = new Set([
  "overview",
  "demand",
  "supply",
  "orders",
  "sales",
  "inventory",
  "distribution",
  "fts",
  "chargebacks",
  "formulary-change-tracking",
  "secure-supply-chain",
]);

export type ManageSection = keyof typeof MANAGE_SECTION_MAP | "overview";
export type NavigationItemName = (typeof NAVIGATION_ITEMS)[number]["name"];
