import "@testing-library/jest-dom";
import { act, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useLayoutEffect, useMemo, useState, type ReactNode } from "react";
import { PageFiltersProvider, usePageFilters, usePageFiltersActions, usePageFiltersState } from "@/contexts/PageFiltersContext";
import { usePageFilterRegistration } from "@/hooks/usePageFilterRegistration";

const stableSlot: ReactNode = <span data-testid="slot">filters</span>;

function RegisterIdenticalTwice() {
  const { registerPageFilters } = usePageFiltersActions();
  useLayoutEffect(() => {
    registerPageFilters(stableSlot, "test-reg-id", { hasActiveFilters: false });
    registerPageFilters(stableSlot, "test-reg-id", { hasActiveFilters: false });
  }, [registerPageFilters]);
  return null;
}

/**
 * Re-registers whenever `n` changes with a fresh options object identity (same field values) —
 * provider should bail out and not recurse.
 */
function ReregisterEveryParentRender({ n }: { n: number }) {
  const { registerPageFilters } = usePageFiltersActions();
  useLayoutEffect(() => {
    registerPageFilters(stableSlot, "stable-reg-id", { hasActiveFilters: false });
  }, [registerPageFilters, n]);
  return null;
}

function BumpParentRerenderHarness() {
  const [n, setN] = useState(0);
  return (
    <div>
      <button type="button" aria-label="bump-count" onClick={() => setN(x => x + 1)}>
        Bump
      </button>
      <span data-testid="bump-val">{n}</span>
      <ReregisterEveryParentRender n={n} />
    </div>
  );
}

function SlotOutlet() {
  const { slot } = usePageFiltersState();
  return <div data-testid="slot-wrap">{slot}</div>;
}

function RegistrationEcho() {
  const { options } = usePageFiltersState();
  return <span data-testid="has-active">{String(options.hasActiveFilters ?? false)}</span>;
}

function ToggleRegistration({ active }: { active: boolean }) {
  const { registerPageFilters } = usePageFiltersActions();
  const noop = useMemo(() => () => {}, []);
  useLayoutEffect(() => {
    registerPageFilters(stableSlot, "toggle-id", { hasActiveFilters: active, onClearAllFilters: noop });
  }, [registerPageFilters, active, noop]);
  return null;
}

describe("PageFiltersProvider", () => {
  it("bails out on duplicate synchronous register with identical payload", () => {
    let childRenders = 0;
    function CountingSubscriber() {
      usePageFiltersState();
      childRenders++;
      return null;
    }

    render(
      <PageFiltersProvider>
        <RegisterIdenticalTwice />
        <CountingSubscriber />
      </PageFiltersProvider>
    );

    expect(childRenders).toBeLessThan(50);
  });

  it("does not hit maximum update depth when parent re-renders re-run registration with unstable options identity", async () => {
    const user = userEvent.setup();
    const errSpy = jest.spyOn(console, "error").mockImplementation((...args: unknown[]) => {
      const msg = String(args[0] ?? "");
      if (msg.includes("Maximum update depth exceeded")) {
        throw new Error(msg);
      }
    });

    let childRenders = 0;
    function CountingSubscriber() {
      usePageFiltersState();
      childRenders++;
      return null;
    }

    try {
      render(
        <PageFiltersProvider>
          <BumpParentRerenderHarness />
          <CountingSubscriber />
          <SlotOutlet />
        </PageFiltersProvider>
      );

      for (let i = 0; i < 15; i++) {
        await act(async () => {
          await user.click(screen.getByRole("button", { name: "bump-count" }));
        });
      }
    } finally {
      errSpy.mockRestore();
    }

    expect(screen.getByTestId("bump-val")).toHaveTextContent("15");
    expect(childRenders).toBeLessThan(200);
    expect(within(screen.getByTestId("slot-wrap")).getByTestId("slot")).toBeInTheDocument();
  });

  it("does not re-render action-only consumers when registration state updates with equivalent payload", async () => {
    const user = userEvent.setup();
    let actionOnlyRenders = 0;

    function ActionOnlyConsumer() {
      usePageFiltersActions();
      actionOnlyRenders++;
      return null;
    }

    function StateMutatingRegistrar() {
      const { registerPageFilters } = usePageFiltersActions();
      const [n, setN] = useState(0);

      useLayoutEffect(() => {
        registerPageFilters(stableSlot, "action-only-id", { hasActiveFilters: false });
      }, [registerPageFilters, n]);

      return (
        <button type="button" aria-label="mutate-registration" onClick={() => setN(x => x + 1)}>
          Mutate {n}
        </button>
      );
    }

    render(
      <PageFiltersProvider>
        <ActionOnlyConsumer />
        <StateMutatingRegistrar />
        <SlotOutlet />
      </PageFiltersProvider>
    );

    const rendersAfterMount = actionOnlyRenders;

    for (let i = 0; i < 10; i++) {
      await act(async () => {
        await user.click(screen.getByRole("button", { name: "mutate-registration" }));
      });
    }

    expect(actionOnlyRenders).toBe(rendersAfterMount);
    expect(within(screen.getByTestId("slot-wrap")).getByTestId("slot")).toBeInTheDocument();
  });

  it("updates layout options when hasActiveFilters changes", () => {
    const { rerender } = render(
      <PageFiltersProvider>
        <ToggleRegistration active={false} />
        <RegistrationEcho />
      </PageFiltersProvider>
    );

    expect(screen.getByTestId("has-active")).toHaveTextContent("false");

    rerender(
      <PageFiltersProvider>
        <ToggleRegistration active={true} />
        <RegistrationEcho />
      </PageFiltersProvider>
    );

    expect(screen.getByTestId("has-active")).toHaveTextContent("true");
  });

  it("exposes hasActiveFilters from usePageFilters", () => {
    function Registrar() {
      const { registerPageFilters } = usePageFiltersActions();
      useLayoutEffect(() => {
        registerPageFilters(stableSlot, "combined-id", {
          hasActiveFilters: true,
          onClearAllFilters: () => {},
        });
      }, [registerPageFilters]);
      return null;
    }

    function CombinedReader() {
      const { hasActiveFilters } = usePageFilters();
      return <span data-testid="combined-active">{String(hasActiveFilters)}</span>;
    }

    render(
      <PageFiltersProvider>
        <Registrar />
        <CombinedReader />
      </PageFiltersProvider>
    );

    expect(screen.getByTestId("combined-active")).toHaveTextContent("true");
  });
});

describe("usePageFilterRegistration", () => {
  it("does not re-register on parent re-render when options object identity changes but values stay the same", async () => {
    const user = userEvent.setup();
    let stateRenders = 0;
    const stableClear = jest.fn();

    function HookConsumer({ bump }: { bump: number }) {
      usePageFilterRegistration(stableSlot, { hasActiveFilters: false, onClearAllFilters: stableClear });
      return <span data-testid="bump">{bump}</span>;
    }

    function Parent() {
      const [n, setN] = useState(0);
      return (
        <>
          <button type="button" aria-label="parent-bump" onClick={() => setN(x => x + 1)}>
            Bump
          </button>
          <HookConsumer bump={n} />
        </>
      );
    }

    function StateCounter() {
      usePageFiltersState();
      stateRenders++;
      return null;
    }

    render(
      <PageFiltersProvider>
        <Parent />
        <StateCounter />
        <SlotOutlet />
      </PageFiltersProvider>
    );

    const rendersAfterMount = stateRenders;

    for (let i = 0; i < 10; i++) {
      await act(async () => {
        await user.click(screen.getByRole("button", { name: "parent-bump" }));
      });
    }

    expect(screen.getByTestId("bump")).toHaveTextContent("10");
    expect(stateRenders).toBe(rendersAfterMount);
    expect(within(screen.getByTestId("slot-wrap")).getByTestId("slot")).toBeInTheDocument();
  });

  it("keeps slot registered when hasActiveFilters toggles (layout cleanup then re-register)", () => {
    const stableClear = jest.fn();

    function HookConsumer({ active }: { active: boolean }) {
      usePageFilterRegistration(stableSlot, { hasActiveFilters: active, onClearAllFilters: stableClear });
      return null;
    }

    const { rerender } = render(
      <PageFiltersProvider>
        <HookConsumer active={false} />
        <RegistrationEcho />
        <SlotOutlet />
      </PageFiltersProvider>
    );

    expect(screen.getByTestId("has-active")).toHaveTextContent("false");
    expect(within(screen.getByTestId("slot-wrap")).getByTestId("slot")).toBeInTheDocument();

    rerender(
      <PageFiltersProvider>
        <HookConsumer active={true} />
        <RegistrationEcho />
        <SlotOutlet />
      </PageFiltersProvider>
    );

    expect(screen.getByTestId("has-active")).toHaveTextContent("true");
    expect(within(screen.getByTestId("slot-wrap")).getByTestId("slot")).toBeInTheDocument();
  });
});
