import { createContext, useContext, useState, useCallback, useMemo, type ReactNode } from "react";

export interface PageFiltersRegistrationOptions {
  hasActiveFilters?: boolean;
  onClearAllFilters?: () => void;
}

interface PageFiltersState {
  slot: ReactNode | null;
  registrationId: string | null;
  options: PageFiltersRegistrationOptions;
  showPageFilters: boolean;
}

interface PageFiltersActions {
  registerPageFilters: (slot: ReactNode, id: string, options: PageFiltersRegistrationOptions) => void;
  unregisterPageFilters: (id: string) => void;
  setShowPageFilters: (show: boolean) => void;
}

const PageFiltersStateContext = createContext<PageFiltersState>({
  slot: null,
  registrationId: null,
  options: {},
  showPageFilters: false,
});

const PageFiltersActionsContext = createContext<PageFiltersActions>({
  registerPageFilters: () => {},
  unregisterPageFilters: () => {},
  setShowPageFilters: () => {},
});

function isSamePageFiltersRegistration(
  prev: PageFiltersState,
  slot: ReactNode,
  id: string,
  options: PageFiltersRegistrationOptions
): boolean {
  return (
    prev.registrationId === id &&
    prev.slot === slot &&
    prev.options.hasActiveFilters === options.hasActiveFilters &&
    prev.options.onClearAllFilters === options.onClearAllFilters
  );
}

export function PageFiltersProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PageFiltersState>({
    slot: null,
    registrationId: null,
    options: {},
    showPageFilters: false,
  });

  const registerPageFilters = useCallback(
    (slot: ReactNode, id: string, options: PageFiltersRegistrationOptions) => {
      setState(prev => {
        if (isSamePageFiltersRegistration(prev, slot, id, options)) return prev;
        return { ...prev, slot, registrationId: id, options };
      });
    },
    []
  );

  const unregisterPageFilters = useCallback((id: string) => {
    setState(prev => {
      if (prev.registrationId !== id) return prev;
      return { ...prev, slot: null, registrationId: null, options: {} };
    });
  }, []);

  const setShowPageFilters = useCallback((show: boolean) => {
    setState(prev => {
      if (prev.showPageFilters === show) return prev;
      return { ...prev, showPageFilters: show };
    });
  }, []);

  const actionsValue = useMemo(
    () => ({ registerPageFilters, unregisterPageFilters, setShowPageFilters }),
    [registerPageFilters, unregisterPageFilters, setShowPageFilters]
  );

  return (
    <PageFiltersActionsContext.Provider value={actionsValue}>
      <PageFiltersStateContext.Provider value={state}>
        {children}
      </PageFiltersStateContext.Provider>
    </PageFiltersActionsContext.Provider>
  );
}

export function usePageFiltersState() {
  return useContext(PageFiltersStateContext);
}

export function usePageFiltersActions() {
  return useContext(PageFiltersActionsContext);
}

/**
 * Combined hook for ManageLayout — reads filter content and exposes the show/hide toggle.
 */
export function usePageFilters() {
  const { slot, showPageFilters, options } = useContext(PageFiltersStateContext);
  const { setShowPageFilters } = useContext(PageFiltersActionsContext);
  return {
    pageFiltersContent: slot,
    showPageFilters,
    setShowPageFilters,
    hasActiveFilters: options.hasActiveFilters ?? false,
    onClearAllFilters: options.onClearAllFilters,
  };
}
