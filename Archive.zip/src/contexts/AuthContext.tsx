import React, { createContext, useContext, useEffect, useCallback, useState } from "react";
import { setNewRelicUser, clearNewRelicUser } from "@/lib/newRelicUser";
import { redirectToLogin, getEndSessionUrl } from "@/lib/authUrls";
import type { LogoutResponse } from "@/lib/authUrls";
import { queryClient } from "@/lib/queryClient";
import { isTenantRequiredError, tenantContextQueryOptions } from "@/tenant/tenantContextQuery";

import apiClient, {
  DOMAIN_NOT_ALLOWED_CODE,
  DomainNotAllowedError,
  EMAIL_NOT_ALLOWED_CODE,
  EmailNotAllowedError,
  onAuthFailure,
  suppressAuthRedirects,
} from "@/lib/apiClient";
import { useGlobalFiltersStore } from "@/stores/slices/globalFilters";

interface User {
  entra_id: string;
  email: string;
  first_name: string;
  last_name: string;
  is_active: boolean;
  date_joined?: string;
  last_login?: string;
}

interface AppAuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  isLoading: boolean;
  error: string | null;
  login: () => void;
  logout: () => Promise<void>;
  checkAuthStatus: () => Promise<void>;
}

type SessionProbeResult =
  | { status: "authenticated"; user: User }
  | { status: "unauthenticated" }
  | { status: "error"; message: string };

const AppAuthContext = createContext<AppAuthContextType | undefined>(undefined);

export const useAuth = (): AppAuthContextType => {
  const context = useContext(AppAuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

function resolveProbeErrorMessage(err: unknown): string {
  const responseCode =
    err && typeof err === "object" && (err as { response?: { data?: { code?: string } } }).response?.data?.code;
  const errCode =
    err instanceof DomainNotAllowedError
      ? DOMAIN_NOT_ALLOWED_CODE
      : err instanceof EmailNotAllowedError
        ? EMAIL_NOT_ALLOWED_CODE
        : (err && typeof err === "object" && (err as { code?: string }).code) || responseCode;

  if (errCode === DOMAIN_NOT_ALLOWED_CODE) {
    return "Your domain is not allowed to access this application. Please contact your administrator.";
  }
  if (errCode === EMAIL_NOT_ALLOWED_CODE) {
    return "Your email is not allowed to access this application. Please contact your administrator.";
  }
  return err instanceof Error ? err.message : "Failed to fetch user information";
}

async function prefetchTenantContext(): Promise<void> {
  try {
    // fetchQuery warms the shared Query cache and rejects on failure (unlike prefetchQuery).
    await queryClient.fetchQuery(tenantContextQueryOptions());
  } catch (err) {
    // Non-blocking: error remains in the Query cache for consumers via useQuery.
    // TODO(tenant-picker): authenticated but no active_tenant_uuid in session.
    // Future: show tenant selection UI (GET /api/tenants/ + POST /api/tenants/active/).
    if (isTenantRequiredError(err) && import.meta.env.DEV) {
      console.error("[tenant-context] tenant_required");
    }
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [appUser, setAppUser] = useState<User | null>(null);
  const [appError, setAppError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const mapProfileToUser = useCallback((userInfo: Record<string, string | undefined>): User => {
    return {
      entra_id: userInfo.id as string,
      email: (userInfo.mail || userInfo.userPrincipalName) as string,
      first_name: userInfo.givenName || "",
      last_name: userInfo.surname || "",
      is_active: true,
    };
  }, []);

  const probeSession = useCallback(async (): Promise<SessionProbeResult> => {
    try {
      const response = await apiClient.get("/auth/me/", {
        skipAuthRedirect: true,
      });

      if (response.data.success) {
        return {
          status: "authenticated",
          user: mapProfileToUser(response.data.data),
        };
      }
      return {
        status: "error",
        message: response.data.error || "Failed to get user information",
      };
    } catch (err: unknown) {
      if (err && typeof err === "object" && (err as { name?: string }).name === "AuthenticationError") {
        return { status: "unauthenticated" };
      }

      console.error("Failed to fetch user from backend:", err);
      return { status: "error", message: resolveProbeErrorMessage(err) };
    }
  }, [mapProfileToUser]);

  const applySessionResult = useCallback((result: SessionProbeResult) => {
    if (result.status === "authenticated") {
      setAppUser(result.user);
      setAppError(null);
      setNewRelicUser({
        id: result.user.entra_id,
        email: result.user.email,
        firstName: result.user.first_name,
        lastName: result.user.last_name,
      });
      return;
    }

    setAppUser(null);
    if (result.status === "error") {
      setAppError(result.message);
    } else {
      setAppError(null);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthFailure(() => {
      setAppUser(null);
      setAppError("Your session has expired. Please sign in again.");
      clearNewRelicUser();
    });

    return unsubscribe;
  }, []);

  useEffect(() => {
    let cancelled = false;

    const bootstrap = async () => {
      setIsLoading(true);
      const result = await probeSession();
      if (cancelled) return;
      applySessionResult(result);
      if (result.status === "authenticated") {
        void prefetchTenantContext();
      }
      setIsLoading(false);
    };

    void bootstrap();

    return () => {
      cancelled = true;
    };
  }, [probeSession, applySessionResult]);

  const login = useCallback(() => {
    setAppError(null);
    redirectToLogin();
  }, []);

  const logout = useCallback(async () => {
    suppressAuthRedirects();
    setAppError(null);

    try {
      await queryClient.cancelQueries();
      queryClient.clear();

      const response = await apiClient.post<LogoutResponse>("/logout/", undefined, {
        skipAuthRedirect: true,
      });
      const endSessionUrl = getEndSessionUrl(response.data);

      clearNewRelicUser();
      setAppUser(null);
      useGlobalFiltersStore.getState().clearFilters();

      if (endSessionUrl) {
        window.location.assign(endSessionUrl);
      } else {
        window.location.assign("/login");
      }
    } catch (err: unknown) {
      console.error("Logout failed:", err);
      clearNewRelicUser();
      setAppUser(null);
      useGlobalFiltersStore.getState().clearFilters();
      window.location.assign("/login");
    }
  }, []);

  const checkAuthStatus = useCallback(async () => {
    setIsLoading(true);
    const result = await probeSession();
    applySessionResult(result);
    if (result.status === "authenticated") {
      void prefetchTenantContext();
    }
    setIsLoading(false);
  }, [probeSession, applySessionResult]);

  const contextValue: AppAuthContextType = {
    isAuthenticated: !!appUser,
    user: appUser,
    isLoading,
    error: appError,
    login,
    logout,
    checkAuthStatus,
  };

  return <AppAuthContext.Provider value={contextValue}>{children}</AppAuthContext.Provider>;
};
