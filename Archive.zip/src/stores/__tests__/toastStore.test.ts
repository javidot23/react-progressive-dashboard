import { MAX_TOASTS, useToastStore } from "@/stores/toastStore";

describe("toastStore", () => {
  beforeEach(() => {
    useToastStore.setState({ toasts: [] });
  });

  const makeToast = (id: string): import("@/stores/toastStore").ToastItem => ({
    id,
    variant: "info",
    title: `Title ${id}`,
  });

  it("addToast appends items", () => {
    useToastStore.getState().addToast(makeToast("a"));
    useToastStore.getState().addToast(makeToast("b"));
    expect(useToastStore.getState().toasts.map(t => t.id)).toEqual(["a", "b"]);
  });

  it("caps at MAX_TOASTS and drops oldest", () => {
    for (let i = 0; i <= MAX_TOASTS + 1; i += 1) {
      useToastStore.getState().addToast(makeToast(`t${i}`));
    }
    const ids = useToastStore.getState().toasts.map(t => t.id);
    expect(ids).toHaveLength(MAX_TOASTS);
    expect(ids[0]).toBe("t2");
    expect(ids[MAX_TOASTS - 1]).toBe(`t${MAX_TOASTS + 1}`);
  });

  it("dismiss removes only matching id", () => {
    useToastStore.getState().addToast(makeToast("keep"));
    useToastStore.getState().addToast(makeToast("gone"));
    useToastStore.getState().dismiss("gone");
    expect(useToastStore.getState().toasts.map(t => t.id)).toEqual(["keep"]);
  });

  it("dismissAll clears queue", () => {
    useToastStore.getState().addToast(makeToast("x"));
    useToastStore.getState().addToast(makeToast("y"));
    useToastStore.getState().dismissAll();
    expect(useToastStore.getState().toasts).toEqual([]);
  });
});
