import { create } from "zustand";

export const MAX_TOASTS = 5;

export type ToastVariant = "success" | "error" | "info" | "warning";

export interface ToastAction {
  label: string;
  onClick: () => void;
}

export interface ToastItem {
  id: string;
  variant: ToastVariant;
  title: string;
  description?: string;
  duration?: number;
  action?: ToastAction;
}

interface ToastState {
  toasts: ToastItem[];
  addToast: (toast: ToastItem) => void;
  dismiss: (id: string) => void;
  dismissAll: () => void;
}

export const useToastStore = create<ToastState>(set => ({
  toasts: [],
  addToast: toast =>
    set(s => ({
      toasts: [...s.toasts, toast].slice(-MAX_TOASTS),
    })),
  dismiss: id =>
    set(s => ({
      toasts: s.toasts.filter(t => t.id !== id),
    })),
  dismissAll: () => set({ toasts: [] }),
}));
