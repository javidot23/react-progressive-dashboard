import { create } from "zustand";

export interface FilterValue {
  id: string;
  label: string;
}

export interface MultiFilterValue {
  ids: string[];
  labels: string[];
}

export type FilterValueType = FilterValue | MultiFilterValue;

export type GlobalFiltersState = Record<string, FilterValueType>;

export function isMultiFilter(value: FilterValueType): value is MultiFilterValue {
  return value !== null && typeof value === "object" && "ids" in value && Array.isArray((value as MultiFilterValue).ids);
}

interface GlobalFiltersStore {
  filters: GlobalFiltersState;
  version: number; // Bump on every change to trigger refetches

  // Actions
  setFilter: (key: string, value: FilterValueType) => void;
  removeFilter: (key: string) => void;
  clearFilters: () => void;
  setAllFilters: (filters: GlobalFiltersState) => void;
  hydrateFromURL: (search: string) => void;
  hydrateFromLocalStorage: () => void;
}

const LS_KEY = "global_filters";

export const useGlobalFiltersStore = create<GlobalFiltersStore>((set, get) => ({
  filters: {},
  version: 0,

  setFilter: (key: string, value: FilterValueType) => {
    set(state => ({
      filters: { ...state.filters, [key]: value },
      version: state.version + 1,
    }));
  },

  removeFilter: (key: string) => {
    set(state => {
      const newFilters = { ...state.filters };
      delete newFilters[key];
      return {
        filters: newFilters,
        version: state.version + 1,
      };
    });
  },

  clearFilters: () => {
    set(state => ({
      filters: {},
      version: state.version + 1,
    }));
    // Explicitly remove from localStorage
    localStorage.removeItem(LS_KEY);
  },

  setAllFilters: (newFilters: GlobalFiltersState) => {
    set(state => {
      const currentFiltersJson = JSON.stringify(state.filters);
      const newFiltersJson = JSON.stringify(newFilters);

      if (currentFiltersJson === newFiltersJson) {
        return { filters: newFilters };
      }

      return {
        filters: newFilters,
        version: state.version + 1,
      };
    });
  },

  hydrateFromURL: (search: string) => {
    const params = new URLSearchParams(search);
    const filters: GlobalFiltersState = {};

    params.forEach((value, key) => {
      if (key.startsWith("gf_")) {
        // Try to get label from localStorage cache
        const lsData = localStorage.getItem(LS_KEY);
        let cachedLabel = value; // Default to ID

        if (lsData) {
          try {
            const cached = JSON.parse(lsData);
            if (cached[key] && cached[key].label) {
              cachedLabel = cached[key].label;
            }
          } catch (e) {
            // Ignore parse errors
          }
        }

        filters[key] = { id: value, label: cachedLabel };
      }
    });

    // Set filters and write to localStorage
    set({ filters, version: get().version + 1 });
    localStorage.setItem(LS_KEY, JSON.stringify(filters));
  },

  hydrateFromLocalStorage: () => {
    try {
      const stored = localStorage.getItem(LS_KEY);
      if (!stored) return;

      const filters = JSON.parse(stored);
      set({ filters, version: get().version + 1 });
    } catch (e) {
      console.warn("[Global Filters] Failed to parse localStorage:", e);
    }
  },
}));

// Export for direct access (used by interceptor)
export const getGlobalFilters = () => useGlobalFiltersStore.getState().filters;
export const getGlobalFiltersVersion = () => useGlobalFiltersStore.getState().version;
