export interface WeeklyOpenCount {
  currentWeek: number;
  previousWeek: number;
  weekStartDate: string;
  previousWeekStartDate: string;
  requiresActionCount: number;
  difference: number;
  percentageChange: number;
}

// KPI Trend Point - common structure for all KPI trends
export interface KPITrendPoint {
  period_start: string;
  period_end: string;
  value: number;
  metrics?: Record<string, number>;
}

// KPI Trend data structure
export interface KPITrendData {
  kpi?: string;
  unit?: string;
  points: KPITrendPoint[];
}

export interface OtifData {
  thisWeekOtif?: number;
  lastWeekOtif?: number;
  last30DaysOtif?: number;
  previous30DaysOtif?: number;
  // New KPI fields
  kpiValue?: number;
  kpiPreviousValue?: number;
  trend?: KPITrendData;
}

export interface TwoWeekSummary {
  current_total_issues?: number;
  current_opened_issues?: number;
  current_closed_issues?: number;
  previous_total_issues?: number;
  previous_opened_issues?: number;
  previous_closed_issues?: number;
  current_period_start?: string;
  current_period_end?: string;
  previous_period_start?: string;
  previous_period_end?: string;
  open_issues?: number;
  total_issues?: number;
  snapshot_date?: string;
  // New KPI fields
  kpiValue?: number;
  kpiTotal?: number;
  trend?: KPITrendData;
}

export interface OtifTrendsData {
  day: string;
  on_time_count: number;
  in_full_count: number;
  otif_percentage: number;
  total_materials: number;
}

export interface WeeklyOtifLineCountsData {
  year: number;
  week: number;
  otif_count: number;
  ot_but_not_if_count: number;
  if_but_not_ot_count: number;
  not_ot_or_if_count: number;
  total_lines: number;
  otif_percentage: number;
}

export interface WeeklyRiskAnalysis {
  aggregateRiskScore: number;
  totalDollarsAtRisk: number;
  productsCount: number;
  weekStart: string;
  weekEnd: string;
  analysisDate: string;
  // New fields for weekly averages
  averageRiskScoreThisWeek: number;
  averageRiskScoreLastWeek: number;
  averageDollarsAtRiskThisWeek: number;
  averageDollarsAtRiskLastWeek: number;
  thisWeekStart: string;
  thisWeekEnd: string;
  lastWeekStart: string;
  lastWeekEnd: string;
  // New KPI fields
  kpiValue?: number;
  kpiPreviousValue?: number;
  trend?: KPITrendData;
}

export interface ValueAtRiskTrendData {
  kpiValue: number;
  kpiPreviousValue: number;
  trend: KPITrendData;
}

export interface ServiceLevelAnalysis {
  thisWeekAverage: number;
  lastWeekAverage: number;
}

export interface SupplyChainEventDisplay {
  id: number;
  eventId: string;
  type: string;
  typeDescription: string;
  status: string;
  startDate: string;
  endDate: string | null;
  latitude: number | null;
  longitude: number | null;
  createdAt: string;
  updatedAt: string;
  material: number | undefined;
}

export interface VendorDisplay {
  id: number;
  vendorNbr: string;
  name: string;
  country: string;
  city: string;
  latitude: number;
  longitude: number;
  riskRating: number;
  drivingRisk: string;
  vendorGroup?: string;
  createdAt: string;
  updatedAt: string;
  // Extended vendor metrics from API
  totalDollarsAtRisk?: number | null;
  riskAdjustedValue?: number | null;
  materialsAtRisk?: number;
  totalMaterials?: number;
  salesVolume?: number | null;
  salesAmount?: number | null;
  serviceLevels90Days?: Array<{
    date: string;
    avg_fill_rate: number;
    total_order_qty?: number;
    total_received_qty?: number;
  }>;
  inboundFillRate?: number | null;
  outboundFillRate?: number | null;
  productDamagesRate?: number | null;
  otifPercentage?: number | null;
  overallScore?: number | null;
  asnTimeliness?: number | null;
  asnEssential?: number | null;
  catMgrList?: string[];
  buyerList?: string[];
}

export interface CriticalProductDisplay {
  id: number;
  matNbr: string;
  name: string;
  riskRating: number;
  drivingRisk: string;
  dollarsAtRisk: number;
  omits: number;
  eaNumber: string;
  saleableQtyOnHand: number;
  qtyOrdered: number;
  forecastQty7day: number;
  vendor: number;
  vendorName?: string;
  materialGroup?: string;
  productFamily?: string;
  createdAt: string;
  updatedAt: string;
  riskAdjustedValue?: number;
}

export interface MaterialFormulary {
  id: number;
  name: string;
  valid_from: string | null;
  valid_to: string | null;
  created_at: string;
  updated_at: string;
  material: number;
}

export interface MaterialSubstituteDisplay {
  id: number;
  materialId: number;
  materialName: string;
  materialVendorName?: string;
  substituteId: number;
  substituteName: string;
  substituteMatNbr: string;
  riskRating: number;
  drivingRisk: string;
  dollarsAtRisk: number;
  marketShare: number;
  saleableQtyOnHand: number;
  qtyOrdered: number;
  forecastQty7day: number;
  costPerUnit: number;
  vendorId: number;
  vendorNbr?: string;
  omits: number;
  rank: number;
  byContract: boolean;
  createdAt: string;
  updatedAt: string;
  materialFormularies: MaterialFormulary[];
  availablePlantsCount: number;
}

export interface ServiceLevelTrendDisplay {
  date: string;
  day: string;
  mediumImpact: number;
  highImpact: number;
  serviceLevel: number;
  dataType: "actual" | "projected";
  totalOrderQty: number;
  totalRawServiceQty: number;
  rawUnitSl: number;
  vendor: string | null;
}

export interface IssuesState {
  materialSubstitutes: MaterialSubstituteDisplay[];

  materialSubstitutesPagination: {
    currentMaterialId: number | null;
    hasMore: boolean;
    isLoadingMore: boolean;
    offset: number;
    limit: number;
    totalCount: number;
  };

  additionalParams?: string;

  loading: {
    materialSubstitutes: boolean;
  };

  errors: {
    materialSubstitutes: string | null;
  };

  lastFetched: {
    materialSubstitutes: number | null;
  };

  _cardDataCache?: {
    key: string;
    data: {
      title: string;
      value: string;
      change: string;
      changeType: "increase" | "decrease" | "neutral";
      icon: React.ReactNode;
      iconBgColor: string;
    };
  };
}

// KPI Query Parameters for fetching trend data
export interface KPIQueryParams {
  start_date?: string;
  end_date?: string;
  aggregation?: "day" | "week" | "month";
}

export interface IssuesActions {
  fetchMaterialSubstitutes: (materialId: number, reset?: boolean, additionalParams?: string) => Promise<void>;
  loadMoreMaterialSubstitutes: () => Promise<void>;
  clearMaterialSubstitutes: () => void;
  clearAllErrors: () => void;
  resetIssuesState: () => void;
  clearAllCache: () => void;
}

export type IssuesSlice = IssuesState & IssuesActions;
