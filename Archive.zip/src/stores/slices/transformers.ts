import {
  WeeklyOpenCountResponse,
  OtifResponse,
  WeeklyRiskAnalysisResponse,
  MaterialRiskWeeklyAveragesResponse,
  ServiceLevelAnalysisResponse,
  SupplyChainEventsResponse,
  SupplyChainEvent,
  TopRiskiestVendorsResponse,
  RiskiestVendor,
  TopRiskiestMaterialsResponse,
  TopRiskiestMaterial,
  ServiceLevelTrendResponse,
  ServiceLevelTrendData,
  VendorDetail,
} from "@/lib/apiServices";
import { MaterialSubstituteDisplay } from "@/stores/slices/types";
import {
  WeeklyOpenCount,
  OtifData,
  WeeklyRiskAnalysis,
  ServiceLevelAnalysis,
  SupplyChainEventDisplay,
  VendorDisplay,
  CriticalProductDisplay,
  ServiceLevelTrendDisplay,
} from "./types";

const calculatePercentageChange = (current: number, previous: number): number => {
  if (previous === 0) return current > 0 ? 100 : 0;
  return ((current - previous) / previous) * 100;
};

export const transformWeeklyOpenCountResponse = (response: WeeklyOpenCountResponse): WeeklyOpenCount => {
  if (!response.data) {
    throw new Error("Invalid API response: missing data field");
  }

  const { data } = response;
  const difference = data.current_week_count - data.previous_week_count;
  const percentageChange = calculatePercentageChange(data.current_week_count, data.previous_week_count);

  return {
    currentWeek: data.current_week_count,
    previousWeek: data.previous_week_count,
    weekStartDate: data.week_start_date,
    previousWeekStartDate: data.previous_week_start_date,
    requiresActionCount: data.current_week_requires_action_count,
    difference,
    percentageChange,
  };
};

export const transformOtifResponse = (response: OtifResponse): OtifData => {
  if (!response.data || !Array.isArray(response.data) || response.data.length === 0) {
    throw new Error("Invalid API response: missing data field or empty array");
  }

  const data = response.data[0];

  return {
    thisWeekOtif: data.this_week_otif,
    lastWeekOtif: data.last_week_otif,
    last30DaysOtif: data.last_30_days_otif,
    previous30DaysOtif: data.previous_30_days_otif,
    kpiValue: data.kpi_value ?? data.last_30_days_otif,
    kpiPreviousValue: data.kpi_previous_value ?? data.previous_30_days_otif,
    trend: data.trend,
  };
};

export const transformWeeklyRiskAnalysisResponse = (response: WeeklyRiskAnalysisResponse): WeeklyRiskAnalysis => {
  if (!response.data) {
    throw new Error("Invalid API response: missing data field");
  }

  const { data } = response;

  return {
    aggregateRiskScore: data.aggregate_risk_score,
    totalDollarsAtRisk: data.total_dollars_at_risk,
    productsCount: data.products_count,
    weekStart: data.period.week_start,
    weekEnd: data.period.week_end,
    analysisDate: data.period.analysis_date,
    averageRiskScoreThisWeek: data.aggregate_risk_score,
    averageRiskScoreLastWeek: 0,
    averageDollarsAtRiskThisWeek: data.total_dollars_at_risk,
    averageDollarsAtRiskLastWeek: 0,
    thisWeekStart: data.period.week_start,
    thisWeekEnd: data.period.week_end,
    lastWeekStart: "",
    lastWeekEnd: "",
  };
};

export const transformMaterialRiskWeeklyAveragesResponse = (
  response: MaterialRiskWeeklyAveragesResponse
): Partial<WeeklyRiskAnalysis> => {
  if (!response.data) {
    throw new Error("Invalid API response: missing data field");
  }

  const { data } = response;

  return {
    averageRiskScoreThisWeek: data.average_risk_score_this_week,
    averageRiskScoreLastWeek: data.average_risk_score_last_week,
    averageDollarsAtRiskThisWeek: data.average_dollars_at_risk_this_week,
    averageDollarsAtRiskLastWeek: data.average_dollars_at_risk_last_week,
    thisWeekStart: data.period.this_week_start,
    thisWeekEnd: data.period.this_week_end,
    lastWeekStart: data.period.last_week_start,
    lastWeekEnd: data.period.last_week_end,
  };
};

export const transformServiceLevelAnalysisResponse = (response: ServiceLevelAnalysisResponse): ServiceLevelAnalysis => {
  if (!response.success || !response.data) {
    throw new Error("Invalid API response: missing data field");
  }

  const { data } = response;
  const transformed = {
    thisWeekAverage: data.this_week_average,
    lastWeekAverage: data.last_week_average,
  };

  if (typeof transformed.thisWeekAverage !== "number" || isNaN(transformed.thisWeekAverage)) {
    console.warn("Invalid this_week_average:", data.this_week_average);
  }

  if (typeof transformed.lastWeekAverage !== "number" || isNaN(transformed.lastWeekAverage)) {
    console.warn("Invalid last_week_average:", data.last_week_average);
  }

  return transformed;
};

export const transformSupplyChainEventsResponse = (response: SupplyChainEventsResponse): SupplyChainEventDisplay[] => {
  if (!response.success || !response.data || !Array.isArray(response.data)) {
    console.warn("Invalid supply chain events response structure");
    return [];
  }

  return response.data.map((event: SupplyChainEvent) => ({
    id: event.id,
    eventId: event.event_id,
    type: event.type,
    typeDescription: event.type_description,
    status: event.status,
    startDate: event.start_date,
    endDate: event.end_date,
    latitude: event.latitude,
    longitude: event.longitude,
    createdAt: event.created_at,
    updatedAt: event.updated_at,
    material: event.material,
  }));
};

export const transformTopRiskiestVendorsResponse = (response: TopRiskiestVendorsResponse): VendorDisplay[] => {
  if (!response.success || !response.data || !response.data.results || !Array.isArray(response.data.results)) {
    console.warn("Invalid top riskiest vendors response structure");
    return [];
  }

  return response.data.results.map((vendor: RiskiestVendor) => ({
    id: vendor.id,
    vendorNbr: vendor.vendor_nbr,
    name: vendor.name,
    country: vendor.country,
    city: vendor.city,
    latitude: vendor.latitude,
    longitude: vendor.longitude,
    riskRating: vendor.risk_rating,
    drivingRisk: vendor.driving_risk,
    vendorGroup: vendor.vendor_group,
    createdAt: vendor.created_at,
    updatedAt: vendor.updated_at,
  }));
};

export const transformVendorDetailsResponse = (response: {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: VendorDetail[];
  };
  message?: string;
}): VendorDisplay[] => {
  if (!response.success || !response.data || !response.data.results || !Array.isArray(response.data.results)) {
    console.warn("Invalid vendor details response structure");
    return [];
  }

  return response.data.results.map((vendor: VendorDetail) => ({
    id: vendor.id,
    vendorNbr: vendor.vendor_nbr,
    name: vendor.name,
    country: vendor.country,
    city: vendor.city,
    latitude: vendor.latitude,
    longitude: vendor.longitude,
    riskRating: vendor.risk_rating,
    drivingRisk: vendor.driving_risk,
    vendorGroup: vendor.vendor_group,
    createdAt: vendor.created_at,
    updatedAt: vendor.updated_at,
    totalDollarsAtRisk: vendor.total_dollars_at_risk,
    riskAdjustedValue: vendor.risk_adjusted_value,
    materialsAtRisk: vendor.materials_at_risk,
    totalMaterials: vendor.total_materials,
    salesVolume: vendor.sales_volume,
    salesAmount: vendor.sales_amount,
    serviceLevels90Days: vendor.service_levels_90_days,
    inboundFillRate: vendor.inbound_fill_rate,
    outboundFillRate: vendor.outbound_fill_rate,
    productDamagesRate: vendor.product_damages_rate,
    otifPercentage: vendor.otif_percentage,
    overallScore: vendor.overall_score,
    asnTimeliness: vendor.asn_timeliness,
    asnEssential: vendor.asn_essential,
    catMgrList: vendor.cat_mgr_list,
    buyerList: vendor.buyer_list,
  }));
};

export const transformCriticalProductsResponse = (response: TopRiskiestMaterialsResponse): CriticalProductDisplay[] => {
  if (!response.success || !response.data || !response.data.materials || !Array.isArray(response.data.materials)) {
    console.warn("Invalid critical products response structure");
    return [];
  }

  return response.data.materials.map((product: TopRiskiestMaterial) => ({
    id: product.id,
    matNbr: product.mat_nbr,
    name: product.name,
    riskRating: product.risk_rating,
    drivingRisk: product.driving_risk,
    dollarsAtRisk: product.dollars_at_risk,
    omits: 0,
    eaNumber: product.ndc || "",
    saleableQtyOnHand: product.saleable_qty_on_hand,
    qtyOrdered: 0,
    forecastQty7day: product.forecast_qty_7day,
    vendor: typeof product.vendor === "number" ? product.vendor : 0,
    vendorName: typeof product.vendor === "string" ? product.vendor : undefined,
    materialGroup: product.material_group,
    productFamily: product.product_family || undefined,
    createdAt: product.created_at,
    updatedAt: product.updated_at,
  }));
};

export const transformServiceLevelTrendResponse = (response: ServiceLevelTrendResponse): ServiceLevelTrendDisplay[] => {
  if (!response.success || !response.data || !Array.isArray(response.data)) {
    console.warn("Invalid service level trend response structure");
    return [];
  }

  return response.data.map((item: ServiceLevelTrendData) => {
    const [y, m, d] = item.date.split("-").map(Number);
    const date = new Date(y, m - 1, d);
    const day = date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });

    const fillRatePct = item.fill_rate_pct ?? 0;

    return {
      date: item.date,
      day,
      mediumImpact: item.total_order_qty,
      highImpact: item.total_received_qty,
      serviceLevel: fillRatePct,
      dataType: item.data_type,
      totalOrderQty: item.total_order_qty,
      totalRawServiceQty: item.total_received_qty,
      rawUnitSl: fillRatePct / 100,
      vendor: item.vendor ?? null,
    };
  });
};

export const transformMaterialSubstitutesResponse = (response: any): MaterialSubstituteDisplay[] => {
  if (!response?.data?.results || !Array.isArray(response.data.results)) {
    return [];
  }

  return response.data.results.map((item: any, index: number) => {
    const subMatNbr = item.sub_mat_nbr ?? "";
    const numericId = parseInt(String(subMatNbr), 10);
    const id = Number.isNaN(numericId) ? index : numericId;

    const materialFormularies = (item.material_formularies || []).map((f: { mat_nbr?: string; parent_program?: string }) => ({
      id: 0,
      name: f.parent_program ?? "",
      valid_from: null as string | null,
      valid_to: null as string | null,
      created_at: "",
      updated_at: "",
      material: 0,
    }));

    return {
      id,
      materialId: 0,
      materialName: "",
      materialVendorName: item.vendor_name ?? "",
      substituteId: id,
      substituteName: item.name ?? subMatNbr ?? "Unknown",
      substituteMatNbr: subMatNbr,
      riskRating: 0,
      drivingRisk: "",
      dollarsAtRisk: item.dollars_at_risk ?? 0,
      marketShare: item.market_share ?? 0,
      saleableQtyOnHand: item.saleable_qty_on_hand ?? 0,
      qtyOrdered: 0,
      forecastQty7day: item.forecast_qty_7day ?? 0,
      costPerUnit: item.cost_per_unit ?? 0,
      vendorId: 0,
      vendorNbr: item.vendor_nbr ?? "",
      omits: 0,
      rank: item.substitute_material_rank ?? 0,
      byContract: false,
      createdAt: "",
      updatedAt: "",
      materialFormularies,
      availablePlantsCount: item.available_plants_count ?? 0,
    };
  });
};

// Transformer for the legacy REST material-substitute endpoint (used for variant portal tenants)
// Response shape: { id, rank, material: { id, name, mat_nbr, vendor, ... }, material_formularies, available_plants_count }
export const transformMaterialSubstitutesLegacyResponse = (response: any): MaterialSubstituteDisplay[] => {
  if (!response?.data?.results || !Array.isArray(response.data.results)) {
    return [];
  }

  return response.data.results.map((item: any) => {
    const material = item.material ?? {};
    const vendor = material.vendor ?? {};

    const materialFormularies = (item.material_formularies || []).map((f: any) => ({
      id: f.id ?? 0,
      name: f.name ?? "",
      valid_from: null as string | null,
      valid_to: null as string | null,
      created_at: f.created_at ?? "",
      updated_at: f.updated_at ?? "",
      material: 0,
    }));

    return {
      id: item.id,
      materialId: 0,
      materialName: "",
      materialVendorName: vendor.name ?? "",
      substituteId: material.id, // used for /demand-forecast/inventory-on-each-plant/{id}/
      substituteName: material.name ?? material.mat_nbr ?? "Unknown",
      substituteMatNbr: material.mat_nbr ?? "",
      riskRating: material.risk_rating ?? 0,
      drivingRisk: material.driving_risk ?? "",
      dollarsAtRisk: material.dollars_at_risk ?? 0,
      marketShare: material.market_share ?? 0,
      saleableQtyOnHand: material.saleable_qty_on_hand ?? 0,
      qtyOrdered: 0,
      forecastQty7day: material.forecast_qty_7day ?? 0,
      costPerUnit: material.cost_per_unit ?? 0,
      vendorId: vendor.id ?? 0,
      vendorNbr: vendor.vendor_nbr ?? "",
      omits: 0,
      rank: item.rank ?? 0,
      byContract: false,
      createdAt: item.created_at ?? "",
      updatedAt: item.updated_at ?? "",
      materialFormularies,
      availablePlantsCount: item.available_plants_count ?? 0,
    };
  });
};
