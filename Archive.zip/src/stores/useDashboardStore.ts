/**
 * Re-exports manage-dashboard TanStack Query hooks for backward-compatible import paths.
 * Server state for issues lives in useIssuesQuery / useIssuesInfiniteQuery (issueService).
 */
export {
  usePlanOperationsDataQuery as usePlanOperationsData,
  useMaterialOmitCountsQuery as useMaterialOmitCounts,
  useInventoryBandsQuery as useInventoryBands,
  usePlantLeadTimesQuery as usePlantLeadTimes,
  usePlantOrderStatsQuery as usePlantOrderStats,
  useSalesComparisonByMonthQuery as useSalesComparisonByMonth,
  useFulfillmentTrendQuery as useFulfillmentTrend,
  useWeeklyPerformanceQuery as useWeeklyPerformance,
  useFilledOrderedUnitsQuery as useFilledOrderedUnits,
  useClassOfTradeFilledRateQuery as useClassOfTradeFilledRate,
  useDemandTrendDataQuery as useDemandTrendData,
  useMaterialGroupUnitsDataQuery as useMaterialGroupUnitsData,
  useMaterialSalesDataQuery as useMaterialSalesData,
  useContractSalesDataQuery as useContractSalesData,
  useCorporateSalesDataQuery as useCorporateSalesData,
  useStateSalesDataQuery as useStateSalesData,
  useMaterialWithContractSalesDataQuery as useMaterialWithContractSalesData,
  useSubstitutionAltServeKpisQuery,
  usePurchaseOrderDetailQuery as usePurchaseOrderDetail,
  useMaterialOrderQuantitiesQuery as useMaterialOrderQuantities,
  useMaterialOrderQuantitiesMtdQuery as useMaterialOrderQuantitiesMtd,
  useCustomerOrderQuantitiesQuery as useCustomerOrderQuantities,
} from "@/hooks/queries/useManageDashboardQueries";
