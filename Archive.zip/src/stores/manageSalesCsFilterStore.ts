import { create } from "zustand";

interface ManageSalesCsFilterStore {
  federal_cs_ind?: string;
  version: number;
  setFederalCsInd: (value?: string) => void;
  clearFederalCsInd: () => void;
}

export const useManageSalesCsFilterStore = create<ManageSalesCsFilterStore>((set, get) => ({
  federal_cs_ind: undefined,
  version: 0,

  setFederalCsInd: (value?: string) => {
    const normalized = value && value.trim() !== "" ? value : undefined;
    if (get().federal_cs_ind === normalized) return;
    set(state => ({
      federal_cs_ind: normalized,
      version: state.version + 1,
    }));
  },

  clearFederalCsInd: () => {
    if (get().federal_cs_ind === undefined) return;
    set(state => ({
      federal_cs_ind: undefined,
      version: state.version + 1,
    }));
  },
}));

export function getManageSalesCsFilterVersion(): number {
  return useManageSalesCsFilterStore.getState().version;
}
