export { TENANT_CONFIGS } from './definitions';
export type { TenantBaseConfig, TenantBuildConfig, TenantFeatureFlags, TenantModules } from './types';

// Re-exports for the vite build plugin
export { KNOWN_TENANT_IDS } from '../types';
export type { TenantId as BuildableTenantId } from '../types';

export function isValidTenant(value: string): value is import('../types').TenantId {
  return [
    'stratium',
    'stratium.customer.vendor',
    'stratium.customer',
    'stratium.vendor',
  ].includes(value);
}
