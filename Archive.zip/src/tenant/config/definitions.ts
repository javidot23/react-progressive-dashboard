import type { TenantId } from '../types';
import type { TenantBaseConfig } from './types';

type DeepPartial<T> = {
  [K in keyof T]?: T[K] extends object ? DeepPartial<T[K]> : T[K];
};

function deepMerge<T extends object>(base: T, override: DeepPartial<T>): T {
  const result = { ...base };
  for (const key of Object.keys(override) as (keyof T)[]) {
    const val = override[key];
    if (val !== undefined && val !== null) {
      const baseVal = base[key];
      if (
        typeof val === 'object' &&
        !Array.isArray(val) &&
        typeof baseVal === 'object' &&
        baseVal !== null
      ) {
        result[key] = deepMerge(baseVal as object, val as object) as T[typeof key];
      } else {
        result[key] = val as T[typeof key];
      }
    }
  }
  return result;
}

// ─── Stratium default (full feature set) ──────────────────────────────────────

const STRATIUM_CONFIG: TenantBaseConfig = {
  id: 'stratium',
  name: 'stratium',
  displayName: 'Stratium',
  description: 'Supply Chain Risk Management',
  branding: {
    title: 'Stratium | Supply Chain Risk Management',
    logoVariant: 'stratium',
    primaryColor: '#0057B8',
  },
  features: {
    customLists: true,
    disruptionsMap: true,
    exportActions: true,
    glossary: true,
    productSubstitutionAnalysis: true,
    corporateChainSales: true,
    modifyGoal: true,
  },
  modules: {
    overview: true,
    react: true,
    plan: true,
    manage: true,
    profile: true,
    manageOverview: true,
    manageDemand: true,
    manageSupply: true,
    manageSales: true,
    manageInventory: true,
    manageSupplyManagement: true,
    manageOrders: true,
    manageDistribution: false,
    manageFTS: false,
    manageChargebacks: false,
    manageFormularyChangeTracking: false,
    manageSecureSupplyChain: false,
    manageCSSalesChangeTracking: false,
    manageForecastComparison: false,
  },
};

// ─── Per-tenant overrides (only what differs from Stratium) ───────────────────

type TenantOverride = DeepPartial<TenantBaseConfig>;
const TENANT_OVERRIDES: Record<Exclude<TenantId, 'stratium'>, TenantOverride> = {

  // Vendor-like tenant without CS Sales Change, FTS, Chargebacks,
  // Formulary Change Tracking, and Secure Supply Chain.
  'stratium.customer.vendor': {
    id: 'stratium.customer.vendor',
    name: 'stratium-customer-vendor',
    displayName: 'Stratium Customer Vendor',
    description: 'Supply Chain Visibility — Customer Vendor',
    branding: {
      title: 'Stratium | Customer Vendor',
      logoVariant: 'stratium',
      primaryColor: '#0057B8',
    },
    features: {
      productSubstitutionAnalysis: false,
      modifyGoal: false,
    },
    modules: {
      manageSupplyManagement: false,
      manageOrders: false,
      manageForecastComparison: true,
    },
  },

  // Reduced feature set — no vendor sections, no Stratium-only KPIs
  'stratium.customer': {
    id: 'stratium.customer',
    name: 'stratium-customer',
    displayName: 'Stratium Customer',
    description: 'Supply Chain Visibility — Customer',
    branding: {
      title: 'Stratium | Customer',
      logoVariant: 'stratium',
      primaryColor: '#0057B8',
    },
    features: {
      customLists: false,
      disruptionsMap: true,
      corporateChainSales: false,
      modifyGoal: false,
    },
    modules: {
      manageSupplyManagement: false,
    },
  },

  // Vendor-specific — different section set, no substitution analysis
  'stratium.vendor': {
    id: 'stratium.vendor',
    name: 'stratium-vendor',
    displayName: 'Stratium Vendor',
    description: 'Supply Chain Visibility — Vendor',
    branding: {
      title: 'Stratium | Vendor',
      logoVariant: 'stratium',
      primaryColor: '#0057B8',
    },
    features: {
      customLists: true,
      productSubstitutionAnalysis: false,
      modifyGoal: false,
      // corporateChainSales inherits true from Stratium default
    },
    modules: {
      manageSupplyManagement: false,
      manageOrders: false,
      manageFTS: true,
      manageChargebacks: true,
      manageFormularyChangeTracking: true,
      manageSecureSupplyChain: true,
      manageCSSalesChangeTracking: true,
      manageForecastComparison: true,
    },
  },
};

export const TENANT_CONFIGS: Record<TenantId, TenantBaseConfig> = {
  stratium: STRATIUM_CONFIG,
  'stratium.customer.vendor': deepMerge(STRATIUM_CONFIG, TENANT_OVERRIDES['stratium.customer.vendor']),
  'stratium.customer': deepMerge(STRATIUM_CONFIG, TENANT_OVERRIDES['stratium.customer']),
  'stratium.vendor': deepMerge(STRATIUM_CONFIG, TENANT_OVERRIDES['stratium.vendor']),
};
