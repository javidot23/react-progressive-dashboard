import type { TenantId } from '../types';

export interface TenantBranding {
  title: string;
  logoVariant: string;
  primaryColor: string;
  favicon?: string;
}

export interface TenantFeatureFlags {
  customLists: boolean;
  disruptionsMap: boolean;
  exportActions: boolean;
  glossary: boolean;
  productSubstitutionAnalysis: boolean;
  corporateChainSales: boolean;
  modifyGoal: boolean;
  [key: string]: boolean;
}

export interface TenantModules {
  overview: boolean;
  react: boolean;
  plan: boolean;
  manage: boolean;
  profile: boolean;
  manageOverview: boolean;
  manageDemand: boolean;
  manageSupply: boolean;
  manageSales: boolean;
  manageInventory: boolean;
  manageSupplyManagement: boolean;
  manageOrders: boolean;
  manageDistribution: boolean;
  // Vendor-portal modules (stratium.vendor)
  manageFTS: boolean;
  manageChargebacks: boolean;
  manageFormularyChangeTracking: boolean;
  manageSecureSupplyChain: boolean;
  manageCSSalesChangeTracking: boolean;
  manageForecastComparison: boolean;
  [key: string]: boolean;
}

export interface TenantBaseConfig {
  id: TenantId;
  name: string;
  displayName: string;
  description: string;
  branding: TenantBranding;
  features: TenantFeatureFlags;
  modules: TenantModules;
}

// Subset used by the vite build plugin
export type TenantBuildConfig = TenantBaseConfig;
