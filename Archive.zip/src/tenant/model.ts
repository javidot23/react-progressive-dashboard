export type TenantType = "customer" | "vendor" | "customer_vendor";
export type EntitlementTier = "standard" | "premium" | "platinum";

export interface TenantContext {
  tenant_uuid: string;
  tenant_code: string;
  tenant_name: string;
  tenant_type: TenantType;
  entitlement_tier: EntitlementTier;
  is_federated: boolean;
}

export interface ApiSuccess<T> {
  success: true;
  data: T;
}

export interface ApiError {
  success: false;
  type: string;
  code: string;
  error: string;
}

export type TenantContextResponse = ApiSuccess<TenantContext> | ApiError;

export const TENANT_REQUIRED_CODE = "tenant_required";

export type TenantAwareType = TenantType | readonly TenantType[];

export function matchesTenantType(required: TenantAwareType, type: TenantType | undefined): boolean {
  if (!type) return false;
  return Array.isArray(required) ? required.includes(type) : required === type;
}

export interface TenantPortalFlags {
  readonly tenantType: TenantType | undefined;
  readonly isReady: boolean;
  readonly isCustomer: boolean;
  readonly isVendor: boolean;
  readonly isCustomerVendor: boolean;
  readonly isUpstream: boolean;
  readonly isDownstream: boolean;
  readonly features: {
    readonly customLists: boolean;
    readonly corporateChainSales: boolean;
    readonly productSubstitutionAnalysis: boolean;
  };
  readonly modules: {
    readonly manageOrders: boolean;
    readonly manageInventory: boolean;
    readonly manageFTS: boolean;
    readonly manageChargebacks: boolean;
    readonly manageFormularyChangeTracking: boolean;
    readonly manageSecureSupplyChain: boolean;
    readonly manageCSSalesChangeTracking: boolean;
    readonly manageForecastComparison: boolean;
  };
}

const UNRESOLVED_TENANT_PORTAL_FLAGS = {
  tenantType: undefined,
  isReady: false,
  isCustomer: false,
  isVendor: false,
  isCustomerVendor: false,
  isUpstream: false,
  isDownstream: false,
  features: {
    customLists: false,
    corporateChainSales: false,
    productSubstitutionAnalysis: false,
  },
  modules: {
    manageOrders: false,
    manageInventory: false,
    manageFTS: false,
    manageChargebacks: false,
    manageFormularyChangeTracking: false,
    manageSecureSupplyChain: false,
    manageCSSalesChangeTracking: false,
    manageForecastComparison: false,
  },
} as const satisfies TenantPortalFlags;

const TENANT_PORTAL_FLAGS = {
  customer: {
    tenantType: "customer",
    isReady: true,
    isCustomer: true,
    isVendor: false,
    isCustomerVendor: false,
    isUpstream: false,
    isDownstream: true,
    features: {
      customLists: true,
      corporateChainSales: false,
      productSubstitutionAnalysis: true,
    },
    modules: {
      manageOrders: true,
      manageInventory: false,
      manageFTS: false,
      manageChargebacks: false,
      manageFormularyChangeTracking: false,
      manageSecureSupplyChain: false,
      manageCSSalesChangeTracking: false,
      manageForecastComparison: false,
    },
  },
  vendor: {
    tenantType: "vendor",
    isReady: true,
    isCustomer: false,
    isVendor: true,
    isCustomerVendor: false,
    isUpstream: true,
    isDownstream: false,
    features: {
      customLists: true,
      corporateChainSales: true,
      productSubstitutionAnalysis: false,
    },
    modules: {
      manageOrders: false,
      manageInventory: true,
      manageFTS: true,
      manageChargebacks: true,
      manageFormularyChangeTracking: true,
      manageSecureSupplyChain: true,
      manageCSSalesChangeTracking: true,
      manageForecastComparison: true,
    },
  },
  customer_vendor: {
    tenantType: "customer_vendor",
    isReady: true,
    isCustomer: false,
    isVendor: false,
    isCustomerVendor: true,
    isUpstream: true,
    isDownstream: false,
    features: {
      customLists: true,
      corporateChainSales: true,
      productSubstitutionAnalysis: false,
    },
    modules: {
      manageOrders: false,
      manageInventory: true,
      manageFTS: false,
      manageChargebacks: false,
      manageFormularyChangeTracking: false,
      manageSecureSupplyChain: false,
      manageCSSalesChangeTracking: false,
      manageForecastComparison: true,
    },
  },
} as const satisfies Record<TenantType, TenantPortalFlags>;

export function getTenantPortalFlags(type: TenantType | undefined): TenantPortalFlags {
  return type ? TENANT_PORTAL_FLAGS[type] : UNRESOLVED_TENANT_PORTAL_FLAGS;
}
