import type { ReactNode } from 'react';
import { useTenantConfig } from './useTenantConfig';
import type { TenantId } from './types';
import type { TenantFeatureFlags, TenantModules } from './config/types';

interface TenantFeatureProps {
  children: ReactNode;
  /** Render only when the active tenant exactly matches this ID */
  tenant?: TenantId;
  /** Render only when this feature flag is enabled */
  feature?: keyof TenantFeatureFlags;
  /** Render only when this module is enabled */
  module?: keyof TenantModules;
  /** Rendered when the condition is NOT met (optional fallback) */
  fallback?: ReactNode;
}

/**
 * Conditionally renders children based on tenant identity, feature flags, or modules.
 *
 * @example
 * // By tenant
 * <TenantFeature tenant="stratium.vendor"><FTSLink /></TenantFeature>
 *
 * // By feature flag
 * <TenantFeature feature="disruptionsMap"><DisruptionsLink /></TenantFeature>
 *
 * // By module
 * <TenantFeature module="manageOrders"><OrdersNav /></TenantFeature>
 */
export function TenantFeature({ children, tenant, feature, module: mod, fallback = null }: TenantFeatureProps) {
  const { tenantId, isFeatureEnabled, isModuleEnabled } = useTenantConfig();

  const matches =
    (tenant === undefined || tenantId === tenant) &&
    (feature === undefined || isFeatureEnabled(feature)) &&
    (mod === undefined || isModuleEnabled(mod));

  return <>{matches ? children : fallback}</>;
}

/**
 * Filters an array of items, removing entries whose `tenant` field does not
 * match the active tenant. Items with no `tenant` field are always included.
 */
export function useFilterByTenant<T extends { tenant?: TenantId }>(items: T[]): T[] {
  const { tenantId } = useTenantConfig();
  return items.filter((item) => !item.tenant || item.tenant === tenantId);
}

/**
 * Selects a value from a map keyed by tenant ID, falling back to `default`.
 *
 * @example
 * const subtitle = useForTenant({
 *   stratium: 'Risk analysis and resiliency insights',
 *   'stratium.customer': 'Real-time visibility across the supply chain',
 *   default: 'Supply Chain Platform',
 * });
 */
export function useForTenant<T>(
  map: Partial<Record<TenantId, T>> & { default?: T },
): T | undefined {
  const { tenantId } = useTenantConfig();
  return map[tenantId] ?? map.default;
}
