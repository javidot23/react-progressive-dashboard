import { createContext, useMemo } from 'react';
import type { ReactNode } from 'react';
import { TENANT_CONFIGS } from './config/definitions';
import type { TenantBaseConfig, TenantFeatureFlags, TenantModules } from './config/types';
import {
  isCustomerVendorPortal,
  isCustomerPortal,
  isVendorPortal,
  isFullFeatureSet,
  isVariantFamily,
} from './types';
import type { TenantId } from './types';

export interface TenantConfigContextValue {
  config: TenantBaseConfig;
  tenantId: TenantId;
  isFeatureEnabled: (feature: keyof TenantFeatureFlags) => boolean;
  isModuleEnabled: (module: keyof TenantModules) => boolean;
  // Pre-computed tenant identity booleans — use these in components instead of
  // calling predicates at every call site
  isCustomerVendorPortal: boolean;
  isCustomerPortal: boolean;
  isVendorPortal: boolean;
  /** true for base stratium only (full feature/module set) */
  isFullFeatureSet: boolean;
  /** true for any stratium.* portal variant */
  isVariantFamily: boolean;
}

export const TenantConfigContext = createContext<TenantConfigContextValue | null>(null);

interface TenantConfigProviderProps {
  children: ReactNode;
  /** Override the build-time tenant — use only in tests */
  forceTenantId?: TenantId;
}

export function TenantConfigProvider({ children, forceTenantId }: TenantConfigProviderProps) {
  const tenantId: TenantId = forceTenantId ?? (__TENANT__ as TenantId);
  const config = TENANT_CONFIGS[tenantId] ?? TENANT_CONFIGS.stratium;

  const value = useMemo<TenantConfigContextValue>(
    () => ({
      config,
      tenantId,
      isFeatureEnabled: (feature) => config.features[feature] ?? false,
      isModuleEnabled: (module) => config.modules[module] ?? false,
      isCustomerVendorPortal: isCustomerVendorPortal(tenantId),
      isCustomerPortal: isCustomerPortal(tenantId),
      isVendorPortal: isVendorPortal(tenantId),
      isFullFeatureSet: isFullFeatureSet(tenantId),
      isVariantFamily: isVariantFamily(tenantId),
    }),
    [config, tenantId],
  );

  return (
    <TenantConfigContext.Provider value={value}>
      {children}
    </TenantConfigContext.Provider>
  );
}
