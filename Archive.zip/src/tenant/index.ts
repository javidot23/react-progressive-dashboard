export { TENANT_REQUIRED_CODE, getTenantPortalFlags, matchesTenantType } from "./model";
export type {
  ApiError,
  ApiSuccess,
  EntitlementTier,
  TenantAwareType,
  TenantContext,
  TenantContextResponse,
  TenantPortalFlags,
  TenantType,
} from "./model";

export {
  TENANT_CONTEXT_QUERY_KEY,
  TenantContextError,
  fetchTenantContext,
  isTenantRequiredError,
  tenantContextQueryOptions,
} from "./tenantContextQuery";

export { selectTenantPortalFlags, useTenantContextQuery } from "./useTenantContextQuery";
