// Provider
export { TenantConfigProvider } from './TenantConfigProvider';
export type { TenantConfigContextValue } from './TenantConfigProvider';

// Hooks
export { useTenantConfig, useFeatureFlag, useModuleFlag } from './useTenantConfig';

// Conditional render + array utilities
export { TenantFeature, useFilterByTenant, useForTenant } from './TenantFeature';

// Build-time (non-hook) tenant filter — use outside React components or in useMemo.
export type TenantAwareItem = { tenant?: import('./types').TenantId | readonly import('./types').TenantId[]; [key: string]: any };
export function filterByTenant<T extends TenantAwareItem>(items: T[]): T[] {
  const tenantId = CURRENT_TENANT_CONFIG.id;
  return items.filter((item) => {
    if (!item.tenant) return true;
    if (Array.isArray(item.tenant)) return (item.tenant as readonly import('./types').TenantId[]).includes(tenantId);
    return item.tenant === tenantId;
  });
}

// Predicates — call without args to check the current build-time tenant,
// or pass an explicit TenantId for testing / provider use.
export {
  isCustomerVendorPortal,
  isCustomerPortal,
  isVendorPortal,
  isFullFeatureSet,
  isVariantFamily,
  shouldShowStratiumLayout,
  matchesTenant,
  KNOWN_TENANT_IDS,
} from './types';

// Build-time config object — use in non-hook contexts (e.g. page titles, utilities).
// Prefer useTenantConfig() inside React components.
export { TENANT_CONFIGS } from './config/definitions';

import type { TenantBaseConfig } from './config/types';
export const CURRENT_TENANT_CONFIG: TenantBaseConfig = __TENANT_CONFIG__;

// Types
export type { TenantId } from './types';
export type { TenantBaseConfig, TenantFeatureFlags, TenantModules } from './config/types';
