import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { getTenantPortalFlags, type TenantContext, type TenantPortalFlags } from "./model";
import { tenantContextQueryOptions } from "./tenantContextQuery";

export type { TenantPortalFlags };

export const selectTenantPortalFlags = (data: TenantContext): TenantPortalFlags => getTenantPortalFlags(data.tenant_type);

export function useTenantContextQuery<TData = TenantContext>(select?: (data: TenantContext) => TData) {
  const { isAuthenticated, isLoading } = useAuth();

  return useQuery({
    ...tenantContextQueryOptions(),
    enabled: isAuthenticated && !isLoading,
    select,
  });
}
