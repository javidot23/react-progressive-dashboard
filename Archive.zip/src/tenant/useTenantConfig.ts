import { useContext } from 'react';
import { TenantConfigContext } from './TenantConfigProvider';
import type { TenantConfigContextValue } from './TenantConfigProvider';
import type { TenantFeatureFlags, TenantModules } from './config/types';

export function useTenantConfig(): TenantConfigContextValue {
  const context = useContext(TenantConfigContext);
  if (!context) {
    throw new Error('useTenantConfig must be used within TenantConfigProvider');
  }
  return context;
}

export function useFeatureFlag(feature: keyof TenantFeatureFlags): boolean {
  return useTenantConfig().isFeatureEnabled(feature);
}

export function useModuleFlag(module: keyof TenantModules): boolean {
  return useTenantConfig().isModuleEnabled(module);
}
