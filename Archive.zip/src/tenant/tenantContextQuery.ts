import { isAxiosError } from "axios";
import { queryOptions } from "@tanstack/react-query";

import apiClient from "@/lib/apiClient";
import { TENANT_REQUIRED_CODE, type ApiError, type TenantContext, type TenantContextResponse } from "./model";

const TENANT_CONTEXT_STALE_TIME_MS = 15 * 60_000;

export const TENANT_CONTEXT_QUERY_KEY = ["tenants", "context"] as const;

const AUTHENTICATION_ERROR_NAMES = new Set(["AuthenticationError", "DomainNotAllowedError", "EmailNotAllowedError"]);

export class TenantContextError extends Error {
  constructor(
    readonly response: ApiError,
    readonly status?: number
  ) {
    super(response.error);
    this.name = "TenantContextError";
  }

  get code(): string {
    return this.response.code;
  }
}

function httpStatus(error: unknown): number | undefined {
  if (error instanceof TenantContextError) return error.status;
  if (isAxiosError<ApiError>(error)) return error.response?.status;
  if (error instanceof Error && AUTHENTICATION_ERROR_NAMES.has(error.name)) return 401;
  return undefined;
}

function shouldRetryTenantContext(failureCount: number, error: unknown): boolean {
  const status = httpStatus(error);
  if (status === 401 || status === 403) return false;
  return failureCount < 2;
}

export function isTenantRequiredError(error: unknown): boolean {
  if (error instanceof TenantContextError) {
    return error.status === 403 && error.response.code === TENANT_REQUIRED_CODE;
  }

  return isAxiosError<ApiError>(error) && error.response?.status === 403 && error.response.data?.code === TENANT_REQUIRED_CODE;
}

export async function fetchTenantContext(signal?: AbortSignal): Promise<TenantContext> {
  const response = await apiClient.get<TenantContextResponse>("/tenants/context/", { signal });
  const body = response.data;

  if (body?.success === true && body.data) {
    return body.data;
  }

  if (body?.success === false) {
    throw new TenantContextError(body, response.status);
  }

  throw new Error("Tenant context response missing data");
}

export function tenantContextQueryOptions() {
  return queryOptions({
    queryKey: TENANT_CONTEXT_QUERY_KEY,
    queryFn: ({ signal }) => fetchTenantContext(signal),
    staleTime: TENANT_CONTEXT_STALE_TIME_MS,
    retry: shouldRetryTenantContext,
  });
}
