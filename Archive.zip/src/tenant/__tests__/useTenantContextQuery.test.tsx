import React from "react";
import { renderHook, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

import {
  isTenantRequiredError,
  selectTenantPortalFlags,
  TenantContextError,
  useTenantContextQuery,
  type TenantContext,
} from "@/tenant";

const mockUseAuth = jest.fn();
const mockFetchTenantContext = jest.fn();

jest.mock("@/contexts/AuthContext", () => ({
  useAuth: () => mockUseAuth(),
}));

jest.mock("@/tenant/tenantContextQuery", () => {
  const actual = jest.requireActual("@/tenant/tenantContextQuery") as typeof import("@/tenant/tenantContextQuery");
  return {
    ...actual,
    fetchTenantContext: (...args: unknown[]) => mockFetchTenantContext(...args),
    tenantContextQueryOptions: () => ({
      ...actual.tenantContextQueryOptions(),
      queryFn: ({ signal }: { signal?: AbortSignal }) => mockFetchTenantContext(signal),
    }),
  };
});

const SAMPLE_CONTEXT: TenantContext = {
  tenant_uuid: "11111111-1111-1111-1111-111111111111",
  tenant_code: "stratium",
  tenant_name: "Stratium",
  tenant_type: "customer",
  entitlement_tier: "standard",
  is_federated: true,
};

function wrapperFactory() {
  const client = new QueryClient({
    defaultOptions: {
      queries: { retry: false, gcTime: 0 },
    },
  });
  const wrapper = ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={client}>{children}</QueryClientProvider>
  );
  return { client, wrapper };
}

describe("useTenantContextQuery", () => {
  beforeEach(() => {
    mockFetchTenantContext.mockReset();
    mockUseAuth.mockReturnValue({
      isAuthenticated: true,
      isLoading: false,
    });
  });

  it("returns tenant context when authenticated", async () => {
    mockFetchTenantContext.mockResolvedValueOnce(SAMPLE_CONTEXT);
    const { wrapper } = wrapperFactory();

    const { result } = renderHook(() => useTenantContextQuery(), { wrapper });

    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data).toEqual(SAMPLE_CONTEXT);
    expect(mockFetchTenantContext).toHaveBeenCalledTimes(1);
  });

  it("does not fetch when unauthenticated", async () => {
    mockUseAuth.mockReturnValue({
      isAuthenticated: false,
      isLoading: false,
    });
    const { wrapper } = wrapperFactory();
    const { result } = renderHook(() => useTenantContextQuery(), { wrapper });

    expect(result.current.fetchStatus).toBe("idle");
    expect(mockFetchTenantContext).not.toHaveBeenCalled();
  });

  it("does not fetch while auth is still loading", async () => {
    mockUseAuth.mockReturnValue({
      isAuthenticated: false,
      isLoading: true,
    });
    const { wrapper } = wrapperFactory();
    const { result } = renderHook(() => useTenantContextQuery(), { wrapper });

    expect(result.current.fetchStatus).toBe("idle");
    expect(mockFetchTenantContext).not.toHaveBeenCalled();
  });

  it("supports select for portal flags", async () => {
    mockFetchTenantContext.mockResolvedValueOnce(SAMPLE_CONTEXT);
    const { wrapper } = wrapperFactory();

    const { result } = renderHook(() => useTenantContextQuery(selectTenantPortalFlags), { wrapper });

    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data?.isCustomer).toBe(true);
    expect(result.current.data?.modules.manageOrders).toBe(true);
  });

  it("surfaces tenant_required without retrying", async () => {
    mockFetchTenantContext.mockRejectedValueOnce(
      new TenantContextError(
        {
          success: false,
          type: "client_error",
          code: "tenant_required",
          error: "Active tenant required",
        },
        403
      )
    );
    const { wrapper } = wrapperFactory();

    const { result } = renderHook(() => useTenantContextQuery(), { wrapper });

    await waitFor(() => expect(result.current.isError).toBe(true));
    expect(result.current.error).toBeInstanceOf(TenantContextError);
    expect(isTenantRequiredError(result.current.error)).toBe(true);
    expect(mockFetchTenantContext).toHaveBeenCalledTimes(1);
  });
});
