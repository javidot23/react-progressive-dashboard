import { getTenantPortalFlags, matchesTenantType, type TenantType } from "@/tenant";

const TYPES: (TenantType | undefined)[] = [undefined, "customer", "vendor", "customer_vendor"];

describe("getTenantPortalFlags", () => {
  it("hides gated capabilities while tenant type is unresolved", () => {
    expect(getTenantPortalFlags(undefined)).toEqual({
      tenantType: undefined,
      isReady: false,
      isCustomer: false,
      isVendor: false,
      isCustomerVendor: false,
      isUpstream: false,
      isDownstream: false,
      features: {
        customLists: false,
        corporateChainSales: false,
        productSubstitutionAnalysis: false,
      },
      modules: {
        manageOrders: false,
        manageInventory: false,
        manageFTS: false,
        manageChargebacks: false,
        manageFormularyChangeTracking: false,
        manageSecureSupplyChain: false,
        manageCSSalesChangeTracking: false,
        manageForecastComparison: false,
      },
    });
  });

  it.each([
    [
      "customer",
      {
        tenantType: "customer",
        isReady: true,
        isCustomer: true,
        isVendor: false,
        isCustomerVendor: false,
        isUpstream: false,
        isDownstream: true,
        features: { customLists: true, corporateChainSales: false, productSubstitutionAnalysis: true },
        modules: {
          manageOrders: true,
          manageInventory: false,
          manageFTS: false,
          manageChargebacks: false,
          manageFormularyChangeTracking: false,
          manageSecureSupplyChain: false,
          manageCSSalesChangeTracking: false,
          manageForecastComparison: false,
        },
      },
    ],
    [
      "vendor",
      {
        tenantType: "vendor",
        isReady: true,
        isCustomer: false,
        isVendor: true,
        isCustomerVendor: false,
        isUpstream: true,
        isDownstream: false,
        features: { customLists: true, corporateChainSales: true, productSubstitutionAnalysis: false },
        modules: {
          manageOrders: false,
          manageInventory: true,
          manageFTS: true,
          manageChargebacks: true,
          manageFormularyChangeTracking: true,
          manageSecureSupplyChain: true,
          manageCSSalesChangeTracking: true,
          manageForecastComparison: true,
        },
      },
    ],
    [
      "customer_vendor",
      {
        tenantType: "customer_vendor",
        isReady: true,
        isCustomer: false,
        isVendor: false,
        isCustomerVendor: true,
        isUpstream: true,
        isDownstream: false,
        features: { customLists: true, corporateChainSales: true, productSubstitutionAnalysis: false },
        modules: {
          manageOrders: false,
          manageInventory: true,
          manageFTS: false,
          manageChargebacks: false,
          manageFormularyChangeTracking: false,
          manageSecureSupplyChain: false,
          manageCSSalesChangeTracking: false,
          manageForecastComparison: true,
        },
      },
    ],
  ] as const)("maps %s to the expected portal matrix", (type, expected) => {
    expect(getTenantPortalFlags(type)).toEqual(expected);
  });
});

describe("matchesTenantType", () => {
  it("returns false when type is undefined", () => {
    expect(matchesTenantType("customer", undefined)).toBe(false);
    expect(matchesTenantType(["customer", "vendor"], undefined)).toBe(false);
  });

  it("matches a single required tenant type", () => {
    expect(matchesTenantType("customer", "customer")).toBe(true);
    expect(matchesTenantType("customer", "vendor")).toBe(false);
  });

  it("matches when type is included in a required list", () => {
    expect(matchesTenantType(["vendor", "customer_vendor"], "vendor")).toBe(true);
    expect(matchesTenantType(["vendor", "customer_vendor"], "customer_vendor")).toBe(true);
    expect(matchesTenantType(["vendor", "customer_vendor"], "customer")).toBe(false);
  });

  it("covers every known tenant type without throwing", () => {
    TYPES.forEach(type => {
      expect(() => getTenantPortalFlags(type)).not.toThrow();
    });
  });
});
