import {
  TENANT_CONTEXT_QUERY_KEY,
  TenantContextError,
  fetchTenantContext,
  isTenantRequiredError,
  tenantContextQueryOptions,
  type TenantContext,
} from "@/tenant";

jest.mock("@/lib/apiClient", () => ({
  __esModule: true,
  default: { get: jest.fn() },
}));

import apiClient from "@/lib/apiClient";
import axios from "axios";

const mockedGet = apiClient.get as jest.MockedFunction<typeof apiClient.get>;

const SAMPLE_CONTEXT: TenantContext = {
  tenant_uuid: "11111111-1111-1111-1111-111111111111",
  tenant_code: "stratium",
  tenant_name: "Stratium",
  tenant_type: "customer_vendor",
  entitlement_tier: "premium",
  is_federated: false,
};

describe("tenantContextQuery", () => {
  beforeEach(() => {
    mockedGet.mockReset();
  });

  it("exports a stable tenants/context query key", () => {
    expect(TENANT_CONTEXT_QUERY_KEY).toEqual(["tenants", "context"]);
    expect(tenantContextQueryOptions().queryKey).toEqual(TENANT_CONTEXT_QUERY_KEY);
  });

  it("calls GET /tenants/context/ with optional AbortSignal", async () => {
    mockedGet.mockResolvedValueOnce({
      status: 200,
      data: { success: true, data: SAMPLE_CONTEXT },
    } as never);

    const controller = new AbortController();
    const result = await fetchTenantContext(controller.signal);

    expect(mockedGet).toHaveBeenCalledWith("/tenants/context/", { signal: controller.signal });
    expect(result).toEqual(SAMPLE_CONTEXT);
  });

  it("unwraps the success envelope", async () => {
    mockedGet.mockResolvedValueOnce({
      status: 200,
      data: { success: true, data: SAMPLE_CONTEXT },
    } as never);

    await expect(fetchTenantContext()).resolves.toEqual(SAMPLE_CONTEXT);
  });

  it("throws TenantContextError when success is false in the body", async () => {
    mockedGet.mockResolvedValueOnce({
      status: 200,
      data: {
        success: false,
        type: "client_error",
        code: "bad_request",
        error: "Malformed request",
      },
    } as never);

    await expect(fetchTenantContext()).rejects.toMatchObject({
      name: "TenantContextError",
      message: "Malformed request",
      code: "bad_request",
    });
  });

  it("recognizes tenant_required from the raw Axios 403 envelope", async () => {
    const err = new axios.AxiosError("Forbidden");
    err.response = {
      status: 403,
      data: {
        success: false,
        type: "client_error",
        code: "tenant_required",
        error: "Active tenant required",
      },
      statusText: "Forbidden",
      headers: {},
      config: {} as never,
    };

    mockedGet.mockRejectedValueOnce(err);

    try {
      await fetchTenantContext();
      fail("expected throw");
    } catch (e) {
      expect(e).toBe(err);
      expect(isTenantRequiredError(e)).toBe(true);
    }
  });

  it("throws on missing data envelope", async () => {
    mockedGet.mockResolvedValueOnce({ status: 200, data: { success: true } } as never);
    await expect(fetchTenantContext()).rejects.toThrow(/missing data/i);
  });

  it("does not retry 401 or 403", () => {
    const retry = tenantContextQueryOptions().retry;
    expect(typeof retry).toBe("function");
    if (typeof retry !== "function") return;

    expect(
      retry(
        0,
        new TenantContextError(
          {
            success: false,
            type: "client_error",
            code: "session_expired",
            error: "expired",
          },
          401
        )
      )
    ).toBe(false);
    expect(
      retry(
        0,
        new TenantContextError(
          {
            success: false,
            type: "client_error",
            code: "tenant_required",
            error: "forbidden",
          },
          403
        )
      )
    ).toBe(false);
  });

  it("retries transient failures up to the limit", () => {
    const retry = tenantContextQueryOptions().retry;
    expect(typeof retry).toBe("function");
    if (typeof retry !== "function") return;

    const transient = new TenantContextError(
      {
        success: false,
        type: "server_error",
        code: "server_error",
        error: "boom",
      },
      500
    );
    expect(retry(0, transient)).toBe(true);
    expect(retry(1, transient)).toBe(true);
    expect(retry(2, transient)).toBe(false);
  });

  it.each(["AuthenticationError", "DomainNotAllowedError", "EmailNotAllowedError"])(
    "does not retry the %s emitted by apiClient for 401",
    errorName => {
      const retry = tenantContextQueryOptions().retry;
      expect(typeof retry).toBe("function");
      if (typeof retry !== "function") return;

      const authenticationError = new Error("SESSION_EXPIRED");
      authenticationError.name = errorName;

      expect(retry(0, authenticationError)).toBe(false);
    }
  );
});
