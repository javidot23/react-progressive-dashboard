export type TenantId =
  | 'stratium'
  | 'stratium.customer.vendor'
  | 'stratium.customer'
  | 'stratium.vendor';

// Build-time global injected by the vite plugin — declared here to avoid a
// circular dependency with src/types/tenant.d.ts which imports this type.
declare const __TENANT__: TenantId;

export const KNOWN_TENANT_IDS: TenantId[] = [
  'stratium',
  'stratium.customer.vendor',
  'stratium.customer',
  'stratium.vendor',
];

// Concrete predicates — one per deployable tenant.
// The `id` parameter is optional: omit it to check the build-time tenant
// (resolved from __TENANT__ at compile time), or pass an explicit TenantId
// for testing / provider use.
export const isCustomerVendorPortal = (id: TenantId = __TENANT__): boolean =>
  id === 'stratium.customer.vendor';
export const isCustomerPortal = (id: TenantId = __TENANT__): boolean =>
  id === 'stratium.customer';
export const isVendorPortal = (id: TenantId = __TENANT__): boolean =>
  id === 'stratium.vendor';

// Groupings
// isFullFeatureSet: tenants that share the full Stratium feature/module set.
export const isFullFeatureSet = (id: TenantId = __TENANT__): boolean =>
  id === 'stratium';

// isVariantFamily: any variant portal tenant (stratium.*)
export const isVariantFamily = (id: TenantId = __TENANT__): boolean =>
  id.startsWith('stratium.');

// shouldShowStratiumLayout: tenants that use the Stratium-style layout (base + vendor-like tenants).
// stratium.customer uses a different compact layout.
export const shouldShowStratiumLayout = (id: TenantId = __TENANT__): boolean =>
  id === 'stratium' || id === 'stratium.vendor' || id === 'stratium.customer.vendor';

// matchesTenant: checks if the current (or given) tenant matches a required tenant spec.
// Supports a single TenantId or an array of TenantIds.
export const matchesTenant = (
  required: TenantId | readonly TenantId[],
  id: TenantId = __TENANT__,
): boolean =>
  Array.isArray(required)
    ? (required as readonly TenantId[]).includes(id)
    : id === required;
