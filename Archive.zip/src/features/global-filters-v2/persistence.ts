import {
  GLOBAL_FILTER_V2_KEYS,
  GLOBAL_FILTER_V2_LS_KEY,
  createEmptySelections,
  type GlobalFilterV2Selections,
  normalizeSelections,
} from "./types";

export function readGlobalFilterV2FromLocalStorage(): GlobalFilterV2Selections | null {
  try {
    const raw = localStorage.getItem(GLOBAL_FILTER_V2_LS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<GlobalFilterV2Selections>;
    const next = createEmptySelections();
    for (const key of GLOBAL_FILTER_V2_KEYS) {
      const value = parsed[key];
      next[key] = Array.isArray(value) ? value.map(String) : [];
    }
    return normalizeSelections(next);
  } catch {
    return null;
  }
}

export function writeGlobalFilterV2ToLocalStorage(selections: GlobalFilterV2Selections): void {
  try {
    localStorage.setItem(GLOBAL_FILTER_V2_LS_KEY, JSON.stringify(normalizeSelections(selections)));
  } catch {
    // Ignore.
  }
}

export function clearGlobalFilterV2LocalStorage(): void {
  try {
    localStorage.removeItem(GLOBAL_FILTER_V2_LS_KEY);
  } catch {
    // Ignore.
  }
}
