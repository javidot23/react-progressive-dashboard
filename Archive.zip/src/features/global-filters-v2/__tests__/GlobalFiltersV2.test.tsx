import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, useLocation } from "react-router-dom";
import { GlobalFiltersV2 } from "../GlobalFiltersV2";
import { GLOBAL_FILTER_V2_LS_KEY } from "../types";

function LocationProbe() {
  const location = useLocation();
  return <div data-testid="location-search">{location.search}</div>;
}

function renderFilters(initialEntry = "/manage/summary") {
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[initialEntry]}>
        <GlobalFiltersV2 />
        <LocationProbe />
      </MemoryRouter>
    </QueryClientProvider>
  );
}

describe("GlobalFiltersV2", () => {
  const memory = new Map<string, string>();

  beforeEach(() => {
    memory.clear();
    (localStorage.getItem as jest.Mock).mockImplementation((key: string) => memory.get(key) ?? null);
    (localStorage.setItem as jest.Mock).mockImplementation((key: string, value: string) => {
      memory.set(key, value);
    });
    (localStorage.removeItem as jest.Mock).mockImplementation((key: string) => {
      memory.delete(key);
    });
    (localStorage.clear as jest.Mock).mockImplementation(() => {
      memory.clear();
    });
  });

  it("opens the panel with the three filter groups and applies on Show results", async () => {
    const user = userEvent.setup();
    renderFilters();

    await user.click(screen.getByRole("button", { name: /filters/i }));

    const dialog = await screen.findByRole("dialog", { name: /filters/i });
    expect(within(dialog).getByText("Formulary (Contract Type)")).toBeInTheDocument();
    expect(within(dialog).getByText("Material Status")).toBeInTheDocument();
    expect(within(dialog).getByText("WHO Essential")).toBeInTheDocument();

    await user.click(within(dialog).getByRole("button", { name: "Preferred" }));
    await user.click(within(dialog).getByRole("button", { name: "Active" }));
    await user.click(within(dialog).getByRole("button", { name: "Yes" }));
    await user.click(within(dialog).getByRole("button", { name: "Show results" }));

    await waitFor(() => {
      const search = screen.getByTestId("location-search").textContent ?? "";
      expect(search).toContain("gf2_formulary=preferred");
      expect(search).toContain("gf2_material_status=active");
      expect(search).toContain("gf2_who_essential=1");
    });
    expect(JSON.parse(localStorage.getItem(GLOBAL_FILTER_V2_LS_KEY)!)).toEqual({
      formulary: ["preferred"],
      materialStatus: ["active"],
      whoEssential: ["1"],
    });
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("does not commit draft toggles until Show results", async () => {
    const user = userEvent.setup();
    renderFilters();

    await user.click(screen.getByRole("button", { name: /filters/i }));
    const dialog = await screen.findByRole("dialog");
    await user.click(within(dialog).getByRole("button", { name: "Specialty" }));
    await user.click(within(dialog).getByRole("button", { name: "Close filters" }));

    expect(screen.getByTestId("location-search")).toHaveTextContent("");
    expect(localStorage.getItem(GLOBAL_FILTER_V2_LS_KEY)).toBeNull();
  });

  it("clears applied filters immediately from Clear all", async () => {
    const user = userEvent.setup();
    renderFilters("/manage/summary?gf2_formulary=preferred");

    await user.click(screen.getByRole("button", { name: /filters/i }));
    await user.click(await screen.findByRole("button", { name: "Clear all" }));

    await waitFor(() => {
      expect(screen.getByTestId("location-search")).toHaveTextContent("");
    });
    expect(JSON.parse(localStorage.getItem(GLOBAL_FILTER_V2_LS_KEY)!)).toEqual({
      formulary: [],
      materialStatus: [],
      whoEssential: [],
    });
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });
});
