import { render, waitFor } from "@testing-library/react";
import { MemoryRouter, useLocation } from "react-router-dom";
import { GlobalFilterV2Boundary } from "../GlobalFilterV2Boundary";
import { GLOBAL_FILTER_V2_LS_KEY } from "../types";

function LocationProbe() {
  const location = useLocation();
  return <div data-testid="search">{location.search}</div>;
}

describe("GlobalFilterV2Boundary", () => {
  const memory = new Map<string, string>();

  beforeEach(() => {
    memory.clear();
    (localStorage.getItem as jest.Mock).mockImplementation((key: string) => memory.get(key) ?? null);
    (localStorage.setItem as jest.Mock).mockImplementation((key: string, value: string) => {
      memory.set(key, value);
    });
    (localStorage.removeItem as jest.Mock).mockImplementation((key: string) => {
      memory.delete(key);
    });
    (localStorage.clear as jest.Mock).mockImplementation(() => {
      memory.clear();
    });
  });

  it("restores gf2_* from localStorage when the URL has none", async () => {
    localStorage.setItem(
      GLOBAL_FILTER_V2_LS_KEY,
      JSON.stringify({
        formulary: ["preferred"],
        materialStatus: [],
        whoEssential: ["1"],
      })
    );

    const { getByTestId } = render(
      <MemoryRouter initialEntries={["/manage/summary"]}>
        <GlobalFilterV2Boundary>
          <LocationProbe />
        </GlobalFilterV2Boundary>
      </MemoryRouter>
    );

    await waitFor(() => {
      const search = getByTestId("search").textContent ?? "";
      expect(search).toContain("gf2_formulary=preferred");
      expect(search).toContain("gf2_who_essential=1");
    });
  });

  it("does not overwrite existing gf2_* URL params", async () => {
    localStorage.setItem(
      GLOBAL_FILTER_V2_LS_KEY,
      JSON.stringify({
        formulary: ["specialty"],
        materialStatus: [],
        whoEssential: [],
      })
    );

    const { getByTestId } = render(
      <MemoryRouter initialEntries={["/manage/summary?gf2_formulary=preferred"]}>
        <GlobalFilterV2Boundary>
          <LocationProbe />
        </GlobalFilterV2Boundary>
      </MemoryRouter>
    );

    await waitFor(() => {
      expect(getByTestId("search").textContent).toBe("?gf2_formulary=preferred");
    });
  });
});
