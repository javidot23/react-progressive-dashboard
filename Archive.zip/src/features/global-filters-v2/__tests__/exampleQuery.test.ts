import { QueryClient } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import { exampleManageWidgetQueryOptions } from "../exampleQuery";
import { buildGlobalFilterV2QueryKeyFragment } from "../queryScope";

/** Fetch through a real QueryClient so the queryFn runs with a genuine context. */
function runQueryFn(options: ReturnType<typeof exampleManageWidgetQueryOptions>) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return client.fetchQuery(options);
}

describe("exampleManageWidgetQueryOptions", () => {
  let getSpy: jest.SpyInstance;

  beforeEach(() => {
    getSpy = jest.spyOn(apiClient, "get").mockResolvedValue({ data: { ok: true } } as never);
  });

  afterEach(() => {
    getSpy.mockRestore();
  });

  it("sends exactly the filters encoded in the query key", async () => {
    const selections = {
      formulary: ["specialty", "preferred"],
      materialStatus: ["active"],
      whoEssential: ["1"],
    };
    const support = ["formulary", "whoEssential"] as const;
    const options = exampleManageWidgetQueryOptions({ selections, support, widgetId: "w1" });

    await runQueryFn(options);

    const [url, config] = getSpy.mock.calls[0] as [string, { params: Record<string, unknown> }];
    expect(url).toBe("/manage/example/w1/");
    expect(config.params).toEqual({ formulary: "preferred,specialty", who_essential: "1" });

    // The unsupported filter is absent from both the request and the key.
    expect(options.queryKey[2]).toEqual(buildGlobalFilterV2QueryKeyFragment(selections, support));
    expect(options.queryKey[2]).toEqual({
      globalFiltersV2: {
        formulary: ["preferred", "specialty"],
        materialStatus: [],
        whoEssential: ["1"],
      },
    });
  });

  it("keys unordered and duplicated selections identically", () => {
    const a = exampleManageWidgetQueryOptions({
      selections: { formulary: ["specialty", "preferred"], materialStatus: [], whoEssential: [] },
      widgetId: "w1",
    });
    const b = exampleManageWidgetQueryOptions({
      selections: {
        formulary: ["preferred", "specialty", "preferred"],
        materialStatus: [],
        whoEssential: [],
      },
      widgetId: "w1",
    });

    expect(a.queryKey).toEqual(b.queryKey);
  });

  it("lets local params win and serializes commas and slashes raw for the WAF", async () => {
    const options = exampleManageWidgetQueryOptions({
      selections: { formulary: ["a/b", "c"], materialStatus: [], whoEssential: [] },
      widgetId: "w2",
      localParams: { page: 2 },
    });

    await runQueryFn(options);

    const [, config] = getSpy.mock.calls[0] as [
      string,
      {
        params: Record<string, unknown>;
        paramsSerializer: { serialize: (params: Record<string, unknown>) => string };
      },
    ];
    expect(config.params).toEqual({ formulary: "a/b,c", page: 2 });
    expect(config.paramsSerializer.serialize(config.params)).toBe("formulary=a/b,c&page=2");
  });
});
