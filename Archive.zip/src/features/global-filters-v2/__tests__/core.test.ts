import {
  GLOBAL_FILTER_V2_LS_KEY,
  normalizeSelections,
  pickSupportedSelections,
  resolveSupportedKeys,
  selectionsEqual,
} from "../types";
import { mapGlobalFilterV2ToBackendParams, mergeGlobalFilterV2Params } from "../requestPolicy";
import { parseGlobalFilterV2FromSearch, serializeGlobalFilterV2ToSearch, hasGlobalFilterV2InSearch } from "../url";
import { buildGlobalFilterV2QueryKeyFragment } from "../queryScope";
import {
  readGlobalFilterV2FromLocalStorage,
  writeGlobalFilterV2ToLocalStorage,
  clearGlobalFilterV2LocalStorage,
} from "../persistence";

describe("global-filters-v2 types", () => {
  it("normalizes and compares selections", () => {
    const a = normalizeSelections({
      formulary: ["specialty", "preferred", "preferred"],
      materialStatus: ["active"],
      whoEssential: [],
    });
    const b = normalizeSelections({
      formulary: ["preferred", "specialty"],
      materialStatus: ["active"],
      whoEssential: [],
    });
    expect(a.formulary).toEqual(["preferred", "specialty"]);
    expect(selectionsEqual(a, b)).toBe(true);
  });

  it("resolves support policies", () => {
    expect(resolveSupportedKeys("all")).toEqual(["formulary", "materialStatus", "whoEssential"]);
    expect(resolveSupportedKeys(false)).toEqual([]);
    expect(resolveSupportedKeys(["formulary"])).toEqual(["formulary"]);
    expect(pickSupportedSelections({ formulary: ["a"], materialStatus: ["b"], whoEssential: ["1"] }, ["formulary"])).toEqual({
      formulary: ["a"],
      materialStatus: [],
      whoEssential: [],
    });
  });
});

describe("global-filters-v2 url", () => {
  it("round-trips gf2_* params and preserves unrelated keys", () => {
    const search = serializeGlobalFilterV2ToSearch(
      { formulary: ["preferred", "specialty"], materialStatus: ["active"], whoEssential: ["1"] },
      "tab=local&gf_supplier=legacy"
    );
    expect(search).toContain("tab=local");
    expect(search).toContain("gf_supplier=legacy");
    expect(search).toContain("gf2_formulary=preferred");
    expect(search).toContain("gf2_formulary=specialty");
    expect(search).toContain("gf2_material_status=active");
    expect(search).toContain("gf2_who_essential=1");

    const parsed = parseGlobalFilterV2FromSearch(`?${search}`);
    expect(parsed).toEqual({
      formulary: ["preferred", "specialty"],
      materialStatus: ["active"],
      whoEssential: ["1"],
    });
  });

  it("detects only gf2_* keys", () => {
    expect(hasGlobalFilterV2InSearch("?gf2_formulary=a")).toBe(true);
    expect(hasGlobalFilterV2InSearch("?gf_supplier=a")).toBe(false);
  });
});

describe("global-filters-v2 persistence", () => {
  const memory = new Map<string, string>();

  beforeEach(() => {
    memory.clear();
    (localStorage.getItem as jest.Mock).mockImplementation((key: string) => memory.get(key) ?? null);
    (localStorage.setItem as jest.Mock).mockImplementation((key: string, value: string) => {
      memory.set(key, value);
    });
    (localStorage.removeItem as jest.Mock).mockImplementation((key: string) => {
      memory.delete(key);
    });
    (localStorage.clear as jest.Mock).mockImplementation(() => {
      memory.clear();
    });
  });

  it("persists to a dedicated localStorage key without touching legacy", () => {
    memory.set("global_filters", JSON.stringify({ gf_supplier: { id: "1", label: "A" } }));
    writeGlobalFilterV2ToLocalStorage({
      formulary: ["preferred"],
      materialStatus: [],
      whoEssential: ["1"],
    });
    expect(localStorage.getItem(GLOBAL_FILTER_V2_LS_KEY)).toContain("preferred");
    expect(JSON.parse(localStorage.getItem("global_filters")!)).toEqual({
      gf_supplier: { id: "1", label: "A" },
    });
    expect(readGlobalFilterV2FromLocalStorage()?.formulary).toEqual(["preferred"]);
    clearGlobalFilterV2LocalStorage();
    expect(localStorage.getItem(GLOBAL_FILTER_V2_LS_KEY)).toBeNull();
  });
});

describe("global-filters-v2 request policy", () => {
  it("maps supported selections to backend params", () => {
    const params = mapGlobalFilterV2ToBackendParams(
      {
        formulary: ["preferred", "specialty"],
        materialStatus: ["active"],
        whoEssential: ["1"],
      },
      "all"
    );
    expect(params).toEqual({
      formulary: "preferred,specialty",
      xplant_mat_stat: "active",
      who_essential: "1",
    });

    expect(
      mapGlobalFilterV2ToBackendParams(
        {
          formulary: ["preferred"],
          materialStatus: ["active"],
          whoEssential: ["1"],
        },
        ["formulary"]
      )
    ).toEqual({ formulary: "preferred" });

    expect(
      mapGlobalFilterV2ToBackendParams(
        {
          formulary: ["preferred"],
          materialStatus: [],
          whoEssential: [],
        },
        false
      )
    ).toEqual({});
  });

  it("lets local params win on merge", () => {
    expect(mergeGlobalFilterV2Params({ formulary: "global" }, { formulary: "local", page: 1 })).toEqual({
      formulary: "local",
      page: 1,
    });
  });
});

describe("global-filters-v2 query key fragment", () => {
  it("includes only supported filters", () => {
    const fragment = buildGlobalFilterV2QueryKeyFragment(
      {
        formulary: ["preferred"],
        materialStatus: ["active"],
        whoEssential: ["1"],
      },
      ["materialStatus"]
    );
    expect(fragment).toEqual({
      globalFiltersV2: {
        formulary: [],
        materialStatus: ["active"],
        whoEssential: [],
      },
    });
  });
});
