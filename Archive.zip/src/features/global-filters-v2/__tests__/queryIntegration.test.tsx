import { QueryClient, QueryClientProvider, useQuery } from "@tanstack/react-query";
import { renderHook, waitFor } from "@testing-library/react";
import type { ReactNode } from "react";
import { MemoryRouter } from "react-router-dom";
import { buildGlobalFilterV2QueryKeyFragment } from "../queryScope";
import { useGlobalFilterV2 } from "../useGlobalFilterV2";

function createWrapper(initialEntry = "/manage/summary") {
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return ({ children }: { children: ReactNode }) => (
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[initialEntry]}>{children}</MemoryRouter>
    </QueryClientProvider>
  );
}

describe("global-filters-v2 query integration", () => {
  it("refetches when applied supported filters change, not on draft-only edits", async () => {
    const fetchFn = jest.fn(async () => ({ ok: true }));

    const { result, rerender } = renderHook(
      () => {
        const { selections, apply } = useGlobalFilterV2();
        const fragment = buildGlobalFilterV2QueryKeyFragment(selections, "all");
        const query = useQuery({
          queryKey: ["manage-v2-example", fragment],
          queryFn: fetchFn,
        });
        return { query, selections, apply };
      },
      { wrapper: createWrapper() }
    );

    await waitFor(() => expect(result.current.query.isSuccess).toBe(true));
    expect(fetchFn).toHaveBeenCalledTimes(1);

    // Draft-only: mutate local state without applying — no extra fetch.
    const draft = {
      ...result.current.selections,
      formulary: ["specialty"],
    };
    expect(draft).not.toEqual(result.current.selections);
    rerender();
    expect(fetchFn).toHaveBeenCalledTimes(1);

    result.current.apply({
      formulary: ["preferred"],
      materialStatus: [],
      whoEssential: [],
    });
    rerender();

    await waitFor(() => expect(fetchFn).toHaveBeenCalledTimes(2));
  });

  it("does not refetch when only unsupported filters change", async () => {
    const fetchFn = jest.fn(async () => ({ ok: true }));
    const support = ["formulary"] as const;

    const { result, rerender } = renderHook(
      () => {
        const { selections, apply } = useGlobalFilterV2();
        const fragment = buildGlobalFilterV2QueryKeyFragment(selections, support);
        const query = useQuery({
          queryKey: ["manage-v2-partial", fragment],
          queryFn: fetchFn,
        });
        return { query, apply };
      },
      {
        wrapper: createWrapper("/manage/summary?gf2_formulary=preferred"),
      }
    );

    await waitFor(() => expect(result.current.query.isSuccess).toBe(true));
    expect(fetchFn).toHaveBeenCalledTimes(1);

    result.current.apply({
      formulary: ["preferred"],
      materialStatus: ["active"],
      whoEssential: ["1"],
    });
    rerender();

    await waitFor(() => expect(result.current.query.isSuccess).toBe(true));
    expect(fetchFn).toHaveBeenCalledTimes(1);
  });
});
