/**
 * Example integration contract for new Stratium Manage queries.
 *
 * Copy this pattern when adding real Manage endpoints:
 * 1. Read selections from `useGlobalFilterV2()` (or pass them in from a parent)
 * 2. Key the query with `manageV2QueryKeys.widget(id, selections, support)`
 * 3. Build request params from the same selections + support via
 *    `buildGlobalFilterV2RequestConfig`, so params can never disagree with the key
 * 4. Forward TanStack's `signal`
 */
import { keepPreviousData, queryOptions } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import { manageV2QueryKeys } from "./queryScope";
import { buildGlobalFilterV2RequestConfig } from "./requestPolicy";
import type { GlobalFilterV2Selections, GlobalFilterV2Support } from "./types";

export function exampleManageWidgetQueryOptions(args: {
  selections: GlobalFilterV2Selections;
  support?: GlobalFilterV2Support;
  widgetId?: string;
  localParams?: Record<string, unknown>;
}) {
  const support = args.support ?? "all";
  const widgetId = args.widgetId ?? "example-widget";
  const requestConfig = buildGlobalFilterV2RequestConfig(args.selections, support, args.localParams);

  return queryOptions({
    queryKey: manageV2QueryKeys.widget(widgetId, args.selections, support),
    queryFn: async ({ signal }) => {
      const response = await apiClient.get<{ ok: boolean }>(`/manage/example/${widgetId}/`, {
        ...requestConfig,
        signal,
      });
      return response.data;
    },
    placeholderData: keepPreviousData,
  });
}
