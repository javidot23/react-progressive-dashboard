import { GLOBAL_FILTER_V2_CONFIG, type GlobalFilterV2OptionsCatalog } from "./types";

export const TEMPORARY_GLOBAL_FILTER_V2_OPTIONS: GlobalFilterV2OptionsCatalog = {
  formulary: {
    key: "formulary",
    label: GLOBAL_FILTER_V2_CONFIG.formulary.label,
    options: [
      { id: "formulary", label: "Formulary" },
      { id: "non_formulary", label: "Non-Formulary" },
      { id: "preferred", label: "Preferred" },
      { id: "specialty", label: "Specialty" },
    ],
  },
  materialStatus: {
    key: "materialStatus",
    label: GLOBAL_FILTER_V2_CONFIG.materialStatus.label,
    options: [
      { id: "active", label: "Active" },
      { id: "inactive", label: "Inactive" },
      { id: "pending", label: "Pending" },
      { id: "discontinued", label: "Discontinued" },
    ],
  },
  whoEssential: {
    key: "whoEssential",
    label: GLOBAL_FILTER_V2_CONFIG.whoEssential.label,
    options: [
      { id: "1", label: "Yes" },
      { id: "0", label: "No" },
    ],
  },
};

export type FetchGlobalFilterV2Options = (signal?: AbortSignal) => Promise<GlobalFilterV2OptionsCatalog>;

let optionsFetcher: FetchGlobalFilterV2Options = async () => TEMPORARY_GLOBAL_FILTER_V2_OPTIONS;

export function setGlobalFilterV2OptionsFetcher(fetcher: FetchGlobalFilterV2Options): void {
  optionsFetcher = fetcher;
}

export function resetGlobalFilterV2OptionsFetcher(): void {
  optionsFetcher = async () => TEMPORARY_GLOBAL_FILTER_V2_OPTIONS;
}

export async function fetchGlobalFilterV2Options(signal?: AbortSignal): Promise<GlobalFilterV2OptionsCatalog> {
  return optionsFetcher(signal);
}
