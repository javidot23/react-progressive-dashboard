import { queryOptions } from "@tanstack/react-query";
import { fetchGlobalFilterV2Options } from "./options";
import { type GlobalFilterV2Selections, type GlobalFilterV2Support, pickSupportedSelections } from "./types";

export const globalFilterV2OptionsQueryKey = ["global-filters-v2", "options"] as const;

export function globalFilterV2OptionsQueryOptions() {
  return queryOptions({
    queryKey: globalFilterV2OptionsQueryKey,
    queryFn: ({ signal }) => fetchGlobalFilterV2Options(signal),
    staleTime: 5 * 60_000,
  });
}

export function buildGlobalFilterV2QueryKeyFragment(
  selections: GlobalFilterV2Selections,
  support: GlobalFilterV2Support = "all"
): { globalFiltersV2: GlobalFilterV2Selections } {
  return {
    globalFiltersV2: pickSupportedSelections(selections, support),
  };
}

export const manageV2QueryKeys = {
  root: ["manage-v2"] as const,
  widget: (widgetId: string, selections: GlobalFilterV2Selections, support: GlobalFilterV2Support = "all") =>
    [...manageV2QueryKeys.root, widgetId, buildGlobalFilterV2QueryKeyFragment(selections, support)] as const,
};
