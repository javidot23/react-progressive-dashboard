import { useEffect, useRef, type ReactNode } from "react";
import { useSearchParams } from "react-router-dom";
import { hasAppliedFilters } from "./types";
import { readGlobalFilterV2FromLocalStorage, writeGlobalFilterV2ToLocalStorage } from "./persistence";
import { hasGlobalFilterV2InSearchParams, writeGlobalFilterV2ToSearchParams } from "./url";

export function GlobalFilterV2Boundary({ children }: { children: ReactNode }) {
  const [params, setParams] = useSearchParams();
  const restoredRef = useRef(false);

  useEffect(() => {
    if (restoredRef.current) return;
    restoredRef.current = true;

    if (hasGlobalFilterV2InSearchParams(params)) {
      return;
    }

    const fromLs = readGlobalFilterV2FromLocalStorage();
    if (!fromLs || !hasAppliedFilters(fromLs)) {
      return;
    }

    writeGlobalFilterV2ToLocalStorage(fromLs);
    setParams(prev => writeGlobalFilterV2ToSearchParams(prev, fromLs), { replace: true });
  }, [params, setParams]);

  return children;
}
