import { useEffect, type ReactNode } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { useSearchParams } from "react-router-dom";
import { GlobalFiltersV2 } from "./GlobalFiltersV2";

function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-[36rem] items-start justify-end overflow-visible bg-ui-background-primary p-6">{children}</div>
  );
}

function SeedSearchParams({ search }: { search: string }) {
  const [, setParams] = useSearchParams();

  useEffect(() => {
    setParams(new URLSearchParams(search.startsWith("?") ? search.slice(1) : search), { replace: true });
  }, [search, setParams]);

  return null;
}

const meta: Meta<typeof GlobalFiltersV2> = {
  title: "Features/GlobalFiltersV2",
  component: GlobalFiltersV2,
  decorators: [
    Story => (
      <Layout>
        <Story />
      </Layout>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof GlobalFiltersV2>;

export const Default: Story = {};
export const WithAppliedFilters: Story = {
  decorators: [
    Story => (
      <>
        <SeedSearchParams search="gf2_formulary=preferred&gf2_formulary=specialty&gf2_material_status=discontinued&gf2_who_essential=1" />
        <Story />
      </>
    ),
  ],
};
