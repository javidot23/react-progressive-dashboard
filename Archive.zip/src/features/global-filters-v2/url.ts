import { toWafSafeQueryString } from "@/lib/queryStringUtils";
import {
  GLOBAL_FILTER_V2_CONFIG,
  GLOBAL_FILTER_V2_KEYS,
  GLOBAL_FILTER_V2_URL_PREFIX,
  createEmptySelections,
  type GlobalFilterV2Selections,
  normalizeSelections,
} from "./types";

export function isGlobalFilterV2UrlKey(key: string): boolean {
  return key.startsWith(GLOBAL_FILTER_V2_URL_PREFIX);
}

export function parseGlobalFilterV2FromSearchParams(params: URLSearchParams): GlobalFilterV2Selections {
  const next = createEmptySelections();

  for (const key of GLOBAL_FILTER_V2_KEYS) {
    next[key] = params
      .getAll(GLOBAL_FILTER_V2_CONFIG[key].urlKey)
      .map(value => value.trim())
      .filter(Boolean);
  }

  return normalizeSelections(next);
}

export function parseGlobalFilterV2FromSearch(search: string): GlobalFilterV2Selections {
  const params = new URLSearchParams(search.startsWith("?") ? search.slice(1) : search);
  return parseGlobalFilterV2FromSearchParams(params);
}

export function hasGlobalFilterV2InSearchParams(params: URLSearchParams): boolean {
  for (const key of params.keys()) {
    if (isGlobalFilterV2UrlKey(key)) return true;
  }
  return false;
}

export function hasGlobalFilterV2InSearch(search: string): boolean {
  const params = new URLSearchParams(search.startsWith("?") ? search.slice(1) : search);
  return hasGlobalFilterV2InSearchParams(params);
}

export function writeGlobalFilterV2ToSearchParams(
  params: URLSearchParams,
  selections: GlobalFilterV2Selections
): URLSearchParams {
  const next = new URLSearchParams(params);
  const keysToDelete: string[] = [];
  next.forEach((_, key) => {
    if (isGlobalFilterV2UrlKey(key)) keysToDelete.push(key);
  });
  keysToDelete.forEach(key => next.delete(key));

  const normalized = normalizeSelections(selections);
  for (const key of GLOBAL_FILTER_V2_KEYS) {
    const urlKey = GLOBAL_FILTER_V2_CONFIG[key].urlKey;
    for (const id of normalized[key]) {
      next.append(urlKey, id);
    }
  }

  return next;
}

export function serializeGlobalFilterV2ToSearch(selections: GlobalFilterV2Selections, currentSearch = ""): string {
  const params = new URLSearchParams(currentSearch.startsWith("?") ? currentSearch.slice(1) : currentSearch);
  return toWafSafeQueryString(writeGlobalFilterV2ToSearchParams(params, selections));
}
