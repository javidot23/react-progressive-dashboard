import { useCallback, useId, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/atoms/Button";
import { useDialogFocusTrap } from "@/components/atoms/useDialogFocusTrap";
import { cn } from "@/lib/utils";
import { globalFilterV2OptionsQueryOptions } from "./queryScope";
import {
  GLOBAL_FILTER_V2_KEYS,
  countAppliedFilters,
  createEmptySelections,
  type GlobalFilterV2Key,
  type GlobalFilterV2Selections,
  normalizeSelections,
} from "./types";
import { useGlobalFilterV2 } from "./useGlobalFilterV2";

function toggleId(ids: string[], id: string): string[] {
  return ids.includes(id) ? ids.filter(value => value !== id) : [...ids, id];
}

function ChipButton({ label, selected, onToggle }: { label: string; selected: boolean; onToggle: () => void }) {
  return (
    <Button
      type="button"
      size="sm"
      aria-pressed={selected}
      onClick={onToggle}
      variant={selected ? "fill" : "outline"}
      className={
        selected
          ? "border border-transparent"
          : "border-ui-border-secondary bg-ui-background-secondary text-ui-text-primary hover:bg-ui-background-muted"
      }
    >
      {label}
    </Button>
  );
}

export function GlobalFiltersV2() {
  const { selections: applied, apply, clear } = useGlobalFilterV2();

  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<GlobalFilterV2Selections>(applied);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const panelId = useId();

  const optionsQuery = useQuery(globalFilterV2OptionsQueryOptions());
  const appliedCount = countAppliedFilters(applied);

  const openPanel = useCallback(() => {
    setDraft(normalizeSelections(applied));
    setOpen(true);
  }, [applied]);

  const closePanel = useCallback(() => {
    setOpen(false);
  }, []);

  useDialogFocusTrap({
    isOpen: open,
    onClose: closePanel,
    containerRef: panelRef,
    triggerRef,
  });

  const toggleDraft = useCallback((key: GlobalFilterV2Key, id: string) => {
    setDraft(prev => ({
      ...prev,
      [key]: toggleId(prev[key], id),
    }));
  }, []);

  const handleClearAll = useCallback(() => {
    clear();
    setDraft(createEmptySelections());
    closePanel();
  }, [clear, closePanel]);

  const handleShowResults = useCallback(() => {
    apply(draft);
    closePanel();
  }, [draft, apply, closePanel]);

  return (
    <div className="relative">
      <Button
        ref={triggerRef}
        type="button"
        action="secondary"
        size="sm"
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? panelId : undefined}
        onClick={() => (open ? closePanel() : openPanel())}
        startIcon={<SlidersHorizontal aria-hidden="true" className="!h-4 !w-4" strokeWidth={2} />}
        className="h-8 gap-1.5 border-transparent bg-neutral-100 px-3 text-sm font-bold text-brand-primary-main hover:bg-neutral-200"
      >
        Filters
        {appliedCount > 0 ? (
          <span className="inline-flex min-w-5 items-center justify-center rounded-full bg-brand-primary-main px-1.5 text-xs text-white">
            {appliedCount}
          </span>
        ) : null}
      </Button>

      {open ? (
        <>
          <button
            type="button"
            aria-label="Dismiss filters"
            className="fixed inset-0 z-[9998] cursor-default bg-transparent"
            onClick={closePanel}
          />
          <div
            ref={panelRef}
            id={panelId}
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            tabIndex={-1}
            className="absolute right-0 top-full z-[9999] mt-2 w-[min(360px,calc(100vw-1rem))] rounded-xl border border-[#EAEAEA] bg-ui-background-primary outline-none"
            style={{ boxShadow: "0px 10px 30px -10px #00000014" }}
          >
            <div className="relative flex items-center justify-center border-b border-ui-border-primary px-4 py-3">
              <button
                type="button"
                aria-label="Close filters"
                onClick={closePanel}
                className="absolute left-3 top-1/2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-[#F7F7F7] text-ui-text-secondary hover:bg-ui-background-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-interactive-primary-focus"
              >
                <X aria-hidden="true" className="h-4 w-4" />
              </button>
              <h2 id={titleId} className="text-base font-bold text-ui-text-primary">
                Filters
              </h2>
            </div>

            <div className="max-h-[min(70vh,28rem)] space-y-4 overflow-y-auto px-4 py-4">
              {optionsQuery.isPending ? <p className="text-sm text-ui-text-secondary">Loading filter options…</p> : null}

              {optionsQuery.isError ? (
                <p className="text-sm text-status-error-main" role="alert">
                  Unable to load filter options.
                </p>
              ) : null}

              {optionsQuery.data
                ? GLOBAL_FILTER_V2_KEYS.map((key, index) => {
                    const group = optionsQuery.data[key];
                    return (
                      <section key={key} className={cn(index > 0 && "border-t border-[#F3F3F3] pt-4")} aria-label={group.label}>
                        <h3 className="mb-3 text-sm font-bold text-ui-text-primary">{group.label}</h3>
                        <div className="flex flex-wrap gap-2">
                          {group.options.map(option => (
                            <ChipButton
                              key={option.id}
                              label={option.label}
                              selected={draft[key].includes(option.id)}
                              onToggle={() => toggleDraft(key, option.id)}
                            />
                          ))}
                        </div>
                      </section>
                    );
                  })
                : null}
            </div>

            <div className="flex items-center justify-between gap-3 border-t border-ui-border-primary px-4 py-3">
              <button
                type="button"
                onClick={handleClearAll}
                className="text-sm font-semibold text-brand-primary-main hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-interactive-primary-focus"
              >
                Clear all
              </button>
              <Button type="button" size="sm" onClick={handleShowResults} disabled={!optionsQuery.data}>
                Show results
              </Button>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
