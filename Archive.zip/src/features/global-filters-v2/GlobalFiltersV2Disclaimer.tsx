import { useState } from "react";
import AlertTriangleIcon from "@/assets/icons/alert-triangle-primary.svg";
import RemoveIcon from "@/assets/icons/remove.svg";
import { GLOBAL_FILTER_V2_KEYS, hasAppliedFilters, resolveSupportedKeys, type GlobalFilterV2Support } from "./types";
import { useGlobalFilterV2 } from "./useGlobalFilterV2";

const DEFAULT_MESSAGE = "This chart is not filtered based on all of the global filters you've selected";

interface GlobalFiltersV2DisclaimerProps {
  message?: string;
  support?: GlobalFilterV2Support;
}

export function GlobalFiltersV2Disclaimer({ message = DEFAULT_MESSAGE, support = false }: GlobalFiltersV2DisclaimerProps) {
  const { selections } = useGlobalFilterV2();
  const [isCollapsed, setIsCollapsed] = useState(false);

  if (!hasAppliedFilters(selections)) {
    return null;
  }

  const supported = new Set(resolveSupportedKeys(support));
  const hasUnsupportedApplied = GLOBAL_FILTER_V2_KEYS.some(key => selections[key].length > 0 && !supported.has(key));

  if (!hasUnsupportedApplied) {
    return null;
  }

  if (isCollapsed) {
    return (
      <button
        type="button"
        onClick={() => setIsCollapsed(false)}
        className="mb-4 flex h-10 w-10 items-center justify-center rounded-md border border-[#FFA400] bg-[#FFF8BA] hover:bg-[#FFE066]"
        aria-label="Expand disclaimer"
      >
        <img src={AlertTriangleIcon} alt="" width={18} height={18} />
      </button>
    );
  }

  return (
    <div className="mb-4 flex items-center gap-3 rounded-md border border-[#FFA400] bg-[#FFF8BA] p-3">
      <img src={AlertTriangleIcon} alt="" width={18} height={18} className="shrink-0" />
      <div className="min-w-0 flex-1">
        <h3 className="text-sm font-bold text-ui-text-primary">Disclaimer</h3>
        <p className="text-sm text-ui-text-secondary">{message}</p>
      </div>
      <button type="button" onClick={() => setIsCollapsed(true)} aria-label="Collapse disclaimer" className="shrink-0">
        <img src={RemoveIcon} alt="" width={18} height={18} />
      </button>
    </div>
  );
}
