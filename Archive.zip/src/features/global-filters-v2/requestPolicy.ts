import { serializeParamsWafSafe } from "@/lib/queryStringUtils";
import {
  GLOBAL_FILTER_V2_CONFIG,
  GLOBAL_FILTER_V2_KEYS,
  type GlobalFilterV2Selections,
  type GlobalFilterV2Support,
  pickSupportedSelections,
} from "./types";

export function mapGlobalFilterV2ToBackendParams(
  selections: GlobalFilterV2Selections,
  support: GlobalFilterV2Support = "all"
): Record<string, string> {
  const supported = pickSupportedSelections(selections, support);
  const out: Record<string, string> = {};

  for (const key of GLOBAL_FILTER_V2_KEYS) {
    const ids = supported[key];
    if (ids.length === 0) continue;
    out[GLOBAL_FILTER_V2_CONFIG[key].backendParam] = ids.join(",");
  }

  return out;
}

export function mergeGlobalFilterV2Params(
  globalParams: Record<string, string>,
  localParams: Record<string, unknown>
): Record<string, unknown> {
  return { ...globalParams, ...localParams };
}

export function buildGlobalFilterV2RequestConfig(
  selections: GlobalFilterV2Selections,
  support: GlobalFilterV2Support = "all",
  localParams: Record<string, unknown> = {}
) {
  return {
    params: mergeGlobalFilterV2Params(mapGlobalFilterV2ToBackendParams(selections, support), localParams),
    paramsSerializer: { serialize: serializeParamsWafSafe },
  };
}
