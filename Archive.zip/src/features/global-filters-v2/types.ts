export const GLOBAL_FILTER_V2_KEYS = ["formulary", "materialStatus", "whoEssential"] as const;

export type GlobalFilterV2Key = (typeof GLOBAL_FILTER_V2_KEYS)[number];

export type GlobalFilterV2Selections = Record<GlobalFilterV2Key, string[]>;

export type GlobalFilterV2Option = {
  id: string;
  label: string;
};

export type GlobalFilterV2OptionGroup = {
  key: GlobalFilterV2Key;
  label: string;
  options: GlobalFilterV2Option[];
};

export type GlobalFilterV2OptionsCatalog = Record<GlobalFilterV2Key, GlobalFilterV2OptionGroup>;

type GlobalFilterV2FilterConfig = {
  urlKey: string;
  backendParam: string;
  label: string;
};

export const GLOBAL_FILTER_V2_CONFIG = {
  formulary: {
    urlKey: "gf2_formulary",
    backendParam: "formulary",
    label: "Formulary (Contract Type)",
  },
  materialStatus: {
    urlKey: "gf2_material_status",
    backendParam: "xplant_mat_stat",
    label: "Material Status",
  },
  whoEssential: {
    urlKey: "gf2_who_essential",
    backendParam: "who_essential",
    label: "WHO Essential",
  },
} as const satisfies Record<GlobalFilterV2Key, GlobalFilterV2FilterConfig>;

export const GLOBAL_FILTER_V2_URL_PREFIX = "gf2_";

export const GLOBAL_FILTER_V2_LS_KEY = "stratium_global_filters_v2";

export type GlobalFilterV2Support = "all" | readonly GlobalFilterV2Key[] | false;

export function createEmptySelections(): GlobalFilterV2Selections {
  const next = {} as GlobalFilterV2Selections;
  for (const key of GLOBAL_FILTER_V2_KEYS) {
    next[key] = [];
  }
  return next;
}

export function normalizeSelectionIds(ids: readonly string[]): string[] {
  return [...new Set(ids.map(id => String(id).trim()).filter(Boolean))].sort();
}

export function normalizeSelections(selections: GlobalFilterV2Selections): GlobalFilterV2Selections {
  const next = {} as GlobalFilterV2Selections;
  for (const key of GLOBAL_FILTER_V2_KEYS) {
    next[key] = normalizeSelectionIds(selections[key] ?? []);
  }
  return next;
}

export function countAppliedFilters(selections: GlobalFilterV2Selections): number {
  return GLOBAL_FILTER_V2_KEYS.reduce((total, key) => total + selections[key].length, 0);
}

export function hasAppliedFilters(selections: GlobalFilterV2Selections): boolean {
  return countAppliedFilters(selections) > 0;
}

export function selectionsEqual(a: GlobalFilterV2Selections, b: GlobalFilterV2Selections): boolean {
  return GLOBAL_FILTER_V2_KEYS.every(key => {
    const left = normalizeSelectionIds(a[key] ?? []);
    const right = normalizeSelectionIds(b[key] ?? []);
    if (left.length !== right.length) return false;
    return left.every((id, index) => id === right[index]);
  });
}

export function resolveSupportedKeys(support: GlobalFilterV2Support = "all"): GlobalFilterV2Key[] {
  if (support === false) return [];
  if (support === "all") return [...GLOBAL_FILTER_V2_KEYS];
  return GLOBAL_FILTER_V2_KEYS.filter(key => support.includes(key));
}

export function pickSupportedSelections(
  selections: GlobalFilterV2Selections,
  support: GlobalFilterV2Support = "all"
): GlobalFilterV2Selections {
  const supported = new Set(resolveSupportedKeys(support));
  const next = {} as GlobalFilterV2Selections;
  for (const key of GLOBAL_FILTER_V2_KEYS) {
    next[key] = supported.has(key) ? normalizeSelectionIds(selections[key] ?? []) : [];
  }
  return next;
}
