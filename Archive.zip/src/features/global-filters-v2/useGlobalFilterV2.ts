import { useCallback, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { writeGlobalFilterV2ToLocalStorage } from "./persistence";
import { createEmptySelections, type GlobalFilterV2Selections, normalizeSelections } from "./types";
import { parseGlobalFilterV2FromSearchParams, writeGlobalFilterV2ToSearchParams } from "./url";

export function useGlobalFilterV2() {
  const [params, setParams] = useSearchParams();

  const selections = useMemo(() => parseGlobalFilterV2FromSearchParams(params), [params]);

  const apply = useCallback(
    (next: GlobalFilterV2Selections) => {
      const normalized = normalizeSelections(next);
      writeGlobalFilterV2ToLocalStorage(normalized);
      setParams(prev => writeGlobalFilterV2ToSearchParams(prev, normalized), { replace: true });
    },
    [setParams]
  );

  const clear = useCallback(() => {
    apply(createEmptySelections());
  }, [apply]);

  return { selections, apply, clear };
}
