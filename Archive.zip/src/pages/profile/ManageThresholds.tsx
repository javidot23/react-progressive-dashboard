import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/atoms/Card";
import { Input } from "@/components/atoms/Input";
import { Button } from "@/components/atoms/Button";
import { getMySettings, updateMySettings, UserSettingsResponse } from "@/services/userSettingsService";
import { getErrorMessage } from "@/lib/getErrorMessage";
import { toast } from "@/lib/toast";
import retryIconUrl from "@/assets/icons/retry-icon.svg?url";

const DEFAULT_SERVICE_LEVEL = 90;
const PERCENTAGE_MIN = 0;
const PERCENTAGE_MAX = 100;

const initialState = {
  inboundServiceLevel: DEFAULT_SERVICE_LEVEL,
  valueAtRisk: 0,
  productUnfilledQuantity: 0,
  daysOnHand: 0,
};
interface ThresholdCardProps {
  label: string;
  currentValue: number;
  value: string;
  onChange: (value: string) => void;
  linkTo: string;
  showPercentSign?: boolean;
  max?: number;
}

const clampPercentage = (value: number): number => Math.min(PERCENTAGE_MAX, Math.max(PERCENTAGE_MIN, Math.round(value)));

const clampPositive = (value: number): number => Math.max(0, Math.round(value));

const parseNumericValue = (value: number | string | null | undefined, clampFn: (n: number) => number): number | null => {
  if (value == null) return null;
  return clampFn(Number(value));
};

const toDisplayString = (value: number | null, defaultValue: string = ""): string =>
  value == null ? defaultValue : String(value);

const ThresholdCard: React.FC<ThresholdCardProps> = ({
  label,
  currentValue,
  value,
  onChange,
  linkTo,
  showPercentSign = true,
  max,
}) => {
  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const inputValue = e.target.value;
      if (inputValue === "") {
        onChange("");
        return;
      }
      const n = Number(inputValue);
      if (!Number.isNaN(n)) {
        const clamped = max != null ? clampPercentage(n) : clampPositive(n);
        onChange(String(clamped));
      }
    },
    [onChange, max]
  );

  return (
    <Card className="p-0 rounded-lg bg-ui-background-secondary border-0 grow">
      <CardContent className="p-0">
        <div className="flex flex-col sm:flex-row">
          <div className="w-full sm:w-[3px] h-[3px] sm:h-auto bg-brand-primary-main rounded sm:mr-4 mb-4 sm:mb-0" />
          <div className="flex-1 py-4 px-2 sm:px-1">
            <div className="text-ui-text-primary">{label}</div>
            <div className="text-xs text-ui-text-secondary mt-1">
              Current: {currentValue}
              {showPercentSign && "%"}
            </div>
            <div className="mt-3 flex flex-col sm:flex-row items-start sm:items-center gap-2 w-full sm:max-w-xl">
              <Input
                type="number"
                min="0"
                max={max}
                value={value}
                onChange={handleChange}
                className="bg-white border-ui-border-primary rounded-md h-10 w-full sm:w-auto grow"
              />
              {showPercentSign && <span className="text-sm text-ui-text-secondary px-2">%</span>}
            </div>
            <Link
              to={linkTo}
              className="mt-3 inline-flex items-center justify-center rounded-md px-3 h-8 bg-[rgba(232,232,232,1)] text-brand-primary-main font-bold text-xs sm:text-sm w-full sm:w-auto border border-ui-border-primary hover:opacity-80 transition-opacity"
            >
              View Chart Location
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export const ManageThresholds: React.FC = () => {
  const [settings, setSettings] = useState<UserSettingsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const data = await getMySettings();
        setSettings(data);
      } catch (e) {
        console.warn("Failed to load user settings", e);
      } finally {
        setLoading(false);
      }
    };

    loadSettings();
  }, []);

  const parsedValues = useMemo(() => {
    if (!settings) return null;

    return {
      inboundServiceLevel: parseNumericValue(settings.inbound_service_level_target, clampPercentage) ?? null,
      valueAtRisk: parseNumericValue(settings.risk_threshold, clampPercentage) ?? null,
      productUnfilledQuantity: parseNumericValue(settings.products_omit_goal, clampPercentage) ?? null,
      daysOnHand: parseNumericValue(settings.days_on_hand, clampPositive) ?? null,
    };
  }, [settings]);

  const savedValues = useMemo(() => {
    if (!parsedValues) return initialState;

    return {
      inboundServiceLevel: parsedValues.inboundServiceLevel ?? DEFAULT_SERVICE_LEVEL,
      valueAtRisk: parsedValues.valueAtRisk ?? 0,
      productUnfilledQuantity: parsedValues.productUnfilledQuantity ?? 0,
      daysOnHand: parsedValues.daysOnHand ?? 0,
    };
  }, [parsedValues]);

  const [formState, setFormState] = useState({
    inboundServiceLevel: String(DEFAULT_SERVICE_LEVEL),
    valueAtRisk: "",
    productUnfilledQuantity: "",
    daysOnHand: "",
  });

  useEffect(() => {
    if (parsedValues) {
      setFormState({
        inboundServiceLevel: toDisplayString(parsedValues.inboundServiceLevel ?? null, String(DEFAULT_SERVICE_LEVEL)),
        valueAtRisk: toDisplayString(parsedValues.valueAtRisk ?? null),
        productUnfilledQuantity: toDisplayString(parsedValues.productUnfilledQuantity ?? null),
        daysOnHand: toDisplayString(parsedValues.daysOnHand ?? null),
      });
    }
  }, [parsedValues]);

  const isValidPercentage = useCallback((value: string): boolean => {
    if (value === "") return true;
    const n = Number(value);
    return !Number.isNaN(n) && Number.isInteger(n) && n >= PERCENTAGE_MIN && n <= PERCENTAGE_MAX;
  }, []);

  const isValidPositiveInt = useCallback((value: string): boolean => {
    if (value === "") return true;
    const n = Number(value);
    return !Number.isNaN(n) && Number.isInteger(n) && n >= 0;
  }, []);

  const canSave = useMemo(
    () =>
      isValidPercentage(formState.inboundServiceLevel) &&
      isValidPercentage(formState.valueAtRisk) &&
      isValidPercentage(formState.productUnfilledQuantity) &&
      isValidPositiveInt(formState.daysOnHand),
    [formState, isValidPercentage, isValidPositiveInt]
  );

  const handleSave = useCallback(async () => {
    setSaving(true);
    setSaveError(null);

    try {
      const updatedSettings = await updateMySettings({
        inbound_service_level_target: formState.inboundServiceLevel === "" ? null : Number(formState.inboundServiceLevel),
        risk_threshold: formState.valueAtRisk === "" ? null : Number(formState.valueAtRisk),
        products_omit_goal: formState.productUnfilledQuantity === "" ? null : Number(formState.productUnfilledQuantity),
        days_on_hand: formState.daysOnHand === "" ? null : Number(formState.daysOnHand),
        value_at_risk_target: formState.valueAtRisk === "" ? null : Number(formState.valueAtRisk),
        unfilled_percentage_target: formState.productUnfilledQuantity === "" ? null : Number(formState.productUnfilledQuantity),
      });

      setSettings(updatedSettings);
      toast.success({ title: "Thresholds saved" });
    } catch (e) {
      setSaveError("Failed to save settings");
      toast.error({
        title: "Couldn't save thresholds",
        description: getErrorMessage(e),
      });
    } finally {
      setSaving(false);
    }
  }, [formState]);

  const handleReset = useCallback(() => {
    setFormState({
      inboundServiceLevel: String(DEFAULT_SERVICE_LEVEL),
      valueAtRisk: "",
      productUnfilledQuantity: "",
      daysOnHand: "",
    });
  }, []);

  if (loading) {
    return (
      <div className="bg-white border border-ui-border-primary rounded-md p-4 md:p-6">
        <p className="text-ui-text-secondary">Loading settings...</p>
      </div>
    );
  }

  return (
    <div className="bg-white border border-[#E2E8F0] rounded-2xl p-4 md:p-6 space-y-6">
      <div>
        <h2 className="text-base sm:text-lg font-semibold text-ui-text-primary">Risk & Performance Thresholds</h2>
        <p className="text-xs text-ui-text-secondary mt-1">
          Configure personal thresholds and targets across all charts and modules. Your settings apply only to your view and won't
          impact other users.
        </p>
      </div>
      <div className="flex flex-col gap-10">
        <div className="flex flex-col gap-4">
          <p className="font-bold text-ui-text-primary">Overview Module</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <ThresholdCard
              label="Inbound Service Level Goal"
              currentValue={savedValues.inboundServiceLevel}
              value={formState.inboundServiceLevel}
              onChange={value => setFormState(prev => ({ ...prev, inboundServiceLevel: value }))}
              linkTo="/overview"
              max={PERCENTAGE_MAX}
            />
            <ThresholdCard
              label="Value at Risk Goal"
              currentValue={savedValues.valueAtRisk}
              value={formState.valueAtRisk}
              onChange={value => setFormState(prev => ({ ...prev, valueAtRisk: value }))}
              linkTo="/overview"
              max={PERCENTAGE_MAX}
            />
            <ThresholdCard
              label="Outbound Unfilled Quantity Goal"
              currentValue={savedValues.productUnfilledQuantity}
              value={formState.productUnfilledQuantity}
              onChange={value => setFormState(prev => ({ ...prev, productUnfilledQuantity: value }))}
              linkTo="/overview"
              max={PERCENTAGE_MAX}
            />
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <p className="font-bold text-ui-text-primary">Manage Module</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <ThresholdCard
              label="Days On Hand"
              currentValue={savedValues.daysOnHand}
              value={formState.daysOnHand}
              onChange={value => setFormState(prev => ({ ...prev, daysOnHand: value }))}
              linkTo="/manage/inventory"
              max={PERCENTAGE_MAX}
            />
          </div>
        </div>
      </div>
      <div className="pt-4 mt-2 border-t border-ui-border-primary flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <Button
          disabled={!canSave || saving}
          onClick={handleSave}
          className="px-5 bg-brand-primary-main text-white font-bold text-sm w-full sm:w-auto"
        >
          {saving ? "Saving..." : "Save My Thresholds"}
        </Button>
        <Button variant="outline" onClick={handleReset} className="rounded-md text-brand-primary-main font-bold w-full sm:w-auto">
          <img src={retryIconUrl} className="w-4 h-4 mr-2" alt="" aria-hidden="true" />
          Reset to Default
        </Button>
        {saveError && <span className="text-red-600 text-sm sm:ml-2 mt-2 sm:mt-0">{saveError}</span>}
      </div>
    </div>
  );
};
