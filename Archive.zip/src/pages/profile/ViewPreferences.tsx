import React from "react";
import { Card, CardContent } from "@/components/atoms/Card";
import { useTableSettings } from "@/components/atoms/TableSettings";

export const ViewPreferences: React.FC = () => {
  const tableSettings = useTableSettings();
  const settings = tableSettings?.settings;
  const updateSettings = tableSettings?.updateSettings;

  return (
    <div className="bg-white rounded-md p-4 md:p-6 space-y-6">
      <div className="border-b border-b-[#F0F0F0] pb-4">
        <h2 className="text-base sm:text-lg font-semibold text-ui-text-primary">Display Preferences</h2>
        <p className="text-xs text-ui-text-secondary mt-1">
          Set your levels and targets that apply across all relevant charts and modules
        </p>
      </div>
      <Card className="p-0 border-none">
        <CardContent className="p-0">
          <div className="flex flex-col items-start justify-between gap-4">
            <div className="flex-1">
              <div className="text-sm font-medium text-ui-text-primary">Default Chart View</div>
              <div className="text-xs text-ui-text-secondary mt-1">
                Choose your preferred view type for all charts that support both options
              </div>
            </div>
            <div className="sm:w-96">
              <select
                className="h-10 px-3 mt-4 sm:mt-0 rounded-md text-sm w-full border-1 border-[#8A8A8A] text-ui-text-primary focus:outline-hidden"
                value={settings?.viewMode || "card"}
                onChange={e => {
                  const newMode = e.target.value as "card" | "table";
                  updateSettings?.({ viewMode: newMode });
                }}
              >
                <option value="card">Cards View</option>
                <option value="table">Table View</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
