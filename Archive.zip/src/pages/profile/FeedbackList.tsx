import { useState, useEffect, useCallback, useRef } from "react";
import { Trash2, ChevronDown, ChevronUp, X, Download, ZoomIn, Filter } from "lucide-react";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/atoms/Table";
import { Button } from "@/components/atoms/Button";
import { Pagination } from "@/components/atoms/Pagination";
import { useFeedbackQuery, useFeedbackFiltersQuery } from "@/hooks/queries/useFeedbackQuery";
import { useUpdateFeedbackMutation, useDeleteFeedbackMutation } from "@/hooks/queries/useFeedbackMutations";
import { Feedback, FeedbackStatus, FeedbackFilterParams } from "@/services/feedbackService";

const DEFAULT_PAGE_SIZE = 10;

const STATUS_LABELS: Record<FeedbackStatus, string> = {
  open: "Open",
  in_progress: "In Progress",
  resolved: "Resolved",
  closed: "Closed",
};

const STATUS_STYLES: Record<FeedbackStatus, string> = {
  open: "bg-blue-100 text-blue-700",
  in_progress: "bg-yellow-100 text-yellow-700",
  resolved: "bg-green-100 text-green-700",
  closed: "bg-gray-100 text-gray-600",
};

const NEXT_STATUS: Record<FeedbackStatus, FeedbackStatus | null> = {
  open: "in_progress",
  in_progress: "resolved",
  resolved: "closed",
  closed: null,
};

const formatDate = (iso: string) =>
  new Date(iso).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

/**
 * Slugs and route keys (hyphens/underscores) → readable labels: capitalize each word, preserve existing casing after the first letter.
 */
function formatFeedbackContextLabel(raw: string | null | undefined): string {
  if (raw == null || !String(raw).trim()) return "";
  return String(raw)
    .trim()
    .replace(/[-_]+/g, " ")
    .split(/\s+/)
    .filter(Boolean)
    .map(word => (word.length === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)))
    .join(" ");
}

function ImageLightbox({ src, alt, onClose }: { src: string; alt: string; onClose: () => void }) {
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    },
    [onClose]
  );

  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [handleKeyDown]);

  const handleDownload = async () => {
    try {
      const res = await fetch(src);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `feedback-screenshot-${Date.now()}.png`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      window.open(src, "_blank");
    }
  };

  return (
    <div className="fixed inset-0 z-9999 flex items-center justify-center bg-black/70 backdrop-blur-xs" onClick={onClose}>
      <div className="absolute top-4 right-4 flex items-center gap-2">
        <button
          onClick={e => {
            e.stopPropagation();
            handleDownload();
          }}
          className="rounded-full bg-white/10 p-2 text-white hover:bg-white/25 transition-colors"
          aria-label="Download screenshot"
        >
          <Download className="h-5 w-5" />
        </button>
        <button
          onClick={onClose}
          className="rounded-full bg-white/10 p-2 text-white hover:bg-white/25 transition-colors"
          aria-label="Close preview"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <img
        src={src}
        alt={alt}
        onClick={e => e.stopPropagation()}
        className="max-h-[90vh] max-w-[90vw] rounded-lg object-contain shadow-2xl"
      />
    </div>
  );
}

function FeedbackRow({ item }: { item: Feedback }) {
  const [expanded, setExpanded] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const updateMutation = useUpdateFeedbackMutation();
  const deleteMutation = useDeleteFeedbackMutation();

  const nextStatus = NEXT_STATUS[item.status];

  const handleAdvanceStatus = () => {
    if (!nextStatus) return;
    updateMutation.mutate({ id: item.id, data: { status: nextStatus } });
  };

  const handleDelete = () => {
    if (!window.confirm("Delete this feedback item?")) return;
    deleteMutation.mutate(item.id);
  };

  return (
    <>
      <TableRow className="cursor-pointer hover:bg-ui-background-muted/50" onClick={() => setExpanded(prev => !prev)}>
        <TableCell className="text-ui-text-secondary text-xs">{item.id}</TableCell>
        <TableCell className="max-w-[200px] truncate text-sm">{item.feedback}</TableCell>
        <TableCell className="text-xs text-ui-text-primary">{formatFeedbackContextLabel(item.module) || "—"}</TableCell>
        <TableCell className="text-xs text-ui-text-primary">{formatFeedbackContextLabel(item.page) || "—"}</TableCell>
        <TableCell className="text-xs text-ui-text-secondary">
          {item.user.first_name} {item.user.last_name}
        </TableCell>
        <TableCell>
          <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${STATUS_STYLES[item.status]}`}>
            {STATUS_LABELS[item.status]}
          </span>
        </TableCell>
        <TableCell className="text-xs text-ui-text-secondary whitespace-nowrap">{formatDate(item.created_at)}</TableCell>
        <TableCell onClick={e => e.stopPropagation()}>
          <div className="flex items-center gap-1">
            {nextStatus && (
              <Button
                variant="outline"
                size="sm"
                className="text-xs h-7 px-2 whitespace-nowrap"
                isLoading={updateMutation.isPending}
                onClick={handleAdvanceStatus}
              >
                → {STATUS_LABELS[nextStatus]}
              </Button>
            )}
            <button
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
              className="p-1 rounded text-ui-text-secondary hover:text-status-error-main transition-colors disabled:opacity-50"
              aria-label="Delete feedback"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
            <span className="text-ui-text-secondary">
              {expanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            </span>
          </div>
        </TableCell>
      </TableRow>

      {expanded && (
        <TableRow>
          <TableCell colSpan={8} className="bg-ui-background-muted/30 px-6 pb-4 pt-2">
            <div className="space-y-3">
              <div>
                <p className="text-xs font-medium text-ui-text-secondary mb-1">Full feedback</p>
                <p className="text-sm text-ui-text-primary whitespace-pre-wrap">{item.feedback}</p>
              </div>
              {item.subtab && (
                <div>
                  <p className="text-xs font-medium text-ui-text-secondary mb-1">Subtab</p>
                  <p className="text-sm text-ui-text-primary">{formatFeedbackContextLabel(item.subtab) || item.subtab}</p>
                </div>
              )}
              {item.screenshot && (
                <div>
                  <p className="text-xs font-medium text-ui-text-secondary mb-1">Screenshot</p>
                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      setLightboxOpen(true);
                    }}
                    className="group relative cursor-zoom-in"
                  >
                    <img
                      src={item.screenshot}
                      alt="Feedback screenshot"
                      className="max-h-64 rounded-md border border-ui-border-primary object-contain transition-opacity group-hover:opacity-80"
                    />
                    <span className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="rounded-full bg-black/50 p-2 text-white">
                        <ZoomIn className="h-5 w-5" />
                      </span>
                    </span>
                  </button>
                </div>
              )}
              {lightboxOpen && item.screenshot && (
                <ImageLightbox src={item.screenshot} alt="Feedback screenshot" onClose={() => setLightboxOpen(false)} />
              )}
            </div>
          </TableCell>
        </TableRow>
      )}
    </>
  );
}

function FilterDropdown({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const selectedLabel = options.find(o => o.value === value)?.label ?? "All";

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(prev => !prev)}
        className="flex items-center gap-1.5 h-8 px-3 text-xs font-medium rounded-md border border-ui-border-primary bg-white hover:border-gray-400 transition-colors whitespace-nowrap"
      >
        <span className="text-ui-text-secondary">{label}:</span>
        <span className="text-ui-text-primary">{selectedLabel}</span>
        <ChevronDown className={`h-3.5 w-3.5 text-ui-text-secondary transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="absolute top-full left-0 mt-1 min-w-[160px] bg-white border border-gray-300 rounded-md shadow-lg z-30 py-1 max-h-60 overflow-y-auto">
          {options.map(opt => (
            <button
              key={opt.value}
              onClick={() => {
                onChange(opt.value);
                setOpen(false);
              }}
              className={`block w-full px-3 py-1.5 text-left text-xs hover:bg-ui-background-muted ${
                value === opt.value ? "bg-ui-background-muted font-semibold text-ui-text-primary" : "text-ui-text-secondary"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function FeedbackFilterBar({
  filters,
  onChange,
}: {
  filters: FeedbackFilterParams;
  onChange: (filters: FeedbackFilterParams) => void;
}) {
  const { data: filterOptions, isLoading } = useFeedbackFiltersQuery();

  if (isLoading || !filterOptions) return null;

  const hasActiveFilters = Object.values(filters).some(v => !!v);

  const statusOptions = [
    { value: "", label: "All" },
    ...filterOptions.statuses.map(s => ({
      value: s,
      label: STATUS_LABELS[s as FeedbackStatus] ?? s,
    })),
  ];

  const moduleOptions = [
    { value: "", label: "All" },
    ...filterOptions.modules.map(m => ({ value: m, label: formatFeedbackContextLabel(m) || m })),
  ];

  const pageOptions = [
    { value: "", label: "All" },
    ...filterOptions.pages.map(p => ({ value: p, label: formatFeedbackContextLabel(p) || p })),
  ];

  const userOptions = [
    { value: "", label: "All" },
    ...filterOptions.users.map(u => ({
      value: u.id,
      label: `${u.first_name} ${u.last_name}`,
    })),
  ];

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <Filter className="h-4 w-4 text-ui-text-secondary shrink-0" />
      <FilterDropdown
        label="Status"
        value={filters.status ?? ""}
        options={statusOptions}
        onChange={v => onChange({ ...filters, status: v || undefined })}
      />
      <FilterDropdown
        label="Module"
        value={filters.module ?? ""}
        options={moduleOptions}
        onChange={v => onChange({ ...filters, module: v || undefined })}
      />
      <FilterDropdown
        label="Page"
        value={filters.page ?? ""}
        options={pageOptions}
        onChange={v => onChange({ ...filters, page: v || undefined })}
      />
      <FilterDropdown
        label="User"
        value={filters.user ?? ""}
        options={userOptions}
        onChange={v => onChange({ ...filters, user: v || undefined })}
      />
      {hasActiveFilters && (
        <button
          onClick={() => onChange({})}
          className="flex items-center gap-1 h-8 px-2 text-xs text-ui-text-secondary hover:text-status-error-main transition-colors"
        >
          <X className="h-3.5 w-3.5" />
          Clear
        </button>
      )}
    </div>
  );
}

export function FeedbackList() {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [filters, setFilters] = useState<FeedbackFilterParams>({});

  const { data, isLoading, error } = useFeedbackQuery(currentPage, pageSize, filters);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handlePageSizeChange = (size: number) => {
    setPageSize(size);
    setCurrentPage(1);
  };

  const handleFilterChange = (newFilters: FeedbackFilterParams) => {
    setFilters(newFilters);
    setCurrentPage(1);
  };

  if (error) {
    return (
      <div className="flex items-center justify-center py-10">
        <p className="text-status-error-main text-sm">Failed to load feedback.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <FeedbackFilterBar filters={filters} onChange={handleFilterChange} />

      {isLoading && !data ? (
        <div className="flex items-center justify-center py-10">
          <p className="text-ui-text-secondary text-sm">Loading feedback...</p>
        </div>
      ) : !data?.results.length ? (
        <div className="flex items-center justify-center py-10">
          <p className="text-ui-text-secondary text-sm">No feedback submitted yet.</p>
        </div>
      ) : (
        <>
          <div className="overflow-x-auto border border-ui-border-primary rounded-md">
            <Table>
              <TableHeader className="bg-ui-background-secondary">
                <TableRow>
                  <TableHead className="text-xs font-semibold text-ui-text-secondary w-10">#</TableHead>
                  <TableHead className="text-xs font-semibold text-ui-text-secondary">Feedback</TableHead>
                  <TableHead className="text-xs font-semibold text-ui-text-secondary">Module</TableHead>
                  <TableHead className="text-xs font-semibold text-ui-text-secondary">Page</TableHead>
                  <TableHead className="text-xs font-semibold text-ui-text-secondary">User</TableHead>
                  <TableHead className="text-xs font-semibold text-ui-text-secondary">Status</TableHead>
                  <TableHead className="text-xs font-semibold text-ui-text-secondary whitespace-nowrap">Submitted</TableHead>
                  <TableHead className="text-xs font-semibold text-ui-text-secondary">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.results.map(item => (
                  <FeedbackRow key={item.id} item={item} />
                ))}
              </TableBody>
            </Table>
          </div>

          <Pagination
            currentPage={currentPage}
            pageSize={pageSize}
            total={data.total}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            itemName="feedback items"
            isLoading={isLoading}
          />
        </>
      )}
    </div>
  );
}
