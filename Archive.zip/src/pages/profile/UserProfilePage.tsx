import React, { useState } from "react";
import { CircleUserRound, Pencil } from "lucide-react";
import { getAaaSProfileUrl } from "@/lib/authBranding";
import { Card, CardContent, CardHeader } from "@/components/atoms/Card";
import { Button } from "@/components/atoms/Button";
import { useAuth } from "@/contexts/AuthContext";
import { AuthMeProfile, useProfile } from "@/hooks/useProfile";
import { Header } from "@/components/organisms";
import { Footer } from "@/components";
import { GeneralInfo } from "@/pages/profile/GeneralInfo";
import { ManageThresholds } from "./ManageThresholds";
import { ViewPreferences } from "./ViewPreferences";
import { DataFreshnessTable } from "@/components/molecules/DataFreshnessTable";
import { FeedbackList } from "@/pages/profile/FeedbackList";

const TabIds = {
  GENERAL_INFORMATION: "general-information",
  MANAGE_THRESHOLDS: "manage-thresholds",
  VIEW_PREFERENCES: "view-preferences",
  DATA_FRESHNESS: "data-freshness",
  FEEDBACK: "feedback",
};

type Tab = {
  id: (typeof TabIds)[keyof typeof TabIds];
  label: string;
};

const tabs: Tab[] = [
  {
    id: TabIds.GENERAL_INFORMATION,
    label: "General Information",
  },
  {
    id: TabIds.MANAGE_THRESHOLDS,
    label: "Manage Thresholds",
  },
  {
    id: TabIds.VIEW_PREFERENCES,
    label: "View Preferences",
  },
  {
    id: TabIds.DATA_FRESHNESS,
    label: "Data Freshness",
  },
  {
    id: TabIds.FEEDBACK,
    label: "Feedback",
  },
];

const SignOutIcon = () => {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M15.1562 14.2211V15.1586C15.1562 15.4072 15.0575 15.6457 14.8817 15.8215C14.7058 15.9973 14.4674 16.0961 14.2188 16.0961H11.4062M11.4062 4.84609H14.2188C14.4674 4.84609 14.7058 4.94486 14.8817 5.12068C15.0575 5.29649 15.1562 5.53495 15.1562 5.78359V6.72109M15.1562 8.59546L17.0312 10.4705M17.0312 10.4705H11.875M17.0312 10.4705L15.1569 12.3455M7.10999 9.76794C7.06353 9.76794 7.01811 9.78176 6.97952 9.80762C6.94092 9.83349 6.91089 9.87024 6.89322 9.91321C6.87556 9.95619 6.87107 10.0034 6.88031 10.049C6.88956 10.0945 6.91213 10.1363 6.94516 10.1689C6.97819 10.2016 7.02019 10.2237 7.06581 10.2325C7.11144 10.2412 7.15864 10.2362 7.20142 10.2181C7.2442 10.2 7.28063 10.1696 7.30608 10.1307C7.33153 10.0918 7.34486 10.0463 7.34436 9.99982C7.34444 9.96902 7.33844 9.9385 7.32669 9.91003C7.31494 9.88156 7.29768 9.85569 7.2759 9.83391C7.25412 9.81213 7.22825 9.79486 7.19978 9.78312C7.1713 9.77137 7.14079 9.76536 7.10999 9.76544M8.99625 17.0286L3.37125 16.2248C3.25959 16.2089 3.15742 16.1532 3.08349 16.068C3.00956 15.9829 2.96882 15.8739 2.96875 15.7611V4.82796C2.96866 4.72062 3.00542 4.6165 3.07288 4.533C3.14034 4.4495 3.23441 4.39168 3.33938 4.36921L8.96438 2.98109C9.03275 2.96645 9.10352 2.9673 9.17152 2.98356C9.23953 2.99982 9.30303 3.03109 9.35738 3.07507C9.41173 3.11906 9.45555 3.17464 9.48564 3.23776C9.51572 3.30087 9.53131 3.36992 9.53125 3.43984V16.5648C9.53121 16.632 9.51675 16.6983 9.48885 16.7594C9.46095 16.8204 9.42026 16.8748 9.36953 16.9187C9.3188 16.9627 9.25923 16.9953 9.19483 17.0142C9.13043 17.0332 9.06271 17.0381 8.99625 17.0286Z"
        stroke="#E22F00"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

const ProfilePageSkeleton = () => {
  return (
    <Card className="rounded-lg border-[#E2E8F0] w-full mb-4 h-fit">
      <CardHeader className="p-4">
        <div className="bg-[#F7F6FF] w-full">
          <div className="flex gap-4 p-4">
            <div className="w-28 h-28 bg-gray-200 rounded-md animate-pulse" />
            <div className="flex flex-col gap-1 py-1 flex-1">
              <div className="h-8 bg-gray-200 rounded animate-pulse w-48 mb-2" />
              <div className="h-4 bg-gray-200 rounded animate-pulse w-32 mb-4" />
              <div className="h-8 bg-gray-200 rounded animate-pulse w-40" />
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-2 h-fit">
        <div className="w-full">
          <div className="relative flex border-b border-gray-200">
            {[1, 2, 3].map(item => (
              <div key={item} className="px-4 py-3">
                <div className="h-5 bg-gray-200 rounded animate-pulse w-32" />
              </div>
            ))}
          </div>
          {/* Tab content skeleton */}
          <div className="mt-4 space-y-4">
            <div className="h-6 bg-gray-200 rounded animate-pulse w-40" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[1, 2, 3, 4, 5, 6, 7].map(item => (
                <div key={item} className="flex gap-2">
                  <div className="w-5 h-5 bg-gray-200 rounded animate-pulse" />
                  <div className="flex-1">
                    <div className="h-3 bg-gray-200 rounded animate-pulse w-20 mb-2" />
                    <div className="h-4 bg-gray-200 rounded animate-pulse w-32" />
                  </div>
                </div>
              ))}
            </div>
            <div className="h-6 bg-gray-200 rounded animate-pulse w-48 mt-6" />
            <div className="flex gap-4">
              <div className="w-full h-[200px] bg-gray-200 rounded-md animate-pulse" />
              <div className="flex flex-col gap-2">
                <div className="h-4 bg-gray-200 rounded animate-pulse w-48" />
                <div className="h-4 bg-gray-200 rounded animate-pulse w-32" />
                <div className="h-4 bg-gray-200 rounded animate-pulse w-24" />
                <div className="h-4 bg-gray-200 rounded animate-pulse w-20" />
                <div className="h-8 bg-gray-200 rounded animate-pulse w-32 mt-4" />
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const UserProfilePage: React.FC = () => {
  const { logout } = useAuth();
  const { profile, isLoading } = useProfile();
  const [activeTab, setActiveTab] = useState(tabs[0].id);
  const aaaSProfileUrl = getAaaSProfileUrl();

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <div className="w-full h-[100px] bg-[url('/src/assets/images/banner.svg')] bg-no-repeat bg-cover bg-center">
        <div className="h-full max-w-(--breakpoint-2xl) mx-auto flex items-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white">Account Settings</h1>
        </div>
      </div>
      <div className="flex-1 w-full max-w-(--breakpoint-2xl) mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center my-3">
          <p>
            Welcome to your profile! Here you can view your account details, manage your thresholds, and customize your
            preferences to make the platform work best for you.
          </p>
          <Button
            variant="ghost"
            size="sm"
            className="text-status-error-main flex shrink-0 items-center gap-1 pr-0 hover:bg-transparent"
            onClick={logout}
          >
            <SignOutIcon />
            Sign Out
          </Button>
        </div>
        <div className="flex flex-col lg:flex-row gap-4 lg:gap-8">
          {isLoading ? (
            <ProfilePageSkeleton />
          ) : (
            <Card className="w-full mb-4 h-fit">
              <CardHeader className="p-4">
                <div className="bg-[#F7F6FF] w-full">
                  <div className="flex gap-4 p-4">
                    <div className="w-28 h-28 flex items-center justify-center">
                      {profile?.photoDataUrl ? (
                        <img src={profile.photoDataUrl} alt="User" className="w-full h-full rounded-full object-cover" />
                      ) : (
                        <div className="w-full h-full rounded-full bg-gray-100 flex items-center justify-center">
                          <CircleUserRound className="w-20 h-20 text-gray-600" />
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col gap-1 py-1 my-auto">
                      <div className="flex items-center gap-2">
                        <p className="text-2xl font-semibold text-ui-text-primary">
                          {profile?.givenName} {profile?.surname}
                        </p>
                        {aaaSProfileUrl && (
                          <a
                            href={aaaSProfileUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center text-brand-primary-main hover:text-brand-primary-dark transition-colors"
                            aria-label="Edit profile in SAP CDC"
                            title="Edit profile in SAP CDC"
                          >
                            <Pencil className="w-5 h-5" />
                          </a>
                        )}
                      </div>
                      <p className="text-sm text-ui-text-secondary">
                        {profile?.jobTitle} • {profile?.department}
                      </p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4 pt-2 h-fit">
                <div className="w-full">
                  <div role="tablist" aria-label="Tabs" className="relative flex border-b border-gray-200">
                    {tabs.map(tab => {
                      const isActive = activeTab === tab.id;
                      return (
                        <button
                          key={tab.id}
                          role="tab"
                          aria-selected={isActive}
                          aria-controls={`panel-${tab.id}`}
                          id={`tab-${tab.id}`}
                          onClick={() => setActiveTab(tab.id)}
                          className={`
                relative px-4 py-3 text-sm font-medium
                focus:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main
                transition-colors
                ${isActive ? "font-semibold text-ui-text-primary" : "text-ui-text-secondary hover:text-ui-text-primary"}
              `}
                        >
                          {tab.label}
                          <span
                            aria-hidden
                            className={`
                  absolute inset-x-0 bottom-0 h-0.5
                  bg-brand-primary-main
                  ${isActive ? "scale-x-100" : "scale-x-0"}
                `}
                          />
                        </button>
                      );
                    })}
                  </div>
                  <div className="mt-4 h-fit">
                    {tabs.map(tab => (
                      <div
                        key={tab.id}
                        role="tabpanel"
                        id={`panel-${tab.id}`}
                        aria-labelledby={`tab-${tab.id}`}
                        hidden={activeTab !== tab.id}
                        className="focus:outline-hidden"
                      >
                        {tab.id === TabIds.GENERAL_INFORMATION && <GeneralInfo profile={profile as AuthMeProfile} />}
                        {tab.id === TabIds.MANAGE_THRESHOLDS && <ManageThresholds />}
                        {tab.id === TabIds.VIEW_PREFERENCES && <ViewPreferences />}
                        {tab.id === TabIds.DATA_FRESHNESS && <DataFreshnessTable />}
                        {tab.id === TabIds.FEEDBACK && <FeedbackList />}
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default UserProfilePage;
