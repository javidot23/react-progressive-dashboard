import "@testing-library/jest-dom";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { BrowserRouter } from "react-router-dom";
import ProductSubstitutionAnalysis from '@/pages/ProductSubstitutionAnalysis';

const mockNavigate = jest.fn();
const mockLocation: {
  search: string;
  pathname: string;
  state?: any;
} = {
  search: '?material_id=79&issue_id=123',
  pathname: '/react/substitution-analysis',
  state: null,
};

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useLocation: () => mockLocation,
  useNavigate: () => mockNavigate,
}));

const mockMaterialSubstitutes = [
  {
    id: 235,
    rank: 3,
    substituteName: "Person Injection",
    substituteId: 29,
    substituteMatNbr: "10244066",
    riskRating: 0.82,
    drivingRisk: "Cost",
    dollarsAtRisk: 3323.48,
    marketShare: 0.15,
    saleableQtyOnHand: 6971.0,
    forecastQty7day: 1499.0,
    costPerUnit: 1.85,
    vendorId: 36,
    vendorNbr: "V36",
    materialFormularies: [],
    availablePlantsCount: 1,
    materialName: "State Inhaler",
    omits: 0,
  },
  {
    id: 233,
    rank: 1,
    substituteName: "Pretty Cream",
    substituteId: 47,
    substituteMatNbr: "10000030",
    riskRating: 0.53,
    drivingRisk: "Compliance",
    dollarsAtRisk: 73511.57,
    marketShare: 0.25,
    saleableQtyOnHand: 7821.0,
    forecastQty7day: 328.0,
    costPerUnit: 2.45,
    vendorId: 30,
    vendorNbr: "V30",
    materialFormularies: [
      { id: 1, name: "Formulary A" },
      { id: 2, name: "Formulary B" }
    ],
    availablePlantsCount: 2,
    materialName: "State Inhaler",
    omits: 0,
  },
];

const mockLoadMoreMaterialSubstitutes = jest.fn();

const defaultMaterialSubstitutesQueryResult = {
  materialSubstitutes: mockMaterialSubstitutes,
  totalCount: 2,
  hasMore: false,
  isLoading: false,
  isFetchingNextPage: false,
  error: null as string | null,
  fetchNextPage: mockLoadMoreMaterialSubstitutes,
  refetch: jest.fn(),
};

type MaterialSubstitutesQueryParams = {
  materialId: number | null;
  additionalParams?: string;
  enabled?: boolean;
};

const mockUseMaterialSubstitutesInfiniteQuery = jest.fn(
  (_params?: MaterialSubstitutesQueryParams) => defaultMaterialSubstitutesQueryResult
);

jest.mock('@/hooks/queries/useMaterialSubstitutesInfiniteQuery', () => ({
  useMaterialSubstitutesInfiniteQuery: (params: MaterialSubstitutesQueryParams) =>
    mockUseMaterialSubstitutesInfiniteQuery(params),
}));

const mockSubstituteDetails = {
  material: {
    id: 79,
    mat_nbr: 'MAT-79',
    name: 'State Inhaler',
    risk_rating: 0.5,
    driving_risk: 'Cost',
    dollars_at_risk: 12345.67,
    saleable_qty_on_hand: 1000,
    forecast_qty_7day: 100,
    cost_per_unit: 2.5,
    market_share: 25,
    vendor: { id: 1, vendor_nbr: 'V-1', name: 'Test Vendor' },
  },
  material_formularies: [],
  available_plants_count: 10,
};

const mockUseMaterialSubstituteDetailsQuery = jest.fn(() => ({
  details: mockSubstituteDetails,
  isLoading: false,
  error: null,
  refetch: jest.fn(),
}));

jest.mock('@/hooks/queries/useMaterialSubstituteDetailsQuery', () => ({
  useMaterialSubstituteDetailsQuery: () => mockUseMaterialSubstituteDetailsQuery(),
}));

jest.mock('@/components/templates/DashboardLayout', () => ({
  __esModule: true,
  default: ({ children }: any) => (
    <div data-testid="dashboard-layout">{children}</div>
  ),
}));

jest.mock('@/components/molecules/LazyLoader', () => ({
  __esModule: true,
  default: () => <div data-testid="lazy-loader">Loading...</div>,
}));

jest.mock('@/components/molecules/KeepInMindModal', () => ({
  KeepInMindModal: ({ isOpen, onClose, onContinue, isSubmitting }: any) => {
    if (!isOpen) return null;
    return (
      <div data-testid="keep-in-mind-modal">
        <button data-testid="keep-in-mind-close" onClick={onClose}>Close</button>
        <button data-testid="keep-in-mind-continue" onClick={onContinue} disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Continue'}
        </button>
      </div>
    );
  },
}));

jest.mock('@/services/actionService', () => ({
  createAction: jest.fn(),
}));

jest.mock('@/lib/apiServices', () => ({
  ...jest.requireActual('@/lib/apiServices'),
  materialFormularyService: {
    getUniqueMaterialFormulary: jest.fn(),
  },
  demandForecastService: {
    getInventoryOnEachPlant: jest.fn(),
  },
  materialSubstitutesService: {
    getMaterialSubstitutes: jest.fn(),
    getMaterialSubstituteDetails: jest.fn(),
  },
}));

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <BrowserRouter>{children}</BrowserRouter>
);

describe('ProductSubstitutionAnalysis', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockNavigate.mockClear();
    process.env.VITE_API_BASE_URL = 'http://test-api.com';
    // Reset mockLocation to default
    mockLocation.search = '?material_id=79&issue_id=123';
    mockLocation.pathname = '/react/substitution-analysis';
    mockLocation.state = null;

    mockUseMaterialSubstitutesInfiniteQuery.mockImplementation(
      () => defaultMaterialSubstitutesQueryResult
    );
    mockUseMaterialSubstituteDetailsQuery.mockImplementation(() => ({
      details: mockSubstituteDetails,
      isLoading: false,
      error: null,
      refetch: jest.fn(),
    }));
    mockLoadMoreMaterialSubstitutes.mockClear();
  });

  it('renders the page layout correctly', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    expect(screen.getByTestId('dashboard-layout')).toBeInTheDocument();
    expect(screen.getByText('At Risk Material')).toBeInTheDocument();
    // Check for primary risk badge
    expect(screen.getByText('Driving Risk:')).toBeInTheDocument();
  });

  it('renders substitute cards when data is available', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    expect(screen.getByText('Person Injection')).toBeInTheDocument();
    expect(screen.getByText('Pretty Cream')).toBeInTheDocument();
  });

  it('displays correct status based on rank', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    expect(screen.getByText('Best Match')).toBeInTheDocument();

    expect(screen.getByText('Alternative 3')).toBeInTheDocument();
  });

  it('shows contract navigation arrows only when formularies exist', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );
  });

  it('displays dynamic formularies count in pagination', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    // Contract pagination shows "Contract (1 of 2)" format
    expect(screen.getByText(/Contract \(1 of 2\)/)).toBeInTheDocument();

    expect(screen.queryByText(/1 of 0/)).not.toBeInTheDocument();
  });

  it('calculates inventory days correctly', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    expect(screen.getByText('33 days')).toBeInTheDocument();
    expect(screen.getByText('167 days')).toBeInTheDocument();
  });

  it('displays market share as percentage', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    // Market share displays as "-%", "0%" or percentage values
    const marketShareElements = screen.getAllByText(/-%|0%|\d+%/);
    expect(marketShareElements.length).toBeGreaterThan(0);
  });

  it('displays risk exposure in currency format', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    // Multiple elements may display the same risk value (KPI section + card)
    const riskElements3K = screen.getAllByText('$3,323.48');
    expect(riskElements3K.length).toBeGreaterThan(0);
    const riskElements74K = screen.getAllByText('$73,511.57');
    expect(riskElements74K.length).toBeGreaterThan(0);
  });

  it('displays cost per unit correctly', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    // Multiple elements may display the same cost value (KPI section + card)
    const costElements185 = screen.getAllByText('$1.85');
    expect(costElements185.length).toBeGreaterThan(0);
    const costElements245 = screen.getAllByText('$2.45');
    expect(costElements245.length).toBeGreaterThan(0);
  });

  it('displays available plants count', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    expect(screen.getByText('(1) Distribution Centers')).toBeInTheDocument();
    expect(screen.getByText('(2) Distribution Centers')).toBeInTheDocument();
  });

  it('handles navigation buttons correctly', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    const cancelButton = screen.getByText('Cancel');
    const doneButton = screen.getByText('Done');

    fireEvent.click(cancelButton);
    expect(mockNavigate).toHaveBeenCalledWith('/react');

    fireEvent.click(doneButton);
    expect(mockNavigate).toHaveBeenCalledWith('/react');
  });

  it('shows warning when no materialId is provided', () => {
    const mockLocationNoMaterial = {
      search: '',
      pathname: '/react/substitution-analysis',
    };

    jest.doMock('react-router-dom', () => ({
      ...jest.requireActual('react-router-dom'),
      useLocation: () => mockLocationNoMaterial,
      useNavigate: () => mockNavigate,
    }));

    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    // Page still renders with At Risk Material section
    expect(screen.getByText('At Risk Material')).toBeInTheDocument();
  });

  it('handles loading state correctly', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    expect(screen.getByText('At Risk Material')).toBeInTheDocument();
  });

  it('displays substitutes when data is available', async () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    await waitFor(() => {
      expect(screen.getByText('State Inhaler')).toBeInTheDocument();
    });
    expect(screen.getByText('Person Injection')).toBeInTheDocument();
    expect(screen.getByText('Pretty Cream')).toBeInTheDocument();
  });

  it('renders contract display correctly based on formularies', () => {
    render(
      <TestWrapper>
        <ProductSubstitutionAnalysis />
      </TestWrapper>
    );

    expect(screen.getAllByText('No Contract').length).toBeGreaterThan(0);
  });

  describe('View Switching', () => {
    it('starts with flow view by default', () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const flowViewButton = screen.getByText('Flow View');
      expect(flowViewButton).toBeInTheDocument();
    });

    it('can switch to table view', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const tableViewButton = screen.getByText('Table View');
      await userEvent.click(tableViewButton);

      expect(screen.getByText('Table View')).toBeInTheDocument();
    });

    it('can switch back to flow view', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const tableViewButton = screen.getByText('Table View');
      await userEvent.click(tableViewButton);

      const flowViewButton = screen.getByText('Flow View');
      await userEvent.click(flowViewButton);

      expect(screen.getByText('Flow View')).toBeInTheDocument();
    });
  });

  describe('Substitute Selection', () => {
    it('allows selecting a substitute in flow view', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const radioButtons = screen.getAllByRole('radio');
      if (radioButtons.length > 0) {
        await userEvent.click(radioButtons[0]);
        expect(radioButtons[0]).toBeChecked();
      }
    });

    it('allows selecting a substitute in table view', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const tableViewButton = screen.getByText('Table View');
      await userEvent.click(tableViewButton);

      await waitFor(() => {
        const radioButtons = screen.getAllByRole('radio');
        if (radioButtons.length > 0) {
          expect(radioButtons[0]).toBeInTheDocument();
        }
      });
    });

    it('enables Done button when a substitute is selected', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const doneButton = screen.getByText('Done');
      expect(doneButton).toBeDisabled();

      const radioButtons = screen.getAllByRole('radio');
      if (radioButtons.length > 0) {
        await userEvent.click(radioButtons[0]);
        await waitFor(() => {
          expect(doneButton).not.toBeDisabled();
        });
      }
    });

    it('disables Done button when no substitute is selected', () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const doneButton = screen.getByText('Done');
      expect(doneButton).toBeDisabled();
    });
  });

  describe('KeepInMindModal Integration', () => {
    it('opens KeepInMindModal when Done is clicked with selection', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const radioButtons = screen.getAllByRole('radio');
      if (radioButtons.length > 0) {
        await userEvent.click(radioButtons[0]);

        const doneButton = screen.getByText('Done');
        await userEvent.click(doneButton);

        await waitFor(() => {
          expect(screen.getByTestId('keep-in-mind-modal')).toBeInTheDocument();
        });
      }
    });

    it('closes KeepInMindModal when close button is clicked', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const radioButtons = screen.getAllByRole('radio');
      if (radioButtons.length > 0) {
        await userEvent.click(radioButtons[0]);

        const doneButton = screen.getByText('Done');
        await userEvent.click(doneButton);

        await waitFor(() => {
          expect(screen.getByTestId('keep-in-mind-modal')).toBeInTheDocument();
        });

        const closeButton = screen.getByTestId('keep-in-mind-close');
        await userEvent.click(closeButton);

        await waitFor(() => {
          expect(screen.queryByTestId('keep-in-mind-modal')).not.toBeInTheDocument();
        });
      }
    });

    it('shows submitting state in KeepInMindModal', async () => {
      const { createAction } = require('@/services/actionService');
      createAction.mockImplementation(() => new Promise(() => {}));

      mockLocation.search = '?material_id=79&issue_nbr=ISSUE-123&potential_action_nbr=PA-001';
      mockLocation.state = {
        materialId: 79,
        materialName: 'Test Material',
        materialData: { mat_nbr: 'MAT123' },
        issueNbr: 'ISSUE-123',
        potentialAction: { paction_nbr: 'PA-001' }
      };

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const radioButtons = screen.getAllByRole('radio');
      if (radioButtons.length > 0) {
        await userEvent.click(radioButtons[0]);

        const doneButton = screen.getByText('Done');
        await userEvent.click(doneButton);

        await waitFor(() => {
          expect(screen.getByTestId('keep-in-mind-modal')).toBeInTheDocument();
        });

        const continueButton = screen.getByTestId('keep-in-mind-continue');
        await userEvent.click(continueButton);

        await waitFor(() => {
          expect(screen.getByText('Submitting...')).toBeInTheDocument();
        });
      }
    });
  });

  describe('Action Creation Flow', () => {
    beforeEach(() => {
      const { createAction } = require('@/services/actionService');
      createAction.mockClear();
    });

    it('creates action when coming from React page with issue', async () => {
      const { createAction } = require('@/services/actionService');
      createAction.mockResolvedValue({ success: true });

      mockLocation.search = '?material_id=79&issue_nbr=ISSUE-123&potential_action_nbr=PA-001';
      mockLocation.state = {
        materialId: 79,
        materialName: 'Test Material',
        materialData: { mat_nbr: 'MAT123' },
        issueNbr: 'ISSUE-123',
        potentialAction: { paction_nbr: 'PA-001' }
      };

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const radioButtons = screen.getAllByRole('radio');
      if (radioButtons.length > 0) {
        await userEvent.click(radioButtons[0]);

        const doneButton = screen.getByText('Done');
        await userEvent.click(doneButton);

        await waitFor(() => {
          expect(screen.getByTestId('keep-in-mind-modal')).toBeInTheDocument();
        });

        const continueButton = screen.getByTestId('keep-in-mind-continue');
        await userEvent.click(continueButton);

        await waitFor(() => {
          expect(createAction).toHaveBeenCalledWith(
            expect.objectContaining({
              issue_nbr: 'ISSUE-123',
              mat_nbr: 'MAT123',
              potential_action_nbr: 'PA-001',
            })
          );
        });
      }
    });

    it('navigates back without creating action when not in action flow', async () => {
      mockLocation.search = '?material_id=79';
      mockLocation.state = null;

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const radioButtons = screen.getAllByRole('radio');
      if (radioButtons.length > 0) {
        await userEvent.click(radioButtons[0]);

        const doneButton = screen.getByText('Done');
        await userEvent.click(doneButton);

        await waitFor(() => {
          expect(screen.getByTestId('keep-in-mind-modal')).toBeInTheDocument();
        });

        const continueButton = screen.getByTestId('keep-in-mind-continue');
        await userEvent.click(continueButton);

        await waitFor(() => {
          expect(mockNavigate).toHaveBeenCalledWith('/react');
        });
      }
    });
  });

  describe('Contract Filtering', () => {
    beforeEach(() => {
      const { materialFormularyService } = require('@/lib/apiServices');
      materialFormularyService.getUniqueMaterialFormulary.mockResolvedValue({
        data: {
          success: true,
          data: [
            { id: 1, name: 'Contract A' },
            { id: 2, name: 'Contract B' }
          ]
        }
      });
    });

    it('loads contract options on mount', async () => {
      const { materialFormularyService } = require('@/lib/apiServices');

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(materialFormularyService.getUniqueMaterialFormulary).toHaveBeenCalled();
      });
    });

    it('displays contract dropdown', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      // Wait for contract options to load and select to be enabled
      await waitFor(() => {
        const contractSelect = screen.getByRole('combobox');
        expect(contractSelect).toBeInTheDocument();
        expect(contractSelect).not.toBeDisabled();
      }, { timeout: 3000 });

      // Verify the label exists (there may be multiple "Contract" texts, so use getAllByText)
      const contractLabels = screen.getAllByText('Contract');
      expect(contractLabels.length).toBeGreaterThan(0);
    });

    it('shows read-only No Contract instead of dropdown when API returns no options', async () => {
      const { materialFormularyService } = require('@/lib/apiServices');
      materialFormularyService.getUniqueMaterialFormulary.mockResolvedValue({
        data: {
          success: true,
          data: [],
        },
      });

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.queryByRole('combobox')).not.toBeInTheDocument();
      });

      expect(screen.getByText('Alternative Materials')).toBeInTheDocument();
      expect(screen.getAllByText('No Contract').length).toBeGreaterThan(0);
    });

    it('filters substitutes by selected contract', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      await waitFor(() => {
        const contractSelect = screen.getByRole('combobox');
        expect(contractSelect).toBeInTheDocument();
        expect(contractSelect).not.toBeDisabled();
      }, { timeout: 3000 });

      const contractSelect = screen.getByRole('combobox');
      await userEvent.selectOptions(contractSelect, 'Contract A');

      await waitFor(() => {
        const withFormulary = mockUseMaterialSubstitutesInfiniteQuery.mock.calls.some(
          ([arg]: [MaterialSubstitutesQueryParams?]) =>
            typeof arg?.additionalParams === 'string' &&
            arg.additionalParams.includes('material_formulary')
        );
        expect(withFormulary).toBe(true);
      });
    });
  });

  describe('Distribution Centers Modal', () => {
    it('opens distribution centers modal when button is clicked', async () => {
      const { demandForecastService } = require('@/lib/apiServices');
      demandForecastService.getInventoryOnEachPlant.mockResolvedValue({
        data: {
          success: true,
          data: [
            {
              plant: { node_id: 1, id: '001', name: 'Plant A' },
              unrestricted_qty_on_hand: 100,
              forecast_qty_7day: 10
            }
          ]
        }
      });

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      // Find the distribution centers button - it contains text like "(1) Distribution Centers"
      const distributionButtons = screen.getAllByText(/Distribution Centers/);
      if (distributionButtons.length > 0) {
        // Find the button element (not just the text)
        const button = distributionButtons[0].closest('button');
        if (button) {
          await userEvent.click(button);

          await waitFor(() => {
            expect(screen.getByText('Distribution Centers')).toBeInTheDocument();
          }, { timeout: 3000 });
        }
      }
    });
  });

  describe('URL Parameter Handling', () => {
    it('extracts material_id from URL parameters', () => {
      mockLocation.search = '?material_id=79';
      mockLocation.state = null;

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      expect(mockUseMaterialSubstitutesInfiniteQuery).toHaveBeenCalledWith(
        expect.objectContaining({ materialId: 79 })
      );
    });

    it('uses materialId from navigation state when URL param is missing', () => {
      mockLocation.search = '';
      mockLocation.state = {
        materialId: 79,
        materialName: 'Test Material'
      };

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      expect(mockUseMaterialSubstitutesInfiniteQuery).toHaveBeenCalledWith(
        expect.objectContaining({ materialId: 79 })
      );
    });

    it('extracts issue_nbr and potential_action_nbr from URL', () => {
      mockLocation.search = '?material_id=79&issue_nbr=ISSUE-123&potential_action_nbr=PA-001';
      mockLocation.state = null;

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      expect(screen.getByText('At Risk Material')).toBeInTheDocument();
    });
  });

  describe('Error Handling', () => {
    it('displays error message when materialSubstitutes fetch fails', () => {
      mockUseMaterialSubstitutesInfiniteQuery.mockReturnValue({
        ...defaultMaterialSubstitutesQueryResult,
        materialSubstitutes: [],
        error: 'Failed to load substitutes',
      });

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      expect(screen.getByText('Failed to load substitutes')).toBeInTheDocument();
    });

    it('handles action creation errors gracefully', async () => {
      const { createAction } = require('@/services/actionService');
      createAction.mockRejectedValue(new Error('Action creation failed'));

      mockLocation.search = '?material_id=79&issue_nbr=ISSUE-123&potential_action_nbr=PA-001';
      mockLocation.state = {
        materialId: 79,
        materialName: 'Test Material',
        materialData: { mat_nbr: 'MAT123' },
        issueNbr: 'ISSUE-123',
        potentialAction: { paction_nbr: 'PA-001' }
      };

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      // Wait for substitutes to render
      await waitFor(() => {
        const radioButtons = screen.getAllByRole('radio');
        expect(radioButtons.length).toBeGreaterThan(0);
      });

      const radioButtons = screen.getAllByRole('radio');
      if (radioButtons.length > 0) {
        await userEvent.click(radioButtons[0]);

        const doneButton = screen.getByText('Done');
        await userEvent.click(doneButton);

        await waitFor(() => {
          expect(screen.getByTestId('keep-in-mind-modal')).toBeInTheDocument();
        });

        const continueButton = screen.getByTestId('keep-in-mind-continue');
        await userEvent.click(continueButton);

        await waitFor(() => {
          expect(mockNavigate).toHaveBeenCalledWith('/react');
        });
      }
    });
  });

  describe('Empty States', () => {
    it('displays message when no substitutes are found', () => {
      mockUseMaterialSubstitutesInfiniteQuery.mockReturnValue({
        ...defaultMaterialSubstitutesQueryResult,
        materialSubstitutes: [],
        totalCount: 0,
      });

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      expect(screen.getByText(/No substitute materials found/i)).toBeInTheDocument();
    });
  });

  describe('Infinite Scroll / Load More', () => {
    it('loads more when scrolling near bottom', async () => {
      const mockLoadMore = jest.fn();
      mockUseMaterialSubstitutesInfiniteQuery.mockReturnValue({
        ...defaultMaterialSubstitutesQueryResult,
        hasMore: true,
        fetchNextPage: mockLoadMore,
      });

      const { container } = render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const scrollContainer = container.querySelector('[style*="maxHeight"]');
      if (scrollContainer) {
        Object.defineProperty(scrollContainer, 'scrollHeight', { value: 1000, writable: true });
        Object.defineProperty(scrollContainer, 'scrollTop', { value: 900, writable: true });
        Object.defineProperty(scrollContainer, 'clientHeight', { value: 100, writable: true });

        fireEvent.scroll(scrollContainer);

        await waitFor(() => {
          expect(mockLoadMore).toHaveBeenCalled();
        });
      }
    });

    it('shows loading indicator when loading more', () => {
      mockUseMaterialSubstitutesInfiniteQuery.mockReturnValue({
        ...defaultMaterialSubstitutesQueryResult,
        hasMore: true,
        isFetchingNextPage: true,
      });

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      expect(screen.getAllByTestId('lazy-loader').length).toBeGreaterThan(0);
    });
  });

  describe('Formulary Navigation', () => {
    it('displays formulary pagination when multiple formularies exist', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      // Check that the pagination text is shown (e.g., "Contract (1 of 2)")
      await waitFor(() => {
        expect(screen.getByText(/Contract \(1 of 2\)/)).toBeInTheDocument();
      });
    });

    it('displays formulary name in contract section', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      // Check for Contract or Formulary text
      await waitFor(() => {
        const contractElements = screen.getAllByText(/Contract|Formulary/);
        expect(contractElements.length).toBeGreaterThan(0);
      });
    });

    it('shows contract label for products without formularies', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getAllByText('No Contract').length).toBeGreaterThan(0);
      });
    });
  });

  describe('Material Data Display', () => {
    it('displays material name and Supplier Name', async () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText('State Inhaler')).toBeInTheDocument();
      });
    });

    it('displays KPI metrics', () => {
      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const valueAtRiskElements = screen.getAllByText(/Value at Risk/i);
      expect(valueAtRiskElements.length).toBeGreaterThan(0);
      // Market Share label is now "GCN Market Share"
      const marketShareElements = screen.getAllByText(/GCN Market Share|Market Share/i);
      expect(marketShareElements.length).toBeGreaterThan(0);
    });
  });

  describe('Data Sorting', () => {
    it('sorts substitutes by rank', () => {
      const unsortedSubstitutes = [
        { ...mockMaterialSubstitutes[0], rank: 3 },
        { ...mockMaterialSubstitutes[1], rank: 1 },
      ];

      mockUseMaterialSubstitutesInfiniteQuery.mockReturnValue({
        ...defaultMaterialSubstitutesQueryResult,
        materialSubstitutes: unsortedSubstitutes,
      });

      render(
        <TestWrapper>
          <ProductSubstitutionAnalysis />
        </TestWrapper>
      );

      const substituteNames = screen.getAllByText(/Person Injection|Pretty Cream/);
      expect(substituteNames.length).toBeGreaterThan(0);
    });
  });
});
