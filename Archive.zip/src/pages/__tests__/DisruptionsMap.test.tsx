import React from "react";
import { render, screen, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import DisruptionsMap from "@/pages/DisruptionsMap";
import { supplyChainEventsService } from "@/lib/apiServices";

const createTestQueryClient = () =>
  new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false },
    },
  });

/* -----------------------------
   Mocks
------------------------------ */

// Mock react-router
const mockSetSearchParams = jest.fn();
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useSearchParams: () => [{ get: () => null }, mockSetSearchParams],
}));

// Mock DashboardLayout
jest.mock("@/components/templates/DashboardLayout", () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode }) => <div data-testid="dashboard-layout">{children}</div>,
}));

// Mock Leaflet + React Leaflet
jest.mock("react-leaflet", () => ({
  MapContainer: ({ children }: { children: React.ReactNode }) => <div data-testid="map-container">{children}</div>,
  TileLayer: () => <div data-testid="tile-layer" />,
  GeoJSON: () => <div data-testid="geojson-layer" />,
  Marker: () => <div data-testid="marker" />,
  ZoomControl: () => <div data-testid="zoom-control" />,
  useMap: () => ({
    addLayer: jest.fn(),
    removeLayer: jest.fn(),
    eachLayer: jest.fn(),
    setView: jest.fn(),
    removeControl: jest.fn(),
    on: jest.fn(),
    off: jest.fn(),
  }),
  useMapEvents: () => ({}),
}));

jest.mock("leaflet", () => ({
  __esModule: true,
  divIcon: jest.fn(() => ({})),
  default: {
    marker: jest.fn(() => ({
      addTo: jest.fn(),
      bindPopup: jest.fn(),
      on: jest.fn(),
    })),
    geoJSON: jest.fn(() => ({
      addTo: jest.fn(),
    })),
    control: {
      zoom: jest.fn(() => ({
        addTo: jest.fn(),
      })),
    },
    divIcon: jest.fn(() => ({})),
    Marker: function () {},
  },
}));

// Mock UI components
jest.mock("@/components/atoms/Legend", () => ({
  __esModule: true,
  default: () => <div data-testid="legend">Legend</div>,
}));

jest.mock("@/components/atoms/InfoIcon", () => ({
  __esModule: true,
  default: () => <div data-testid="info-icon">Info</div>,
}));

// Mock API service
jest.mock("@/lib/apiServices", () => ({
  supplyChainEventsService: {
    getEventsWithLocation: jest.fn(),
    getSupplyChainEvent: jest.fn().mockResolvedValue({ data: { success: true, data: null } }),
  },
}));

jest.mock("@/hooks/useCountriesGeoJson", () => ({
  useCountriesGeoJson: () => ({
    data: { type: "FeatureCollection", features: [] },
    loading: false,
    error: null,
  }),
}));

/* -----------------------------
   Test Wrapper
------------------------------ */

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <QueryClientProvider client={createTestQueryClient()}>
    <BrowserRouter>{children}</BrowserRouter>
  </QueryClientProvider>
);

/* -----------------------------
   Tests
------------------------------ */

describe("DisruptionsMap", () => {
  const mockGetEvents = supplyChainEventsService.getEventsWithLocation as jest.Mock;

  const mockGetSupplyChainEvent = supplyChainEventsService.getSupplyChainEvent as jest.Mock;

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();

    mockGetEvents.mockResolvedValue({
      data: {
        success: true,
        data: {
          count: 0,
          results: [],
        },
      },
    });

    mockGetSupplyChainEvent.mockResolvedValue({
      data: { success: true, data: null },
    });
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  it("renders without crashing", async () => {
    await waitFor(() =>
      expect(() =>
        render(
          <TestWrapper>
            <DisruptionsMap />
          </TestWrapper>
        )
      ).not.toThrow()
    );
  });

  it("renders main layout and map components", async () => {
    render(
      <TestWrapper>
        <DisruptionsMap />
      </TestWrapper>
    );

    expect(await screen.findByTestId("dashboard-layout")).toBeInTheDocument();
    expect(await screen.findByTestId("map-container")).toBeInTheDocument();
    expect(screen.getByTestId("legend")).toBeInTheDocument();
    expect(screen.getByTestId("info-icon")).toBeInTheDocument();
  });

  it("renders page title and subtitle text", async () => {
    render(
      <TestWrapper>
        <DisruptionsMap />
      </TestWrapper>
    );

    expect(await screen.findByText("Location-Based Risk Events")).toBeInTheDocument();

    expect(screen.getAllByText(/This map only displays events with geographic coordinates/i)[0]).toBeInTheDocument();
  });

  it("shows loading state while fetching events", async () => {
    let resolvePromise: any;

    mockGetEvents.mockReturnValue(
      new Promise(resolve => {
        resolvePromise = resolve;
      })
    );

    render(
      <TestWrapper>
        <DisruptionsMap />
      </TestWrapper>
    );

    expect(await screen.findByTestId("map-loading")).toBeInTheDocument();

    resolvePromise({
      data: {
        success: true,
        data: {
          count: 0,
          results: [],
        },
      },
    });

    await waitFor(() => {
      expect(screen.queryByTestId("map-loading")).not.toBeInTheDocument();
    });
  });

  it("handles successful events fetch", async () => {
    const mockEvents = [
      {
        event_id: "EVT-1",
        type: "Earthquake",
        created_at: new Date().toISOString(),
        latitude: 34.05,
        longitude: -118.25,
        mat_nbr: {
          name: "Material A",
          risk_rating: 0.8,
        },
      },
    ];

    mockGetEvents.mockResolvedValue({
      data: {
        success: true,
        data: {
          count: mockEvents.length,
          results: mockEvents,
        },
      },
    });

    render(
      <TestWrapper>
        <DisruptionsMap />
      </TestWrapper>
    );

    await waitFor(() => {
      expect(mockGetEvents).toHaveBeenCalled();
    });

    expect(screen.getByTestId("map-container")).toBeInTheDocument();
  });

  it("displays error state when API fails", async () => {
    mockGetEvents.mockRejectedValue(new Error("API Error"));

    render(
      <TestWrapper>
        <DisruptionsMap />
      </TestWrapper>
    );

    expect(await screen.findByText(/API Error/)).toBeInTheDocument();
  });

  it("has breadcrumb link to overview", async () => {
    render(
      <TestWrapper>
        <DisruptionsMap />
      </TestWrapper>
    );

    const breadcrumb = await screen.findByText("Overview Module");
    expect(breadcrumb).toHaveAttribute("href", "/overview");
  });
});
