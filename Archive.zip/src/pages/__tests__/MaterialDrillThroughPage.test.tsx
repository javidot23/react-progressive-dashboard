import "@testing-library/jest-dom";
import { render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import type React from "react";
import MaterialDrillThroughPage from "@/pages/MaterialDrillThroughPage";

const mockUseIssueByIdQuery = jest.fn();
const mockUseMaterialSubstituteDetailsQuery = jest.fn();
const mockUseMaterialActionHistoryQuery = jest.fn();

jest.mock("@/hooks/queries", () => ({
  useIssueByIdQuery: (...args: unknown[]) => mockUseIssueByIdQuery(...args),
  useMaterialRiskQuery: () => ({ riskData: [], isLoading: false }),
  useMaterialSubstituteDetailsQuery: (...args: unknown[]) => mockUseMaterialSubstituteDetailsQuery(...args),
  useIssueDrivingEventQuery: () => ({
    event: null,
    isLoading: false,
    isFetching: false,
  }),
  useMaterialRiskWeeklyAveragesQuery: () => ({ weeklyData: [], isLoading: false }),
  useMaterialActionHistoryQuery: (...args: unknown[]) => mockUseMaterialActionHistoryQuery(...args),
}));

jest.mock("@/hooks", () => ({
  useRiskModelDescriptions: () => ({
    enrichRiskData: (riskData: unknown[]) => riskData,
    getEnrichedMetadata: (riskType: string) => ({
      original_risk_type: riskType,
      risk_type: riskType,
      risk_description: riskType,
      display_name: riskType,
    }),
  }),
}));

jest.mock("@/components/templates/DashboardLayout", () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock("@/components/templates/CardLayout", () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock("@/components/material-drill-through/MaterialDrillTabs", () => ({
  MATERIAL_DRILL_TAB_QUERY_KEY: "tab",
  ...jest.requireActual("@/components/material-drill-through/MaterialDrillTabs"),
  MaterialDrillTabs: () => <div data-testid="material-drill-tabs" />,
}));

jest.mock("@/components/material-drill-through/MaterialProfileCard", () => ({
  MaterialProfileCard: () => <div data-testid="material-profile-card" />,
}));

jest.mock("@/components/material-drill-through/VendorProfileCard", () => ({
  VendorProfileCard: () => <div data-testid="vendor-profile-card" />,
}));

jest.mock("@/components/material-drill-through/MaterialSummaryHeader", () => ({
  MaterialSummaryHeader: () => <div data-testid="material-summary-header" />,
}));

jest.mock("@/components/material-drill-through/RecommendedActionsCard", () => ({
  RecommendedActionsCard: () => <div data-testid="recommended-actions-card" />,
}));

jest.mock("@/components/material-drill-through/ActionHistoryPanel", () => ({
  ActionHistoryPanel: () => <div data-testid="action-history-panel" />,
}));

jest.mock("@/components/material-drill-through/DrivingEventPanel", () => ({
  DrivingEventPanel: () => <div data-testid="driving-event-panel" />,
}));

jest.mock("@/components/material-drill-through/DrivingRiskEventsTimeline", () => ({
  DrivingRiskEventsTimeline: () => <div data-testid="driving-risk-events-timeline" />,
}));

jest.mock("@/components/material-drill-through/MaterialRiskScoreChart", () => ({
  MaterialRiskScoreChart: () => <div data-testid="material-risk-score-chart" />,
}));

jest.mock("@/components/molecules/IssueNotesCard", () => ({
  IssueNotesCard: () => <div data-testid="issue-notes-card" />,
}));

describe("MaterialDrillThroughPage", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockUseIssueByIdQuery.mockReturnValue({
      isLoading: false,
      issue: {
        id: 123,
        issue_nbr: "ISS-123",
        status: "OPEN",
        created_at: "2026-05-19T09:00:00Z",
        updated_at: "2026-05-19T09:00:00Z",
        risk_adjusted_value: 1250,
        actions: [],
        potential_actions: [],
        notes_count: 0,
        last_note: null,
        material: {
          id: 222,
          mat_nbr: "MAT-222",
          name: "Issue Detail Material",
          ndc: "12345678901",
          risk_rating: 0.5,
          driving_risk: "Supply",
          dollars_at_risk: 2500,
          vendor: {
            id: 333,
            name: "Issue Detail Vendor",
          },
        },
      },
    });
    mockUseMaterialSubstituteDetailsQuery.mockReturnValue({
      details: {
        material: {
          id: 222,
          mat_nbr: "MAT-222",
          name: "Detail Material",
          risk_rating: 0.5,
          driving_risk: "Supply",
          dollars_at_risk: 2500,
          saleable_qty_on_hand: 100,
          forecast_qty_7day: 50,
          vendor: {
            id: 333,
            vendor_nbr: "V-333",
            name: "Detail Vendor",
            risk_rating: 0.46,
          },
        },
        material_formularies: [],
        available_plants_count: 2,
      },
      isLoading: false,
    });
    mockUseMaterialActionHistoryQuery.mockReturnValue({
      actions: [],
      total: 0,
      isLoading: false,
      isFetching: false,
    });
  });

  it("uses the single issue response to resolve material context on direct URL load", async () => {
    render(
      <MemoryRouter initialEntries={["/react/product/123?tab=actions"]}>
        <Routes>
          <Route path="/react/product/:issueId" element={<MaterialDrillThroughPage />} />
        </Routes>
      </MemoryRouter>
    );

    await waitFor(() => {
      expect(mockUseIssueByIdQuery).toHaveBeenCalledWith({
        issueId: 123,
        enabled: true,
      });
    });

    expect(mockUseMaterialSubstituteDetailsQuery).toHaveBeenCalledWith({
      materialId: 222,
      enabled: true,
    });
    expect(mockUseMaterialActionHistoryQuery).toHaveBeenCalledWith({
      matNbr: "MAT-222",
      page: 1,
      pageSize: 10,
      enabled: true,
    });
  });

  it("renders Material & Supplier Profile tab content when tab=profile", async () => {
    render(
      <MemoryRouter initialEntries={["/react/product/123?tab=profile"]}>
        <Routes>
          <Route path="/react/product/:issueId" element={<MaterialDrillThroughPage />} />
        </Routes>
      </MemoryRouter>
    );

    await waitFor(() => {
      expect(screen.getByTestId("material-profile-card")).toBeInTheDocument();
      expect(screen.getByTestId("vendor-profile-card")).toBeInTheDocument();
    });

    expect(screen.queryByTestId("recommended-actions-card")).not.toBeInTheDocument();
  });
});
