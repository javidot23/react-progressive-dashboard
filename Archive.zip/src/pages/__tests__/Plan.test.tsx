import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import { BrowserRouter } from "react-router-dom";
import Plan from "@/pages/Plan";
import { useVendorFilters } from "@/hooks/useVendorFilters";
import { useVendorsInfiniteQuery, useVendorsListPaginatedQuery } from "@/hooks/queries";

jest.mock("@/hooks/useVendorFilters");
jest.mock("@/hooks/queries", () => {
  const { createUseFilterRangesQueryMock } = jest.requireActual("@/__tests__/mocks/useFilterRangesQuery");
  return {
    useVendorsInfiniteQuery: jest.fn(),
    useVendorsListPaginatedQuery: jest.fn(),
    ...createUseFilterRangesQueryMock(),
  };
});
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useSearchParams: jest.fn(),
}));

jest.mock("@/components/templates/DashboardLayout", () => ({
  __esModule: true,
  default: function MockDashboardLayout({
    children,
    pageTitle,
    pageSubtitle,
    bannerRightContent,
  }: {
    children: React.ReactNode;
    pageTitle: React.ReactNode;
    pageSubtitle: string;
    bannerRightContent?: React.ReactNode;
  }) {
    return (
      <div data-testid="dashboard-layout">
        <div data-testid="page-title">{pageTitle}</div>
        <div data-testid="page-subtitle">{pageSubtitle}</div>
        {bannerRightContent && <div>{bannerRightContent}</div>}
        {children}
      </div>
    );
  },
}));

jest.mock("@/components/templates/DataViewLayout", () => ({
  __esModule: true,
  default: ({ title, subtitle, data }: { title: string; subtitle: string; data: unknown[] }) => (
    <div data-testid="data-view-layout">
      <div data-testid="data-title">{title}</div>
      <div data-testid="data-subtitle">{subtitle}</div>
      <div data-testid="data-count">{data?.length || 0}</div>
    </div>
  ),
}));

jest.mock("@/components/atoms/PageTitle", () => ({
  PageTitle: ({ title, section }: { title: string; section: string }) => (
    <div data-testid="page-title-component">
      <span data-testid="title">{title}</span>
      <span data-testid="section">{section}</span>
    </div>
  ),
}));

jest.mock("@/components/atoms/Filters", () => ({
  __esModule: true,
  default: () => <div data-testid="filters">Filters</div>,
}));

jest.mock("@/components/atoms/AppliedFilters", () => ({
  __esModule: true,
  default: () => <div data-testid="applied-filters">Applied Filters</div>,
}));

jest.mock("@/components/organisms/GlobalFilters", () => ({
  __esModule: true,
  default: () => <div data-testid="global-filters">Global Filters</div>,
}));

jest.mock("@/components/organisms", () => ({
  MainKPIs: () => <div data-testid="main-kpis">Main KPIs</div>,
}));

jest.mock("@/hooks/useTableColumns", () => ({
  useTableColumns: jest.fn(() => ({
    columns: [],
    saveColumns: jest.fn(),
    resetColumns: jest.fn(),
  })),
}));

jest.mock("@/components/molecules/TableConfigurationModal", () => ({
  TableConfigurationModal: ({ isOpen, onClose: _onClose }: { isOpen: boolean; onClose: () => void }) =>
    isOpen ? <div data-testid="table-config-modal">Table Config Modal</div> : null,
}));

jest.mock("@/components/molecules/CreateCustomFilterModal", () => ({
  CreateCustomFilterModal: ({ isOpen, onClose: _onClose }: { isOpen: boolean; onClose: () => void }) =>
    isOpen ? <div data-testid="create-filter-modal">Create Filter Modal</div> : null,
}));

jest.mock("@/components/molecules/ReorderTableModal", () => ({
  ReorderTableModal: ({ isOpen, onClose: _onClose }: { isOpen: boolean; onClose: () => void }) =>
    isOpen ? <div data-testid="reorder-table-modal">Reorder Table Modal</div> : null,
}));

jest.mock("@/components/molecules/VendorCardView", () => ({
  __esModule: true,
  default: ({ vendor }: { vendor: { id: number; name: string } }) => (
    <div data-testid={`vendor-card-${vendor.id}`}>{vendor.name}</div>
  ),
}));

jest.mock("@/components/molecules/VendorTableView", () => ({
  __esModule: true,
  default: ({ data }: { data: unknown[] }) => (
    <div data-testid="vendor-table">
      <div data-testid="vendor-table-count">{data?.length || 0}</div>
    </div>
  ),
}));

const TestWrapper = ({ children }: { children: React.ReactNode }) => <BrowserRouter>{children}</BrowserRouter>;

describe("Plan", () => {
  const mockUseVendorFilters = useVendorFilters as jest.MockedFunction<typeof useVendorFilters>;
  const mockUseVendorsInfiniteQuery = useVendorsInfiniteQuery as jest.MockedFunction<typeof useVendorsInfiniteQuery>;
  const mockUseVendorsListPaginatedQuery = useVendorsListPaginatedQuery as jest.MockedFunction<
    typeof useVendorsListPaginatedQuery
  >;
  let mockUseSearchParams: jest.MockedFunction<() => [URLSearchParams, jest.Mock]>;

  beforeEach(() => {
    jest.clearAllMocks();

    mockUseSearchParams = jest.requireMock("react-router-dom").useSearchParams as jest.MockedFunction<
      () => [URLSearchParams, jest.Mock]
    >;

    mockUseVendorFilters.mockReturnValue({
      filters: {},
      setFilters: jest.fn(),
    });

    const mockSearchParams = new URLSearchParams();
    const mockSetSearchParams = jest.fn();
    mockUseSearchParams.mockReturnValue([mockSearchParams, mockSetSearchParams]);

    mockUseVendorsInfiniteQuery.mockReturnValue({
      vendors: [],
      isLoading: false,
      hasMore: false,
      total: 0,
      isFetchingNextPage: false,
      fetchNextPage: jest.fn(),
      refetch: jest.fn(),
      isFetching: false,
      isPending: false,
      isPlaceholderData: false,
      error: null,
      isError: false,
      invalidateVendors: jest.fn(),
    });

    mockUseVendorsListPaginatedQuery.mockReturnValue({
      vendors: [],
      isLoading: false,
      total: 0,
      refetch: jest.fn(),
      isFetching: false,
      isPending: false,
      isPlaceholderData: false,
      error: null,
      isError: false,
      hasMore: false,
      prefetchNextPage: jest.fn(),
      invalidateVendors: jest.fn(),
    });
  });

  it("renders without crashing", () => {
    expect(() =>
      render(
        <TestWrapper>
          <Plan />
        </TestWrapper>
      )
    ).not.toThrow();
  });

  it("renders main components", () => {
    render(
      <TestWrapper>
        <Plan />
      </TestWrapper>
    );

    expect(screen.getByTestId("dashboard-layout")).toBeInTheDocument();
    expect(screen.getByTestId("global-filters")).toBeInTheDocument();
    expect(screen.getByTestId("main-kpis")).toBeInTheDocument();
    expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
  });

  it("renders correct page title and section", () => {
    render(
      <TestWrapper>
        <Plan />
      </TestWrapper>
    );

    expect(screen.getByTestId("title")).toHaveTextContent("Supply Chain Resiliency Mapping");
    expect(screen.getByTestId("section")).toHaveTextContent("Plan");
  });

  it("renders data view layout with correct title", () => {
    render(
      <TestWrapper>
        <Plan />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-title")).toHaveTextContent("Supplier Risk Assessment");
  });

  it("displays loading state when data is loading", () => {
    mockUseVendorsInfiniteQuery.mockReturnValue({
      vendors: [],
      isLoading: true,
      hasMore: false,
      total: 0,
      isFetchingNextPage: false,
      fetchNextPage: jest.fn(),
      refetch: jest.fn(),
      isFetching: false,
      isPending: false,
      isPlaceholderData: false,
      error: null,
      isError: false,
      invalidateVendors: jest.fn(),
    });

    render(
      <TestWrapper>
        <Plan />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("0");
  });

  it("displays vendors when data is available", () => {
    const mockVendors = [
      {
        id: 1,
        name: "Vendor 1",
        vendor_nbr: "V001",
        city: "City 1",
        country: "Country 1",
        latitude: 1.0,
        longitude: 1.0,
        risk_rating: 1,
        driving_risk: "Low",
        created_at: "2021-01-01",
        updated_at: "2021-01-01",
      },
      {
        id: 2,
        name: "Vendor 2",
        vendor_nbr: "V002",
        city: "City 2",
        country: "Country 2",
        latitude: 2.0,
        longitude: 2.0,
        risk_rating: 2,
        driving_risk: "Medium",
        created_at: "2021-01-01",
        updated_at: "2021-01-01",
      },
    ];

    mockUseVendorsInfiniteQuery.mockReturnValue({
      vendors: mockVendors,
      isLoading: false,
      hasMore: true,
      total: 2,
      isFetchingNextPage: false,
      fetchNextPage: jest.fn(),
      refetch: jest.fn(),
      isFetching: false,
      isPending: false,
      isPlaceholderData: false,
      error: null,
      isError: false,
      invalidateVendors: jest.fn(),
    });

    mockUseVendorsListPaginatedQuery.mockReturnValue({
      vendors: mockVendors,
      isLoading: false,
      total: 2,
      refetch: jest.fn(),
      isFetching: false,
      isPending: false,
      isPlaceholderData: false,
      error: null,
      isError: false,
      hasMore: true,
      prefetchNextPage: jest.fn(),
      invalidateVendors: jest.fn(),
    });

    render(
      <TestWrapper>
        <Plan />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("2");
  });

  it("handles empty data state", () => {
    mockUseVendorsInfiniteQuery.mockReturnValue({
      vendors: [],
      isLoading: false,
      hasMore: false,
      total: 0,
      isFetchingNextPage: false,
      fetchNextPage: jest.fn(),
      refetch: jest.fn(),
      isFetching: false,
      isPending: false,
      isPlaceholderData: false,
      error: null,
      isError: false,
      invalidateVendors: jest.fn(),
    });

    render(
      <TestWrapper>
        <Plan />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("0");
  });
});
