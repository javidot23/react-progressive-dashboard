import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import { BrowserRouter } from "react-router-dom";
import PlanProductPage from "@/pages/PlanProductPage";
import { useMaterialFilters } from "@/hooks/useMaterialFilters";
import { useNetworkStatus } from "@/hooks/useNetworkStatus";
import { useVendorQuery, useMaterialsQuery, useMaterialsInfiniteQuery, useVendorsListQuery } from "@/hooks/queries";

jest.mock("@/hooks/useMaterialFilters");
jest.mock("@/hooks/useNetworkStatus");
jest.mock("@/hooks/queries", () => {
  const { createUseFilterRangesQueryMock } = jest.requireActual(
    "@/__tests__/mocks/useFilterRangesQuery",
  );
  return {
    useVendorQuery: jest.fn(),
    useMaterialsQuery: jest.fn(),
    useMaterialsInfiniteQuery: jest.fn(),
    useVendorsListQuery: jest.fn(),
    ...createUseFilterRangesQueryMock(),
  };
});

jest.mock("@/hooks", () => ({
  ...jest.requireActual("@/hooks"),
  useRiskModelDescriptions: () => ({
    getEnrichedMetadata: (riskType: string) => ({
      display_name: riskType || "",
      original_risk_type: riskType,
      risk_type: riskType,
      risk_description: riskType,
    }),
  }),
}));

jest.mock("@/components/templates/DashboardLayout", () => ({
  __esModule: true,
  default: ({ children }: any) => <div data-testid="dashboard-layout">{children}</div>,
}));

jest.mock("@/components/templates/DataViewLayout", () => ({
  __esModule: true,
  default: ({ title }: any) => <div data-testid="data-view-layout">{title}</div>,
}));

jest.mock("@/components/molecules/VendorDetailCards", () => ({
  __esModule: true,
  default: () => <div data-testid="vendor-detail-cards">Vendor Detail Cards</div>,
}));

jest.mock("@/components/atoms/Filters", () => ({
  __esModule: true,
  default: () => <div data-testid="filters">Filters</div>,
}));

jest.mock("@/components/atoms/AppliedFilters", () => ({
  __esModule: true,
  default: () => <div data-testid="applied-filters">Applied Filters</div>,
}));

const mockNavigate = jest.fn();
const mockUseParams = jest.fn(() => ({ vendorId: "1" }));
jest.mock("react-router-dom", () => {
  const actual = jest.requireActual("react-router-dom");
  return {
    ...actual,
    useNavigate: () => mockNavigate,
    useParams: () => mockUseParams(),
  };
});

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <BrowserRouter>{children}</BrowserRouter>
);

describe("PlanProductPage", () => {
  const mockUseMaterialFilters = useMaterialFilters as jest.MockedFunction<typeof useMaterialFilters>;
  const mockUseNetworkStatus = useNetworkStatus as jest.MockedFunction<typeof useNetworkStatus>;
  const mockUseVendorQuery = useVendorQuery as jest.MockedFunction<typeof useVendorQuery>;
  const mockUseMaterialsQuery = useMaterialsQuery as jest.MockedFunction<typeof useMaterialsQuery>;
  const mockUseMaterialsInfiniteQuery = useMaterialsInfiniteQuery as jest.MockedFunction<typeof useMaterialsInfiniteQuery>;
  const mockUseVendorsListQuery = useVendorsListQuery as jest.MockedFunction<typeof useVendorsListQuery>;

  const mockVendor = {
    id: 1,
    name: "Test Vendor",
    vendor_nbr: "V001",
    country: "USA",
    city: "New York",
    latitude: 0,
    longitude: 0,
    driving_risk: "Supply",
    risk_rating: 0.75,
    created_at: "2024-01-01",
    updated_at: "2024-01-01",
    service_levels_90_days: [],
    materials_at_risk: 10,
    total_materials: 100,
    sales_volume: 1000,
    sales_amount: 50000,
    risk_adjusted_value: 100000,
  };

  beforeEach(() => {
    jest.clearAllMocks();
    mockNavigate.mockClear();
    mockUseParams.mockReturnValue({ vendorId: "1" });

    mockUseMaterialFilters.mockReturnValue({
      filters: {},
      setFilters: jest.fn(),
    });

    mockUseNetworkStatus.mockReturnValue(true);

    mockUseVendorQuery.mockReturnValue({
      vendor: mockVendor,
      isLoading: false,
      isFetching: false,
      isPending: false,
      invalidateVendor: jest.fn(),
      error: null,
      isError: false,
      refetch: jest.fn(),
    });

    mockUseMaterialsQuery.mockReturnValue({
      materials: [],
      isLoading: false,
      total: 0,
      hasMore: false,
      refetch: jest.fn(),
      isFetching: false,
      isPending: false,
      isPlaceholderData: false,
      error: null,
      isError: false,
      prefetchNextPage: jest.fn(),
      invalidateMaterials: jest.fn(),
    });

    mockUseMaterialsInfiniteQuery.mockReturnValue({
      materials: [],
      isLoading: false,
      hasMore: false,
      total: 0,
      isFetchingNextPage: false,
      fetchNextPage: jest.fn(),
      refetch: jest.fn(),
      isFetching: false,
      isPending: false,
      isPlaceholderData: false,
      error: null,
      isError: false,
      invalidateMaterials: jest.fn(),
    });

    mockUseVendorsListQuery.mockReturnValue({
      vendors: [],
      isLoading: false,
      isFetching: false,
      error: null,
      isError: false,
      refetch: jest.fn(),
    });
  });

  it("renders without crashing", () => {
    expect(() =>
      render(
        <TestWrapper>
          <PlanProductPage />
        </TestWrapper>
      )
    ).not.toThrow();
  });

  it("renders dashboard layout", () => {
    render(
      <TestWrapper>
        <PlanProductPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("dashboard-layout")).toBeInTheDocument();
  });

  it("renders vendor detail cards", () => {
    render(
      <TestWrapper>
        <PlanProductPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("vendor-detail-cards")).toBeInTheDocument();
  });

  it("renders data view layout", () => {
    render(
      <TestWrapper>
        <PlanProductPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
  });



  it("displays error state when vendor query fails", () => {
    mockUseVendorQuery.mockReturnValue({
      vendor: null,
      isLoading: false,
      isFetching: false,
      isPending: false,
      invalidateVendor: jest.fn(),
      error: "Failed to load vendor",
      isError: true,
      refetch: jest.fn(),
    });

    render(
      <TestWrapper>
        <PlanProductPage />
      </TestWrapper>
    );


  });

  it("handles missing vendorId by redirecting", () => {
    mockUseParams.mockReturnValue({ vendorId: "" });

    render(
      <TestWrapper>
        <PlanProductPage />
      </TestWrapper>
    );

    expect(mockNavigate).toHaveBeenCalledWith("/plan", { replace: true });
  });
});
