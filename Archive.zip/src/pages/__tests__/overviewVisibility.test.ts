import { getOverviewBottomSlots, OVERVIEW_BOTTOM_BY_TENANT } from "@/pages/overviewVisibility";
import type { TenantType } from "@/tenant";

const TENANT_TYPES = Object.keys(OVERVIEW_BOTTOM_BY_TENANT) as TenantType[];

describe("getOverviewBottomSlots", () => {
  it.each([
    ["customer", { highRiskSuppliers: true, highRiskMaterials: true, currentVsPrior: false }],
    ["vendor", { highRiskSuppliers: false, highRiskMaterials: true, currentVsPrior: true }],
    ["customer_vendor", { highRiskSuppliers: false, highRiskMaterials: false, currentVsPrior: true }],
  ] as const)("returns the correct slots for %s", (type, expected) => {
    expect(getOverviewBottomSlots(type)).toEqual(expected);
  });

  it("returns undefined when tenant type is missing", () => {
    expect(getOverviewBottomSlots(undefined)).toBeUndefined();
  });

  it("covers every TenantType", () => {
    expect(TENANT_TYPES).toEqual(["customer", "vendor", "customer_vendor"]);
  });
});
