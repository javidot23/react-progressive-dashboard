import { render, screen, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TableSettingsProvider } from "@/components/atoms";
import ReactPage from "@/pages/ReactPage";
import { useGranularityIssueFilters } from "@/hooks/useGranularityIssueFilters";
import { useGranularityIssuesQuery } from "@/hooks/queries/useGranularityIssuesQuery";
import { useGranularityIssuesInfiniteQuery } from "@/hooks/queries/useGranularityIssuesInfiniteQuery";
import { IssueAtGranularityApiData } from "@/types/granularityIssue";

jest.mock("@/hooks/useGranularityIssueFilters");
jest.mock("@/hooks/queries", () => {
  const { createUseFilterRangesQueryMock } = jest.requireActual("@/__tests__/mocks/useFilterRangesQuery");
  return {
    ...createUseFilterRangesQueryMock(),
  };
});
jest.mock("@/hooks/queries/useGranularityIssuesQuery", () => ({
  useGranularityIssuesQuery: jest.fn(),
}));
jest.mock("@/hooks/queries/useGranularityIssuesInfiniteQuery", () => ({
  useGranularityIssuesInfiniteQuery: jest.fn(),
}));
jest.mock("@/hooks/useTableColumns", () => ({
  useTableColumns: jest.fn(),
}));
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useSearchParams: jest.fn(),
}));
jest.mock("@/lib/apiServices", () => ({
  drivingRiskService: {
    getMaterialDrivingRisk: jest.fn(),
  },
}));

jest.mock("@/hooks", () => ({
  ...jest.requireActual("@/hooks"),
  useRiskModelDescriptions: () => ({
    getEnrichedMetadata: (riskType: string) => ({
      display_name: riskType || "",
      original_risk_type: riskType,
      risk_type: riskType,
      risk_description: riskType,
    }),
  }),
}));

jest.mock("@/components/templates/DashboardLayout", () => ({
  __esModule: true,
  default: function MockDashboardLayout({
    children,
    pageTitle,
    pageSubtitle,
    bannerRightContent,
  }: {
    children: React.ReactNode;
    pageTitle: React.ReactNode;
    pageSubtitle: string;
    bannerRightContent?: React.ReactNode;
  }) {
    return (
      <div data-testid="dashboard-layout">
        <div data-testid="page-title">{pageTitle}</div>
        <div data-testid="page-subtitle">{pageSubtitle}</div>
        {bannerRightContent && <div>{bannerRightContent}</div>}
        {children}
      </div>
    );
  },
}));

jest.mock("@/components/templates/DataViewLayout", () => ({
  __esModule: true,
  default: function MockDataViewLayout({
    title,
    subtitle,
    data,
    viewMode,
    loading,
    hasMore,
    onLoadMore,
    renderCard,
    renderTable,
    filters,
  }: any) {
    return (
      <div data-testid="data-view-layout">
        <div data-testid="data-title">{title}</div>
        <div data-testid="data-subtitle">{subtitle}</div>
        <div data-testid="view-mode">{viewMode || "card"}</div>
        <div data-testid="loading-state">{loading ? "Loading" : "Not Loading"}</div>
        <div data-testid="has-more">{hasMore ? "Has More" : "No More"}</div>
        <div data-testid="filters-container">{filters}</div>
        <div data-testid="data-count">{data?.length || 0}</div>

        <button data-testid="load-more-button" onClick={onLoadMore} disabled={!hasMore || loading}>
          Load More
        </button>

        <div data-testid="rendered-content">
          {viewMode === "card" ? data?.map((item: any, index: number) => renderCard(item, index)) : renderTable(data)}
        </div>
      </div>
    );
  },
}));

jest.mock("@/components/organisms/GlobalFilters", () => ({
  __esModule: true,
  default: () => <div data-testid="global-filters">Global Filters</div>,
}));

jest.mock("@/components/organisms", () => ({
  MainKPIs: () => <div data-testid="main-kpis">Main KPIs</div>,
}));

jest.mock("@/components/atoms/PageTitle", () => ({
  PageTitle: ({ title, section }: any) => (
    <div data-testid="page-title-component">
      <span data-testid="title">{title}</span>
      <span data-testid="section">{section}</span>
    </div>
  ),
}));

jest.mock("@/components/atoms/Filters", () => ({
  __esModule: true,
  default: () => <div data-testid="filters">Filters</div>,
}));

jest.mock("@/components/atoms/AppliedFilters", () => ({
  __esModule: true,
  default: () => <div data-testid="applied-filters">Applied Filters</div>,
}));

jest.mock("@/components/organisms/InboundServiceLevelTrend", () => ({
  __esModule: true,
  default: () => <div data-testid="inbound-service-level-trend">Service Level Trend</div>,
}));

// Test wrapper with QueryClient, Router, and TableSettingsProvider
const TestWrapper = ({ children }: { children: React.ReactNode }) => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: 0,
      },
      mutations: {
        retry: false,
      },
    },
  });

  return (
    <QueryClientProvider client={queryClient}>
      <TableSettingsProvider>
        <BrowserRouter>{children}</BrowserRouter>
      </TableSettingsProvider>
    </QueryClientProvider>
  );
};

// Helper function to create mock query return values
const createMockQueryReturn = (overrides: any = {}) => ({
  issues: mockIssueApiData,
  total: 2,
  hasMore: false,
  isLoading: false,
  isFetching: false,
  isPlaceholderData: false,
  isPending: false,
  error: null,
  isError: false,
  refetch: jest.fn(),
  prefetchNextPage: jest.fn(),
  invalidateIssues: jest.fn(),
  ...overrides,
});

const createMockInfiniteQueryReturn = (overrides: any = {}) => ({
  issues: mockIssueApiData,
  total: 2,
  hasMore: false,
  isLoading: false,
  isFetching: false,
  isFetchingNextPage: false,
  isPending: false,
  isPlaceholderData: false,
  error: null,
  isError: false,
  fetchNextPage: jest.fn(),
  refetch: jest.fn(),
  invalidateIssues: jest.fn(),
  ...overrides,
});

// Mock data
const mockIssueApiData: IssueAtGranularityApiData[] = [
  {
    id: 1,
    issue_nbr: "ISS-001",
    event_id: null,
    status: "open",
    date_identified: new Date().toISOString(),
    start_date: "2025-01-01",
    granularity_type: "material",
    fdb_gcn_seq_nbr: null,
    ndc: "12345-678-90",
    fei_number: null,
    hicl: null,
    hicl_description: null,
    plant: null,
    impacted_material_count: 1,
    effective_risk_rating: 0.75,
    effective_dollars_at_risk: 100000,
    effective_risk_adjusted_value: 75000,
    driving_event: null,
    group: null,
    persona: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    last_note: null,
    notes_count: 0,
    has_actions: false,
    material: {
      id: 1,
      name: "Test Material 1",
      ndc: "12345-678-90",
      mat_nbr: "MAT001",
      ean_n4_nbr_11: "12345678901",
      risk_rating: 0.75,
      driving_risk: "Supply",
      dollars_at_risk: 100000,
      xplant_mat_stat: "AC",
      vendor: {
        id: 1,
        name: "Test Vendor 1",
        driving_risk: "Supply",
      },
    },
  },
  {
    id: 2,
    issue_nbr: "ISS-002",
    event_id: null,
    status: "open",
    date_identified: new Date().toISOString(),
    start_date: "2025-01-02",
    granularity_type: "material",
    fdb_gcn_seq_nbr: null,
    ndc: "23456-789-01",
    fei_number: null,
    hicl: null,
    hicl_description: null,
    plant: null,
    impacted_material_count: 1,
    effective_risk_rating: 0.65,
    effective_dollars_at_risk: 50000,
    effective_risk_adjusted_value: 32500,
    driving_event: null,
    group: null,
    persona: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    last_note: null,
    notes_count: 0,
    has_actions: false,
    material: {
      id: 2,
      name: "Test Material 2",
      ndc: "23456-789-01",
      mat_nbr: "MAT002",
      ean_n4_nbr_11: "23456789012",
      risk_rating: 0.65,
      driving_risk: "Operational",
      dollars_at_risk: 50000,
      xplant_mat_stat: "AC",
      vendor: {
        id: 2,
        name: "Test Vendor 2",
      },
    },
  },
];

const defaultFilters = {
  ordering: "-effective_risk_adjusted_value",
  effective_risk_rating_min: null,
  effective_risk_rating_max: null,
  effective_risk_adjusted_value_min: null,
  effective_risk_adjusted_value_max: null,
  effective_dollars_at_risk_min: null,
  effective_dollars_at_risk_max: null,
  impacted_material_count_min: null,
  impacted_material_count_max: null,
  group: null,
};

// Mock variables at module scope for access in all describe blocks
const mockUseGranularityIssueFilters = useGranularityIssueFilters as jest.MockedFunction<typeof useGranularityIssueFilters>;
const mockUseGranularityIssuesQuery = useGranularityIssuesQuery as jest.MockedFunction<typeof useGranularityIssuesQuery>;
const mockUseGranularityIssuesInfiniteQuery = useGranularityIssuesInfiniteQuery as jest.MockedFunction<
  typeof useGranularityIssuesInfiniteQuery
>;
let mockUseTableColumns: jest.MockedFunction<() => { columns: any[]; saveColumns: jest.Mock; resetColumns: jest.Mock }>;
let mockUseSearchParams: jest.MockedFunction<() => [URLSearchParams, jest.Mock]>;
let mockDrivingRiskService: { getMaterialDrivingRisk: jest.Mock };

describe("ReactPage", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    // Initialize mocks
    mockUseTableColumns = jest.requireMock("@/hooks/useTableColumns").useTableColumns as jest.MockedFunction<any>;
    mockUseSearchParams = jest.requireMock("react-router-dom").useSearchParams as jest.MockedFunction<any>;
    mockDrivingRiskService = jest.requireMock("@/lib/apiServices").drivingRiskService;

    mockUseGranularityIssueFilters.mockReturnValue({
      filters: defaultFilters,
      setFilters: jest.fn(),
    });

    const mockSearchParams = new URLSearchParams();
    const mockSetSearchParams = jest.fn();
    mockUseSearchParams.mockReturnValue([mockSearchParams, mockSetSearchParams]);

    mockUseTableColumns.mockReturnValue({
      columns: [],
      saveColumns: jest.fn(),
      resetColumns: jest.fn(),
    });

    mockUseGranularityIssuesQuery.mockReturnValue(createMockQueryReturn());
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(createMockInfiniteQueryReturn());
  });

  describe("Rendering", () => {
    it("renders all main components", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("dashboard-layout")).toBeInTheDocument();
      expect(screen.getByTestId("global-filters")).toBeInTheDocument();
      expect(screen.getByTestId("main-kpis")).toBeInTheDocument();
      expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
      expect(screen.getByTestId("filters")).toBeInTheDocument();
      expect(screen.getByTestId("applied-filters")).toBeInTheDocument();
      expect(screen.getByTestId("inbound-service-level-trend")).toBeInTheDocument();
    });

    it("renders correct page title and subtitle", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("title")).toHaveTextContent("Supply Chain Resiliency Mapping");
      expect(screen.getByTestId("section")).toHaveTextContent("React");
      expect(screen.getByTestId("page-subtitle")).toHaveTextContent(
        "Insights and recommended actions to mitigate unexpected events in supply chain operations."
      );
    });

    it("renders filter configuration correctly", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("filters")).toBeInTheDocument();
      expect(screen.getByTestId("applied-filters")).toBeInTheDocument();
    });
  });

  describe("Filtering", () => {
    it("passes filters to components correctly", () => {
      const mockSetFilters = jest.fn();
      mockUseGranularityIssueFilters.mockReturnValue({
        filters: {
          group: "SGS",
          effective_risk_adjusted_value_min: 10000,
        },
        setFilters: mockSetFilters,
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("applied-filters")).toBeInTheDocument();
    });

    it("updates filters when group filter changes", async () => {
      const mockSetFilters = jest.fn();
      mockUseGranularityIssueFilters.mockReturnValue({
        filters: defaultFilters,
        setFilters: mockSetFilters,
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("filters")).toBeInTheDocument();
    });

    it("can clear all filters", async () => {
      const mockSetFilters = jest.fn();
      mockUseGranularityIssueFilters.mockReturnValue({
        filters: { group: "SGS", effective_risk_adjusted_value_min: 10000 },
        setFilters: mockSetFilters,
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("applied-filters")).toBeInTheDocument();
    });

    it("renders the group filter dropdown", async () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("filters")).toBeInTheDocument();
      });
    });
  });

  describe("Pagination", () => {
    it("displays pagination controls in table view", async () => {
      const mockSearchParams = new URLSearchParams();
      mockSearchParams.set("view", "table");
      mockUseSearchParams.mockReturnValue([mockSearchParams, jest.fn()]);

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
      });
    });

    it("handles page change", async () => {
      mockUseGranularityIssuesQuery.mockReturnValue({
        issues: mockIssueApiData,
        total: 20,
        hasMore: true,
        isLoading: false,
        isFetching: false,
        isPlaceholderData: false,
        isPending: false,
        error: null,
        isError: false,
        refetch: jest.fn(),
        prefetchNextPage: jest.fn(),
        invalidateIssues: jest.fn(),
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
    });

    it("handles page size change and resets to page 1", async () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
    });

    it("resets page to 1 when filters change", () => {
      const mockSetFilters = jest.fn();
      const { rerender } = render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      mockUseGranularityIssueFilters.mockReturnValue({
        filters: { group: "SGS" },
        setFilters: mockSetFilters,
      });

      rerender(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("dashboard-layout")).toBeInTheDocument();
    });
  });

  describe("Data Loading States", () => {
    it("shows loading while a new granularity scope is being fetched (placeholder suppressed)", () => {
      mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
        createMockInfiniteQueryReturn({
          issues: [],
          total: 0,
          isLoading: false,
          isFetching: true,
          isPlaceholderData: true,
        })
      );

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("loading-state")).toHaveTextContent("Loading");
      expect(screen.getByTestId("data-count")).toHaveTextContent("0");
    });

    it("shows loading state when issues are loading", () => {
      mockUseGranularityIssuesQuery.mockReturnValue({
        issues: [],
        total: 0,
        hasMore: false,
        isLoading: true,
        isFetching: true,
        isPlaceholderData: false,
        isPending: true,
        error: null,
        isError: false,
        refetch: jest.fn(),
        prefetchNextPage: jest.fn(),
        invalidateIssues: jest.fn(),
      });

      mockUseGranularityIssuesInfiniteQuery.mockReturnValue({
        issues: [],
        total: 0,
        hasMore: false,
        isLoading: true,
        isFetching: true,
        isFetchingNextPage: false,
        isPending: true,
        isPlaceholderData: false,
        error: null,
        isError: false,
        fetchNextPage: jest.fn(),
        refetch: jest.fn(),
        invalidateIssues: jest.fn(),
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("loading-state")).toHaveTextContent("Loading");
    });

    it("shows has more state correctly", () => {
      mockUseGranularityIssuesQuery.mockReturnValue({
        issues: mockIssueApiData,
        total: 20,
        hasMore: true,
        isLoading: false,
        isFetching: false,
        isPlaceholderData: false,
        isPending: false,
        error: null,
        isError: false,
        refetch: jest.fn(),
        prefetchNextPage: jest.fn(),
        invalidateIssues: jest.fn(),
      });

      mockUseGranularityIssuesInfiniteQuery.mockReturnValue({
        issues: mockIssueApiData,
        total: 20,
        hasMore: true,
        isLoading: false,
        isFetching: false,
        isFetchingNextPage: false,
        isPending: false,
        isPlaceholderData: false,
        error: null,
        isError: false,
        fetchNextPage: jest.fn(),
        refetch: jest.fn(),
        invalidateIssues: jest.fn(),
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("has-more")).toHaveTextContent("Has More");
    });

    it("handles empty issue list", () => {
      mockUseGranularityIssuesQuery.mockReturnValue({
        issues: [],
        total: 0,
        hasMore: false,
        isLoading: false,
        isFetching: false,
        isPlaceholderData: false,
        isPending: false,
        error: null,
        isError: false,
        refetch: jest.fn(),
        prefetchNextPage: jest.fn(),
        invalidateIssues: jest.fn(),
      });

      mockUseGranularityIssuesInfiniteQuery.mockReturnValue({
        issues: [],
        total: 0,
        hasMore: false,
        isLoading: false,
        isFetching: false,
        isFetchingNextPage: false,
        isPending: false,
        isPlaceholderData: false,
        error: null,
        isError: false,
        fetchNextPage: jest.fn(),
        refetch: jest.fn(),
        invalidateIssues: jest.fn(),
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("data-count")).toHaveTextContent("0");
    });
  });

  describe("Module Filtering", () => {
    it("passes 'React' module to useGranularityIssuesQuery hook", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(mockUseGranularityIssuesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          module: "React",
        })
      );
    });

    it("passes current page and page size to useGranularityIssuesQuery", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(mockUseGranularityIssuesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          page: 1,
          pageSize: 10,
        })
      );
    });

    it("passes filters (plus grain ordering) to useGranularityIssuesQuery", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(mockUseGranularityIssuesQuery).toHaveBeenCalledWith(
        expect.objectContaining({
          filters: expect.objectContaining({
            ordering: "-effective_risk_adjusted_value",
          }),
        })
      );
    });
  });

  describe("Edge Cases", () => {
    it("handles undefined issues gracefully", () => {
      mockUseGranularityIssuesQuery.mockReturnValue({
        issues: [] as any,
        total: 0,
        hasMore: false,
        isLoading: false,
        isFetching: false,
        isPlaceholderData: false,
        isPending: false,
        error: null,
        isError: false,
        refetch: jest.fn(),
        prefetchNextPage: jest.fn(),
        invalidateIssues: jest.fn(),
      });

      mockUseGranularityIssuesInfiniteQuery.mockReturnValue({
        issues: [] as any,
        total: 0,
        hasMore: false,
        isLoading: false,
        isFetching: false,
        isFetchingNextPage: false,
        isPending: false,
        isPlaceholderData: false,
        error: null,
        isError: false,
        fetchNextPage: jest.fn(),
        refetch: jest.fn(),
        invalidateIssues: jest.fn(),
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("data-count")).toHaveTextContent("0");
    });

    it("handles issues without vendor data", () => {
      const issueWithoutVendor = [
        {
          ...mockIssueApiData[0],
          material: {
            ...mockIssueApiData[0].material,
            vendor: undefined as any,
          },
        },
      ];

      mockUseGranularityIssuesQuery.mockReturnValue(
        createMockQueryReturn({
          issues: issueWithoutVendor,
          total: 1,
        })
      );
      mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
        createMockInfiniteQueryReturn({
          issues: issueWithoutVendor,
          total: 1,
        })
      );

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("data-count")).toHaveTextContent("1");
    });

    it("handles issues without dollars_at_risk", () => {
      const issueWithoutDollars = [
        {
          ...mockIssueApiData[0],
          material: {
            ...mockIssueApiData[0].material,
            dollars_at_risk: undefined as any,
          },
        },
      ];

      mockUseGranularityIssuesQuery.mockReturnValue(
        createMockQueryReturn({
          issues: issueWithoutDollars,
          total: 1,
        })
      );
      mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
        createMockInfiniteQueryReturn({
          issues: issueWithoutDollars,
          total: 1,
        })
      );

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("data-count")).toHaveTextContent("1");
    });
  });

  describe("Integration Tests", () => {
    it("filters and data work together", () => {
      const mockSetFilters = jest.fn();
      mockUseGranularityIssueFilters.mockReturnValue({
        filters: { group: "SGS" },
        setFilters: mockSetFilters,
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("applied-filters")).toBeInTheDocument();
      expect(screen.getByTestId("data-count")).toHaveTextContent("2");
    });

    it("view mode persists across filter changes", async () => {
      const mockSetFilters = jest.fn();
      mockUseGranularityIssueFilters.mockReturnValue({
        filters: defaultFilters,
        setFilters: mockSetFilters,
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      // View mode is controlled by URL params, not buttons
      expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
    });

    it("pagination works with filtering", async () => {
      const mockSetFilters = jest.fn();
      mockUseGranularityIssueFilters.mockReturnValue({
        filters: { group: "SGS" },
        setFilters: mockSetFilters,
      });

      mockUseGranularityIssuesQuery.mockReturnValue(
        createMockQueryReturn({
          issues: mockIssueApiData,
          hasMore: true,
          total: 20,
        })
      );
      mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
        createMockInfiniteQueryReturn({
          issues: mockIssueApiData,
          hasMore: true,
          total: 20,
        })
      );

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
    });
  });

  describe("Accessibility", () => {
    it("has proper test ids for accessibility testing", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("dashboard-layout")).toBeInTheDocument();
      expect(screen.getByTestId("global-filters")).toBeInTheDocument();
      expect(screen.getByTestId("main-kpis")).toBeInTheDocument();
      expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
    });

    it("renders correct page title and section", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("title")).toHaveTextContent("Supply Chain Resiliency Mapping");
      expect(screen.getByTestId("section")).toHaveTextContent("React");
    });

    it("renders data view layout with correct title", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("data-title")).toHaveTextContent("Open Issues by Risk Exposure");
    });

    it("renders service level trend component", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("inbound-service-level-trend")).toBeInTheDocument();
    });

    it("service level trend is displayed after data view layout", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      const dataViewLayout = screen.getByTestId("data-view-layout");
      const serviceLevelTrend = screen.getByTestId("inbound-service-level-trend");

      expect(dataViewLayout).toBeInTheDocument();
      expect(serviceLevelTrend).toBeInTheDocument();
    });
  });

  describe("GlobalFilters Component", () => {
    it("renders global filters at the top of the page", () => {
      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("global-filters")).toBeInTheDocument();
    });

    it("global filters work independently from local filters", async () => {
      const mockSetFilters = jest.fn();
      mockUseGranularityIssueFilters.mockReturnValue({
        filters: defaultFilters,
        setFilters: mockSetFilters,
      });

      render(
        <TestWrapper>
          <ReactPage />
        </TestWrapper>
      );

      expect(screen.getByTestId("global-filters")).toBeInTheDocument();

      expect(screen.getByTestId("filters")).toBeInTheDocument();
    });
  });
});

describe("Advanced Data Mapping and Transformation", () => {
  beforeEach(() => {
    mockUseTableColumns = jest.requireMock("@/hooks/useTableColumns").useTableColumns as jest.MockedFunction<any>;
    mockUseSearchParams = jest.requireMock("react-router-dom").useSearchParams as jest.MockedFunction<any>;
    mockDrivingRiskService = jest.requireMock("@/lib/apiServices").drivingRiskService;
    const mockSearchParams = new URLSearchParams();
    const mockSetSearchParams = jest.fn();
    mockUseSearchParams.mockReturnValue([mockSearchParams, mockSetSearchParams]);
    mockUseTableColumns.mockReturnValue({
      columns: [],
      saveColumns: jest.fn(),
      resetColumns: jest.fn(),
    });
    mockDrivingRiskService.getMaterialDrivingRisk.mockResolvedValue({
      data: {
        success: true,
        data: [],
      },
    });
    mockUseGranularityIssuesQuery.mockReturnValue(createMockQueryReturn());
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(createMockInfiniteQueryReturn());
  });

  it("correctly maps all issue fields from API to UI format", () => {
    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("2");
  });

  it("handles issues with all optional fields present", () => {
    const completeIssue = [
      {
        ...mockIssueApiData[0],
        has_actions: true,
        material: {
          ...mockIssueApiData[0].material,
          dollars_at_risk: 100000,
          vendor: {
            name: "Complete Vendor",
            driving_risk: "Operational",
          },
        },
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: completeIssue,
        total: 1,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: completeIssue,
        total: 1,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("1");
  });

  it("handles issues with minimal required fields", () => {
    const minimalIssue = [
      {
        id: 999,
        issue_id: "ISS-MIN",
        issue_nbr: "ISS-MIN",
        status: "open",
        description: "Minimal",
        start_date: "2025-01-01",
        act_required_date: "2025-01-15",
        created_at: "2025-01-01T00:00:00Z",
        has_actions: false,
        material: {
          id: 999,
          name: "Minimal Material",
          ndc: "00000-000-00",
          mat_nbr: "MIN001",
          ean_n4_nbr_11: "00000000000",
          risk_rating: 0.5,
          driving_risk: "None",
          dollars_at_risk: 0,
          xplant_mat_stat: "AC",
          vendor: {
            name: "Minimal Vendor",
            driving_risk: "None",
          },
        },
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: minimalIssue,
        total: 1,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: minimalIssue,
        total: 1,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("1");
  });

  it("correctly calculates risk exposure with dollars at risk", () => {
    const issueWithDollars = [
      {
        ...mockIssueApiData[0],
        material: {
          ...mockIssueApiData[0].material,
          risk_rating: 0.75,
          dollars_at_risk: 100000,
        },
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: issueWithDollars,
        total: 1,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: issueWithDollars,
        total: 1,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("1");
  });

  it("handles various date formats correctly", () => {
    const issuesWithDifferentDates = [
      {
        ...mockIssueApiData[0],
        created_at: "2025-01-01T00:00:00Z",
      },
      {
        ...mockIssueApiData[1],
        created_at: "2024-12-25T12:30:00Z",
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: issuesWithDifferentDates,
        total: 2,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: issuesWithDifferentDates,
        total: 2,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("2");
  });
});

describe("Advanced Filter Combinations", () => {
  beforeEach(() => {
    mockUseTableColumns = jest.requireMock("@/hooks/useTableColumns").useTableColumns as jest.MockedFunction<any>;
    mockUseSearchParams = jest.requireMock("react-router-dom").useSearchParams as jest.MockedFunction<any>;
    mockDrivingRiskService = jest.requireMock("@/lib/apiServices").drivingRiskService;
    const mockSearchParams = new URLSearchParams();
    const mockSetSearchParams = jest.fn();
    mockUseSearchParams.mockReturnValue([mockSearchParams, mockSetSearchParams]);
    mockUseTableColumns.mockReturnValue({
      columns: [],
      saveColumns: jest.fn(),
      resetColumns: jest.fn(),
    });
    mockDrivingRiskService.getMaterialDrivingRisk.mockResolvedValue({
      data: {
        success: true,
        data: [],
      },
    });
    mockUseGranularityIssuesQuery.mockReturnValue(createMockQueryReturn());
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(createMockInfiniteQueryReturn());
  });

  it("handles multiple filters applied simultaneously", () => {
    const multipleFilters = {
      group: "SGS",
      effective_risk_adjusted_value_min: 10000,
      effective_risk_adjusted_value_max: 100000,
      ordering: "-effective_dollars_at_risk",
    };

    mockUseGranularityIssueFilters.mockReturnValue({
      filters: multipleFilters,
      setFilters: jest.fn(),
    });

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("applied-filters")).toBeInTheDocument();
  });

  it("handles filter removal one by one", async () => {
    const mockSetFilters = jest.fn();
    const filtersWithMultiple = {
      group: "SGS",
      effective_risk_adjusted_value_min: 10000,
    };

    mockUseGranularityIssueFilters.mockReturnValue({
      filters: filtersWithMultiple,
      setFilters: mockSetFilters,
    });

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("applied-filters")).toBeInTheDocument();
  });

  it("handles ordering/sorting changes", () => {
    const filtersWithOrdering = {
      ...defaultFilters,
      ordering: "effective_risk_rating",
    };

    mockUseGranularityIssueFilters.mockReturnValue({
      filters: filtersWithOrdering,
      setFilters: jest.fn(),
    });

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(mockUseGranularityIssuesQuery).toHaveBeenCalled();
  });

  it("handles range filter boundaries correctly", () => {
    const rangeFilters = {
      ...defaultFilters,
      effective_risk_adjusted_value_min: 0,
      effective_risk_adjusted_value_max: 1000000000,
    };

    mockUseGranularityIssueFilters.mockReturnValue({
      filters: rangeFilters,
      setFilters: jest.fn(),
    });

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(mockUseGranularityIssuesQuery).toHaveBeenCalled();
  });
});

describe("Advanced Table View Scenarios", () => {
  beforeEach(() => {
    mockUseTableColumns = jest.requireMock("@/hooks/useTableColumns").useTableColumns as jest.MockedFunction<any>;
    mockUseSearchParams = jest.requireMock("react-router-dom").useSearchParams as jest.MockedFunction<any>;
    mockUseGranularityIssuesQuery.mockReturnValue(createMockQueryReturn());
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(createMockInfiniteQueryReturn());
  });

  it("table view displays all columns correctly", async () => {
    const mockSearchParams = new URLSearchParams();
    mockSearchParams.set("view", "table");
    mockUseSearchParams.mockReturnValue([mockSearchParams, jest.fn()]);

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    await waitFor(() => {
      expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
    });
  });

  it("handles sorting in table view", async () => {
    const mockSearchParams = new URLSearchParams();
    mockSearchParams.set("view", "table");
    mockUseSearchParams.mockReturnValue([mockSearchParams, jest.fn()]);

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    await waitFor(() => {
      expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
    });
  });
});

describe("Advanced Error Handling and Edge Cases", () => {
  beforeEach(() => {
    mockUseTableColumns = jest.requireMock("@/hooks/useTableColumns").useTableColumns as jest.MockedFunction<any>;
    mockUseSearchParams = jest.requireMock("react-router-dom").useSearchParams as jest.MockedFunction<any>;
    mockDrivingRiskService = jest.requireMock("@/lib/apiServices").drivingRiskService;
    const mockSearchParams = new URLSearchParams();
    const mockSetSearchParams = jest.fn();
    mockUseSearchParams.mockReturnValue([mockSearchParams, mockSetSearchParams]);
    mockUseTableColumns.mockReturnValue({
      columns: [],
      saveColumns: jest.fn(),
      resetColumns: jest.fn(),
    });
    mockDrivingRiskService.getMaterialDrivingRisk.mockResolvedValue({
      data: {
        success: true,
        data: [],
      },
    });
    mockUseGranularityIssuesQuery.mockReturnValue(createMockQueryReturn());
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(createMockInfiniteQueryReturn());
  });

  it("handles API errors gracefully", () => {
    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: [],
        total: 0,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: [],
        total: 0,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("0");
  });

  it("handles network timeout scenarios", () => {
    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: [],
        isLoading: true,
        isFetching: true,
        isPending: true,
        total: 0,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: [],
        isLoading: true,
        isFetching: true,
        isPending: true,
        total: 0,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("loading-state")).toHaveTextContent("Loading");
  });

  it("handles malformed issue data", () => {
    const malformedIssue = [
      {
        ...mockIssueApiData[0],
        material: {
          ...mockIssueApiData[0].material,
          risk_rating: null as any, // Malformed data
        },
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: malformedIssue,
        total: 1,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: malformedIssue,
        total: 1,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    // Should handle gracefully
    expect(screen.getByTestId("data-count")).toHaveTextContent("1");
  });

  it("handles extremely long product names", () => {
    const longNameIssue = [
      {
        ...mockIssueApiData[0],
        material: {
          ...mockIssueApiData[0].material,
          name: "A".repeat(500), // Very long name
        },
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: longNameIssue,
        total: 1,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: longNameIssue,
        total: 1,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("1");
  });

  it("handles special characters in material numbers", () => {
    const specialCharIssue = [
      {
        ...mockIssueApiData[0],
        material: {
          ...mockIssueApiData[0].material,
          ndc: "12345-678-90",
          mat_nbr: "MAT-001/ABC@2024",
          ean_n4_nbr_11: "12345-67890",
          xplant_mat_stat: "AC",
        },
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: specialCharIssue,
        total: 1,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: specialCharIssue,
        total: 1,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("1");
  });
});

describe("Advanced User Workflows", () => {
  beforeEach(() => {
    mockUseTableColumns = jest.requireMock("@/hooks/useTableColumns").useTableColumns as jest.MockedFunction<any>;
    mockUseSearchParams = jest.requireMock("react-router-dom").useSearchParams as jest.MockedFunction<any>;
    mockDrivingRiskService = jest.requireMock("@/lib/apiServices").drivingRiskService;
    const mockSearchParams = new URLSearchParams();
    const mockSetSearchParams = jest.fn();
    mockUseSearchParams.mockReturnValue([mockSearchParams, mockSetSearchParams]);
    mockUseTableColumns.mockReturnValue({
      columns: [],
      saveColumns: jest.fn(),
      resetColumns: jest.fn(),
    });
    mockDrivingRiskService.getMaterialDrivingRisk.mockResolvedValue({
      data: {
        success: true,
        data: [],
      },
    });
    mockUseGranularityIssuesQuery.mockReturnValue(createMockQueryReturn());
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(createMockInfiniteQueryReturn());
  });

  it("complete workflow: load page, apply filter, switch view, paginate", async () => {
    const mockSetFilters = jest.fn();
    mockUseGranularityIssueFilters.mockReturnValue({
      filters: defaultFilters,
      setFilters: mockSetFilters,
    });

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: mockIssueApiData,
        hasMore: true,
        total: 50,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: mockIssueApiData,
        hasMore: true,
        total: 50,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    // Step 1: Page loads
    expect(screen.getByTestId("dashboard-layout")).toBeInTheDocument();
    expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
  });

  it("workflow: filter by group", async () => {
    const mockSetFilters = jest.fn();
    mockUseGranularityIssueFilters.mockReturnValue({
      filters: {
        ...defaultFilters,
        group: "SGS",
      },
      setFilters: mockSetFilters,
    });

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("applied-filters")).toBeInTheDocument();
  });

  it("workflow: change page size and verify reset", async () => {
    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
  });
});

describe("Component Lifecycle and Re-rendering", () => {
  beforeEach(() => {
    mockUseTableColumns = jest.requireMock("@/hooks/useTableColumns").useTableColumns as jest.MockedFunction<any>;
    mockUseSearchParams = jest.requireMock("react-router-dom").useSearchParams as jest.MockedFunction<any>;
    mockDrivingRiskService = jest.requireMock("@/lib/apiServices").drivingRiskService;
    const mockSearchParams = new URLSearchParams();
    const mockSetSearchParams = jest.fn();
    mockUseSearchParams.mockReturnValue([mockSearchParams, mockSetSearchParams]);
    mockUseTableColumns.mockReturnValue({
      columns: [],
      saveColumns: jest.fn(),
      resetColumns: jest.fn(),
    });
    mockDrivingRiskService.getMaterialDrivingRisk.mockResolvedValue({
      data: {
        success: true,
        data: [],
      },
    });
    mockUseGranularityIssuesQuery.mockReturnValue(createMockQueryReturn());
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(createMockInfiniteQueryReturn());
  });

  it("handles multiple re-renders without issues", () => {
    const { rerender } = render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("2");

    // Force re-render
    rerender(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("2");
  });

  it("properly cleans up on unmount", () => {
    const { unmount } = render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("dashboard-layout")).toBeInTheDocument();

    // Unmount the component
    unmount();

    // Should not crash
    expect(screen.queryByTestId("dashboard-layout")).not.toBeInTheDocument();
  });

  it("handles rapid filter changes", async () => {
    const mockSetFilters = jest.fn();
    mockUseGranularityIssueFilters.mockReturnValue({
      filters: defaultFilters,
      setFilters: mockSetFilters,
    });

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-view-layout")).toBeInTheDocument();
  });
});

describe("Driving Risk Label Transformation", () => {
  beforeEach(() => {
    mockUseTableColumns = jest.requireMock("@/hooks/useTableColumns").useTableColumns as jest.MockedFunction<any>;
    mockUseSearchParams = jest.requireMock("react-router-dom").useSearchParams as jest.MockedFunction<any>;
    mockDrivingRiskService = jest.requireMock("@/lib/apiServices").drivingRiskService;
    const mockSearchParams = new URLSearchParams();
    const mockSetSearchParams = jest.fn();
    mockUseSearchParams.mockReturnValue([mockSearchParams, mockSetSearchParams]);
    mockUseTableColumns.mockReturnValue({
      columns: [],
      saveColumns: jest.fn(),
      resetColumns: jest.fn(),
    });
    mockDrivingRiskService.getMaterialDrivingRisk.mockResolvedValue({
      data: {
        success: true,
        data: [],
      },
    });
    mockUseGranularityIssuesQuery.mockReturnValue(createMockQueryReturn());
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(createMockInfiniteQueryReturn());
  });

  it("correctly transforms all driving risk labels", () => {
    const issuesWithAllRisks = [
      {
        ...mockIssueApiData[0],
        material: { ...mockIssueApiData[0].material, driving_risk: "Supply" },
      },
      {
        ...mockIssueApiData[1],
        material: { ...mockIssueApiData[1].material, driving_risk: "Quality" },
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: issuesWithAllRisks,
        total: 2,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: issuesWithAllRisks,
        total: 2,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    // Labels should be transformed by getEnrichedMetadata (risk-model-description API)
    expect(screen.getByTestId("data-count")).toHaveTextContent("2");
  });

  it("handles unknown driving risk labels", () => {
    const unknownRiskIssue = [
      {
        ...mockIssueApiData[0],
        material: {
          ...mockIssueApiData[0].material,
          driving_risk: "UnknownRiskType",
        },
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: unknownRiskIssue,
        total: 1,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: unknownRiskIssue,
        total: 1,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("1");
  });

  it("handles empty issues state", () => {
    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: [],
        total: 0,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: [],
        total: 0,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("0");
  });

  it("identifies issues created at midnight as new", () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const midnightIssue = [
      {
        ...mockIssueApiData[0],
        created_at: today.toISOString(),
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: midnightIssue,
        total: 1,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: midnightIssue,
        total: 1,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    // Should still be marked as new issue
    expect(screen.getByTestId("data-count")).toHaveTextContent("1");
  });

  it("handles timezone differences correctly", () => {
    const timezoneIssue = [
      {
        ...mockIssueApiData[0],
        created_at: "2025-01-15T00:00:00+05:30", // India timezone
      },
    ];

    mockUseGranularityIssuesQuery.mockReturnValue(
      createMockQueryReturn({
        issues: timezoneIssue,
        total: 1,
      })
    );
    mockUseGranularityIssuesInfiniteQuery.mockReturnValue(
      createMockInfiniteQueryReturn({
        issues: timezoneIssue,
        total: 1,
      })
    );

    render(
      <TestWrapper>
        <ReactPage />
      </TestWrapper>
    );

    expect(screen.getByTestId("data-count")).toHaveTextContent("1");
  });
});
