import "@testing-library/jest-dom";
import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter, Routes, Route } from "react-router-dom";
import React from "react";

import IssueDrillThroughPage from "../IssueDrillThroughPage";
import type { IssueImpactedMaterialApiData } from "@/types/granularityIssue";

const mockNavigate = jest.fn();
const mockActionClick = jest.fn();
const mockImpactedQuery = jest.fn();
const mockFilterRangesQuery = jest.fn();
const mockRemoveMutate = jest.fn();

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: () => mockNavigate,
}));

jest.mock("@/contexts/AuthContext", () => ({
  useAuth: () => ({ user: { entra_id: "user-entra-id" }, isAuthenticated: true, isLoading: false }),
}));

jest.mock("@/tenant", () => ({
  ...jest.requireActual("@/tenant"),
  useTenantContextQuery: jest.fn(() => ({
    data: jest.requireActual("@/tenant").getTenantPortalFlags("customer"),
  })),
}));

jest.mock("@/components/templates/DashboardLayout", () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock("@/components/atoms/Filters", () => ({
  __esModule: true,
  default: ({ filters, setFilters }: { filters: Record<string, unknown>; setFilters: (f: Record<string, unknown>) => void }) => (
    <div data-testid="filters">
      <span>Sort</span>
      <button
        type="button"
        data-testid="set-risk-rating-min"
        onClick={() => setFilters({ ...filters, risk_rating_min: 0.5, risk_rating_max: 1 })}
      >
        Set risk range
      </button>
    </div>
  ),
}));

jest.mock("@/hooks", () => ({
  useRiskModelDescriptions: () => ({ getEnrichedMetadata: (t: string) => ({ display_name: t }) }),
}));

const materials: IssueImpactedMaterialApiData[] = [
  {
    id: 1,
    mat_nbr: "MAT-1",
    name: "Alpha",
    ndc: "1",
    vendor: "V1",
    vendor_nbr: "N1",
    risk_rating: 0.9,
    driving_risk: "x",
    dollars_at_risk: 10,
    unfilled_qty: 212,
  },
  {
    id: 2,
    mat_nbr: "MAT-2",
    name: "Beta",
    ndc: "2",
    vendor: "V2",
    vendor_nbr: "N2",
    risk_rating: 0.5,
    driving_risk: "x",
    dollars_at_risk: 20,
  },
  {
    id: 3,
    mat_nbr: "MAT-3",
    name: "Gamma",
    ndc: "3",
    vendor: "V3",
    vendor_nbr: "N3",
    risk_rating: 0.3,
    driving_risk: "x",
    dollars_at_risk: 30,
  },
];

const defaultRecordedActions = [
  {
    id: 456,
    user_id: "user-entra-id",
    action: null,
    created_at: "2026-06-01T10:00:00Z",
    user: { id: "user-entra-id", first_name: "Jane", last_name: "Doe" },
    potential_action: { recommendation_type_nbr: "26", paction_nbr: "PA-1" },
  },
];

const defaultPotentialActions = [
  {
    id: 1,
    paction_nbr: "PA-1",
    issue_nbr: "ISS-749539",
    action_type: "Operational",
    recommendation: "Put Item to Bid",
    recommendation_type_nbr: "26",
    action_category: "Strategic",
    recommended_action_flag: true,
    status: null,
    module: "React",
    created_at: "",
    updated_at: "",
    material: "",
  },
  {
    id: 2,
    paction_nbr: "PA-2",
    issue_nbr: "ISS-749539",
    action_type: "Operational",
    recommendation: "Allocate",
    recommendation_type_nbr: "27",
    action_category: "Tactical",
    recommended_action_flag: false,
    status: null,
    module: "React",
    created_at: "",
    updated_at: "",
    material: "",
  },
];

let mockRecordedActions = defaultRecordedActions;
let mockPotentialActions = defaultPotentialActions;

jest.mock("@/components/atoms", () => ({
  Pagination: ({
    currentPage,
    total,
    onPageChange,
  }: {
    currentPage: number;
    total: number;
    onPageChange: (page: number) => void;
  }) => (
    <div data-testid="pagination">
      <span>
        Page {currentPage} of {total}
      </span>
      <button type="button" data-testid="page-2" onClick={() => onPageChange(2)}>
        Go to page 2
      </button>
    </div>
  ),
}));

jest.mock("@/hooks/queries", () => ({
  useGranularityIssueByIdQuery: () => ({
    issue: {
      id: 1783,
      issue_nbr: "ISS-749539",
      granularity_type: "gcn",
      fdb_gcn_seq_nbr: "635410",
      status: "OPEN",
      date_identified: "2026-06-24",
      impacted_material_count: 3,
      effective_risk_rating: 0.87,
      effective_dollars_at_risk: 60,
      effective_risk_adjusted_value: 52,
      driving_event: null,
      actions: mockRecordedActions,
      potential_actions: mockPotentialActions,
      material: null,
      group: "Ops",
      persona: "Analyst",
    },
    isLoading: false,
  }),
  useIssueImpactedMaterialsQuery: (args: unknown) => {
    mockImpactedQuery(args);
    return {
      materials,
      total: 3,
      isLoading: false,
      isPlaceholderData: false,
      isFetching: false,
    };
  },
  useIssueDrivingEventQuery: () => ({ event: null, isLoading: false, isFetching: false }),
  useFilterRangesQuery: (args: unknown) => {
    mockFilterRangesQuery(args);
    return {
      maxes: { risk_adjusted_value: 14649, dollars_at_risk: 77096 },
      ranges: {},
      getMax: (_k: string, fb?: number) => fb ?? 0,
      isLoading: false,
      isFetching: false,
      isSuccess: true,
      isError: false,
      error: null,
      refetch: jest.fn(),
    };
  },
}));

jest.mock("@/hooks/queries/useRemoveActionMutation", () => ({
  __esModule: true,
  default: () => ({
    mutate: mockRemoveMutate,
    isPending: false,
  }),
}));

jest.mock("@/hooks/useIssueActionFlow", () => ({
  useIssueActionFlow: () => ({
    modalState: { type: "closed" },
    isActionMutationPending: false,
    handleActionClick: (...a: unknown[]) => mockActionClick(...a),
    handleKeepInMindContinue: jest.fn(),
    closeModal: jest.fn(),
  }),
  NO_ACTION_TYPE: "no_action_required",
  SWITCH_MANUFACTURER_TYPE: "31",
}));

function renderPage() {
  return render(
    <MemoryRouter initialEntries={["/react/issue/1783"]}>
      <Routes>
        <Route path="/react/issue/:issueId" element={<IssueDrillThroughPage />} />
      </Routes>
    </MemoryRouter>
  );
}

describe("IssueDrillThroughPage", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockRecordedActions = defaultRecordedActions;
    mockPotentialActions = defaultPotentialActions;
  });

  it("renders the issue summary with grain and materials-affected count", () => {
    renderPage();
    // Level chip shows the grain label + mono grain identifier
    expect(screen.getAllByText("Product Family").length).toBeGreaterThan(0);
    expect(screen.getAllByText("635410").length).toBeGreaterThan(0);
    expect(screen.getByText("Materials Affected")).toBeInTheDocument();
    // Facts
    expect(screen.getByText("Ops")).toBeInTheDocument();
    expect(screen.getByText("Analyst")).toBeInTheDocument();
  });

  it("selects all impacted materials by default", () => {
    renderPage();
    expect(screen.getByText(/3 of 3 on this page · 3 of 3 total selected/)).toBeInTheDocument();
    expect(screen.getByText("Alpha")).toBeInTheDocument();
    expect(screen.getByText("Gamma")).toBeInTheDocument();
  });

  it("shows the unfilled quantity for each impacted material", () => {
    renderPage();
    expect(screen.getByText("Unfilled Qty")).toBeInTheDocument();
    expect(screen.getByText("212")).toBeInTheDocument();
  });

  it("queries impacted materials with the default risk-adjusted-value ordering and a filter bar", () => {
    renderPage();
    // The impacted-materials query is called with the default ordering.
    expect(mockImpactedQuery).toHaveBeenCalledWith(
      expect.objectContaining({ filters: expect.objectContaining({ ordering: "-risk_adjusted_value" }) })
    );
    // The shared Filters Sort control is rendered for the materials panel.
    expect(screen.getByTestId("filters")).toBeInTheDocument();
    expect(screen.getByText("Sort")).toBeInTheDocument();
  });

  it("passes range filters to the impacted-materials query when the filter bar changes", () => {
    renderPage();
    fireEvent.click(screen.getByTestId("set-risk-rating-min"));
    expect(mockImpactedQuery).toHaveBeenLastCalledWith(
      expect.objectContaining({
        filters: expect.objectContaining({
          ordering: "-risk_adjusted_value",
          risk_rating_min: 0.5,
          risk_rating_max: 1,
        }),
      })
    );
  });

  it("loads slider bounds from issue_impacted_materials filter-ranges scoped by issue_id", () => {
    renderPage();
    expect(mockFilterRangesQuery).toHaveBeenCalledWith(
      expect.objectContaining({
        module: "issue_impacted_materials",
        keys: ["risk_adjusted_value", "dollars_at_risk"],
        params: { issue_id: 1783 },
        enabled: true,
      })
    );
  });

  it("excludes a material when its checkbox is unchecked", () => {
    renderPage();
    const checkboxes = screen.getAllByRole("checkbox");
    fireEvent.click(checkboxes[0]);
    expect(screen.getByText(/2 of 3 on this page · 2 of 3 total selected/)).toBeInTheDocument();
    expect(screen.getByText(/1 excluded/)).toBeInTheDocument();
  });

  it("requests paginated impacted materials", () => {
    renderPage();
    expect(mockImpactedQuery).toHaveBeenCalledWith(expect.objectContaining({ page: 1, pageSize: 50, issueId: 1783 }));
    fireEvent.click(screen.getByTestId("page-2"));
    expect(mockImpactedQuery).toHaveBeenLastCalledWith(expect.objectContaining({ page: 2, pageSize: 50 }));
  });

  it("does not preselect any action on first visit", () => {
    mockRecordedActions = [];
    renderPage();
    expect(screen.getByText("Select a recommended action")).toBeInTheDocument();
    expect(screen.queryByRole("button", { pressed: true })).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Apply to 3 materials/ })).toBeDisabled();
  });

  it("does not auto-select an action when one has already been recorded", () => {
    renderPage();
    expect(screen.getByText("Select a recommended action")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Apply to 3 materials/ })).toBeDisabled();
  });

  it("applies a recommended action after the user explicitly selects one", () => {
    renderPage();
    fireEvent.click(screen.getByRole("button", { name: /Allocate/ }));
    fireEvent.click(screen.getByRole("button", { name: /Apply to 3 materials/ }));
    expect(mockActionClick).toHaveBeenCalledWith("27", expect.objectContaining({ paction_nbr: "PA-2" }));
  });

  it("deselects the chosen action when its button is clicked again", () => {
    renderPage();
    fireEvent.click(screen.getByRole("button", { name: /Allocate/ }));
    expect(screen.getByText(/Selected action: Allocate/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /Allocate/ }));
    expect(screen.getByText("Select a recommended action")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Apply to 3 materials/ })).toBeDisabled();
  });

  it("selects only one action when multiple recommendations share the same type", () => {
    mockRecordedActions = [];
    mockPotentialActions = [
      {
        id: 1,
        paction_nbr: "PA-1",
        issue_nbr: "ISS-749539",
        action_type: "Operational",
        recommendation: "Action A",
        recommendation_type_nbr: "26",
        action_category: "Strategic",
        recommended_action_flag: true,
        status: null,
        module: "React",
        created_at: "",
        updated_at: "",
        material: "",
      },
      {
        id: 2,
        paction_nbr: "PA-2",
        issue_nbr: "ISS-749539",
        action_type: "Operational",
        recommendation: "Action B",
        recommendation_type_nbr: "26",
        action_category: "Tactical",
        recommended_action_flag: true,
        status: null,
        module: "React",
        created_at: "",
        updated_at: "",
        material: "",
      },
      {
        id: 3,
        paction_nbr: "PA-3",
        issue_nbr: "ISS-749539",
        action_type: "Operational",
        recommendation: "Action C",
        recommendation_type_nbr: "26",
        action_category: "Operational",
        recommended_action_flag: true,
        status: null,
        module: "React",
        created_at: "",
        updated_at: "",
        material: "",
      },
      {
        id: 4,
        paction_nbr: "PA-4",
        issue_nbr: "ISS-749539",
        action_type: "Operational",
        recommendation: "Action D",
        recommendation_type_nbr: "26",
        action_category: "Operational",
        recommended_action_flag: true,
        status: null,
        module: "React",
        created_at: "",
        updated_at: "",
        material: "",
      },
    ];
    renderPage();
    expect(screen.queryByRole("button", { pressed: true })).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /Action B/ }));
    expect(screen.getAllByRole("button", { pressed: true })).toHaveLength(1);
    expect(screen.getByText(/Selected action: Action B/)).toBeInTheDocument();
  });

  it("lists recommended actions grouped by category, without RECOMMENDED/OPENS ANALYSIS badges, and marks who took an action", () => {
    renderPage();
    expect(screen.getByText("Put Item to Bid")).toBeInTheDocument();
    expect(screen.getByText("Allocate")).toBeInTheDocument();
    // Grouped under their action_category headers
    expect(screen.getByText("Strategic")).toBeInTheDocument();
    expect(screen.getByText("Tactical")).toBeInTheDocument();
    expect(screen.queryByText("RECOMMENDED")).not.toBeInTheDocument();
    expect(screen.queryByText("OPENS ANALYSIS")).not.toBeInTheDocument();
    expect(screen.getByText(/Taken by Jane Doe/)).toBeInTheDocument();
  });

  it("blocks re-taking an action that has already been recorded", () => {
    renderPage();
    const putToBidButtons = screen.getAllByRole("button", { name: /Put Item to Bid/ });
    expect(putToBidButtons[0]).toBeDisabled();
    expect(screen.getByRole("button", { name: /Allocate/ })).toBeEnabled();
  });

  it("marks only the taken paction_nbr when multiple recommendations share a type", () => {
    mockRecordedActions = [
      {
        id: 456,
        user_id: "user-entra-id",
        action: null,
        created_at: "2026-06-01T10:00:00Z",
        user: { id: "user-entra-id", first_name: "Jane", last_name: "Doe" },
        potential_action: { recommendation_type_nbr: "26", paction_nbr: "PA-3" },
      },
    ];
    mockPotentialActions = [
      {
        id: 1,
        paction_nbr: "PA-1",
        issue_nbr: "ISS-749539",
        action_type: "Operational",
        recommendation: "Strategic same type",
        recommendation_type_nbr: "26",
        action_category: "Strategic",
        recommended_action_flag: true,
        status: null,
        module: "React",
        created_at: "",
        updated_at: "",
        material: "",
      },
      {
        id: 2,
        paction_nbr: "PA-2",
        issue_nbr: "ISS-749539",
        action_type: "Operational",
        recommendation: "Another strategic same type",
        recommendation_type_nbr: "26",
        action_category: "Strategic",
        recommended_action_flag: false,
        status: null,
        module: "React",
        created_at: "",
        updated_at: "",
        material: "",
      },
      {
        id: 3,
        paction_nbr: "PA-3",
        issue_nbr: "ISS-749539",
        action_type: "Operational",
        recommendation: "Operational same type",
        recommendation_type_nbr: "26",
        action_category: "Operational",
        recommended_action_flag: false,
        status: null,
        module: "React",
        created_at: "",
        updated_at: "",
        material: "",
      },
    ];
    renderPage();

    expect(screen.getByRole("button", { name: /Strategic same type/ })).toBeEnabled();
    expect(screen.getByRole("button", { name: /Another strategic same type/ })).toBeEnabled();
    const operationalButtons = screen.getAllByRole("button", { name: /Operational same type/ });
    expect(operationalButtons[0]).toBeDisabled();
    expect(screen.getByText(/Taken by Jane Doe/)).toBeInTheDocument();
  });

  it("opens the material-centric detail (not the issue page) when an impacted material row is clicked", () => {
    renderPage();
    fireEvent.click(screen.getByText("Alpha"));
    expect(mockNavigate).toHaveBeenCalledTimes(1);
    const [url, options] = mockNavigate.mock.calls[0];
    expect(url).toContain("/react/material/1");
    expect(options?.state).toMatchObject({ from: "issue", originIssueId: 1783 });
  });

  it("shows Delete Action next to a taken action when the user owns it", () => {
    renderPage();
    expect(screen.getByRole("button", { name: /Delete Put Item to Bid action/ })).toBeInTheDocument();
  });

  it("calls logical delete with issue id and part number when Delete Action is confirmed", () => {
    renderPage();
    fireEvent.click(screen.getByRole("button", { name: /Delete Put Item to Bid action/ }));
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    expect(mockRemoveMutate).toHaveBeenCalledWith({ actionId: 456, issueId: 1783, partNumber: "PA-1" }, expect.any(Object));
  });
});
