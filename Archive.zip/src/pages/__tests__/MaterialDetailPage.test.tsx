import "@testing-library/jest-dom";
import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter, Routes, Route } from "react-router-dom";
import React from "react";

import MaterialDetailPage from "../MaterialDetailPage";

const mockNavigate = jest.fn();

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: () => mockNavigate,
}));

jest.mock("@/components/templates/DashboardLayout", () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock("@/hooks", () => ({
  useRiskModelDescriptions: () => ({ enrichRiskData: (d: unknown) => d ?? [], getEnrichedMetadata: (t: string) => ({ display_name: t }) }),
}));

jest.mock("@/hooks/queries", () => ({
  useMaterialSubstituteDetailsQuery: () => ({
    details: {
      material: {
        id: 421,
        mat_nbr: "MAT-1",
        name: "Example Drug 50mg",
        ndc: "12345-678-90",
        risk_rating: 0.8,
        dollars_at_risk: 1000,
        vendor: { id: 7, name: "Acme Pharma", vendor_nbr: "V-9" },
      },
      material_formularies: [],
      available_plants_count: 0,
    },
    isLoading: false,
  }),
  useMaterialRiskQuery: () => ({ riskData: [], isLoading: false }),
  useMaterialRiskWeeklyAveragesQuery: () => ({ weeklyData: null, isLoading: false }),
  useMaterialActionHistoryQuery: () => ({ actions: [], total: 0, isLoading: false, isFetching: false }),
  useMaterialSupplyChainEventsQuery: () => ({ events: [], isLoading: false, isFetching: false }),
}));

// Stub the heavy tab bodies + header; keep MaterialDrillTabs real so we assert the tab set.
jest.mock("@/components/material-drill-through/MaterialSummaryHeader", () => ({
  MaterialSummaryHeader: ({ name }: { name: string }) => <h1>{name}</h1>,
}));
jest.mock("@/components/material-drill-through/DrivingRiskEventsTimeline", () => ({
  DrivingRiskEventsTimeline: () => <div data-testid="risk-contributors" />,
}));
jest.mock("@/components/material-drill-through/MaterialRiskScoreChart", () => ({
  MaterialRiskScoreChart: () => <div data-testid="risk-chart" />,
}));
jest.mock("@/components/material-drill-through/MaterialEventsPanel", () => ({
  MaterialEventsPanel: () => <div data-testid="material-events" />,
}));
jest.mock("@/components/material-drill-through/MaterialProfileCard", () => ({
  MaterialProfileCard: () => <div data-testid="material-profile" />,
}));
jest.mock("@/components/material-drill-through/VendorProfileCard", () => ({
  VendorProfileCard: () => <div data-testid="vendor-profile" />,
}));
jest.mock("@/components/material-drill-through/ActionHistoryPanel", () => ({
  ActionHistoryPanel: () => <div data-testid="action-history" />,
}));

function renderPage(initialEntry = { pathname: "/react/material/421", search: "?matNbr=MAT-1" }, state?: unknown) {
  return render(
    <MemoryRouter initialEntries={[{ ...initialEntry, state }]}>
      <Routes>
        <Route path="/react/material/:materialId" element={<MaterialDetailPage />} />
      </Routes>
    </MemoryRouter>
  );
}

describe("MaterialDetailPage", () => {
  beforeEach(() => jest.clearAllMocks());

  it("renders the inspect-only tab set (no Notes tab)", () => {
    renderPage();
    expect(screen.getByText("Driving Risk & Contributors")).toBeInTheDocument();
    expect(screen.getByText("Material & Supplier Profile")).toBeInTheDocument();
    expect(screen.getByText("Action History")).toBeInTheDocument();
    expect(screen.queryByText("Notes")).not.toBeInTheDocument();
    expect(screen.queryByText("Actions & History")).not.toBeInTheDocument();
  });

  it("defaults to the Risk & Contributors tab with material events + contributors + trend", () => {
    renderPage();
    expect(screen.getByTestId("material-events")).toBeInTheDocument();
    expect(screen.getByTestId("risk-contributors")).toBeInTheDocument();
    expect(screen.getByTestId("risk-chart")).toBeInTheDocument();
  });

  it("shows the Action History tab (read-only) with no take-action card", () => {
    renderPage({ pathname: "/react/material/421", search: "?matNbr=MAT-1&tab=actions" });
    expect(screen.getByTestId("action-history")).toBeInTheDocument();
    // No recommended-actions / take-action affordance on this page.
    expect(screen.queryByText(/Recommended Actions/i)).not.toBeInTheDocument();
  });

  it("coerces a stale ?tab=notes to the first visible tab", () => {
    renderPage({ pathname: "/react/material/421", search: "?tab=notes&matNbr=MAT-1" });
    // Notes body would be action-history/profile; risk tab is the fallback.
    expect(screen.getByTestId("material-events")).toBeInTheDocument();
  });

  it("renders the material name in the header", () => {
    renderPage();
    expect(screen.getByRole("heading", { name: "Example Drug 50mg" })).toBeInTheDocument();
  });

  it("shows 'Back to issue' and navigates to the origin issue when arriving from one", () => {
    renderPage({ pathname: "/react/material/421", search: "?matNbr=MAT-1" }, { from: "issue", originIssueId: 55 });
    const back = screen.getByRole("button", { name: /Back to issue/ });
    fireEvent.click(back);
    expect(mockNavigate).toHaveBeenCalledWith("/react/issue/55");
  });

  it("shows 'Back to React' when not arriving from an issue", () => {
    renderPage();
    expect(screen.getByRole("button", { name: /Back to React/ })).toBeInTheDocument();
  });
});
