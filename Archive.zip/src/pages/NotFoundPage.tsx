import { buttonStyles, Typography } from "@/components/atoms";
import { DashboardLayout } from "@/components/templates";
import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <DashboardLayout>
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <Typography variant="h1" className="text-6xl font-bold text-ui-text-muted mb-4">
          404
        </Typography>

        <Typography variant="h2" className="text-2xl font-semibold text-ui-text-primary mb-2">
          Page Not Found
        </Typography>

        <Typography variant="body1" color="secondary" className="mb-8 max-w-md">
          The page you're looking for doesn't exist or has been moved.
        </Typography>

        <Link to="/" className={buttonStyles()}>
          Return to Dashboard
        </Link>
      </div>
    </DashboardLayout>
  );
}
