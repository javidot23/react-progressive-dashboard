import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import Logo from "@/assets/icons/white-logo.svg";
import CopyrightIcon from "@/assets/icons/c-icon.svg";

export default function LoginPage() {
  const { login, isAuthenticated, isLoading, error } = useAuth();
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated && !isLoading) {
      navigate('/overview', { replace: true });
    }
  }, [isAuthenticated, isLoading, navigate]);

  const handleLogin = () => {
    setIsLoggingIn(true);
    login();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen relative overflow-hidden bg-[url('/src/public/images/login-disclaimer-bg.jpg')] bg-no-repeat bg-cover bg-center">
        <div className="absolute inset-0"></div>
        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
          <div className="animate-spin rounded-full h-20 w-20 sm:h-32 sm:w-32 border-b-2 border-white"></div>
          <p className="text-white mt-4 text-sm sm:text-base text-center px-4">
            Loading...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative overflow-hidden bg-[url('/src/public/images/login-disclaimer-bg.jpg')] bg-no-repeat bg-cover bg-center">
      <div className="absolute inset-0"></div>
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 sm:px-6">
        <div className="mb-4 sm:mb-6">
          <img src={Logo} alt="logo" width={224} height={32} className="my-5 w-[160px] sm:w-[200px] md:w-[224px] h-auto" />
        </div>
        <div className="flex flex-col space-y-4 sm:space-y-6 bg-white rounded-md w-full max-w-[340px] sm:max-w-[420px] md:max-w-[491px] min-h-[160px] shadow-xl px-4 sm:px-6 md:px-8 py-5 sm:py-6">
          <div className="text-base sm:text-lg text-[#1E1E1E] font-semibold text-ui-text-primary">
            Log in
          </div>

          {error && (
            <div className="bg-red-50 border-l-4 border-red-400 p-3 sm:p-4 rounded">
              <p className="text-xs sm:text-sm text-red-700">{error}</p>
            </div>
          )}

          <button
            onClick={handleLogin}
            disabled={isLoggingIn}
            className="w-full flex flex-row items-center justify-center bg-brand-primary-main hover:bg-brand-primary-dark disabled:opacity-50 disabled:cursor-not-allowed text-white py-2.5 sm:py-3 rounded-md transition-colors duration-200 cursor-pointer"
          >
            <div className="flex flex-row items-center gap-2 font-bold text-sm sm:text-base">
              {isLoggingIn ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : null}
              <span className="whitespace-nowrap">
                {isLoggingIn ? 'Signing in...' : 'Sign In'}
              </span>
            </div>
          </button>

          <div className="text-xs sm:text-sm text-[#3B3B3B] text-center font-medium leading-relaxed">
            Contact your site administrator to request access.
          </div>
        </div>
      </div>

      <div className="absolute bottom-4 left-4 right-4 sm:left-7 sm:right-auto sm:bottom-4">
        <p className="text-[#838383] text-xs sm:text-sm flex flex-row items-center justify-center sm:justify-start gap-1">
          <img src={CopyrightIcon} alt="copyright" width={15} className="w-[12px] sm:w-[15px]" />
          <span className="text-center sm:text-left">All rights reserved to Cencora, Inc.</span>
        </p>
      </div>
    </div>
  );
}
