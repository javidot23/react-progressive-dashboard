import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import DashboardLayout from "@/components/templates/DashboardLayout";
import DataViewLayout from "@/components/templates/DataViewLayout";
import { PageTitle } from "@/components/atoms/PageTitle";
import GlobalFilters from "@/components/organisms/GlobalFilters";
import { IssueCard } from "@/components/organisms/IssueCard";
import { useGranularityIssueFilters } from "@/hooks/useGranularityIssueFilters";
import Filters from "@/components/atoms/Filters";
import AppliedFilters from "@/components/atoms/AppliedFilters";
import { granularityIssueFiltersConfig, granularityIssueAppliedFiltersConfig } from "@/lib/filterConfigs";
import IssueTableView from "@/components/molecules/IssueTableView";
import InboundServiceLevelTrend from "@/components/organisms/InboundServiceLevelTrend";
import { MainKPIs } from "@/components/organisms";
import { TableConfigurationModal } from "@/components/molecules/TableConfigurationModal";
import { useRiskModelDescriptions } from "@/hooks";
import { CreateCustomFilterModal } from "@/components/molecules/CreateCustomFilterModal";
import { ReorderTableModal } from "@/components/molecules/ReorderTableModal";
import { useTableColumns } from "@/hooks/useTableColumns";
import { useFilterRangesQuery } from "@/hooks/queries";
import { useGranularityIssuesQuery } from "@/hooks/queries/useGranularityIssuesQuery";
import { useGranularityIssuesInfiniteQuery } from "@/hooks/queries/useGranularityIssuesInfiniteQuery";
import { mapGranularityIssue, getGranularityLevelOptions } from "@/lib/granularity";
import { getGcnLabel } from "@/lib/gcnLabels";
import { resolveIssueFeedTableScope } from "@/lib/issueTableConfig";

const DEFAULT_PAGE_SIZE = 10;
const DEFAULT_PAGE = 1;
const MODULE_NAME = "React";
const LEVEL_PARAM = "level";
const VIEW_MODE = {
  CARD: "card",
  TABLE: "table",
} as const;

export function ReactPageContent() {
  const { getEnrichedMetadata } = useRiskModelDescriptions();

  const [searchParams, setSearchParams] = useSearchParams();
  const [currentPage, setCurrentPage] = useState(DEFAULT_PAGE);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { filters, setFilters } = useGranularityIssueFilters();

  const granularityLevelOptions = useMemo(() => getGranularityLevelOptions(), []);

  // Native-granularity level filter (URL param `level`; "" = All Levels).
  const granularityLevel = useMemo(() => {
    const level = searchParams.get(LEVEL_PARAM) ?? "";
    return granularityLevelOptions.some(o => o.value === level) ? level : "";
  }, [searchParams, granularityLevelOptions]);

  const tableViewScope = useMemo(() => resolveIssueFeedTableScope(granularityLevel), [granularityLevel]);
  const viewMode = (searchParams.get("view") as "card" | "table" | undefined) ?? VIEW_MODE.CARD;

  const [showTableConfigModal, setShowTableConfigModal] = useState(false);
  const [showCreateFilterModal, setShowCreateFilterModal] = useState(false);
  const [showReorderTableModal, setShowReorderTableModal] = useState(false);
  const { columns, saveColumns, resetColumns } = useTableColumns(tableViewScope);

  // Filters actually sent to the query: user filters (incl. `ordering`, set by the
  // Filters sort control) + the selected grain. fetchGranularityIssues defaults the
  // ordering to `-effective_risk_adjusted_value` when none is set.
  const queryFilters = useMemo(() => {
    const next: Record<string, unknown> = { ...filters };
    if (granularityLevel) {
      next.granularity_type = granularityLevel;
    }
    return next;
  }, [filters, granularityLevel]);

  const infiniteQuery = useGranularityIssuesInfiniteQuery({
    filters: queryFilters,
    pageSize,
    module: MODULE_NAME,
    enabled: viewMode === VIEW_MODE.CARD,
  });

  const paginatedQuery = useGranularityIssuesQuery({
    filters: queryFilters,
    page: currentPage,
    pageSize,
    module: MODULE_NAME,
    enabled: viewMode === VIEW_MODE.TABLE,
  });

  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(page);
  }, []);

  const handlePageSizeChange = useCallback((size: number) => {
    setPageSize(size);
    setCurrentPage(DEFAULT_PAGE);
  }, []);

  useEffect(() => {
    setCurrentPage(DEFAULT_PAGE);
  }, [filters, granularityLevel]);

  const handleLevelChange = useCallback(
    (level: string) => {
      const newParams = new URLSearchParams(searchParams);
      if (level) {
        newParams.set(LEVEL_PARAM, level);
      } else {
        newParams.delete(LEVEL_PARAM);
      }
      setSearchParams(newParams, { replace: true });
    },
    [searchParams, setSearchParams]
  );

  const cardIssues = useMemo(
    () => infiniteQuery.issues.map(issue => mapGranularityIssue(issue, getEnrichedMetadata)),
    [infiniteQuery.issues, getEnrichedMetadata]
  );
  const tableIssues = useMemo(
    () => paginatedQuery.issues.map(issue => mapGranularityIssue(issue, getEnrichedMetadata)),
    [paginatedQuery.issues, getEnrichedMetadata]
  );

  const activeIssuesQuery = viewMode === VIEW_MODE.CARD ? infiniteQuery : paginatedQuery;
  const rawIssues = viewMode === VIEW_MODE.CARD ? cardIssues : tableIssues;

  // Scope = filters + view (not page). When this changes, hide placeholder rows from the prior scope.
  const listScopeKey = useMemo(() => JSON.stringify({ filters: queryFilters, viewMode }), [queryFilters, viewMode]);
  const [resolvedScopeKey, setResolvedScopeKey] = useState(listScopeKey);
  const listScopeKeyRef = useRef(listScopeKey);
  listScopeKeyRef.current = listScopeKey;

  useEffect(() => {
    if (!activeIssuesQuery.isLoading && !activeIssuesQuery.isPlaceholderData) {
      setResolvedScopeKey(listScopeKeyRef.current);
    }
  }, [listScopeKey, activeIssuesQuery.isLoading, activeIssuesQuery.isPlaceholderData]);

  const isScopedRefetch = activeIssuesQuery.isPlaceholderData && resolvedScopeKey !== listScopeKey;
  const issuesReady = !activeIssuesQuery.isLoading && !isScopedRefetch;
  const displayIssues = issuesReady ? rawIssues : [];

  const hasMore = viewMode === VIEW_MODE.CARD ? infiniteQuery.hasMore : paginatedQuery.hasMore;
  const total = issuesReady ? (viewMode === VIEW_MODE.CARD ? infiniteQuery.total : paginatedQuery.total) : 0;
  const isFetchingNextPage = infiniteQuery.isFetchingNextPage;
  const fetchNextPage = infiniteQuery.fetchNextPage;
  const showIssuesLoading = activeIssuesQuery.isLoading || (isScopedRefetch && activeIssuesQuery.isFetching);

  const handleLoadMore = useCallback(() => {
    if (hasMore && !isFetchingNextPage && viewMode === VIEW_MODE.CARD && issuesReady) {
      fetchNextPage();
    }
  }, [hasMore, isFetchingNextPage, viewMode, fetchNextPage, issuesReady]);

  const { maxes: issueRangeMaxes } = useFilterRangesQuery({
    module: "all_issues",
    keys: ["effective_risk_adjusted_value", "effective_dollars_at_risk", "impacted_material_count"],
    params: granularityLevel ? { granularity_type: granularityLevel } : undefined,
  });

  const dataViewTitle = "Open Issues by Risk Exposure";

  const dataViewBadge = (
    <span className="text-sm font-bold text-[#3B3B3B] bg-white rounded-full px-2 py-1 border-1 border-[#CBD5E1]">
      {total ? `${total} Issues` : "Issues"}
    </span>
  );

  const filtersContent = (
    <div className="flex flex-col space-y-3 w-full">
      {/* Granularity level filter — sorting is handled by the Filters bar's built-in Sort control */}
      <div className="inline-flex flex-wrap w-fit rounded-[4px] items-center gap-2 border-1 border-[#CBD5E1] p-2">
        {granularityLevelOptions.map(option => (
          <button
            key={option.key}
            onClick={() => handleLevelChange(option.value)}
            className={`px-4 py-2 rounded-md text-sm font-semibold transition-colors cursor-pointer ${
              granularityLevel === option.value
                ? "bg-brand-primary-main text-white"
                : "bg-ui-background-primary text-ui-text-primary"
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>
      <Filters
        filters={filters}
        setFilters={setFilters}
        config={granularityIssueFiltersConfig}
        dynamicMaxValues={issueRangeMaxes}
      />
      <AppliedFilters filters={filters} setFilters={setFilters} config={granularityIssueAppliedFiltersConfig} />
    </div>
  );

  return (
    <>
      <MainKPIs />
      <div className="flex flex-col gap-4">
        <DataViewLayout
          title={dataViewTitle}
          subtitle={`View issues at their original granularity — from a single material up to a ${getGcnLabel()}, NDC, facility, or therapeutic class — with the driving event and aggregate exposure. Open an issue to explore every impacted material and take action.`}
          data={displayIssues}
          viewMode={viewMode}
          loading={showIssuesLoading && displayIssues.length === 0}
          hasMore={hasMore}
          onLoadMore={handleLoadMore}
          badge={dataViewBadge}
          renderCard={issue => (
            /* Recommended actions: IssueCard → drill-through (View more and take action) */
            <IssueCard key={issue.id} issue={issue} vendorId={issue.vendorId} />
          )}
          renderTable={data => (
            <IssueTableView
              data={data}
              currentPage={currentPage}
              pageSize={pageSize}
              total={total}
              onPageChange={handlePageChange}
              onPageSizeChange={handlePageSizeChange}
              viewScope={tableViewScope}
              columns={columns}
            />
          )}
          filters={filtersContent}
        />

        <InboundServiceLevelTrend />
      </div>

      {/* Table Configuration Modal */}
      <TableConfigurationModal
        isOpen={showTableConfigModal}
        onClose={() => setShowTableConfigModal(false)}
        onSelectCreateFilter={() => {
          setShowTableConfigModal(false);
          setShowCreateFilterModal(true);
        }}
        onSelectReorderTable={() => {
          setShowTableConfigModal(false);
          setShowReorderTableModal(true);
        }}
      />

      {/* Create Custom Filter Modal */}
      <CreateCustomFilterModal
        isOpen={showCreateFilterModal}
        onClose={() => setShowCreateFilterModal(false)}
        onCreate={filterData => {
          // TODO: Implement save custom filter functionality
          console.warn("Filter created:", filterData);
        }}
      />

      {/* Reorder Table Modal */}
      <ReorderTableModal
        isOpen={showReorderTableModal}
        onClose={() => setShowReorderTableModal(false)}
        columns={columns}
        onApply={saveColumns}
        onReset={resetColumns}
        viewScope={tableViewScope}
      />
    </>
  );
}

export default function ReactPage() {
  return (
    <DashboardLayout
      pageTitle={<PageTitle title="Supply Chain Resiliency Mapping" section="React" />}
      pageSubtitle="Insights and recommended actions to mitigate unexpected events in supply chain operations."
      bannerRightContent={<GlobalFilters variant="banner" />}
    >
      <ReactPageContent />
    </DashboardLayout>
  );
}
