import { useState, useEffect, useCallback, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import DashboardLayout from "@/components/templates/DashboardLayout";
import DataViewLayout from "@/components/templates/DataViewLayout";
import { PageTitle } from "@/components/atoms/PageTitle";
import GlobalFilters from "@/components/organisms/GlobalFilters";
import Filters from "@/components/atoms/Filters";
import AppliedFilters from "@/components/atoms/AppliedFilters";
import { vendorFiltersConfig, vendorAppliedFiltersConfig } from "@/lib/filterConfigs";
import VendorCardView from "@/components/molecules/VendorCardView";
import VendorTableView from "@/components/molecules/VendorTableView";
import { useVendorFilters } from "@/hooks/useVendorFilters";
import { useVendorsInfiniteQuery, useVendorsListPaginatedQuery, useFilterRangesQuery } from "@/hooks/queries";
import { MainKPIs } from "@/components/organisms";
import { useTableColumns } from "@/hooks/useTableColumns";
import { TableConfigurationModal } from "@/components/molecules/TableConfigurationModal";
import { CreateCustomFilterModal } from "@/components/molecules/CreateCustomFilterModal";
import { ReorderTableModal } from "@/components/molecules/ReorderTableModal";

const VIEW_MODE = {
  CARD: "card",
  TABLE: "table",
} as const;
const DEFAULT_PAGE_SIZE = 10;
const DEFAULT_PAGE = 1;

export default function Plan() {
  const [searchParams, setSearchParams] = useSearchParams();
  const viewMode = searchParams.get("view") as "card" | "table" | undefined;
  const [currentPage, setCurrentPage] = useState(DEFAULT_PAGE);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { filters, setFilters } = useVendorFilters();

  // ``sales_volume_qty`` is a parent slider with amount + volume children, so
  // we request per-child keys and let ``Filters`` map them to each child.
  const { maxes: planRangeMaxes } = useFilterRangesQuery({
    module: "vendor_plan",
    keys: ["risk_adjusted_value", "sales_amount", "sales_volume", "materials_at_risk"],
  });

  // Initialize activeRiskView from URL parameter or default to "material"
  const [activeRiskView, setActiveRiskView] = useState<"material" | "gcn" | "product">(() => {
    const viewParam = searchParams.get("selected_tab");
    if (viewParam === "material" || viewParam === "gcn" || viewParam === "product") {
      return viewParam;
    }
    return "material";
  });
  const [showTableConfigModal, setShowTableConfigModal] = useState(false);
  const [showCreateFilterModal, setShowCreateFilterModal] = useState(false);
  const [showReorderTableModal, setShowReorderTableModal] = useState(false);
  const { columns, saveColumns, resetColumns } = useTableColumns(activeRiskView);

  const infiniteQuery = useVendorsInfiniteQuery({
    filters,
    pageSize,
    enabled: viewMode === VIEW_MODE.CARD,
  });

  const paginatedQuery = useVendorsListPaginatedQuery({
    filters,
    page: currentPage,
    pageSize,
    enabled: viewMode === VIEW_MODE.TABLE,
  });

  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(page);
  }, []);

  const handlePageSizeChange = useCallback((size: number) => {
    setPageSize(size);
    setCurrentPage(DEFAULT_PAGE);
  }, []);

  useEffect(() => {
    setCurrentPage(DEFAULT_PAGE);
  }, [filters]);

  // Sync activeRiskView with URL parameter
  useEffect(() => {
    const viewParam = searchParams.get("selected_tab");
    if (viewParam === "material" || viewParam === "gcn" || viewParam === "product") {
      setActiveRiskView(viewParam);
    }
  }, [searchParams]);

  // Update URL when activeRiskView changes
  const handleRiskViewChange = useCallback((view: "material" | "gcn" | "product") => {
    setActiveRiskView(view);
    const newParams = new URLSearchParams(searchParams);
    if (view === "material") {
      // Remove selected_tab param for default view to keep URLs clean
      newParams.delete("selected_tab");
    } else {
      newParams.set("selected_tab", view);
    }
    setSearchParams(newParams, { replace: true });
  }, [searchParams, setSearchParams]);

  const displayVendors = viewMode === VIEW_MODE.CARD ? infiniteQuery.vendors : paginatedQuery.vendors;
  const isLoading = viewMode === VIEW_MODE.CARD ? infiniteQuery.isLoading : paginatedQuery.isLoading;
  const hasMore = viewMode === VIEW_MODE.CARD ? infiniteQuery.hasMore : paginatedQuery.hasMore;
  const total = viewMode === VIEW_MODE.CARD ? infiniteQuery.total : paginatedQuery.total;
  const isFetchingNextPage = infiniteQuery.isFetchingNextPage;
  const fetchNextPage = infiniteQuery.fetchNextPage;

  const handleLoadMore = useCallback(() => {
    if (hasMore && !isFetchingNextPage && viewMode === VIEW_MODE.CARD) {
      fetchNextPage();
    }
  }, [hasMore, isFetchingNextPage, viewMode, fetchNextPage]);

  const pageTitleNode = (
    <PageTitle title="Supply Chain Resiliency Mapping" section="Plan" />
  );

  const riskViewChips = useMemo(
    () => [
      { key: "material" as const, label: "Material Risk Level" },
      // { key: "gcn" as const, label: "GCN Risk Level" },
      // { key: "product" as const, label: "Product Family" },
    ],
    []
  );

  return (
    <DashboardLayout
      pageTitle={pageTitleNode}
      pageSubtitle="Insights and recommended actions to mitigate unexpected events in supply chain operations."
      bannerRightContent={<GlobalFilters variant="banner" />}
    >
      <MainKPIs />
        <DataViewLayout
          title="Supplier Risk Assessment"
          subtitle="View risk scores grouped by suppliers. Click on a supplier to explore risk ratings for their associated materials."
          data={displayVendors}
          viewMode={viewMode}
          loading={isLoading && displayVendors.length === 0}
          hasMore={hasMore}
          onLoadMore={handleLoadMore}
          renderCard={vendor => (
            <VendorCardView key={vendor.id} vendor={vendor} />
          )}
          renderTable={data => (
            <VendorTableView
              data={data}
              currentPage={currentPage}
              pageSize={pageSize}
              total={total}
              onPageChange={handlePageChange}
              onPageSizeChange={handlePageSizeChange}
              viewScope={activeRiskView}
              columns={columns}
            />
          )}
          filters={
            <div className="flex flex-col space-y-3 w-full">
              <div className="inline-flex flex-wrap w-fit rounded-[4px] items-center gap-2 border-1 border-[#CBD5E1] p-2">
                {riskViewChips.map(chip => (
                    <button
                      key={chip.key}
                      onClick={() => handleRiskViewChange(chip.key)}
                      className={`px-4 py-2 rounded-md text-sm font-semibold transition-colors cursor-pointer ${
                        activeRiskView === chip.key
                          ? "bg-brand-primary-main text-white"
                          : "bg-ui-background-primary text-ui-text-primary"
                      }`}
                    >
                      {chip.label}
                    </button>
                ))}
              </div>
              <Filters
                filters={filters}
                setFilters={setFilters}
                config={vendorFiltersConfig}
                dynamicMaxValues={planRangeMaxes}
              />
              <AppliedFilters filters={filters} setFilters={setFilters} config={vendorAppliedFiltersConfig} />
            </div>
          }
        />
      <TableConfigurationModal
        isOpen={showTableConfigModal}
        onClose={() => setShowTableConfigModal(false)}
        onSelectCreateFilter={() => {
          setShowTableConfigModal(false);
          setShowCreateFilterModal(true);
        }}
        onSelectReorderTable={() => {
          setShowTableConfigModal(false);
          setShowReorderTableModal(true);
        }}
      />

      {/* Create Custom Filter Modal */}
      <CreateCustomFilterModal
        isOpen={showCreateFilterModal}
        onClose={() => setShowCreateFilterModal(false)}
        onCreate={(filterData) => {
          // TODO: Implement save custom filter functionality
          console.log("Filter created:", filterData);
        }}
      />

      {/* Reorder Table Modal */}
      <ReorderTableModal
        isOpen={showReorderTableModal}
        onClose={() => setShowReorderTableModal(false)}
        columns={columns}
        onApply={saveColumns}
        onReset={resetColumns}
        viewScope={activeRiskView}
      />
    </DashboardLayout>
  );
}
