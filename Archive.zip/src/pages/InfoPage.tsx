import React from "react";
import {Card} from "@/components/atoms/Card";
import {Badge} from "@/components/atoms/Badge";

const getBuildInfo = () => {
  const env = import.meta.env.MODE;
  const version =
    import.meta.env.VITE_APP_VERSION ||
    (globalThis as any).__APP_VERSION__ ||
    "1.0.0";
  const buildDate =
    import.meta.env.VITE_BUILD_DATE ||
    (globalThis as any).__BUILD_DATE__ ||
    new Date().toISOString();
  const apiUrl =
    import.meta.env.VITE_API_BASE_URL;

  return {
    environment: env,
    version,
    buildDate,
    apiUrl,
  };
};

const getEnvironmentBadge = (env: string) => {
  switch (env.toLowerCase()) {
    case "production":
    case "prod":
      return {text: "PRODUCTION", variant: "destructive" as const};
    case "staging":
    case "stage":
      return {text: "STAGING", variant: "secondary" as const};
    case "development":
    case "dev":
      return {text: "DEVELOPMENT", variant: "default" as const};
    default:
      return {text: env.toUpperCase(), variant: "outline" as const};
  }
};

// Get system information
const getSystemInfo = () => {
  const userAgent = navigator.userAgent;
  const platform = navigator.platform;
  const language = navigator.language;
  const online = navigator.onLine;
  const cookieEnabled = navigator.cookieEnabled;

  return {
    userAgent,
    platform,
    language,
    online,
    cookieEnabled,
    timestamp: new Date().toISOString(),
  };
};

export const InfoPage: React.FC = () => {
  const buildInfo = getBuildInfo();
  const envBadge = getEnvironmentBadge(buildInfo.environment);
  const systemInfo = getSystemInfo();

  // Application status - 200 if running properly
  const appStatus = {
    code: 200,
    message: "OK",
    description: "Application is running properly",
  };

  return (
    <div className="min-h-screen bg-ui-background-secondary py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-ui-text-primary mb-2">
            Application Information
          </h1>
          <p className="text-ui-text-secondary">
            System status and build information
          </p>
        </div>

        {/* Status Code */}
        <Card className="mb-6 p-6 bg-status-success-light border-status-success-main">
          <div className="flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl font-bold text-status-success-main mb-2">
                {appStatus.code}
              </div>
              <div className="text-xl font-semibold text-status-success-dark mb-1">
                {appStatus.message}
              </div>
              <div className="text-status-success-text">
                {appStatus.description}
              </div>
            </div>
          </div>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Build Information */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold text-ui-text-primary mb-4">
              Build Information
            </h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Environment:</span>
                <Badge variant={envBadge.variant}>{envBadge.text}</Badge>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Version:</span>
                <code className="px-2 py-1 bg-ui-background-muted rounded text-sm">
                  v{buildInfo.version}
                </code>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Build Date:</span>
                <span className="text-sm text-ui-text-primary">
                  {new Date(buildInfo.buildDate).toLocaleString()}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">API URL:</span>
                <code className="px-2 py-1 bg-ui-background-muted rounded text-sm max-w-48 truncate">
                  {buildInfo.apiUrl}
                </code>
              </div>
            </div>
          </Card>

          {/* System Information */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold text-ui-text-primary mb-4">
              System Information
            </h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Status:</span>
                <Badge variant={systemInfo.online ? "default" : "destructive"}>
                  {systemInfo.online ? "ONLINE" : "OFFLINE"}
                </Badge>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Platform:</span>
                <span className="text-sm text-ui-text-primary">
                  {systemInfo.platform}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Language:</span>
                <span className="text-sm text-ui-text-primary">
                  {systemInfo.language}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Cookies:</span>
                <Badge
                  variant={systemInfo.cookieEnabled ? "default" : "destructive"}
                >
                  {systemInfo.cookieEnabled ? "ENABLED" : "DISABLED"}
                </Badge>
              </div>
            </div>
          </Card>

          {/* Runtime Information */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold text-ui-text-primary mb-4">
              Runtime Information
            </h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Current Time:</span>
                <span className="text-sm text-ui-text-primary">
                  {new Date().toLocaleString()}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Uptime:</span>
                <span className="text-sm text-ui-text-primary">
                  {Math.floor(performance.now() / 1000)}s
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Memory Usage:</span>
                <span className="text-sm text-ui-text-primary">
                  {(performance as any).memory
                    ? `${Math.round((performance as any).memory.usedJSHeapSize / 1024 / 1024)}MB`
                    : "N/A"}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-ui-text-secondary">Viewport:</span>
                <span className="text-sm text-ui-text-primary">
                  {window.innerWidth}x{window.innerHeight}
                </span>
              </div>
            </div>
          </Card>
        </div>

        {/* User Agent */}
        <Card className="mt-6 p-6">
          <h2 className="text-xl font-semibold text-ui-text-primary mb-4">
            User Agent
          </h2>
          <code className="text-xs text-ui-text-muted break-all">
            {systemInfo.userAgent}
          </code>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8 text-ui-text-muted text-sm">
          <p>Generated at {new Date().toLocaleString()}</p>
          <p className="mt-1">Cencora Stratium Frontend • Status: Operational</p>
        </div>
      </div>
    </div>
  );
};

export default InfoPage;
