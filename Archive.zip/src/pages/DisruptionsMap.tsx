import PrimaryPin from "@/assets/icons/primary-pin.svg";
import InfoIcon from "@/components/atoms/InfoIcon";
import Legend, { type LegendItem } from "@/components/atoms/Legend";
import DashboardLayout from "@/components/templates/DashboardLayout";
import {
  detailedEventToBasicEvent,
  useSupplyChainEventDetailQuery,
  useSupplyChainEventsWithLocationQuery,
} from "@/hooks/queries";
import { useCountriesGeoJson } from "@/hooks/useCountriesGeoJson";
import type { DetailedSupplyChainEvent, SupplyChainEventWithLocation } from "@/lib/apiServices";
import type { GeoJsonObject } from "geojson";
import { divIcon, type DivIcon } from "leaflet";
import "leaflet/dist/leaflet.css";
import { Clock, Map, MapPin } from "lucide-react";
import React, { useCallback, useEffect, useId, useMemo } from "react";
import { GeoJSON, MapContainer, Marker, ZoomControl, useMap, useMapEvents } from "react-leaflet";
import { Link, useSearchParams } from "react-router-dom";

const MAP_CONFIG = {
  center: [20, 0] as [number, number],
  zoom: 2,
  minZoom: 1,
  maxZoom: 18,
  maxBounds: [
    [-85, -180],
    [85, 180],
  ] as [[number, number], [number, number]],
  maxBoundsViscosity: 0,
} as const;

const VALID_LAT_RANGE = { min: -90, max: 90 } as const;
const VALID_LNG_RANGE = { min: -180, max: 180 } as const;

const isValidCoordinate = (lat: number, lng: number): boolean =>
  lat >= VALID_LAT_RANGE.min && lat <= VALID_LAT_RANGE.max && lng >= VALID_LNG_RANGE.min && lng <= VALID_LNG_RANGE.max;

const escapeHtmlForAttr = (s: string): string =>
  String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const MAP_HEIGHT = 600;

const RISK_LEGEND_ITEMS: LegendItem[] = [
  { id: "highly-likely", label: "Highly Likely", color: "#DC2626", shape: "square" },
  { id: "likely", label: "Likely", color: "#F97316", shape: "square" },
  { id: "even-chance", label: "Even Chance", color: "#EAB308", shape: "square" },
  { id: "unlikely", label: "Unlikely", color: "#22C55E", shape: "square" },
  { id: "highly-unlikely", label: "Highly Unlikely", color: "#15803D", shape: "square" },
];

// Map risk rating (0-1) to risk level
const getRiskLevel = (riskRating: number): { level: string; color: string } => {
  if (riskRating >= 0.8) return { level: "Highly Likely", color: "#DC2626" };
  if (riskRating >= 0.6) return { level: "Likely", color: "#F97316" };
  if (riskRating >= 0.4) return { level: "Even Chance", color: "#EAB308" };
  if (riskRating >= 0.2) return { level: "Unlikely", color: "#22C55E" };
  return { level: "Highly Unlikely", color: "#15803D" };
};

const MARKER_ICON_CACHE: Record<string, DivIcon> = {};
const MARKER_ICON_CACHE_KEYS: string[] = [];
const MAX_ICON_CACHE_SIZE = 50;

const createMarkerIcon = (riskColor: string, ariaLabel?: string, selected = false): DivIcon => {
  const safeLabel = ariaLabel ? escapeHtmlForAttr(ariaLabel) : "";
  const key = `${riskColor}:${safeLabel}:${selected}`;
  if (key in MARKER_ICON_CACHE) {
    return MARKER_ICON_CACHE[key];
  }
  if (MARKER_ICON_CACHE_KEYS.length >= MAX_ICON_CACHE_SIZE) {
    const firstKey = MARKER_ICON_CACHE_KEYS.shift();
    if (firstKey) delete MARKER_ICON_CACHE[firstKey];
  }
  const labelAttrs = safeLabel ? ` role="button" title="${safeLabel}" aria-label="${safeLabel}"` : "";
  const size = selected ? 36 : 32;
  const anchor = size / 2;
  const boxShadow = selected ? "0 4px 12px rgba(0,0,0,0.3)" : "0 2px 4px rgba(0,0,0,0.2)";
  const icon = divIcon({
    className: `custom-risk-marker${selected ? " custom-risk-marker--selected" : ""}`,
    html: `<div style="
        width: ${size}px;
        height: ${size}px;
        border-radius: 50%;
        background-color: ${riskColor};
        border: 2px solid white;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: ${boxShadow};
        cursor: pointer;
      " ${labelAttrs}>
        <svg width="${size - 12}" height="${size - 12}" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M9.99999 14.2188C9.95353 14.2188 9.90812 14.2327 9.86952 14.2585C9.83093 14.2844 9.80089 14.3211 9.78323 14.3641C9.76557 14.4071 9.76107 14.4543 9.77032 14.4999C9.77957 14.5454 9.80214 14.5872 9.83517 14.6198C9.8682 14.6525 9.91019 14.6746 9.95582 14.6834C10.0014 14.6921 10.0486 14.6871 10.0914 14.669C10.1342 14.6509 10.1706 14.6205 10.1961 14.5816C10.2215 14.5427 10.2349 14.4972 10.2344 14.4507C10.2345 14.4199 10.2284 14.3894 10.2167 14.3609C10.2049 14.3325 10.1877 14.3066 10.1659 14.2848C10.1441 14.263 10.1183 14.2458 10.0898 14.234C10.0613 14.2223 10.0308 14.2163 9.99999 14.2163M10 12.3438V7.65635M11.0131 3.6001C10.9201 3.41073 10.7759 3.25122 10.5968 3.13967C10.4177 3.02812 10.211 2.96899 10 2.96899C9.78903 2.96899 9.58227 3.02812 9.4032 3.13967C9.22412 3.25122 9.0799 3.41073 8.98688 3.6001L3.06626 15.6613C2.99499 15.8063 2.96184 15.9671 2.96995 16.1284C2.97805 16.2898 3.02714 16.4464 3.11259 16.5835C3.19803 16.7206 3.317 16.8337 3.45827 16.912C3.59954 16.9904 3.75846 17.0315 3.92001 17.0313H16.08C16.2416 17.0315 16.4005 16.9904 16.5417 16.912C16.683 16.8337 16.802 16.7206 16.8874 16.5835C16.9729 16.4464 17.022 16.2898 17.0301 16.1284C17.0382 15.9671 17.005 15.8063 16.9338 15.6613L11.0131 3.6001Z" stroke="white" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </div>
    `,
    iconSize: [size, size],
    iconAnchor: [anchor, anchor],
  });
  MARKER_ICON_CACHE[key] = icon;
  MARKER_ICON_CACHE_KEYS.push(key);
  return icon;
};

const MapMarkers = React.memo<{
  events: SupplyChainEventWithLocation[];
  selectedEventId: string | null;
  onEventClick: (event: SupplyChainEventWithLocation) => void;
}>(({ events, selectedEventId, onEventClick }) => (
  <>
    {events.map(event => {
      const lat = event.latitude;
      const lng = event.longitude;
      if (lat == null || lng == null || !isValidCoordinate(lat, lng)) return null;
      const riskInfo = getRiskLevel(event.mat_nbr?.risk_rating || 0);
      const ariaLabel = `View ${event.type} event details`;
      const isSelected = selectedEventId != null && event.id?.toString() === selectedEventId;
      return (
        <Marker
          key={event.id}
          position={[lat, lng]}
          icon={createMarkerIcon(riskInfo.color, ariaLabel, isSelected)}
          zIndexOffset={isSelected ? 1000 : 0}
          eventHandlers={{
            click: e => {
              e.originalEvent?.stopPropagation();
              onEventClick(event);
            },
          }}
        />
      );
    })}
  </>
));

const MapClickHandler: React.FC<{ onMapClick: () => void }> = ({ onMapClick }) => {
  useMapEvents({
    click: onMapClick,
  });
  return null;
};

const FitBoundsToEvents: React.FC<{
  events: SupplyChainEventWithLocation[];
  resetViewTrigger?: number;
}> = ({ events, resetViewTrigger = 0 }) => {
  const map = useMap();
  const hasFittedRef = React.useRef(false);
  const prevTriggerRef = React.useRef(resetViewTrigger);

  useEffect(() => {
    if (resetViewTrigger > 0 && resetViewTrigger !== prevTriggerRef.current) {
      hasFittedRef.current = false;
      prevTriggerRef.current = resetViewTrigger;
    }
  }, [resetViewTrigger]);

  useEffect(() => {
    if (events.length === 0) return;
    if (hasFittedRef.current) return;

    const validEvents = events.filter(
      e => e.latitude != null && e.longitude != null && isValidCoordinate(e.latitude, e.longitude)
    );
    if (validEvents.length === 0) return;

    hasFittedRef.current = true;
    const bounds = validEvents.map(e => [e.latitude!, e.longitude!] as [number, number]);
    map.fitBounds(bounds, { padding: [50, 50], maxZoom: 12 });
  }, [map, events, resetViewTrigger]);

  return null;
};

const EmptyEventState: React.FC = () => {
  return (
    <div className="bg-ui-background-primary border border-gray-200 rounded-[10px] p-6 md:mt-28 flex flex-col items-center justify-center min-h-[600px]">
      <div className="flex flex-col items-center justify-center text-center">
        <div className="w-24 h-24 rounded-full bg-[#E8E0F7] flex items-center justify-center mb-6">
          <img src={PrimaryPin} alt="Map Pin" className="w-12 h-12" />
        </div>
        <h3 className="text-xl font-semibold text-[#374151] mb-3">Select an Event</h3>
        <p className="text-sm text-[#6B7280] max-w-sm">
          Click on any event marker on the map to view detailed information, affected materials, and available actions.
        </p>
      </div>
    </div>
  );
};

const SHIMMER_STYLES = `
  @keyframes disruptions-map-shimmer {
    0% { background-position: -200% 0; }
    100% { background-position: 200% 0; }
  }
  .disruptions-map-shimmer {
    background: linear-gradient(90deg, #f0f0f0 0%, #e8e8e8 20%, #f0f0f0 40%, #f0f0f0 100%);
    background-size: 200% 100%;
    animation: disruptions-map-shimmer 1.5s ease-in-out infinite;
  }
`;

const MapShimmer: React.FC<{ height?: number; className?: string }> = ({ height = MAP_HEIGHT, className = "" }) => (
  <div
    className={`absolute inset-0 z-1000 flex flex-col rounded-[16px] overflow-hidden border border-[#E2E8F0] ${className}`}
    style={{ height }}
    aria-label="Map loading"
    data-testid="map-loading"
  >
    <div className="flex-1 disruptions-map-shimmer rounded-[16px]" />
  </div>
);

const EventDetailShimmer: React.FC = () => (
  <div className="w-full bg-white rounded-lg border border-neutral-100 md:mt-28">
    <div className="w-full p-6 animate-pulse">
      <div className="flex items-center gap-2 mb-2">
        <div className="h-3 w-16 bg-neutral-100 rounded" />
        <div className="h-3 w-24 bg-neutral-100 rounded" />
      </div>
      <div className="h-6 w-48 bg-neutral-100 rounded mb-4" />
      <div className="h-4 w-full bg-neutral-100 rounded mb-1" />
      <div className="h-4 w-3/4 bg-neutral-100 rounded mb-6" />
      <div className="space-y-2 rounded-[4px] border border-neutral-100 p-4 mb-6">
        <div className="h-4 w-32 bg-neutral-100 rounded mb-2" />
        <div className="w-full h-[200px] bg-neutral-100 rounded mb-2" />
        <div className="h-4 w-48 bg-neutral-100 rounded mx-auto" />
      </div>
      <div className="mb-6">
        <div className="h-4 w-24 bg-neutral-100 rounded mb-3" />
        <div className="grid grid-cols-2 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="rounded-[4px] p-2 border border-neutral-100">
              <div className="h-3 w-20 bg-neutral-100 rounded mb-2" />
              <div className="h-4 w-32 bg-neutral-100 rounded" />
            </div>
          ))}
        </div>
      </div>
      <div className="rounded-md p-4 border border-neutral-100 bg-neutral-50">
        <div className="h-4 w-32 bg-neutral-100 rounded mb-3" />
        <div className="bg-white rounded-[8px] p-3 border border-neutral-100">
          <div className="flex flex-row items-center justify-between">
            <div className="flex-1">
              <div className="h-4 w-40 bg-neutral-100 rounded mb-2" />
              <div className="h-3 w-24 bg-neutral-100 rounded" />
            </div>
            <div className="w-2 h-2 bg-neutral-100 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  </div>
);

// Helper function to format time ago
const getTimeAgo = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (diffInSeconds < 60) return `${diffInSeconds} seconds ago`;
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
  return `${Math.floor(diffInSeconds / 86400)} days ago`;
};

// Helper function to format coordinates
const formatCoordinates = (lat: number, lng: number): string => {
  const latDir = lat >= 0 ? "N" : "S";
  const lngDir = lng >= 0 ? "E" : "W";
  return `${Math.abs(lat).toFixed(4)}° ${latDir}, ${Math.abs(lng).toFixed(4)}° ${lngDir}`;
};

const MapStyles: React.FC = () => {
  const styleId = useId().replace(/:/g, "-");
  useEffect(() => {
    const id = `event-detail-map-styles-${styleId}`;
    if (!document.getElementById(id)) {
      const styleSheet = document.createElement("style");
      styleSheet.id = id;
      styleSheet.textContent = `
        .insight-alert-map .leaflet-container {
          background: #F5F5F5 !important;
          overflow: hidden !important;
        }
        .insight-alert-map .leaflet-map-pane {
          overflow: visible !important;
        }
      `;
      document.head.appendChild(styleSheet);
    }

    return () => {
      const existingStyle = document.getElementById(id);
      existingStyle?.remove();
    };
  }, [styleId]);

  return null;
};

const EVENT_DETAIL_GEOJSON_STYLE = {
  fillColor: "#E5E7EB",
  color: "#FFFFFF",
  weight: 1,
  opacity: 1,
  fillOpacity: 1,
} as const;

const SetViewToCenter: React.FC<{ center: [number, number]; zoom: number }> = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [map, center, zoom]);
  return null;
};

// Event Detail Panel Component
const EventDetailPanel: React.FC<{
  event: SupplyChainEventWithLocation | null;
  detailedEvent: DetailedSupplyChainEvent | null;
  loadingDetailedEvent: boolean;
  onClose: () => void;
  geoJsonData: GeoJsonObject | null;
}> = ({ event, detailedEvent, loadingDetailedEvent, onClose, geoJsonData }) => {
  if (!event) return null;

  // Use detailed event data if available, otherwise fall back to basic event data
  const displayEvent = detailedEvent || event;

  // Get coordinates - detailed event might have null latitude/longitude
  const eventLat = displayEvent.latitude ?? event.latitude;
  const eventLng = displayEvent.longitude ?? event.longitude;

  const riskInfo = getRiskLevel(displayEvent.mat_nbr?.risk_rating || 0);
  const timeAgo = getTimeAgo(displayEvent.created_at);
  const hasValidCoords = eventLat !== null && eventLng !== null && isValidCoordinate(eventLat, eventLng);
  const coordinates = hasValidCoords ? formatCoordinates(eventLat!, eventLng!) : null;

  return (
    <div className="relative bg-ui-background-primary border border-gray-200 rounded-[10px] p-6 md:mt-28 min-h-[600px]">
      {loadingDetailedEvent ? (
        <div className="w-full animate-pulse">
          <div className="flex items-start justify-between w-full mb-2">
            <div className="flex items-center gap-2">
              <div className="h-3 w-16 bg-neutral-100 rounded" />
              <div className="h-3 w-24 bg-neutral-100 rounded" />
            </div>
            <button onClick={onClose} className="ml-4 text-ui-text-secondary hover:text-ui-text-primary" aria-label="Close panel">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 6L6 18M6 6l12 12" />
              </svg>
            </button>
          </div>
          <div className="h-6 w-48 bg-neutral-100 rounded mb-4" />
          <div className="h-4 w-full bg-neutral-100 rounded mb-1" />
          <div className="h-4 w-3/4 bg-neutral-100 rounded mb-6" />
          <div className="space-y-2 rounded-[4px] border border-neutral-100 p-4 mb-6">
            <div className="h-4 w-32 bg-neutral-100 rounded mb-2" />
            <div className="w-full h-[200px] bg-neutral-100 rounded mb-2" />
            <div className="h-4 w-48 bg-neutral-100 rounded mx-auto" />
          </div>
          <div className="mb-6">
            <div className="h-4 w-24 bg-neutral-100 rounded mb-3" />
            <div className="grid grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="rounded-[4px] p-2 border border-neutral-100">
                  <div className="h-3 w-20 bg-neutral-100 rounded mb-2" />
                  <div className="h-4 w-32 bg-neutral-100 rounded" />
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-md p-4 border border-neutral-100 bg-neutral-50">
            <div className="h-4 w-32 bg-neutral-100 rounded mb-3" />
            <div className="bg-white rounded-[8px] p-3 border border-neutral-100">
              <div className="flex flex-row items-center justify-between">
                <div className="flex-1">
                  <div className="h-4 w-40 bg-neutral-100 rounded mb-2" />
                  <div className="h-3 w-24 bg-neutral-100 rounded" />
                </div>
                <div className="w-2 h-2 bg-neutral-100 rounded-full" />
              </div>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Title */}
          <div className="flex items-center space-x-2 mb-2 shrink-0">
            <div className="flex items-start justify-between w-full">
              <div className="flex-1">
                <div className="flex flex-row items-center gap-2 mb-2">
                  <Clock className="h-3 w-3" color="#6B7280" />
                  <div className="text-xs text-ui-text-secondary">{timeAgo}</div>
                </div>
                <h2 className="text-xl font-bold text-color-heading">{displayEvent.type}</h2>
              </div>
              <button
                onClick={onClose}
                className="ml-4 text-ui-text-secondary hover:text-ui-text-primary"
                aria-label="Close panel"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 6L6 18M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
          {/* Subtitle */}
          <div className="text-sm text-ui-text-secondary mb-4 shrink-0">
            <p className="text-sm text-ui-text-secondary">
              {displayEvent.type_description || displayEvent.metadata || "No description available."}
            </p>
          </div>
          {/* Event Location */}
          {hasValidCoords && (
            <div className="space-y-2 rounded-[4px] border p-4 mb-6">
              <h3 className="text-sm font-semibold text-gray-900 flex items-center gap-2">
                <MapPin className="h-4 w-4" color="#593AB1" />
                Event Location
              </h3>
              <div className="rounded-lg min-h-[200px] relative overflow-hidden" style={{ background: "#F5F5F5" }}>
                <MapContainer
                  center={[eventLat, eventLng]}
                  maxZoom={8}
                  zoomControl={true}
                  attributionControl={false}
                  scrollWheelZoom={true}
                  doubleClickZoom={true}
                  dragging={true}
                  touchZoom={true}
                  className="w-full h-[200px] rounded-[4px] z-0 insight-alert-map"
                  style={{ position: "relative", background: "#F5F5F5" }}
                  aria-label="Event location map"
                >
                  <MapStyles />
                  {geoJsonData && <GeoJSON data={geoJsonData} style={EVENT_DETAIL_GEOJSON_STYLE} />}
                  <Marker position={[eventLat, eventLng]} icon={createMarkerIcon(riskInfo.color, "Event location")} />
                  <SetViewToCenter center={[eventLat, eventLng]} zoom={6} />
                </MapContainer>
              </div>
              {coordinates && (
                <div className="flex flex-row items-center justify-center text-sm bg-[#F5F5F5] rounded-[4px] p-2 text-[#6B7280]">
                  <div className="flex flex-row items-center justify-center space-x-2">
                    <Map className="h-3 w-3" color="#6B7280" />
                    <span>{coordinates}</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Event Details */}
          <div className="mb-6">
            <h3 className="font-bold text-sm mb-3">Event Details</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#F5F5F569] rounded-[4px] p-2">
                <div className="text-xs text-ui-text-secondary mb-1">Epicenter</div>
                <div className="text-sm font-medium">{coordinates ?? "N/A"}</div>
              </div>
              <div className="bg-[#F5F5F569] rounded-[4px] p-2">
                <div className="flex flex-row items-center justify-between">
                  <div className="text-xs text-ui-text-secondary mb-1">Affected Radius</div>
                  <span className="text-[11px] px-2 py-0.5 bg-[#E8E8E8] rounded-full text-[#3B3B3B] font-bold text-2xs">
                    Coming Soon
                  </span>
                </div>
                <div className="text-sm font-medium">N/A</div>
              </div>
              <div className="bg-[#F5F5F569] rounded-[4px] p-2">
                <div className="flex flex-row items-center justify-between">
                  <div className="text-2xs text-ui-text-secondary mb-1">Magnitude / Severity</div>
                  <span className="text-[9px] px-2 py-0.5 bg-[#E8E8E8] rounded-full text-[#3B3B3B] font-bold">Coming Soon</span>
                </div>
                <div className="text-sm font-medium">N/A</div>
              </div>

              <div className="bg-[#F5F5F569] rounded-[4px] p-2">
                <div className="flex flex-row items-center justify-between">
                  <div className="text-xs text-ui-text-secondary mb-1">Depth</div>
                  <span className="text-[11px] px-2 py-0.5 bg-[#E8E8E8] rounded-full text-[#3B3B3B] font-bold">Coming Soon</span>
                </div>
                <div className="text-sm font-medium ">N/A</div>
              </div>
            </div>
          </div>

          {/* Affected Materials */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
            <h3 className="text-sm mb-3">Affected Materials</h3>
            {(() => {
              // Collect materials only from related events
              const materials: Array<{ name: string; mat_nbr: string; risk_rating: number }> = [];

              // Add related events materials
              if (detailedEvent?.related_events) {
                detailedEvent.related_events.forEach(relatedEvent => {
                  if (relatedEvent.mat_nbr) {
                    // Avoid duplicates by checking if material already exists
                    const exists = materials.some(m => m.mat_nbr === relatedEvent.mat_nbr.mat_nbr);
                    if (!exists) {
                      materials.push({
                        name: relatedEvent.mat_nbr.name,
                        mat_nbr: relatedEvent.mat_nbr.mat_nbr || "N/A",
                        risk_rating: relatedEvent.mat_nbr.risk_rating || 0,
                      });
                    }
                  }
                });
              }

              if (materials.length === 0) {
                return <div className="text-sm text-ui-text-secondary">No material information available</div>;
              }

              // Calculate max height: approximately 70px per item (3 items = ~210px)
              // Add some padding for spacing between items
              const maxHeight = materials.length > 3 ? "210px" : "auto";
              const shouldScroll = materials.length > 3;

              return (
                <div
                  className="space-y-2"
                  style={{
                    maxHeight: maxHeight,
                    overflowY: shouldScroll ? "auto" : "visible",
                  }}
                >
                  {materials.map((material, index) => {
                    const riskInfo = getRiskLevel(material.risk_rating);
                    return (
                      <div key={`${material.mat_nbr}-${index}`} className="bg-white rounded-[8px] p-3 border border-yellow-200">
                        <div className="flex flex-row items-center justify-between">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="font-medium text-sm mb-1">{material.name}</div>
                              <div className="text-xs text-ui-text-secondary">{material.mat_nbr}</div>
                            </div>
                          </div>
                          <div className="w-2 h-2 rounded-full mt-1" style={{ backgroundColor: riskInfo.color }}></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        </>
      )}
    </div>
  );
};

export default function DisruptionsMap() {
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedEventId = searchParams.get("eventId");
  const { data: geoJsonData, loading: geoJsonLoading, error: geoJsonError } = useCountriesGeoJson();

  const {
    events,
    hasMore,
    isFetchingNextPage,
    fetchNextPage,
    isLoading: loading,
    isError: isEventsError,
    error: eventsError,
  } = useSupplyChainEventsWithLocationQuery();

  // Fetch remaining pages in background after initial load
  useEffect(() => {
    if (hasMore && !isFetchingNextPage && events.length > 0) {
      fetchNextPage();
    }
  }, [hasMore, isFetchingNextPage, events.length, fetchNextPage]);

  const { detailedEvent, isLoading: loadingDetailedEvent } = useSupplyChainEventDetailQuery({
    eventId: selectedEventId,
    enabled: !!selectedEventId,
  });

  const selectedEvent = useMemo((): SupplyChainEventWithLocation | null => {
    if (!selectedEventId) return null;
    const fromEvents = events.find(e => e.id.toString() === selectedEventId);
    if (fromEvents) return fromEvents;
    if (detailedEvent) return detailedEventToBasicEvent(detailedEvent);
    return null;
  }, [selectedEventId, events, detailedEvent]);

  const loadingFromUrl = !!selectedEventId && !selectedEvent;

  const handleEventClick = useCallback(
    (event: SupplyChainEventWithLocation) => {
      if (event.id) {
        setSearchParams({ eventId: event.id.toString() });
      }
    },
    [setSearchParams]
  );

  const handleClearSelection = useCallback(() => {
    setSearchParams({});
  }, [setSearchParams]);

  const error = isEventsError && eventsError ? String(eventsError) : null;

  const geoJsonStyle = useMemo(
    () => ({
      fillColor: "#E5E7EB",
      weight: 1,
      opacity: 1,
      color: "#FFFFFF",
      fillOpacity: 1,
    }),
    []
  );

  return (
    <DashboardLayout>
      <style>{SHIMMER_STYLES}</style>
      <div className="">
        <div className="flex items-center space-x-2 text-sm text-ui-text-muted py-6">
          <Link to="/overview" className="hover:text-brand-primary-main transition-colors">
            Overview Module
          </Link>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
          <span className="text-brand-primary-main">Disruptions Events Map</span>
        </div>
        <div className="flex flex-col md:flex-row gap-4">
          {/* Main Map Card */}
          <div className="flex-1">
            <div className="bg-ui-background-primary rounded-[10px] border-0">
              {/* Title */}
              <div className="flex items-center space-x-2 mb-2 shrink-0">
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold text-color-heading">Location-Based Risk Events</h1>
                  <InfoIcon
                    position="bottom"
                    tooltip="This map only displays events with geographic coordinates. Additional risk events without location data may exist in other modules."
                  />
                </div>
              </div>
              {/* Subtitle */}
              <div className="text-sm text-ui-text-secondary mb-4 shrink-0">
                <p className="text-sm text-ui-text-secondary">
                  This map only displays events with geographic coordinates. Additional risk events without location data may
                  exist in other modules.
                </p>
              </div>
              <hr className="mb-3" />
              <div className="mb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <Legend items={RISK_LEGEND_ITEMS} orientation="horizontal" spacing="md" />
              </div>

              {/* Map */}
              <div className="relative" style={{ height: `${MAP_HEIGHT}px` }}>
                {loading && <MapShimmer />}
                {error && (
                  <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-75 z-1000">
                    <div className="text-red-600 text-sm">{error}</div>
                  </div>
                )}
                {geoJsonLoading && <MapShimmer />}
                {geoJsonError && (
                  <div className="absolute inset-0 flex items-center justify-center bg-white/90 z-500 rounded-[16px]">
                    <div className="text-center p-4">
                      <p className="text-sm text-red-600 mb-2">Failed to load map data</p>
                      <p className="text-xs text-gray-600">{geoJsonError.message}</p>
                    </div>
                  </div>
                )}

                <MapContainer
                  style={{
                    background: "#F5F5F5",
                    height: "100%",
                    width: "100%",
                    borderRadius: "16px",
                    border: "1px solid #E2E8F0",
                  }}
                  center={MAP_CONFIG.center}
                  zoom={MAP_CONFIG.zoom}
                  minZoom={MAP_CONFIG.minZoom}
                  maxZoom={MAP_CONFIG.maxZoom}
                  maxBounds={MAP_CONFIG.maxBounds}
                  maxBoundsViscosity={MAP_CONFIG.maxBoundsViscosity}
                  zoomControl={false}
                  attributionControl={false}
                  scrollWheelZoom={true}
                  doubleClickZoom={true}
                  dragging={true}
                  touchZoom={true}
                  aria-label="Location-based risk events map. Click markers to view event details."
                >
                  {geoJsonData && <GeoJSON data={geoJsonData} style={geoJsonStyle} />}
                  <FitBoundsToEvents events={events} />
                  <MapMarkers events={events} selectedEventId={selectedEventId} onEventClick={handleEventClick} />
                  <MapClickHandler onMapClick={handleClearSelection} />
                  <ZoomControl position="topright" />
                </MapContainer>
              </div>
            </div>
          </div>

          {/* Event Detail Panel - Separate Card */}
          <div className="w-full md:w-1/3 shrink-0 ">
            {loadingFromUrl ? (
              <EventDetailShimmer />
            ) : selectedEvent ? (
              <EventDetailPanel
                event={selectedEvent}
                detailedEvent={detailedEvent}
                loadingDetailedEvent={loadingDetailedEvent}
                onClose={handleClearSelection}
                geoJsonData={geoJsonData}
              />
            ) : (
              <EmptyEventState />
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
