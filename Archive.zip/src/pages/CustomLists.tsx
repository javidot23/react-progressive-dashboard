import { Header } from "@/components/organisms";
import { Card, CardContent, CardHeader } from "@/components/atoms/Card";
import CustomListKpis from "@/components/custom-lists/components/CustomListKpis";
import CustomListDetails from "@/components/custom-lists/components/CustomListDetails";
import CustomListSidebar from "@/components/custom-lists/components/CustomListSidebar";
import { ChevronLeft } from "lucide-react";
import { Link } from "react-router-dom";

const CustomLists = () => {
    return (
        <div className="min-h-screen flex flex-col bg-gray-50">
            <Header />
            <div className="w-full relative min-h-[320px] lg:h-[320px] bg-[url('/src/assets/images/banner.svg')] bg-no-repeat bg-cover bg-center">
                <Card className="absolute top-6 sm:top-8 lg:top-12 left-1/2 -translate-x-1/2 w-[calc(100%-2rem)] sm:w-[calc(100%-3rem)] lg:w-full max-w-[1455px]">
                    <CardHeader className="p-4 sm:p-6">
                        <Link
                            to="/overview"
                            className="mb-4 inline-flex h-10 w-fit items-center justify-center gap-2 rounded-md bg-[#E8E8E8] px-4 py-2 text-sm font-semibold text-[#461E96] transition-colors hover:bg-[#E8E8E8] hover:text-[#461E96] focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        >
                            <ChevronLeft className="h-6 w-6 shrink-0 text-[#461E96]" aria-hidden />
                            Back
                        </Link>
                        <div className="text-xl sm:text-2xl font-bold">Add Products</div>
                        <div className="text-sm sm:text-base text-text-secondary">
                            Select products to add to Essential List
                        </div>
                    </CardHeader>
                    <CardContent className="flex flex-col gap-4 sm:gap-6 p-4 sm:p-6 pt-0 sm:pt-0">
                        <CustomListKpis />
                        <div className="flex flex-col lg:flex-row gap-4">
                            <CustomListSidebar />
                            <CustomListDetails />
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
};

export default CustomLists;
