import DashboardLayout from "@/components/templates/DashboardLayout";
import DataViewLayout from "@/components/templates/DataViewLayout";
import { useState, useEffect, useCallback, useMemo } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import pillIcon from "@/assets/icons/plan/pill.svg";
import Filters, { type FiltersConfig } from "@/components/atoms/Filters";
import AppliedFilters from "@/components/atoms/AppliedFilters";
import { materialAppliedFiltersConfig, getMaterialFiltersConfigWithMaterialSearch } from "@/lib/filterConfigs";
import VendorDetailCards from "@/components/molecules/VendorDetailCards";
import { MaterialRiskDriverModal } from "@/components/molecules/MaterialRiskDriverModal";
import MaterialRiskCard from "@/components/organisms/MaterialRiskCard";
import MaterialRiskTable from "@/components/organisms/MaterialRiskTable";
import { useMaterialFilters } from "@/hooks/useMaterialFilters";
import { useNetworkStatus } from "@/hooks/useNetworkStatus";
import { VendorRawData } from "@/lib/vendorUtils";
import { transformMaterialsData } from "@/lib/utils";
import {
  useMaterialsQuery,
  useMaterialsInfiniteQuery,
  useVendorQuery,
  useVendorsListQuery,
  useFilterRangesQuery,
  VendorData,
} from "@/hooks/queries";
import { useRiskModelDescriptions } from "@/hooks";

const DEFAULT_PAGE = 1;
const DEFAULT_PAGE_SIZE = 10;
const RISK_LABELS = {
  HIGHLY_LIKELY: "Highly Likely",
  LIKELY: "Likely",
  EVEN_CHANCE: "Even Chance",
  UNLIKELY: "Unlikely",
  HIGHLY_UNLIKELY: "Highly Unlikely",
} as const;

const VIEW_MODE = {
  CARD: "card",
  TABLE: "table",
} as const;

interface VendorOption {
  id: number;
  name: string;
  country: string;
  risk_rating: number;
  vendor_nbr?: string;
}

const getRiskBadge = (riskRating: number) => {
  if (riskRating >= 0.81) {
    return {
      text: RISK_LABELS.HIGHLY_LIKELY,
      className:
        "flex items-center bg-red-100 text-red-800 border border-1 border-red-300 px-2 py-0.5 rounded text-xs font-semibold text-nowrap",
    };
  } else if (riskRating >= 0.61) {
    return {
      text: RISK_LABELS.LIKELY,
      className:
        "flex items-center bg-yellow-100 text-yellow-800 border border-1 border-yellow-300 px-2 py-0.5 rounded text-xs font-semibold text-nowrap",
    };
  } else if (riskRating >= 0.41) {
    return {
      text: RISK_LABELS.EVEN_CHANCE,
      className:
        "flex items-center bg-yellow-100 text-yellow-800 border border-1 border-yellow-300 px-2 py-0.5 rounded text-xs font-semibold text-nowrap",
    };
  } else if (riskRating >= 0.21) {
    return {
      text: RISK_LABELS.UNLIKELY,
      className:
        "flex items-center bg-green-100 text-green-800 border border-1 border-green-300 px-2 py-0.5 rounded text-xs font-semibold text-nowrap",
    };
  } else {
    return {
      text: RISK_LABELS.HIGHLY_UNLIKELY,
      className:
        "flex items-center bg-green-100 text-green-800 border border-1 border-green-300 px-2 py-0.5 rounded text-xs font-semibold text-nowrap",
    };
  }
};

function usePagination(initialPage = DEFAULT_PAGE, initialPageSize = DEFAULT_PAGE_SIZE) {
  const [currentPage, setCurrentPage] = useState(initialPage);
  const [pageSize, setPageSize] = useState(initialPageSize);

  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(page);
  }, []);

  const handlePageSizeChange = useCallback((size: number) => {
    setPageSize(size);
    setCurrentPage(DEFAULT_PAGE);
  }, []);

  const resetPage = useCallback(() => {
    setCurrentPage(DEFAULT_PAGE);
  }, []);

  return {
    currentPage,
    pageSize,
    handlePageChange,
    handlePageSizeChange,
    resetPage,
  };
}

function useViewMode() {
  const [searchParams] = useSearchParams();
  const viewMode = searchParams.get("view") as "card" | "table" | undefined;
  return { viewMode };
}

function useComparisonMode() {
  const [showCompareDropdown, setShowCompareDropdown] = useState(false);
  const [comparisonVendorId, setComparisonVendorId] = useState<number | null>(null);
  const [isComparisonMode, setIsComparisonMode] = useState(false);

  const handleCompareClick = useCallback(() => {
    setShowCompareDropdown(prev => !prev);
  }, []);

  const handleVendorSelect = useCallback((vendor: VendorOption) => {
    setComparisonVendorId(vendor.id);
    setShowCompareDropdown(false);
  }, []);

  const handleExitComparison = useCallback(() => {
    setIsComparisonMode(false);
    setComparisonVendorId(null);
  }, []);

  const closeDropdown = useCallback(() => {
    setShowCompareDropdown(false);
  }, []);

  return {
    showCompareDropdown,
    comparisonVendorId,
    isComparisonMode,
    setIsComparisonMode,
    handleCompareClick,
    handleVendorSelect,
    handleExitComparison,
    closeDropdown,
  };
}

export default function PlanProductPage() {
  const { vendorId: urlVendorId } = useParams<{ vendorId: string }>();
  const navigate = useNavigate();
  const isOnline = useNetworkStatus();
  const [showMaterialRiskDriverModal, setShowMaterialRiskDriverModal] = useState(false);
  const [modalVendorData, setModalVendorData] = useState<VendorRawData | null>(null);
  const vendorId = useMemo(() => {
    return urlVendorId ? parseInt(urlVendorId, 10) : null;
  }, [urlVendorId]);
  const { filters, setFilters } = useMaterialFilters();
  const materialFilters = useMemo(() => {
    const matNbrDisplay = filters.mat_nbr;
    if (!matNbrDisplay || matNbrDisplay === "") return filters;
    const match = matNbrDisplay.match(/^\(([^)]+)\)/);
    return { ...filters, mat_nbr: match ? match[1] : matNbrDisplay };
  }, [filters]);
  const dynamicFiltersConfig = useMemo(() => getMaterialFiltersConfigWithMaterialSearch(vendorId), [vendorId]);

  const materialRangeParams = useMemo(() => (vendorId ? { supplier: String(vendorId) } : undefined), [vendorId]);
  const { maxes: materialRangeMaxes } = useFilterRangesQuery({
    module: "material",
    keys: ["risk_adjusted_value"],
    params: materialRangeParams,
  });
  const { getEnrichedMetadata } = useRiskModelDescriptions();
  const { viewMode } = useViewMode();
  const { currentPage, pageSize, handlePageChange, handlePageSizeChange } = usePagination();
  const {
    showCompareDropdown,
    comparisonVendorId,
    isComparisonMode,
    setIsComparisonMode,
    handleCompareClick,
    handleVendorSelect,
    handleExitComparison,
    closeDropdown,
  } = useComparisonMode();
  const {
    vendor,
    error: vendorError,
    isLoading: vendorLoading,
    isPending: vendorPending,
  } = useVendorQuery({
    vendorId: vendorId ?? 0,
    enabled: !!vendorId && vendorId > 0,
  });
  const infiniteQuery = useMaterialsInfiniteQuery({
    vendorId,
    filters: materialFilters,
    pageSize,
    enabled: viewMode === VIEW_MODE.CARD,
  });
  const paginatedQuery = useMaterialsQuery({
    vendorId,
    filters: materialFilters,
    page: currentPage,
    pageSize,
    enabled: viewMode === VIEW_MODE.TABLE,
  });
  const { vendors: vendorsList, isLoading: vendorsListLoading } = useVendorsListQuery({
    limit: 50,
    enabled: showCompareDropdown,
  });

  const { vendor: comparisonVendor, isLoading: comparisonVendorLoading } = useVendorQuery({
    vendorId: comparisonVendorId ?? 0,
    enabled: !!comparisonVendorId && comparisonVendorId > 0,
  });

  const { materials: comparisonMaterials } = useMaterialsQuery({
    vendorId: comparisonVendorId,
    filters: {},
    page: 1,
    pageSize: 10,
    enabled: !!comparisonVendorId && comparisonVendorId > 0,
  });

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest(".compare-dropdown-container")) {
        closeDropdown();
      }
    };

    if (showCompareDropdown) {
      document.addEventListener("mousedown", handleClickOutside);
      return () => document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [showCompareDropdown, closeDropdown]);

  // Enable comparison mode when data is loaded
  useEffect(() => {
    if (comparisonVendorId && comparisonVendor && !isComparisonMode) {
      setIsComparisonMode(true);
    }
  }, [comparisonVendorId, comparisonVendor, isComparisonMode]);

  // Redirect to plan page if no vendor ID provided
  useEffect(() => {
    if (!urlVendorId) {
      navigate(`/plan`, { replace: true });
    }
  }, [urlVendorId, navigate]);

  // Get materials data based on view mode
  const materials = viewMode === VIEW_MODE.CARD ? infiniteQuery.materials : paginatedQuery.materials;

  const total = viewMode === VIEW_MODE.CARD ? infiniteQuery.total : paginatedQuery.total;

  const hasMore = viewMode === VIEW_MODE.CARD ? infiniteQuery.hasMore : paginatedQuery.hasMore;

  const materialsLoading = viewMode === VIEW_MODE.CARD ? infiniteQuery.isLoading : paginatedQuery.isLoading;

  const handleLoadMore = useCallback(() => {
    if (viewMode === VIEW_MODE.CARD && infiniteQuery.fetchNextPage) {
      infiniteQuery.fetchNextPage();
    }
  }, [viewMode, infiniteQuery]);

  // Use vendor from query (not vendorData)
  const vendorData = vendor;

  // Calculate KPI metrics from API data
  const kpiMetrics = {
    totalMaterials: vendorData?.total_materials ?? 0,
    highRisk: vendorData?.high_risk_materials_count ?? 0,
    mediumRisk: vendorData?.medium_risk_materials_count ?? 0,
    pendingActions: (vendorData?.issues_last_24h_count ?? 0) - (vendorData?.issues_with_actions_last_24h_count ?? 0),
    newIssues: vendorData?.issues_last_24h_count ?? 0,
  };

  if (vendorLoading || vendorPending) {
    return (
      <DashboardLayout hideBanner={true}>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-2 border-brand-primary-main border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-gray-500">Loading vendor data...</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  // Only return null if vendor data is not available after loading completes
  if (!vendorData) {
    return null;
  }

  const serviceLevels = vendorData.service_levels_90_days ?? [];

  const averageServiceLevel =
    serviceLevels.length > 0
      ? serviceLevels.reduce((sum: number, s: any) => {
          const orderQty = s.total_order_qty ?? 0;
          const receivedQty = s.total_received_qty ?? 0;
          return sum + (orderQty > 0 ? (receivedQty / orderQty) * 100 : 0);
        }, 0) / serviceLevels.length
      : 0;

  // Transform materials data to include risk scores and material details
  const transformedMaterials = transformMaterialsData(materials, r => getEnrichedMetadata(r).display_name || r);

  // Debug logging removed to prevent infinite loop

  // Apply filtering and sorting
  const filteredAndSortedMaterials = transformedMaterials.filter(material => {
    // Risk rating filter - material.risk_score is already a percentage (0-100)
    if (filters.risk_rating_min !== null || filters.risk_rating_max !== null) {
      const riskScore = material.risk_score || 93.7;
      if (filters.risk_rating_min !== null && riskScore < filters.risk_rating_min) return false;
      if (filters.risk_rating_max !== null && riskScore > filters.risk_rating_max) return false;
    }

    // Primary risk filter (compare by raw driving_risk; filter value is from API/dropdown)
    if (filters.primary_risk && filters.primary_risk !== "") {
      if (material.driving_risk !== filters.primary_risk) return false;
    }

    // Risk adjusted value filter
    if (filters.risk_adjusted_value_min !== null || filters.risk_adjusted_value_max !== null) {
      const riskAdjustedValue = material.risk_adjusted_value
        ? parseFloat(material.risk_adjusted_value.split(" / ")[0].replace(/[^0-9]/g, "")) || 90000
        : 90000;

      if (filters.risk_adjusted_value_min !== null && riskAdjustedValue < filters.risk_adjusted_value_min) return false;
      if (filters.risk_adjusted_value_max !== null && riskAdjustedValue > filters.risk_adjusted_value_max) return false;
    }

    return true;
  });

  // For backward compatibility, keep the old variable name
  const filteredMaterials = filteredAndSortedMaterials;

  // Calculate total count based on filtered results for pagination
  // Use the API total count instead of filtered length to show correct pagination
  const filteredTotal = total;

  const filteredComparisonMaterials = comparisonMaterials
    ? transformMaterialsData(comparisonMaterials, r => getEnrichedMetadata(r).display_name || r).filter(() => true)
    : [];

  if (vendorError) {
    return (
      <DashboardLayout hideBanner={true}>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="text-red-500 mb-4">Error loading data: {vendorError}</div>
            {!isOnline && <div className="text-orange-500 mb-4 text-sm">Please check your internet connection.</div>}
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-brand-primary-main text-white rounded hover:bg-brand-primary-dark transition-colors"
            >
              Retry
            </button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout hideBanner={true}>
      <main>
        <div className="flex flex-row items-center justify-between">
          <div className="flex items-center space-x-2 text-sm text-ui-text-muted py-6">
            <button onClick={() => navigate("/plan")} className="hover:text-brand-primary-main transition-colors">
              Plan
            </button>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
            <span className="text-brand-primary-main">
              {vendorData.name} • {vendorData.vendor_nbr}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative compare-dropdown-container">
              <button
                onClick={handleCompareClick}
                className="flex items-center space-x-2 px-3 py-1 border-2 border-brand-primary-main text-brand-primary-main bg-inherit hover:bg-purple-50 font-semibold rounded transition-colors"
              >
                <span className="leading-none flex flex-row items-center space-x-1 text-sm">
                  Compare with{" "}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className={`size-5 transition-transform ${showCompareDropdown ? "rotate-180" : ""}`}
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                  </svg>
                </span>
              </button>

              {showCompareDropdown && (
                <div className="absolute top-full right-0 mt-1 w-64 bg-white border border-gray-200 rounded-md shadow-lg z-50 max-h-60 overflow-y-auto">
                  {vendorsListLoading ? (
                    <div className="p-3 text-center text-gray-500 text-sm">
                      <div className="animate-spin w-4 h-4 border-2 border-brand-primary-main border-t-transparent rounded-full mx-auto mb-1"></div>
                      Loading vendors...
                    </div>
                  ) : vendorsList && vendorsList.length > 0 ? (
                    <div className="py-1">
                      {vendorsList
                        .filter((m: { id: number }) => m.id !== (vendorId || 0)) // Don't show current vendor
                        .map((vendor: VendorOption) => (
                          <button
                            key={vendor.id}
                            onClick={() => handleVendorSelect(vendor)}
                            className="w-full px-3 py-2 text-left hover:bg-gray-50 flex items-center justify-between group"
                          >
                            <div className="flex-1 min-w-0">
                              <div className="font-medium text-gray-900 text-sm truncate">
                                {vendor.name}
                                {vendor.vendor_nbr ? ` • ${vendor.vendor_nbr}` : ""}
                              </div>
                              <div className="text-xs text-gray-500">
                                {vendor.country} • Risk: {vendor.risk_rating?.toFixed(2) || "N/A"}
                              </div>
                            </div>
                            <svg
                              className="w-4 h-4 text-gray-400 group-hover:text-brand-primary-main opacity-0 group-hover:opacity-100 transition-opacity"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </button>
                        ))}
                    </div>
                  ) : (
                    <div className="p-3 text-center text-gray-500 text-sm">No vendors available</div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="overflow-hidden pb-2">
          <div className="py-3">
            {/* Comparison mode header */}
            {isComparisonMode && (
              <div className="flex items-center justify-end mb-4">
                <button
                  onClick={handleExitComparison}
                  className="flex items-center gap-2 px-3 py-1 text-gray-600 hover:text-gray-800 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                  Exit Comparison
                </button>
              </div>
            )}
            {isComparisonMode ? (
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 lg:gap-6">
                {/* Left side - Original vendor */}
                <div className="xl:border-r xl:border-gray-200 xl:pr-6">
                  <VendorComparisonContent
                    vendor={vendorData}
                    materials={filteredMaterials}
                    filters={filters}
                    setFilters={setFilters}
                    filtersConfig={dynamicFiltersConfig}
                    viewMode={viewMode}
                    isComparisonMode={isComparisonMode}
                    panelVendorId={vendorId ?? undefined}
                  />
                </div>
                <div className="xl:pl-6">
                  {comparisonVendor && !comparisonVendorLoading ? (
                    <VendorComparisonContent
                      vendor={comparisonVendor}
                      materials={filteredComparisonMaterials}
                      filters={filters}
                      setFilters={setFilters}
                      filtersConfig={dynamicFiltersConfig}
                      viewMode={viewMode}
                      isComparisonMode={isComparisonMode}
                      panelVendorId={comparisonVendorId ?? undefined}
                    />
                  ) : (
                    <div className="flex items-center justify-center h-64">
                      <div className="text-center">
                        <div className="animate-spin w-8 h-8 border-2 border-brand-primary-main border-t-transparent rounded-full mx-auto mb-4"></div>
                        <p className="text-gray-500">Loading comparison vendor...</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <>
                {/* KPI Metrics Section */}
                <div className="bg-[#E3F2FD] border border-[#BFDBFE] rounded-md px-4 py-4 mb-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex flex-wrap items-center gap-4 sm:gap-6">
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-2xl font-bold text-[#1E3A8A]">{kpiMetrics.totalMaterials}</div>
                        <div className="text-sm text-gray-600">Total Materials</div>
                      </div>
                      <div className="h-6 w-px bg-gray-300"></div>
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-2xl font-bold text-[#DC2626]">{kpiMetrics.highRisk}</div>
                        <div className="text-sm text-gray-600">High Risk (≥90%)</div>
                      </div>
                      <div className="h-6 w-px bg-gray-300"></div>
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-2xl font-bold text-[#EA580C]">{kpiMetrics.mediumRisk}</div>
                        <div className="text-sm text-gray-600">Medium Risk (70-89%)</div>
                      </div>
                      <div className="h-6 w-px bg-gray-300"></div>
                      <div className="flex flex-col items-center gap-2">
                        <div className="text-2xl font-bold text-[#9333EA]">{kpiMetrics.pendingActions}</div>
                        <div className="text-sm text-gray-600">Pending Actions</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2 text-[#2563EB]">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                          strokeWidth={1.5}
                          stroke="currentColor"
                          className="w-5 h-5"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
                          />
                        </svg>
                        <span className="text-sm font-medium">
                          {kpiMetrics.newIssues} new issue{kpiMetrics.newIssues !== 1 ? "s" : ""} detected in last 24 hours
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="rounded-md sm:px-6 md:px-0 py-3 mt-2 mb-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="flex flex-col sm:flex-row sm:items-center space-x-2 sm:space-x-3 gap-2">
                      <div className="bg-brand-primary-main rounded-xl text-ui-background-primary py-2 px-2 sm:py-3 sm:px-3 shrink-0">
                        <img src={pillIcon} alt="Logo" className="w-4 h-4 sm:w-5 sm:h-5" />
                      </div>
                      <div className="flex flex-col min-w-0">
                        <div className="text-(--cds-color-text-heading) text-lg sm:text-xl font-bold wrap-break-word min-w-0">
                          {vendorData.name} • {vendorData.vendor_nbr}
                        </div>
                        <p className="text-sm text-ui-text-secondary">
                          {vendorData.city && vendorData.country
                            ? `${vendorData.city}, ${vendorData.country}`
                            : vendorData.city || vendorData.country || ""}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <VendorDetailCards
                  vendorData={vendorData}
                  averageServiceLevel={averageServiceLevel}
                  serviceLevels={serviceLevels}
                  className="grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
                />
              </>
            )}
          </div>
        </div>
        {!isComparisonMode && (
          <DataViewLayout
            title="Supplier Risk Assessment"
            subtitle={`Displays all pharmaceutical products from ${vendorData.name} filtered by highest risk score, showing key risk indicators including driving risk percentages, primary risk classifications, risk-adjusted values, material status, NDC information, and action statuses.`}
            data={filteredMaterials}
            loading={materialsLoading && filteredMaterials.length === 0}
            hasMore={hasMore}
            viewMode={viewMode}
            onLoadMore={handleLoadMore}
            badge={
              <span className="text-sm font-bold text-[#3B3B3B] bg-white rounded-full px-2 py-1 border-1 border-[#CBD5E1]">
                {filteredTotal ? `${filteredTotal} Materials` : "Materials"}
              </span>
            }
            filters={
              <div className="flex flex-col space-y-3 w-full">
                <Filters
                  filters={filters}
                  setFilters={setFilters}
                  config={dynamicFiltersConfig}
                  dynamicMaxValues={materialRangeMaxes}
                />
                <AppliedFilters filters={filters} setFilters={setFilters} config={materialAppliedFiltersConfig} />
              </div>
            }
            renderCard={material => (
              <MaterialRiskCard
                key={material.id}
                material={material}
                isComparisonMode={isComparisonMode}
                vendorId={vendorId ?? undefined}
              />
            )}
            renderTable={tableMaterials => (
              <MaterialRiskTable
                materials={tableMaterials}
                isComparisonMode={isComparisonMode}
                currentPage={currentPage}
                pageSize={pageSize}
                total={total}
                onPageChange={handlePageChange}
                onPageSizeChange={handlePageSizeChange}
                vendorId={vendorId ?? undefined}
              />
            )}
          />
        )}
        <svg
          width="0"
          height="0"
          style={{
            position: "absolute",
            width: 0,
            height: 0,
            overflow: "hidden",
          }}
          aria-hidden="true"
          focusable="false"
        >
          <defs>
            <linearGradient id="line-gradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#461E96" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#693DC6" stopOpacity="0.7" />
              <stop offset="100%" stopColor="#461E96" stopOpacity="0.1" />
            </linearGradient>
          </defs>
        </svg>
      </main>

      {showMaterialRiskDriverModal && (
        <MaterialRiskDriverModal
          isOpen={showMaterialRiskDriverModal}
          onClose={() => {
            setShowMaterialRiskDriverModal(false);
            setModalVendorData(null);
          }}
          materialName="Vendor Risk Analysis"
          vendorName={
            modalVendorData
              ? `${modalVendorData.name}${modalVendorData.vendor_nbr ? ` • ${modalVendorData.vendor_nbr}` : ""}`
              : "Unknown Vendor"
          }
          overallRiskScore={(modalVendorData?.risk_rating || 0) * 100}
          dollarsAtRisk={modalVendorData?.risk_adjusted_value || 0}
          riskLevel={modalVendorData?.risk_rating || 0}
        />
      )}
    </DashboardLayout>
  );
}
interface VendorComparisonContentProps {
  vendor: VendorData | VendorRawData;
  materials: ReturnType<typeof transformMaterialsData>;
  filters: Record<string, unknown>;
  setFilters: (filters: Record<string, unknown>) => void;
  filtersConfig: FiltersConfig;
  viewMode: "card" | "table" | undefined;
  isComparisonMode: boolean;
  /** The *panel's own* vendor id (left = primary, right = comparison). */
  panelVendorId?: number;
}

function VendorComparisonContent({
  vendor,
  materials,
  filters,
  setFilters,
  filtersConfig,
  viewMode,
  isComparisonMode,
  panelVendorId,
}: VendorComparisonContentProps) {
  // Each panel resolves its own range max so the two sides don't share state.
  const comparisonRangeParams = useMemo(() => (panelVendorId ? { supplier: String(panelVendorId) } : undefined), [panelVendorId]);
  const { maxes: comparisonRangeMaxes } = useFilterRangesQuery({
    module: "material",
    keys: ["risk_adjusted_value"],
    params: comparisonRangeParams,
  });
  const vendorRiskBadge = getRiskBadge(vendor.risk_rating);
  const serviceLevels = vendor.service_levels_90_days ?? [];
  const averageServiceLevel =
    serviceLevels.length > 0
      ? serviceLevels.reduce((sum: number, s: any) => {
          const orderQty = s.total_order_qty ?? 0;
          const receivedQty = s.total_received_qty ?? 0;
          return sum + (orderQty > 0 ? (receivedQty / orderQty) * 100 : 0);
        }, 0) / serviceLevels.length
      : 0;

  return (
    <div className="w-full">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-3">
        <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
          <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
            <img src={pillIcon} alt="Pill Icon" className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
            <div className="text-lg sm:text-xl font-bold text-ui-text-primary wrap-break-word min-w-0">
              {vendor.name} • {vendor.vendor_nbr}
            </div>
            <div className={`${vendorRiskBadge.className} text-xs shrink-0`}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-3 h-3 mr-1 shrink-0"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
                />
              </svg>
              <span className="whitespace-nowrap">{vendorRiskBadge.text}</span>
            </div>
          </div>
          <div className="flex items-center flex-wrap gap-x-2 text-sm text-ui-text-secondary">
            <span className="hidden sm:inline">•</span>
            <span className="hidden sm:inline">{vendor.country}</span>
          </div>
        </div>
      </div>

      <div className="bg-ui-background-primary rounded-[10px] border border-[#E2E8F0] p-6 mb-6">
        <VendorDetailCards
          vendorData={vendor}
          averageServiceLevel={averageServiceLevel}
          serviceLevels={serviceLevels}
          className="grid-cols-1 md:grid-cols-2"
        />
      </div>

      <DataViewLayout
        title="Supplier Risk Assessment"
        subtitle={`Displays all pharmaceutical products from ${vendor.name} • ${vendor.vendor_nbr} filtered by highest risk score.`}
        data={materials}
        loading={false}
        hasMore={false}
        viewMode={viewMode}
        filters={
          <div className="flex flex-col space-y-3 w-full">
            <div className="[&_.grid]:flex! [&_.grid]:flex-col! [&_.grid]:gap-4! space-y-3">
              <Filters filters={filters} setFilters={setFilters} config={filtersConfig} dynamicMaxValues={comparisonRangeMaxes} />
              <AppliedFilters filters={filters} setFilters={setFilters} config={materialAppliedFiltersConfig} />
            </div>
          </div>
        }
        renderCard={material => (
          <div className="w-full">
            <MaterialRiskCard
              key={material.id}
              material={material}
              isComparisonMode={isComparisonMode}
              vendorId={panelVendorId}
            />
          </div>
        )}
        renderTable={tableMaterials => (
          <MaterialRiskTable
            materials={tableMaterials}
            isComparisonMode={isComparisonMode}
            currentPage={1}
            pageSize={10}
            total={materials.length}
            onPageChange={() => {}}
            onPageSizeChange={() => {}}
            vendorId={panelVendorId}
          />
        )}
      />
    </div>
  );
}
