import type { TenantType } from "@/tenant";

export const OVERVIEW_BOTTOM_BY_TENANT = {
  customer: {
    highRiskSuppliers: true,
    highRiskMaterials: true,
    currentVsPrior: false,
  },
  vendor: {
    highRiskSuppliers: false,
    highRiskMaterials: true,
    currentVsPrior: true,
  },
  customer_vendor: {
    highRiskSuppliers: false,
    highRiskMaterials: false,
    currentVsPrior: true,
  },
} as const satisfies Record<TenantType, { highRiskSuppliers: boolean; highRiskMaterials: boolean; currentVsPrior: boolean }>;

export type OverviewBottomSlots = (typeof OVERVIEW_BOTTOM_BY_TENANT)[TenantType];

export function getOverviewBottomSlots(type?: TenantType): OverviewBottomSlots | undefined {
  return type ? OVERVIEW_BOTTOM_BY_TENANT[type] : undefined;
}
