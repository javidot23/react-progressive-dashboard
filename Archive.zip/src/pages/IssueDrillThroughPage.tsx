import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import DashboardLayout from "@/components/templates/DashboardLayout";
import CardLayout from "@/components/templates/CardLayout";
import { Pagination } from "@/components/atoms";
import { ROUTES } from "@/constants/routes";
import {
  useGranularityIssueByIdQuery,
  useIssueImpactedMaterialsQuery,
  useIssueDrivingEventQuery,
  useFilterRangesQuery,
} from "@/hooks/queries";
import useRemoveActionMutation from "@/hooks/queries/useRemoveActionMutation";
import { useRiskModelDescriptions } from "@/hooks";
import { useImpactedMaterialSelection } from "@/hooks/useImpactedMaterialSelection";
import { RiskScoreGauge } from "@/components/material-drill-through/RiskScoreGauge";
import { DrivingEventPanel } from "@/components/material-drill-through/DrivingEventPanel";
import { KeepInMindModal } from "@/components/molecules/KeepInMindModal";
import { RemoveActionConfirmModal } from "@/components/molecules/RemoveActionConfirmModal";
import Filters from "@/components/atoms/Filters";
import AppliedFilters from "@/components/atoms/AppliedFilters";
import { impactedMaterialsFiltersConfig, impactedMaterialsAppliedFiltersConfig } from "@/lib/filterConfigs";
import { ImpactedMaterialsTable } from "@/components/issue-drill-through/ImpactedMaterialsTable";
import { StickyActionBar } from "@/components/issue-drill-through/StickyActionBar";
import { useIssueActionFlow, NO_ACTION_TYPE, SWITCH_MANUFACTURER_TYPE } from "@/hooks/useIssueActionFlow";
import { mapGranularityIssue } from "@/lib/granularity";
import { formatCurrencyCompact } from "@/lib/utils";
import { formatMaterialActionActorLabel, formatMaterialActionDateOnly } from "@/lib/materialActionDisplay";
import { navigateToMaterialDetail, type IssueDrillThroughLocationState } from "@/lib/issueDrillThroughUtils";
import { fetchAllIssueImpactedMaterialNbrs } from "@/services/issueService";
import { isMaterialActionOwner } from "@/lib/materialActionOwnership";
import { useAuth } from "@/contexts/AuthContext";
import { selectTenantPortalFlags, useTenantContextQuery } from "@/tenant";
import type { IssueImpactedMaterialApiData } from "@/types/granularityIssue";
import type { PotentialAction, MaterialAction } from "@/lib/types";

const MATERIALS_PAGE_SIZE = 50;
const DEFAULT_MAT_PAGE = 1;
const DEFAULT_MAT_FILTERS = impactedMaterialsAppliedFiltersConfig.defaultFilters;
const ACTION_CATEGORY_ORDER = ["Tactical", "Strategic", "Operational"];

interface ChosenAction {
  type: string;
  /** Unique per potential-action row — never use recommendation_type_nbr alone for selection UI. */
  pactionNbr: string | null;
  label: string;
  potentialAction?: PotentialAction;
  isSubstitution: boolean;
}

const NO_ACTION_CHOSEN: ChosenAction = {
  type: NO_ACTION_TYPE,
  pactionNbr: null,
  label: "No Action Required",
  isSubstitution: false,
};

/** A recorded action on the issue (ActionSerializer shape — only the fields we display). */
interface TakenActionRecord {
  id?: number;
  user_id?: string;
  action?: string | null;
  created_at?: string;
  user?: { id?: string; first_name?: string; last_name?: string } | null;
  potential_action?: {
    recommendation_type_nbr?: string;
    paction_nbr?: string;
    recommendation?: string;
  } | null;
}

interface PendingIssueRemove {
  takenAction: TakenActionRecord;
  actionLabel: string;
  partNumber: string;
}

function resolveTakenActionPartNumber(
  takenAction: TakenActionRecord,
  typeKey: string,
  potentialActions: PotentialAction[]
): string | null {
  if (takenAction.potential_action?.paction_nbr) {
    return takenAction.potential_action.paction_nbr;
  }
  if (typeKey === NO_ACTION_TYPE) {
    return "no_action";
  }
  return potentialActions.find(pa => pa.recommendation_type_nbr === typeKey)?.paction_nbr ?? null;
}

function takenActionToModalDetails(takenAction: TakenActionRecord): MaterialAction {
  return {
    id: takenAction.id ?? 0,
    issue_nbr: "",
    user_id: takenAction.user_id ?? "",
    user: takenAction.user
      ? {
          id: takenAction.user.id ?? "",
          first_name: takenAction.user.first_name ?? "",
          last_name: takenAction.user.last_name ?? "",
        }
      : null,
    created_at: takenAction.created_at ?? "",
    updated_at: takenAction.created_at ?? "",
    potential_action: takenAction.potential_action as MaterialAction["potential_action"],
    action: takenAction.action ?? null,
    substituted_material: null,
    material_number: "",
    material_name: "",
    vendor_name: "",
  };
}

/** "Taken by … · date" line shown under an action that has already been recorded. */
function TakenBadge({ action }: { action: TakenActionRecord }) {
  return (
    <span className="mt-1 inline-flex items-center gap-1.5 text-2xs font-semibold text-[#119D63]">
      <span className="inline-flex items-center justify-center rounded-full border border-[#06C07A] bg-[#D8FEE7] p-0.5">
        <span className="h-1.5 w-1.5 rounded-full bg-[#119D63]" />
      </span>
      Taken by {formatMaterialActionActorLabel(action)} · {formatMaterialActionDateOnly(action.created_at)}
    </span>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col">
      <span className="text-xs text-ui-text-secondary">{label}</span>
      <span className="text-sm font-semibold text-ui-text-primary">{value || "-"}</span>
    </div>
  );
}

export default function IssueDrillThroughPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: flags } = useTenantContextQuery(selectTenantPortalFlags);
  const substitutionAnalysisEnabled = Boolean(flags?.features.productSubstitutionAnalysis);
  const { issueId: issueIdParam } = useParams<{ issueId: string }>();
  const location = useLocation();
  const navState = (location.state as IssueDrillThroughLocationState | null) ?? {};
  const { getEnrichedMetadata } = useRiskModelDescriptions();

  const issueIdFromUrl = Number(issueIdParam);
  const isValidIssueId = Number.isFinite(issueIdFromUrl) && issueIdFromUrl > 0;

  const { issue: issueDetail, isLoading: issueLoading } = useGranularityIssueByIdQuery({
    issueId: isValidIssueId ? issueIdFromUrl : undefined,
    enabled: isValidIssueId,
  });

  const {
    event: drivingEvent,
    isLoading: drivingEventLoading,
    isFetching: drivingEventFetching,
  } = useIssueDrivingEventQuery({
    issueId: isValidIssueId ? issueIdFromUrl : undefined,
    enabled: isValidIssueId,
  });

  // Server-side ordering + range filters for the impacted-materials table (default RAV high→low).
  const [matFilters, setMatFilters] = useState<Record<string, unknown>>(() => ({ ...DEFAULT_MAT_FILTERS }));
  const [matPage, setMatPage] = useState(DEFAULT_MAT_PAGE);
  const [matPageSize, setMatPageSize] = useState(MATERIALS_PAGE_SIZE);

  const { maxes: materialRangeMaxes } = useFilterRangesQuery({
    module: "issue_impacted_materials",
    keys: ["risk_adjusted_value", "dollars_at_risk"],
    params: isValidIssueId ? { issue_id: issueIdFromUrl } : undefined,
    enabled: isValidIssueId,
  });

  const {
    materials,
    total: materialsTotal,
    isLoading: materialsLoading,
    isPlaceholderData,
    isFetching: materialsFetching,
  } = useIssueImpactedMaterialsQuery({
    issueId: isValidIssueId ? issueIdFromUrl : undefined,
    page: matPage,
    pageSize: matPageSize,
    filters: matFilters,
    enabled: isValidIssueId,
  });

  // View-model for the summary (seeded from nav state until detail resolves).
  const view = useMemo(
    () => (issueDetail ? mapGranularityIssue(issueDetail, getEnrichedMetadata) : null),
    [issueDetail, getEnrichedMetadata]
  );

  const title = view?.productName ?? navState.title ?? "Issue";
  const granularityLabel = view?.granularityLabel ?? navState.granularityLabel ?? "Issue";
  const granularityValue = view?.granularityValue ?? navState.granularityValue ?? "";
  const riskLevel = view?.riskLevel ?? Math.round((navState.effectiveRiskRating ?? 0) * 100);
  const aggregateDollars = view?.effectiveDollarsAtRisk ?? navState.effectiveDollarsAtRisk ?? 0;
  const impactedCount = view?.impactedMaterialCount ?? navState.impactedMaterialCount ?? materialsTotal;
  const issueNbr = view?.issueNbr ?? navState.issueNbr;

  const potentialActions = useMemo<PotentialAction[]>(() => {
    const source = (issueDetail?.potential_actions ?? navState.potentialActions ?? []) as PotentialAction[];
    return source;
  }, [issueDetail?.potential_actions, navState.potentialActions]);

  // Actions already recorded on this issue, keyed by unique paction_nbr (+ a "no_action" entry).
  const takenActionsByPactionNbr = useMemo(() => {
    const map = new Map<string, TakenActionRecord>();
    const source = (issueDetail?.actions ?? navState.actions ?? []) as TakenActionRecord[];
    for (const action of source) {
      const pactionKey = action?.potential_action?.paction_nbr;
      if (pactionKey && !map.has(pactionKey)) map.set(pactionKey, action);
      if (action?.action === "no_action" && !map.has(NO_ACTION_TYPE)) map.set(NO_ACTION_TYPE, action);
    }
    return map;
  }, [issueDetail?.actions, navState.actions]);

  // Group recommended actions into Tactical / Strategic / Operational (parity with the material
  // page's ActionButtonGroup); anything uncategorized falls into a trailing group.
  const groupedActions = useMemo(() => {
    const known = new Map<string, PotentialAction[]>();
    const uncategorized: PotentialAction[] = [];
    for (const pa of potentialActions) {
      const cat = (pa.action_category ?? "").toString().trim();
      if (cat && ACTION_CATEGORY_ORDER.includes(cat)) {
        const bucket = known.get(cat) ?? [];
        bucket.push(pa);
        known.set(cat, bucket);
      } else {
        uncategorized.push(pa);
      }
    }
    const sections: { title?: string; items: PotentialAction[] }[] = [];
    for (const cat of ACTION_CATEGORY_ORDER) {
      const items = known.get(cat);
      if (items?.length) sections.push({ title: cat, items });
    }
    if (uncategorized.length) sections.push({ items: uncategorized });
    return sections;
  }, [potentialActions]);

  // ----- Selection state (exclusion-based, persists across pagination) -----
  const [query, setQuery] = useState("");
  const [chosen, setChosen] = useState<ChosenAction | null>(null);
  const [pendingRemove, setPendingRemove] = useState<PendingIssueRemove | null>(null);
  const removeActionMutation = useRemoveActionMutation(null);

  const selection = useImpactedMaterialSelection({
    materials,
    materialsTotal,
    impactedCount,
    matFilters,
  });

  const {
    excludedMatNbrs,
    resetSelection,
    actionScopeTotal,
    selectedCount,
    grainExcludedCount,
    applyToWholeGrain,
    toggle,
    toggleAllVisible,
    selectedOnPageCount,
    selectedMaterialRows,
    allVisibleSelected,
  } = selection;

  // Reset page state when navigating to a different issue.
  useEffect(() => {
    setMatFilters({ ...DEFAULT_MAT_FILTERS });
    setMatPage(DEFAULT_MAT_PAGE);
    setQuery("");
    setChosen(null);
    setPendingRemove(null);
    resetSelection();
  }, [issueIdFromUrl, resetSelection]);

  const matFiltersKey = useMemo(() => JSON.stringify(matFilters), [matFilters]);
  useEffect(() => {
    resetSelection();
    setMatPage(DEFAULT_MAT_PAGE);
  }, [matFiltersKey, resetSelection]);

  const filteredMaterials = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return materials;
    return materials.filter(m => [m.name, m.mat_nbr, m.ndc, m.vendor].some(v => (v ?? "").toString().toLowerCase().includes(q)));
  }, [materials, query]);

  const selectedSet = useMemo(() => {
    const next = new Set<string>();
    for (const m of materials) {
      if (!excludedMatNbrs.has(m.mat_nbr)) next.add(m.mat_nbr);
    }
    return next;
  }, [materials, excludedMatNbrs]);

  const selectedDollars = applyToWholeGrain
    ? aggregateDollars
    : selectedMaterialRows.reduce((sum, m) => sum + (m.dollars_at_risk ?? 0), 0);

  const materialsReady = !materialsLoading && !isPlaceholderData;

  const toChosenAction = useCallback(
    (pa: PotentialAction): ChosenAction => ({
      type: pa.recommendation_type_nbr,
      pactionNbr: pa.paction_nbr,
      label: pa.recommendation,
      potentialAction: pa,
      isSubstitution: substitutionAnalysisEnabled && pa.recommendation_type_nbr === SWITCH_MANUFACTURER_TYPE,
    }),
    [substitutionAnalysisEnabled]
  );

  const isPotentialActionChosen = useCallback((pa: PotentialAction) => chosen?.pactionNbr === pa.paction_nbr, [chosen]);

  /** Next untaken action after `afterPactionNbr` (list order, then No Action). No wrap-around. */
  const pickNextAvailableAction = useCallback(
    (taken: Set<string> | Map<string, TakenActionRecord>, after?: { pactionNbr?: string | null }): ChosenAction | null => {
      const isTaken = (slot: string) => (taken instanceof Map ? taken.has(slot) : taken.has(slot));

      if (after) {
        if (after.pactionNbr == null) {
          return null;
        }
        const idx = potentialActions.findIndex(pa => pa.paction_nbr === after.pactionNbr);
        const start = idx >= 0 ? idx + 1 : 0;
        const next = potentialActions.slice(start).find(pa => !isTaken(pa.paction_nbr));
        if (next) return toChosenAction(next);
        if (!isTaken(NO_ACTION_TYPE)) {
          return NO_ACTION_CHOSEN;
        }
        return null;
      }

      const available = potentialActions.filter(pa => !isTaken(pa.paction_nbr));
      const recommended = available.find(pa => pa.recommended_action_flag) ?? available[0];
      if (recommended) return toChosenAction(recommended);
      if (!isTaken(NO_ACTION_TYPE)) {
        return NO_ACTION_CHOSEN;
      }
      return null;
    },
    [potentialActions, toChosenAction]
  );

  // When the selected action becomes recorded (e.g. after refetch), advance to the next available one.
  useEffect(() => {
    if (!chosen) return;
    const takenSlot = chosen.pactionNbr ?? (chosen.type === NO_ACTION_TYPE ? NO_ACTION_TYPE : null);
    if (takenSlot == null || !takenActionsByPactionNbr.has(takenSlot)) return;
    setChosen(pickNextAvailableAction(takenActionsByPactionNbr, { pactionNbr: chosen.pactionNbr }));
  }, [chosen, takenActionsByPactionNbr, pickNextAvailableAction]);

  const resolveMatNbrs = useCallback(async () => {
    if (!isValidIssueId) return [];
    const allNbrs = await fetchAllIssueImpactedMaterialNbrs({
      issueId: issueIdFromUrl,
      filters: matFilters,
      pageSize: matPageSize,
    });
    return allNbrs.filter(nbr => !excludedMatNbrs.has(nbr));
  }, [isValidIssueId, issueIdFromUrl, matFilters, matPageSize, excludedMatNbrs]);

  const actionFlow = useIssueActionFlow({
    issueId: isValidIssueId ? issueIdFromUrl : undefined,
    issueNbr,
    onActionApplied: () => {
      // Advance immediately (before refetch lands) so the sticky bar stays on the next action.
      setChosen(current => {
        if (!current) return null;
        const treatedAsTaken = new Set(takenActionsByPactionNbr.keys());
        if (current.pactionNbr) {
          treatedAsTaken.add(current.pactionNbr);
        } else if (current.type === NO_ACTION_TYPE) {
          treatedAsTaken.add(NO_ACTION_TYPE);
        }
        return pickNextAvailableAction(treatedAsTaken, { pactionNbr: current.pactionNbr });
      });
    },
    selectedMaterials: selectedMaterialRows.map(m => ({
      id: m.id,
      mat_nbr: m.mat_nbr,
      name: m.name,
      vendorName: m.vendor ?? undefined,
      riskRating: m.risk_rating,
      drivingRisk: m.driving_risk,
      dollarsAtRisk: m.dollars_at_risk,
    })),
    applyToWholeGrain,
    selectedCount,
    totalCount: actionScopeTotal,
    aggregate: {
      riskRating: view?.effectiveRiskRating,
      drivingRisk: view?.drivingRiskRaw,
      dollarsAtRisk: aggregateDollars,
    },
    resolveMatNbrs: applyToWholeGrain ? undefined : resolveMatNbrs,
  });

  const handleRowClick = (material: IssueImpactedMaterialApiData) => {
    navigateToMaterialDetail(navigate, {
      materialId: material.id,
      matNbr: material.mat_nbr,
      name: material.name,
      ndc: material.ndc ?? undefined,
      vendorName: material.vendor ?? undefined,
      vendorNbr: material.vendor_nbr ?? undefined,
      riskLevel: Math.round((material.risk_rating ?? 0) * 100),
      dollarsAtRisk: material.dollars_at_risk,
      from: "issue",
      originIssueId: issueIdFromUrl,
    });
  };

  const handleApply = () => {
    if (!chosen) return;
    actionFlow.handleActionClick(chosen.type, chosen.potentialAction);
  };

  const handleRemoveClick = (takenAction: TakenActionRecord, typeKey: string, actionLabel: string) => {
    if (!isMaterialActionOwner(takenAction, user?.entra_id)) return;
    const partNumber = resolveTakenActionPartNumber(takenAction, typeKey, potentialActions);
    if (!partNumber || takenAction.id == null) return;
    setPendingRemove({ takenAction, actionLabel, partNumber });
  };

  const handleRemoveConfirm = () => {
    if (!pendingRemove || !isValidIssueId || removeActionMutation.isPending) return;
    if (!isMaterialActionOwner(pendingRemove.takenAction, user?.entra_id)) {
      setPendingRemove(null);
      return;
    }

    removeActionMutation.mutate(
      {
        actionId: pendingRemove.takenAction.id!,
        issueId: issueIdFromUrl,
        partNumber: pendingRemove.partNumber,
      },
      {
        onSuccess: () => {
          setPendingRemove(null);
        },
      }
    );
  };

  const renderDeleteActionButton = (takenAction: TakenActionRecord, typeKey: string, actionLabel: string) => {
    if (!takenAction.id || !isMaterialActionOwner(takenAction, user?.entra_id)) return null;
    if (!resolveTakenActionPartNumber(takenAction, typeKey, potentialActions)) return null;

    return (
      <button
        type="button"
        onClick={e => {
          e.stopPropagation();
          handleRemoveClick(takenAction, typeKey, actionLabel);
        }}
        className="flex shrink-0 items-center gap-2 rounded border-2 border-neutral-200 px-2 py-1 text-xs font-bold text-brand-primary-main transition-all duration-200 hover:border-brand-primary-main hover:bg-purple-50"
        aria-label={`Delete ${actionLabel} action`}
      >
        Delete Action
      </button>
    );
  };

  const renderActionButton = (pa: PotentialAction) => {
    const isChosen = isPotentialActionChosen(pa);
    const otherModule = pa.module && pa.module !== "React";
    const takenAction = takenActionsByPactionNbr.get(pa.paction_nbr);
    // Once this specific potential action has been recorded it is locked.
    const isTaken = Boolean(takenAction);
    return (
      <div key={pa.paction_nbr} className="flex flex-col gap-2 sm:flex-row sm:items-start">
        <button
          type="button"
          disabled={isTaken}
          aria-disabled={isTaken}
          aria-pressed={isChosen}
          onClick={
            isTaken ? undefined : () => setChosen(current => (current?.pactionNbr === pa.paction_nbr ? null : toChosenAction(pa)))
          }
          className={`flex flex-1 items-start gap-2 rounded-md border p-3 text-left transition-colors ${
            isTaken
              ? "border-[#E2E8F0] opacity-70 cursor-not-allowed"
              : isChosen
                ? "border-brand-primary-main bg-brand-primary-50"
                : "border-[#E2E8F0] hover:border-brand-primary-200"
          }`}
        >
          <span
            className={`mt-0.5 h-4 w-4 shrink-0 rounded-full border-2 ${
              isChosen && !isTaken ? "border-brand-primary-main bg-brand-primary-main" : "border-[#CBD5E1]"
            }`}
          />
          <span className="min-w-0">
            <span className="text-sm font-semibold text-ui-text-primary">{pa.recommendation}</span>
            {otherModule ? (
              <span className="mt-0.5 block text-xs text-ui-text-secondary">action lives in {pa.module}</span>
            ) : null}
            {takenAction ? (
              <span className="block">
                <TakenBadge action={takenAction} />
              </span>
            ) : null}
          </span>
        </button>
        {takenAction ? renderDeleteActionButton(takenAction, pa.recommendation_type_nbr, pa.recommendation) : null}
      </div>
    );
  };

  if (!isValidIssueId) {
    return (
      <DashboardLayout hideBanner>
        <p className="text-red-600 py-8">Invalid issue ID.</p>
        <button
          type="button"
          onClick={() => navigate(ROUTES.REACT)}
          className="text-brand-primary-main font-semibold hover:underline"
        >
          Back to issue feed
        </button>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout hideBanner className="bg-white">
      <div style={{ paddingBottom: 150 }}>
        <button
          type="button"
          onClick={() => navigate(ROUTES.REACT)}
          className="flex items-center gap-1 text-sm text-[#6E6E6E] hover:text-brand-primary-main my-6 transition-colors"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={2}
            stroke="currentColor"
            className="w-4 h-4"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
          </svg>
          Back to issue feed
        </button>

        {/* Issue summary */}
        <div className="rounded-[10px] border border-[#E2E8F0] bg-white p-6 shadow-xs">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
            <div className="min-w-0">
              <span className="inline-flex items-center gap-1.5 rounded bg-brand-primary-100 text-brand-primary-main border border-brand-primary-200 px-2 py-0.5 text-2xs font-semibold">
                {granularityLabel}
                {granularityValue ? <span className="font-mono">{granularityValue}</span> : null}
              </span>
              <h1 className="mt-2 text-2xl font-bold text-ui-text-primary">{title}</h1>
              <div className="mt-4 flex flex-wrap gap-x-8 gap-y-3">
                <Fact label="Group" value={view?.group ?? navState.group ?? "-"} />
                <Fact label="Persona" value={view?.persona ?? navState.persona ?? "-"} />
                <Fact label="Identified" value={view?.createdAt ?? navState.dateIdentified ?? "-"} />
                <Fact label="Status" value={view?.status ?? navState.status ?? "-"} />
                <Fact label="Driving Risk" value={view?.drivingRisk ?? navState.drivingRisk ?? "-"} />
              </div>
            </div>
            <div className="flex items-center gap-8 shrink-0">
              <RiskScoreGauge score={riskLevel} />
              <div className="flex flex-col gap-4">
                <div>
                  <div className="text-xs text-ui-text-secondary">Aggregate $ at Risk</div>
                  <div className="text-xl font-bold text-[#E22F00]">{formatCurrencyCompact(aggregateDollars, true)}</div>
                </div>
                <div>
                  <div className="text-xs text-ui-text-secondary">Materials Affected</div>
                  <div className="text-xl font-bold text-ui-text-primary">{impactedCount}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Driving event + recommended actions */}
        <div className="mt-6 grid grid-cols-1 xl:grid-cols-[1.5fr_1fr] gap-6">
          <DrivingEventPanel event={drivingEvent} isLoading={drivingEventLoading} isFetching={drivingEventFetching} />

          <CardLayout title="Recommended Actions" className="flex h-full min-h-0 flex-col">
            <div className="flex max-h-[400px] flex-col gap-4 overflow-y-auto">
              {potentialActions.length === 0 && !issueLoading ? (
                <p className="text-sm text-ui-text-secondary">No recommended actions for this issue.</p>
              ) : null}
              {groupedActions.map((section, index) => (
                <div key={section.title ?? `uncategorized-${index}`} className="flex flex-col gap-2">
                  {section.title ? (
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-[#525252] whitespace-nowrap">{section.title}</p>
                      <hr className="flex-1 border-t border-[#E0E0E0]" />
                    </div>
                  ) : null}
                  {section.items.map(renderActionButton)}
                </div>
              ))}
              {/* No Action Required */}
              {(() => {
                const noActionTaken = takenActionsByPactionNbr.get(NO_ACTION_TYPE);
                const isChosen = chosen?.type === NO_ACTION_TYPE;
                const isTaken = Boolean(noActionTaken);
                return (
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-start">
                    <button
                      type="button"
                      disabled={isTaken}
                      aria-disabled={isTaken}
                      onClick={
                        isTaken
                          ? undefined
                          : () => setChosen(current => (current?.type === NO_ACTION_TYPE ? null : NO_ACTION_CHOSEN))
                      }
                      className={`flex flex-1 items-start gap-2 rounded-md border p-3 text-left transition-colors ${
                        isTaken
                          ? "border-[#E2E8F0] opacity-70 cursor-not-allowed"
                          : isChosen
                            ? "border-brand-primary-main bg-brand-primary-50"
                            : "border-[#E2E8F0] hover:border-brand-primary-200"
                      }`}
                    >
                      <span
                        className={`mt-0.5 h-4 w-4 shrink-0 rounded-full border-2 ${
                          isChosen && !isTaken ? "border-brand-primary-main bg-brand-primary-main" : "border-[#CBD5E1]"
                        }`}
                      />
                      <span className="min-w-0">
                        <span className="text-sm font-semibold text-ui-text-primary">No Action Required</span>
                        {noActionTaken ? (
                          <span className="block">
                            <TakenBadge action={noActionTaken} />
                          </span>
                        ) : null}
                      </span>
                    </button>
                    {noActionTaken ? renderDeleteActionButton(noActionTaken, NO_ACTION_TYPE, "No Action Required") : null}
                  </div>
                );
              })()}
            </div>
          </CardLayout>
        </div>

        {/* Impacted materials */}
        <div className="mt-6">
          <CardLayout title="Impacted Materials">
            {/* Server-side sort + range filters for this issue's materials */}
            <div className="space-y-3">
              <Filters
                filters={matFilters}
                setFilters={setMatFilters}
                config={impactedMaterialsFiltersConfig}
                dynamicMaxValues={materialRangeMaxes}
              />
              <AppliedFilters filters={matFilters} setFilters={setMatFilters} config={impactedMaterialsAppliedFiltersConfig} />
            </div>
            <div className="mb-3 mt-3 flex flex-wrap items-center justify-between gap-3">
              <div className="relative">
                <input
                  type="search"
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  placeholder="Search materials"
                  className="w-64 max-w-full rounded-md border border-[#CBD5E1] px-3 py-2 text-sm"
                />
              </div>
              <div className="flex items-center gap-3 text-sm">
                <span className="text-ui-text-secondary">
                  {selectedOnPageCount} of {materials.length} on this page · {selectedCount} of {actionScopeTotal} total selected
                </span>
                <button
                  type="button"
                  onClick={() => toggleAllVisible(filteredMaterials)}
                  className="font-semibold text-brand-primary-main hover:underline"
                >
                  {allVisibleSelected ? "Deselect all" : "Select all"}
                </button>
              </div>
            </div>
            <div className="mb-3 rounded-md bg-brand-primary-50 px-3 py-2 text-xs text-brand-primary-main">
              By default the action applies to <strong>all</strong> impacted materials. Uncheck any material to exclude it, or
              click a row to open its detail.
            </div>
            {!materialsReady ? (
              <div className="h-32 animate-pulse rounded-md bg-gray-100" />
            ) : (
              <ImpactedMaterialsTable
                materials={filteredMaterials}
                selected={selectedSet}
                onToggle={toggle}
                onRowClick={handleRowClick}
              />
            )}
            {materialsTotal > 0 ? (
              <Pagination
                currentPage={matPage}
                pageSize={matPageSize}
                total={materialsTotal}
                onPageChange={setMatPage}
                onPageSizeChange={size => {
                  setMatPageSize(size);
                  setMatPage(DEFAULT_MAT_PAGE);
                }}
                itemName="Materials"
                isLoading={materialsFetching}
                className="mt-4"
              />
            ) : null}
          </CardLayout>
        </div>
      </div>

      <StickyActionBar
        actionLabel={chosen?.label ?? null}
        selectedCount={selectedCount}
        totalCount={actionScopeTotal}
        selectedDollars={selectedDollars}
        isSubstitution={chosen?.isSubstitution ?? false}
        onApply={handleApply}
        isSubmitting={actionFlow.isActionMutationPending}
      />

      {actionFlow.modalState.type === "keepInMind" && (
        <KeepInMindModal
          isOpen
          onClose={actionFlow.closeModal}
          onContinue={actionFlow.handleKeepInMindContinue}
          isSubmitting={actionFlow.isActionMutationPending}
          summary={{
            actionLabel: chosen?.label,
            actionType: chosen?.potentialAction?.action_category ?? chosen?.potentialAction?.action_type,
            appliesToCount: selectedCount,
            totalCount: actionScopeTotal,
            excludedCount: grainExcludedCount,
            exposure: formatCurrencyCompact(selectedDollars, true),
          }}
        />
      )}

      <RemoveActionConfirmModal
        isOpen={Boolean(pendingRemove)}
        onClose={() => setPendingRemove(null)}
        onConfirm={handleRemoveConfirm}
        actionDetails={pendingRemove ? takenActionToModalDetails(pendingRemove.takenAction) : null}
        actionLabelOverride={pendingRemove?.actionLabel}
        issueLevel
        isSubmitting={removeActionMutation.isPending}
      />
    </DashboardLayout>
  );
}
