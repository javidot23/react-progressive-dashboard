import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useLocation, useSearchParams } from "react-router-dom";
import DashboardLayout from "@/components/templates/DashboardLayout";
import { ROUTES } from "@/constants/routes";
import {
  useIssueByIdQuery,
  useMaterialRiskQuery,
  useMaterialSubstituteDetailsQuery,
  useIssueDrivingEventQuery,
  useMaterialRiskWeeklyAveragesQuery,
  useMaterialActionHistoryQuery,
} from "@/hooks/queries";
import { useRiskModelDescriptions } from "@/hooks";
import { MaterialSummaryHeader } from "@/components/material-drill-through/MaterialSummaryHeader";
import {
  MaterialDrillTabs,
  parseMaterialDrillTab,
  MATERIAL_DRILL_TAB_QUERY_KEY,
} from "@/components/material-drill-through/MaterialDrillTabs";
import { DrivingEventPanel } from "@/components/material-drill-through/DrivingEventPanel";
import { DrivingRiskEventsTimeline } from "@/components/material-drill-through/DrivingRiskEventsTimeline";
import { MaterialRiskScoreChart } from "@/components/material-drill-through/MaterialRiskScoreChart";
import { RecommendedActionsCard } from "@/components/material-drill-through/RecommendedActionsCard";
import { ActionHistoryPanel } from "@/components/material-drill-through/ActionHistoryPanel";
import { MaterialProfileCard } from "@/components/material-drill-through/MaterialProfileCard";
import { VendorProfileCard } from "@/components/material-drill-through/VendorProfileCard";
import { IssueNotesCard } from "@/components/molecules/IssueNotesCard";
import {
  isIssueActionResolved,
  isIssueCreatedToday,
  issueToMaterialWithIssues,
  MATERIAL_DRILL_MATERIAL_ID_QUERY_KEY,
  type MaterialDrillThroughLocationState,
} from "@/lib/materialDrillThroughUtils";

const ACTION_HISTORY_PAGE_SIZE = 10;

export default function MaterialDrillThroughPage() {
  const navigate = useNavigate();
  const { issueId: issueIdParam } = useParams<{ issueId: string }>();
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();
  const navState = (location.state as MaterialDrillThroughLocationState | null) ?? {};

  const issueIdFromUrl = Number(issueIdParam);
  const isValidIssueId = Number.isFinite(issueIdFromUrl) && issueIdFromUrl > 0;

  const materialIdFromQuery = useMemo(() => {
    const raw = searchParams.get(MATERIAL_DRILL_MATERIAL_ID_QUERY_KEY);
    if (!raw) return undefined;
    const parsed = Number(raw);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
  }, [searchParams]);

  const { issue: issueDetail, isLoading: issueDetailLoading } = useIssueByIdQuery({
    issueId: isValidIssueId ? issueIdFromUrl : undefined,
    enabled: isValidIssueId,
  });

  const issueMaterial = issueDetail?.material;
  const materialId =
    issueMaterial?.id ??
    navState.materialId ??
    materialIdFromQuery;
  const isValidMaterialId = materialId != null && Number.isFinite(materialId) && materialId > 0;

  useEffect(() => {
    if (!issueMaterial?.id || !searchParams.has(MATERIAL_DRILL_MATERIAL_ID_QUERY_KEY)) {
      return;
    }
    const next = new URLSearchParams(searchParams);
    next.delete(MATERIAL_DRILL_MATERIAL_ID_QUERY_KEY);
    setSearchParams(next, { replace: true });
  }, [issueMaterial?.id, searchParams, setSearchParams]);

  const activeTab = parseMaterialDrillTab(searchParams.get(MATERIAL_DRILL_TAB_QUERY_KEY));
  const [actionHistoryPage, setActionHistoryPage] = useState(1);

  const { details, isLoading: detailsLoading } = useMaterialSubstituteDetailsQuery({
    materialId: isValidMaterialId ? materialId : undefined,
    enabled: isValidMaterialId,
  });

  const matNbr = issueMaterial?.mat_nbr ?? details?.material?.mat_nbr ?? navState.matNbr ?? "";

  useEffect(() => {
    setActionHistoryPage(1);
  }, [matNbr]);

  const issueId = isValidIssueId ? issueIdFromUrl : navState.issueId;

  const { riskData: rawRiskData, isLoading: riskLoading } = useMaterialRiskQuery({
    materialId: isValidMaterialId ? materialId : undefined,
    enabled: isValidMaterialId,
  });

  const {
    event: drivingEvent,
    isLoading: drivingEventLoading,
    isFetching: drivingEventFetching,
  } = useIssueDrivingEventQuery({
    issueId: isValidIssueId ? issueIdFromUrl : undefined,
    enabled: isValidIssueId,
  });

  const { weeklyData, isLoading: weeklyLoading } = useMaterialRiskWeeklyAveragesQuery({
    matNbr,
    enabled: !!matNbr,
  });

  const {
    actions: actionHistory,
    total: actionHistoryTotal,
    isLoading: actionHistoryLoading,
    isFetching: actionHistoryFetching,
  } = useMaterialActionHistoryQuery({
    matNbr,
    page: actionHistoryPage,
    pageSize: ACTION_HISTORY_PAGE_SIZE,
    enabled: isValidMaterialId && !!matNbr && activeTab === "actions",
  });

  const { enrichRiskData, getEnrichedMetadata } = useRiskModelDescriptions();
  const enrichedRiskData = useMemo(() => enrichRiskData(rawRiskData), [enrichRiskData, rawRiskData]);

  const material = details?.material;
  const riskRating =
    material?.risk_rating ??
    issueMaterial?.risk_rating ??
    (navState.riskLevel != null ? navState.riskLevel / 100 : 0);
  const riskScore = Math.round(riskRating * (riskRating <= 1 ? 100 : 1));
  const dollarsAtRisk = material?.dollars_at_risk ?? issueMaterial?.dollars_at_risk ?? navState.dollarsAtRisk ?? 0;
  const riskAdjustedValue = issueDetail?.risk_adjusted_value ?? Math.round((riskScore / 100) * dollarsAtRisk);

  const vendorIdFromMaterial =
    typeof material?.vendor === "object"
      ? material.vendor.id
      : issueMaterial?.vendor?.id;

  const vendorNbr =
    (typeof material?.vendor === "object" ? material.vendor.vendor_nbr : undefined) ??
    issueMaterial?.vendor?.vendor_nbr ??
    navState.vendorNbr;

  const mergedIssueRow = issueDetail;

  const actionResolved = isIssueActionResolved(
    mergedIssueRow?.actions,
    navState.actionStatus === "Reviewed"
  );

  const isNewIssue = mergedIssueRow?.created_at
    ? isIssueCreatedToday(mergedIssueRow.created_at)
    : Boolean(navState.isNewIssue);

  const materialVendor =
    typeof material?.vendor === "object"
      ? { id: material.vendor.id, name: material.vendor.name }
      : undefined;

  const drivingRiskRawForActions =
    material?.driving_risk ??
    navState.drivingRisk ??
    issueMaterial?.driving_risk;

  const drivingRiskLabel = useMemo(() => {
    if (!drivingRiskRawForActions?.trim()) return undefined;
    const meta = getEnrichedMetadata(drivingRiskRawForActions);
    return meta.display_name || drivingRiskRawForActions;
  }, [drivingRiskRawForActions, getEnrichedMetadata]);

  /** Recommended actions: potential_actions and issue context from GET /issue/:id/ only. */
  const materialForRecommendedActions = useMemo(() => {
    if (!issueDetail?.issue_nbr) return null;

    const resolvedMaterialId =
      materialId ?? issueDetail.material?.id ?? navState.materialId ?? materialIdFromQuery;
    if (!resolvedMaterialId) return null;

    return issueToMaterialWithIssues(
      issueDetail,
      resolvedMaterialId,
      matNbr || issueDetail.material?.mat_nbr || "",
      riskRating,
      drivingRiskRawForActions,
      dollarsAtRisk
    );
  }, [
    issueDetail,
    materialId,
    matNbr,
    riskRating,
    drivingRiskRawForActions,
    dollarsAtRisk,
    materialIdFromQuery,
    navState.materialId,
  ]);

  const vendorIdForActions =
    issueMaterial?.vendor?.id ??
    vendorIdFromMaterial ??
    materialForRecommendedActions?.vendor?.id;
  const resolvedNotesIssue = mergedIssueRow;
  const issueBackendId = issueId ?? resolvedNotesIssue?.id;
  const lastNoteForNotes = resolvedNotesIssue?.last_note ?? navState.lastNote ?? null;
  const notesCountResolved = resolvedNotesIssue?.notes_count ?? navState.notesCount ?? 0;
  const hasActionsForNotes =
    issueBackendId != null && isIssueActionResolved(mergedIssueRow?.actions, navState.actionStatus === "Reviewed");

  const ndcForNotes = material?.ndc ?? issueMaterial?.ndc ?? navState.ndc ?? "";

  const notesTabLoading = !issueBackendId && issueDetailLoading;

  if (!isValidIssueId) {
    return (
      <DashboardLayout hideBanner>
        <p className="text-red-600 py-8">Invalid issue ID.</p>
        <button
          type="button"
          onClick={() => navigate(ROUTES.REACT)}
          className="text-brand-primary-main font-semibold hover:underline"
        >
          Back to React
        </button>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout hideBanner className="bg-white">
      <button
        type="button"
        onClick={() => navigate(ROUTES.REACT)}
        className="flex items-center gap-1 text-sm text-[#6E6E6E] hover:text-brand-primary-main my-6 transition-colors"
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
        </svg>
        Go back to React
      </button>

      <MaterialSummaryHeader
        name={material?.name ?? issueMaterial?.name ?? navState.productName ?? "Material"}
        ndc={material?.ndc ?? issueMaterial?.ndc}
        productFamily={material?.product_family}
        category={material?.category}
        marketShare={material?.market_share}
        buyerCommentNotes={material?.buyer_comment_notes}
        nextPoDelivery={details?.next_po_delivery ?? material?.next_po_delivery}
        vendor={materialVendor?.name ?? issueMaterial?.vendor?.name}
        vendorNbr={vendorNbr}
        riskScore={riskScore}
        riskAdjustedValue={riskAdjustedValue}
        drivingRiskLabel={drivingRiskLabel}
        isNewIssue={isNewIssue}
        actionResolved={actionResolved}
        isLoading={detailsLoading || issueDetailLoading}
      />

      <div className="mt-6">
        <MaterialDrillTabs />

        {activeTab === "risk-events" && (
          <div className="my-6 space-y-6">
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <DrivingEventPanel
                event={drivingEvent}
                isLoading={drivingEventLoading}
                isFetching={drivingEventFetching}
              />
              <DrivingRiskEventsTimeline riskData={enrichedRiskData} isLoading={riskLoading} />
            </div>
            <MaterialRiskScoreChart weeklyData={weeklyData} isLoading={weeklyLoading} />
          </div>
        )}

        {activeTab === "profile" && (
          <div className="my-6 grid grid-cols-1 xl:grid-cols-2 gap-6">
            <MaterialProfileCard
              material={details?.material}
              materialFormularies={
                Array.isArray(details?.material_formularies)
                  ? details?.material_formularies
                  : undefined
              }
              availablePlantsCount={details?.available_plants_count}
              riskAdjustedValue={riskAdjustedValue}
              isLoading={detailsLoading}
            />
            <VendorProfileCard
              vendor={
                typeof material?.vendor === "object" && material?.vendor
                  ? material.vendor
                  : null
              }
              isLoading={detailsLoading}
            />
          </div>
        )}

        {activeTab === "actions" && (
          <div className="my-6">
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <RecommendedActionsCard
                material={materialForRecommendedActions}
                vendorId={vendorIdForActions}
                isLoading={issueDetailLoading && !materialForRecommendedActions}
              />
              <ActionHistoryPanel
                actions={actionHistory}
                total={actionHistoryTotal}
                currentPage={actionHistoryPage}
                pageSize={ACTION_HISTORY_PAGE_SIZE}
                isLoading={actionHistoryLoading}
                isFetching={actionHistoryFetching}
                onPageChange={setActionHistoryPage}
              />
            </div>
          </div>
        )}

        {activeTab === "notes" && (
          <div className="my-6">
            {notesTabLoading ? (
              <div className="space-y-6 animate-pulse">
                <div className="h-8 w-32 rounded bg-gray-200" />
                <div className="h-4 w-64 rounded bg-gray-200" />
                <div className="h-32 rounded-xl border border-[#E5E5EA] bg-gray-100" />
                <div className="h-24 rounded-lg bg-gray-100" />
              </div>
            ) : issueBackendId ? (
              <IssueNotesCard
                view="page"
                issueBackendId={String(issueBackendId)}
                matNbr={matNbr}
                ndc={ndcForNotes}
                hasActions={Boolean(hasActionsForNotes)}
                lastNote={lastNoteForNotes}
                notesCount={notesCountResolved}
              />
            ) : null}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
