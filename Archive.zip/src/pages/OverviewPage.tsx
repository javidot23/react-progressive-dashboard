// import {CriticalAlert} from "@/components/organisms/CriticalAlert";
import { useState, useEffect } from "react";
import { isVendorPortal, isCustomerVendorPortal, isVariantFamily } from "@/tenant";
import { MainKPIs } from "@/components/organisms/MainKPIs";
import CurrentVsPriorSalesChart from "@/components/manage/overview/CurrentVsPriorSalesChart";
import { ServiceLevelCard } from "@/components/organisms/ServiceLevelCard";
import { OTIFPerformanceCard } from "@/components/organisms/OTIFPerformanceCard";
import { ValueAtRiskTrendCard } from "@/components/organisms/ValueAtRiskTrendCard";
import ProductOmitsTrendChart from "@/components/manage/overview/ProductOmitsTrendChart";
import { RiskListCard } from "@/components/organisms/RiskListCard";
import { InsightsAlertCard, type InsightAlert } from "@/components/organisms/InsightsAlertCard";
import GlobalFilters from "@/components/organisms/GlobalFilters";
import DashboardLayout from "@/components/templates/DashboardLayout";
import { useQueryClient } from "@tanstack/react-query";
import { serviceLevelQueryKeys } from "@/hooks/queries/useServiceLevelQueries";
import { mainKpiQueryKeys } from "@/hooks/queries/useMainKpiQueries";
import { useCriticalProductsQuery, criticalProductsQueryKeys } from "@/hooks/queries/useCriticalProductsQuery";
import { useTopRiskiestVendorsQuery, topRiskiestVendorsQueryKeys } from "@/hooks/queries/useTopRiskiestVendorsQuery";
import { useGlobalFiltersListener } from "@/hooks/useGlobalFiltersListener";
import { useRiskModelDescriptions } from "@/hooks";
import { RiskLevel } from "@/lib/types";
import cencoraInsightsIcon from "@/assets/icons/insights-icon.svg";
import { type DetailedSupplyChainEvent } from "@/lib/apiServices";
import { useTopRiskiestMaterialsEventsQuery, topRiskiestMaterialsEventsQueryKeys } from "@/hooks/queries/useTopRiskiestMaterialsEventsQuery";
import arrowRightIcon from "@/assets/icons/right-arrow-primary.svg";
import { useNavigate } from "react-router-dom";
import { Modal } from "@/components/atoms/Modal";
import { Button } from "@/components/atoms/Button";
const getInitials = (fullName: string): string =>
  fullName
    .split(" ")
    .filter(Boolean)
    .map(word => word[0]?.toUpperCase() ?? "")
    .join("");

const getRiskLevel = (rating: number): RiskLevel => {
  if (rating >= 0.9) return "Critical";
  if (rating >= 0.8) return "High";
  if (rating >= 0.6) return "Medium";
  return "Watch";
};

const getImpactLevel = (riskRating: number): "High Impact" | "Medium Impact" | "Low Impact" => {
  if (riskRating >= 0.8) return "High Impact";
  if (riskRating >= 0.5) return "Medium Impact";
  return "Low Impact";
};

const transformEventToAlert = (event: DetailedSupplyChainEvent | any): InsightAlert => {
  // Use type as title and metadata as description
  const title = event.type || "Supply Chain Event";
  const rawDescription = event.type_description || event.metadata || "No description available";
  const description = rawDescription.charAt(0).toUpperCase() + rawDescription.slice(1);

  // Get material info if available
  // Note: In the top-riskiest-materials-events endpoint, mat_nbr is a string (material number)
  // In the detailed event endpoint, mat_nbr is an object with full material details
  const material = typeof event.mat_nbr === "object" && event.mat_nbr !== null ? event.mat_nbr : null;
  const matNbrString = typeof event.mat_nbr === "string" ? event.mat_nbr : material?.mat_nbr || "";

  let impactLevel: "High Impact" | "Medium Impact" | "Low Impact" = "Medium Impact";
  let affectedMaterials: string[] = [];
  let eventDetails = undefined;

  if (material) {
    // Full material object available (from detailed endpoint)
    impactLevel = getImpactLevel(material.risk_rating || 0);
    const materialName = material.name || "Unknown Material";
    const materialNumber = material.mat_nbr || material.ndc || "";
    let materialDisplay = materialNumber ? `${materialName} • ${materialNumber}` : materialName;
    if (material.scrm_mat_grp) materialDisplay += ` • ${material.scrm_mat_grp}`;
    affectedMaterials = [materialDisplay];

    if (event.related_events) {
      event.related_events.forEach((relatedEvent: DetailedSupplyChainEvent) => {
        if (relatedEvent?.mat_nbr) {
          const relatedMaterial = relatedEvent.mat_nbr;
          const relatedName = relatedMaterial.name || "Unknown Material";
          const relatedNumber = relatedMaterial.mat_nbr || relatedMaterial.ndc || "";
          let relatedDisplay = relatedNumber ? `${relatedName} • ${relatedNumber}` : relatedName;
          if (relatedMaterial.scrm_mat_grp) relatedDisplay += ` • ${relatedMaterial.scrm_mat_grp}`;
          if (!affectedMaterials.includes(relatedDisplay)) {
            affectedMaterials.push(relatedDisplay);
          }
        }
      });
    }

    // Determine epicenter from coordinates or material info
    let epicenter = "Global Supply Chain";
    if (event.latitude !== null && event.longitude !== null) {
      epicenter = `${event.latitude.toFixed(2)}°N, ${event.longitude.toFixed(2)}°E`;
    } else if (material.buyer_name) {
      epicenter = material.buyer_name;
    }

    // Use risk rating for magnitude if available
    const magnitude = material.risk_rating ? Math.round(material.risk_rating * 100) : undefined;

    eventDetails = {
      magnitude,
      depth: material.product_family || material.material_group || "Unknown",
      epicenter,
      affectedRadius: material.hic3_therapy_class || "Multiple regions",
    };
  } else if (matNbrString) {
    // Only material number string available (from top-riskiest-materials-events endpoint)
    let fallbackDisplay = `Material • ${matNbrString}`;
    if (event.scrm_mat_grp) fallbackDisplay += ` • ${event.scrm_mat_grp}`;
    affectedMaterials = [fallbackDisplay];

    // Determine epicenter from coordinates
    let epicenter = "Global Supply Chain";
    if (event.latitude !== null && event.longitude !== null) {
      const lat = event.latitude >= 0 ? `${event.latitude.toFixed(4)}° N` : `${Math.abs(event.latitude).toFixed(4)}° S`;
      const lng = event.longitude >= 0 ? `${event.longitude.toFixed(4)}° E` : `${Math.abs(event.longitude).toFixed(4)}° W`;
      epicenter = `${lat}, ${lng}`;
    }

    eventDetails = {
      epicenter,
      affectedRadius: "Multiple regions",
    };
  }

  // Calculate likelihood based on risk rating
  let likelihood: "Highly Likely" | "Likely" | "Possible" = "Possible";
  if (material) {
    const riskRating = material.risk_rating || 0;
    if (riskRating >= 0.7) {
      likelihood = "Highly Likely";
    } else if (riskRating >= 0.4) {
      likelihood = "Likely";
    }
  }

  // Format event location
  let eventLocation = undefined;
  if (event.latitude !== null && event.longitude !== null) {
    const lat = event.latitude >= 0 ? `${event.latitude.toFixed(4)}° N` : `${Math.abs(event.latitude).toFixed(4)}° S`;
    const lng = event.longitude >= 0 ? `${event.longitude.toFixed(4)}° E` : `${Math.abs(event.longitude).toFixed(4)}° W`;
    eventLocation = {
      coordinates: `${lat}, ${lng}`,
    };
  }

  return {
    id: event.id?.toString() || Math.random().toString(),
    title,
    description,
    impactLevel,
    likelihood,
    eventDetails,
    eventLocation,
    affectedMaterials: affectedMaterials.slice(0, 5),
    recommendation: event.metadata || `Review ${event.type}`,
    knowledgeGraphLink: "#",
    onViewKnowledgeGraph: () => {
      // console.log("Navigate to knowledge graph for event", event.event_id);
    },
  };
};

export default function OverviewPage() {
  const navigate = useNavigate();
  const isStageEnvironment =
    typeof window !== "undefined" && window.location.hostname === "scrm-stage.cencora.com";
  const [isEnvironmentModalOpen, setIsEnvironmentModalOpen] = useState(isStageEnvironment);
  const { getEnrichedMetadata } = useRiskModelDescriptions();
  const {
    topRiskiestVendors,
    totalCount: topRiskiestVendorsTotalCount,
    isLoading: VendorsLoading,
    error: vendorsError,
    dataUpdatedAt: vendorsDataUpdatedAt,
    refetch: refetchVendors,
  } = useTopRiskiestVendorsQuery(3);
  const vendorsLastFetched = vendorsDataUpdatedAt || null;
  const {
    criticalProducts,
    totalCount: criticalProductsTotalCount,
    isLoading: productsLoading,
    error: productsError,
    dataUpdatedAt: productsDataUpdatedAt,
    refetch: refetchCriticalProducts,
  } = useCriticalProductsQuery(3);
  const productsLastFetched = productsDataUpdatedAt || null;
  const queryClient = useQueryClient();

  // Listen to global filter changes and refetch data
  useGlobalFiltersListener(() => {
    void queryClient.invalidateQueries({ queryKey: serviceLevelQueryKeys.all });
    void queryClient.invalidateQueries({ queryKey: criticalProductsQueryKeys.all });
    void queryClient.invalidateQueries({ queryKey: topRiskiestVendorsQueryKeys.all });
    void queryClient.invalidateQueries({ queryKey: topRiskiestMaterialsEventsQueryKeys.all });
    void queryClient.invalidateQueries({ queryKey: mainKpiQueryKeys.all });
    void Promise.all([refetchVendors(), refetchCriticalProducts()]);
  });

  const transformedVendors = (topRiskiestVendors || []).map(manufacturer => ({
    id: manufacturer.id,
    name: manufacturer.name,
    description: getEnrichedMetadata(manufacturer.drivingRisk).display_name || manufacturer.drivingRisk,
    initials: getInitials(manufacturer.name),
    risk: getRiskLevel(manufacturer.riskRating),
    riskRating: manufacturer.riskRating,
    vendorNbr: manufacturer.vendorNbr,
    dollarsAtRisk: manufacturer.totalDollarsAtRisk ?? manufacturer.riskAdjustedValue ?? 0,
    riskAdjustedValue: manufacturer.riskAdjustedValue ?? undefined,
  }));

  // High-risk materials: display uses mat_nbr (matNbr); material id is not shown in UI
  const transformedProducts = (criticalProducts || []).map(product => ({
    id: product.id,
    name: product.name,
    description: getEnrichedMetadata(product.drivingRisk).display_name || product.drivingRisk,
    initials: getInitials(product.name),
    risk: getRiskLevel(product.riskRating),
    riskRating: product.riskRating,
    ndc: product.eaNumber || undefined,
    matNbr: product.matNbr,
    materialGroup: product.materialGroup || "N/A",
    productFamily: product.productFamily || undefined,
    dollarsAtRisk: product.dollarsAtRisk,
    vendorName: product.vendorName,
  }));

  const [insightAlerts, setInsightAlerts] = useState<InsightAlert[]>([]);
  const topRiskiestMaterialsEventsQuery = useTopRiskiestMaterialsEventsQuery();
  const insightAlertsLoading = topRiskiestMaterialsEventsQuery.isPending;

  const handleGoToProduction = () => {
    sessionStorage.clear();
    window.location.href = "https://scrm.cencora.com";
  };

  useEffect(() => {
    if (topRiskiestMaterialsEventsQuery.isError) {
      setInsightAlerts([]);
      return;
    }
    if (!topRiskiestMaterialsEventsQuery.data) {
      return;
    }
    const listEvents = topRiskiestMaterialsEventsQuery.data.slice(0, 4);
    setInsightAlerts(listEvents.map((event: any) => transformEventToAlert(event)));
  }, [topRiskiestMaterialsEventsQuery.data, topRiskiestMaterialsEventsQuery.isError]);

  return (
    <DashboardLayout
      pageSubtitle="Here’s what’s happening with your supply chain today"
      bannerRightContent={<GlobalFilters variant="banner" />}
    >
      <Modal isOpen={isEnvironmentModalOpen} onClose={() => setIsEnvironmentModalOpen(false)} title="Information">
        <div className="space-y-4">
          <p className="text-sm text-ui-text-primary whitespace-pre-line">
            {`You are currently in the Stage environment.

This is a testing environment only, data may be unstable or reset at any time. To access live data and functionality, please switch to the Production environment.`}
          </p>
          <div className="flex justify-end border-t border-gray-200 pt-4">
            <Button onClick={handleGoToProduction}>Go to Production</Button>
          </div>
        </div>
      </Modal>
      {isVariantFamily() ? (
        <MainKPIs />
      ) : (
        <div className="bg-white px-6 pb-4 pt-6 rounded-lg border border-[#E2E8F0] z-30">
          <div className="mb-2 lg:mb-4">
            <div className="flex flex-row items-center justify-between">
              <div className="flex flex-row items-center space-x-2">
                <img src={cencoraInsightsIcon} alt="Cencora Insights" />
                <div className="flex flex-col items-start">
                  <div className="text-md font-bold text-ui-text-primary ">Cencora Insights</div>
                  <p className="text-sm text-ui-text-secondary">
                    Stay ahead of market changes with automated monitoring of demand patterns, material costs, and supply chain
                    risks. Get actionable insights when it matters most.
                  </p>
                </div>
              </div>
              <button onClick={() => navigate("/disruptions-map")} className="flex flex-row items-center space-x-1">
                <div className="text-sm font-bold text-brand-primary-main">View Events In Map</div>
                <img src={arrowRightIcon} alt="Arrow Right" className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
            {insightAlertsLoading ? (
              Array.from({ length: 4 }).map((_, index) => (
                <div
                  key={`skeleton-${index}`}
                  className="bg-[#EEEDFE52] border border-[#E2E8F0] rounded-lg p-4 flex flex-col h-[164px]"
                >
                  <div className="h-5 w-3/4 bg-gray-200 rounded animate-pulse mb-2"></div>
                  <div className="space-y-2 flex-1 mb-4">
                    <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
                    <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
                    <div className="h-4 w-2/3 bg-gray-200 rounded animate-pulse"></div>
                  </div>
                  <div className="h-8 w-24 bg-gray-200 rounded animate-pulse mt-auto"></div>
                </div>
              ))
            ) : insightAlerts.length === 0 ? (
              <div className="col-span-full text-center py-4 text-ui-text-secondary">No insights available at this time.</div>
            ) : (
              insightAlerts.map(alert => <InsightsAlertCard key={alert.id} alert={alert} />)
            )}
          </div>
        </div>
      )}

      {/* Rest of the dashboard content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
        <OTIFPerformanceCard />
        <ServiceLevelCard />
        <ValueAtRiskTrendCard />
        <ProductOmitsTrendChart />
      </div>
      {isCustomerVendorPortal() ? (
        <div className="grid grid-cols-1 gap-4">
          <CurrentVsPriorSalesChart />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {isVendorPortal() ? (
            <CurrentVsPriorSalesChart />
          ) : (
            <RiskListCard
              title="High-Risk Suppliers"
              description="Lists high-risk suppliers based on risk score."
              items={transformedVendors}
              loading={VendorsLoading}
              error={vendorsError}
              lastFetched={vendorsLastFetched}
              totalCount={topRiskiestVendorsTotalCount}
            />
          )}
          <RiskListCard
            title="High-Risk Materials"
            description="List top 3 high-risk materials based on risk adjusted value."
            items={transformedProducts}
            loading={productsLoading}
            error={productsError}
            lastFetched={productsLastFetched}
            totalCount={criticalProductsTotalCount}
          />
        </div>
      )}
      {/* <CencoraAISection /> */}
    </DashboardLayout>
  );
}
