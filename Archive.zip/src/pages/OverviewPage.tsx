// import {CriticalAlert} from "@/components/organisms/CriticalAlert";
import { useState } from "react";
import { ServiceLevelCard } from "@/components/organisms/ServiceLevelCard";
import { OTIFPerformanceCard } from "@/components/organisms/OTIFPerformanceCard";
import { ValueAtRiskTrendCard } from "@/components/organisms/ValueAtRiskTrendCard";
import ProductOmitsTrendChart from "@/components/manage/overview/ProductOmitsTrendChart";
import CurrentVsPriorSalesChart from "@/components/manage/overview/CurrentVsPriorSalesChart";
import { RiskListCard } from "@/components/organisms/RiskListCard";
import { MainKPIs } from "@/components/organisms";
import GlobalFilters from "@/components/organisms/GlobalFilters";
import DashboardLayout from "@/components/templates/DashboardLayout";
import { useQueryClient } from "@tanstack/react-query";
import { serviceLevelQueryKeys } from "@/hooks/queries/useServiceLevelQueries";
import { mainKpiQueryKeys } from "@/hooks/queries/useMainKpiQueries";
import { useCriticalProductsQuery, criticalProductsQueryKeys } from "@/hooks/queries/useCriticalProductsQuery";
import { useTopRiskiestVendorsQuery, topRiskiestVendorsQueryKeys } from "@/hooks/queries/useTopRiskiestVendorsQuery";
import { useGlobalFiltersListener } from "@/hooks/useGlobalFiltersListener";
import { useRiskModelDescriptions } from "@/hooks";
import { RiskLevel } from "@/lib/types";
import { Modal } from "@/components/atoms/Modal";
import { Button } from "@/components/atoms/Button";
import { selectTenantPortalFlags, useTenantContextQuery } from "@/tenant";
import { getOverviewBottomSlots } from "@/pages/overviewVisibility";

const getInitials = (fullName: string): string =>
  fullName
    .split(" ")
    .filter(Boolean)
    .map(word => word[0]?.toUpperCase() ?? "")
    .join("");

const getRiskLevel = (rating: number): RiskLevel => {
  if (rating >= 0.9) return "Critical";
  if (rating >= 0.8) return "High";
  if (rating >= 0.6) return "Medium";
  return "Watch";
};

export function OverviewPageContent() {
  const isStageEnvironment = typeof window !== "undefined" && window.location.hostname === "scrm-stage.cencora.com";
  const [isEnvironmentModalOpen, setIsEnvironmentModalOpen] = useState(isStageEnvironment);
  const { getEnrichedMetadata } = useRiskModelDescriptions();
  const { data: flags } = useTenantContextQuery(selectTenantPortalFlags);
  const bottom = getOverviewBottomSlots(flags?.tenantType);
  const salesChartSpansRow = Boolean(bottom && !bottom.highRiskSuppliers && !bottom.highRiskMaterials);

  const {
    topRiskiestVendors,
    totalCount: topRiskiestVendorsTotalCount,
    isLoading: vendorsLoading,
    error: vendorsError,
    dataUpdatedAt: vendorsDataUpdatedAt,
  } = useTopRiskiestVendorsQuery(3, { enabled: !!bottom?.highRiskSuppliers });

  const {
    criticalProducts,
    totalCount: criticalProductsTotalCount,
    isLoading: productsLoading,
    error: productsError,
    dataUpdatedAt: productsDataUpdatedAt,
  } = useCriticalProductsQuery(3, { enabled: !!bottom?.highRiskMaterials });

  const queryClient = useQueryClient();

  useGlobalFiltersListener(() => {
    void queryClient.invalidateQueries({ queryKey: serviceLevelQueryKeys.all });
    void queryClient.invalidateQueries({ queryKey: mainKpiQueryKeys.all });
    void queryClient.invalidateQueries({ queryKey: criticalProductsQueryKeys.all });
    void queryClient.invalidateQueries({ queryKey: topRiskiestVendorsQueryKeys.all });
  });

  const transformedVendors = topRiskiestVendors.map(manufacturer => ({
    id: manufacturer.id,
    name: manufacturer.name,
    description: getEnrichedMetadata(manufacturer.drivingRisk).display_name || manufacturer.drivingRisk,
    initials: getInitials(manufacturer.name),
    risk: getRiskLevel(manufacturer.riskRating),
    riskRating: manufacturer.riskRating,
    vendorNbr: manufacturer.vendorNbr,
    dollarsAtRisk: manufacturer.totalDollarsAtRisk ?? manufacturer.riskAdjustedValue ?? 0,
    riskAdjustedValue: manufacturer.riskAdjustedValue ?? undefined,
  }));

  const transformedProducts = criticalProducts.map(product => ({
    id: product.id,
    name: product.name,
    description: getEnrichedMetadata(product.drivingRisk).display_name || product.drivingRisk,
    initials: getInitials(product.name),
    risk: getRiskLevel(product.riskRating),
    riskRating: product.riskRating,
    ndc: product.eaNumber || undefined,
    matNbr: product.matNbr,
    materialGroup: product.materialGroup || "N/A",
    productFamily: product.productFamily || undefined,
    dollarsAtRisk: product.dollarsAtRisk,
    vendorName: product.vendorName,
  }));

  const handleGoToProduction = () => {
    sessionStorage.clear();
    window.location.href = "https://scrm.cencora.com";
  };

  return (
    <>
      <Modal isOpen={isEnvironmentModalOpen} onClose={() => setIsEnvironmentModalOpen(false)} title="Information">
        <div className="space-y-4">
          <p className="text-sm text-ui-text-primary whitespace-pre-line">
            {`You are currently in the Stage environment.

This is a testing environment only, data may be unstable or reset at any time. To access live data and functionality, please switch to the Production environment.`}
          </p>
          <div className="flex justify-end border-t border-gray-200 pt-4">
            <Button onClick={handleGoToProduction}>Go to Production</Button>
          </div>
        </div>
      </Modal>

      <MainKPIs />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
        <OTIFPerformanceCard />
        <ServiceLevelCard />
        <ValueAtRiskTrendCard />
        <ProductOmitsTrendChart />
      </div>

      {bottom && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {bottom.highRiskSuppliers && (
            <RiskListCard
              title="High-Risk Suppliers"
              description="Lists high-risk suppliers based on risk score."
              items={transformedVendors}
              loading={vendorsLoading}
              error={vendorsError}
              lastFetched={vendorsDataUpdatedAt || null}
              totalCount={topRiskiestVendorsTotalCount}
            />
          )}
          {bottom.currentVsPrior && (
            <div className={salesChartSpansRow ? "lg:col-span-2" : undefined}>
              <CurrentVsPriorSalesChart />
            </div>
          )}
          {bottom.highRiskMaterials && (
            <RiskListCard
              title="High-Risk Materials"
              description="List top 3 high-risk materials based on risk adjusted value."
              items={transformedProducts}
              loading={productsLoading}
              error={productsError}
              lastFetched={productsDataUpdatedAt || null}
              totalCount={criticalProductsTotalCount}
            />
          )}
        </div>
      )}
    </>
  );
}

export default function OverviewPage() {
  return (
    <DashboardLayout
      pageSubtitle="Here’s what’s happening with your supply chain today"
      bannerRightContent={<GlobalFilters variant="banner" />}
    >
      <OverviewPageContent />
    </DashboardLayout>
  );
}
