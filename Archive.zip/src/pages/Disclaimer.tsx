import {Button} from "@/components/atoms/Button";
import {Link} from "react-router-dom";
import CopyrightIcon from "@/assets/icons/c-icon.svg";

export default function Disclaimer() {
  return (
    <div className="min-h-screen bg-[url('/src/public/images/background.jpg')] bg-no-repeat bg-cover bg-center flex items-center justify-center relative px-4">
      <div className="bg-white rounded-md shadow-2xl max-w-lg w-full relative z-10">
        <div className="flex items-center justify-between p-4">
          <h2 className="text-xl font-semibold text-[#1E1E1E]">
            Terms of Service
          </h2>
          <button className="text-neutral-500 hover:text-[#6b7280] transition-colors">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="size-6"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M6 18 18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        <hr className="text-[#E5E7EB]" />

        <div className="p-4 space-y-4">
          <p className="text-[#3B3B3B] text-sm leading-relaxed">
            This platform and the underlying application contain intellectual
            property and confidential information owned by or licensed to
            Cencora Drug Corporation and its affiliates. Use of this platform
            information is subject to the terms and restrictions between you and
            Cencora under one or more applicable agreements.
          </p>
          <p className="text-[#3B3B3B] text-sm leading-relaxed">
            The information may not be disclosed to third parties, except where
            expressly authorized in those agreements. Analytics displayed are
            derived from available public or commercial third-party sources, and
            Cencora makes no warranty or representation regarding the accuracy,
            timeliness, or completeness of the source data for, or the
            calculation of, this information.
          </p>
        </div>

        <hr className="text-[#E5E7EB]" />

        <div className="py-3 px-4 rounded-md flex flex-row items-row justify-end bg-background-secondary">
          <Link to="/overview">
            <Button className="bg-[#461E96] text-white px-5 h-[32px] rounded-[4px] text-sm font-bold cursor-pointer hover:bg-brand-primary-dark">
              I accept
            </Button>
          </Link>
        </div>
      </div>

      <div className="absolute bottom-4 left-7">
        <p className="text-[#838383] text-sm flex flex-row items-center gap-1">
          <img src={CopyrightIcon} alt="copyright" width={15} />
          All rights reserved to Cencora, Inc.
        </p>
      </div>
    </div>
  );
}
