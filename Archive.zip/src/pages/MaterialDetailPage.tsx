import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useLocation, useSearchParams } from "react-router-dom";
import DashboardLayout from "@/components/templates/DashboardLayout";
import { ROUTES } from "@/constants/routes";
import {
  useMaterialSubstituteDetailsQuery,
  useMaterialRiskQuery,
  useMaterialRiskWeeklyAveragesQuery,
  useMaterialActionHistoryQuery,
  useMaterialSupplyChainEventsQuery,
} from "@/hooks/queries";
import { useRiskModelDescriptions } from "@/hooks";
import { MaterialSummaryHeader } from "@/components/material-drill-through/MaterialSummaryHeader";
import {
  MaterialDrillTabs,
  parseMaterialDrillTab,
  MATERIAL_DRILL_TAB_QUERY_KEY,
  type MaterialDrillTab,
} from "@/components/material-drill-through/MaterialDrillTabs";
import { DrivingRiskEventsTimeline } from "@/components/material-drill-through/DrivingRiskEventsTimeline";
import { MaterialRiskScoreChart } from "@/components/material-drill-through/MaterialRiskScoreChart";
import { MaterialEventsPanel } from "@/components/material-drill-through/MaterialEventsPanel";
import { MaterialProfileCard } from "@/components/material-drill-through/MaterialProfileCard";
import { VendorProfileCard } from "@/components/material-drill-through/VendorProfileCard";
import { ActionHistoryPanel } from "@/components/material-drill-through/ActionHistoryPanel";
import type { MaterialDetailLocationState } from "@/lib/issueDrillThroughUtils";

const ACTION_HISTORY_PAGE_SIZE = 10;
const MAT_NBR_QUERY_KEY = "matNbr";

// Inspect-only material detail: no Notes tab, no take-action (both are issue-scoped).
const VISIBLE_TABS: { id: MaterialDrillTab; label: string }[] = [
  { id: "risk-events", label: "Driving Risk & Contributors" },
  { id: "profile", label: "Material & Supplier Profile" },
  { id: "actions", label: "Action History" },
];

export default function MaterialDetailPage() {
  const navigate = useNavigate();
  const { materialId: materialIdParam } = useParams<{ materialId: string }>();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const navState = (location.state as MaterialDetailLocationState | null) ?? {};

  const materialId = Number(materialIdParam);
  const isValidMaterialId = Number.isFinite(materialId) && materialId > 0;

  const parsedTab = parseMaterialDrillTab(searchParams.get(MATERIAL_DRILL_TAB_QUERY_KEY));
  const activeTab: MaterialDrillTab = VISIBLE_TABS.some(t => t.id === parsedTab) ? parsedTab : "risk-events";

  const [actionHistoryPage, setActionHistoryPage] = useState(1);

  const { details, isLoading: detailsLoading } = useMaterialSubstituteDetailsQuery({
    materialId: isValidMaterialId ? materialId : undefined,
    enabled: isValidMaterialId,
  });

  const material = details?.material;
  const matNbr = navState.matNbr ?? searchParams.get(MAT_NBR_QUERY_KEY) ?? material?.mat_nbr ?? "";

  useEffect(() => {
    setActionHistoryPage(1);
  }, [matNbr]);

  const { enrichRiskData } = useRiskModelDescriptions();
  const { riskData: rawRiskData, isLoading: riskLoading } = useMaterialRiskQuery({
    materialId: isValidMaterialId ? materialId : undefined,
    enabled: isValidMaterialId,
  });
  const enrichedRiskData = useMemo(() => enrichRiskData(rawRiskData), [enrichRiskData, rawRiskData]);

  const { weeklyData, isLoading: weeklyLoading } = useMaterialRiskWeeklyAveragesQuery({
    matNbr,
    enabled: !!matNbr,
  });

  const {
    events: materialEvents,
    isLoading: eventsLoading,
    isFetching: eventsFetching,
  } = useMaterialSupplyChainEventsQuery({
    matNbr,
    enabled: !!matNbr && activeTab === "risk-events",
  });

  const {
    actions: actionHistory,
    total: actionHistoryTotal,
    isLoading: actionHistoryLoading,
    isFetching: actionHistoryFetching,
  } = useMaterialActionHistoryQuery({
    matNbr,
    page: actionHistoryPage,
    pageSize: ACTION_HISTORY_PAGE_SIZE,
    enabled: !!matNbr && activeTab === "actions",
  });

  const materialVendor = typeof material?.vendor === "object" && material?.vendor ? material.vendor : null;

  const riskRating = material?.risk_rating ?? (navState.riskLevel != null ? navState.riskLevel / 100 : 0);
  const riskScore = Math.round(riskRating * (riskRating <= 1 ? 100 : 1));
  const dollarsAtRisk = material?.dollars_at_risk ?? navState.dollarsAtRisk ?? 0;
  const riskAdjustedValue = Math.round((riskScore / 100) * dollarsAtRisk);

  // Back navigation: return to the originating issue drill-through when present.
  const cameFromIssue = navState.from === "issue" && navState.originIssueId != null;
  const backTarget = cameFromIssue ? `${ROUTES.REACT_ISSUE}/${navState.originIssueId}` : ROUTES.REACT;
  const backLabel = cameFromIssue ? "Back to issue" : "Back to React";

  if (!isValidMaterialId) {
    return (
      <DashboardLayout hideBanner>
        <p className="text-red-600 py-8">Invalid material ID.</p>
        <button
          type="button"
          onClick={() => navigate(ROUTES.REACT)}
          className="text-brand-primary-main font-semibold hover:underline"
        >
          Back to React
        </button>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout hideBanner className="bg-white">
      <button
        type="button"
        onClick={() => navigate(backTarget)}
        className="flex items-center gap-1 text-sm text-[#6E6E6E] hover:text-brand-primary-main my-6 transition-colors"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2}
          stroke="currentColor"
          className="w-4 h-4"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
        </svg>
        {backLabel}
      </button>

      <MaterialSummaryHeader
        name={material?.name ?? navState.name ?? "Material"}
        ndc={material?.ndc ?? navState.ndc}
        productFamily={material?.product_family}
        category={material?.category}
        marketShare={material?.market_share}
        buyerCommentNotes={material?.buyer_comment_notes}
        nextPoDelivery={details?.next_po_delivery ?? material?.next_po_delivery}
        vendor={materialVendor?.name ?? navState.vendorName}
        vendorNbr={materialVendor?.vendor_nbr ?? navState.vendorNbr}
        riskScore={riskScore}
        riskAdjustedValue={riskAdjustedValue}
        hideIssueMeta
        isLoading={detailsLoading}
      />

      <div className="mt-6">
        <MaterialDrillTabs tabs={VISIBLE_TABS} />

        {activeTab === "risk-events" && (
          <div className="my-6 space-y-6">
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <MaterialEventsPanel events={materialEvents} isLoading={eventsLoading} isFetching={eventsFetching} />
              <DrivingRiskEventsTimeline riskData={enrichedRiskData} isLoading={riskLoading} />
            </div>
            <MaterialRiskScoreChart weeklyData={weeklyData} isLoading={weeklyLoading} />
          </div>
        )}

        {activeTab === "profile" && (
          <div className="my-6 grid grid-cols-1 xl:grid-cols-2 gap-6">
            <MaterialProfileCard
              material={details?.material}
              materialFormularies={Array.isArray(details?.material_formularies) ? details?.material_formularies : undefined}
              availablePlantsCount={details?.available_plants_count}
              riskAdjustedValue={riskAdjustedValue}
              isLoading={detailsLoading}
            />
            <VendorProfileCard vendor={materialVendor} isLoading={detailsLoading} />
          </div>
        )}

        {activeTab === "actions" && (
          <div className="my-6">
            <ActionHistoryPanel
              actions={actionHistory}
              total={actionHistoryTotal}
              currentPage={actionHistoryPage}
              pageSize={ACTION_HISTORY_PAGE_SIZE}
              isLoading={actionHistoryLoading}
              isFetching={actionHistoryFetching}
              onPageChange={setActionHistoryPage}
            />
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
