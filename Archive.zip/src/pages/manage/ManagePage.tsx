import { useLayoutEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { PageFiltersProvider } from "@/contexts/PageFiltersContext";
import { ManageLayout } from "./layout/ManageLayout";
import { MANAGE_SECTION_MAP, VALID_MANAGE_SECTIONS, NavigationItemName } from "@/constants/manageRoutes";

const capitalize = (str: string): string => {
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

const getActiveItemFromPath = (pathname: string): NavigationItemName => {
  const parts = pathname.split("/").filter(Boolean);

  if (parts.length >= 1 && parts[0] === "manage") {
    if (parts.length === 1) {
      return "Overview";
    }

    if (parts.length >= 2) {
      const section = parts[1];

      if (!VALID_MANAGE_SECTIONS.has(section)) {
        console.warn(`Invalid manage section: ${section}`);
        return "Overview";
      }

      const mappedName = MANAGE_SECTION_MAP[section];
      if (mappedName) {
        return mappedName as NavigationItemName;
      }

      const capitalized = capitalize(section);
      return capitalized as NavigationItemName;
    }
  }

  return "Overview";
};

const Manage = () => {
  const location = useLocation();

  const [activeItem, setActiveItem] = useState<NavigationItemName>(() => getActiveItemFromPath(location.pathname));

  useLayoutEffect(() => {
    const newActiveItem = getActiveItemFromPath(location.pathname);

    if (newActiveItem !== activeItem) {
      setActiveItem(newActiveItem);
    }
  }, [location.pathname, activeItem]);

  return (
    <PageFiltersProvider>
      <ManageLayout activeItem={activeItem} setActiveItem={setActiveItem}>
        <Outlet />
      </ManageLayout>
    </PageFiltersProvider>
  );
};

export default Manage;
