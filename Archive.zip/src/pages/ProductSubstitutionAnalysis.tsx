import React, { useState, useEffect, useRef, useCallback } from "react";
import { MapContainer, useMap } from "react-leaflet";
import L from "leaflet";
import { demandForecastService, materialFormularyService } from "@/lib/apiServices";
import { createPortal } from "react-dom";
import { useLocation, useNavigate } from "react-router-dom";
import DashboardLayout from "@/components/templates/DashboardLayout";
import { Button } from "@/components/atoms/Button";
import { useMaterialSubstitutesInfiniteQuery } from "@/hooks/queries/useMaterialSubstitutesInfiniteQuery";
import { useMaterialSubstituteDetailsQuery } from "@/hooks/queries/useMaterialSubstituteDetailsQuery";
import type { MaterialFormulary } from "@/stores/slices/types";
import usStatesData from "@/public/data/us-states.json";

import LazyLoader from "@/components/molecules/LazyLoader";
import "leaflet/dist/leaflet.css";
import { KeepInMindModal } from "@/components/molecules/KeepInMindModal";
import { DecisionRationaleModal } from "@/components/molecules/DecisionRationaleModal";
import { createAction, submitDecisionRationale } from "@/services/actionService";
import { incrementCompletedActionsCount, shouldShowDecisionRationaleModal } from "@/lib/actionTracking";
import { getErrorMessage } from "@/lib/getErrorMessage";
import { toast } from "@/lib/toast";
import { isVariantFamily } from "@/tenant";

const DiscountDollarDashIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="11.25" />
      <path d="M9.75 14.25A2.25 2.25 0 1 0 12 12a2.25 2.25 0 1 1 2.25-2.25" />
      <path d="M12 6 12 7.5" />
      <path d="M12 16.5 12 18" />
    </g>
  </svg>
);

const AnalyticsGraphBarIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6.88 5.12 2.87 9.13" />
      <path d="M14.31 6.32 9.64 5.08" />
      <path d="M20.39 2.89 16.81 5.69" />
      <circle cx="8.25" cy="4.5" r="1.5" />
      <circle cx="21.75" cy="2.25" r="1.5" />
      <circle cx="15.75" cy="6.75" r="1.5" />
      <circle cx="2.25" cy="10.5" r="1.5" />
      <path d="M.75 23.25 23.25 23.25" />
      <path d="M6 17.75H3a.76.76 0 0 0 -.75.75v4.75h4.5V18.5A.75.75 0 0 0 6 17.75Z" />
      <path d="M13.5 10.75h-3a.76.76 0 0 0 -.75.75V23.25h4.5V11.5A.75.75 0 0 0 13.5 10.75Z" />
      <path d="M21 14.75H18a.76.76 0 0 0 -.75.75v7.75h4.5V15.5A.75.75 0 0 0 21 14.75Z" />
    </g>
  </svg>
);

const AppWindowGraphIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M.76 15.75H6.59a1.51 1.51 0 0 0 1.34-.83L9.7 11.37a.76.76 0 0 1 1.39.1L12.94 17a.75.75 0 0 0 1.38.09l1.78-3.55a1.49 1.49 0 0 1 1.34-.83h5.81" />
      <rect height="20" rx="1.5" width="22.5" x=".75" y="2" />
      <path d="M.75 6.5 23.25 6.5" />
    </g>
  </svg>
);

const ShipmentUploadIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 .75.75 5.25 12 9.75 23.25 5.25 12 .75Z" />
      <path d="M.75 5.25.75 18.75 12 23.25 12 9.75.75 5.25Z" />
      <path d="M23.25 5.25 23.25 18.75 12 23.25 12 9.75 23.25 5.25Z" />
      <path d="M18.187 7.275 6.937 2.775" />
      <path d="M20.625 16.5 18.75 17.25" />
    </g>
  </svg>
);

const CalendarIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <rect height="19.5" rx="1.5" width="22.5" x=".752" y="3.75" />
      <path d="M.752 9.75 23.252 9.75" />
      <path d="M6.752 6 6.752.75" />
      <path d="M17.252 6 17.252.75" />
    </g>
  </svg>
);

const TaskListCheckIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5.25 10.511 10.5 10.511" />
      <path d="M5.25 14.261 8.25 14.261" />
      <path d="M5.25 18.011 8.25 18.011" />
      <path d="M9.75 23.261H2.25a1.5 1.5 0 0 1 -1.5-1.5V6.011a1.5 1.5 0 0 1 1.5-1.5H6a3.75 3.75 0 0 1 7.5 0h3.75a1.5 1.5 0 0 1 1.5 1.5v2.25" />
      <path d="M9.75 3.761a.375.375 0 1 1 -.375.375.375.375 0 0 1 .375-.375" />
      <path d="M11.25 17.261A6 6 0 1 0 23.25 17.261 6 6 0 1 0 11.25 17.261Z" />
      <path d="M19.924 15.516 17.019 19.39a.751.751 0 0 1 -1.131.08l-1.5-1.5" />
    </g>
  </svg>
);

const EarthSearchIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 23.25A11.25 11.25 0 1 1 23.25 12" />
      <path d="M4.99 20.8 6 15.75 7.48 15.75" />
      <path d="M8.25 12.74l-.47-1.85A1.49 1.49 0 0 0 6.33 9.75H1" />
      <path d="M21 5.25H16.92a1.49 1.49 0 0 0 -1.45 1.14L15.2 7.45" />
      <circle cx="15.76" cy="15.75" r="5.25" />
      <path d="M23.25 23.25 19.48 19.46" />
    </g>
  </svg>
);

const QuestionCircleIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none">
      <path d="M9 9a3 3 0 1 1 4 2.829 1.5 1.5 0 0 0 -1 1.415V14.25" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M12 17.25a.375.375 0 1 0 .375.375A.375.375 0 0 0 12 17.25h0" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M.75 12A11.25 11.25 0 1 0 23.25 12 11.25 11.25 0 1 0 .75 12Z" />
    </g>
  </svg>
);

const AlertTriangleIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z" />
      <path d="M12 9v3.75" />
      <path d="M12 17.25h.01" />
    </g>
  </svg>
);

const PillIcon = ({ className, style }: { className?: string; style?: React.CSSProperties }) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5" width="1em" height="1em" className={className} style={style}>
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M10.5 10.5 13.5 13.5" />
      <path d="M13.5 10.5 10.5 13.5" />
      <path d="M21 12a9 9 0 1 1 -18 0 9 9 0 0 1 18 0Z" />
    </g>
  </svg>
);

const usdFullCurrencyFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

function formatUsdFull(amount: number): string {
  if (!Number.isFinite(amount)) return "$-";
  return usdFullCurrencyFormatter.format(amount);
}

/** U.S.-style grouping for thousands; preserves fractional digits (no grouping in the % value). */
const usNumberFormatter = new Intl.NumberFormat("en-US", {
  maximumFractionDigits: 20,
});

function formatUsNumber(value: number): string {
  if (!Number.isFinite(value)) return "-";
  return usNumberFormatter.format(value);
}

function formatPercentValue(value: number, fractionDigits = 0): string {
  if (!Number.isFinite(value)) return "-";
  return `${value.toFixed(fractionDigits)}%`;
}

interface SubstituteProduct {
  id: string;
  title: string;
  name: string;
  vendor: string;
  vendorNbr: string;
  riskExposure: string;
  marketShare: string;
  inventoryDays: string;
  costUnit: string;
  availability: string;
  contract: string;
  tags: { label: string; color: string }[];
  headerColor: string;
  statusText: string;
  demandForecast: string;
  omits: string;
  availablePlantsCount: string;
  substituteId: string;
  matNbr: string;
  formulariesCount: number;
  hasFormularies: boolean;
  materialFormularies: MaterialFormulary[];
}

const mapSubstituteData = (
  storeSubstitute: any
): SubstituteProduct => {
  const getHeaderColor = (rank: number): string => {
    if (rank === 1) return "var(--color-text-success, #007F50)";
    if (rank === 2) return "#F97316";
    return "var(--Cencora-brand-700-core, var(--color-brand-700, #461E96))";
  };

  const getStatusText = (rank: number): string => {
    if (rank === 1) return "ALTERNATIVE 1 (BEST MATCH)";
    if (rank === 2) return "ALTERNATIVE 2 (GOOD MATCH)";
    return `ALTERNATIVE ${rank} (VIABLE OPTION)`;
  };

  const getTags = (storeSubstitute: any) => {
    const tags: { label: string; color: string }[] = [];

    if (storeSubstitute.materialFormularies && storeSubstitute.materialFormularies.length > 0) {
      tags.push({ label: "Switch to This Vendor", color: "bg-green-100 text-green-800" });
    }

    return tags;
  };

  const calculateInventoryDays = (saleableQty: number, forecastQty: number): number => {
    if (forecastQty === 0) return 0;
    return Math.round((saleableQty / forecastQty) * 7);
  };

  const inventoryDays = calculateInventoryDays(
    storeSubstitute.saleableQtyOnHand || 0,
    storeSubstitute.forecastQty7day || 1
  );

  const materialFormularies = storeSubstitute.materialFormularies || [];


  const getSupplierName = (rank: number): string => {
    switch (rank) {
      case 1: return "Winder Pharma";
      case 2: return "Rising Pharma";
      case 3: return "Par Pharma Inc";
      case 4: return "Mylan Pharmaceuticals";
      default: return `Vendor ${storeSubstitute.vendorId || "Unknown"}`;
    }
  };

  const result = {
    id: (storeSubstitute.id || 0).toString(),
    title: storeSubstitute.substituteName || "Phenobarb 64.8 mg Tab 1000",
    name: storeSubstitute.substituteName || "Phenobarb 64.8 mg Tab 1000",
    vendor: storeSubstitute.materialVendorName || getSupplierName(storeSubstitute.rank || 4),
    vendorNbr: storeSubstitute.vendorNbr || "",
    riskExposure: formatUsdFull(storeSubstitute.dollarsAtRisk || 0),
    marketShare:
      storeSubstitute.marketShare && storeSubstitute.marketShare > 0
        ? formatPercentValue(storeSubstitute.marketShare || 0, 0)
        : "-",
    inventoryDays: inventoryDays > 0 ? `${formatUsNumber(inventoryDays)} days` : "-",
    costUnit: storeSubstitute.costPerUnit && storeSubstitute.costPerUnit > 0 ? formatUsdFull(storeSubstitute.costPerUnit) : "$-",
    availability:
      storeSubstitute.saleableQtyOnHand && storeSubstitute.saleableQtyOnHand > 0
        ? formatUsNumber(Math.round(storeSubstitute.saleableQtyOnHand || 0))
        : "-",
    contract: materialFormularies.length > 0 ? materialFormularies[0].name : "No Contract",
    tags: getTags(storeSubstitute),
    headerColor: getHeaderColor(storeSubstitute.rank || 4),
    statusText: getStatusText(storeSubstitute.rank || 4),
    demandForecast:
      storeSubstitute.forecastQty7day && storeSubstitute.forecastQty7day > 0
        ? formatUsNumber(storeSubstitute.forecastQty7day || 0)
        : "-",
    omits: formatUsNumber(storeSubstitute.omits || 0),
    availablePlantsCount: formatUsNumber(storeSubstitute.availablePlantsCount || 0),
    substituteId: storeSubstitute.substituteId ? storeSubstitute.substituteId.toString() : '0',
    matNbr: storeSubstitute.substituteMatNbr || "",
    formulariesCount: materialFormularies.length,
    hasFormularies: materialFormularies.length > 0,
    materialFormularies: materialFormularies,
  };


  return result;
};

const MaterialCard: React.FC<{ materialName: string; vendorName: string }> = ({
  materialName,
  vendorName,
}) => (
  <div className="flex items-center justify-between rounded-lg bg-slate-50 border border-slate-200 p-4">
    <div className="flex items-center gap-4">
      <div className="w-12 h-12 rounded-lg flex items-center justify-center bg-brand-primary-700">
        <PillIcon className="w-6 h-6 text-white" />
      </div>
      <div>
        <h3 className="text-base font-semibold text-text-heading">{materialName}</h3>
        <p className="text-sm text-text-secondary">{vendorName}</p>
      </div>
    </div>
    <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold bg-danger-50 border border-danger-200 text-danger-600">
      <AlertTriangleIcon className="w-3.5 h-3.5" />
      Highly Likely
    </div>
  </div>
);

const LOW_STOCK_DAYS_THRESHOLD = 14;

const DC_MAP_CENTER: [number, number] = [39.0, -96.5];
const DC_MAP_ZOOM = 4;
const DC_MAP_BOUNDS: [[number, number], [number, number]] = [
  [24.0, -125.0],
  [50.0, -66.0],
];
const dcMapGeoJsonStyle = {
  fillColor: "var(--color-neutral-200, #CACACA)",
  color: "#ffffff",
  weight: 1,
  opacity: 1,
  fillOpacity: 1,
};

const DistributionCenterUSStatesLayer: React.FC = () => {
  const map = useMap();
  useEffect(() => {
    const geojsonData = usStatesData as any;
    const layer = L.geoJSON(geojsonData, {
      style: () => dcMapGeoJsonStyle,
    });
    layer.addTo(map);
    return () => {
      map.removeLayer(layer);
    };
  }, [map]);
  return null;
};

type DistributionCenterItem = {
  id: number | string;
  name: string;
  location: string;
  daysOnHand: number;
  onHandQuantity: number;
  riskLevel: string;
  latitude: number | null;
  longitude: number | null;
  stockLevel: "available" | "low";
};

const DistributionCenterMapMarkers: React.FC<{
  centers: DistributionCenterItem[];
  selectedCenterId: number | string | null;
  onCenterClick: (center: DistributionCenterItem) => void;
}> = ({ centers, selectedCenterId, onCenterClick }) => {
  const map = useMap();
  const markersRef = useRef<L.Marker[]>([]);

  useEffect(() => {
    markersRef.current.forEach((marker) => map.removeLayer(marker));
    markersRef.current = [];

    centers.forEach((center) => {
      if (center.latitude != null && center.longitude != null) {
        const color = center.stockLevel === "low" ? "#F97316" : "#22C55E";
        const marker = L.marker([center.latitude, center.longitude], {
          icon: L.divIcon({
            className: "custom-dc-marker",
            html: `
              <div style="
                width: 28px;
                height: 28px;
                border-radius: 50%;
                background-color: ${color};
                border: 2px solid white;
                box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                cursor: pointer;
              "></div>
            `,
            iconSize: [28, 28],
            iconAnchor: [14, 14],
          }),
        });
        marker.on("click", () => {
          onCenterClick(center);
        });
        marker.addTo(map);
        markersRef.current.push(marker);
      }
    });

    return () => {
      markersRef.current.forEach((marker) => map.removeLayer(marker));
      markersRef.current = [];
    };
  }, [map, centers, selectedCenterId, onCenterClick]);

  return null;
};

const FlyToCenter: React.FC<{ center: DistributionCenterItem | null }> = ({ center }) => {
  const map = useMap();
  useEffect(() => {
    if (center?.latitude != null && center?.longitude != null) {
      map.setView([center.latitude, center.longitude], 10);
    }
  }, [map, center?.id, center?.latitude, center?.longitude]);
  return null;
};

const DistributionCenterZoomControl: React.FC = () => {
  const map = useMap();
  useEffect(() => {
    const zoomControl = L.control.zoom({ position: "topright" });
    zoomControl.addTo(map);
    return () => {
      if (typeof (map as L.Map).removeControl === "function") {
        (map as L.Map).removeControl(zoomControl);
      }
    };
  }, [map]);
  return null;
};

const DistributionCentersModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  materialName: string;
  vendorName: string;
  substitutionId: string;
}> = ({ isOpen, onClose, materialName, vendorName, substitutionId }) => {
  const [distributionCenters, setDistributionCenters] = useState<DistributionCenterItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedCenterId, setSelectedCenterId] = useState<number | string | null>(null);
  const hasFetchedRef = useRef<boolean>(false);
  const currentSubstitutionIdRef = useRef<string>("");
  const listRowRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const fetchDistributionCentersData = useCallback(async () => {
    if (hasFetchedRef.current && currentSubstitutionIdRef.current === substitutionId) {
      return;
    }

    setLoading(true);
    setError(null);
    setSelectedCenterId(null);
    hasFetchedRef.current = true;
    currentSubstitutionIdRef.current = substitutionId;

    try {
      const response = await demandForecastService.getInventoryOnEachPlant(substitutionId);
      const result = response.data;

      if (result.success && result.data) {
        const mappedCenters: DistributionCenterItem[] = result.data.map((item: any) => {
          const daysOnHand =
            item.forecast_qty_7day > 0
              ? (item.unrestricted_qty_on_hand / (item.forecast_qty_7day / 7))
              : 0;
          const roundedDays = Math.round(daysOnHand);
          const plant = item.plant || {};
          const props = plant.properties || {};
          const name =
            (props.plant_name as string) || plant.name || plant.id || item.plant_nbr || "Unknown";
          const locationParts = [plant.city, plant.state, plant.postal_code].filter(Boolean);
          const location = locationParts.length > 0 ? locationParts.join(", ") : "Location not available";

          return {
            id: plant.node_id ?? plant.id ?? item.plant_nbr ?? 0,
            name: String(name),
            location,
            daysOnHand: roundedDays,
            onHandQuantity: Math.round(item.unrestricted_qty_on_hand ?? 0),
            riskLevel: "Highly Likely",
            latitude: plant.latitude != null ? Number(plant.latitude) : null,
            longitude: plant.longitude != null ? Number(plant.longitude) : null,
            stockLevel: roundedDays < LOW_STOCK_DAYS_THRESHOLD ? "low" : "available",
          };
        });
        setDistributionCenters(mappedCenters);
      } else {
        setError("Failed to load distribution centers data");
      }
    } catch (err) {
      console.error("Error fetching distribution centers:", err);
      setError("Failed to load distribution centers data");
    } finally {
      setLoading(false);
    }
  }, [substitutionId]);

  useEffect(() => {
    if (isOpen && substitutionId) {
      fetchDistributionCentersData();
    } else if (!isOpen) {
      hasFetchedRef.current = false;
      currentSubstitutionIdRef.current = "";
      setSelectedCenterId(null);
    }
  }, [isOpen, substitutionId, fetchDistributionCentersData]);

  const selectedCenter =
    selectedCenterId != null
      ? distributionCenters.find((c) => c.id === selectedCenterId) ?? null
      : null;

  const handleCenterClick = useCallback((center: DistributionCenterItem) => {
    setSelectedCenterId(center.id);
  }, []);

  useEffect(() => {
    if (selectedCenterId != null) {
      const key = String(selectedCenterId);
      const el = listRowRefs.current[key];
      el?.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
  }, [selectedCenterId]);

  if (!isOpen) return null;

  return createPortal(
    <div
      className="fixed top-0 left-0 right-0 bottom-0 w-screen h-screen min-w-full min-h-full bg-black bg-opacity-50 flex items-center justify-center z-9999"
    >
      <div
        className="bg-white rounded-lg shadow-xl w-[95vw] max-w-[900px] mx-4 flex flex-col"
        style={{ maxHeight: "85vh", overflow: "hidden" }}
      >
        <div className="flex items-center justify-between p-6 border-b border-gray-200 shrink-0">
          <div>
            <h2
              className="text-xl font-semibold mb-1"
              style={{
                color: "var(--Cencora-brand-700-core, #461E96)",
                fontFamily: "var(--text-heading-xl-font-family, Cencora-Gilroy)",
                fontSize: "20px",
                fontWeight: "600",
              }}
            >
              Distribution Centers
            </h2>
            <p
              className="text-gray-600"
              style={{
                color: "var(--Cencora-text-secondary, #6E6E6E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "500",
              }}
            >
              {materialName} – {vendorName} availability
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl font-light"
            style={{ lineHeight: "1" }}
          >
            ×
          </button>
        </div>

        <div className="p-6 flex-1 flex flex-col min-h-0 overflow-hidden">
          {loading && (
            <div className="flex items-center justify-center py-8">
              <div className="text-sm text-gray-600">Loading distribution centers...</div>
            </div>
          )}

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md text-red-700 text-sm">
              {error}
            </div>
          )}

          {!loading && !error && distributionCenters.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No distribution centers found.
            </div>
          )}

          {!loading && !error && distributionCenters.length > 0 && (
            <>
              <div className="mb-4 shrink-0">
                <div
                  className="rounded-lg border border-gray-200 overflow-hidden"
                  style={{ height: "280px" }}
                >
                  <MapContainer
                    style={{
                      height: "100%",
                      width: "100%",
                      borderRadius: "8px",
                      background: "#f8fafc",
                    }}
                    center={DC_MAP_CENTER}
                    zoom={DC_MAP_ZOOM}
                    minZoom={2}
                    maxZoom={12}
                    zoomControl={false}
                    attributionControl={false}
                    scrollWheelZoom
                    maxBounds={DC_MAP_BOUNDS}
                    maxBoundsViscosity={1}
                  >
                    <DistributionCenterUSStatesLayer />
                    <DistributionCenterMapMarkers
                      centers={distributionCenters}
                      selectedCenterId={selectedCenterId}
                      onCenterClick={handleCenterClick}
                    />
                    <FlyToCenter center={selectedCenter} />
                    <DistributionCenterZoomControl />
                  </MapContainer>
                </div>
                <div className="flex gap-6 mt-2 text-sm">
                  <span className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ backgroundColor: "#22C55E" }}
                    />
                    <span>
                      Available Stock (≥{LOW_STOCK_DAYS_THRESHOLD} days)
                    </span>
                  </span>
                  <span className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ backgroundColor: "#F97316" }}
                    />
                    <span>
                      Low Stock (&lt;{LOW_STOCK_DAYS_THRESHOLD} days)
                    </span>
                  </span>
                </div>
              </div>

              <div className="mt-4 flex-1 min-h-0 flex flex-col">
                <h3
                  className="text-sm font-semibold mb-3"
                  style={{
                    color: "var(--Cencora-text-heading, #1E1E1E)",
                    fontFamily: "var(--text-heading-sm-font-family, Cencora-Gilroy)",
                  }}
                >
                  {formatUsNumber(distributionCenters.length)} DISTRIBUTION CENTERS
                </h3>
                <div
                  className="space-y-3 overflow-auto flex-1 pr-1"
                  style={{ maxHeight: "280px" }}
                >
                  {distributionCenters.map((center) => {
                    const isSelected = selectedCenterId !== null && center.id === selectedCenterId;
                    return (
                      <div
                        key={center.id}
                        ref={(el) => {
                          listRowRefs.current[String(center.id)] = el;
                        }}
                        role="button"
                        tabIndex={0}
                        onClick={() => handleCenterClick(center)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            handleCenterClick(center);
                          }
                        }}
                        className="flex items-center gap-4 border rounded-lg p-4 cursor-pointer transition-colors"
                        style={{
                          borderRadius: "8px",
                          border: isSelected
                            ? "2px solid var(--Cencora-brand-700-core, #461E96)"
                            : "1px solid #E2E8F0",
                          background: isSelected ? "rgba(70, 30, 150, 0.06)" : "#FFF",
                        }}
                      >
                        <span
                          className="w-3 h-3 rounded-full shrink-0"
                          style={{
                            backgroundColor:
                              center.stockLevel === "low" ? "#F97316" : "#22C55E",
                          }}
                        />
                        <div className="flex-1 min-w-0">
                          <div
                            className="font-semibold truncate"
                            style={{
                              color: "var(--Cencora-text-heading, #1E1E1E)",
                              fontSize: "14px",
                            }}
                          >
                            {center.name}
                          </div>
                          <div
                            className="text-sm truncate"
                            style={{ color: "var(--Cencora-text-secondary, #6E6E6E)" }}
                          >
                            {center.location}
                          </div>
                        </div>
                        <div className="flex gap-6 shrink-0">
                          <div>
                            <div
                              className="font-semibold text-right"
                              style={{
                                color: "var(--Cencora-text-heading, #1E1E1E)",
                                fontSize: "14px",
                              }}
                            >
                              {formatUsNumber(center.daysOnHand)} days
                            </div>
                            <div
                              className="text-xs text-right"
                              style={{ color: "var(--Cencora-text-secondary, #6E6E6E)" }}
                            >
                              DAYS ON HAND
                            </div>
                          </div>
                          <div>
                            <div
                              className="font-semibold text-right"
                              style={{
                                color: "var(--Cencora-text-heading, #1E1E1E)",
                                fontSize: "14px",
                              }}
                            >
                              {formatUsNumber(center.onHandQuantity)}
                            </div>
                            <div
                              className="text-xs text-right"
                              style={{ color: "var(--Cencora-text-secondary, #6E6E6E)" }}
                            >
                              ON HAND QTY
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
};

function valueAtRiskValueTextClass(value: string): string {
  if (value === "-" || value === "$-") return "text-2xl";
  const len = value.length;
  if (len <= 11) return "text-2xl";
  if (len <= 14) return "text-xl";
  if (len <= 17) return "text-lg";
  if (len <= 21) return "text-base";
  return "text-sm";
}

const KPIMetricItem: React.FC<{
  icon: React.ReactNode;
  value: string;
  label: string;
  valueClassName?: string;
}> = ({ icon, value, label, valueClassName = "text-2xl" }) => (
  <div className="flex flex-col p-4 bg-white rounded-lg border border-slate-200 shadow-xs flex-1 min-w-[120px] h-full">
    <div className="flex items-center gap-2 mb-3">
      <div className="w-8 h-8 rounded-md flex items-center justify-center bg-brand-primary-50 shrink-0">
        {icon}
      </div>
      <span className="text-xs font-medium text-text-secondary leading-tight">{label}</span>
    </div>
    <span className={`font-semibold leading-tight tabular-nums wrap-break-word min-w-0 ${valueClassName}`}>{value}</span>
  </div>
);

interface KPIMetricsProps {
  valueAtRisk?: string;
  marketShare?: string;
  demandForecast?: string;
  onHandQuantity?: string;
  daysOnHand?: string;
  costPerUnit?: string;
  contractCount?: string;
  distributionCenters?: string;
}

const KPIMetrics: React.FC<KPIMetricsProps> = ({
  valueAtRisk = "$0.00",
  marketShare = "0%",
  demandForecast = "0",
  onHandQuantity = "0",
  daysOnHand = "0",
  costPerUnit = "$0.00",
  contractCount = "0",
  distributionCenters = "0",
}) => {
  const valueAtRiskDisplay = valueAtRisk;

  return (
  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 items-stretch">
    <KPIMetricItem
      icon={<AlertTriangleIcon className="w-4 h-4 text-brand-primary-700" />}
      value={valueAtRiskDisplay}
      label="Value at Risk"
      valueClassName={valueAtRiskValueTextClass(valueAtRiskDisplay)}
    />
    {!isVariantFamily() && (
      <KPIMetricItem
        icon={<AnalyticsGraphBarIcon className="w-4 h-4 text-brand-primary-700" />}
        value={marketShare}
        label="GCN Market Share"
      />
    )}
    {!isVariantFamily() && (
      <KPIMetricItem
        icon={<AppWindowGraphIcon className="w-4 h-4 text-brand-primary-700" />}
        value={demandForecast}
        label="Demand Forecast"
      />
    )}
    {!isVariantFamily() && (
      <KPIMetricItem
        icon={<ShipmentUploadIcon className="w-4 h-4 text-brand-primary-700" />}
        value={onHandQuantity}
        label="On Hand Quantity"
      />
    )}
    <KPIMetricItem
      icon={<CalendarIcon className="w-4 h-4 text-brand-primary-700" />}
      value={daysOnHand}
      label="Days on Hand"
    />
    {!isVariantFamily() && (
      <KPIMetricItem
        icon={<DiscountDollarDashIcon className="w-4 h-4 text-brand-primary-700" />}
        value={costPerUnit}
        label="Cost/Unit"
      />
    )}
    <KPIMetricItem
      icon={<TaskListCheckIcon className="w-4 h-4 text-brand-primary-700" />}
      value={contractCount}
      label="Contract"
    />
    <KPIMetricItem
      icon={<EarthSearchIcon className="w-4 h-4 text-brand-primary-700" />}
      value={distributionCenters}
      label="Distribution Centers"
    />
  </div>
  );
};

const SubstituteTable: React.FC<{
  products: SubstituteProduct[];
  onDistributionCentersClick: (product: SubstituteProduct) => void;
  onRadioChange: (substituteId: string) => void;
  selectedSubstituteId?: string;
}> = ({ products, onDistributionCentersClick, onRadioChange, selectedSubstituteId }) => {
  const [formularyIndexByProductId, setFormularyIndexByProductId] = useState<Record<string, number>>({});
  const productsKey = products.map(p => p.id).join(",");

  useEffect(() => {
    setFormularyIndexByProductId((prev) => {
      const next: Record<string, number> = {};
      for (const p of products) {
        const count = p.formulariesCount || 0;
        const prevIdx = prev[p.id] ?? 0;
        const clamped = count > 0 ? Math.min(Math.max(prevIdx, 0), count - 1) : 0;
        next[p.id] = clamped;
      }
      return next;
    });
  }, [productsKey]);

  const getFormularyIndex = (productId: string) => formularyIndexByProductId[productId] ?? 0;
  const setPrevFormulary = (product: SubstituteProduct) => {
    const count = product.formulariesCount || 0;
    if (count <= 1) return;
    setFormularyIndexByProductId((prev) => {
      const current = prev[product.id] ?? 0;
      const nextIdx = current > 0 ? current - 1 : count - 1;
      return { ...prev, [product.id]: nextIdx };
    });
  };
  const setNextFormulary = (product: SubstituteProduct) => {
    const count = product.formulariesCount || 0;
    if (count <= 1) return;
    setFormularyIndexByProductId((prev) => {
      const current = prev[product.id] ?? 0;
      const nextIdx = current < count - 1 ? current + 1 : 0;
      return { ...prev, [product.id]: nextIdx };
    });
  };

  return (
    <div className="w-full ">
      <table className="w-full border-collapse bg-white min-w-[1200px]" style={{ borderSpacing: 0, width: 'max-content' }}>
        <thead>
          <tr>
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">
              <div className="flex items-center gap-1">
                Potential Substitutes
                <QuestionCircleIcon
                  className="w-4 h-4"
                  style={{
                    color: 'var(--cencora-brand-700-core, var(--color-brand-700, #461E96))'
                  }}
                />
              </div>
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">
              Supplier
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">
              Status
            </th>
            {!isVariantFamily() && (
              <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">
                Market Share
              </th>
            )}
            {!isVariantFamily() && (
              <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">
                Demand Forecast
              </th>
            )}
            {!isVariantFamily() && (
              <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">
                On Hand Quantity
              </th>
            )}
            <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">
              Days on Hand
            </th>
            {!isVariantFamily() && (
              <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">
                Cost/Unit
              </th>
            )}
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">
              <div className="flex items-center gap-1">
                Contract
                <QuestionCircleIcon
                  className="w-4 h-4"
                  style={{
                    color: 'var(--cencora-brand-700-core, var(--color-brand-700, #461E96))'
                  }}
                />
              </div>
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">
              View More
            </th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => {
            const getStatusStyle = () => {
              if (product.statusText.includes("BEST MATCH")) {
                return {
                  backgroundColor: "var(--color-text-success, #007F50)",
                  color: "#FFFFFF",
                  padding: "4px 12px",
                  borderRadius: "var(--size-border-radius-full, 9999px)",
                  fontSize: "12px",
                  fontWeight: "500"
                };
              } else if (product.statusText.includes("Not Available")) {
                return {
                  backgroundColor: "#9CA3AF",
                  color: "#374151",
                  padding: "4px 12px",
                  borderRadius: "12px",
                  fontSize: "12px",
                  fontWeight: "500"
                };
              } else {
                return {
                  color: "#374151",
                  fontSize: "12px",
                  fontWeight: "500"
                };
              }
            };

            const statusStyle = getStatusStyle();

            return (
              <tr key={product.id}>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="selectedSubstitute"
                      checked={selectedSubstituteId === product.id}
                      onChange={() => onRadioChange(product.id)}
                      className="w-4 h-4"
                      style={{
                        accentColor: "#593AB1"
                      }}
                    />
                    <span className="text-sm text-gray-900">
                      {product.name}{product.matNbr && <span className="text-slate-400"> • {product.matNbr}</span>}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className="text-sm text-gray-900">
                    {product.vendor.replace('Vendor ', '')}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span style={statusStyle}>
                    {product.statusText}
                  </span>
                </td>
                {!isVariantFamily() && (
                  <td className="px-4 py-3 text-center">
                    <span className="text-sm text-gray-900">
                      {product.marketShare}
                    </span>
                  </td>
                )}
                {!isVariantFamily() && (
                  <td className="px-4 py-3 text-center">
                    <span className="text-sm text-gray-900">
                      {product.demandForecast}
                    </span>
                  </td>
                )}
                {!isVariantFamily() && (
                  <td className="px-4 py-3 text-center">
                    <span className="text-sm text-gray-900">
                      {product.availability}
                    </span>
                  </td>
                )}
                <td className="px-4 py-3 text-center">
                  <span className="text-sm text-gray-900">
                    {product.inventoryDays}
                  </span>
                </td>
                {!isVariantFamily() && (
                  <td className="px-4 py-3 text-center">
                    <span className="text-sm text-gray-900">
                      {product.costUnit}
                    </span>
                  </td>
                )}
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    {product.hasFormularies && product.formulariesCount > 1 && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setPrevFormulary(product);
                        }}
                        className="text-brand-primary-700 hover:text-brand-primary-800"
                        aria-label="Previous contract"
                      >
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" style={{
                          filter: 'brightness(0) saturate(100%) invert(35%) sepia(91%) saturate(1267%) hue-rotate(242deg) brightness(91%) contrast(101%)'
                        }}>
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                        </svg>
                      </button>
                    )}
                    <span className="text-sm text-gray-900">
                      {product.hasFormularies
                        ? product.materialFormularies?.[getFormularyIndex(product.id)]?.name ?? "No Contract"
                        : "No Contract"}
                    </span>
                    {product.hasFormularies && product.formulariesCount > 1 && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setNextFormulary(product);
                        }}
                        className="text-brand-primary-700 hover:text-brand-primary-800"
                        aria-label="Next contract"
                      >
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" style={{
                          filter: 'brightness(0) saturate(100%) invert(35%) sepia(91%) saturate(1267%) hue-rotate(242deg) brightness(91%) contrast(101%)'
                        }}>
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </button>
                    )}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <button
                    className="flex items-center gap-1 px-3 py-1 border rounded text-xs font-medium cursor-pointer hover:opacity-80 transition-opacity"
                    style={{
                      borderColor: "#593AB1",
                      backgroundColor: "#593AB1",
                      color: "#FFFFFF",
                      borderRadius: "4px"
                    }}
                    onClick={() => onDistributionCentersClick(product)}
                  >
                    <EarthSearchIcon
                      className="w-3 h-3"
                      style={{
                        color: 'white'
                      }}
                    />
                    <span>({product.availablePlantsCount}) DC</span>
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

const SubstituteCard: React.FC<{
  product: SubstituteProduct;
  onDistributionCentersClick: (product: SubstituteProduct) => void;
  isChecked: boolean;
  onCheckboxChange: (checked: boolean) => void;
}> = ({ product, onDistributionCentersClick, isChecked, onCheckboxChange }) => {
  const [currentFormularyIndex, setCurrentFormularyIndex] = useState(0);

  useEffect(() => {
    setCurrentFormularyIndex(0);
  }, [product.id]);

  const isBestMatch = (statusText: string) => statusText.includes("BEST MATCH");

  const getDisplayStatusText = (statusText: string) => {
    if (statusText.includes("BEST MATCH")) {
      return "Best Match";
    } else if (statusText.includes("GOOD MATCH")) {
      return "Alternative 2";
    } else if (statusText.includes("VIABLE OPTION")) {
      const match = statusText.match(/ALTERNATIVE (\d+)/);
      return match ? `Alternative ${match[1]}` : "Alternative";
    }
    return statusText;
  };

  const getStatusColor = (statusText: string) => {
    if (statusText.includes("GOOD MATCH") || statusText.includes("VIABLE OPTION")) {
      return "text-brand-primary-700";
    }
    return "text-text-heading";
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 shadow-xs flex flex-col h-full">
      {/* Card Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-100">
        {/* Radio + Switch Label */}
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="radio"
            checked={isChecked}
            onChange={(e) => onCheckboxChange(e.target.checked)}
            className="w-4 h-4 accent-brand-primary-700"
          />
          <span className="text-sm font-medium text-brand-primary-700">
            Switch to This Material
          </span>
        </label>

        {/* Distribution Centers Button */}
        <button
          onClick={() => onDistributionCentersClick(product)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-brand-primary-700 border-2 border-slate-200 rounded hover:bg-slate-50 transition-colors"
        >
          <EarthSearchIcon className="w-4 h-4" />
          <span>({product.availablePlantsCount}) Distribution Centers</span>
        </button>
      </div>

      {/* Product Info - Title Row with background */}
      <div className="p-4 bg-slate-50">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-base font-semibold text-text-heading mb-0.5">
              {product.name}{product.matNbr && <span className="text-sm font-normal text-slate-400"> • {product.matNbr}</span>}
            </h3>
            <p className="text-sm text-text-secondary">
              {product.vendor}{product.vendorNbr && <span className="text-slate-400"> • {product.vendorNbr}</span>}
            </p>
          </div>
          {isBestMatch(product.statusText) ? (
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-success-500 text-white">
              {getDisplayStatusText(product.statusText)}
            </span>
          ) : (
            <span className={`text-base font-bold ${getStatusColor(product.statusText)}`}>
              {getDisplayStatusText(product.statusText)}
            </span>
          )}
        </div>
      </div>

      {/* KPI List */}
      <div className="p-4">
        <div className="space-y-2">
          <div className="flex justify-between items-center py-1">
            <span className="text-sm text-text-secondary">Value at Risk</span>
            <span className="text-sm font-semibold text-text-heading">{product.riskExposure}</span>
          </div>
          <div className="flex justify-between items-center py-1">
            <span className="text-sm text-text-secondary">Market Share</span>
            <span className="text-sm font-semibold text-text-heading">{product.marketShare}</span>
          </div>
          <div className="flex justify-between items-center py-1">
            <span className="text-sm text-text-secondary">Demand Forecast</span>
            <span className="text-sm font-semibold text-text-heading">{product.demandForecast}</span>
          </div>
          <div className="flex justify-between items-center py-1">
            <span className="text-sm text-text-secondary">On Hand Quantity</span>
            <span className="text-sm font-semibold text-text-heading">{product.availability}</span>
          </div>
          <div className="flex justify-between items-center py-1">
            <span className="text-sm text-text-secondary">Days on hand</span>
            <span className="text-sm font-semibold text-text-heading">{product.inventoryDays}</span>
          </div>
          <div className="flex justify-between items-center py-1">
            <span className="text-sm text-text-secondary">Cost/Unit</span>
            <span className="text-sm font-semibold text-text-heading">{product.costUnit}</span>
          </div>

          {/* Contract with pagination */}
          <div className="flex justify-between items-center py-1">
            <span className="text-sm text-text-secondary">
              {product.hasFormularies && product.formulariesCount > 1
                ? `Contract (${formatUsNumber(currentFormularyIndex + 1)} of ${formatUsNumber(product.formulariesCount)})`
                : "Contract"
              }
            </span>
            <div className="flex items-center gap-2">
              {product.hasFormularies && product.formulariesCount > 1 && (
                <button
                  onClick={() => setCurrentFormularyIndex(prev =>
                    prev > 0 ? prev - 1 : product.formulariesCount - 1
                  )}
                  className="text-brand-primary-700 hover:text-brand-primary-800"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
              )}
              <span className="text-sm font-semibold text-text-heading">
                {product.hasFormularies
                  ? product.materialFormularies?.[currentFormularyIndex]?.name ?? "No Contract"
                  : "No Contract"}
              </span>
              {product.hasFormularies && product.formulariesCount > 1 && (
                <button
                  onClick={() => setCurrentFormularyIndex(prev =>
                    prev < product.formulariesCount - 1 ? prev + 1 : 0
                  )}
                  className="text-brand-primary-700 hover:text-brand-primary-800"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function ProductSubstitutionAnalysis() {
  const location = useLocation();
  const navigate = useNavigate();
  const [activeView, setActiveView] = useState<"flow" | "table">("flow");
  const [isDistributionModalOpen, setIsDistributionModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<SubstituteProduct | null>(null);
  const [selectedSubstitutes, setSelectedSubstitutes] = useState<Set<string>>(new Set());
  const [isKeepInMindModalOpen, setIsKeepInMindModalOpen] = useState(false);
  const [isDecisionRationaleModalOpen, setIsDecisionRationaleModalOpen] = useState(false);
  const [createdActionId, setCreatedActionId] = useState<number | null>(null);
  const [isSubmittingRationale, setIsSubmittingRationale] = useState(false);
  const [contractOptions, setContractOptions] = useState<{ name: string }[]>([]);
  const [selectedContract, setSelectedContract] = useState<string>("");
  const [contractLoading, setContractLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);


  const searchParams = new URLSearchParams(location.search);
  const materialIdParam = searchParams.get('material_id');
  const issueNbrParam = searchParams.get('issue_nbr');
  const potentialActionNbrParam = searchParams.get('potential_action_nbr');
  const materialIdFromUrl = materialIdParam ? parseInt(materialIdParam, 10) : null;

  const materialDataFromState = location.state as {
    materialId?: number;
    materialName?: string;
    vendorName?: string;
    materialData?: any;
    issueId?: number;
    issueNbr?: string;
    potentialAction?: any;
  } | null;

  const materialId = materialIdFromUrl || materialDataFromState?.materialId || null;
  const issueNbr = issueNbrParam || materialDataFromState?.issueNbr || null;
  const potentialActionNbr = potentialActionNbrParam || materialDataFromState?.potentialAction?.paction_nbr || null;
  const potentialAction = materialDataFromState?.potentialAction;
  const actionType = potentialAction?.recommendation_type_nbr || null;

  const materialSubstitutesParams = selectedContract
    ? new URLSearchParams({ material_formulary: selectedContract }).toString()
    : "";

  const {
    materialSubstitutes,
    hasMore: hasMoreMaterialSubstitutes,
    isLoading: isLoadingMaterialSubstitutes,
    isFetchingNextPage: isLoadingMoreMaterialSubstitutes,
    error: materialSubstitutesError,
    fetchNextPage: loadMoreMaterialSubstitutes,
  } = useMaterialSubstitutesInfiniteQuery({
    materialId,
    additionalParams: materialSubstitutesParams,
    enabled: !!materialId,
  });

  const {
    details: substitutedMaterialDetails,
    isLoading: substitutedMaterialDetailsLoading,
    error: substitutedMaterialDetailsError,
  } = useMaterialSubstituteDetailsQuery({
    materialId: materialId ?? undefined,
    enabled: !!materialId,
  });

  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const pendingActionToastRef = useRef<{ title: string; description?: string } | null>(null);

  useEffect(() => {
    const fetchContractOptions = async () => {
      setContractLoading(true);
      try {
        const response = await materialFormularyService.getUniqueMaterialFormulary();
        const result = response.data;

        if (result.success && result.data) {
          setContractOptions(result.data);
        } else {
          console.error('Failed to fetch contract options:', result);
        }
      } catch (error) {
        console.error('Error fetching contract options:', error);
      } finally {
        setContractLoading(false);
      }
    };

    fetchContractOptions();
  }, []);

  const handleScroll = useCallback(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const { scrollTop, scrollHeight, clientHeight } = container;
    const scrollThreshold = 100;

    if (
      scrollHeight - scrollTop - clientHeight < scrollThreshold &&
      hasMoreMaterialSubstitutes &&
      !isLoadingMoreMaterialSubstitutes &&
      !isLoadingMaterialSubstitutes
    ) {
      void loadMoreMaterialSubstitutes();
    }
  }, [
    hasMoreMaterialSubstitutes,
    isLoadingMoreMaterialSubstitutes,
    isLoadingMaterialSubstitutes,
    loadMoreMaterialSubstitutes,
  ]);

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    container.addEventListener("scroll", handleScroll);
    return () => container.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  const handleContractChange = (contractName: string) => {
    setSelectedContract(contractName);
  };

  const sortedMaterialSubstitutes = [...materialSubstitutes].sort(
    (a, b) => (a.rank || 999) - (b.rank || 999)
  );

  const substitutes: SubstituteProduct[] =
    sortedMaterialSubstitutes
      .map(mapSubstituteData)
      .filter((substitute, index, array) => {
        return array.findIndex(item => item.id === substitute.id) === index;
      });

  const filteredSubstitutes = selectedContract
    ? substitutes.filter(substitute =>
      substitute.materialFormularies?.some(formulary => formulary.name === selectedContract)
    )
    : substitutes;

  const substitutedMaterial = substitutedMaterialDetails?.material;
  const substitutedMaterialVendorName =
    typeof substitutedMaterial?.vendor === "object"
      ? `${substitutedMaterial?.vendor?.name}${substitutedMaterial?.vendor?.vendor_nbr ? ` • ${substitutedMaterial?.vendor?.vendor_nbr}` : ''}`
      : "";

  const materialData = substitutedMaterial
    ? {
      name: substitutedMaterial?.name || materialDataFromState?.materialName || "Unknown Material",
      vendorName: substitutedMaterialVendorName || materialDataFromState?.vendorName || "Unknown Vendor",
    }
    : {
      name: materialDataFromState?.materialName || "Unknown Material",
      vendorName: materialDataFromState?.vendorName || "Unknown Vendor",
    };

  const substitutedSaleableQty = substitutedMaterial?.saleable_qty_on_hand ?? null;
  const substitutedForecastQty7day = substitutedMaterial?.forecast_qty_7day ?? null;

  const kpiData = substitutedMaterial ? {
    valueAtRisk: substitutedMaterial.dollars_at_risk != null
      ? formatUsdFull(substitutedMaterial.dollars_at_risk)
      : "-",
    marketShare:
      substitutedMaterial.market_share != null
        ? formatPercentValue(substitutedMaterial.market_share, 0)
        : "-",
    demandForecast:
      substitutedMaterial.forecast_qty_7day != null &&
      Number(substitutedMaterial.forecast_qty_7day) > 0
        ? formatUsNumber(Number(substitutedMaterial.forecast_qty_7day))
        : "-",
    onHandQuantity:
      substitutedMaterial.saleable_qty_on_hand != null
        ? formatUsNumber(Math.round(substitutedMaterial.saleable_qty_on_hand))
        : "-",
    daysOnHand:
      substitutedSaleableQty != null && substitutedForecastQty7day != null
        ? substitutedForecastQty7day === 0
          ? "0"
          : formatUsNumber(Math.round((substitutedSaleableQty / substitutedForecastQty7day) * 7))
        : "-",
    costPerUnit: substitutedMaterial.cost_per_unit != null
      ? formatUsdFull(substitutedMaterial.cost_per_unit)
      : "-",
    contractCount:
      substitutedMaterialDetails?.material_formularies &&
      substitutedMaterialDetails.material_formularies.length > 0
        ? formatUsNumber(substitutedMaterialDetails.material_formularies.length)
        : "No Contract",
    distributionCenters:
      substitutedMaterialDetails?.available_plants_count != null
        ? formatUsNumber(substitutedMaterialDetails.available_plants_count)
        : "-",
  } : {
    valueAtRisk: "-",
    marketShare: "-",
    demandForecast: "-",
    onHandQuantity: "-",
    daysOnHand: "-",
    costPerUnit: "-",
    contractCount: "No Contract",
    distributionCenters: "-",
  };

  const handleCancel = () => {
    navigate("/react");
  };

  const handleDone = () => {
    if (selectedSubstitutes.size > 0) {
      setIsKeepInMindModalOpen(true);
    }
  };

  const handleKeepInMindContinue = async () => {
    const isActionFlow = !!(issueNbr && potentialActionNbr);

    if (!isActionFlow) {
      setIsKeepInMindModalOpen(false);
      navigate("/react");
      return;
    }

    if (selectedSubstitutes.size === 0) {
      console.error('No substitute selected');
      setIsKeepInMindModalOpen(false);
      return;
    }

    setIsSubmitting(true);

    try {
      const selectedSubstituteId = Array.from(selectedSubstitutes)[0];

      const selectedSubstitute = materialSubstitutes.find(
        (sub: any) => sub.id?.toString() === selectedSubstituteId
      );

      if (!selectedSubstitute) {
        console.error('Could not find selected substitute');
        setIsKeepInMindModalOpen(false);
        navigate("/react");
        return;
      }

      const matNbr = materialDataFromState?.materialData?.mat_nbr;

      if (!matNbr) {
        console.error('Material number (mat_nbr) is missing');
        setIsKeepInMindModalOpen(false);
        navigate("/react");
        return;
      }

      const materialData = materialDataFromState?.materialData;
      const materialRiskRating = materialData?.risk_rating ?? substitutedMaterialDetails?.material?.risk_rating;
      const materialDrivingRisk = materialData?.driving_risk ?? substitutedMaterialDetails?.material?.driving_risk;
      const materialDollarsAtRisk = materialData?.dollars_at_risk ?? substitutedMaterialDetails?.material?.dollars_at_risk;

      const actionData = {
        issue_nbr: issueNbr,
        mat_nbr: matNbr,
        potential_action_nbr: potentialActionNbr,
        substituted_material_nbr: selectedSubstitute.substituteMatNbr || selectedSubstitute.substituteId?.toString(),
        material_risk_rating: materialRiskRating,
        material_driving_risk: materialDrivingRisk,
        material_dollars_at_risk: materialDollarsAtRisk,
      };

      const response = await createAction(actionData);

      if (response.success) {
        setIsKeepInMindModalOpen(false);

        const description =
          (typeof potentialAction?.recommendation === "string" && potentialAction.recommendation.trim()) ||
          "Your action was saved.";
        const successPayload: { title: string; description: string } = {
          title: "Action applied",
          description,
        };

        if (response.data?.id) {
          const newCount = incrementCompletedActionsCount();
          const actionTypeForModal = potentialAction?.recommendation_type_nbr || "31";
          const shouldShow = shouldShowDecisionRationaleModal(actionTypeForModal, newCount);

          if (shouldShow) {
            pendingActionToastRef.current = successPayload;
            setCreatedActionId(response.data.id);
            setIsDecisionRationaleModalOpen(true);
          } else {
            toast.success(successPayload);
            navigate("/react");
          }
        } else {
          toast.success(successPayload);
          navigate("/react");
        }
      } else {
        console.error("Failed to create action");
        toast.error({
          title: "Couldn't apply action",
          description: "Failed to create action",
        });
        setIsKeepInMindModalOpen(false);
        navigate("/react");
      }
    } catch (error) {
      console.error("Error creating action:", error);
      toast.error({
        title: "Couldn't apply action",
        description: getErrorMessage(error),
      });
      setIsKeepInMindModalOpen(false);
      navigate("/react");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDecisionRationaleSubmit = async (data: {
    time_to_complete: string;
    decision_rationale: string;
  }) => {
    if (!createdActionId) {
      console.error("Action ID is missing");
      return;
    }

    setIsSubmittingRationale(true);
    try {
      await submitDecisionRationale(createdActionId, data);
      const pending = pendingActionToastRef.current;
      pendingActionToastRef.current = null;
      toast.success({
        title: "Action applied",
        description:
          pending?.description != null ? `${pending.description} Rationale recorded.` : "Rationale recorded.",
      });
      setIsDecisionRationaleModalOpen(false);
      setCreatedActionId(null);
      navigate("/react");
    } catch (error) {
      console.error("Error submitting decision rationale:", error);
      if (pendingActionToastRef.current) {
        toast.success(pendingActionToastRef.current);
        pendingActionToastRef.current = null;
      }
      toast.error({
        title: "Couldn't save decision rationale",
        description: getErrorMessage(error),
      });
      throw error;
      throw error;
    } finally {
      setIsSubmittingRationale(false);
    }
  };

  const handleKeepInMindClose = () => {
    setIsKeepInMindModalOpen(false);
  };

  const handleSubstituteCheckboxChange = (substituteId: string, checked: boolean) => {
    setSelectedSubstitutes(prev => {
      if (checked) {
        return new Set([substituteId]);
      } else {
        const newSet = new Set(prev);
        newSet.delete(substituteId);
        return newSet;
      }
    });
  };

  const handleSubstituteRadioChange = (substituteId: string) => {
    setSelectedSubstitutes(new Set([substituteId]));
  };

  const handleDistributionCentersClick = (product: SubstituteProduct) => {
    setSelectedProduct(product);
    setIsDistributionModalOpen(true);
  };

  const handleCloseDistributionModal = () => {
    setIsDistributionModalOpen(false);
    setSelectedProduct(null);
  };

  return (
    <>
      <DashboardLayout hideBanner>
        {/* At Risk Material Section */}
        <div className="bg-white w-full max-w-[1460px] my-8">
          {/* Red top border line */}
          <div className="h-1 w-full bg-danger-500" />

          {/* At Risk Material Header */}
          <div className="px-6 pt-6 pb-2">
            <h1 className="text-xl font-semibold text-text-heading mb-1">
              At Risk Material
            </h1>
            <p className="text-base font-medium text-text-secondary">
              This is the material at risk from the manufacturer {materialData.name}
            </p>
          </div>

          {substitutedMaterialDetailsLoading && (
            <div className="px-6 pb-2 flex items-center gap-2">
              <LazyLoader />
              <span className="text-sm text-text-secondary">Loading material details...</span>
            </div>
          )}

          {substitutedMaterialDetailsError && (
            <div className="px-6 pb-2">
              <div className="p-3 bg-status-error-light border border-status-error-main rounded-md text-status-error-main text-sm">
                {substitutedMaterialDetailsError}
              </div>
            </div>
          )}

          {/* Driving Risk Badge and View Toggle */}
          <div className="px-6 pb-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              {/* Driving Risk Badge */}
              <div className="flex items-center gap-3">
                <span className="text-base font-semibold text-text-heading">
                  Driving Risk:
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded text-xs font-semibold bg-danger-50 border border-danger-200 text-danger-600">
                  Market Risk
                </span>
              </div>

              {/* View Toggle Buttons */}
              <div className="flex rounded border border-brand-primary-700 overflow-hidden">
                <button
                  onClick={() => setActiveView("table")}
                  className={`px-4 py-1.5 text-sm font-semibold transition-colors duration-200 ${
                    activeView === "table"
                      ? "bg-brand-primary-100 text-brand-primary-700"
                      : "bg-white text-brand-primary-700 hover:bg-brand-primary-50"
                  }`}
                >
                  Table View
                </button>
                <button
                  onClick={() => setActiveView("flow")}
                  className={`px-4 py-1.5 text-sm font-semibold transition-colors duration-200 border-l border-brand-primary-700 ${
                    activeView === "flow"
                      ? "bg-brand-primary-100 text-brand-primary-700"
                      : "bg-white text-brand-primary-700 hover:bg-brand-primary-50"
                  }`}
                >
                  Flow View
                </button>
              </div>
            </div>
          </div>

          {/* Material Card */}
          <div className="px-6 pb-4">
            <MaterialCard
              materialName={materialData.name}
              vendorName={materialData.vendorName}
            />
          </div>

          {/* KPI Metrics */}
          <div className="px-6 pb-6">
            <KPIMetrics
              valueAtRisk={kpiData.valueAtRisk}
              marketShare={kpiData.marketShare}
              demandForecast={kpiData.demandForecast}
              onHandQuantity={kpiData.onHandQuantity}
              daysOnHand={kpiData.daysOnHand}
              costPerUnit={kpiData.costPerUnit}
              contractCount={kpiData.contractCount}
              distributionCenters={kpiData.distributionCenters}
            />
          </div>
        </div>

        {/* Alternative Materials Section */}
        <div className="bg-white border-t border-slate-200 w-full max-w-[1460px]">
          <div className="px-6">
            {/* Alternative Materials Header */}
            <div className="flex flex-col lg:flex-row lg:justify-between lg:items-start pt-6 pb-4 gap-4">
              <div className="flex-1">
                <h2 className="text-xl font-semibold text-text-heading mb-1">
                  Alternative Materials
                </h2>
                <p className="text-base font-medium text-text-secondary">
                  Evaluate alternative products based on risk factors, availability, and business impact
                </p>
              </div>
              <div className="flex flex-col items-start lg:items-end">
                <div className="w-full lg:w-auto min-w-[200px]">
                  <label className="block text-sm font-medium text-text-heading mb-2">
                    Contract
                  </label>
                  {contractLoading ? (
                    <div className="w-full px-3 py-2 border border-slate-300 rounded-md bg-slate-50 text-text-secondary text-sm">
                      Loading...
                    </div>
                  ) : contractOptions.length === 0 ? (
                    <div className="w-full px-3 py-2 border border-slate-200 rounded-md bg-slate-50 text-text-heading text-sm">
                      No Contract
                    </div>
                  ) : (
                    <select
                      className="w-full px-3 py-2 border border-slate-300 rounded-md bg-white text-text-heading text-sm focus:outline-hidden focus:ring-2 focus:ring-brand-primary-700 focus:border-brand-primary-700 appearance-none pr-8"
                      style={{
                        backgroundImage: 'url("data:image/svg+xml,%3csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 20 20\'%3e%3cpath stroke=\'%236b7280\' stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'1.5\' d=\'m6 8 4 4 4-4\'/%3e%3c/svg%3e")',
                        backgroundPosition: 'right 8px center',
                        backgroundRepeat: 'no-repeat',
                        backgroundSize: '16px'
                      }}
                      value={selectedContract}
                      onChange={(e) => handleContractChange(e.target.value)}
                    >
                      <option value="">Contract</option>
                      {contractOptions.map((contract, index) => (
                        <option key={index} value={contract.name}>
                          {contract.name}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              </div>
            </div>

            {activeView === "flow" && isLoadingMaterialSubstitutes && (
              <div className="flex items-center gap-2 pb-4">
                <LazyLoader />
                <span className="text-sm text-text-secondary">Loading substitutes...</span>
              </div>
            )}

            {materialSubstitutesError && (
              <div className="mb-4 p-3 bg-status-error-light border border-status-error-main rounded-md text-status-error-main text-sm">
                {materialSubstitutesError}
              </div>
            )}

            {!materialId && (
              <div className="mb-4 p-3 bg-status-warning-light border border-status-warning-main rounded-md text-status-warning-dark text-sm">
                No material selected. Please navigate from a vendor page.
              </div>
            )}

            <div
              className="rounded w-full"
              style={{
                borderRadius: '4px'
              }}
            >
              <div
                ref={scrollContainerRef}
                className="overflow-y-auto"
                style={{ maxHeight: "600px" }}
              >
                {filteredSubstitutes.length > 0 ? (
                  activeView === "table" ? (
                    <div className="overflow-x-auto">
                      <SubstituteTable
                        products={filteredSubstitutes}
                        onDistributionCentersClick={handleDistributionCentersClick}
                        onRadioChange={handleSubstituteRadioChange}
                        selectedSubstituteId={Array.from(selectedSubstitutes)[0]}
                      />
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
                      {filteredSubstitutes.map((substitute) => (
                        <SubstituteCard
                          key={substitute.id}
                          product={substitute}
                          onDistributionCentersClick={handleDistributionCentersClick}
                          isChecked={selectedSubstitutes.has(substitute.id)}
                          onCheckboxChange={(checked) => handleSubstituteCheckboxChange(substitute.id, checked)}
                        />
                      ))}
                    </div>
                  )
                ) : (
                  <div className="text-center py-8 text-text-secondary">
                    {selectedContract
                      ? `No substitute materials found for contract "${selectedContract}".`
                      : "No substitute materials found."
                    }
                  </div>
                )}

                {isLoadingMoreMaterialSubstitutes && (
                  <div className="text-center py-4">
                    <LazyLoader />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row justify-end gap-4 py-6 px-6 border-t border-slate-200 mt-4">
            <Button
              variant="outline"
              onClick={handleCancel}
              className="px-6 py-2 w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button
              onClick={handleDone}
              disabled={selectedSubstitutes.size === 0}
              className="px-6 py-2 text-white w-full sm:w-auto"
              style={{
                backgroundColor: selectedSubstitutes.size === 0 ? '#9CA3AF' : 'var(--color-brand-600, #593AB1)',
                borderColor: selectedSubstitutes.size === 0 ? '#9CA3AF' : 'var(--color-brand-600, #593AB1)',
                cursor: selectedSubstitutes.size === 0 ? 'not-allowed' : 'pointer'
              }}
            >
              Done
            </Button>
          </div>
        </div>

        {selectedProduct && (
          <DistributionCentersModal
            isOpen={isDistributionModalOpen}
            onClose={handleCloseDistributionModal}
            materialName={materialData.name}
            vendorName={selectedProduct.vendor}
            substitutionId={selectedProduct.substituteId}
          />
        )}

        <KeepInMindModal
          isOpen={isKeepInMindModalOpen}
          onClose={handleKeepInMindClose}
          onContinue={handleKeepInMindContinue}
          isSubmitting={isSubmitting}
        />

        <DecisionRationaleModal
          isOpen={isDecisionRationaleModalOpen}
          onSubmit={handleDecisionRationaleSubmit}
          isSubmitting={isSubmittingRationale}
          actionType={actionType || undefined}
          actionLabel={potentialAction?.recommendation}
        />
      </DashboardLayout>
    </>
  );
}
