import { StratiumRoutedPageLayout } from "./layout/StratiumRoutedPageLayout";
import { OverviewPageContent } from "@/pages/OverviewPage";

export default function StratiumOverviewPage() {
  return (
    <StratiumRoutedPageLayout
      activePrimaryId="overview"
      pageName="Overview"
      pageSubtitle="Here’s what’s happening with your supply chain today"
    >
      <OverviewPageContent />
    </StratiumRoutedPageLayout>
  );
}
