import { StratiumRoutedPageLayout } from "./layout/StratiumRoutedPageLayout";
import { PlanPageContent } from "@/pages/Plan";

export default function StratiumPlanPage() {
  return (
    <StratiumRoutedPageLayout
      activePrimaryId="plan"
      pageName="Plan Module"
      pageSubtitle="Insights and recommended actions to mitigate unexpected events in supply chain operations."
    >
      <PlanPageContent />
    </StratiumRoutedPageLayout>
  );
}
