import { StratiumRoutedPageLayout } from "./layout/StratiumRoutedPageLayout";
import { ReactPageContent } from "@/pages/ReactPage";

export default function StratiumReactPage() {
  return (
    <StratiumRoutedPageLayout
      activePrimaryId="react"
      pageName="React Module"
      pageSubtitle="Insights and recommended actions to mitigate unexpected events in supply chain operations."
    >
      <ReactPageContent />
    </StratiumRoutedPageLayout>
  );
}
