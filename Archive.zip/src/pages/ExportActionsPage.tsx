import React, { useState, useEffect, useCallback } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Button } from '@/components/atoms/Button'
import { Input } from '@/components/atoms/Input'
import { Badge } from '@/components/atoms/Badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/atoms/Table'
import { Pagination } from '@/components/atoms/Pagination'
import DashboardLayout from '@/components/templates/DashboardLayout'
import { PageTitle } from '@/components/atoms/PageTitle'
import { InfoIcon } from '@/components/atoms'
import { userActionService, UserAction } from '@/lib/apiServices'
import { useAuth } from '@/contexts/AuthContext'
import { useUserActionsQuery, userActionsQueryKeys, buildDateParams } from '@/hooks/queries'
import useRemoveActionMutation from '@/hooks/queries/useRemoveActionMutation'
import { RemoveActionConfirmModal } from '@/components/molecules/RemoveActionConfirmModal'
import { MaterialAction } from '@/lib/types'
import { isMaterialActionOwner } from '@/lib/materialActionOwnership'
import Tooltip from '@/components/atoms/Tooltip'

export const ExportActionsPage: React.FC = () => {
  const { user } = useAuth()
  const queryClient = useQueryClient()
  const removeActionMutation = useRemoveActionMutation(null)
  const [exporting, setExporting] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [showRemoveModal, setShowRemoveModal] = useState(false)
  const [pendingRemoveAction, setPendingRemoveAction] = useState<UserAction | null>(null)
  const { actions, totalActions, isLoading, isFetching } = useUserActionsQuery({
    page: currentPage,
    pageSize,
    startDate,
    endDate,
  })

  const getTodayDate = () => {
    return new Date().toISOString().split('T')[0]
  }

  const getMaxDate = () => {
    return getTodayDate()
  }


  const getMinEndDate = () => {
    return startDate || undefined
  }

  const getMinStartDate = () => {
    return '2022-01-01'
  }


  const isDateRangeExceeds31Days = () => {
    if (startDate && endDate) {

      const start = new Date(startDate)
      const end = new Date(endDate)
      const diffTime = end.getTime() - start.getTime()
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      return diffDays > 31
    } else if (startDate && !endDate) {
      const start = new Date(startDate)
      const today = new Date()
      const diffTime = today.getTime() - start.getTime()
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      return diffDays > 31
    }
    return false
  }

  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newStartDate = e.target.value
    setStartDate(newStartDate)

    if (endDate && newStartDate && endDate < newStartDate) {
      setEndDate('')
    }
  }

  const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEndDate(e.target.value)
  }

  const clearDateFilters = () => {
    setStartDate('')
    setEndDate('')
  }

  const formatActionDate = (dateString: string): string => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true
    })
  }

  const getActionText = (action: UserAction): string => {
    if (action.substituted_material) {
      return `Manufacturer Switch`
    }
    if (action.potential_action) {
      return action.potential_action.recommendation
    }
    if (action.action === "no_action") {
      return `No Action Required`
    }
    return action.action_type || 'Action'
  }

  const getActionType = (action: UserAction): string => {
    if (action.substituted_material) {
      return 'Switch'
    }
    if (action.potential_action) {
      return action.potential_action.action_type
    }
    if (action.action === "no_action") {
      return 'No Action'
    }
    return action.action_type || 'Action'
  }

  useEffect(() => {
    if (startDate || endDate) {
      setCurrentPage(1)
    }
  }, [startDate, endDate])


  const handleExport = async () => {
    setExporting(true)
    try {
      let inclusiveStart: string
      let inclusiveEndLabel: string

      if (startDate && endDate) {
        inclusiveStart = startDate
        inclusiveEndLabel = endDate
      } else if (startDate) {
        inclusiveStart = startDate
        inclusiveEndLabel = new Date().toISOString().split('T')[0]
      } else {
        const today = new Date()
        const pastYear = new Date(today)
        pastYear.setFullYear(today.getFullYear() - 1)

        inclusiveStart = pastYear.toISOString().split('T')[0]
        inclusiveEndLabel = today.toISOString().split('T')[0]
      }

      const { createdAtAfter, createdAtBefore } = buildDateParams(
        inclusiveStart,
        startDate && !endDate ? '' : inclusiveEndLabel
      )
      if (!createdAtAfter || !createdAtBefore) {
        return
      }

      const response = await userActionService.exportUserActions(createdAtAfter, createdAtBefore)
      const blob = new Blob([response.data], { type: 'text/csv' })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `actions_${inclusiveStart}_to_${inclusiveEndLabel}.csv`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)

    } catch (error) {
      console.error('Error exporting user action log:', error)
    } finally {
      setExporting(false)
    }
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
  }


  const handlePageSizeChange = (size: number) => {
    setPageSize(size)
    setCurrentPage(1)
  }

  const canRemoveAction = useCallback(
    (action: UserAction) => isMaterialActionOwner(action, user?.entra_id),
    [user?.entra_id]
  )

  const handleRemoveClick = useCallback((action: UserAction) => {
    setPendingRemoveAction(action)
    setShowRemoveModal(true)
  }, [])

  const handleRemoveConfirm = () => {
    if (!pendingRemoveAction || removeActionMutation.isPending) return
    removeActionMutation.mutate(pendingRemoveAction.id, {
      onSuccess: () => {
        setShowRemoveModal(false)
        setPendingRemoveAction(null)
        queryClient.invalidateQueries({
          queryKey: userActionsQueryKeys.lists(),
        })
      },
    })
  }

  const handleRemoveClose = useCallback(() => {
    setShowRemoveModal(false)
    setPendingRemoveAction(null)
  }, [])

  const isButtonDisabled = exporting || isDateRangeExceeds31Days() || !startDate || !endDate

  return (
    <DashboardLayout
      pageTitle={<PageTitle title="Export your actions" />}
      pageSubtitle="View, filter, and export your action history by date range."
    >
      {/* User Action History Section */}
      <div className="bg-white rounded-lg border border-ui-border-primary shadow-xs">
        {/* Section Header */}
        <div className="px-4 sm:px-6 pt-6 pb-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              <div className="flex items-center space-x-2">
                <h2 className="text-ui-text-primary text-lg sm:text-xl font-bold">
                  User Action History
                </h2>
                <InfoIcon size={25} position="right" tooltip="View and export your user action history." />
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-ui-background-muted text-ui-text-primary w-fit">
                  {totalActions} Actions
                </Badge>
                {isFetching && (
                  <span className="text-xs text-ui-text-secondary">
                    Updating...
                  </span>
                )}
              </div>
            </div>
            <Tooltip content="A start date and end date are required to export actions. You can export with range not more than 31 days.">
              <Button
                onClick={handleExport}
                disabled={isButtonDisabled}
                className="bg-brand-primary-main hover:bg-brand-primary-dark text-white w-full sm:w-auto sm:max-w-[133px] h-8 text-sm font-bold disabled:opacity-50 disabled:cursor-not-allowed focus:outline-2 focus:outline-solid focus:outline-brand-primary-main focus:font-bold"
              >
                Export Actions
              </Button>
            </Tooltip>

          </div>
        </div>

        {/* Date Range Filter */}
        <div className="px-4 sm:px-6 py-4">
          <div className="flex flex-col space-y-4">
            <label className="text-sm font-medium text-ui-text-primary">
              Date Range
            </label>
            <div className="flex flex-col sm:flex-row sm:items-end gap-4">
              <div className="flex flex-col space-y-2">
                <label className="text-xs font-medium text-ui-text-secondary">
                  Start Date
                </label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={handleStartDateChange}
                  min={getMinStartDate()}
                  max={getMaxDate()}
                  className="w-full sm:w-48"
                />
              </div>
              <div className="flex flex-col space-y-2">
                <label className="text-xs font-medium text-ui-text-secondary">
                  End Date
                </label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={handleEndDateChange}
                  min={getMinEndDate()}
                  max={getMaxDate()}
                  className="w-full sm:w-48"
                />
              </div>
              {(startDate || endDate) && (
                <Button
                  onClick={clearDateFilters}
                  variant="outline"
                  size="sm"
                  className="h-8 px-3 text-xs w-full sm:w-auto"
                >
                  Clear Filters
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Actions Table */}
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="px-3 sm:px-6 py-2 text-left font-bold text-ui-text-primary">
                  <div className="flex items-center gap-2">
                    Action
                    <InfoIcon size={20} position="right" tooltip="The action performed by the user." />
                  </div>
                </TableHead>
                <TableHead className="px-3 sm:px-6 py-2 text-left font-bold text-ui-text-primary">
                  Type
                </TableHead>
                <TableHead className="px-3 sm:px-6 py-2 text-left font-bold text-ui-text-primary">
                  Material
                </TableHead>
                <TableHead className="px-3 sm:px-6 py-2 text-left font-bold text-ui-text-primary">
                  Date & Time
                </TableHead>
                <TableHead className="px-3 sm:px-6 py-2 text-left font-bold text-ui-text-primary">
                  Details
                </TableHead>
                <TableHead className="px-3 sm:px-6 py-2 text-left font-bold text-ui-text-primary min-w-[100px]">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading || (isFetching && actions.length === 0) ? (
                <TableRow style={{ height: '40px' }}>
                  <TableCell colSpan={6} className="px-3 sm:px-6 py-8 text-center text-sm text-ui-text-secondary">
                    Loading actions...
                  </TableCell>
                </TableRow>
              ) : actions.length === 0 ? (
                <TableRow style={{ height: '40px' }}>
                  <TableCell colSpan={6} className="px-3 sm:px-6 py-8 text-center text-sm text-ui-text-secondary">
                    No actions found
                  </TableCell>
                </TableRow>
              ) : (
                actions.map((action) => (
                  <TableRow key={action.id} style={{ height: '40px' }}>
                    <TableCell className="px-3 sm:px-6 py-2 text-sm font-medium text-ui-text-primary">
                      <div className="truncate max-w-[200px] sm:max-w-none">
                        {getActionText(action)}
                      </div>
                    </TableCell>
                    <TableCell className="px-3 sm:px-6 py-2">
                      <span
                        className="inline-flex items-center px-2 sm:px-3 py-1 text-xs sm:text-sm font-medium text-ui-text-primary"
                        style={{
                          borderRadius: 'var(--size-border-radius-full, 9999px)',
                          background: 'var(--color-background-tertiary, #E8E8E8)',
                          border: 'none'
                        }}
                      >
                        {getActionType(action)}
                      </span>
                    </TableCell>
                    <TableCell className="px-3 sm:px-6 py-2 text-sm text-ui-text-primary">
                      <div className="truncate max-w-[150px] sm:max-w-none">
                        {action.material_name}
                      </div>
                    </TableCell>
                    <TableCell className="px-3 sm:px-6 py-2 text-xs sm:text-sm text-ui-text-primary">
                      <div className="truncate max-w-[120px] sm:max-w-none">
                        {formatActionDate(action.created_at)}
                      </div>
                    </TableCell>
                    <TableCell className="px-3 sm:px-6 py-2 text-sm text-ui-text-primary">
                      <div className="truncate max-w-[150px] sm:max-w-none">
                        {action.substituted_material
                          ? `Switched to ${action.substituted_material.vendor_name}`
                          : action.potential_action?.recommendation || action.recommendation || 'Action performed'
                        }
                      </div>
                    </TableCell>
                    <TableCell className="px-3 sm:px-6 py-2">
                      {canRemoveAction(action) && (
                        <button
                          type="button"
                          onClick={() => handleRemoveClick(action)}
                          className="flex items-center gap-2 border-2 rounded px-2 py-1 transition-all duration-200 border-neutral-200 hover:border-brand-primary-main hover:bg-purple-50 cursor-pointer text-xs font-bold text-brand-primary-main"
                          aria-label={`Delete ${getActionText(action)} action`}
                        >
                          Delete Action
                        </button>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        <Pagination
          currentPage={currentPage}
          pageSize={pageSize}
          total={totalActions}
          onPageChange={handlePageChange}
          onPageSizeChange={handlePageSizeChange}
          itemName="Actions"
          showPageSizeSelect={true}
          className="border-t border-ui-border-primary"
        />
      </div>
      {showRemoveModal && <RemoveActionConfirmModal
        isOpen={showRemoveModal}
        onClose={handleRemoveClose}
        onConfirm={handleRemoveConfirm}
        actionDetails={pendingRemoveAction as MaterialAction | null}
        isSubmitting={removeActionMutation.isPending}
      />}
    </DashboardLayout>
  )
}

export default ExportActionsPage
