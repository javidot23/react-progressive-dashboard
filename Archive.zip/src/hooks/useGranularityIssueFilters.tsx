import { useState, useEffect, useCallback, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import {
  deserializeGranularityIssueFilters,
  mergeGranularityIssueFiltersIntoParams,
  type GranularityIssueFilters,
} from "@/lib/granularityIssueFilterUtils";

export const useGranularityIssueFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const searchParamsRef = useRef(searchParams);
  searchParamsRef.current = searchParams;

  const [filters, setFiltersState] = useState<GranularityIssueFilters>(() =>
    deserializeGranularityIssueFilters(searchParams)
  );

  const setFilters = useCallback((newFilters: GranularityIssueFilters) => {
    setFiltersState(newFilters);
    const params = mergeGranularityIssueFiltersIntoParams(searchParamsRef.current, newFilters);
    setSearchParams(params, { replace: true });
  }, [setSearchParams]);

  useEffect(() => {
    setFiltersState(deserializeGranularityIssueFilters(searchParams));
  }, [searchParams]);

  return {
    filters,
    setFilters,
  };
};
