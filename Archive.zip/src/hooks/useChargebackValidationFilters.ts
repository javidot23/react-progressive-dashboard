import { useState, useEffect, useCallback, useRef } from "react";
import { useSearchParams } from "react-router-dom";

const PREFIX = "cbv_";

const DEFAULT_FILTERS = {
  ordering: "-dm_post_date",
  rejection_reason: "",
} as const;

function serializeChargebackValidationFilters(filters: Record<string, unknown>): URLSearchParams {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "") {
      params.set(`${PREFIX}${key}`, value.toString());
    }
  });
  return params;
}

function deserializeChargebackValidationFilters(searchParams: URLSearchParams): Record<string, unknown> {
  const filters = { ...DEFAULT_FILTERS };
  for (const [key, value] of searchParams.entries()) {
    if (key.startsWith(PREFIX)) {
      const filterKey = key.slice(PREFIX.length);
      if (filterKey in filters) {
        (filters as Record<string, unknown>)[filterKey] = value;
      }
    }
  }
  return filters;
}

export function useChargebackValidationFilters() {
  const [searchParams, setSearchParams] = useSearchParams();
  const searchParamsRef = useRef(searchParams);
  searchParamsRef.current = searchParams;

  const [filters, setFiltersState] = useState<Record<string, unknown>>(() =>
    deserializeChargebackValidationFilters(searchParams)
  );

  const setFilters = useCallback(
    (newFilters: Record<string, unknown>) => {
      setFiltersState(newFilters);
      const params = new URLSearchParams(searchParamsRef.current);
      for (const key of [...params.keys()]) {
        if (key.startsWith(PREFIX)) params.delete(key);
      }
      const newParams = serializeChargebackValidationFilters(newFilters);
      newParams.forEach((value, key) => params.set(key, value));
      setSearchParams(params, { replace: true });
    },
    [setSearchParams]
  );

  useEffect(() => {
    setFiltersState(deserializeChargebackValidationFilters(searchParams));
  }, [searchParams]);

  return { filters, setFilters };
}
