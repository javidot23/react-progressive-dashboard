import { useQuery } from "@tanstack/react-query";
import { vendorListService, VendorListFilters } from "@/lib/apiServices";

export interface UseVendorListOptions {
  filters?: VendorListFilters;
  enabled?: boolean;
}

export const useVendorList = ({ filters = {}, enabled = true }: UseVendorListOptions = {}) => {
  return useQuery({
    queryKey: ["vendor", "list", filters],
    queryFn: async () => {
      const response = await vendorListService.getVendorList(filters);
      return response.data.data;
    },
    enabled,
  });
};
