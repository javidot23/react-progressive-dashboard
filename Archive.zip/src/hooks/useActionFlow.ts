import { useState, useCallback, useRef, useTransition } from "react";
import { useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { issuesQueryKeys, issueByIdQueryKeys, materialsQueryKeys, materialActionHistoryQueryKeys } from "@/hooks/queries";
import useRemoveActionMutation from "@/hooks/queries/useRemoveActionMutation";
import useActionMutation from "@/hooks/queries/useActionMutation";
import { ROUTES } from "@/constants/routes";
import { submitDecisionRationale } from "@/services/actionService";
import { incrementCompletedActionsCount, shouldShowDecisionRationaleModal } from "@/lib/actionTracking";
import { isMaterialActionOwner } from "@/lib/materialActionOwnership";
import { getErrorMessage } from "@/lib/getErrorMessage";
import { toast } from "@/lib/toast";
import { MaterialAction, MaterialWithIssues, PotentialAction } from "@/lib/types";
import { selectTenantPortalFlags, useTenantContextQuery } from "@/tenant";

// Constants
const NO_ACTION_TYPE = "no_action_required";
const SWITCH_MANUFACTURER_TYPE = "31";

type PendingActionToast = { title: string; description?: string };

// Discriminated union for modal state - single source of truth
type ModalState =
  | { type: "closed" }
  | { type: "keepInMind"; pendingAction: PendingAction }
  | { type: "decisionRationale"; actionId: number; actionType: string; actionLabel?: string }
  | { type: "removeConfirm"; action: MaterialAction };

interface PendingAction {
  type: string;
  potentialAction?: PotentialAction;
}

interface UseActionFlowParams {
  material: MaterialWithIssues;
  issueId?: number;
  issueNbr?: string;
  vendorId?: number;
}

export function useActionFlow({ material, issueId, issueNbr, vendorId }: UseActionFlowParams) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { data: flags } = useTenantContextQuery(selectTenantPortalFlags);
  const [modalState, setModalState] = useState<ModalState>({ type: "closed" });
  const [isSubmittingRationale, setIsSubmittingRationale] = useState(false);
  const [isPending, startTransition] = useTransition();
  const isProcessing = useRef(false);
  const pendingActionToastRef = useRef<PendingActionToast | null>(null);

  const actionMutation = useActionMutation(vendorId ?? null);
  const removeActionMutation = useRemoveActionMutation(vendorId ?? null);

  const invalidateQueries = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: issuesQueryKeys.all, refetchType: "active" });
    queryClient.invalidateQueries({ queryKey: issueByIdQueryKeys.all, refetchType: "active" });
    queryClient.invalidateQueries({
      queryKey: materialActionHistoryQueryKeys.all,
      refetchType: "active",
    });
    if (vendorId) {
      queryClient.invalidateQueries({ queryKey: materialsQueryKeys.byVendor(vendorId) });
    }
  }, [queryClient, vendorId]);

  // Close any modal
  const closeModal = useCallback(() => {
    if (!isSubmittingRationale) {
      if (modalState.type === "decisionRationale") {
        if (pendingActionToastRef.current) {
          toast.success(pendingActionToastRef.current);
          pendingActionToastRef.current = null;
        }
        invalidateQueries();
      }
      setModalState({ type: "closed" });
    }
  }, [isSubmittingRationale, modalState.type, invalidateQueries]);

  /** Shared path after Keep-in-Mind (or immediate "No action required") to POST the action. */
  const performActionCreation = useCallback(
    async (pendingAction: PendingAction) => {
      if (isProcessing.current || !issueNbr) {
        return;
      }

      isProcessing.current = true;

      try {
        const actionData = await actionMutation.mutateAsync({
          issueNbr,
          matNbr: material.mat_nbr,
          actionType: pendingAction.type,
          potentialActionNbr: pendingAction.potentialAction?.paction_nbr,
          materialRiskRating: material.risk_rating,
          materialDrivingRisk: material.driving_risk,
          materialDollarsAtRisk: material.dollars_at_risk,
          skipInvalidation: true,
        });

        const successPayload: PendingActionToast = {
          title: "Action applied",
          description:
            pendingAction.potentialAction?.recommendation?.trim() ||
            (pendingAction.type === NO_ACTION_TYPE ? "No action required was recorded." : "Your action was saved."),
        };

        let deferToast = false;
        if (actionData?.id) {
          const newCount = incrementCompletedActionsCount();
          deferToast = shouldShowDecisionRationaleModal(pendingAction.type, newCount);
        }

        if (deferToast && actionData?.id) {
          pendingActionToastRef.current = successPayload;
        } else {
          toast.success(successPayload);
        }

        startTransition(() => {
          if (actionData?.id) {
            if (deferToast) {
              setModalState({
                type: "decisionRationale",
                actionId: actionData.id,
                actionType: pendingAction.type,
                actionLabel: pendingAction.potentialAction?.recommendation,
              });
            } else {
              invalidateQueries();
              setModalState({ type: "closed" });
            }
          } else {
            invalidateQueries();
            setModalState({ type: "closed" });
          }
        });
      } catch (error) {
        console.error("Error creating action:", error);
        toast.error({
          title: "Couldn't apply action",
          description: getErrorMessage(error),
        });
        setModalState({ type: "closed" });
      } finally {
        isProcessing.current = false;
      }
    },
    [issueNbr, actionMutation, material, invalidateQueries]
  );

  // Handle action button click
  const handleActionClick = useCallback(
    (actionType: string, potentialAction?: PotentialAction) => {
      if (actionType === SWITCH_MANUFACTURER_TYPE && flags?.features.productSubstitutionAnalysis) {
        const params = new URLSearchParams({
          material_id: material.id.toString(),
          ...(issueId && { issue_id: issueId.toString() }),
          ...(issueNbr && { issue_nbr: issueNbr }),
          ...(potentialAction && { potential_action_nbr: potentialAction.paction_nbr }),
        });

        navigate(`${ROUTES.REACT_SUBSTITUTION}?${params.toString()}`, {
          state: {
            materialId: material.id,
            materialName: material.name,
            vendorName: material.vendor?.name,
            materialData: material,
            issueId,
            issueNbr,
            potentialAction,
          },
        });
        return;
      }

      if (actionType === NO_ACTION_TYPE) {
        void performActionCreation({ type: actionType, potentialAction });
        return;
      }

      setModalState({
        type: "keepInMind",
        pendingAction: { type: actionType, potentialAction },
      });
    },
    [flags?.features.productSubstitutionAnalysis, material, issueId, issueNbr, navigate, performActionCreation]
  );

  // Handle KeepInMind continue - creates the action
  const handleKeepInMindContinue = useCallback(async () => {
    if (modalState.type !== "keepInMind" || !issueNbr) {
      return;
    }

    await performActionCreation(modalState.pendingAction);
  }, [modalState, issueNbr, performActionCreation]);

  // Handle DecisionRationale submit
  const handleDecisionRationaleSubmit = useCallback(
    async (data: { time_to_complete: string; decision_rationale: string }) => {
      if (modalState.type !== "decisionRationale") return;

      setIsSubmittingRationale(true);
      try {
        await submitDecisionRationale(modalState.actionId, data);
        invalidateQueries();
        setModalState({ type: "closed" });
        const pending = pendingActionToastRef.current;
        pendingActionToastRef.current = null;
        toast.success({
          title: "Action applied",
          description: pending?.description != null ? `${pending.description} Rationale recorded.` : "Rationale recorded.",
        });
      } catch (error) {
        console.error("Error submitting decision rationale:", error);
        if (pendingActionToastRef.current) {
          toast.success(pendingActionToastRef.current);
          pendingActionToastRef.current = null;
        }
        toast.error({
          title: "Couldn't save decision rationale",
          description: getErrorMessage(error),
        });
        throw error;
      } finally {
        setIsSubmittingRationale(false);
      }
    },
    [modalState, invalidateQueries]
  );

  // Handle remove action click
  const handleRemoveClick = useCallback((action: MaterialAction) => {
    setModalState({ type: "removeConfirm", action });
  }, []);

  const handleRemoveConfirm = useCallback(() => {
    if (modalState.type !== "removeConfirm" || removeActionMutation.isPending) return;

    if (!isMaterialActionOwner(modalState.action, user?.entra_id)) {
      setModalState({ type: "closed" });
      return;
    }

    removeActionMutation.mutate(modalState.action.id, {
      onSuccess: () => {
        setModalState({ type: "closed" });
      },
    });
  }, [modalState, removeActionMutation, user?.entra_id]);

  return {
    // State
    modalState,
    isSubmittingRationale,
    isPending,
    isActionMutationPending: actionMutation.isPending,
    isRemoveMutationPending: removeActionMutation.isPending,

    // Actions
    handleActionClick,
    handleKeepInMindContinue,
    handleDecisionRationaleSubmit,
    handleRemoveClick,
    handleRemoveConfirm,
    closeModal,

    // Constants
    NO_ACTION_TYPE,
  };
}

export { NO_ACTION_TYPE, SWITCH_MANUFACTURER_TYPE };
export type { ModalState, PendingAction };
