import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { serializeIssueFilters, deserializeIssueFilters } from "@/lib/issueFilterUtils";

export const useIssueFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  // Initialize filters from URL parameters
  const [filters, setFiltersState] = useState(() => {
    return deserializeIssueFilters(searchParams);
  });

  // Custom setFilters function that updates both state and URL
  const setFilters = (newFilters: any) => {
    setFiltersState(newFilters);
    const params = serializeIssueFilters(newFilters);
    setSearchParams(params, { replace: true });
  };

  // Handle URL parameter changes (back/forward navigation)
  useEffect(() => {
    const newFilters = deserializeIssueFilters(searchParams);
    setFiltersState(newFilters);
  }, [searchParams]);

  return {
    filters,
    setFilters,
  };
};
