import { useCallback, useMemo, useState } from "react";
import { impactedMaterialsAppliedFiltersConfig } from "@/lib/filterConfigs";
import type { IssueImpactedMaterialApiData } from "@/types/granularityIssue";

const DEFAULT_MAT_FILTERS = impactedMaterialsAppliedFiltersConfig.defaultFilters;

/** True when matFilters differ from defaults (range keys set or non-default ordering). */
export function hasActiveImpactedMaterialFilters(matFilters: Record<string, unknown>): boolean {
  return Object.entries(DEFAULT_MAT_FILTERS).some(([key, defaultValue]) => {
    const current = matFilters[key];
    if (key === "ordering") {
      return current !== defaultValue;
    }
    return current !== null && current !== undefined && current !== "";
  });
}

interface UseImpactedMaterialSelectionParams {
  materials: IssueImpactedMaterialApiData[];
  /** Total from the impacted-materials query (filtered count when filters active). */
  materialsTotal: number;
  /** Issue-level impacted material count (whole grain). */
  impactedCount: number;
  matFilters: Record<string, unknown>;
}

export function useImpactedMaterialSelection({
  materials,
  materialsTotal,
  impactedCount,
  matFilters,
}: UseImpactedMaterialSelectionParams) {
  const [excludedMatNbrs, setExcludedMatNbrs] = useState<Set<string>>(() => new Set());

  const resetSelection = useCallback(() => {
    setExcludedMatNbrs(new Set());
  }, []);

  const hasActiveMatFilters = useMemo(
    () => hasActiveImpactedMaterialFilters(matFilters),
    [matFilters]
  );

  const actionScopeTotal = hasActiveMatFilters ? materialsTotal : impactedCount;
  const selectedCount = Math.max(0, actionScopeTotal - excludedMatNbrs.size);
  const grainExcludedCount = Math.max(0, actionScopeTotal - selectedCount);
  const applyToWholeGrain = !hasActiveMatFilters && excludedMatNbrs.size === 0;

  const isSelected = useCallback(
    (matNbr: string) => !excludedMatNbrs.has(matNbr),
    [excludedMatNbrs]
  );

  const toggle = useCallback((matNbr: string) => {
    setExcludedMatNbrs(prev => {
      const next = new Set(prev);
      if (next.has(matNbr)) next.delete(matNbr);
      else next.add(matNbr);
      return next;
    });
  }, []);

  const toggleAllVisible = useCallback((visibleMaterials: IssueImpactedMaterialApiData[]) => {
    const visibleNbrs = visibleMaterials.map(m => m.mat_nbr);
    const allVisibleSelected =
      visibleNbrs.length > 0 && visibleNbrs.every(nbr => !excludedMatNbrs.has(nbr));

    setExcludedMatNbrs(prev => {
      const next = new Set(prev);
      if (allVisibleSelected) {
        visibleNbrs.forEach(nbr => next.add(nbr));
      } else {
        visibleNbrs.forEach(nbr => next.delete(nbr));
      }
      return next;
    });
  }, [excludedMatNbrs]);

  const selectedOnPageCount = useMemo(
    () => materials.filter(m => !excludedMatNbrs.has(m.mat_nbr)).length,
    [materials, excludedMatNbrs]
  );

  const selectedMaterialRows = useMemo(
    () => materials.filter(m => !excludedMatNbrs.has(m.mat_nbr)),
    [materials, excludedMatNbrs]
  );

  const allVisibleSelected =
    materials.length > 0 && materials.every(m => !excludedMatNbrs.has(m.mat_nbr));

  return {
    excludedMatNbrs,
    resetSelection,
    hasActiveMatFilters,
    actionScopeTotal,
    selectedCount,
    grainExcludedCount,
    applyToWholeGrain,
    isSelected,
    toggle,
    toggleAllVisible,
    selectedOnPageCount,
    selectedMaterialRows,
    allVisibleSelected,
  };
}
