import { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "react-router-dom";

const PREFIX = "pofs_";

const DEFAULT_FILTERS = {
  ordering: "-total_failed_scans",
  total_failed_scans_min: null as number | null,
  total_failed_scans_max: null as number | null,
  sgtin_not_found_errors_min: null as number | null,
  sgtin_not_found_errors_max: null as number | null,
  lot_errors_min: null as number | null,
  lot_errors_max: null as number | null,
  expiration_errors_min: null as number | null,
  expiration_errors_max: null as number | null,
};

function serializePurchaseOrdersFailedScansFilters(filters: Record<string, unknown>): URLSearchParams {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "") {
      params.set(`${PREFIX}${key}`, value.toString());
    }
  });
  return params;
}

function deserializePurchaseOrdersFailedScansFilters(searchParams: URLSearchParams): Record<string, unknown> {
  const filters = { ...DEFAULT_FILTERS };
  for (const [key, value] of searchParams.entries()) {
    if (key.startsWith(PREFIX)) {
      const filterKey = key.slice(PREFIX.length);
      if (filterKey in filters) {
        if (filterKey === "ordering") {
          (filters as Record<string, unknown>)[filterKey] = value;
        } else {
          const numValue = Number(value);
          if (!Number.isNaN(numValue)) {
            (filters as Record<string, unknown>)[filterKey] = numValue;
          }
        }
      }
    }
  }
  return filters;
}

export function usePurchaseOrdersFailedScansFilters() {
  const [searchParams, setSearchParams] = useSearchParams();

  const [filters, setFiltersState] = useState<Record<string, unknown>>(() =>
    deserializePurchaseOrdersFailedScansFilters(searchParams)
  );

  const setFilters = useCallback(
    (newFilters: Record<string, unknown>) => {
      setFiltersState(newFilters);
      const params = new URLSearchParams(searchParams);
      for (const key of [...params.keys()]) {
        if (key.startsWith(PREFIX)) params.delete(key);
      }
      const newParams = serializePurchaseOrdersFailedScansFilters(newFilters);
      newParams.forEach((value, key) => params.set(key, value));
      setSearchParams(params, { replace: true });
    },
    [searchParams, setSearchParams]
  );

  useEffect(() => {
    setFiltersState(deserializePurchaseOrdersFailedScansFilters(searchParams));
  }, [searchParams]);

  return { filters, setFilters };
}
