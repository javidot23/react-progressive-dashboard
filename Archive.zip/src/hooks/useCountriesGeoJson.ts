import { useState, useEffect } from "react";
import type { GeoJsonObject } from "geojson";

export function useCountriesGeoJson() {
  const [data, setData] = useState<GeoJsonObject | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    import("@/public/data/global-states.json")
      .then(module => {
        if (!cancelled) setData(module.default as GeoJsonObject);
      })
      .catch(err => {
        if (!cancelled) setError(err);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return { data, loading, error };
}
