import { useMemo, useCallback } from 'react'
import { colors, getColor, getCSSVar } from '@/lib/colors'
import {
  chartColorSystem,
  getSeriesColors,
  mapSeriesColors,
  resolveSeriesColor,
  type ChartPaletteName,
  type GetSeriesColorsOptions,
} from '@/lib/chartColors'


export function useColors() {
  const colorPalette = useMemo(() => colors, [])

  const getColorValue = useCallback((path: string): string => {
    return getColor(path)
  }, [])

  const getCSSVariable = useCallback((path: string): string => {
    return getCSSVar(path)
  }, [])

  const themeColor = useCallback((
    colorPath: string,
    variant: 'main' | 'light' | 'dark' = 'main'
  ): string => {
    const fullPath = colorPath.includes('.') ? colorPath : `${colorPath}.${variant}`
    return getColor(fullPath)
  }, [])

  const getColorStyles = useCallback((styles: Record<string, string>) => {
    const resolvedStyles: Record<string, string> = {}

    Object.entries(styles).forEach(([property, colorPath]) => {
      if (typeof colorPath === 'string' && colorPath.includes('.')) {
        resolvedStyles[property] = getColor(colorPath)
      } else {
        resolvedStyles[property] = colorPath
      }
    })

    return resolvedStyles
  }, [])

  const statusColors = useMemo(() => ({
    success: {
      main: colorPalette.status.success.main,
      light: colorPalette.status.success.light,
      dark: colorPalette.status.success.dark,
      bright: colorPalette.status.success.bright,
    },
    warning: {
      main: colorPalette.status.warning.main,
      light: colorPalette.status.warning.light,
      dark: colorPalette.status.warning.dark,
      accent: colorPalette.status.warning.accent,
    },
    error: {
      main: colorPalette.status.error.main,
      light: colorPalette.status.error.light,
      dark: colorPalette.status.error.dark,
      text: colorPalette.status.error.text,
    },
    info: {
      main: colorPalette.status.info.main,
      light: colorPalette.status.info.light,
      dark: colorPalette.status.info.dark,
      accent: colorPalette.status.info.accent,
      border: colorPalette.status.info.border,
      surface: colorPalette.status.info.surface,
    },
  }), [colorPalette])

  const brandColors = useMemo(() => ({
    primary: {
      main: colorPalette.brand.primary.main,
      light: colorPalette.brand.primary.light,
      dark: colorPalette.brand.primary.dark,
      surface: colorPalette.brand.primary.surface,
    },
    secondary: {
      main: colorPalette.brand.secondary.main,
      light: colorPalette.brand.secondary.light,
      dark: colorPalette.brand.secondary.dark,
    },
  }), [colorPalette])

  const chartColors = useMemo(() => ({
    risk: colorPalette.chart.risk,
    data: colorPalette.chart.data,
    geography: colorPalette.chart.geography,
    /** Shared CSS-variable chart system (palettes, semantic, series helpers). */
    system: chartColorSystem,
  }), [colorPalette])

  const uiColors = useMemo(() => ({
    text: colorPalette.ui.text,
    background: colorPalette.ui.background,
    border: colorPalette.ui.border,
    interactive: colorPalette.ui.interactive,
  }), [colorPalette])

  const componentColors = useMemo(() => ({
    status: colorPalette.component.status,
    riskBadge: colorPalette.component.riskBadge,
  }), [colorPalette])

  const getRiskColor = useCallback((level: 'critical' | 'high' | 'medium' | 'low'): string => {
    return colorPalette.chart.risk[level] || colorPalette.chart.risk.medium
  }, [colorPalette])

  const getStatusColor = useCallback((status: 'success' | 'warning' | 'error' | 'info'): string => {
    return colorPalette.status[status]?.main || colorPalette.status.info.main
  }, [colorPalette])

  const getTailwindClass = useCallback((
    type: 'bg' | 'text' | 'border',
    colorPath: string
  ): string => {
    const twPath = colorPath.replace(/\./g, '-')
    return `${type}-${twPath}`
  }, [])

  return {
    colors: colorPalette,

    getColor: getColorValue,
    getCSSVar: getCSSVariable,
    getColorStyles,
    themeColor,

    status: statusColors,
    brand: brandColors,
    chart: chartColors,
    ui: uiColors,
    component: componentColors,

    getRiskColor,
    getStatusColor,
    getTailwindClass,

    primary: brandColors.primary.main,
    secondary: brandColors.secondary.main,
    success: statusColors.success.main,
    warning: statusColors.warning.main,
    error: statusColors.error.main,
    info: statusColors.info.main,
  }
}

export function useBrandColors() {
  const { brand } = useColors()
  return brand
}

export function useStatusColors() {
  const { status } = useColors()
  return status
}

export function useChartColors() {
  const { chart } = useColors()

  const getSeries = useCallback(
    (count: number, options?: GetSeriesColorsOptions) => getSeriesColors(count, options),
    []
  )

  const mapSeries = useCallback(
    (seriesKeys: string[], options?: Omit<GetSeriesColorsOptions, 'seriesKeys'>) =>
      mapSeriesColors(seriesKeys, options),
    []
  )

  const resolveSeries = useCallback(
    (index: number, palette?: ChartPaletteName | readonly string[], override?: string) =>
      resolveSeriesColor(index, palette, override),
    []
  )

  return {
    ...chart,
    system: chartColorSystem,
    getSeriesColors: getSeries,
    mapSeriesColors: mapSeries,
    resolveSeriesColor: resolveSeries,
  }
}

export function useUIColors() {
  const { ui } = useColors()
  return ui
}


export type UseColorsReturn = ReturnType<typeof useColors>
