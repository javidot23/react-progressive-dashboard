import { useEffect, useRef } from "react";
import { useGlobalFiltersStore } from "@/stores/slices/globalFilters";

/**
 * Hook that components can use to listen to global filter changes
 * and trigger their own data refetches when global filters change
 */
export function useGlobalFiltersListener(onGlobalFiltersChange: () => void) {
  const { version } = useGlobalFiltersStore();
  const lastVersionRef = useRef(version);

  useEffect(() => {
    // Only trigger callback if version actually changed (not on initial mount)
    if (lastVersionRef.current !== version) {
      lastVersionRef.current = version;
      onGlobalFiltersChange();
    }
  }, [version, onGlobalFiltersChange]);
}

/**
 * Hook that returns the current global filters version
 * Components can use this in their useEffect dependencies to refetch data
 */
export function useGlobalFiltersVersion() {
  const { version } = useGlobalFiltersStore();
  return version;
}
