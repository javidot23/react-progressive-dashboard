import { useState, useEffect, useCallback } from "react";
import { getGcnDescriptionLabel, getGcnNumberLabel, getMaterialInGcnLabel } from "@/lib/gcnLabels";
import { getDefaultIssueFeedColumns, type IssueFeedTableScope } from "@/lib/issueTableConfig";
import { TableColumn } from "@/components/molecules/ReorderTableModal";

const TABLE_COLUMNS_STORAGE_KEY = "stratium:tableColumns";

export type TableColumnsViewScope = "material" | "gcn" | "product" | IssueFeedTableScope;

// Legacy Plan vendor table presets (VendorTableView renders its own headers).
const getDefaultMaterialColumns = (): TableColumn[] => [
  { id: "material_name", label: "Material Name", visible: true, locked: true },
  { id: "material_id", label: "Material ID", visible: true, locked: true },
  { id: "vendor_name", label: "Vendor", visible: true },
  { id: "vendor_nbr", label: "Vendor Id", visible: true },
  { id: "ndc", label: "NDC", visible: true },
  { id: "material_status", label: "Material Status", visible: true },
  { id: "risk_score", label: "Risk Score", visible: true },
  { id: "primary_risk", label: "Driving Risk", visible: true },
  { id: "risk_adjusted_value", label: "Risk Adjusted Value", visible: true },
  { id: "created_date", label: "Created Date", visible: true },
  { id: "action_status", label: "Action Status", visible: true },
  { id: "notes", label: "Notes", visible: true },
  { id: "recommended_actions", label: "Recommended Actions", visible: true },
];

const getDefaultGcnColumns = (): TableColumn[] => [
  { id: "gcn_number", label: getGcnNumberLabel(), visible: true },
  { id: "gcn_description", label: getGcnDescriptionLabel(), visible: true },
  { id: "material_in_gcn", label: getMaterialInGcnLabel(), visible: true },
  { id: "category", label: "Category", visible: false },
  { id: "risk_score", label: "Risk Score", visible: true },
  { id: "primary_risk", label: "Driving Risk", visible: true },
  { id: "created_date", label: "Created Date", visible: true },
  { id: "action_status", label: "Action Status", visible: true },
  { id: "notes", label: "Notes", visible: true },
  { id: "recommended_actions", label: "Recommended Actions", visible: true },
];

function resolveDefaultColumns(viewScope: TableColumnsViewScope): TableColumn[] {
  if (viewScope === "aggregated" || viewScope === "mixed") {
    return getDefaultIssueFeedColumns(viewScope);
  }
  if (viewScope === "material") {
    return getDefaultIssueFeedColumns("material");
  }
  if (viewScope === "gcn") {
    return getDefaultGcnColumns();
  }
  return getDefaultMaterialColumns();
}

export const useTableColumns = (viewScope: TableColumnsViewScope = "material") => {
  const getDefaultColumns = useCallback(() => resolveDefaultColumns(viewScope), [viewScope]);

  const [columns, setColumns] = useState<TableColumn[]>(getDefaultColumns());

  useEffect(() => {
    try {
      const saved = localStorage.getItem(`${TABLE_COLUMNS_STORAGE_KEY}:${viewScope}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        const defaults = getDefaultColumns();
        const merged = defaults.map(defaultCol => {
          const savedCol = parsed.find((c: TableColumn) => c.id === defaultCol.id);
          return savedCol ? { ...defaultCol, ...savedCol, locked: defaultCol.locked } : defaultCol;
        });
        parsed.forEach((savedCol: TableColumn) => {
          if (!merged.find(c => c.id === savedCol.id)) {
            merged.push(savedCol);
          }
        });
        setColumns(merged);
      } else {
        setColumns(getDefaultColumns());
      }
    } catch (error) {
      console.error("Failed to load table columns:", error);
      setColumns(getDefaultColumns());
    }
  }, [viewScope, getDefaultColumns]);

  const saveColumns = useCallback(
    (newColumns: TableColumn[]) => {
      setColumns(newColumns);
      try {
        localStorage.setItem(`${TABLE_COLUMNS_STORAGE_KEY}:${viewScope}`, JSON.stringify(newColumns));
      } catch (error) {
        console.error("Failed to save table columns:", error);
      }
    },
    [viewScope]
  );

  const resetColumns = useCallback(() => {
    const defaults = getDefaultColumns();
    setColumns(defaults);
    try {
      localStorage.setItem(`${TABLE_COLUMNS_STORAGE_KEY}:${viewScope}`, JSON.stringify(defaults));
    } catch (error) {
      console.error("Failed to reset table columns:", error);
    }
  }, [viewScope, getDefaultColumns]);

  return {
    columns,
    saveColumns,
    resetColumns,
  };
};
