import {useEffect, useState} from "react";

export const useLayoutStabilization = () => {
  const [isStable, setIsStable] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let timeoutId: ReturnType<typeof setTimeout> | undefined;

    document.body.classList.add("page-loading");

    const handleLoad = () => {
      timeoutId = setTimeout(() => {
        if (cancelled) return;
        document.body.classList.remove("page-loading");
        setIsStable(true);
      }, 100);
    };

    if (document.readyState === "complete") {
      handleLoad();
    } else {
      window.addEventListener("load", handleLoad);
    }

    return () => {
      cancelled = true;
      if (timeoutId !== undefined) {
        clearTimeout(timeoutId);
      }
      window.removeEventListener("load", handleLoad);
      document.body.classList.remove("page-loading");
    };
  }, []);

  return {isStable};
};
