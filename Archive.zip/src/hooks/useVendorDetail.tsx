import { useState, useEffect } from 'react';
import { vendorsService } from '@/lib/apiServices';
import type { VendorDetail } from '@/lib/apiServices';

interface UseVendorDetailParams {
  vendorId: number;
}

interface UseVendorDetailReturn {
  vendor: VendorDetail | null;
  loading: boolean;
  error: string | null;
}

export function useVendorDetail({
  vendorId
}: UseVendorDetailParams): UseVendorDetailReturn {
  const [vendor, setVendor] = useState<VendorDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchVendor = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await vendorsService.getVendorById(vendorId);

        if (response.data.success) {
          setVendor(response.data.data);
        } else {
          setError('Failed to fetch vendor details');
        }
      } catch (err) {
        console.warn('Could not fetch vendor details:', err);
        // Don't set error - just use fallback data
        setVendor(null);
      } finally {
        setLoading(false);
      }
    };

    if (vendorId && vendorId > 0) {
      fetchVendor();
    } else {
      setLoading(false);
    }
  }, [vendorId]);

  return {
    vendor,
    loading,
    error
  };
}
