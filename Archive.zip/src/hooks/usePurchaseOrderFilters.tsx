import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { serializePurchaseOrderFilters, deserializePurchaseOrderFilters } from "@/lib/purchaseOrderFilterUtils";

export const usePurchaseOrderFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  // Initialize filters from URL parameters
  const [filters, setFiltersState] = useState(() => {
    return deserializePurchaseOrderFilters(searchParams);
  });

  // Custom setFilters function that updates both state and URL
  const setFilters = (newFilters: any) => {
    setFiltersState(newFilters);

    // Get current URL params and only update Purchase Order related params
    const currentParams = new URLSearchParams(searchParams);
    const newParams = serializePurchaseOrderFilters(newFilters);

    // Remove existing Purchase Order filter params
    const poFilterKeys = [
      'ordering', 'units_ordered_min', 'units_ordered_max',
      'units_received_on_time_min', 'units_received_on_time_max',
      'units_received_late_min', 'units_received_late_max',
      'units_not_received_min', 'units_not_received_max',
      'inbound_fill_rate_min', 'inbound_fill_rate_max'
    ];

    poFilterKeys.forEach(key => currentParams.delete(key));

    // Add new Purchase Order filter params
    newParams.forEach((value, key) => {
      currentParams.set(key, value);
    });

    setSearchParams(currentParams, { replace: true });
  };

  // Handle URL parameter changes (back/forward navigation)
  useEffect(() => {
    const newFilters = deserializePurchaseOrderFilters(searchParams);
    setFiltersState(newFilters);
  }, [searchParams]);

  return {
    filters,
    setFilters,
  };
};
