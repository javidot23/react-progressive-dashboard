import { useState, useEffect } from "react";
import { getDataUpdateHistory, DataUpdateHistoryItem } from "@/services/dataUpdateHistoryService";

export const useDataUpdateHistory = () => {
  const [data, setData] = useState<DataUpdateHistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const result = await getDataUpdateHistory();
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err : new Error("Failed to fetch data update history"));
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  return { data, isLoading, error };
};
