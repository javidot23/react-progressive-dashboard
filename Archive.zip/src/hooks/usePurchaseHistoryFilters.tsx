import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { serializePurchaseHistoryFilters, deserializePurchaseHistoryFilters } from "@/lib/purchaseOrderFilterUtils";

export const usePurchaseHistoryFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  // Initialize filters from URL parameters
  const [filters, setFiltersState] = useState(() => {
    return deserializePurchaseHistoryFilters(searchParams);
  });

  // Custom setFilters function that updates both state and URL
  const setFilters = (newFilters: any) => {
    setFiltersState(newFilters);

    // Get current URL params and only update Purchase History related params
    const currentParams = new URLSearchParams(searchParams);
    const newParams = serializePurchaseHistoryFilters(newFilters);

    // Remove existing Purchase History filter params
    const phFilterKeys = [
      'material_id', 'original_order_qty_min', 'original_order_qty_max',
      'received_qty_min', 'received_qty_max',
      'units_received_on_time_min', 'units_received_on_time_max',
      'units_received_late_min', 'units_received_late_max',
      'units_not_received_min', 'units_not_received_max'
    ];

    phFilterKeys.forEach(key => currentParams.delete(key));

    // Add new Purchase History filter params
    newParams.forEach((value, key) => {
      currentParams.set(key, value);
    });

    setSearchParams(currentParams, { replace: true });
  };

  // Handle URL parameter changes (back/forward navigation)
  useEffect(() => {
    const newFilters = deserializePurchaseHistoryFilters(searchParams);
    setFiltersState(newFilters);
  }, [searchParams]);

  return {
    filters,
    setFilters,
  };
};
