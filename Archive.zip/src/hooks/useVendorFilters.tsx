import { useCallback, useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { serializeFilters, deserializeFilters } from "@/lib/vendorUtils";

export const useVendorFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  // Initialize filters from URL parameters
  const [filters, setFiltersState] = useState(() => {
    return deserializeFilters(searchParams);
  });

  const setFilters = useCallback(
    (newFilters: Record<string, unknown>) => {
      setFiltersState(newFilters);
      const params = serializeFilters(newFilters);
      setSearchParams(params, { replace: true });
    },
    [setSearchParams]
  );

  // Handle URL parameter changes (back/forward navigation)
  useEffect(() => {
    const newFilters = deserializeFilters(searchParams);
    setFiltersState(newFilters);
  }, [searchParams]);

  return {
    filters,
    setFilters,
  };
};
