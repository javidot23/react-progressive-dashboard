import { useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useActionMutation } from "@/hooks/queries/useActionMutation";
import { getErrorMessage } from "@/lib/getErrorMessage";
import { toast } from "@/lib/toast";
import { PotentialAction } from "@/lib/types";

const NO_ACTION_TYPE = "no_action_required";
const SWITCH_MANUFACTURER_TYPE = "31";

/** A currently-selected impacted material (subset of the impacted-materials rows). */
export interface SelectedActionMaterial {
  id: number;
  mat_nbr: string;
  name?: string;
  vendorName?: string;
  riskRating?: number;
  drivingRisk?: string;
  dollarsAtRisk?: number;
}

type ModalState =
  | { type: "closed" }
  | { type: "keepInMind"; actionType: string; potentialAction?: PotentialAction };

interface UseIssueActionFlowParams {
  issueId?: number;
  issueNbr?: string;
  /** Materials on the current page that are selected (for substitution + display). */
  selectedMaterials: SelectedActionMaterial[];
  /** True when nothing is excluded and no mat filters — omit mat_nbrs for whole grain. */
  applyToWholeGrain: boolean;
  /** Count of materials the action applies to (grain or filtered scope). */
  selectedCount: number;
  /** Total in action scope — used for the summary toast when applying to whole grain. */
  totalCount: number;
  vendorId?: number;
  /** Aggregate context recorded on the created action(s). */
  aggregate?: { riskRating?: number; drivingRisk?: string; dollarsAtRisk?: number };
  /** Resolve explicit mat_nbrs when applyToWholeGrain is false (may fetch unloaded pages). */
  resolveMatNbrs?: () => Promise<string[]>;
  /** Called after an action is successfully recorded (clears sticky-bar selection). */
  onActionApplied?: () => void;
}

/**
 * Issue-level (multi-material) action flow. Parallel to the single-material
 * `useActionFlow`: applies a chosen action to the selected impacted materials
 * (or ALL, by omitting mat_nbrs). Bulk creates get a summary toast rather than
 * the per-action decision-rationale modal.
 */
export function useIssueActionFlow({
  issueId,
  issueNbr,
  selectedMaterials,
  applyToWholeGrain,
  selectedCount,
  totalCount,
  vendorId,
  aggregate,
  resolveMatNbrs,
  onActionApplied,
}: UseIssueActionFlowParams) {
  const navigate = useNavigate();
  const [modalState, setModalState] = useState<ModalState>({ type: "closed" });
  const isProcessing = useRef(false);

  const actionMutation = useActionMutation(vendorId ?? null);

  const closeModal = useCallback(() => setModalState({ type: "closed" }), []);

  const performActionCreation = useCallback(
    async (actionType: string, potentialAction?: PotentialAction) => {
      if (isProcessing.current || !issueNbr) return;
      if (!applyToWholeGrain && selectedCount === 0) return;

      isProcessing.current = true;

      try {
        let matNbrs: string[] | undefined;
        if (applyToWholeGrain) {
          matNbrs = undefined;
        } else if (resolveMatNbrs) {
          matNbrs = await resolveMatNbrs();
        } else {
          matNbrs = selectedMaterials.map(m => m.mat_nbr);
        }

        if (!applyToWholeGrain && (!matNbrs || matNbrs.length === 0)) {
          return;
        }

        const response = await actionMutation.mutateAsync({
          issueNbr,
          matNbrs,
          actionType,
          potentialActionNbr: potentialAction?.paction_nbr,
          materialRiskRating: aggregate?.riskRating,
          materialDrivingRisk: aggregate?.drivingRisk,
          materialDollarsAtRisk: aggregate?.dollarsAtRisk,
        });

        const createdCount = Array.isArray(response?.created)
          ? response.created.length
          : applyToWholeGrain
            ? totalCount
            : matNbrs?.length ?? selectedCount;
        const skippedCount = Array.isArray(response?.skipped) ? response.skipped.length : 0;

        toast.success({
          title: "Action applied",
          description:
            (potentialAction?.recommendation?.trim() || "Action recorded") +
            ` — applied to ${createdCount} material${createdCount === 1 ? "" : "s"}` +
            (skippedCount ? `, ${skippedCount} skipped` : "") +
            ".",
        });
        onActionApplied?.();
        setModalState({ type: "closed" });
      } catch (error) {
        console.error("Error creating issue action:", error);
        toast.error({ title: "Couldn't apply action", description: getErrorMessage(error) });
        setModalState({ type: "closed" });
      } finally {
        isProcessing.current = false;
      }
    },
    [
      issueNbr,
      selectedMaterials,
      applyToWholeGrain,
      selectedCount,
      totalCount,
      actionMutation,
      aggregate,
      resolveMatNbrs,
      onActionApplied,
    ]
  );

  const handleActionClick = useCallback(
    (actionType: string, potentialAction?: PotentialAction) => {
      // Substitution leaves the page; it needs a single material.
      if (actionType === SWITCH_MANUFACTURER_TYPE) {
        if (selectedMaterials.length !== 1) return; // guarded by the sticky bar
        const material = selectedMaterials[0];
        const params = new URLSearchParams({
          material_id: String(material.id),
          ...(issueId && { issue_id: String(issueId) }),
          ...(issueNbr && { issue_nbr: issueNbr }),
          ...(potentialAction && { potential_action_nbr: potentialAction.paction_nbr }),
        });
        navigate(`/react/substitution-analysis?${params.toString()}`, {
          state: {
            materialId: material.id,
            materialName: material.name,
            vendorName: material.vendorName,
            issueId,
            issueNbr,
            potentialAction,
          },
        });
        return;
      }

      if (actionType === NO_ACTION_TYPE) {
        void performActionCreation(actionType, potentialAction);
        return;
      }

      setModalState({ type: "keepInMind", actionType, potentialAction });
    },
    [selectedMaterials, issueId, issueNbr, navigate, performActionCreation]
  );

  const handleKeepInMindContinue = useCallback(() => {
    if (modalState.type !== "keepInMind") return;
    void performActionCreation(modalState.actionType, modalState.potentialAction);
  }, [modalState, performActionCreation]);

  return {
    modalState,
    isActionMutationPending: actionMutation.isPending,
    applyToWholeGrain,
    handleActionClick,
    handleKeepInMindContinue,
    closeModal,
    NO_ACTION_TYPE,
    SWITCH_MANUFACTURER_TYPE,
  };
}

export { NO_ACTION_TYPE, SWITCH_MANUFACTURER_TYPE };
export type { ModalState as IssueActionModalState };
