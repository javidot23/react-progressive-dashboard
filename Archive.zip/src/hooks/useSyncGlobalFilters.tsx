import { useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useGlobalFiltersStore, GlobalFiltersState, isMultiFilter } from "@/stores/slices/globalFilters";
import { useQueryClient } from "@tanstack/react-query";
import { getCurrentMode } from "@/lib/globalFiltersInterceptor";
import { toWafSafeQueryString } from "@/lib/queryStringUtils";

const LS_KEY = "global_filters";
const GF_PREFIX = "gf_";

/**
 * Parse global filters from URL query params (gf_* keys).
 * Supports multiple values per key (e.g. gf_supplier=1&gf_supplier=2).
 */
function parseFiltersFromUrl(search: string): GlobalFiltersState {
  const params = new URLSearchParams(search);
  const filters: GlobalFiltersState = {};
  const lsFilters = getFiltersFromLS();
  const gfKeys = [...new Set([...params.keys()].filter(k => k.startsWith(GF_PREFIX)))];

  gfKeys.forEach(key => {
    const values = params.getAll(key);
    if (values.length === 0) return;
    if (values.length === 1) {
      const cached = lsFilters[key];
      const label = cached && !isMultiFilter(cached) && cached.label ? cached.label : values[0];
      filters[key] = { id: values[0], label };
    } else {
      const labels = values.map(id => {
        const cached = lsFilters[key];
        if (cached && isMultiFilter(cached)) {
          const idx = cached.ids.indexOf(id);
          return idx >= 0 ? cached.labels[idx] : id;
        }
        return id;
      });
      filters[key] = { ids: values, labels };
    }
  });

  return filters;
}

/**
 * Serialize filters to URL query string.
 */
function serializeFiltersToUrl(filters: GlobalFiltersState, currentSearch: string): string {
  const params = new URLSearchParams(currentSearch);

  const keysToDelete: string[] = [];
  params.forEach((_, key) => {
    if (key.startsWith(GF_PREFIX)) keysToDelete.push(key);
  });
  keysToDelete.forEach(key => params.delete(key));

  Object.entries(filters).forEach(([key, value]) => {
    if (!key.startsWith(GF_PREFIX)) return;
    if (isMultiFilter(value)) {
      value.ids.forEach(id => params.append(key, id));
    } else if (value && typeof value === "object" && "id" in value && value.id) {
      params.set(key, String(value.id));
    }
  });

  return toWafSafeQueryString(params);
}

/**
 * Read filters from localStorage
 */
function getFiltersFromLS(): GlobalFiltersState {
  try {
    const stored = localStorage.getItem(LS_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch (e) {
    console.warn("[Global Filters] Failed to parse localStorage:", e);
    return {};
  }
}

function shouldInvalidateOnGlobalFilterChange(queryKey: readonly unknown[]): boolean {
  if (!Array.isArray(queryKey)) return false;
  if (queryKey.includes("filter-source")) return false;

  if (queryKey.some(part => typeof part === "object" && part !== null && "globalFiltersVersion" in part)) {
    return true;
  }

  const rootKey = queryKey[0];
  return rootKey === "main-kpi" || rootKey === "manage-dashboard" || rootKey === "issues";
}

/**
 * Write filters to localStorage
 */
function saveFiltersToLS(filters: GlobalFiltersState): void {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(filters));
  } catch (e) {
    console.warn("[Global Filters] Failed to write to localStorage:", e);
  }
}

/**
 * Hook that syncs global filters between URL ↔ store ↔ localStorage
 * Mount this ONCE at the app root level
 */
export function useSyncGlobalFilters() {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { filters, setAllFilters } = useGlobalFiltersStore();

  const isInitialMount = useRef(true);
  const lastSyncedUrl = useRef("");
  const lastSyncedFilters = useRef("");

  // HYDRATION: On mount or route change, hydrate store from URL or localStorage
  useEffect(() => {
    const currentUrl = location.pathname + location.search;
    const currentMode = getCurrentMode();

    // Skip if we already processed this URL
    if (lastSyncedUrl.current === currentUrl && !isInitialMount.current) {
      return;
    }

    lastSyncedUrl.current = currentUrl;

    // For root path "/", skip processing and let React Router redirect to /overview first
    // Filters will be processed after redirect completes
    if (location.pathname === "/") {
      // Don't mark as initial mount so filters can be processed after redirect
      return;
    }

    // For IGNORE routes, remove global filters from URL and don't sync
    if (currentMode === "IGNORE") {
      // Remove global filter params from URL if present
      const params = new URLSearchParams(location.search);
      let hasGFParams = false;
      params.forEach((_, key) => {
        if (key.startsWith(GF_PREFIX)) {
          params.delete(key);
          hasGFParams = true;
        }
      });

      if (hasGFParams) {
        const newSearch = params.toString();
        const newPath = newSearch ? `${location.pathname}?${newSearch}` : location.pathname;
        navigate(newPath, { replace: true });
      }

      isInitialMount.current = false;
      return;
    }

    const urlFilters = parseFiltersFromUrl(location.search);
    const hasUrlFilters = Object.keys(urlFilters).length > 0;

    // Get current store state (read directly, don't use in dependency to avoid loops)
    const currentStoreFilters = useGlobalFiltersStore.getState().filters;
    const currentFiltersJson = JSON.stringify(currentStoreFilters);
    const urlFiltersJson = JSON.stringify(urlFilters);
    const hasStoreFilters = Object.keys(currentStoreFilters).length > 0;

    if (hasUrlFilters) {
      // URL has filters - hydrate store from URL
      if (currentFiltersJson !== urlFiltersJson) {
        setAllFilters(urlFilters);
        saveFiltersToLS(urlFilters);
      }
    } else {
      // URL doesn't have filters
      const lsFilters = getFiltersFromLS();
      const lsFiltersJson = JSON.stringify(lsFilters);

      // If store has filters but URL doesn't, preserve them in the URL (navigation case)
      if (hasStoreFilters) {
        const newSearch = serializeFiltersToUrl(currentStoreFilters, location.search);
        const currentSearch = location.search.replace(/^\?/, "");

        if (newSearch !== currentSearch) {
          const newPath = newSearch ? `${location.pathname}?${newSearch}` : location.pathname;
          navigate(newPath, { replace: true });
        }
      } else if (Object.keys(lsFilters).length > 0) {
        // Restore from localStorage if store is empty
        if (currentFiltersJson !== lsFiltersJson) {
          setAllFilters(lsFilters);

          const newSearch = serializeFiltersToUrl(lsFilters, location.search);
          if (newSearch) {
            navigate(`${location.pathname}?${newSearch}`, { replace: true });
          }
        }
      } else {
        // No filters anywhere, ensure store is empty
        if (Object.keys(currentStoreFilters).length > 0) {
          setAllFilters({});
        }
      }
    }

    isInitialMount.current = false;
  }, [location.pathname, location.search, setAllFilters, navigate]);

  // SYNC: When store changes, update URL and localStorage
  useEffect(() => {
    // Skip initial mount (handled by hydration above)
    if (isInitialMount.current) {
      return;
    }

    // Skip processing on root path - let redirect happen first
    if (location.pathname === "/") {
      return;
    }

    const currentMode = getCurrentMode();

    // Skip syncing to URL for IGNORE routes
    if (currentMode === "IGNORE") {
      return;
    }

    const filtersJson = JSON.stringify(filters);

    // Skip if filters haven't actually changed
    if (filtersJson === lastSyncedFilters.current) {
      return;
    }

    lastSyncedFilters.current = filtersJson;

    // 1. Update localStorage (synchronous)
    saveFiltersToLS(filters);

    // 2. Update URL (synchronous)
    const newSearch = serializeFiltersToUrl(filters, location.search);
    const currentSearch = location.search.replace(/^\?/, "");

    if (newSearch !== currentSearch) {
      const newPath = newSearch ? `${location.pathname}?${newSearch}` : location.pathname;

      navigate(newPath, { replace: true });
    }

    // 3. Invalidate filter-aware queries to trigger refetch
    queryClient.invalidateQueries({
      predicate: query => shouldInvalidateOnGlobalFilterChange(query.queryKey),
    });
  }, [filters, location.pathname, location.search, navigate, queryClient]);

  return null;
}
