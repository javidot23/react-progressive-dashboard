import { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import { getDefaultSelectedMonth } from "@/lib/ftsMonthUtils";

const PREFIX = "fts_me_";

const DEFAULT_FILTERS = {
  ordering: "-fts_exposure",
  selected_month: getDefaultSelectedMonth(),
} as const;

function serializeFTSMaterialExposureFilters(filters: Record<string, unknown>): URLSearchParams {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "") {
      params.set(`${PREFIX}${key}`, value.toString());
    }
  });
  return params;
}

function deserializeFTSMaterialExposureFilters(searchParams: URLSearchParams): Record<string, unknown> {
  const filters = { ...DEFAULT_FILTERS };
  for (const [key, value] of searchParams.entries()) {
    if (key.startsWith(PREFIX)) {
      const filterKey = key.slice(PREFIX.length);
      if (filterKey in filters) {
        (filters as Record<string, unknown>)[filterKey] = value;
      }
    }
  }
  return filters;
}

export function useFTSMaterialExposureFilters() {
  const [searchParams, setSearchParams] = useSearchParams();

  const [filters, setFiltersState] = useState<Record<string, unknown>>(() => deserializeFTSMaterialExposureFilters(searchParams));

  const setFilters = useCallback(
    (newFilters: Record<string, unknown>) => {
      setFiltersState(newFilters);
      const params = new URLSearchParams(searchParams);
      for (const key of [...params.keys()]) {
        if (key.startsWith(PREFIX)) params.delete(key);
      }
      const newParams = serializeFTSMaterialExposureFilters(newFilters);
      newParams.forEach((value, key) => params.set(key, value));
      setSearchParams(params, { replace: true });
    },
    [searchParams, setSearchParams]
  );

  useEffect(() => {
    setFiltersState(deserializeFTSMaterialExposureFilters(searchParams));
  }, [searchParams]);

  return { filters, setFilters };
}
