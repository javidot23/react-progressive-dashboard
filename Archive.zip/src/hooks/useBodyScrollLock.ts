import { useEffect } from "react";

let lockCount = 0;
let restoreScroll: (() => void) | null = null;
let inertRoot: HTMLElement | null = null;

function getAppRoot(): HTMLElement | null {
  return document.getElementById("root");
}

function lock() {
  if (lockCount++ > 0) return;

  const { body, documentElement: html } = document;
  const prevBodyOverflow = body.style.overflow;
  const prevHtmlOverflow = html.style.overflow;
  body.style.overflow = "hidden";
  html.style.overflow = "hidden";
  restoreScroll = () => {
    body.style.overflow = prevBodyOverflow;
    html.style.overflow = prevHtmlOverflow;
  };

  const root = getAppRoot();
  if (root && "inert" in root) {
    inertRoot = root;
    root.inert = true;
  }
}

function unlock() {
  if (lockCount === 0) return;
  if (--lockCount === 0) {
    restoreScroll?.();
    restoreScroll = null;
    if (inertRoot) {
      inertRoot.inert = false;
      inertRoot = null;
    }
  }
}

export function useBodyScrollLock(locked: boolean) {
  useEffect(() => {
    if (!locked) return;
    lock();
    return unlock;
  }, [locked]);
}

/** Test-only reset for ref-counted lock state between test cases. */
export function resetBodyScrollLockForTests() {
  while (lockCount > 0) {
    unlock();
  }
  restoreScroll = null;
  if (inertRoot) {
    inertRoot.inert = false;
    inertRoot = null;
  }
  document.body.style.overflow = "";
  document.documentElement.style.overflow = "";
}
