import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { VendorListFilters } from "@/lib/apiServices";
import { deserializeFiltersFromUrl, updateUrlWithFilters } from "@/lib/utils";

export const useScorecardFilters = () => {
  const [searchParams] = useSearchParams();

  // Default filters
  const defaultFilters: VendorListFilters = {
    limit: 10,
    offset: 0,
    ordering: "-inbound_fill_rate",
  };

  // Initialize filters from URL or use defaults
  const [filters, setFiltersState] = useState<VendorListFilters>(() => {
    const urlFilters = deserializeFiltersFromUrl(searchParams);
    return { ...defaultFilters, ...urlFilters };
  });

  // Update URL when filters change
  useEffect(() => {
    updateUrlWithFilters(filters);
  }, [filters]);

  // Update filters when URL changes (browser back/forward)
  useEffect(() => {
    const urlFilters = deserializeFiltersFromUrl(searchParams);
    setFiltersState(prevFilters => ({ ...prevFilters, ...urlFilters }));
  }, [searchParams]);

  const setFilters = (newFilters: VendorListFilters | ((prev: VendorListFilters) => VendorListFilters)) => {
    const updatedFilters = typeof newFilters === 'function' ? newFilters(filters) : newFilters;
    setFiltersState(updatedFilters);
  };

  return {
    filters,
    setFilters,
  };
};
