import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { serializeMaterialFilters, deserializeMaterialFilters } from "@/lib/materialFilterUtils";

export const useMaterialFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  // Initialize filters from URL parameters
  const [filters, setFiltersState] = useState(() => {
    return deserializeMaterialFilters(searchParams);
  });

  // Custom setFilters function that updates both state and URL
  const setFilters = (newFilters: any) => {
    setFiltersState(newFilters);
    const params = serializeMaterialFilters(newFilters);
    setSearchParams(params, { replace: true });
  };

  // Handle URL parameter changes (back/forward navigation)
  useEffect(() => {
    const newFilters = deserializeMaterialFilters(searchParams);
    setFiltersState(newFilters);
  }, [searchParams]);

  return {
    filters,
    setFilters,
  };
};
