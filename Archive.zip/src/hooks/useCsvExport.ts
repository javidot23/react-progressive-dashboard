import { useCallback, useRef, useState } from "react";
import { downloadCsv, toCsv, type CsvColumn } from "@/lib/csv";

export type UseCsvExportResult = {
  isExporting: boolean;
  exportRows: <T>(filename: string, columns: CsvColumn<T>[], rows: T[]) => void;
  exportAsync: <T>(filename: string, columns: CsvColumn<T>[], loadRows: () => Promise<T[]>) => Promise<void>;
};

/**
 * Shared CSV download helper with in-flight guard for DataGrid export buttons.
 */
export function useCsvExport(): UseCsvExportResult {
  const [isExporting, setIsExporting] = useState(false);
  const exportingRef = useRef(false);

  const exportRows = useCallback(<T>(filename: string, columns: CsvColumn<T>[], rows: T[]) => {
    downloadCsv(filename, toCsv(rows, columns));
  }, []);

  const exportAsync = useCallback(async <T>(filename: string, columns: CsvColumn<T>[], loadRows: () => Promise<T[]>) => {
    if (exportingRef.current) return;
    exportingRef.current = true;
    setIsExporting(true);
    try {
      const rows = await loadRows();
      downloadCsv(filename, toCsv(rows, columns));
    } finally {
      exportingRef.current = false;
      setIsExporting(false);
    }
  }, []);

  return { isExporting, exportRows, exportAsync };
}
