import { useMemo } from "react";
import { useQuery, useMutation, useQueryClient, UseQueryOptions, UseMutationOptions } from "@tanstack/react-query";
import { AxiosResponse, AxiosError } from "axios";
import { getYesterdayIso } from "@/lib/dateUtils";
import {
  userService,
  riskService,
  dashboardService,
  materialsLowInventoryService,
  dcInventoryService,
  weeklySupplyService,
  ApiResponse,
  User,
  RiskData,
  DashboardStats,
  MaterialsLowInventoryFilters,
  MaterialsLowInventoryResponse,
  DCInventoryFilters,
  DCInventoryResponse,
  MaterialPlantCustomersFilters,
  MaterialPlantCustomersResponse,
  WeeklySupplyResponse,
  materialPlantCustomersService,
} from "@/lib/apiServices";
import { useGlobalFiltersStore } from "@/stores/slices/globalFilters";

export const queryKeys = {
  users: ["users"] as const,
  user: (id: string) => ["users", id] as const,
  currentUser: ["auth", "me"] as const,
  risks: ["risks"] as const,
  risk: (id: string) => ["risks", id] as const,
  dashboardStats: ["dashboard", "stats"] as const,
  riskTrends: (period: string) => ["dashboard", "trends", period] as const,
  materialsLowInventory: ["materials", "lowInventory"] as const,
  dcInventory: ["dc", "inventory"] as const,
  materialPlantCustomers: ["materialPlantCustomers"] as const,
  weeklySupply: ["weekly", "supply"] as const,
};

type QueryOptions<T> = Omit<UseQueryOptions<AxiosResponse<ApiResponse<T>>, AxiosError>, "queryKey" | "queryFn">;
type MutationOptions<TData, TVariables> = UseMutationOptions<AxiosResponse<ApiResponse<TData>>, AxiosError, TVariables>;

export const useCurrentUser = (options?: QueryOptions<User>) => {
  return useQuery({
    queryKey: queryKeys.currentUser,
    queryFn: ({ signal }) => userService.getCurrentUser(signal),
    ...options,
  });
};

export const useUsers = (params?: { page?: number; limit?: number }, options?: QueryOptions<User[]>) => {
  return useQuery({
    queryKey: [...queryKeys.users, params],
    queryFn: ({ signal }) => userService.getUsers(params, signal),
    ...options,
  });
};

export const useUpdateProfile = (options?: MutationOptions<User, Partial<User>>) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: userService.updateProfile,
    meta: {
      successMessage: "Profile updated",
      errorMessage: "Couldn't update profile",
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: queryKeys.currentUser });
    },
    ...options,
  });
};

export const useRisks = (
  params?: {
    page?: number;
    limit?: number;
    riskLevel?: string;
    sortBy?: string;
    sortOrder?: "asc" | "desc";
  },
  options?: QueryOptions<RiskData[]>
) => {
  return useQuery({
    queryKey: [...queryKeys.risks, params],
    queryFn: ({ signal }) => riskService.getRisks(params, signal),
    ...options,
  });
};

export const useRisk = (id: string, options?: QueryOptions<RiskData>) => {
  return useQuery({
    queryKey: queryKeys.risk(id),
    queryFn: ({ signal }) => riskService.getRiskById(id, signal),
    enabled: !!id,
    ...options,
  });
};

export const useCreateRisk = (options?: MutationOptions<RiskData, Omit<RiskData, "id" | "createdAt" | "updatedAt">>) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: riskService.createRisk,
    meta: {
      successMessage: "Risk created",
      errorMessage: "Couldn't create risk",
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: queryKeys.risks });
      void queryClient.invalidateQueries({ queryKey: queryKeys.dashboardStats });
    },
    ...options,
  });
};

export const useUpdateRisk = (options?: MutationOptions<RiskData, { id: string; data: Partial<RiskData> }>) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }) => riskService.updateRisk(id, data),
    meta: {
      successMessage: "Risk updated",
      errorMessage: "Couldn't update risk",
    },
    onSuccess: (_, variables) => {
      void queryClient.invalidateQueries({ queryKey: queryKeys.risk(variables.id) });
      void queryClient.invalidateQueries({ queryKey: queryKeys.risks });
      void queryClient.invalidateQueries({ queryKey: queryKeys.dashboardStats });
    },
    ...options,
  });
};

export const useDeleteRisk = (options?: MutationOptions<null, string>) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: riskService.deleteRisk,
    meta: {
      successMessage: "Risk deleted",
      errorMessage: "Couldn't delete risk",
    },
    onSuccess: (_, id) => {
      queryClient.removeQueries({ queryKey: queryKeys.risk(id) });
      void queryClient.invalidateQueries({ queryKey: queryKeys.risks });
      void queryClient.invalidateQueries({ queryKey: queryKeys.dashboardStats });
    },
    ...options,
  });
};

export const useDashboardStats = (dateRange?: { from: string; to: string }, options?: QueryOptions<DashboardStats>) => {
  return useQuery({
    queryKey: [...queryKeys.dashboardStats, dateRange],
    queryFn: ({ signal }) => dashboardService.getStats(dateRange, signal),
    ...options,
  });
};

interface RiskTrend {
  date: string;
  count: number;
  level: string;
}

export const useRiskTrends = (period: "7d" | "30d" | "90d" | "1y" = "30d", options?: QueryOptions<RiskTrend[]>) => {
  return useQuery({
    queryKey: queryKeys.riskTrends(period),
    queryFn: ({ signal }) => dashboardService.getRiskTrends(period, signal),
    ...options,
  });
};

export const useApiQuery = <T = unknown,>(
  key: unknown[],
  queryFn: () => Promise<AxiosResponse<ApiResponse<T>>>,
  options?: QueryOptions<T>
) => {
  return useQuery({
    queryKey: key,
    queryFn,
    ...options,
  });
};

export const useApiMutation = <TData = unknown, TVariables = unknown>(
  mutationFn: (variables: TVariables) => Promise<AxiosResponse<ApiResponse<TData>>>,
  options?: MutationOptions<TData, TVariables>
) => {
  return useMutation({
    mutationFn,
    ...options,
  });
};

export const useMaterialsLowInventory = (
  params?: MaterialsLowInventoryFilters,
  options?: Omit<UseQueryOptions<AxiosResponse<MaterialsLowInventoryResponse>, AxiosError>, "queryKey" | "queryFn">
) => {
  const globalFiltersVersion = useGlobalFiltersStore(state => state.version);

  return useQuery({
    queryKey: [...queryKeys.materialsLowInventory, params, globalFiltersVersion],
    queryFn: ({ signal }) => materialsLowInventoryService.getMaterialsLowInventory(params, signal),
    ...options,
  });
};

export const useDCInventory = (
  matNbr: string | null,
  params?: DCInventoryFilters,
  options?: Omit<UseQueryOptions<AxiosResponse<DCInventoryResponse>, AxiosError>, "queryKey" | "queryFn">
) => {
  const globalFiltersVersion = useGlobalFiltersStore(state => state.version);

  return useQuery({
    queryKey: [...queryKeys.dcInventory, matNbr, params, globalFiltersVersion],
    queryFn: ({ signal }) => dcInventoryService.getDCInventory(matNbr!, params, signal),
    enabled: !!matNbr,
    ...options,
  });
};

export const useMaterialPlantCustomers = (
  matNbr: string | null,
  plantNbr: string | null,
  params?: MaterialPlantCustomersFilters,
  options?: Omit<UseQueryOptions<AxiosResponse<MaterialPlantCustomersResponse>, AxiosError>, "queryKey" | "queryFn">
) => {
  const globalFiltersVersion = useGlobalFiltersStore(state => state.version);

  const requestParams = useMemo(() => {
    const yesterday = getYesterdayIso();
    return {
      ...params,
      from_date: yesterday,
      to_date: yesterday,
    };
  }, [params]);

  return useQuery({
    queryKey: [...queryKeys.materialPlantCustomers, matNbr, plantNbr, requestParams, globalFiltersVersion],
    queryFn: ({ signal }) => materialPlantCustomersService.getCustomers(matNbr!, plantNbr!, requestParams, signal),
    enabled: !!matNbr && !!plantNbr,
    ...options,
  });
};

export const useWeeklySupply = (
  params?: { ordering?: string; material?: string },
  options?: Omit<UseQueryOptions<AxiosResponse<WeeklySupplyResponse>, AxiosError>, "queryKey" | "queryFn">
) => {
  const globalFiltersVersion = useGlobalFiltersStore(state => state.version);

  return useQuery({
    queryKey: [...queryKeys.weeklySupply, params, globalFiltersVersion],
    queryFn: ({ signal }) => weeklySupplyService.getWeeklySupply(params, signal),
    ...options,
  });
};

export type { AxiosResponse, AxiosError };
