import { useEffect, useRef } from "react";
import { useManageSalesCsFilterStore } from "@/stores/manageSalesCsFilterStore";

/**
 * Hook that components can use to listen to Manage Sales CS schedule filter changes
 * and trigger their own data refetches when the filter changes.
 */
export function useManageSalesCsFilterListener(onCsFilterChange: () => void) {
  const version = useManageSalesCsFilterStore(state => state.version);
  const lastVersionRef = useRef(version);

  useEffect(() => {
    if (lastVersionRef.current !== version) {
      lastVersionRef.current = version;
      onCsFilterChange();
    }
  }, [version, onCsFilterChange]);
}

export function useManageSalesCsFilterVersion(): number {
  return useManageSalesCsFilterStore(state => state.version);
}
