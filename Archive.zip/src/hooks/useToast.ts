import { useMemo } from "react";
import { toast } from "@/lib/toast";

export function useToast() {
  return useMemo(() => ({ toast }), []);
}
