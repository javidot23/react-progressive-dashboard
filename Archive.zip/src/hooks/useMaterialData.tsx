import { useState, useEffect, useRef } from "react";
import { MaterialWithIssues } from "@/lib/types";
import { fetchMaterialsWithIssues } from "@/services/materialService";

interface UseMaterialDataProps {
  vendorId: number | null;
  filters: Record<string, any>;
  page?: number;
  pageSize?: number;
}

export const useMaterialData = ({ vendorId, filters, page = 1, pageSize = 10 }: UseMaterialDataProps) => {
  const [materials, setMaterials] = useState<MaterialWithIssues[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [total, setTotal] = useState(0);
  const isFetching = useRef(false);
  const previousFiltersRef = useRef<string>(JSON.stringify(filters));
  const previousVendorIdRef = useRef<number | null>(vendorId);
  const previousPageRef = useRef<number>(page);

  const fetchData = async (pageNumber: number, size: number, append: boolean = false) => {
    if (isFetching.current || !vendorId) return;

    isFetching.current = true;
    setLoading(true);

    try {
      const {
        results,
        hasMore: hasMoreResults,
        total: totalCount,
      } = await fetchMaterialsWithIssues(vendorId, pageNumber, size, filters);

      if (append) {
        // For infinite scroll, append new results
        setMaterials(prev => [...prev, ...results]);
      } else {
        // For initial load or filter change, replace results
        setMaterials(results);
      }
      setHasMore(hasMoreResults);
      setTotal(totalCount || 0);
    } catch (err) {
      console.error("Error fetching materials:", err);
    } finally {
      setLoading(false);
      isFetching.current = false;
    }
  };

  // Fetch data when page, pageSize, filters, or vendorId change
  useEffect(() => {
    if (!vendorId) return;

    const currentFiltersStr = JSON.stringify(filters);
    const filtersChanged = previousFiltersRef.current !== currentFiltersStr;
    const vendorIdChanged = previousVendorIdRef.current !== vendorId;
    const pageIncreased = page > previousPageRef.current && !filtersChanged && !vendorIdChanged;

    // Reset materials when filters or vendorId change
    if (filtersChanged || vendorIdChanged) {
      setMaterials([]);
    }

    // Determine if we should append or replace data
    const shouldAppend = pageIncreased && previousPageRef.current > 0;

    if (shouldAppend) {
      // Loading more pages (infinite scroll) - append data
      fetchData(page, pageSize, true);
    } else {
      // Initial load, filter change, or reset to page 1 - replace data
      fetchData(page, pageSize, false);
    }

    // Update refs for next comparison
    previousFiltersRef.current = currentFiltersStr;
    previousVendorIdRef.current = vendorId;
    previousPageRef.current = page;
  }, [page, pageSize, filters, vendorId]);

  const loadMore = () => {
    // This is now handled by the parent component through page changes
    console.warn("loadMore is deprecated. Use page changes instead.");
  };

  return {
    materials,
    loading,
    hasMore,
    total,
    loadMore,
  };
};
