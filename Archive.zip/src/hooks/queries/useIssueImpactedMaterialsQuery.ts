import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { fetchIssueImpactedMaterials, FetchIssueImpactedMaterialsResult } from "@/services/issueService";

export const issueImpactedMaterialsQueryKeys = {
  all: ["issue-impacted-materials"] as const,
  lists: () => [...issueImpactedMaterialsQueryKeys.all, "list"] as const,
  list: (issueId: number | string, page: number, pageSize: number, filters: Record<string, unknown>) =>
    [...issueImpactedMaterialsQueryKeys.lists(), { issueId, page, pageSize, filters }] as const,
} as const;

interface UseIssueImpactedMaterialsQueryParams {
  issueId?: number;
  page?: number;
  pageSize?: number;
  /** ordering + range filters passed to the endpoint. */
  filters?: Record<string, unknown>;
  enabled?: boolean;
}

/**
 * Materials impacted by an issue, at its grain — GET /issue/<id>/materials/.
 * Issue-scoped, so global-filter version is intentionally not part of the key
 * (the interceptor also skips gf_* on the /react/issue route).
 */
export function useIssueImpactedMaterialsQuery({
  issueId,
  page = 1,
  pageSize = 25,
  filters = {},
  enabled = true,
}: UseIssueImpactedMaterialsQueryParams) {
  const query = useQuery({
    queryKey: issueImpactedMaterialsQueryKeys.list(issueId ?? "", page, pageSize, filters),
    queryFn: async ({ signal }): Promise<FetchIssueImpactedMaterialsResult> =>
      fetchIssueImpactedMaterials({ issueId: issueId!, page, pageSize, filters, signal }),
    enabled: enabled && !!issueId,
    placeholderData: keepPreviousData,
  });

  return {
    materials: query.data?.results ?? [],
    total: query.data?.total ?? 0,
    hasMore: query.data?.hasMore ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    error: query.error,
    isError: query.isError,
    refetch: query.refetch,
  };
}

export default useIssueImpactedMaterialsQuery;
