import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteAction } from "@/services/actionService";
import {
  issuesQueryKeys,
  issueByIdQueryKeys,
  materialsQueryKeys,
  vendorQueryKeys,
  materialActionHistoryQueryKeys,
  granularityIssuesQueryKeys,
  granularityIssueByIdQueryKeys,
  issueImpactedMaterialsQueryKeys,
  userActionsQueryKeys,
} from "@/hooks/queries";

export type RemoveActionVariables =
  | number
  | {
      actionId: number;
      issueId: number;
      partNumber: string;
    };

export function useRemoveActionMutation(vendorId: number | null) {
  const queryClient = useQueryClient();

  return useMutation({
    meta: {
      successMessage: "Action removed",
      errorMessage: "Couldn't remove action",
    },
    mutationFn: async (variables: RemoveActionVariables) => {
      const response =
        typeof variables === "number"
          ? await deleteAction(variables)
          : await deleteAction(variables.actionId, {
              issue_id: variables.issueId,
              part_number: variables.partNumber,
            });

      if (!response.success) {
        throw new Error("Failed to remove action");
      }

      return response;
    },

    onSuccess: () => {
      if (vendorId) {
        queryClient.invalidateQueries({
          queryKey: materialsQueryKeys.byVendor(vendorId),
        });
        queryClient.invalidateQueries({
          queryKey: vendorQueryKeys.detail(vendorId),
        });
      }
      queryClient.invalidateQueries({
        queryKey: issuesQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: issueByIdQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: materialActionHistoryQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: granularityIssuesQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: granularityIssueByIdQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: issueImpactedMaterialsQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: userActionsQueryKeys.all,
        refetchType: "active",
      });
    },
  });
}

export default useRemoveActionMutation;
