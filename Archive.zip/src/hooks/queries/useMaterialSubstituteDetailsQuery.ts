import { useQuery } from "@tanstack/react-query";
import { materialSubstitutesService, type MaterialSubstitutionDetailsResponse } from "@/lib/apiServices";

export const materialSubstituteDetailsQueryKeys = {
  all: ["material-substitute-details"] as const,
  detail: (materialId: number) => [...materialSubstituteDetailsQueryKeys.all, materialId] as const,
};

interface UseMaterialSubstituteDetailsQueryParams {
  materialId: number | undefined;
  enabled?: boolean;
}

export function useMaterialSubstituteDetailsQuery({ materialId, enabled = true }: UseMaterialSubstituteDetailsQueryParams) {
  const query = useQuery({
    queryKey: materialSubstituteDetailsQueryKeys.detail(materialId ?? 0),
    queryFn: async ({ signal }): Promise<MaterialSubstitutionDetailsResponse["data"] | null> => {
      if (!materialId || materialId <= 0) {
        return null;
      }

      const response = await materialSubstitutesService.getMaterialSubstituteDetails(materialId, signal);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      return null;
    },
    enabled: enabled && !!materialId,
  });

  return {
    details: query.data ?? null,
    isLoading: query.isLoading,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}
