import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createAction, CreateActionRequest } from "@/services/actionService";
import {
  issuesQueryKeys,
  issueByIdQueryKeys,
  materialsQueryKeys,
  materialActionHistoryQueryKeys,
  granularityIssuesQueryKeys,
  granularityIssueByIdQueryKeys,
  issueImpactedMaterialsQueryKeys,
} from "@/hooks/queries";

interface CreateActionParams {
  issueNbr: string;
  /** Single material (per-material flow). Omit when using `matNbrs`. */
  matNbr?: string;
  /** Materials to act on for a granularity issue. Omit + no `matNbr` ⇒ ALL grain materials. */
  matNbrs?: string[];
  actionType: string;
  potentialActionNbr?: string;
  materialRiskRating?: number;
  materialDrivingRisk?: string;
  materialDollarsAtRisk?: number;
  substitutedMaterialNbr?: string;
  skipInvalidation?: boolean;
}

export function useActionMutation(vendorId: number | null) {
  const queryClient = useQueryClient();

  return useMutation({
    meta: {
      silent: true,
    },
    mutationFn: async (params: CreateActionParams) => {
      // Build action data with all critical fields always included
      const actionData: CreateActionRequest = {
        issue_nbr: params.issueNbr,
        mat_nbr: params.matNbr,
        mat_nbrs: params.matNbrs,
        // Critical fields - always include in POST request
        material_risk_rating: params.materialRiskRating,
        material_driving_risk: params.materialDrivingRisk,
        material_dollars_at_risk: params.materialDollarsAtRisk,
      };

      if (params.actionType === "no_action_required") {
        actionData.action = "no_action";
      } else if (params.potentialActionNbr) {
        // Include potential_action_nbr when available
        actionData.potential_action_nbr = params.potentialActionNbr;
      }

      if (params.substitutedMaterialNbr) {
        // Include substituted_material_nbr when available
        actionData.substituted_material_nbr = params.substitutedMaterialNbr;
      }

      const response = await createAction(actionData);

      if (!response.success) {
        throw new Error("Failed to create action");
      }

      return response.data;
    },

    onSuccess: (_data, variables) => {
      if (variables.skipInvalidation) return;
      if (vendorId) {
        queryClient.invalidateQueries({
          queryKey: materialsQueryKeys.byVendor(vendorId),
        });
      }
      queryClient.invalidateQueries({
        queryKey: issuesQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: issueByIdQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: materialActionHistoryQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: granularityIssuesQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: granularityIssueByIdQueryKeys.all,
        refetchType: "active",
      });
      queryClient.invalidateQueries({
        queryKey: issueImpactedMaterialsQueryKeys.all,
        refetchType: "active",
      });
    },
  });
}

export default useActionMutation;
