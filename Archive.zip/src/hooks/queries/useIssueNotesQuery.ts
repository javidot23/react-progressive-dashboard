import { useInfiniteQuery, keepPreviousData } from "@tanstack/react-query";
import { listIssueNotes, type IssueNotesListPayload } from "@/services/issueNotesService";

export const ISSUE_NOTES_DEFAULT_LIMIT = 10;

export const issueNotesQueryKeys = {
  all: ["issue-notes"] as const,
  byIssue: (issueId: string, limit: number) => [...issueNotesQueryKeys.all, issueId, { limit }] as const,
};

export function issueNotesQueriesForIssueFilter(issueId: string) {
  return { queryKey: [...issueNotesQueryKeys.all, issueId] as const };
}

export interface UseIssueNotesQueryParams {
  issueId: string | undefined;
  enabled?: boolean;
  limit?: number;
}

export function getNextIssueNotesPageParam(
  lastPage: IssueNotesListPayload,
  allPages: IssueNotesListPayload[]
): number | undefined {
  const loaded = allPages.reduce((sum, p) => sum + p.results.length, 0);
  if (lastPage.next) return loaded;
  if (loaded < lastPage.count) return loaded;
  return undefined;
}

export function useIssueNotesQuery({ issueId, enabled = true, limit = ISSUE_NOTES_DEFAULT_LIMIT }: UseIssueNotesQueryParams) {
  const safeId = issueId ?? "";

  return useInfiniteQuery({
    queryKey: issueNotesQueryKeys.byIssue(safeId, limit),
    queryFn: async ({ pageParam, signal }): Promise<IssueNotesListPayload> => {
      return listIssueNotes(safeId, limit, pageParam as number, signal);
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) => getNextIssueNotesPageParam(lastPage, allPages),
    enabled: Boolean(issueId) && enabled,
    placeholderData: keepPreviousData,
  });
}
