import { queryOptions, useQuery } from "@tanstack/react-query";
import {
  serviceLevelAnalysisService,
  serviceLevelService,
  serviceLevelTrendService,
  type ServiceLevelPlantData,
} from "@/lib/apiServices";
import { transformServiceLevelAnalysisResponse, transformServiceLevelTrendResponse } from "@/stores/slices/transformers";
import type { ServiceLevelAnalysis, ServiceLevelTrendDisplay } from "@/stores/slices/types";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

const formatDate = (date: Date) => date.toISOString().split("T")[0];

export function getDefaultServiceLevelTrendDateRange() {
  const today = new Date();
  const past = new Date(today);
  past.setDate(today.getDate() - 30);
  return {
    startDate: formatDate(past),
    endDate: formatDate(today),
  };
}

export function getDefaultServiceLevelPlantsDateRange() {
  const endDate = new Date();
  const startDate = new Date();
  startDate.setDate(endDate.getDate() - 30);
  return {
    startDate: formatDate(startDate),
    endDate: formatDate(endDate),
  };
}

export const serviceLevelQueryKeys = {
  all: ["service-level"] as const,
  trend: (startDate: string, endDate: string, globalFiltersVersion: number) =>
    [...serviceLevelQueryKeys.all, "trend", { startDate, endDate, globalFiltersVersion }] as const,
  analysis: (globalFiltersVersion: number) => [...serviceLevelQueryKeys.all, "analysis", globalFiltersVersion] as const,
  plants: (startDate: string, endDate: string) => [...serviceLevelQueryKeys.all, "plants", { startDate, endDate }] as const,
};

export function serviceLevelTrendQueryOptions(startDate: string, endDate: string, globalFiltersVersion: number) {
  return queryOptions({
    queryKey: serviceLevelQueryKeys.trend(startDate, endDate, globalFiltersVersion),
    queryFn: async ({ signal }): Promise<ServiceLevelTrendDisplay[]> => {
      const response = await serviceLevelTrendService.getServiceLevelTrend(startDate, endDate, signal);
      if (response.data.success) {
        return transformServiceLevelTrendResponse(response.data);
      }
      throw new Error("Failed to fetch service level trend");
    },
  });
}

export function serviceLevelAnalysisQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: serviceLevelQueryKeys.analysis(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<ServiceLevelAnalysis> => {
      const response = await serviceLevelAnalysisService.getWeeklyServiceLevelAnalysis(signal);
      if (response.data?.success) {
        return transformServiceLevelAnalysisResponse(response.data);
      }
      throw new Error("Failed to fetch service level analysis");
    },
  });
}

export function serviceLevelPlantsQueryOptions(startDate: string, endDate: string) {
  return queryOptions({
    queryKey: serviceLevelQueryKeys.plants(startDate, endDate),
    queryFn: async ({ signal }): Promise<ServiceLevelPlantData[]> => {
      const response = await serviceLevelService.getServiceLevelPlants({ start_date: startDate, end_date: endDate }, signal);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error("Invalid response format");
    },
  });
}

export function useServiceLevelTrendQuery(startDate?: string, endDate?: string, enabled = true) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const range = getDefaultServiceLevelTrendDateRange();
  const resolvedStart = startDate ?? range.startDate;
  const resolvedEnd = endDate ?? range.endDate;

  return useQuery({
    ...serviceLevelTrendQueryOptions(resolvedStart, resolvedEnd, globalFiltersVersion),
    enabled,
  });
}

export function useServiceLevelPlantsQuery() {
  const { startDate, endDate } = getDefaultServiceLevelPlantsDateRange();
  return useQuery(serviceLevelPlantsQueryOptions(startDate, endDate));
}
