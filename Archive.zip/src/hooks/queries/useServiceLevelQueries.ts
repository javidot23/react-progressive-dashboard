import { queryOptions, useQuery } from "@tanstack/react-query";
import {
  serviceLevelAnalysisService,
  serviceLevelService,
  serviceLevelTrendService,
  type ServiceLevelPlantData,
  type ServiceLevelPlantDataFromGraph,
} from "@/lib/apiServices";
import {
  transformServiceLevelAnalysisResponse,
  transformServiceLevelTrendResponse,
} from "@/stores/slices/transformers";
import type {
  ServiceLevelAnalysis,
  ServiceLevelTrendDisplay,
} from "@/stores/slices/types";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";
import { isFullFeatureSet, isVendorPortal } from "@/tenant";

const formatDate = (date: Date) => date.toISOString().split("T")[0];

export function getDefaultServiceLevelTrendDateRange() {
  const today = new Date();
  const past = new Date(today);
  past.setDate(today.getDate() - (isVendorPortal() ? 90 : 30));
  return {
    startDate: formatDate(past),
    endDate: formatDate(today),
  };
}

export function getDefaultServiceLevelPlantsDateRange() {
  const endDate = new Date();
  const startDate = new Date();
  startDate.setDate(endDate.getDate() - 30);
  return {
    startDate: formatDate(startDate),
    endDate: formatDate(endDate),
  };
}

const transformFromGraphResponse = (
  fromGraphData: ServiceLevelPlantDataFromGraph[]
): ServiceLevelPlantData[] => {
  return fromGraphData.map((item) => {
    const { plant, service_levels } = item;
    const properties = plant.properties || {};
    const coverageZipCodes = properties.coverage_zip_codes
      ? properties.coverage_zip_codes
          .split(",")
          .map((zip) => zip.trim())
          .filter((zip) => zip.length > 0)
      : [];

    const transformedServiceLevels = (service_levels || []).map((level) => ({
      date: level.date,
      fill_rate: level.fill_rate,
      total_order_qty: level.total_order_qty,
      total_received_qty: level.total_received_qty,
    }));

    return {
      plant: {
        id: plant.node_id,
        plant_nbr: properties.plant || "",
        name: properties.plant_name || "",
        city: plant.city || "",
        state: properties.state_or_province || "",
        postal_code: plant.postal_code || "",
        longitude: plant.longitude,
        latitude: plant.latitude,
        default_lead_time: 0,
        coverage_zip_codes: coverageZipCodes,
        created_at: "",
        updated_at: "",
      },
      service_levels: transformedServiceLevels,
    };
  });
};

export const serviceLevelQueryKeys = {
  all: ["service-level"] as const,
  trend: (startDate: string, endDate: string, globalFiltersVersion: number) =>
    [...serviceLevelQueryKeys.all, "trend", { startDate, endDate, globalFiltersVersion }] as const,
  analysis: (globalFiltersVersion: number) =>
    [...serviceLevelQueryKeys.all, "analysis", globalFiltersVersion] as const,
  plants: (startDate: string, endDate: string) =>
    [...serviceLevelQueryKeys.all, "plants", { startDate, endDate, stratium: isFullFeatureSet() }] as const,
};

export function serviceLevelTrendQueryOptions(
  startDate: string,
  endDate: string,
  globalFiltersVersion: number
) {
  return queryOptions({
    queryKey: serviceLevelQueryKeys.trend(startDate, endDate, globalFiltersVersion),
    queryFn: async ({ signal }): Promise<ServiceLevelTrendDisplay[]> => {
      const response = await serviceLevelTrendService.getServiceLevelTrend(
        startDate,
        endDate,
        signal
      );
      if (response.data.success) {
        return transformServiceLevelTrendResponse(response.data);
      }
      throw new Error("Failed to fetch service level trend");
    },
  });
}

export function serviceLevelAnalysisQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: serviceLevelQueryKeys.analysis(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<ServiceLevelAnalysis> => {
      const response = await serviceLevelAnalysisService.getWeeklyServiceLevelAnalysis(signal);
      if (response.data?.success) {
        return transformServiceLevelAnalysisResponse(response.data);
      }
      throw new Error("Failed to fetch service level analysis");
    },
  });
}

export function serviceLevelPlantsQueryOptions(startDate: string, endDate: string) {
  return queryOptions({
    queryKey: serviceLevelQueryKeys.plants(startDate, endDate),
    queryFn: async ({ signal }): Promise<ServiceLevelPlantData[]> => {
      if (isFullFeatureSet()) {
        const response = await serviceLevelService.getServiceLevelPlantsFromGraph(
          { start_date: startDate, end_date: endDate },
          signal
        );
        if (response.data.success && response.data.data) {
          return transformFromGraphResponse(response.data.data);
        }
        throw new Error("Invalid response format");
      }

      const response = await serviceLevelService.getServiceLevelPlants(
        { start_date: startDate, end_date: endDate },
        signal
      );
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error("Invalid response format");
    },
  });
}

export function useServiceLevelTrendQuery(
  startDate?: string,
  endDate?: string,
  enabled = true
) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const range = getDefaultServiceLevelTrendDateRange();
  const resolvedStart = startDate ?? range.startDate;
  const resolvedEnd = endDate ?? range.endDate;

  return useQuery({
    ...serviceLevelTrendQueryOptions(resolvedStart, resolvedEnd, globalFiltersVersion),
    enabled,
  });
}

export function useServiceLevelPlantsQuery() {
  const { startDate, endDate } = getDefaultServiceLevelPlantsDateRange();
  return useQuery(serviceLevelPlantsQueryOptions(startDate, endDate));
}
