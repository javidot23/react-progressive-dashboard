import { queryOptions, useQuery } from "@tanstack/react-query";
import { aiInsightsService, type AiReferenceParagraph, type AiReferenceParagraphMetrics } from "@/lib/apiServices";
import { US_LOCALE, US_TIMEZONE } from "@/lib/usFormat";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

const INSIGHT_EMPTY = "";

/** Known Manage Summary insight paragraph ids from `/ai-insights/reference-paragraphs/`. */
export const REFERENCE_PARAGRAPH_IDS = {
  OTIF: "paragraph_1_v1_otif",
  UNFILLED: "paragraph_2_v2_unfilled",
  BRIDGE_V2_V3: "paragraph_3_bridge_v2_v3",
  YOY_SALES: "paragraph_4_v3_yoy_sales",
  LOW_INVENTORY: "paragraph_5_v4_low_inventory",
} as const;

export type ReferenceParagraphId = (typeof REFERENCE_PARAGRAPH_IDS)[keyof typeof REFERENCE_PARAGRAPH_IDS];

export type ReferenceParagraphsQueryResult = {
  paragraphs: AiReferenceParagraph[];
  byId: Partial<Record<string, AiReferenceParagraph>>;
};

/** Fill `{key}` / `{key:,}` placeholders from metrics_json when rendered_paragraph is missing. */
export function renderInsightTemplate(template: string, metrics: AiReferenceParagraphMetrics = {}): string {
  return template.replace(/\{(\w+)(?:,)?\}/g, (match, key: string) => {
    const raw = metrics[key];
    if (raw == null || raw === "") return match;
    if (typeof raw === "number" || match.includes(",")) {
      const n = typeof raw === "number" ? raw : Number(raw);
      if (Number.isFinite(n) && match.includes(",")) {
        return n.toLocaleString(US_LOCALE);
      }
    }
    return String(raw);
  });
}

/** Returns API text when available; otherwise empty so callers can hide the block. */
export function getRenderedParagraphText(paragraph?: AiReferenceParagraph | null): string {
  if (!paragraph) return INSIGHT_EMPTY;
  const rendered = paragraph.rendered_paragraph?.trim();
  if (rendered) return rendered;
  const template = paragraph.response_template?.trim();
  if (template) return renderInsightTemplate(template, paragraph.metrics_json ?? {});
  return INSIGHT_EMPTY;
}

export function formatInsightTimestamp(iso?: string | null): string {
  if (!iso?.trim()) return INSIGHT_EMPTY;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return INSIGHT_EMPTY;
  const date = d.toLocaleDateString(US_LOCALE, {
    month: "long",
    day: "numeric",
    year: "numeric",
    timeZone: US_TIMEZONE,
  });
  const time = d.toLocaleTimeString(US_LOCALE, {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: US_TIMEZONE,
  });
  return `${date} · ${time}`;
}

export const referenceParagraphsQueryKeys = {
  all: ["ai-insights", "reference-paragraphs"] as const,
  list: (globalFiltersVersion: number) => [...referenceParagraphsQueryKeys.all, "list", { globalFiltersVersion }] as const,
} as const;

export function referenceParagraphsQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: referenceParagraphsQueryKeys.list(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<ReferenceParagraphsQueryResult> => {
      const response = await aiInsightsService.getReferenceParagraphs({ signal });
      if (!response.data.success) {
        throw new Error(response.data.message || response.data.error || "Failed to fetch AI insights");
      }
      const paragraphs = Array.isArray(response.data.data) ? response.data.data : [];
      return {
        paragraphs,
        byId: Object.fromEntries(paragraphs.map(p => [p.paragraph_id, p])),
      };
    },
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
}

export function useReferenceParagraphsQuery(enabled = true) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery({
    ...referenceParagraphsQueryOptions(globalFiltersVersion),
    enabled,
  });

  return {
    paragraphs: query.data?.paragraphs ?? [],
    byId: query.data?.byId ?? {},
    getParagraphText: (paragraphId: string) => (query.isPending ? "" : getRenderedParagraphText(query.data?.byId[paragraphId])),
    isPending: query.isPending,
    isFetching: query.isFetching,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
