import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { listFeedback, getFeedbackFilters, FeedbackFilterParams } from "@/services/feedbackService";

export const feedbackQueryKeys = {
  all: ["feedback"] as const,
  list: (page: number, pageSize: number, filters?: FeedbackFilterParams) =>
    ["feedback", "list", page, pageSize, filters] as const,
  filters: () => ["feedback", "filters"] as const,
};

export function useFeedbackQuery(page = 1, pageSize = 10, filters?: FeedbackFilterParams) {
  return useQuery({
    queryKey: feedbackQueryKeys.list(page, pageSize, filters),
    queryFn: async ({ signal }) => {
      const response = await listFeedback(page, pageSize, filters, signal);
      return {
        results: response.data.results,
        total: response.data.count,
      };
    },
    placeholderData: keepPreviousData,
  });
}

export function useFeedbackFiltersQuery() {
  return useQuery({
    queryKey: feedbackQueryKeys.filters(),
    queryFn: async ({ signal }) => {
      const response = await getFeedbackFilters(signal);
      return response.data;
    },
  });
}
