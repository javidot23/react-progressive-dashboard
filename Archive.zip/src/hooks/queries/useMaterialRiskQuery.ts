import { useQuery } from "@tanstack/react-query";
import { materialRiskService, MaterialRiskData } from "@/lib/apiServices";

export const materialRiskQueryKeys = {
  all: ["materialRisk"] as const,
  details: () => [...materialRiskQueryKeys.all, "detail"] as const,
  detail: (materialId: number) => [...materialRiskQueryKeys.details(), materialId] as const,
} as const;

interface UseMaterialRiskQueryParams {
  materialId: number | undefined;
  enabled?: boolean;
}

export function useMaterialRiskQuery({ materialId, enabled = true }: UseMaterialRiskQueryParams) {
  const query = useQuery({
    queryKey: materialRiskQueryKeys.detail(materialId ?? 0),
    queryFn: async ({ signal }): Promise<MaterialRiskData[]> => {
      if (!materialId || materialId <= 0) {
        return [];
      }

      const response = await materialRiskService.getMaterialRisk(materialId, signal);

      const responseData = response.data;

      if (responseData.success && Array.isArray(responseData.data)) {
        return responseData.data;
      }

      return [];
    },
    enabled: enabled && !!materialId,
  });

  return {
    riskData: query.data ?? [],
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    error: query.error?.message ?? null,
    isError: query.isError,
    refetch: query.refetch,
  };
}
