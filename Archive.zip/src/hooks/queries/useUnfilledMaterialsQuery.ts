import { useMemo } from "react";
import { infiniteQueryOptions, keepPreviousData, useInfiniteQuery } from "@tanstack/react-query";
import { orderTransactionService, type UnfilledMaterialItem, type UnfilledMaterialsQueryParams } from "@/lib/apiServices";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export type UnfilledMaterialsFilters = Omit<UnfilledMaterialsQueryParams, "limit" | "offset">;

export const unfilledMaterialsQueryKeys = {
  all: ["unfilled-materials"] as const,
  lists: () => [...unfilledMaterialsQueryKeys.all, "list"] as const,
  infinite: (filters: UnfilledMaterialsFilters, pageSize: number, globalFiltersVersion: number) =>
    [...unfilledMaterialsQueryKeys.lists(), "infinite", { ...filters, pageSize, globalFiltersVersion }] as const,
} as const;

export type UnfilledMaterialsPage = {
  results: UnfilledMaterialItem[];
  count: number;
  next: string | null;
};

const emptyUnfilledMaterials: UnfilledMaterialItem[] = [];

export function unfilledMaterialsInfiniteQueryOptions(
  filters: UnfilledMaterialsFilters,
  pageSize: number,
  globalFiltersVersion: number
) {
  return infiniteQueryOptions({
    queryKey: unfilledMaterialsQueryKeys.infinite(filters, pageSize, globalFiltersVersion),
    queryFn: async ({ pageParam, signal }): Promise<UnfilledMaterialsPage> => {
      const response = await orderTransactionService.getUnfilledMaterials(
        { ...filters, limit: pageSize, offset: pageParam },
        { signal }
      );

      if (!response.data.success) {
        throw new Error(response.data.message || response.data.error || "Failed to fetch unfilled materials");
      }

      const page = response.data.data;
      return {
        results: page.results ?? [],
        count: page.count ?? 0,
        next: page.next ?? null,
      };
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage.next) return undefined;
      const loaded = allPages.reduce((sum, page) => sum + page.results.length, 0);
      return loaded < lastPage.count ? loaded : undefined;
    },
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
  });
}

export type UseUnfilledMaterialsInfiniteQueryParams = {
  pageSize?: number;
  search?: string;
  ordering?: string;
  filters?: Omit<UnfilledMaterialsFilters, "search" | "ordering">;
  enabled?: boolean;
};

export function useUnfilledMaterialsInfiniteQuery({
  pageSize = 25,
  search = "",
  ordering = "",
  filters: extraFilters = {},
  enabled = true,
}: UseUnfilledMaterialsInfiniteQueryParams = {}) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const filters: UnfilledMaterialsFilters = {
    ...extraFilters,
    ...(search.trim() ? { search: search.trim() } : {}),
    ...(ordering.trim() ? { ordering: ordering.trim() } : {}),
  };

  const query = useInfiniteQuery({
    ...unfilledMaterialsInfiniteQueryOptions(filters, pageSize, globalFiltersVersion),
    enabled,
  });

  const pages = query.data?.pages;
  const data = useMemo(() => pages?.flatMap(page => page.results) ?? emptyUnfilledMaterials, [pages]);

  return {
    data,
    total: pages?.[0]?.count ?? 0,
    hasNextPage: query.hasNextPage,
    fetchNextPage: query.fetchNextPage,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
