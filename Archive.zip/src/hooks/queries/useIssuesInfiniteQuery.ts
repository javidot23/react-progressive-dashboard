import { useInfiniteQuery, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { fetchIssues, IssueApiData, FetchIssuesResult } from "@/services/issueService";
import { issuesQueryKeys } from "@/hooks/queries";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const issuesInfiniteQueryKeys = {
  all: ["issues"] as const,
  infinite: () => [...issuesInfiniteQueryKeys.all, "infinite"] as const,
  infiniteList: (pageSize: number, filters: Record<string, unknown>, module: string | undefined, globalFiltersVersion: number) =>
    [...issuesInfiniteQueryKeys.infinite(), { pageSize, filters, module, globalFiltersVersion }] as const,
} as const;

interface UseIssuesInfiniteQueryParams {
  filters: Record<string, unknown>;
  pageSize?: number;
  module?: string;
  enabled?: boolean;
}

export const useIssuesInfiniteQuery = ({ filters, pageSize = 10, module, enabled = true }: UseIssuesInfiniteQueryParams) => {
  const queryClient = useQueryClient();
  const globalFiltersVersion = useGlobalFiltersVersion();

  const query = useInfiniteQuery({
    queryKey: issuesInfiniteQueryKeys.infiniteList(pageSize, filters, module, globalFiltersVersion),
    queryFn: async ({ pageParam = 1, signal }): Promise<FetchIssuesResult & { page: number }> => {
      const result = await fetchIssues({
        page: pageParam,
        pageSize,
        filters: filters as Record<string, any>,
        module,
        signal,
      });

      return { ...result, page: pageParam };
    },
    initialPageParam: 1,
    getNextPageParam: (lastPage, allPages) => {
      if (lastPage.hasMore) {
        return allPages.length + 1;
      }
      return undefined;
    },
    enabled,
    placeholderData: keepPreviousData,
  });

  const allIssues = query.data?.pages.flatMap(page => page.results) ?? [];

  const total = query.data?.pages[0]?.total ?? 0;

  const invalidateIssues = () => {
    queryClient.invalidateQueries({
      queryKey: issuesQueryKeys.all,
    });
  };

  return {
    issues: allIssues,
    total,
    hasMore: query.hasNextPage ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    isPlaceholderData: query.isPlaceholderData,
    error: query.error,
    isError: query.isError,
    fetchNextPage: query.fetchNextPage,
    refetch: query.refetch,
    invalidateIssues,
  };
};

export type { IssueApiData };
