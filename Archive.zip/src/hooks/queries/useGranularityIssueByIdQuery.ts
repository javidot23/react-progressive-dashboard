import { useQuery } from "@tanstack/react-query";
import { fetchGranularityIssueById } from "@/services/issueService";

export const granularityIssueByIdQueryKeys = {
  all: ["granularity-issue-by-id"] as const,
  detail: (issueId: number | string) => [...granularityIssueByIdQueryKeys.all, issueId] as const,
};

interface UseGranularityIssueByIdQueryParams {
  issueId?: number;
  enabled?: boolean;
}

/** One issue at granularity — GET /issue/<id>/ typed as the granularity serializer. */
export function useGranularityIssueByIdQuery({ issueId, enabled = true }: UseGranularityIssueByIdQueryParams) {
  const query = useQuery({
    queryKey: granularityIssueByIdQueryKeys.detail(issueId ?? ""),
    queryFn: ({ signal }) => fetchGranularityIssueById(issueId!, signal),
    enabled: enabled && !!issueId,
  });

  return {
    issue: query.data,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    error: query.error,
    refetch: query.refetch,
  };
}

export default useGranularityIssueByIdQuery;
