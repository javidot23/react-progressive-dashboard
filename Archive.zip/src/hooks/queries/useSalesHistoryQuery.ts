import { useMemo } from "react";
import { infiniteQueryOptions, keepPreviousData, useInfiniteQuery } from "@tanstack/react-query";
import { billingTransactionService, type SalesHistoryItem, type SalesHistoryQueryParams } from "@/lib/apiServices";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export type SalesHistoryFilters = Omit<SalesHistoryQueryParams, "limit" | "offset">;

export const salesHistoryQueryKeys = {
  all: ["sales-history"] as const,
  lists: () => [...salesHistoryQueryKeys.all, "list"] as const,
  infinite: (filters: SalesHistoryFilters, pageSize: number, globalFiltersVersion: number) =>
    [...salesHistoryQueryKeys.lists(), "infinite", { ...filters, pageSize, globalFiltersVersion }] as const,
} as const;

export type SalesHistoryPage = {
  results: SalesHistoryItem[];
  count: number;
  next: string | null;
};

const emptySalesHistory: SalesHistoryItem[] = [];

export function salesHistoryInfiniteQueryOptions(filters: SalesHistoryFilters, pageSize: number, globalFiltersVersion: number) {
  return infiniteQueryOptions({
    queryKey: salesHistoryQueryKeys.infinite(filters, pageSize, globalFiltersVersion),
    queryFn: async ({ pageParam, signal }): Promise<SalesHistoryPage> => {
      const response = await billingTransactionService.getSalesHistory(
        { ...filters, limit: pageSize, offset: pageParam },
        { signal }
      );

      if (!response.data.success) {
        throw new Error(response.data.message || response.data.error || "Failed to fetch sales history");
      }

      const page = response.data.data;
      return {
        results: page.results ?? [],
        count: page.count ?? 0,
        next: page.next ?? null,
      };
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage.next) return undefined;
      const loaded = allPages.reduce((sum, page) => sum + page.results.length, 0);
      return loaded < lastPage.count ? loaded : undefined;
    },
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
  });
}

export type UseSalesHistoryInfiniteQueryParams = {
  pageSize?: number;
  search?: string;
  ordering?: string;
  filters?: Omit<SalesHistoryFilters, "search" | "ordering">;
  enabled?: boolean;
};

export function useSalesHistoryInfiniteQuery({
  pageSize = 25,
  search = "",
  ordering = "-sales_quantity",
  filters: extraFilters = {},
  enabled = true,
}: UseSalesHistoryInfiniteQueryParams = {}) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const filters: SalesHistoryFilters = {
    ...extraFilters,
    ...(search.trim() ? { search: search.trim() } : {}),
    ...(ordering.trim() ? { ordering: ordering.trim() } : {}),
  };

  const query = useInfiniteQuery({
    ...salesHistoryInfiniteQueryOptions(filters, pageSize, globalFiltersVersion),
    enabled,
  });

  const pages = query.data?.pages;
  const data = useMemo(() => pages?.flatMap(page => page.results) ?? emptySalesHistory, [pages]);

  return {
    data,
    total: pages?.[0]?.count ?? 0,
    hasNextPage: query.hasNextPage,
    fetchNextPage: query.fetchNextPage,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
