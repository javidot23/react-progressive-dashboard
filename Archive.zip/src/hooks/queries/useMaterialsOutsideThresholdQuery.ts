import { useMemo } from "react";
import { infiniteQueryOptions, keepPreviousData, useInfiniteQuery } from "@tanstack/react-query";
import {
  materialsLowInventoryService,
  type MaterialsLowInventoryFilters,
  type MaterialsLowInventoryResponse,
} from "@/lib/apiServices";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export type MaterialsLowInventoryItem = MaterialsLowInventoryResponse["data"]["results"][number];

export type MaterialsOutsideThresholdFilters = Omit<MaterialsLowInventoryFilters, "limit" | "offset">;

export const materialsOutsideThresholdQueryKeys = {
  all: ["materials-outside-threshold"] as const,
  lists: () => [...materialsOutsideThresholdQueryKeys.all, "list"] as const,
  infinite: (filters: MaterialsOutsideThresholdFilters, pageSize: number, globalFiltersVersion: number) =>
    [...materialsOutsideThresholdQueryKeys.lists(), "infinite", { ...filters, pageSize, globalFiltersVersion }] as const,
} as const;

export type MaterialsOutsideThresholdPage = {
  results: MaterialsLowInventoryItem[];
  count: number;
  next: string | null;
};

const emptyMaterials: MaterialsLowInventoryItem[] = [];

export function materialsOutsideThresholdInfiniteQueryOptions(
  filters: MaterialsOutsideThresholdFilters,
  pageSize: number,
  globalFiltersVersion: number
) {
  return infiniteQueryOptions({
    queryKey: materialsOutsideThresholdQueryKeys.infinite(filters, pageSize, globalFiltersVersion),
    queryFn: async ({ pageParam, signal }): Promise<MaterialsOutsideThresholdPage> => {
      const response = await materialsLowInventoryService.getMaterialsLowInventory(
        { ...filters, limit: pageSize, offset: pageParam },
        signal
      );

      if (!response.data.success) {
        throw new Error("Failed to fetch products outside threshold");
      }

      const page = response.data.data;
      return {
        results: page.results ?? [],
        count: page.count ?? 0,
        next: page.next ?? null,
      };
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage.next) return undefined;
      const loaded = allPages.reduce((sum, page) => sum + page.results.length, 0);
      return loaded < lastPage.count ? loaded : undefined;
    },
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
  });
}

export type UseMaterialsOutsideThresholdInfiniteQueryParams = {
  pageSize?: number;
  search?: string;
  ordering?: string;
  filters?: Omit<MaterialsOutsideThresholdFilters, "material" | "ordering">;
  enabled?: boolean;
};

export function useMaterialsOutsideThresholdInfiniteQuery({
  pageSize = 25,
  search = "",
  ordering = "-dc_count",
  filters: extraFilters = {},
  enabled = true,
}: UseMaterialsOutsideThresholdInfiniteQueryParams = {}) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const filters: MaterialsOutsideThresholdFilters = {
    ...(search.trim() ? { material: search.trim() } : {}),
    ...extraFilters,
    ...(ordering.trim() ? { ordering: ordering.trim() } : {}),
  };

  const query = useInfiniteQuery({
    ...materialsOutsideThresholdInfiniteQueryOptions(filters, pageSize, globalFiltersVersion),
    enabled,
  });

  const pages = query.data?.pages;
  const data = useMemo(() => pages?.flatMap(page => page.results) ?? emptyMaterials, [pages]);

  return {
    data,
    total: pages?.[0]?.count ?? 0,
    hasNextPage: query.hasNextPage,
    fetchNextPage: query.fetchNextPage,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
