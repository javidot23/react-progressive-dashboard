import { useQuery } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import { isIncompleteWeek, weekBoundsFromStartDateString } from "@/lib/incompleteWeek";
import { formatUsShortMonthDayFromYmd } from "@/lib/usFormat";

export const weeklyOutboundUnfilledTrendQueryKeys = {
  all: ["weekly-outbound-unfilled-trend"] as const,
};

export interface WeeklyUnfilledTrendPoint {
  week: string;
  weekStart: string;
  unfilledPercentage: number;
  isIncompleteWeek: boolean;
}

function mapWeeklyRows(
  rows: Array<{
    week_start: string;
    outbound_fill_rate: number;
  }>
): WeeklyUnfilledTrendPoint[] {
  return rows.map(row => {
    const { weekStart, weekEnd } = weekBoundsFromStartDateString(row.week_start);
    const fillRate = Number(row.outbound_fill_rate) || 0;
    const unfilledPercentage = Math.max(0, Math.min(100, Math.round(100 - fillRate)));

    return {
      week: formatUsShortMonthDayFromYmd(row.week_start),
      weekStart: row.week_start,
      unfilledPercentage,
      isIncompleteWeek: isIncompleteWeek(weekStart, weekEnd),
    };
  });
}

export function useWeeklyOutboundUnfilledTrendQuery() {
  const query = useQuery({
    queryKey: weeklyOutboundUnfilledTrendQueryKeys.all,
    queryFn: async ({ signal }) => {
      const response = await apiClient.get("/demand-forecast/weekly-inbound-outbound-performance/", {
        signal,
      });

      if (!response.data.success || !Array.isArray(response.data.data)) {
        throw new Error("Failed to load weekly outbound unfilled trend");
      }

      return mapWeeklyRows(response.data.data);
    },
  });

  return {
    chartData: query.data ?? [],
    isLoading: query.isLoading,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}
