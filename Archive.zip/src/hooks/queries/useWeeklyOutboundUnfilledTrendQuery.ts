import { useQuery } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";
import { isIncompleteWeek, weekBoundsFromStartDateString } from "@/lib/incompleteWeek";
import { formatUsShortMonthDayFromYmd } from "@/lib/usFormat";

export const weeklyOutboundUnfilledTrendQueryKeys = {
  all: ["weekly-outbound-unfilled-trend"] as const,
  trend: (globalFiltersVersion: number) => [...weeklyOutboundUnfilledTrendQueryKeys.all, { globalFiltersVersion }] as const,
};

export interface WeeklyUnfilledTrendPoint {
  week: string;
  weekStart: string;
  unfilledPercentage: number;
  isIncompleteWeek: boolean;
}

function normalizeRateToPercentage(value: unknown): number {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue)) return 0;

  const percentage = numericValue >= 0 && numericValue <= 1 ? numericValue * 100 : numericValue;
  return Math.max(0, Math.min(100, percentage));
}

export function mapWeeklyOutboundUnfilledRows(
  rows: Array<{
    week_start: string;
    outbound_fill_rate: number;
  }>
): WeeklyUnfilledTrendPoint[] {
  return rows
    .map(row => {
      const { weekStart, weekEnd } = weekBoundsFromStartDateString(row.week_start);
      const fillRatePercentage = normalizeRateToPercentage(row.outbound_fill_rate);
      const unfilledPercentage = Number((100 - fillRatePercentage).toFixed(2));

      return {
        week: formatUsShortMonthDayFromYmd(row.week_start),
        weekStart: row.week_start,
        unfilledPercentage,
        isIncompleteWeek: isIncompleteWeek(weekStart, weekEnd),
      };
    })
    .sort((left, right) => left.weekStart.localeCompare(right.weekStart));
}

export function useWeeklyOutboundUnfilledTrendQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery({
    queryKey: weeklyOutboundUnfilledTrendQueryKeys.trend(globalFiltersVersion),
    queryFn: async ({ signal }) => {
      const response = await apiClient.get("/demand-forecast/weekly-inbound-outbound-performance/", {
        signal,
      });

      if (!response.data.success || !Array.isArray(response.data.data)) {
        throw new Error("Failed to load weekly outbound unfilled trend");
      }

      return mapWeeklyOutboundUnfilledRows(response.data.data);
    },
  });

  return {
    chartData: query.data ?? [],
    isLoading: query.isLoading,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}
