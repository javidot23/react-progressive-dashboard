import { useCallback, useMemo, useState } from "react";
import { queryOptions, useInfiniteQuery, useQuery, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import { orderTransactionService } from "@/lib/apiServices";
import { getManageSalesOverviewCsParams } from "@/lib/csScheduleFilter";
import { getRolling90DayInclusiveApiParams } from "@/lib/orderRolling90Days";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";
import { useManageSalesCsFilterVersion } from "@/hooks/useManageSalesCsFilterListener";
import type {
  PlantOrderStatsData,
  SalesComparisonData,
  FulfillmentTrendData,
  WeeklyPerformanceData,
  FilledOrderedUnitsData,
  MaterialGroupUnitsData,
  ClassOfTradeFilledRateData,
  DemandTrendData,
  MaterialOmitCountsData,
  InventoryBandsData,
  PlantLeadTimeData,
  MaterialOrderQuantitiesData,
  MaterialOrderQuantitiesMtdData,
  CustomerOrderQuantitiesData,
  PurchaseOrderDetailData,
  MaterialWithContractSalesData,
} from "@/lib/types";

export const manageDashboardQueryKeys = {
  all: ["manage-dashboard"] as const,
  planOperations: () => [...manageDashboardQueryKeys.all, "plan-operations"] as const,
  materialOmitCounts: () => [...manageDashboardQueryKeys.all, "material-omit-counts"] as const,
  inventoryBands: (globalFiltersVersion: number) =>
    [...manageDashboardQueryKeys.all, "inventory-bands", { globalFiltersVersion }] as const,
  plantLeadTimes: () => [...manageDashboardQueryKeys.all, "plant-lead-times"] as const,
  plantOrderStats: (globalFiltersVersion: number, limit: number) =>
    [...manageDashboardQueryKeys.all, "plant-order-stats", { globalFiltersVersion, limit }] as const,
  salesComparisonByMonth: (globalFiltersVersion: number, csFilterVersion: number) =>
    [...manageDashboardQueryKeys.all, "sales-comparison-by-month", { globalFiltersVersion, csFilterVersion }] as const,
  fulfillmentTrend: (globalFiltersVersion: number) =>
    [...manageDashboardQueryKeys.all, "fulfillment-trend", { globalFiltersVersion }] as const,
  weeklyPerformance: (globalFiltersVersion: number) =>
    [...manageDashboardQueryKeys.all, "weekly-performance", { globalFiltersVersion }] as const,
  filledOrderedUnits: (globalFiltersVersion: number) =>
    [...manageDashboardQueryKeys.all, "filled-ordered-units", { globalFiltersVersion }] as const,
  classOfTradeFilledRate: (globalFiltersVersion: number) =>
    [...manageDashboardQueryKeys.all, "class-of-trade-filled-rate", { globalFiltersVersion }] as const,
  demandTrendData: (globalFiltersVersion: number) =>
    [...manageDashboardQueryKeys.all, "demand-trend-data", { globalFiltersVersion }] as const,
  materialGroupUnitsData: (globalFiltersVersion: number) =>
    [...manageDashboardQueryKeys.all, "material-group-units-data", { globalFiltersVersion }] as const,
  materialSalesData: (globalFiltersVersion: number, csFilterVersion: number) =>
    [...manageDashboardQueryKeys.all, "material-sales-data", { globalFiltersVersion, csFilterVersion }] as const,
  contractSalesData: (globalFiltersVersion: number, csFilterVersion: number, limit: number) =>
    [...manageDashboardQueryKeys.all, "contract-sales-data", { globalFiltersVersion, csFilterVersion, limit }] as const,
  corporateSalesData: (globalFiltersVersion: number, csFilterVersion: number) =>
    [...manageDashboardQueryKeys.all, "corporate-sales-data", { globalFiltersVersion, csFilterVersion }] as const,
  stateSalesData: (globalFiltersVersion: number, csFilterVersion: number) =>
    [...manageDashboardQueryKeys.all, "state-sales-data", { globalFiltersVersion, csFilterVersion }] as const,
  materialWithContractSalesData: (globalFiltersVersion: number, csFilterVersion: number, limit: number) =>
    [...manageDashboardQueryKeys.all, "material-with-contract-sales", { globalFiltersVersion, csFilterVersion, limit }] as const,
  purchaseOrderDetail: (poNumber: string) => [...manageDashboardQueryKeys.all, "purchase-order-detail", poNumber] as const,
  materialOrderQuantities: (globalFiltersVersion: number, limit: number, offset: number, ordering: string) =>
    [...manageDashboardQueryKeys.all, "material-order-quantities", { globalFiltersVersion, limit, offset, ordering }] as const,
  materialOrderQuantitiesMtd: (globalFiltersVersion: number, limit: number, offset: number, ordering?: string) =>
    [
      ...manageDashboardQueryKeys.all,
      "material-order-quantities-mtd",
      { globalFiltersVersion, limit, offset, ordering },
    ] as const,
  customerOrderQuantities: (globalFiltersVersion: number, limit: number, offset: number, ordering: string) =>
    [...manageDashboardQueryKeys.all, "customer-order-quantities", { globalFiltersVersion, limit, offset, ordering }] as const,
} as const;

type PaginatedApiResponse<T> = {
  success?: boolean;
  data?: {
    results?: T[];
    count?: number;
    next?: string | null;
  };
};

type PaginatedPageData = {
  data?: { results?: unknown[]; count?: number; next?: string | null };
};

function requireArrayData<T>(payload: unknown, errorMessage: string): { data: T[] } {
  if (typeof payload !== "object" || payload === null) {
    throw new Error(errorMessage);
  }

  const response = payload as { success?: unknown; data?: unknown };
  if (response.success === false || !Array.isArray(response.data)) {
    throw new Error(errorMessage);
  }

  return payload as { data: T[] };
}

function requirePaginatedData<T>(payload: unknown, errorMessage: string): T {
  if (typeof payload !== "object" || payload === null) {
    throw new Error(errorMessage);
  }

  const response = payload as {
    success?: unknown;
    data?: { count?: unknown; next?: unknown; previous?: unknown; results?: unknown };
  };
  const data = response.data;
  if (
    response.success === false ||
    !data ||
    typeof data.count !== "number" ||
    !Array.isArray(data.results) ||
    !(data.next == null || typeof data.next === "string") ||
    !(data.previous == null || typeof data.previous === "string")
  ) {
    throw new Error(errorMessage);
  }

  return payload as T;
}

function mergeInfinitePages<T extends PaginatedPageData>(pages: T[] | undefined, hasNextPage: boolean): T | null {
  if (!pages?.length) return null;
  const firstPage = pages[0];
  const allResults = pages.flatMap(page => page?.data?.results ?? []);
  const lastPage = pages[pages.length - 1];
  return {
    ...firstPage,
    data: {
      ...firstPage.data,
      results: allResults,
      count: lastPage?.data?.count ?? 0,
      next: hasNextPage ? (lastPage?.data?.next ?? "more") : null,
    },
  } as T;
}

// --- queryOptions factories ---

export function planOperationsQueryOptions() {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.planOperations(),
    queryFn: async ({ signal }) => {
      const response = await apiClient.get("/material/forecasted-demand/", { signal });
      return { forecastedDemand: response.data };
    },
  });
}

export function materialOmitCountsQueryOptions() {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.materialOmitCounts(),
    queryFn: async ({ signal }): Promise<MaterialOmitCountsData> => {
      const response = await apiClient.get("/service-level/material-omit-counts-this-year/", { signal });
      return response.data;
    },
  });
}

export function inventoryBandsQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.inventoryBands(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<InventoryBandsData> => {
      const response = await apiClient.get("/demand-forecast/inventory-bands/", { signal });
      return response.data;
    },
  });
}

export function plantLeadTimesQueryOptions() {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.plantLeadTimes(),
    queryFn: async ({ signal }): Promise<PlantLeadTimeData> => {
      const response = await apiClient.get("/plant/?limit=10&offset=0", { signal });
      return response.data;
    },
  });
}

export function salesComparisonByMonthQueryOptions(globalFiltersVersion: number, csFilterVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.salesComparisonByMonth(globalFiltersVersion, csFilterVersion),
    queryFn: async ({ signal }): Promise<SalesComparisonData> => {
      const response = await apiClient.get("/order-transaction-aggregated/sales-comparison-by-month/", {
        params: getManageSalesOverviewCsParams(),
        signal,
      });
      return response.data;
    },
  });
}

export function fulfillmentTrendQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.fulfillmentTrend(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<FulfillmentTrendData> => {
      const response = await apiClient.get("/order-transaction/fulfillment/", { signal });
      return response.data;
    },
  });
}

export function weeklyPerformanceQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.weeklyPerformance(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<WeeklyPerformanceData> => {
      const response = await apiClient.get("/demand-forecast/weekly-performance/", { signal });
      return requireArrayData<WeeklyPerformanceData["data"][number]>(response.data, "Failed to load weekly demand performance");
    },
  });
}

export function filledOrderedUnitsQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.filledOrderedUnits(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<FilledOrderedUnitsData> => {
      const response = await apiClient.get("/order-transaction/material-group-units/", { signal });
      return requireArrayData<FilledOrderedUnitsData["data"][number]>(response.data, "Failed to load material group units");
    },
  });
}

export function classOfTradeFilledRateQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.classOfTradeFilledRate(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<ClassOfTradeFilledRateData> => {
      const response = await apiClient.get("/order-transaction/class-of-trade-filled-rate/", {
        params: getRolling90DayInclusiveApiParams(),
        signal,
      });
      return requireArrayData<ClassOfTradeFilledRateData["data"][number]>(response.data, "Failed to load class of trade units");
    },
  });
}

export function demandTrendDataQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.demandTrendData(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<DemandTrendData> => {
      const response = await apiClient.get("/order-transaction/alt-serve-substituted-overall-stats/", {
        signal,
      });
      return requireArrayData<DemandTrendData["data"][number]>(response.data, "Failed to load customer demand trend");
    },
  });
}

export function materialGroupUnitsDataQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.materialGroupUnitsData(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<MaterialGroupUnitsData> => {
      const response = await apiClient.get("/order-transaction/material-group-units-weekly/", { signal });
      return requireArrayData<MaterialGroupUnitsData["data"][number]>(
        response.data,
        "Failed to load weekly material group units"
      );
    },
  });
}

export function materialSalesDataQueryOptions(globalFiltersVersion: number, csFilterVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.materialSalesData(globalFiltersVersion, csFilterVersion),
    queryFn: async ({ signal }) => {
      const response = await apiClient.get("/order-transaction/material-sales/?limit=10&offset=0", {
        params: getManageSalesOverviewCsParams(),
        signal,
      });
      const data = response.data;
      if (!data.success || !data.data || !Array.isArray(data.data.results)) {
        throw new Error("API response indicates failure or missing results");
      }
      return data.data.results as Array<{
        material_id: string;
        material_name: string;
        sales_amount: number;
      }>;
    },
  });
}

export function corporateSalesDataQueryOptions(globalFiltersVersion: number, csFilterVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.corporateSalesData(globalFiltersVersion, csFilterVersion),
    queryFn: async ({ signal }) => {
      const response = await apiClient.get("/order-transaction/corporate-sales/?limit=10&offset=0", {
        params: getManageSalesOverviewCsParams(),
        signal,
      });
      const data = response.data;
      if (!data.success || !data.data || !Array.isArray(data.data.results)) {
        throw new Error("API response indicates failure or missing results");
      }
      return data.data.results as Array<{
        corporate_id: string;
        corporate_name: string;
        sales_amount: number;
      }>;
    },
  });
}

export function stateSalesDataQueryOptions(globalFiltersVersion: number, csFilterVersion: number) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.stateSalesData(globalFiltersVersion, csFilterVersion),
    queryFn: async ({ signal }) => {
      const response = await apiClient.get("/order-transaction/state-sales/", {
        params: getManageSalesOverviewCsParams(),
        signal,
      });
      const data = response.data;
      if (!data.success || !data.data || !Array.isArray(data.data)) {
        throw new Error("API response indicates failure or missing results");
      }
      return data.data as Array<{ state: string; sales_amount: number }>;
    },
  });
}

export function purchaseOrderDetailQueryOptions(poNumber: string) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.purchaseOrderDetail(poNumber),
    queryFn: async ({ signal }): Promise<PurchaseOrderDetailData[]> => {
      const response = await apiClient.get(`/purchase-order/${poNumber}/`, { signal });
      const data = response.data;
      if (!data.success || !data.data) {
        throw new Error("API response indicates failure or missing data");
      }
      return data.data;
    },
    enabled: Boolean(poNumber),
  });
}

export function materialOrderQuantitiesQueryOptions(
  globalFiltersVersion: number,
  limit: number,
  offset: number,
  ordering: string
) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.materialOrderQuantities(globalFiltersVersion, limit, offset, ordering),
    queryFn: async ({ signal }): Promise<MaterialOrderQuantitiesData> => {
      const response = await apiClient.get("/order-transaction/material-order-quantities/", {
        params: { limit, offset, ordering },
        signal,
      });
      return requirePaginatedData<MaterialOrderQuantitiesData>(response.data, "Failed to load material order quantities");
    },
    placeholderData: keepPreviousData,
  });
}

export function materialOrderQuantitiesMtdQueryOptions(
  globalFiltersVersion: number,
  limit: number,
  offset: number,
  ordering?: string
) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.materialOrderQuantitiesMtd(globalFiltersVersion, limit, offset, ordering),
    queryFn: async ({ signal }): Promise<MaterialOrderQuantitiesMtdData> => {
      const response = await apiClient.get("/order-transaction/material-order-quantities-mtd/", {
        params: {
          limit,
          offset,
          ...(ordering ? { ordering } : {}),
        },
        signal,
      });
      return requirePaginatedData<MaterialOrderQuantitiesMtdData>(response.data, "Failed to load MTD material order quantities");
    },
    placeholderData: keepPreviousData,
  });
}

export function customerOrderQuantitiesQueryOptions(
  globalFiltersVersion: number,
  limit: number,
  offset: number,
  ordering: string
) {
  return queryOptions({
    queryKey: manageDashboardQueryKeys.customerOrderQuantities(globalFiltersVersion, limit, offset, ordering),
    queryFn: async ({ signal }): Promise<CustomerOrderQuantitiesData> => {
      const response = await apiClient.get("/order-transaction/sold-to-party-order-quantities/", {
        params: {
          limit,
          offset,
          ordering,
          ...getRolling90DayInclusiveApiParams(),
        },
        signal,
      });
      return requirePaginatedData<CustomerOrderQuantitiesData>(response.data, "Failed to load customer order quantities");
    },
    placeholderData: keepPreviousData,
  });
}

// --- useQuery hooks ---

export function usePlanOperationsDataQuery() {
  const { data, isPending, error, refetch } = useQuery(planOperationsQueryOptions());
  return {
    planOperationsData: data ?? { forecastedDemand: null },
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useMaterialOmitCountsQuery() {
  const { data, isPending, error, refetch } = useQuery(materialOmitCountsQueryOptions());
  return {
    materialOmitCounts: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useInventoryBandsQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const { data, isPending, error, refetch, dataUpdatedAt } = useQuery(inventoryBandsQueryOptions(globalFiltersVersion));
  return {
    inventoryBands: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
    lastFetched: dataUpdatedAt || null,
  };
}

export function usePlantLeadTimesQuery() {
  const { data, isPending, error, refetch } = useQuery(plantLeadTimesQueryOptions());
  return {
    plantLeadTimes: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function usePlantOrderStatsQuery(defaultLimit = 50) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const queryClient = useQueryClient();
  const [limit, setLimit] = useState(defaultLimit);

  const { data, isPending, error, refetch, dataUpdatedAt, fetchNextPage, hasNextPage, isFetchingNextPage } = useInfiniteQuery({
    queryKey: manageDashboardQueryKeys.plantOrderStats(globalFiltersVersion, limit),
    queryFn: async ({ pageParam = 0, signal }) => {
      const response = await apiClient.get<PlantOrderStatsData>(
        `/order-transaction/plant-order-stats/?limit=${limit}&offset=${pageParam}`,
        { signal }
      );
      return response.data;
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) => {
      const pageData = (lastPage as PaginatedPageData)?.data;
      if (pageData?.next == null) return undefined;
      return allPages.reduce((sum, page) => sum + (page?.data?.results?.length ?? 0), 0);
    },
  });

  const plantOrderStats = useMemo(() => mergeInfinitePages(data?.pages, Boolean(hasNextPage)), [data?.pages, hasNextPage]);

  const pagination = useMemo(() => {
    const resultsCount = data?.pages.flatMap(page => page?.data?.results ?? []).length ?? 0;
    const lastPageData = (data?.pages[data.pages.length - 1] as PaginatedPageData)?.data;
    const totalCount = lastPageData?.count ?? 0;
    return {
      hasMore: hasNextPage ?? false,
      offset: resultsCount,
      limit,
      totalCount,
      isLoadingMore: isFetchingNextPage,
    };
  }, [data?.pages, hasNextPage, isFetchingNextPage, limit]);

  const fetchPlantOrderStats = useCallback(
    async (nextLimit: number = defaultLimit, offset: number = 0) => {
      if (nextLimit !== limit) {
        setLimit(nextLimit);
        return;
      }
      if (offset === 0) {
        await queryClient.resetQueries({
          queryKey: manageDashboardQueryKeys.plantOrderStats(globalFiltersVersion, nextLimit),
        });
        return;
      }
      await refetch();
    },
    [defaultLimit, limit, globalFiltersVersion, queryClient, refetch]
  );

  const fetchMorePlantOrderStats = useCallback(async () => {
    if (!hasNextPage || isFetchingNextPage) return;
    await fetchNextPage();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  return {
    plantOrderStats,
    loading: isPending && !data,
    error: error?.message ?? null,
    refetch,
    fetchPlantOrderStats,
    fetchMorePlantOrderStats,
    pagination,
    lastFetched: dataUpdatedAt || null,
  };
}

export function useSalesComparisonByMonthQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const csFilterVersion = useManageSalesCsFilterVersion();
  const { data, isPending, error, refetch } = useQuery(salesComparisonByMonthQueryOptions(globalFiltersVersion, csFilterVersion));
  return {
    salesComparisonByMonth: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useFulfillmentTrendQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const { data, isPending, error, refetch } = useQuery(fulfillmentTrendQueryOptions(globalFiltersVersion));
  return {
    fulfillmentTrend: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useWeeklyPerformanceQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const { data, isPending, error, refetch } = useQuery(weeklyPerformanceQueryOptions(globalFiltersVersion));
  return {
    weeklyPerformance: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useFilledOrderedUnitsQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const { data, isPending, error, refetch } = useQuery(filledOrderedUnitsQueryOptions(globalFiltersVersion));
  return {
    filledOrderedUnits: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useClassOfTradeFilledRateQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const { data, isPending, error, refetch } = useQuery(classOfTradeFilledRateQueryOptions(globalFiltersVersion));
  return {
    classOfTradeFilledRate: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useDemandTrendDataQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const { data, isPending, error, refetch } = useQuery(demandTrendDataQueryOptions(globalFiltersVersion));
  return {
    demandTrendData: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useMaterialGroupUnitsDataQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const { data, isPending, error, refetch } = useQuery(materialGroupUnitsDataQueryOptions(globalFiltersVersion));
  return {
    materialGroupUnitsData: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useMaterialSalesDataQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const csFilterVersion = useManageSalesCsFilterVersion();
  const { data, isPending, error, refetch } = useQuery(materialSalesDataQueryOptions(globalFiltersVersion, csFilterVersion));
  return {
    materialSalesData: data ?? [],
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useContractSalesDataQuery(defaultLimit = 20) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const csFilterVersion = useManageSalesCsFilterVersion();
  const queryClient = useQueryClient();
  const [limit, setLimit] = useState(defaultLimit);

  const { data, isPending, error, refetch, dataUpdatedAt, fetchNextPage, hasNextPage, isFetchingNextPage } = useInfiniteQuery({
    queryKey: manageDashboardQueryKeys.contractSalesData(globalFiltersVersion, csFilterVersion, limit),
    queryFn: async ({ pageParam = 0, signal }) => {
      const response = await apiClient.get<PaginatedApiResponse<{ name: string; total_sales_qty: number }>>(
        `/order-transaction/contract-sales/?limit=${limit}&offset=${pageParam}`,
        { params: getManageSalesOverviewCsParams(), signal }
      );
      return response.data;
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) => {
      if (lastPage?.data?.next == null) return undefined;
      return allPages.reduce((sum, page) => sum + (page?.data?.results?.length ?? 0), 0);
    },
  });

  const contractSalesData = useMemo(() => {
    const merged = mergeInfinitePages(data?.pages, Boolean(hasNextPage));
    return merged ? { data: merged.data } : null;
  }, [data?.pages, hasNextPage]);

  const pagination = useMemo(() => {
    const resultsCount = data?.pages.flatMap(page => page?.data?.results ?? []).length ?? 0;
    const totalCount = data?.pages[data.pages.length - 1]?.data?.count ?? 0;
    return {
      hasMore: hasNextPage ?? false,
      offset: resultsCount,
      limit,
      totalCount,
      isLoadingMore: isFetchingNextPage,
    };
  }, [data?.pages, hasNextPage, isFetchingNextPage, limit]);

  const fetchContractSalesData = useCallback(
    async (nextLimit: number = defaultLimit, offset: number = 0) => {
      if (nextLimit !== limit) {
        setLimit(nextLimit);
        return;
      }
      if (offset === 0) {
        await queryClient.resetQueries({
          queryKey: manageDashboardQueryKeys.contractSalesData(globalFiltersVersion, csFilterVersion, nextLimit),
        });
        return;
      }
      await refetch();
    },
    [csFilterVersion, defaultLimit, globalFiltersVersion, limit, queryClient, refetch]
  );

  const fetchMoreContractSalesData = useCallback(async () => {
    if (!hasNextPage || isFetchingNextPage) return;
    await fetchNextPage();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  return {
    contractSalesData,
    loading: isPending && !data,
    error: error?.message ?? null,
    refetch,
    fetchContractSalesData,
    fetchMoreContractSalesData,
    pagination,
    lastFetched: dataUpdatedAt || null,
  };
}

export function useCorporateSalesDataQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const csFilterVersion = useManageSalesCsFilterVersion();
  const { data, isPending, error, refetch } = useQuery(corporateSalesDataQueryOptions(globalFiltersVersion, csFilterVersion));
  return {
    corporateSalesData: data ?? [],
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useStateSalesDataQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const csFilterVersion = useManageSalesCsFilterVersion();
  const { data, isPending, error, refetch } = useQuery(stateSalesDataQueryOptions(globalFiltersVersion, csFilterVersion));
  return {
    stateSalesData: data ?? [],
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function useMaterialWithContractSalesDataQuery(defaultLimit = 20) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const csFilterVersion = useManageSalesCsFilterVersion();
  const queryClient = useQueryClient();
  const [limit, setLimit] = useState(defaultLimit);

  const { data, isPending, error, refetch, dataUpdatedAt, fetchNextPage, hasNextPage, isFetchingNextPage } = useInfiniteQuery({
    queryKey: manageDashboardQueryKeys.materialWithContractSalesData(globalFiltersVersion, csFilterVersion, limit),
    queryFn: async ({ pageParam = 0, signal }) => {
      const response = await apiClient.get<{
        success?: boolean;
        data?: MaterialWithContractSalesData & { results?: unknown[]; next?: string | null; count?: number };
      }>(`/order-transaction/material-with-sales-group-sales/?limit=${limit}&offset=${pageParam}`, {
        params: getManageSalesOverviewCsParams(),
        signal,
      });
      return response.data;
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) => {
      if (lastPage?.data?.next == null) return undefined;
      return allPages.reduce((sum, page) => sum + (page?.data?.results?.length ?? 0), 0);
    },
  });

  const materialWithContractSalesData = useMemo((): MaterialWithContractSalesData | null => {
    const pages = data?.pages;
    if (!pages?.length) return null;
    const firstData = pages[0]?.data;
    if (!firstData) return null;
    const allResults = pages.flatMap(
      page => (page?.data?.results ?? []) as NonNullable<MaterialWithContractSalesData["results"]>
    );
    const lastData = pages[pages.length - 1]?.data;
    return {
      ...firstData,
      results: allResults,
      count: lastData?.count ?? 0,
      next: hasNextPage ? (lastData?.next ?? "more") : null,
    };
  }, [data?.pages, hasNextPage]);

  const pagination = useMemo(() => {
    const resultsCount = materialWithContractSalesData?.results?.length ?? 0;
    return {
      hasMore: hasNextPage ?? false,
      offset: resultsCount,
      limit,
      totalCount: materialWithContractSalesData?.count ?? 0,
      isLoadingMore: isFetchingNextPage,
    };
  }, [materialWithContractSalesData, hasNextPage, isFetchingNextPage, limit]);

  const fetchMaterialWithContractSalesData = useCallback(
    async (nextLimit: number = defaultLimit, offset: number = 0) => {
      if (nextLimit !== limit) {
        setLimit(nextLimit);
        return;
      }
      if (offset === 0) {
        await queryClient.resetQueries({
          queryKey: manageDashboardQueryKeys.materialWithContractSalesData(globalFiltersVersion, csFilterVersion, nextLimit),
        });
        return;
      }
      await refetch();
    },
    [csFilterVersion, defaultLimit, globalFiltersVersion, limit, queryClient, refetch]
  );

  const fetchMoreMaterialWithContractSalesData = useCallback(async () => {
    if (!hasNextPage || isFetchingNextPage) return;
    await fetchNextPage();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  return {
    materialWithContractSalesData,
    loading: isPending && !data,
    error: error?.message ?? null,
    refetch,
    fetchMaterialWithContractSalesData,
    fetchMoreMaterialWithContractSalesData,
    pagination,
    lastFetched: dataUpdatedAt || null,
  };
}

export type SubstitutionAltServeKpisData = {
  total_materials: number;
  materials_with_substitution: number;
  substitution_percent: number;
  materials_with_alt_serve: number;
  alt_serve_percent: number;
};

export function substitutionAltServeKpisQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: [...manageDashboardQueryKeys.all, "substitution-alt-serve-kpis", { globalFiltersVersion }] as const,
    queryFn: async (): Promise<SubstitutionAltServeKpisData> => {
      const response = await orderTransactionService.getSubstitutionAltServeKPIs();
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error("Failed to fetch substitution and alt-serve KPIs");
    },
  });
}

export function useSubstitutionAltServeKpisQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const { data, isPending, error, refetch } = useQuery(substitutionAltServeKpisQueryOptions(globalFiltersVersion));
  return {
    kpis: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
  };
}

export function usePurchaseOrderDetailQuery(poNumber: string) {
  const [activePo, setActivePo] = useState<string | null>(null);
  const effectivePo = activePo ?? (poNumber || null);
  const { data, isPending, error, refetch } = useQuery({
    ...purchaseOrderDetailQueryOptions(effectivePo ?? ""),
    enabled: Boolean(effectivePo),
  });

  const fetchPurchaseOrderDetail = useCallback(async (nextPoNumber: string) => {
    setActivePo(nextPoNumber);
  }, []);

  return {
    purchaseOrderDetail: data ?? null,
    loading: isPending,
    error: error?.message ?? null,
    refetch,
    fetchPurchaseOrderDetail,
  };
}

export function useMaterialOrderQuantitiesQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const [params, setParams] = useState<{
    limit: number;
    offset: number;
    ordering: string;
    globalFiltersVersion: number;
  } | null>(null);

  const effectiveParams = useMemo(
    () =>
      params && params.globalFiltersVersion !== globalFiltersVersion ? { ...params, offset: 0, globalFiltersVersion } : params,
    [globalFiltersVersion, params]
  );

  const query = useQuery({
    ...materialOrderQuantitiesQueryOptions(
      globalFiltersVersion,
      effectiveParams?.limit ?? 10,
      effectiveParams?.offset ?? 0,
      effectiveParams?.ordering ?? "-total_order_qty"
    ),
    enabled: effectiveParams !== null,
  });

  const fetchMaterialOrderQuantities = useCallback(
    async (limit: number = 10, offset: number = 0, ordering: string = "-total_order_qty") => {
      setParams({ limit, offset, ordering, globalFiltersVersion });
    },
    [globalFiltersVersion]
  );

  const pagination = useMemo(() => {
    const data = query.data;
    const limit = effectiveParams?.limit ?? 10;
    const offset = effectiveParams?.offset ?? 0;
    return {
      hasMore: data?.data?.next != null,
      offset,
      limit,
      totalCount: data?.data?.count ?? 0,
      isLoadingMore: false,
      currentPage: Math.floor(offset / limit) + 1,
    };
  }, [effectiveParams, query.data]);

  return {
    materialOrderQuantities: query.data ?? null,
    loading: query.isPending,
    isUpdating: query.isFetching && query.isPlaceholderData,
    error: query.error?.message ?? null,
    refetch: query.refetch,
    fetchMaterialOrderQuantities,
    pagination,
  };
}

export function useMaterialOrderQuantitiesMtdQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const [params, setParams] = useState<{
    limit: number;
    offset: number;
    ordering?: string;
    globalFiltersVersion: number;
  } | null>(null);

  const effectiveParams = useMemo(
    () =>
      params && params.globalFiltersVersion !== globalFiltersVersion ? { ...params, offset: 0, globalFiltersVersion } : params,
    [globalFiltersVersion, params]
  );

  const query = useQuery({
    ...materialOrderQuantitiesMtdQueryOptions(
      globalFiltersVersion,
      effectiveParams?.limit ?? 10,
      effectiveParams?.offset ?? 0,
      effectiveParams?.ordering
    ),
    enabled: effectiveParams !== null,
  });

  const fetchMaterialOrderQuantitiesMtd = useCallback(
    async (limit: number = 10, offset: number = 0, ordering?: string) => {
      setParams({ limit, offset, ordering, globalFiltersVersion });
    },
    [globalFiltersVersion]
  );

  const pagination = useMemo(() => {
    const data = query.data;
    const limit = effectiveParams?.limit ?? 10;
    const offset = effectiveParams?.offset ?? 0;
    return {
      hasMore: data?.data?.next != null,
      offset,
      limit,
      totalCount: data?.data?.count ?? 0,
      isLoadingMore: false,
      currentPage: Math.floor(offset / limit) + 1,
    };
  }, [effectiveParams, query.data]);

  return {
    materialOrderQuantitiesMtd: query.data ?? null,
    loading: query.isPending,
    isUpdating: query.isFetching && query.isPlaceholderData,
    error: query.error?.message ?? null,
    refetch: query.refetch,
    fetchMaterialOrderQuantitiesMtd,
    pagination,
  };
}

export function useCustomerOrderQuantitiesQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const [params, setParams] = useState<{
    limit: number;
    offset: number;
    ordering: string;
    globalFiltersVersion: number;
  } | null>(null);

  const effectiveParams = useMemo(
    () =>
      params && params.globalFiltersVersion !== globalFiltersVersion ? { ...params, offset: 0, globalFiltersVersion } : params,
    [globalFiltersVersion, params]
  );

  const query = useQuery({
    ...customerOrderQuantitiesQueryOptions(
      globalFiltersVersion,
      effectiveParams?.limit ?? 10,
      effectiveParams?.offset ?? 0,
      effectiveParams?.ordering ?? "-total_order_qty"
    ),
    enabled: effectiveParams !== null,
  });

  const fetchCustomerOrderQuantities = useCallback(
    async (limit: number = 10, offset: number = 0, ordering: string = "-total_order_qty") => {
      setParams({ limit, offset, ordering, globalFiltersVersion });
    },
    [globalFiltersVersion]
  );

  const pagination = useMemo(() => {
    const data = query.data;
    const limit = effectiveParams?.limit ?? 10;
    const offset = effectiveParams?.offset ?? 0;
    return {
      hasMore: data?.data?.next != null,
      offset,
      limit,
      totalCount: data?.data?.count ?? 0,
      isLoadingMore: false,
      currentPage: Math.floor(offset / limit) + 1,
    };
  }, [effectiveParams, query.data]);

  return {
    customerOrderQuantities: query.data ?? null,
    loading: query.isPending,
    isUpdating: query.isFetching && query.isPlaceholderData,
    error: query.error?.message ?? null,
    refetch: query.refetch,
    fetchCustomerOrderQuantities,
    pagination,
  };
}
