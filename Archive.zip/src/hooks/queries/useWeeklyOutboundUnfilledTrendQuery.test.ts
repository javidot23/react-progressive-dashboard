import { mapWeeklyOutboundUnfilledRows } from "./useWeeklyOutboundUnfilledTrendQuery";

describe("mapWeeklyOutboundUnfilledRows", () => {
  it("normalizes fractional fill rates and preserves two-decimal unfilled precision", () => {
    const result = mapWeeklyOutboundUnfilledRows([
      { week_start: "2026-07-20", outbound_fill_rate: 0.75 },
      { week_start: "2026-07-27", outbound_fill_rate: 0.9344 },
    ]);

    expect(result.map(point => point.unfilledPercentage)).toEqual([25, 6.56]);
  });

  it("continues to support percentage-form fill rates and clamps invalid ranges", () => {
    const result = mapWeeklyOutboundUnfilledRows([
      { week_start: "2026-07-06", outbound_fill_rate: 71.35 },
      { week_start: "2026-07-13", outbound_fill_rate: 120 },
    ]);

    expect(result.map(point => point.unfilledPercentage)).toEqual([28.65, 0]);
  });

  it("sorts backend rows chronologically before consumers select the latest week", () => {
    const result = mapWeeklyOutboundUnfilledRows([
      { week_start: "2026-07-27", outbound_fill_rate: 0.9 },
      { week_start: "2026-07-06", outbound_fill_rate: 0.7 },
      { week_start: "2026-07-20", outbound_fill_rate: 0.8 },
    ]);

    expect(result.map(point => point.weekStart)).toEqual(["2026-07-06", "2026-07-20", "2026-07-27"]);
    expect(result[result.length - 1]?.unfilledPercentage).toBe(10);
  });
});
