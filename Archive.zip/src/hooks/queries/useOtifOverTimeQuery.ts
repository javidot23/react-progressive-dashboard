import { queryOptions, useQuery } from "@tanstack/react-query";
import {
  issuesService,
  type MaterialOtifTrendData,
  type WeeklyOtifTrendData,
} from "@/lib/apiServices";
import { dateToISO } from "@/lib/dateUtils";
import { formatUsShortMonthDayFromYmd } from "@/lib/usFormat";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const otifOverTimeQueryKeys = {
  all: ["otif-over-time"] as const,
  weekly: (globalFiltersVersion: number) =>
    [...otifOverTimeQueryKeys.all, "weekly", { globalFiltersVersion }] as const,
  material: (materialId: string, globalFiltersVersion: number) =>
    [...otifOverTimeQueryKeys.all, "material", materialId, { globalFiltersVersion }] as const,
} as const;

export interface OtifOverTimeWeeklyPoint {
  date: string;
  label: string;
  onTime: number;
  inFull: number;
  otifPercentage: number;
  week: number;
  year: number;
}

export interface OtifOverTimeMaterialPoint {
  date: string;
  label: string;
  onTime: number;
  inFull: number;
  otifPercentage: number;
  materialStatus: string;
  totalMaterials: number;
}

export type OtifOverTimePoint = OtifOverTimeWeeklyPoint | OtifOverTimeMaterialPoint;

function formatWeeklyLabel(week: number): string {
  return `W${week}`;
}

function formatMaterialLabel(date: string): string {
  return formatUsShortMonthDayFromYmd(date);
}

function transformWeeklyApiData(apiData: WeeklyOtifTrendData[]): OtifOverTimeWeeklyPoint[] {
  return apiData.map(item => {
    const date = new Date(item.year, 0, 1 + (item.week - 1) * 7);
    const otifPercentage = item.total_orders > 0 ? (item.otif_count / item.total_orders) * 100 : 0;

    return {
      date: dateToISO(date),
      label: formatWeeklyLabel(item.week),
      onTime: item.on_time_count,
      inFull: item.in_full_count,
      otifPercentage,
      week: item.week,
      year: item.year,
    };
  });
}

function toCount(value: number | string): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

export function transformMaterialApiData(apiData: MaterialOtifTrendData[]): OtifOverTimeMaterialPoint[] {
  return apiData.map(item => {
    const onTime = toCount(item.on_time_count);
    const inFull = toCount(item.in_full_count);
    const otifCount = toCount(item.otif_count);
    const totalMaterials = toCount(item.total_materials);
    const otifPercentage = totalMaterials > 0 ? (otifCount / totalMaterials) * 100 : 0;

    return {
      date: item.day,
      label: formatMaterialLabel(item.day),
      onTime,
      inFull,
      otifPercentage,
      materialStatus: item.material_status?.trim() || "N/A",
      totalMaterials,
    };
  });
}

export function weeklyOtifOverTimeQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: otifOverTimeQueryKeys.weekly(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<OtifOverTimePoint[]> => {
      const response = await issuesService.getWeeklyOtifTrends(signal);
      if (!response.data.success || !response.data.data) {
        throw new Error("Failed to fetch weekly OTIF trends");
      }
      return transformWeeklyApiData(response.data.data);
    },
  });
}

export function materialOtifOverTimeQueryOptions(materialId: string, globalFiltersVersion: number) {
  return queryOptions({
    queryKey: otifOverTimeQueryKeys.material(materialId, globalFiltersVersion),
    queryFn: async ({ signal }): Promise<OtifOverTimePoint[]> => {
      const response = await issuesService.getMaterialOtifTrends(parseInt(materialId, 10), signal);
      if (!response.data.success || !response.data.data) {
        throw new Error("Failed to fetch material OTIF trends");
      }
      return transformMaterialApiData(response.data.data);
    },
    enabled: !!materialId,
  });
}

interface UseOtifOverTimeQueryParams {
  materialId?: string;
}

export function useOtifOverTimeQuery({ materialId }: UseOtifOverTimeQueryParams = {}) {
  const globalFiltersVersion = useGlobalFiltersVersion();

  const weeklyQuery = useQuery({
    ...weeklyOtifOverTimeQueryOptions(globalFiltersVersion),
    enabled: !materialId,
  });

  const materialQuery = useQuery({
    ...materialOtifOverTimeQueryOptions(materialId ?? "", globalFiltersVersion),
    enabled: !!materialId,
  });

  const query = materialId ? materialQuery : weeklyQuery;

  return {
    chartData: query.data ?? [],
    isLoading: query.isPending,
    isFetched: query.isFetched,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}
