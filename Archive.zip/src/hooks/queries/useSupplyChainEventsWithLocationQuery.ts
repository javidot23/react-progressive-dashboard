import { useInfiniteQuery, useQuery, infiniteQueryOptions, queryOptions, keepPreviousData } from "@tanstack/react-query";
import { transformSupplyChainEventsResponse } from "@/stores/slices/transformers";
import type { SupplyChainEventDisplay } from "@/stores/slices/types";
import { supplyChainEventsService, type SupplyChainEventWithLocation } from "@/lib/apiServices";

export const supplyChainEventsQueryKeys = {
  all: ["supply-chain-events"] as const,
  withLocation: () => [...supplyChainEventsQueryKeys.all, "with-location"] as const,
  withLocationList: (params: { pageSize: number; status: string; hasLocation: boolean }) =>
    [...supplyChainEventsQueryKeys.withLocation(), params] as const,
  detail: (eventId: number | string) => [...supplyChainEventsQueryKeys.all, "detail", eventId] as const,
} as const;

const BATCH_SIZE = 50;
const DEFAULT_PARAMS = {
  pageSize: BATCH_SIZE,
  status: "OPEN",
  hasLocation: true,
};

export interface SupplyChainEventsWithLocationPage {
  results: SupplyChainEventWithLocation[];
  totalCount: number;
  offset: number;
}

export function supplyChainEventsWithLocationQueryOptions(
  params: {
    pageSize?: number;
    status?: string;
    hasLocation?: boolean;
  } = {}
) {
  const {
    pageSize = BATCH_SIZE,
    status = "OPEN",
    hasLocation = true,
  } = {
    ...DEFAULT_PARAMS,
    ...params,
  };

  return infiniteQueryOptions({
    queryKey: supplyChainEventsQueryKeys.withLocationList({
      pageSize,
      status,
      hasLocation,
    }),
    queryFn: async ({ pageParam = 0, signal }): Promise<SupplyChainEventsWithLocationPage> => {
      const response = await supplyChainEventsService.getEventsWithLocation(
        {
          limit: pageSize,
          offset: pageParam,
          status,
          has_location: hasLocation,
        },
        signal
      );

      const data = response.data;
      if (!data.success || !data.data) {
        return { results: [], totalCount: 0, offset: pageParam };
      }

      return {
        results: data.data.results ?? [],
        totalCount: data.data.count ?? 0,
        offset: pageParam,
      };
    },
    initialPageParam: 0,
    getNextPageParam: (
      lastPage: SupplyChainEventsWithLocationPage,
      allPages: SupplyChainEventsWithLocationPage[]
    ): number | undefined => {
      const totalLoaded = allPages.reduce((sum, p) => sum + p.results.length, 0);
      if (totalLoaded < lastPage.totalCount && lastPage.results.length > 0) {
        return lastPage.offset + lastPage.results.length;
      }
      return undefined;
    },
    placeholderData: keepPreviousData,
  });
}

interface UseSupplyChainEventsWithLocationQueryParams {
  pageSize?: number;
  status?: string;
  hasLocation?: boolean;
  enabled?: boolean;
}

export function useSupplyChainEventsWithLocationQuery({
  pageSize = BATCH_SIZE,
  status = "OPEN",
  hasLocation = true,
  enabled = true,
}: UseSupplyChainEventsWithLocationQueryParams = {}) {
  const options = supplyChainEventsWithLocationQueryOptions({
    pageSize,
    status,
    hasLocation,
  });

  const query = useInfiniteQuery({
    ...options,
    enabled,
  });

  const events = query.data?.pages.flatMap(page => page.results) ?? [];
  const totalCount = query.data?.pages[0]?.totalCount ?? 0;

  return {
    events,
    totalCount,
    hasMore: query.hasNextPage ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    isPlaceholderData: query.isPlaceholderData,
    error: query.error,
    isError: query.isError,
    fetchNextPage: query.fetchNextPage,
    refetch: query.refetch,
  };
}

export function latestSupplyChainEventsQueryOptions(limit: number) {
  return queryOptions({
    queryKey: [...supplyChainEventsQueryKeys.all, "latest", limit] as const,
    queryFn: async ({ signal }): Promise<SupplyChainEventDisplay[]> => {
      const response = await supplyChainEventsService.getLatestEvents(limit, signal);
      return transformSupplyChainEventsResponse(response.data);
    },
  });
}

export function useLatestSupplyChainEventsQuery(limit = 10) {
  const query = useQuery(latestSupplyChainEventsQueryOptions(limit));
  return {
    supplyChainEvents: query.data ?? [],
    isLoading: query.isPending,
    error: query.error?.message ?? null,
  };
}
