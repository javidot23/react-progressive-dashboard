import { queryOptions, useQuery } from "@tanstack/react-query";
import { supplyChainEventsService } from "@/lib/apiServices";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const topRiskiestMaterialsEventsQueryKeys = {
  all: ["top-riskiest-materials-events"] as const,
  list: (globalFiltersVersion: number) =>
    [...topRiskiestMaterialsEventsQueryKeys.all, { globalFiltersVersion }] as const,
};

export function topRiskiestMaterialsEventsQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: topRiskiestMaterialsEventsQueryKeys.list(globalFiltersVersion),
    queryFn: async ({ signal }) => {
      const response = await supplyChainEventsService.getTopRiskiestMaterialsEvents(signal);
      const responseData = response.data.data;
      return Array.isArray(responseData) ? responseData : responseData?.events || [];
    },
  });
}

export function useTopRiskiestMaterialsEventsQuery(enabled = true) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  return useQuery({
    ...topRiskiestMaterialsEventsQueryOptions(globalFiltersVersion),
    enabled,
  });
}
