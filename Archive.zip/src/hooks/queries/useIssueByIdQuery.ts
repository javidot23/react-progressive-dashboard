import { useQuery } from "@tanstack/react-query";
import { fetchIssueById } from "@/services/issueService";

export const issueByIdQueryKeys = {
  all: ["issue-by-id"] as const,
  detail: (issueId: number | string) => [...issueByIdQueryKeys.all, issueId] as const,
};

interface UseIssueByIdQueryParams {
  issueId?: number;
  enabled?: boolean;
}

export function useIssueByIdQuery({ issueId, enabled = true }: UseIssueByIdQueryParams) {
  const query = useQuery({
    queryKey: issueByIdQueryKeys.detail(issueId ?? ""),
    queryFn: ({ signal }) => fetchIssueById(issueId!, signal),
    enabled: enabled && !!issueId,
  });

  return {
    issue: query.data,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    error: query.error,
    refetch: query.refetch,
  };
}
