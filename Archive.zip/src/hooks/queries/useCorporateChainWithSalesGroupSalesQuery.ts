import { useInfiniteQuery, useQuery } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";
import type { SalesGroupSale } from "@/components/manage/sales/salesGroupConfig";

const PAGE_SIZE = 20;

export interface CorporateChainWithSalesGroupItem {
  name: string;
  corporate_chain_nbr?: string;
  total_sales_qty: number;
  sales_group_sales?: SalesGroupSale[];
}

interface CorporateChainPageResult {
  results: CorporateChainWithSalesGroupItem[];
  hasMore: boolean;
  nextOffset: number;
}

export const corporateChainWithSalesGroupSalesQueryKeys = {
  all: ["corporate-chain-with-sales-group-sales"] as const,
  infinite: (globalFiltersVersion: number) =>
    [...corporateChainWithSalesGroupSalesQueryKeys.all, "infinite", globalFiltersVersion] as const,
  summary: (globalFiltersVersion: number) =>
    [...corporateChainWithSalesGroupSalesQueryKeys.all, "summary", globalFiltersVersion] as const,
};

async function fetchCorporateChainPage(offset: number, limit: number, signal?: AbortSignal): Promise<CorporateChainPageResult> {
  const response = await apiClient.get(`/order-transaction/corporate-with-sales-group-sales/?limit=${limit}&offset=${offset}`, {
    signal,
  });
  const payload = response.data;

  if (!payload?.success || !payload?.data?.results) {
    throw new Error("Failed to load corporate chain sales");
  }

  const results = payload.data.results as CorporateChainWithSalesGroupItem[];

  return {
    results,
    hasMore: payload.data.next != null,
    nextOffset: offset + results.length,
  };
}

export function useCorporateChainWithSalesGroupSalesInfiniteQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();

  const query = useInfiniteQuery({
    queryKey: corporateChainWithSalesGroupSalesQueryKeys.infinite(globalFiltersVersion),
    queryFn: async ({ pageParam = 0, signal }) => fetchCorporateChainPage(pageParam, PAGE_SIZE, signal),
    initialPageParam: 0,
    getNextPageParam: lastPage => (lastPage.hasMore ? lastPage.nextOffset : undefined),
  });

  const data = query.data?.pages.flatMap(page => page.results) ?? [];
  return {
    data,
    isLoading: query.isLoading,
    isFetchingNextPage: query.isFetchingNextPage,
    error: query.error?.message ?? null,
    hasMore: query.hasNextPage ?? false,
    fetchNextPage: query.fetchNextPage,
    refetch: query.refetch,
    hasEverFetched: query.dataUpdatedAt > 0 || query.isFetched,
  };
}

export interface BackorderCorporateChainSalesRow {
  productName: string;
  salesCurrentPeriod: string;
}

function formatSalesQty(value: number): string {
  if (value >= 1000) {
    return `${Math.round(value / 1000)}K`;
  }
  return value.toLocaleString("en-US");
}

export function useBackorderCorporateChainSalesQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();

  const query = useQuery({
    queryKey: corporateChainWithSalesGroupSalesQueryKeys.summary(globalFiltersVersion),
    queryFn: async ({ signal }) => {
      const page = await fetchCorporateChainPage(0, PAGE_SIZE, signal);
      return page.results.map(row => ({
        productName: row.name,
        salesCurrentPeriod: formatSalesQty(row.total_sales_qty ?? 0),
      }));
    },
  });

  return {
    rows: query.data ?? [],
    isLoading: query.isLoading,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}
