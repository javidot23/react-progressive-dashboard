import { useInfiniteQuery, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { MaterialWithIssues } from "@/lib/types";
import { fetchMaterialsWithIssues } from "@/services/materialService";
import { materialsQueryKeys } from "@/hooks/queries";

export const materialsInfiniteQueryKeys = {
  all: ["materials"] as const,
  infinite: (vendorId: number) => [...materialsInfiniteQueryKeys.all, "vendor", vendorId, "infinite"] as const,
  infiniteList: (vendorId: number, pageSize: number, filters: Record<string, unknown>) =>
    [...materialsInfiniteQueryKeys.infinite(vendorId), { pageSize, filters }] as const,
} as const;

interface UseMaterialsInfiniteQueryParams {
  vendorId: number | null;
  filters: Record<string, unknown>;
  pageSize?: number;
  enabled?: boolean;
}

interface MaterialsPageResult {
  results: MaterialWithIssues[];
  hasMore: boolean;
  total: number;
  page: number;
}

export function useMaterialsInfiniteQuery({ vendorId, filters, pageSize = 10, enabled = true }: UseMaterialsInfiniteQueryParams) {
  const queryClient = useQueryClient();
  const effectiveVendorId = vendorId ?? 0;

  const query = useInfiniteQuery({
    queryKey: materialsInfiniteQueryKeys.infiniteList(effectiveVendorId, pageSize, filters),
    queryFn: async ({ pageParam = 1, signal }): Promise<MaterialsPageResult> => {
      if (!vendorId) {
        return { results: [], hasMore: false, total: 0, page: pageParam };
      }

      const result = await fetchMaterialsWithIssues(vendorId, pageParam, pageSize, filters as Record<string, any>, signal);

      return { ...result, page: pageParam };
    },
    initialPageParam: 1,
    getNextPageParam: (lastPage, allPages) => {
      if (lastPage.hasMore) {
        return allPages.length + 1;
      }
      return undefined;
    },
    enabled: enabled && vendorId !== null && vendorId > 0,
    placeholderData: keepPreviousData,
  });

  const allMaterials = query.data?.pages.flatMap(page => page.results) ?? [];

  const total = query.data?.pages[0]?.total ?? 0;

  const invalidateMaterials = (targetVendorId?: number) => {
    const id = targetVendorId ?? vendorId;
    if (id) {
      queryClient.invalidateQueries({
        queryKey: materialsQueryKeys.byVendor(id),
      });
    }
  };

  return {
    materials: allMaterials,
    total,
    hasMore: query.hasNextPage ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    isPlaceholderData: query.isPlaceholderData,
    error: query.error,
    isError: query.isError,
    fetchNextPage: query.fetchNextPage,
    refetch: query.refetch,
    invalidateMaterials,
  };
}

export type { MaterialWithIssues };
export default useMaterialsInfiniteQuery;
