import { useInfiniteQuery } from "@tanstack/react-query";
import { materialSubstitutesService } from "@/lib/apiServices";
import { transformMaterialSubstitutesResponse } from "@/stores/slices/transformers";
import type { MaterialSubstituteDisplay } from "@/stores/slices/types";

const PAGE_SIZE = 10;

export const materialSubstitutesQueryKeys = {
  all: ["material-substitutes"] as const,
  list: (materialId: number, additionalParams: string) =>
    [...materialSubstitutesQueryKeys.all, materialId, additionalParams] as const,
};

interface UseMaterialSubstitutesInfiniteQueryParams {
  materialId: number | null;
  additionalParams?: string;
  enabled?: boolean;
}

export function useMaterialSubstitutesInfiniteQuery({
  materialId,
  additionalParams = "",
  enabled = true,
}: UseMaterialSubstitutesInfiniteQueryParams) {
  const query = useInfiniteQuery({
    queryKey: materialSubstitutesQueryKeys.list(materialId ?? 0, additionalParams),
    queryFn: async ({ pageParam = 0 }) => {
      if (!materialId) {
        return { items: [] as MaterialSubstituteDisplay[], hasMore: false, totalCount: 0 };
      }

      const recordOffset = pageParam * PAGE_SIZE;
      const response = await materialSubstitutesService.getMaterialSubstitutes(
        materialId,
        PAGE_SIZE,
        recordOffset,
        additionalParams || undefined
      );

      if (!response.data.success) {
        throw new Error("API returned success: false");
      }

      const items = transformMaterialSubstitutesResponse(response.data);

      return {
        items,
        hasMore: response.data.data.next != null,
        totalCount: response.data.data.count ?? items.length,
      };
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) => {
      if (lastPage.hasMore) {
        return allPages.length;
      }
      return undefined;
    },
    enabled: enabled && !!materialId,
  });

  const materialSubstitutes = query.data?.pages.flatMap(page => page.items) ?? [];
  const totalCount = query.data?.pages[0]?.totalCount ?? 0;

  return {
    materialSubstitutes,
    totalCount,
    hasMore: query.hasNextPage ?? false,
    isLoading: query.isLoading,
    isFetchingNextPage: query.isFetchingNextPage,
    error: query.error?.message ?? null,
    fetchNextPage: query.fetchNextPage,
    refetch: query.refetch,
  };
}
