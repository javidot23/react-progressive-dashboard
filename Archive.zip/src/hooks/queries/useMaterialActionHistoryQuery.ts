import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { userActionService, type UserAction } from "@/lib/apiServices";

export const materialActionHistoryQueryKeys = {
  all: ["material-action-history"] as const,
  list: (matNbr: string, page: number, pageSize: number) =>
    [...materialActionHistoryQueryKeys.all, matNbr, page, pageSize] as const,
};

interface UseMaterialActionHistoryQueryParams {
  matNbr: string | undefined;
  page?: number;
  pageSize?: number;
  enabled?: boolean;
}

export function useMaterialActionHistoryQuery({
  matNbr,
  page = 1,
  pageSize = 10,
  enabled = true,
}: UseMaterialActionHistoryQueryParams) {
  const query = useQuery({
    queryKey: materialActionHistoryQueryKeys.list(matNbr ?? "", page, pageSize),
    queryFn: async ({ signal }): Promise<{ results: UserAction[]; count: number }> => {
      if (!matNbr) {
        return { results: [], count: 0 };
      }

      const response = await userActionService.getMaterialActions(
        matNbr,
        {
          limit: pageSize,
          offset: (page - 1) * pageSize,
        },
        signal
      );

      if (response.data.success && response.data.data) {
        return {
          results: response.data.data.results ?? [],
          count: response.data.data.count ?? 0,
        };
      }
      return { results: [], count: 0 };
    },
    enabled: enabled && !!matNbr,
    placeholderData: keepPreviousData,
  });

  return {
    actions: query.data?.results ?? [],
    total: query.data?.count ?? 0,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}
