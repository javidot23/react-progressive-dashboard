import { queryOptions, useQuery } from "@tanstack/react-query";
import { vendorsService } from "@/lib/apiServices";
import { transformVendorDetailsResponse } from "@/stores/slices/transformers";
import type { VendorDisplay } from "@/stores/slices/types";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const topRiskiestVendorsQueryKeys = {
  all: ["top-riskiest-vendors"] as const,
  list: (limit: number, globalFiltersVersion: number) =>
    [...topRiskiestVendorsQueryKeys.all, { limit, globalFiltersVersion }] as const,
};

export function topRiskiestVendorsQueryOptions(limit: number, globalFiltersVersion: number) {
  return queryOptions({
    queryKey: topRiskiestVendorsQueryKeys.list(limit, globalFiltersVersion),
    queryFn: async ({ signal }) => {
      const response = await vendorsService.getVendorDetails(
        limit,
        0,
        "-risk_rating,-risk_adjusted_value",
        signal
      );
      if (response.data.success) {
        return {
          vendors: transformVendorDetailsResponse(response.data) as VendorDisplay[],
          totalCount: response.data.data?.count ?? 0,
        };
      }
      throw new Error("Failed to fetch top riskiest vendors");
    },
  });
}

export function useTopRiskiestVendorsQuery(limit = 3) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery(topRiskiestVendorsQueryOptions(limit, globalFiltersVersion));
  return {
    topRiskiestVendors: query.data?.vendors ?? [],
    totalCount: query.data?.totalCount ?? 0,
    isLoading: query.isPending,
    error: query.error?.message ?? null,
    dataUpdatedAt: query.dataUpdatedAt,
    refetch: query.refetch,
  };
}
