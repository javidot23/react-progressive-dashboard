import { useQuery, useQueryClient } from "@tanstack/react-query";
import { vendorsService } from "@/lib/apiServices";

// Vendor type definition
export interface VendorData {
  id: number;
  name: string;
  vendor_nbr: string;
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  risk_rating: number;
  driving_risk: string;
  created_at: string;
  updated_at: string;
  materials_at_risk?: number;
  total_materials?: number;
  sales_volume?: number | null;
  sales_amount?: number | null;
  risk_adjusted_value?: number | null;
  inbound_fill_rate?: number | null;
  outbound_fill_rate?: number | null;
  product_damages_rate?: number | null;
  otif_percentage?: number | null;
  overall_score?: number | null;
  asn_timeliness?: number | null;
  asn_essential?: number | null;
  vendor_group?: string;
  cat_mgr_list?: string[];
  buyer_list?: string[];
  service_levels_90_days?: Array<{
    material__vendor_id?: string;
    date: string;
    avg_fill_rate: number;
    total_order_qty?: number;
    total_received_qty?: number;
  }>;
  high_risk_materials_count?: number;
  medium_risk_materials_count?: number;
  issues_last_24h_count?: number;
  issues_with_actions_last_24h_count?: number;
}

// Query key factory for vendors
export const vendorQueryKeys = {
  all: ["vendors"] as const,
  lists: () => [...vendorQueryKeys.all, "list"] as const,
  list: (limit: number, offset: number) => [...vendorQueryKeys.lists(), { limit, offset }] as const,
  details: () => [...vendorQueryKeys.all, "detail"] as const,
  detail: (vendorId: number) => [...vendorQueryKeys.details(), vendorId] as const,
  withServiceLevels: (vendorId: number) => [...vendorQueryKeys.detail(vendorId), "serviceLevels"] as const,
} as const;

interface UseVendorQueryParams {
  vendorId: number;
  enabled?: boolean;
}

/**
 * React Query hook for fetching a single vendor with service levels
 * Uses proper caching, deduplication, and automatic refetching
 */
export function useVendorQuery({ vendorId, enabled = true }: UseVendorQueryParams) {
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: vendorQueryKeys.withServiceLevels(vendorId),
    queryFn: async ({ signal }): Promise<VendorData | null> => {
      if (!vendorId || vendorId <= 0) {
        return null;
      }

      const response = await vendorsService.getVendorByIdWithServiceLevels(vendorId, signal);

      if (response.data.success) {
        return response.data.data;
      }

      throw new Error(`Vendor with ID ${vendorId} not found`);
    },
    enabled: enabled && vendorId > 0,
  });

  // Invalidate vendor cache
  const invalidateVendor = () => {
    queryClient.invalidateQueries({
      queryKey: vendorQueryKeys.detail(vendorId),
    });
  };

  return {
    // Data
    vendor: query.data ?? null,

    // Loading states
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isPending: query.isPending,

    // Error state
    error: query.error?.message ?? null,
    isError: query.isError,

    // Actions
    refetch: query.refetch,
    invalidateVendor,
  };
}

/**
 * React Query hook for fetching vendors list (for comparison dropdown)
 */
export function useVendorsListQuery({
  limit = 10,
  offset = 0,
  enabled = true,
}: {
  limit?: number;
  offset?: number;
  enabled?: boolean;
} = {}) {
  const query = useQuery({
    queryKey: vendorQueryKeys.list(limit, offset),
    queryFn: async ({ signal }) => {
      const response = await vendorsService.getVendorDetails(limit, offset, undefined, signal);

      if (response.data.success && response.data.data?.results) {
        return response.data.data.results as Array<{
          id: number;
          name: string;
          country: string;
          risk_rating: number;
          vendor_nbr?: string;
        }>;
      }

      return [];
    },
    enabled,
  });

  return {
    vendors: query.data ?? [],
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    error: query.error,
    isError: query.isError,
    refetch: query.refetch,
  };
}

export default useVendorQuery;
