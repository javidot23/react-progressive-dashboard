import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { supplyChainEventsService, type SupplyChainEvent, type MaterialSupplyChainEventsResponse } from "@/lib/apiServices";

const OPEN_STATUS = "OPEN";

export const materialSupplyChainEventsQueryKeys = {
  all: ["material-supply-chain-events"] as const,
  list: (matNbr: string, page: number, pageSize: number) =>
    [...materialSupplyChainEventsQueryKeys.all, matNbr, page, pageSize] as const,
};

function normalizeEventsResponse(data: MaterialSupplyChainEventsResponse["data"]): {
  results: SupplyChainEvent[];
  count: number;
} {
  if (data && "results" in data && Array.isArray(data.results)) {
    return { results: data.results, count: data.count ?? data.results.length };
  }
  return { results: [], count: 0 };
}

interface UseMaterialSupplyChainEventsQueryParams {
  matNbr: string | undefined;
  page?: number;
  pageSize?: number;
  enabled?: boolean;
}

export function useMaterialSupplyChainEventsQuery({
  matNbr,
  page = 1,
  pageSize = 10,
  enabled = true,
}: UseMaterialSupplyChainEventsQueryParams) {
  const query = useQuery({
    queryKey: materialSupplyChainEventsQueryKeys.list(matNbr ?? "", page, pageSize),
    queryFn: async ({ signal }): Promise<{ results: SupplyChainEvent[]; count: number }> => {
      if (!matNbr) {
        return { results: [], count: 0 };
      }

      const response = await supplyChainEventsService.getMaterialSupplyChainEvents(
        matNbr,
        {
          limit: pageSize,
          offset: (page - 1) * pageSize,
          status: OPEN_STATUS,
        },
        signal
      );

      if (response.data.success) {
        return normalizeEventsResponse(response.data.data);
      }
      return { results: [], count: 0 };
    },
    enabled: enabled && !!matNbr,
    placeholderData: keepPreviousData,
  });

  return {
    events: query.data?.results ?? [],
    total: query.data?.count ?? 0,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}
