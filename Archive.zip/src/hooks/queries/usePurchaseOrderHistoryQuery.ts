import { queryOptions, useQuery, keepPreviousData } from "@tanstack/react-query";
import { purchaseOrderHistoryService } from "@/lib/apiServices";
import { transformPurchaseOrderHistoryItem } from "@/components/manage/supply/overview/ManageSupplyTableView";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const purchaseOrderHistoryQueryKeys = {
  all: ["purchase-order-history"] as const,
  lists: () => [...purchaseOrderHistoryQueryKeys.all, "list"] as const,
  list: (materialId: string, page: number, pageSize: number, filters: Record<string, unknown>, globalFiltersVersion: number) =>
    [...purchaseOrderHistoryQueryKeys.lists(), { materialId, page, pageSize, filters, globalFiltersVersion }] as const,
} as const;

export interface PurchaseOrderHistoryQueryResult {
  results: ReturnType<typeof transformPurchaseOrderHistoryItem>[];
  count: number;
}

export function purchaseOrderHistoryQueryOptions(
  materialId: string,
  page: number,
  pageSize: number,
  filters: Record<string, unknown>,
  globalFiltersVersion: number
) {
  return queryOptions({
    queryKey: purchaseOrderHistoryQueryKeys.list(materialId, page, pageSize, filters, globalFiltersVersion),
    queryFn: async ({ signal }): Promise<PurchaseOrderHistoryQueryResult> => {
      const offset = (page - 1) * pageSize;
      const ordering = typeof filters.ordering === "string" ? filters.ordering : "ordered_date";

      const response = await purchaseOrderHistoryService.getPurchaseOrderHistory(
        parseInt(materialId, 10),
        pageSize,
        offset,
        ordering,
        filters as Record<string, unknown>,
        { signal }
      );

      if (!response.data.success) {
        throw new Error("Failed to fetch purchase order history");
      }

      return {
        results: response.data.data.results.map(transformPurchaseOrderHistoryItem),
        count: response.data.data.count,
      };
    },
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
  });
}

interface UsePurchaseOrderHistoryQueryParams {
  materialId: string | null;
  page?: number;
  pageSize?: number;
  filters: Record<string, unknown>;
  enabled?: boolean;
}

export function usePurchaseOrderHistoryQuery({
  materialId,
  page = 1,
  pageSize = 10,
  filters,
  enabled = true,
}: UsePurchaseOrderHistoryQueryParams) {
  const globalFiltersVersion = useGlobalFiltersVersion();

  const query = useQuery({
    ...purchaseOrderHistoryQueryOptions(materialId ?? "", page, pageSize, filters, globalFiltersVersion),
    enabled: enabled && !!materialId,
  });

  return {
    data: query.data?.results ?? [],
    total: query.data?.count ?? 0,
    isPending: query.isPending,
    isFetching: query.isFetching,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
