import { useQuery, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { fetchIssues, IssueApiData, FetchIssuesResult } from "@/services/issueService";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const issuesQueryKeys = {
  all: ["issues"] as const,
  lists: () => [...issuesQueryKeys.all, "list"] as const,
  list: (
    page: number,
    pageSize: number,
    filters: Record<string, unknown>,
    module: string | undefined,
    globalFiltersVersion: number
  ) => [...issuesQueryKeys.lists(), { page, pageSize, filters, module, globalFiltersVersion }] as const,
} as const;

interface UseIssuesQueryParams {
  filters: Record<string, unknown>;
  page?: number;
  pageSize?: number;
  module?: string;
  enabled?: boolean;
}

export function useIssuesQuery({ filters, page = 1, pageSize = 10, module, enabled = true }: UseIssuesQueryParams) {
  const queryClient = useQueryClient();
  const globalFiltersVersion = useGlobalFiltersVersion();

  const query = useQuery({
    queryKey: issuesQueryKeys.list(page, pageSize, filters, module, globalFiltersVersion),
    queryFn: async ({ signal }): Promise<FetchIssuesResult> => {
      return fetchIssues({
        page,
        pageSize,
        filters: filters as Record<string, any>,
        module,
        signal,
      });
    },
    enabled,
    placeholderData: keepPreviousData,
  });

  const prefetchNextPage = () => {
    if (query.data?.hasMore) {
      queryClient.prefetchQuery({
        queryKey: issuesQueryKeys.list(page + 1, pageSize, filters, module, globalFiltersVersion),
        queryFn: ({ signal }) =>
          fetchIssues({ page: page + 1, pageSize, filters: filters as Record<string, any>, module, signal }),
      });
    }
  };

  const invalidateIssues = () => {
    queryClient.invalidateQueries({
      queryKey: issuesQueryKeys.all,
    });
  };

  return {
    issues: query.data?.results ?? [],
    total: query.data?.total ?? 0,
    hasMore: query.data?.hasMore ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    isPending: query.isPending,
    error: query.error,
    isError: query.isError,
    refetch: query.refetch,
    prefetchNextPage,
    invalidateIssues,
  };
}

export type { IssueApiData };
export default useIssuesQuery;
