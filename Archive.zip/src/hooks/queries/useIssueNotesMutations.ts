import { useMutation, useQueryClient, type InfiniteData, type QueryClient, type QueryKey } from "@tanstack/react-query";
import {
  createIssueNote,
  updateIssueNote,
  deleteIssueNote,
  type CreateIssueNoteRequest,
  type UpdateIssueNoteRequest,
  type IssueNote,
  type IssueNoteUserData,
  type IssueNotesListPayload,
} from "@/services/issueNotesService";
import type { IssueApiData } from "@/services/issueService";
import { issueNotesQueryKeys, issueNotesQueriesForIssueFilter } from "./useIssueNotesQuery";
import { issuesQueryKeys } from "./useIssuesQuery";
import { granularityIssuesQueryKeys } from "./useGranularityIssuesQuery";

/** Issue list caches that expose `id`, `last_note`, and `notes_count` on each row. */
const ISSUE_LIST_QUERY_ROOTS = [issuesQueryKeys.all, granularityIssuesQueryKeys.all] as const;

type IssueListRow = Pick<IssueApiData, "id" | "last_note" | "notes_count">;

export interface OptimisticIssueNoteAuthor {
  id: string;
  user_data?: IssueNoteUserData | null;
}

type NotesSnapshot = Array<[QueryKey, InfiniteData<IssueNotesListPayload> | undefined]>;
type IssuesSnapshot = Array<[QueryKey, unknown]>;

type OptimisticMutationContext = {
  prevNotes: NotesSnapshot;
  prevIssues: IssuesSnapshot;
  tempId?: string;
};

function invalidateIssueListQueries(queryClient: QueryClient) {
  for (const root of ISSUE_LIST_QUERY_ROOTS) {
    queryClient.invalidateQueries({ queryKey: root });
  }
}

function invalidateNotesQueriesForIssue(queryClient: QueryClient, issueId: string) {
  queryClient.invalidateQueries(issueNotesQueriesForIssueFilter(issueId));
}

async function cancelNotesAndIssuesQueries(queryClient: QueryClient, issueId: string) {
  await Promise.all([
    queryClient.cancelQueries({ queryKey: [...issueNotesQueryKeys.all, issueId] }),
    ...ISSUE_LIST_QUERY_ROOTS.map(root => queryClient.cancelQueries({ queryKey: root })),
  ]);
}

function snapshotCaches(
  queryClient: QueryClient,
  issueId: string
): {
  prevNotes: NotesSnapshot;
  prevIssues: IssuesSnapshot;
} {
  const prevNotes = queryClient.getQueriesData<InfiniteData<IssueNotesListPayload>>({
    queryKey: [...issueNotesQueryKeys.all, issueId],
  });
  const prevIssues = ISSUE_LIST_QUERY_ROOTS.flatMap(root => queryClient.getQueriesData({ queryKey: root }));
  return { prevNotes, prevIssues };
}

function restoreSnapshots(queryClient: QueryClient, prevNotes: NotesSnapshot, prevIssues: IssuesSnapshot) {
  for (const [key, data] of prevNotes) {
    if (data === undefined) {
      queryClient.removeQueries({ queryKey: key });
    } else {
      queryClient.setQueryData(key, data);
    }
  }
  for (const [key, data] of prevIssues) {
    if (data === undefined) {
      queryClient.removeQueries({ queryKey: key });
    } else {
      queryClient.setQueryData(key, data);
    }
  }
}

function mapIssuesInQueryData<T extends IssueListRow>(data: unknown, issueId: string, mapRow: (row: T) => T): unknown {
  if (!data || typeof data !== "object") return data;
  const d = data as Record<string, unknown>;
  if ("pages" in d && Array.isArray(d.pages)) {
    const pages = d.pages as Array<{ results: T[]; page?: number }>;
    return {
      ...d,
      pages: pages.map(page => ({
        ...page,
        results: page.results.map(r => (String(r.id) === issueId ? mapRow(r) : r)),
      })),
    };
  }
  if ("results" in d && Array.isArray(d.results)) {
    const f = d as { results: T[] };
    return {
      ...f,
      results: f.results.map(r => (String(r.id) === issueId ? mapRow(r) : r)),
    };
  }
  return data;
}

function setAllIssuesCaches<T extends IssueListRow>(queryClient: QueryClient, issueId: string, mapRow: (row: T) => T) {
  for (const root of ISSUE_LIST_QUERY_ROOTS) {
    const entries = queryClient.getQueriesData({ queryKey: root });
    for (const [key, data] of entries) {
      queryClient.setQueryData(key, mapIssuesInQueryData(data, issueId, mapRow));
    }
  }
}

function normalizeServerNote(note: IssueNote): IssueNote {
  return {
    ...note,
    id: String(note.id),
  };
}

function getNewestNoteFromInfinite(data: InfiniteData<IssueNotesListPayload> | undefined): IssueNote | null {
  return data?.pages?.[0]?.results?.[0] ?? null;
}

export type IssueNotesMutationUiOptions = { silent?: boolean };

export function useCreateIssueNoteMutation(
  issueId: string | undefined,
  optimisticAuthor?: OptimisticIssueNoteAuthor | null,
  options?: IssueNotesMutationUiOptions
) {
  const silent = options?.silent ?? false;
  const queryClient = useQueryClient();

  return useMutation({
    meta: {
      silent,
      errorMessage: "Couldn't add note",
    },
    mutationFn: (body: CreateIssueNoteRequest) => {
      if (!issueId) throw new Error("issueId is required");
      return createIssueNote(issueId, body);
    },
    onMutate: async (body): Promise<OptimisticMutationContext | undefined> => {
      if (!issueId) return;
      const trimmed = body.content.trim();
      if (!trimmed) return;

      await cancelNotesAndIssuesQueries(queryClient, issueId);
      const { prevNotes, prevIssues } = snapshotCaches(queryClient, issueId);

      const tempId = `temp-${crypto.randomUUID()}`;
      const now = new Date().toISOString();
      const tempNote: IssueNote = {
        id: tempId,
        issue_id: issueId,
        content: trimmed,
        user_id: optimisticAuthor?.id ?? "unknown",
        user_data: optimisticAuthor?.user_data ?? null,
        is_my_note: true,
        created_at: now,
        updated_at: now,
      };

      queryClient.setQueriesData<InfiniteData<IssueNotesListPayload>>(
        { queryKey: [...issueNotesQueryKeys.all, issueId] },
        old => {
          if (!old?.pages?.length) return old;
          return {
            ...old,
            pages: old.pages.map((p, i) =>
              i === 0 ? { ...p, count: p.count + 1, results: [tempNote, ...p.results] } : { ...p, count: p.count + 1 }
            ),
          };
        }
      );

      setAllIssuesCaches(queryClient, issueId, issue => ({
        ...issue,
        last_note: tempNote,
        notes_count: (issue.notes_count ?? 0) + 1,
      }));

      return { prevNotes, prevIssues, tempId };
    },
    onError: (_err, _body, ctx) => {
      if (ctx?.prevNotes && ctx?.prevIssues) {
        restoreSnapshots(queryClient, ctx.prevNotes, ctx.prevIssues);
      }
    },
    onSuccess: (serverNote, _body, ctx) => {
      if (!issueId || !ctx?.tempId) return;
      const normalized = normalizeServerNote(serverNote);

      queryClient.setQueriesData<InfiniteData<IssueNotesListPayload>>(
        { queryKey: [...issueNotesQueryKeys.all, issueId] },
        old => {
          if (!old?.pages) return old;
          return {
            ...old,
            pages: old.pages.map(p => ({
              ...p,
              results: p.results.map(n => (n.id === ctx.tempId ? normalized : n)),
            })),
          };
        }
      );

      setAllIssuesCaches(queryClient, issueId, issue => {
        if (issue.last_note && String(issue.last_note.id) === ctx.tempId) {
          return { ...issue, last_note: normalized };
        }
        return issue;
      });
    },
    onSettled: () => {
      if (!issueId) return;
      invalidateIssueListQueries(queryClient);
      invalidateNotesQueriesForIssue(queryClient, issueId);
    },
  });
}

export function useUpdateIssueNoteMutation(issueId: string | undefined, options?: IssueNotesMutationUiOptions) {
  const silent = options?.silent ?? false;
  const queryClient = useQueryClient();

  return useMutation({
    meta: {
      silent,
      errorMessage: "Couldn't update note",
    },
    mutationFn: ({ noteId, body }: { noteId: string; body: UpdateIssueNoteRequest }) => updateIssueNote(noteId, body),
    onMutate: async ({ noteId, body }): Promise<OptimisticMutationContext | undefined> => {
      if (!issueId) return;
      const trimmed = body.content.trim();
      if (!trimmed) return;

      await cancelNotesAndIssuesQueries(queryClient, issueId);
      const { prevNotes, prevIssues } = snapshotCaches(queryClient, issueId);
      const now = new Date().toISOString();

      queryClient.setQueriesData<InfiniteData<IssueNotesListPayload>>(
        { queryKey: [...issueNotesQueryKeys.all, issueId] },
        old => {
          if (!old?.pages) return old;
          return {
            ...old,
            pages: old.pages.map(p => ({
              ...p,
              results: p.results.map(n => (n.id === noteId ? { ...n, content: trimmed, updated_at: now } : n)),
            })),
          };
        }
      );

      setAllIssuesCaches(queryClient, issueId, issue => {
        if (issue.last_note && String(issue.last_note.id) === noteId) {
          return {
            ...issue,
            last_note: { ...issue.last_note, content: trimmed, updated_at: now },
          };
        }
        return issue;
      });

      return { prevNotes, prevIssues };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prevNotes && ctx?.prevIssues) {
        restoreSnapshots(queryClient, ctx.prevNotes, ctx.prevIssues);
      }
    },
    onSettled: () => {
      if (!issueId) return;
      invalidateIssueListQueries(queryClient);
      invalidateNotesQueriesForIssue(queryClient, issueId);
    },
  });
}

export function useDeleteIssueNoteMutation(issueId: string | undefined, options?: IssueNotesMutationUiOptions) {
  const silent = options?.silent ?? false;
  const queryClient = useQueryClient();

  return useMutation({
    meta: {
      silent,
      errorMessage: "Couldn't delete note",
    },
    mutationFn: (noteId: string) => deleteIssueNote(noteId),
    onMutate: async (noteId): Promise<OptimisticMutationContext | undefined> => {
      if (!issueId) return;

      await cancelNotesAndIssuesQueries(queryClient, issueId);
      const { prevNotes, prevIssues } = snapshotCaches(queryClient, issueId);

      queryClient.setQueriesData<InfiniteData<IssueNotesListPayload>>(
        { queryKey: [...issueNotesQueryKeys.all, issueId] },
        old => {
          if (!old?.pages) return old;
          return {
            ...old,
            pages: old.pages.map(p => ({
              ...p,
              count: Math.max(0, p.count - 1),
              results: p.results.filter(n => n.id !== noteId),
            })),
          };
        }
      );

      const afterEntries = queryClient.getQueriesData<InfiniteData<IssueNotesListPayload>>({
        queryKey: [...issueNotesQueryKeys.all, issueId],
      });
      let newLast: IssueNote | null = null;
      for (const [, data] of afterEntries) {
        newLast = getNewestNoteFromInfinite(data);
        break;
      }

      setAllIssuesCaches(queryClient, issueId, issue => {
        const nextCount = Math.max(0, (issue.notes_count ?? 0) - 1);
        const wasLast = issue.last_note && String(issue.last_note.id) === noteId;
        return {
          ...issue,
          notes_count: nextCount,
          last_note: wasLast ? newLast : issue.last_note,
        };
      });

      return { prevNotes, prevIssues };
    },
    onError: (_err, _noteId, ctx) => {
      if (ctx?.prevNotes && ctx?.prevIssues) {
        restoreSnapshots(queryClient, ctx.prevNotes, ctx.prevIssues);
      }
    },
    onSettled: () => {
      if (!issueId) return;
      invalidateIssueListQueries(queryClient);
      invalidateNotesQueriesForIssue(queryClient, issueId);
    },
  });
}
