import { useQuery, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { MaterialWithIssues } from "@/lib/types";
import { fetchMaterialsWithIssues } from "@/services/materialService";

export const materialsQueryKeys = {
  all: ["materials"] as const,
  byVendor: (vendorId: number) => [...materialsQueryKeys.all, "vendor", vendorId] as const,
  lists: (vendorId: number) => [...materialsQueryKeys.byVendor(vendorId), "list"] as const,
  list: (vendorId: number, page: number, pageSize: number, filters: Record<string, unknown>) =>
    [...materialsQueryKeys.lists(vendorId), { page, pageSize, filters }] as const,
} as const;

interface UseMaterialsQueryParams {
  vendorId: number | null;
  filters: Record<string, unknown>;
  page?: number;
  pageSize?: number;
  enabled?: boolean;
}

interface MaterialsQueryResult {
  results: MaterialWithIssues[];
  hasMore: boolean;
  total: number;
}

export function useMaterialsQuery({ vendorId, filters, page = 1, pageSize = 10, enabled = true }: UseMaterialsQueryParams) {
  const queryClient = useQueryClient();

  const effectiveVendorId = vendorId ?? 0;

  const query = useQuery({
    queryKey: materialsQueryKeys.list(effectiveVendorId, page, pageSize, filters),
    queryFn: async ({ signal }): Promise<MaterialsQueryResult> => {
      if (!vendorId) {
        return { results: [], hasMore: false, total: 0 };
      }

      return fetchMaterialsWithIssues(vendorId, page, pageSize, filters, signal);
    },
    enabled: enabled && vendorId !== null && vendorId > 0,
    placeholderData: keepPreviousData,
  });

  const prefetchNextPage = () => {
    if (vendorId && query.data?.hasMore) {
      queryClient.prefetchQuery({
        queryKey: materialsQueryKeys.list(vendorId, page + 1, pageSize, filters),
        queryFn: ({ signal }) => fetchMaterialsWithIssues(vendorId, page + 1, pageSize, filters, signal),
      });
    }
  };

  const invalidateMaterials = (targetVendorId?: number) => {
    if (targetVendorId) {
      queryClient.invalidateQueries({
        queryKey: materialsQueryKeys.byVendor(targetVendorId),
      });
    } else if (vendorId) {
      queryClient.invalidateQueries({
        queryKey: materialsQueryKeys.byVendor(vendorId),
      });
    }
  };

  return {
    materials: query.data?.results ?? [],
    total: query.data?.total ?? 0,
    hasMore: query.data?.hasMore ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    isPending: query.isPending,
    error: query.error,
    isError: query.isError,
    refetch: query.refetch,
    prefetchNextPage,
    invalidateMaterials,
  };
}

export default useMaterialsQuery;
