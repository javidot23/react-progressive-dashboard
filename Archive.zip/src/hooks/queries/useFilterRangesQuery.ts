import { useCallback, useMemo } from "react";
import { keepPreviousData, useQuery } from "@tanstack/react-query";

import {
  FetchFilterRangesParams,
  FilterRangesByKey,
  FilterRangesResponse,
  FilterRangeBounds,
  FilterRangeModule,
  fetchFilterRanges,
} from "@/services/filterRangesService";

export const filterRangesQueryKeys = {
  all: ["filter-ranges"] as const,
  module: (module: FilterRangeModule) => [...filterRangesQueryKeys.all, module] as const,
  byInputs: (module: FilterRangeModule, keys: readonly string[] | undefined, params: Record<string, unknown> | undefined) =>
    [
      ...filterRangesQueryKeys.module(module),
      keys ? [...keys].sort() : null,
      // Sort params so the cache key is order-independent.
      params ? Object.fromEntries(Object.entries(params).sort(([a], [b]) => a.localeCompare(b))) : null,
    ] as const,
} as const;

interface UseFilterRangesQueryOptions extends FetchFilterRangesParams {
  enabled?: boolean;
}

interface UseFilterRangesQueryResult {
  ranges: FilterRangesByKey;
  /** Memoized ``Record<key, max>``; invalid/missing values coerced to ``0``. */
  maxes: Record<string, number>;
  /** ``ranges[key]?.max ?? fallback`` shorthand. Stable across renders. */
  getMax: (key: string, fallback?: number) => number;
  isLoading: boolean;
  isFetching: boolean;
  isSuccess: boolean;
  isError: boolean;
  error: unknown;
  refetch: () => void;
}

const EMPTY_RANGES: FilterRangesByKey = {};
const EMPTY_MAXES: Record<string, number> = {};

function isValidMax(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value) && value >= 0;
}

/**
 * Fetch dynamic ``min``/``max`` for the range sliders on a page.
 * Global ``gf_*`` filters are added by the axios interceptor.
 *
 * ```tsx
 * const { maxes } = useFilterRangesQuery({ module: "issue", keys: ["risk_score"] });
 * <Filters ... dynamicMaxValues={maxes} />
 * ```
 */
export function useFilterRangesQuery({
  module,
  keys,
  params,
  enabled = true,
}: UseFilterRangesQueryOptions): UseFilterRangesQueryResult {
  const query = useQuery<FilterRangesResponse>({
    queryKey: filterRangesQueryKeys.byInputs(module, keys, params as Record<string, unknown> | undefined),
    queryFn: ({ signal }) => fetchFilterRanges({ module, keys, params }, signal),
    enabled,
    placeholderData: keepPreviousData,
  });

  const { data, isLoading, isFetching, isSuccess, isError, error, refetch: refetchQuery } = query;

  const ranges = data?.ranges ?? EMPTY_RANGES;

  const maxes = useMemo<Record<string, number>>(() => {
    if (ranges === EMPTY_RANGES) return EMPTY_MAXES;
    const out: Record<string, number> = {};
    for (const [key, bounds] of Object.entries(ranges)) {
      out[key] = isValidMax(bounds?.max) ? bounds.max : 0;
    }
    return out;
  }, [ranges]);

  const getMax = useCallback(
    (key: string, fallback: number = 0) => {
      const bounds: FilterRangeBounds | undefined = ranges[key];
      if (!bounds || !isValidMax(bounds.max)) return fallback;
      return bounds.max;
    },
    [ranges]
  );

  const refetch = useCallback(() => {
    void refetchQuery();
  }, [refetchQuery]);

  return {
    ranges,
    maxes,
    getMax,
    isLoading,
    isFetching,
    isSuccess,
    isError,
    error,
    refetch,
  };
}

export type { FilterRangeBounds, FilterRangeModule, FilterRangesByKey, FilterRangesResponse };
