import { queryOptions, useQuery } from "@tanstack/react-query";
import { aiInsightsService, type AiAnomalyHeadline } from "@/lib/apiServices";
import { formatInsightTimestamp } from "@/hooks/queries/useReferenceParagraphsQuery";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export type AnomalyHeadlinesQueryResult = {
  headlines: AiAnomalyHeadline[];
  selected: AiAnomalyHeadline | null;
};

function selectAnomalyHeadline(headlines: AiAnomalyHeadline[]): AiAnomalyHeadline | null {
  // Always map the header from the first item in the API list.
  return headlines[0] ?? null;
}

export const anomalyHeadlinesQueryKeys = {
  all: ["ai-insights", "anomaly-headlines"] as const,
  list: (globalFiltersVersion: number) => [...anomalyHeadlinesQueryKeys.all, "list", { globalFiltersVersion }] as const,
} as const;

export function anomalyHeadlinesQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: anomalyHeadlinesQueryKeys.list(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<AnomalyHeadlinesQueryResult> => {
      const response = await aiInsightsService.getAnomalyHeadlines({ signal });
      if (!response.data.success) {
        throw new Error(response.data.message || response.data.error || "Failed to fetch anomaly headlines");
      }
      const headlines = Array.isArray(response.data.data) ? response.data.data : [];
      return {
        headlines,
        selected: selectAnomalyHeadline(headlines),
      };
    },
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
}

export function useAnomalyHeadlinesQuery(enabled = true) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery({
    ...anomalyHeadlinesQueryOptions(globalFiltersVersion),
    enabled,
  });

  // Hide headline content while loading so refresh does not flash placeholders.
  const selected = query.isPending ? null : (query.data?.selected ?? null);
  const timestamp = selected ? formatInsightTimestamp(selected.created_at ?? selected.run_timestamp) : "";

  return {
    headlines: query.data?.headlines ?? [],
    selected,
    title: selected?.headline_text?.trim() || undefined,
    description: selected?.subheadline?.trim() || undefined,
    actionLabel: selected?.deep_link_label?.trim() || undefined,
    sentiment: selected?.sentiment?.trim() || undefined,
    timestamp: timestamp || undefined,
    isPending: query.isPending,
    isFetching: query.isFetching,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
