import { useQuery, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { fetchGranularityIssues, FetchGranularityIssuesResult } from "@/services/issueService";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const granularityIssuesQueryKeys = {
  all: ["granularity-issues"] as const,
  lists: () => [...granularityIssuesQueryKeys.all, "list"] as const,
  list: (
    page: number,
    pageSize: number,
    filters: Record<string, unknown>,
    module: string | undefined,
    globalFiltersVersion: number
  ) => [...granularityIssuesQueryKeys.lists(), { page, pageSize, filters, module, globalFiltersVersion }] as const,
} as const;

interface UseGranularityIssuesQueryParams {
  filters: Record<string, unknown>;
  page?: number;
  pageSize?: number;
  module?: string;
  enabled?: boolean;
}

/** Paginated (table view) list of issues at native granularity — GET /issue/all/. */
export function useGranularityIssuesQuery({
  filters,
  page = 1,
  pageSize = 10,
  module,
  enabled = true,
}: UseGranularityIssuesQueryParams) {
  const queryClient = useQueryClient();
  const globalFiltersVersion = useGlobalFiltersVersion();

  const query = useQuery({
    queryKey: granularityIssuesQueryKeys.list(page, pageSize, filters, module, globalFiltersVersion),
    queryFn: async ({ signal }): Promise<FetchGranularityIssuesResult> => {
      return fetchGranularityIssues({
        page,
        pageSize,
        filters,
        module,
        signal,
      });
    },
    enabled,
    placeholderData: keepPreviousData,
  });

  const prefetchNextPage = () => {
    if (query.data?.hasMore) {
      queryClient.prefetchQuery({
        queryKey: granularityIssuesQueryKeys.list(page + 1, pageSize, filters, module, globalFiltersVersion),
        queryFn: ({ signal }) =>
          fetchGranularityIssues({ page: page + 1, pageSize, filters, module, signal }),
      });
    }
  };

  const invalidateIssues = () => {
    queryClient.invalidateQueries({ queryKey: granularityIssuesQueryKeys.all });
  };

  return {
    issues: query.data?.results ?? [],
    total: query.data?.total ?? 0,
    hasMore: query.data?.hasMore ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    isPending: query.isPending,
    error: query.error,
    isError: query.isError,
    refetch: query.refetch,
    prefetchNextPage,
    invalidateIssues,
  };
}

export default useGranularityIssuesQuery;
