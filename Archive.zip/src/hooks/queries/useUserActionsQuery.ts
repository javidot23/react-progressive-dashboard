import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { userActionService } from "@/lib/apiServices";
import type { UserAction, UserActionsResponse } from "@/lib/apiServices";

export const userActionsQueryKeys = {
  all: ["user-actions"] as const,
  lists: () => [...userActionsQueryKeys.all, "list"] as const,
  list: (params: { page: number; pageSize: number; startDate?: string; endDate?: string }) =>
    [...userActionsQueryKeys.lists(), params] as const,
} as const;

export interface UserActionsQueryParams {
  page: number;
  pageSize: number;
  startDate?: string;
  endDate?: string;
}

interface UserActionsQueryResult {
  results: UserAction[];
  count: number;
}

/** Matches backend: created_at_after is inclusive start day; created_at_before is exclusive (start of day after range). */
export function buildDateParams(
  startDate: string,
  endDate: string
): {
  createdAtDate?: string;
  createdAtAfter?: string;
  createdAtBefore?: string;
} {
  if (startDate && endDate) {
    const endDatePlusOne = new Date(endDate);
    endDatePlusOne.setDate(endDatePlusOne.getDate() + 1);
    const endDateStr = endDatePlusOne.toISOString().split("T")[0];
    return { createdAtAfter: startDate, createdAtBefore: endDateStr };
  }
  if (startDate && !endDate) {
    const today = new Date();
    today.setDate(today.getDate() + 1);
    const todayPlusOne = today.toISOString().split("T")[0];
    return { createdAtAfter: startDate, createdAtBefore: todayPlusOne };
  }
  const dateToUse = startDate || undefined;
  return {
    createdAtDate: dateToUse,
    createdAtAfter: undefined,
    createdAtBefore: undefined,
  };
}

export function useUserActionsQuery({ page, pageSize, startDate = "", endDate = "" }: UserActionsQueryParams) {
  const query = useQuery({
    queryKey: userActionsQueryKeys.list({ page, pageSize, startDate, endDate }),
    queryFn: async ({ signal }): Promise<UserActionsResponse> => {
      const offset = (page - 1) * pageSize;
      const { createdAtDate, createdAtAfter, createdAtBefore } = buildDateParams(startDate, endDate);
      const response = await userActionService.getUserActions(
        pageSize,
        offset,
        createdAtDate,
        createdAtAfter,
        createdAtBefore,
        signal
      );
      return response.data;
    },
    select: (data): UserActionsQueryResult => {
      if (!data?.success || !data?.data) {
        return { results: [], count: 0 };
      }
      return {
        results: data.data.results,
        count: data.data.count,
      };
    },
    placeholderData: keepPreviousData,
  });

  return {
    actions: query.data?.results ?? [],
    totalActions: query.data?.count ?? 0,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    isPending: query.isPending,
    error: query.error,
    isError: query.isError,
    refetch: query.refetch,
  };
}

export default useUserActionsQuery;
