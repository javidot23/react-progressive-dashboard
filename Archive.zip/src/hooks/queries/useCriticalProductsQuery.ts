import { queryOptions, useQuery } from "@tanstack/react-query";
import { fetchGranularityIssues } from "@/services/issueService";
import type { CriticalProductDisplay } from "@/stores/slices/types";
import type { IssueAtGranularityApiData } from "@/types/granularityIssue";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const criticalProductsQueryKeys = {
  all: ["critical-products"] as const,
  list: (limit: number, globalFiltersVersion: number) =>
    [...criticalProductsQueryKeys.all, { limit, globalFiltersVersion }] as const,
};

const HIGH_RISK_MATERIALS_FILTERS = {
  status: "OPEN",
  granularity_type: "material",
  distinct_by_material: true,
  ordering: "-effective_risk_adjusted_value",
};

function transformCriticalProducts(results: IssueAtGranularityApiData[]): CriticalProductDisplay[] {
  return results.map(issue => {
    const material = issue.material;
    return {
      id: material?.id ?? issue.id,
      matNbr: material?.mat_nbr ?? "",
      name: material?.name ?? "",
      riskRating: issue.effective_risk_rating ?? material?.risk_rating ?? 0,
      drivingRisk: material?.driving_risk ?? issue.driving_event?.type ?? "",
      dollarsAtRisk: issue.effective_dollars_at_risk ?? material?.dollars_at_risk ?? 0,
      omits: 0,
      eaNumber: material?.ndc ?? "",
      saleableQtyOnHand: 0,
      qtyOrdered: 0,
      forecastQty7day: 0,
      vendor: material?.vendor?.id ?? 0,
      vendorName: material?.vendor?.name ?? undefined,
      materialGroup: undefined,
      productFamily: undefined,
      createdAt: issue.created_at ?? "",
      updatedAt: issue.updated_at ?? "",
      riskAdjustedValue: issue.effective_risk_adjusted_value,
    };
  });
}

export function criticalProductsQueryOptions(limit: number, globalFiltersVersion: number) {
  return queryOptions({
    queryKey: criticalProductsQueryKeys.list(limit, globalFiltersVersion),
    queryFn: async ({ signal }) => {
      const { results, total } = await fetchGranularityIssues({
        page: 1,
        pageSize: limit,
        filters: HIGH_RISK_MATERIALS_FILTERS,
        module: "React",
        signal,
      });
      return {
        products: transformCriticalProducts(results),
        totalCount: total,
      };
    },
  });
}

export function useCriticalProductsQuery(limit = 3) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery(criticalProductsQueryOptions(limit, globalFiltersVersion));
  return {
    criticalProducts: query.data?.products ?? [],
    totalCount: query.data?.totalCount ?? 0,
    isLoading: query.isPending,
    error: query.error?.message ?? null,
    dataUpdatedAt: query.dataUpdatedAt,
    refetch: query.refetch,
  };
}
