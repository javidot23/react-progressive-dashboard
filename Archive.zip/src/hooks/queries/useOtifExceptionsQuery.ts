import { infiniteQueryOptions, keepPreviousData, useInfiniteQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { purchaseOrderHistoryService, type OtifExceptionItem, type OtifExceptionsQueryParams } from "@/lib/apiServices";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export type OtifExceptionsFilters = Omit<OtifExceptionsQueryParams, "limit" | "offset">;

export const otifExceptionsQueryKeys = {
  all: ["otif-exceptions"] as const,
  lists: () => [...otifExceptionsQueryKeys.all, "list"] as const,
  infinite: (filters: OtifExceptionsFilters, pageSize: number, globalFiltersVersion: number) =>
    [...otifExceptionsQueryKeys.lists(), "infinite", { ...filters, pageSize, globalFiltersVersion }] as const,
} as const;

export type OtifExceptionsPage = {
  results: OtifExceptionItem[];
  count: number;
  next: string | null;
};

const emptyOtifExceptions: OtifExceptionItem[] = [];

export function otifExceptionsInfiniteQueryOptions(
  filters: OtifExceptionsFilters,
  pageSize: number,
  globalFiltersVersion: number
) {
  return infiniteQueryOptions({
    queryKey: otifExceptionsQueryKeys.infinite(filters, pageSize, globalFiltersVersion),
    queryFn: async ({ pageParam, signal }): Promise<OtifExceptionsPage> => {
      const response = await purchaseOrderHistoryService.getOtifExceptions(
        { ...filters, limit: pageSize, offset: pageParam },
        { signal }
      );

      if (!response.data.success) {
        throw new Error(response.data.message || response.data.error || "Failed to fetch OTIF exceptions");
      }

      const page = response.data.data;
      return {
        results: page.results ?? [],
        count: page.count ?? 0,
        next: page.next ?? null,
      };
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage.next) return undefined;
      const loaded = allPages.reduce((sum, page) => sum + page.results.length, 0);
      return loaded < lastPage.count ? loaded : undefined;
    },
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
  });
}

export type UseOtifExceptionsInfiniteQueryParams = {
  pageSize?: number;
  search?: string;
  ordering?: string;
  filters?: OtifExceptionsFilters;
  enabled?: boolean;
};

export function useOtifExceptionsInfiniteQuery({
  pageSize = 25,
  search = "",
  ordering = "material_number",
  filters: extraFilters = {},
  enabled = true,
}: UseOtifExceptionsInfiniteQueryParams = {}) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const filters: OtifExceptionsFilters = {
    ...extraFilters,
    ...(search.trim() ? { search: search.trim() } : {}),
    ...(ordering.trim() ? { ordering: ordering.trim() } : {}),
  };

  const query = useInfiniteQuery({
    ...otifExceptionsInfiniteQueryOptions(filters, pageSize, globalFiltersVersion),
    enabled,
  });

  const pages = query.data?.pages;
  const data = useMemo(() => pages?.flatMap(page => page.results) ?? emptyOtifExceptions, [pages]);

  return {
    data,
    total: pages?.[0]?.count ?? 0,
    hasNextPage: query.hasNextPage,
    fetchNextPage: query.fetchNextPage,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
