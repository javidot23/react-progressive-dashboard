import { useInfiniteQuery, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { fetchGranularityIssues, FetchGranularityIssuesResult } from "@/services/issueService";
import { granularityIssuesQueryKeys } from "@/hooks/queries/useGranularityIssuesQuery";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const granularityIssuesInfiniteQueryKeys = {
  all: ["granularity-issues"] as const,
  infinite: () => [...granularityIssuesInfiniteQueryKeys.all, "infinite"] as const,
  infiniteList: (
    pageSize: number,
    filters: Record<string, unknown>,
    module: string | undefined,
    globalFiltersVersion: number
  ) => [...granularityIssuesInfiniteQueryKeys.infinite(), { pageSize, filters, module, globalFiltersVersion }] as const,
} as const;

interface UseGranularityIssuesInfiniteQueryParams {
  filters: Record<string, unknown>;
  pageSize?: number;
  module?: string;
  enabled?: boolean;
}

/** Infinite (card view) list of issues at native granularity — GET /issue/all/. */
export const useGranularityIssuesInfiniteQuery = ({
  filters,
  pageSize = 10,
  module,
  enabled = true,
}: UseGranularityIssuesInfiniteQueryParams) => {
  const queryClient = useQueryClient();
  const globalFiltersVersion = useGlobalFiltersVersion();

  const query = useInfiniteQuery({
    queryKey: granularityIssuesInfiniteQueryKeys.infiniteList(pageSize, filters, module, globalFiltersVersion),
    queryFn: async ({ pageParam = 1, signal }): Promise<FetchGranularityIssuesResult & { page: number }> => {
      const result = await fetchGranularityIssues({
        page: pageParam,
        pageSize,
        filters,
        module,
        signal,
      });

      return { ...result, page: pageParam };
    },
    initialPageParam: 1,
    getNextPageParam: (lastPage, allPages) => {
      if (lastPage.hasMore) {
        return allPages.length + 1;
      }
      return undefined;
    },
    enabled,
    placeholderData: keepPreviousData,
  });

  const allIssues = query.data?.pages.flatMap(page => page.results) ?? [];
  const total = query.data?.pages[0]?.total ?? 0;

  const invalidateIssues = () => {
    queryClient.invalidateQueries({ queryKey: granularityIssuesQueryKeys.all });
  };

  return {
    issues: allIssues,
    total,
    hasMore: query.hasNextPage ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    isPlaceholderData: query.isPlaceholderData,
    error: query.error,
    isError: query.isError,
    fetchNextPage: query.fetchNextPage,
    refetch: query.refetch,
    invalidateIssues,
  };
};

export default useGranularityIssuesInfiniteQuery;
