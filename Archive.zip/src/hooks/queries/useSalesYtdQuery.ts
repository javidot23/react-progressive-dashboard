import { queryOptions, useQuery } from "@tanstack/react-query";
import { orderTransactionService, type SalesYtdData } from "@/lib/apiServices";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const salesYtdQueryKeys = {
  all: ["sales-ytd"] as const,
  detail: (globalFiltersVersion: number) => [...salesYtdQueryKeys.all, { globalFiltersVersion }] as const,
} as const;

export function salesYtdQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: salesYtdQueryKeys.detail(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<SalesYtdData> => {
      const response = await orderTransactionService.getSalesYtd({ signal });
      if (!response.data.success || !response.data.data) {
        throw new Error(response.data.message || response.data.error || "Failed to fetch sales YTD");
      }
      return response.data.data;
    },
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
}

export function useSalesYtdQuery(enabled = true) {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery({
    ...salesYtdQueryOptions(globalFiltersVersion),
    enabled,
  });

  return {
    data: query.data ?? null,
    isPending: query.isPending,
    isFetching: query.isFetching,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
