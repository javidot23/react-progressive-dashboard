import { useInfiniteQuery, useQueryClient } from "@tanstack/react-query";
import { VendorRawData } from "@/lib/vendorUtils";
import { fetchVendors } from "@/services/vendorService";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const vendorsInfiniteQueryKeys = {
  all: ["vendors"] as const,
  infinite: () => [...vendorsInfiniteQueryKeys.all, "infinite"] as const,
  infiniteList: (pageSize: number, filters: Record<string, unknown>, globalFiltersVersion: number) =>
    [...vendorsInfiniteQueryKeys.infinite(), { pageSize, filters, globalFiltersVersion }] as const,
} as const;

interface UseVendorsInfiniteQueryParams {
  filters: Record<string, unknown>;
  pageSize?: number;
  enabled?: boolean;
}

interface VendorsPageResult {
  results: VendorRawData[];
  hasMore: boolean;
  total: number;
  page: number;
}

export function useVendorsInfiniteQuery({ filters, pageSize = 10, enabled = true }: UseVendorsInfiniteQueryParams) {
  const queryClient = useQueryClient();
  const globalFiltersVersion = useGlobalFiltersVersion();

  const query = useInfiniteQuery({
    queryKey: vendorsInfiniteQueryKeys.infiniteList(pageSize, filters, globalFiltersVersion),
    queryFn: async ({ pageParam = 1, signal }): Promise<VendorsPageResult> => {
      const result = await fetchVendors(pageParam, pageSize, filters as Record<string, any>, signal);

      return { ...result, page: pageParam };
    },
    initialPageParam: 1,
    getNextPageParam: (lastPage, allPages) => {
      if (lastPage.hasMore) {
        return allPages.length + 1;
      }
      return undefined;
    },
    enabled,
  });

  const allVendors = query.data?.pages.flatMap(page => page.results) ?? [];

  const total = query.data?.pages[0]?.total ?? 0;

  const invalidateVendors = () => {
    queryClient.invalidateQueries({
      queryKey: vendorsInfiniteQueryKeys.all,
    });
  };

  return {
    vendors: allVendors,
    total,
    hasMore: query.hasNextPage ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    isPlaceholderData: query.isPlaceholderData,
    error: query.error,
    isError: query.isError,
    fetchNextPage: query.fetchNextPage,
    refetch: query.refetch,
    invalidateVendors,
  };
}

export type { VendorRawData };
export default useVendorsInfiniteQuery;
