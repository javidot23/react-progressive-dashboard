import { useQuery } from "@tanstack/react-query";
import { riskAnalysisService, type MaterialRiskWeeklyAveragesResponse } from "@/lib/apiServices";

export const materialRiskWeeklyAveragesQueryKeys = {
  all: ["material-risk-weekly-averages"] as const,
  detail: (matNbr: string) => [...materialRiskWeeklyAveragesQueryKeys.all, matNbr] as const,
};

interface UseMaterialRiskWeeklyAveragesQueryParams {
  matNbr: string | undefined;
  enabled?: boolean;
}

export function useMaterialRiskWeeklyAveragesQuery({ matNbr, enabled = true }: UseMaterialRiskWeeklyAveragesQueryParams) {
  const query = useQuery({
    queryKey: materialRiskWeeklyAveragesQueryKeys.detail(matNbr ?? ""),
    queryFn: async ({ signal }): Promise<MaterialRiskWeeklyAveragesResponse["data"] | null> => {
      if (!matNbr) {
        return null;
      }

      const response = await riskAnalysisService.getMaterialRiskWeeklyAverages({ material: matNbr }, signal);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      return null;
    },
    enabled: enabled && !!matNbr,
  });

  return {
    weeklyData: query.data ?? null,
    isLoading: query.isLoading,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}
