import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  createFeedback,
  updateFeedback,
  deleteFeedback,
  CreateFeedbackRequest,
  UpdateFeedbackRequest,
} from '@/services/feedbackService';
import { feedbackQueryKeys } from './useFeedbackQuery';

export function useCreateFeedbackMutation(options?: { silent?: boolean }) {
  const silent = options?.silent ?? false;
  return useMutation({
    mutationFn: (data: CreateFeedbackRequest) => createFeedback(data),
    meta: {
      silent,
      successMessage: "Feedback submitted",
      errorMessage: "Couldn't submit feedback",
    },
  });
}

export function useUpdateFeedbackMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: UpdateFeedbackRequest }) =>
      updateFeedback(id, data),
    meta: {
      successMessage: "Feedback updated",
      errorMessage: "Couldn't update feedback",
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: feedbackQueryKeys.all });
    },
  });
}

export function useDeleteFeedbackMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: number) => deleteFeedback(id),
    meta: {
      successMessage: "Feedback deleted",
      errorMessage: "Couldn't delete feedback",
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: feedbackQueryKeys.all });
    },
  });
}
