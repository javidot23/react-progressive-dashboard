import { useCallback } from "react";
import { keepPreviousData, queryOptions, useQuery, useQueryClient } from "@tanstack/react-query";
import { VendorRawData } from "@/lib/vendorUtils";
import { fetchVendors } from "@/services/vendorService";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const vendorsListQueryKeys = {
  all: ["vendors"] as const,
  lists: () => [...vendorsListQueryKeys.all, "list"] as const,
  list: (page: number, pageSize: number, filters: Record<string, unknown>, globalFiltersVersion: number) =>
    [...vendorsListQueryKeys.lists(), { page, pageSize, filters, globalFiltersVersion }] as const,
} as const;

/** Stable empty fallback so consumers do not recreate `[]` each render. */
export const EMPTY_VENDORS_LIST: VendorRawData[] = [];

interface UseVendorsListPaginatedQueryParams {
  filters: Record<string, unknown>;
  page?: number;
  pageSize?: number;
  enabled?: boolean;
}

interface VendorsListResult {
  results: VendorRawData[];
  hasMore: boolean;
  total: number;
}

export function vendorsListPaginatedQueryOptions({
  page,
  pageSize,
  filters,
  globalFiltersVersion,
}: {
  page: number;
  pageSize: number;
  filters: Record<string, unknown>;
  globalFiltersVersion: number;
}) {
  return queryOptions({
    queryKey: vendorsListQueryKeys.list(page, pageSize, filters, globalFiltersVersion),
    queryFn: async ({ signal }): Promise<VendorsListResult> => {
      return fetchVendors(page, pageSize, filters, signal);
    },
    placeholderData: keepPreviousData,
  });
}

export function useVendorsListPaginatedQuery({
  filters,
  page = 1,
  pageSize = 10,
  enabled = true,
}: UseVendorsListPaginatedQueryParams) {
  const queryClient = useQueryClient();
  const globalFiltersVersion = useGlobalFiltersVersion();

  const options = vendorsListPaginatedQueryOptions({
    page,
    pageSize,
    filters,
    globalFiltersVersion,
  });

  const query = useQuery({
    ...options,
    enabled,
  });

  const prefetchNextPage = useCallback(() => {
    if (!query.data?.hasMore) return;
    void queryClient.prefetchQuery(
      vendorsListPaginatedQueryOptions({
        page: page + 1,
        pageSize,
        filters,
        globalFiltersVersion,
      })
    );
  }, [query.data?.hasMore, queryClient, page, pageSize, filters, globalFiltersVersion]);

  const invalidateVendors = useCallback(() => {
    void queryClient.invalidateQueries({
      queryKey: vendorsListQueryKeys.all,
    });
  }, [queryClient]);

  return {
    vendors: query.data?.results ?? EMPTY_VENDORS_LIST,
    total: query.data?.total ?? 0,
    hasMore: query.data?.hasMore ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isPlaceholderData: query.isPlaceholderData,
    isPending: query.isPending,
    error: query.error,
    isError: query.isError,
    refetch: query.refetch,
    prefetchNextPage,
    invalidateVendors,
  };
}

export type { VendorRawData };
export default useVendorsListPaginatedQuery;
