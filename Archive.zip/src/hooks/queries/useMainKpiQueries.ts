import { queryOptions, useQuery } from "@tanstack/react-query";
import {
  issuesService,
  riskAnalysisService,
  type KPIQueryParams,
} from "@/lib/apiServices";
import { transformOtifResponse, transformMaterialRiskWeeklyAveragesResponse } from "@/stores/slices/transformers";
import type {
  OtifData,
  TwoWeekSummary,
  WeeklyOtifLineCountsData,
  WeeklyRiskAnalysis,
  ValueAtRiskTrendData,
  KPITrendPoint,
  WeeklyOpenCount,
} from "@/stores/slices/types";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";
import { transformWeeklyOpenCountResponse } from "@/stores/slices/transformers";

export const mainKpiQueryKeys = {
  all: ["main-kpi"] as const,
  otifData: (globalFiltersVersion: number) =>
    [...mainKpiQueryKeys.all, "otif-data", { globalFiltersVersion }] as const,
  twoWeekSummary: (globalFiltersVersion: number) =>
    [...mainKpiQueryKeys.all, "two-week-summary", { globalFiltersVersion }] as const,
  weeklyOtifLineCounts: (globalFiltersVersion: number) =>
    [...mainKpiQueryKeys.all, "weekly-otif-line-counts", { globalFiltersVersion }] as const,
  aggregateRisk: (globalFiltersVersion: number) =>
    [...mainKpiQueryKeys.all, "aggregate-risk", { globalFiltersVersion }] as const,
  weeklyOpenCount: () => [...mainKpiQueryKeys.all, "weekly-open-count"] as const,
};

export interface AggregateRiskKpiData {
  weeklyRiskAnalysis: WeeklyRiskAnalysis & {
    aggregateRiskScore: number;
    totalDollarsAtRisk: number;
    productsCount: number;
    weekStart: string;
    weekEnd: string;
    analysisDate: string;
    kpiValue?: number;
    kpiPreviousValue?: number;
    trend?: unknown;
  };
  valueAtRiskTrend: ValueAtRiskTrendData;
}

function buildValueAtRiskTrend(apiData: NonNullable<Awaited<ReturnType<typeof riskAnalysisService.getMaterialRiskWeeklyAverages>>["data"]["data"]>): ValueAtRiskTrendData {
  const points: KPITrendPoint[] = (apiData.trend?.points ?? []).map((p: { period_start: string; period_end: string; metrics?: { avg_dollars_at_risk?: number } }) => {
    const avgDollars = p.metrics?.avg_dollars_at_risk ?? 0;
    return {
      period_start: p.period_start,
      period_end: p.period_end,
      value: avgDollars,
      metrics: {
        value_at_risk: avgDollars,
        avg_dollars_at_risk: avgDollars,
      },
    };
  });

  return {
    kpiValue: apiData.average_dollars_at_risk_this_week ?? 0,
    kpiPreviousValue: apiData.average_dollars_at_risk_last_week ?? 0,
    trend: {
      kpi: "value_at_risk",
      unit: "currency",
      points,
    },
  };
}

function buildWeeklyRiskAnalysis(
  responseBody: Awaited<ReturnType<typeof riskAnalysisService.getMaterialRiskWeeklyAverages>>["data"]
): AggregateRiskKpiData["weeklyRiskAnalysis"] {
  const apiData = responseBody.data!;
  const weeklyAveragesData = transformMaterialRiskWeeklyAveragesResponse(responseBody);

  return {
    aggregateRiskScore: weeklyAveragesData.averageRiskScoreThisWeek ?? 0,
    totalDollarsAtRisk: weeklyAveragesData.averageDollarsAtRiskThisWeek ?? 0,
    productsCount: 0,
    weekStart: weeklyAveragesData.thisWeekStart ?? "",
    weekEnd: weeklyAveragesData.thisWeekEnd ?? "",
    analysisDate: new Date().toISOString().split("T")[0],
    averageRiskScoreThisWeek: weeklyAveragesData.averageRiskScoreThisWeek ?? 0,
    averageRiskScoreLastWeek: weeklyAveragesData.averageRiskScoreLastWeek ?? 0,
    averageDollarsAtRiskThisWeek: weeklyAveragesData.averageDollarsAtRiskThisWeek ?? 0,
    averageDollarsAtRiskLastWeek: weeklyAveragesData.averageDollarsAtRiskLastWeek ?? 0,
    thisWeekStart: weeklyAveragesData.thisWeekStart ?? "",
    thisWeekEnd: weeklyAveragesData.thisWeekEnd ?? "",
    lastWeekStart: weeklyAveragesData.lastWeekStart ?? "",
    lastWeekEnd: weeklyAveragesData.lastWeekEnd ?? "",
    kpiValue: apiData.kpi_value ?? weeklyAveragesData.averageRiskScoreThisWeek,
    kpiPreviousValue: apiData.kpi_previous_value ?? weeklyAveragesData.averageRiskScoreLastWeek,
    trend: apiData.trend,
  };
}

export function aggregateRiskKpiQueryOptions(globalFiltersVersion: number, params?: KPIQueryParams) {
  return queryOptions({
    queryKey: mainKpiQueryKeys.aggregateRisk(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<AggregateRiskKpiData> => {
      const response = await riskAnalysisService.getMaterialRiskWeeklyAverages(params, signal);
      if (!response.data.success || !response.data.data) {
        throw new Error("Failed to fetch risk KPI data");
      }
      return {
        weeklyRiskAnalysis: buildWeeklyRiskAnalysis(response.data),
        valueAtRiskTrend: buildValueAtRiskTrend(response.data.data!),
      };
    },
  });
}

export function otifDataQueryOptions(globalFiltersVersion: number, params?: KPIQueryParams) {
  return queryOptions({
    queryKey: mainKpiQueryKeys.otifData(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<OtifData> => {
      const response = await issuesService.getOtif30DaySummary(params, signal);
      if (!response.data.success) {
        throw new Error("Failed to fetch OTIF data");
      }
      return transformOtifResponse(response.data);
    },
  });
}

export function twoWeekSummaryQueryOptions(globalFiltersVersion: number, params?: KPIQueryParams) {
  return queryOptions({
    queryKey: mainKpiQueryKeys.twoWeekSummary(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<TwoWeekSummary> => {
      const response = await issuesService.getTodaySnapshot(params, signal);
      if (!response.data?.success || !response.data?.data) {
        throw new Error("Failed to fetch today snapshot");
      }
      const apiData = response.data.data;
      return {
        open_issues: apiData.open_issues,
        total_issues: apiData.total_issues,
        snapshot_date: apiData.snapshot_date,
        kpiValue: apiData.kpi_value ?? apiData.open_issues,
        kpiTotal: apiData.kpi_total ?? apiData.total_issues,
        trend: apiData.trend,
      };
    },
  });
}

export function weeklyOtifLineCountsQueryOptions(globalFiltersVersion: number) {
  return queryOptions({
    queryKey: mainKpiQueryKeys.weeklyOtifLineCounts(globalFiltersVersion),
    queryFn: async ({ signal }): Promise<WeeklyOtifLineCountsData[]> => {
      const response = await issuesService.getWeeklyOtifLineCounts(signal);
      if (!response.data?.success || !response.data?.data) {
        throw new Error("Failed to fetch weekly OTIF line counts");
      }
      return response.data.data;
    },
  });
}

export function weeklyOpenCountQueryOptions() {
  return queryOptions({
    queryKey: mainKpiQueryKeys.weeklyOpenCount(),
    queryFn: async ({ signal }): Promise<WeeklyOpenCount> => {
      const response = await issuesService.getWeeklyOpenCount(signal);
      return transformWeeklyOpenCountResponse(response.data);
    },
  });
}

export function useOtifDataQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery(otifDataQueryOptions(globalFiltersVersion));
  return {
    otifData: query.data ?? null,
    isLoading: query.isPending,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}

export function useTwoWeekSummaryQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery(twoWeekSummaryQueryOptions(globalFiltersVersion));
  return {
    twoWeekSummary: query.data ?? null,
    isLoading: query.isPending,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}

export function useWeeklyOtifLineCountsQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery(weeklyOtifLineCountsQueryOptions(globalFiltersVersion));
  return {
    weeklyOtifLineCounts: query.data ?? [],
    isLoading: query.isPending,
    isFetched: query.isFetched,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}

export function useAggregateRiskKpiQuery() {
  const globalFiltersVersion = useGlobalFiltersVersion();
  const query = useQuery(aggregateRiskKpiQueryOptions(globalFiltersVersion));
  return {
    weeklyRiskAnalysis: query.data?.weeklyRiskAnalysis ?? null,
    valueAtRiskTrend: query.data?.valueAtRiskTrend ?? null,
    isLoading: query.isPending,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}

export function useWeeklyOpenCountQuery() {
  const query = useQuery(weeklyOpenCountQueryOptions());
  return {
    weeklyOpenCount: query.data ?? null,
    isLoading: query.isPending,
    error: query.error?.message ?? null,
    dataUpdatedAt: query.dataUpdatedAt,
    refetch: query.refetch,
  };
}
