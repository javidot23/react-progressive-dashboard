import { useQuery } from "@tanstack/react-query";
import { isAxiosError } from "axios";
import { supplyChainEventsService, type DetailedSupplyChainEvent } from "@/lib/apiServices";

export const issueDrivingEventQueryKeys = {
  all: ["issue-driving-event"] as const,
  detail: (issueId: number) => [...issueDrivingEventQueryKeys.all, issueId] as const,
};

interface UseIssueDrivingEventQueryParams {
  issueId: number | undefined;
  enabled?: boolean;
}

export function useIssueDrivingEventQuery({ issueId, enabled = true }: UseIssueDrivingEventQueryParams) {
  const query = useQuery({
    queryKey: issueDrivingEventQueryKeys.detail(issueId ?? 0),
    queryFn: async ({ signal }): Promise<DetailedSupplyChainEvent | null> => {
      if (issueId == null || !Number.isFinite(issueId) || issueId <= 0) {
        return null;
      }

      try {
        const response = await supplyChainEventsService.getIssueDrivingEvent(issueId, signal);
        if (response.data.success && response.data.data) {
          return response.data.data;
        }
        return null;
      } catch (error) {
        if (isAxiosError(error) && error.response?.status === 404) {
          return null;
        }
        throw error;
      }
    },
    enabled: enabled && issueId != null && Number.isFinite(issueId) && issueId > 0,
  });

  return {
    event: query.data ?? null,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    error: query.error?.message ?? null,
    refetch: query.refetch,
  };
}
