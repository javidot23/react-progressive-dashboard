import { useQuery, queryOptions } from "@tanstack/react-query";
import { supplyChainEventsService, type DetailedSupplyChainEvent, type SupplyChainEventWithLocation } from "@/lib/apiServices";
import { supplyChainEventsQueryKeys } from "./useSupplyChainEventsWithLocationQuery";

export function supplyChainEventDetailQueryOptions(eventId: number | string | null) {
  return queryOptions({
    queryKey: supplyChainEventsQueryKeys.detail(eventId ?? ""),
    queryFn: async ({ signal }): Promise<DetailedSupplyChainEvent> => {
      if (!eventId) {
        throw new Error("Event ID is required");
      }

      const response = await supplyChainEventsService.getSupplyChainEvent(eventId, signal);

      const data = response.data;
      if (!data.success || !data.data) {
        throw new Error("Failed to fetch event details");
      }

      return data.data;
    },
    enabled: !!eventId,
  });
}

interface UseSupplyChainEventDetailQueryParams {
  eventId: number | string | null;
  enabled?: boolean;
}

export function detailedEventToBasicEvent(detailed: DetailedSupplyChainEvent): SupplyChainEventWithLocation {
  return {
    id: detailed.id,
    event_id: detailed.event_id,
    type: detailed.type,
    type_description: detailed.type_description,
    status: detailed.status,
    start_date: detailed.start_date,
    end_date: detailed.end_date,
    latitude: detailed.latitude ?? 0,
    longitude: detailed.longitude ?? 0,
    mat_nbr: detailed.mat_nbr,
    metadata: detailed.metadata,
    created_at: detailed.created_at,
    updated_at: detailed.updated_at,
  };
}

export function useSupplyChainEventDetailQuery({ eventId, enabled = true }: UseSupplyChainEventDetailQueryParams) {
  const options = supplyChainEventDetailQueryOptions(eventId);

  const query = useQuery({
    ...options,
    enabled: enabled && !!eventId,
  });

  return {
    detailedEvent: query.data ?? null,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isPending: query.isPending,
    error: query.error,
    isError: query.isError,
    refetch: query.refetch,
  };
}
