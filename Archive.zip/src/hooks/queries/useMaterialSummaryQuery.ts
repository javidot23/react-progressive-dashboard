import { queryOptions, useQuery, keepPreviousData } from "@tanstack/react-query";
import { materialSummaryService } from "@/lib/apiServices";
import { transformMaterialSummaryToPurchaseOrder } from "@/components/manage/supply/overview/ManageSupplyTableView";
import { useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";

export const materialSummaryQueryKeys = {
  all: ["material-summary"] as const,
  lists: () => [...materialSummaryQueryKeys.all, "list"] as const,
  list: (page: number, pageSize: number, filters: Record<string, unknown>, globalFiltersVersion: number) =>
    [...materialSummaryQueryKeys.lists(), { page, pageSize, filters, globalFiltersVersion }] as const,
} as const;

export interface MaterialSummaryQueryResult {
  results: ReturnType<typeof transformMaterialSummaryToPurchaseOrder>[];
  count: number;
}

export function materialSummaryQueryOptions(
  page: number,
  pageSize: number,
  filters: Record<string, unknown>,
  globalFiltersVersion: number
) {
  return queryOptions({
    queryKey: materialSummaryQueryKeys.list(page, pageSize, filters, globalFiltersVersion),
    queryFn: async ({ signal }): Promise<MaterialSummaryQueryResult> => {
      const offset = (page - 1) * pageSize;
      const ordering = typeof filters.ordering === "string" ? filters.ordering : "-units_ordered";

      const response = await materialSummaryService.getMaterialSummary(
        pageSize,
        offset,
        ordering,
        filters as Record<string, unknown>,
        { signal }
      );

      if (!response.data.success) {
        throw new Error("Failed to fetch data");
      }

      return {
        results: response.data.data.results.map(transformMaterialSummaryToPurchaseOrder),
        count: response.data.data.count,
      };
    },
    placeholderData: keepPreviousData,
    refetchOnWindowFocus: false,
  });
}

interface UseMaterialSummaryQueryParams {
  page?: number;
  pageSize?: number;
  filters: Record<string, unknown>;
  enabled?: boolean;
}

export function useMaterialSummaryQuery({ page = 1, pageSize = 10, filters, enabled = true }: UseMaterialSummaryQueryParams) {
  const globalFiltersVersion = useGlobalFiltersVersion();

  const query = useQuery({
    ...materialSummaryQueryOptions(page, pageSize, filters, globalFiltersVersion),
    enabled,
  });

  return {
    data: query.data?.results ?? [],
    total: query.data?.count ?? 0,
    isPending: query.isPending,
    isFetching: query.isFetching,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
