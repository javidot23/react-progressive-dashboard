import { useState, useEffect, useRef } from "react";
import apiClient from "@/lib/apiClient";

interface UseIssuesDataProps {
  filters: Record<string, any>;
  page?: number;
  pageSize?: number;
  module?: string;
}

export const useIssuesData = ({
  filters,
  page = 1,
  pageSize = 10,
  module
}: UseIssuesDataProps) => {
  const [issues, setIssues] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [total, setTotal] = useState(0);
  const isFetching = useRef(false);
  const previousFiltersRef = useRef<string>(JSON.stringify(filters));
  const previousPageRef = useRef<number>(page);

  const fetchData = async (pageNumber: number, size: number, append: boolean = false) => {
    if (isFetching.current) return;

    isFetching.current = true;
    setLoading(true);

    try {


      const offset = (pageNumber - 1) * size;
      const queryParams = new URLSearchParams();
      queryParams.append("limit", size.toString());
      queryParams.append("offset", offset.toString());
      queryParams.append("ordering", filters.ordering || "-risk_adjusted_value");

      Object.entries(filters).forEach(([key, value]) => {
        if (
          value !== null &&
          value !== undefined &&
          value !== "" &&
          key !== "ordering"
        ) {
          queryParams.append(key, value.toString());
        }
      });

      // Add module filter if provided
      if (module) {
        queryParams.append("module", module);
      }

      const response = await apiClient.get(
        `/issue/?${queryParams.toString()}`
      );

      const data = response.data;

      if (data.success && data.data && Array.isArray(data.data.results)) {
        const hasMoreResults = data.data.next !== null;
        const totalCount = data.data.count || 0;

        if (append) {
          // For infinite scroll, append new results
          setIssues(prev => [...prev, ...data.data.results]);
        } else {
          // For initial load or filter change, replace results
          setIssues(data.data.results);
        }
        setHasMore(hasMoreResults);
        setTotal(totalCount);
      } else {
        throw new Error("API response indicates failure or missing results");
      }
    } catch (err) {
      console.error("Error fetching issues:", err);
    } finally {
      setLoading(false);
      isFetching.current = false;
    }
  };

  // Fetch data when page, pageSize, or filters change
  useEffect(() => {
    const currentFiltersStr = JSON.stringify(filters);
    const filtersChanged = previousFiltersRef.current !== currentFiltersStr;
    const pageIncreased = page > previousPageRef.current && !filtersChanged;

    // Reset issues when filters change
    if (filtersChanged) {
      setIssues([]);
    }

    // Determine if we should append or replace data
    const shouldAppend = pageIncreased && previousPageRef.current > 0;

    if (shouldAppend) {
      // Loading more pages (infinite scroll) - append data
      fetchData(page, pageSize, true);
    } else {
      // Initial load, filter change, or reset to page 1 - replace data
      fetchData(page, pageSize, false);
    }

    // Update refs for next comparison
    previousFiltersRef.current = currentFiltersStr;
    previousPageRef.current = page;
  }, [page, pageSize, filters]);

  const refetch = () => {
    fetchData(page, pageSize);
  };

  return {
    issues,
    loading,
    hasMore,
    total,
    refetch,
  };
};
