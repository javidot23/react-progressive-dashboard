import { useState, useEffect, useCallback, useRef } from "react";
import { useSearchParams } from "react-router-dom";

const PREFIX = "cs_";

const DEFAULT_FILTERS = {
  ordering: "-invoice_date",
};

function serializeContractSalesFilters(filters: Record<string, unknown>): URLSearchParams {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "") {
      params.set(`${PREFIX}${key}`, value.toString());
    }
  });
  return params;
}

function deserializeContractSalesFilters(searchParams: URLSearchParams): Record<string, unknown> {
  const filters = { ...DEFAULT_FILTERS };
  for (const [key, value] of searchParams.entries()) {
    if (key.startsWith(PREFIX)) {
      const filterKey = key.slice(PREFIX.length);
      if (filterKey in filters) {
        (filters as Record<string, unknown>)[filterKey] = value;
      }
    }
  }
  return filters;
}

export function useContractSalesFilters() {
  const [searchParams, setSearchParams] = useSearchParams();
  const searchParamsRef = useRef(searchParams);
  searchParamsRef.current = searchParams;

  const [filters, setFiltersState] = useState<Record<string, unknown>>(() => deserializeContractSalesFilters(searchParams));

  const setFilters = useCallback(
    (newFilters: Record<string, unknown>) => {
      setFiltersState(newFilters);
      const params = new URLSearchParams(searchParamsRef.current);
      for (const key of [...params.keys()]) {
        if (key.startsWith(PREFIX)) params.delete(key);
      }
      const newParams = serializeContractSalesFilters(newFilters);
      newParams.forEach((value, key) => params.set(key, value));
      setSearchParams(params, { replace: true });
    },
    [setSearchParams]
  );

  useEffect(() => {
    setFiltersState(deserializeContractSalesFilters(searchParams));
  }, [searchParams]);

  return { filters, setFilters };
}
