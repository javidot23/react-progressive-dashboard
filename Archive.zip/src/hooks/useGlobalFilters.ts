// Global Filters: URL ↔ localStorage ↔ UI sync with proper {id, label} model

import { getGcnLabel } from "@/lib/gcnLabels";
import { toWafSafeQueryString } from "@/lib/queryStringUtils";

export interface FilterValue {
  id: string | number;
  label: string;
}

export type GlobalFilters = Record<string, FilterValue | FilterValue[]>;

const LS_KEY = 'global_filters';

// Label cache for resolving IDs back to labels when hydrating from URL
const labelCache = new Map<string, string>();

/**
 * Store a label in the cache for later lookup
 */
export function cacheLabelForId(filterKey: string, id: string | number, label: string) {
  const cacheKey = `${filterKey}:${id}`;
  labelCache.set(cacheKey, label);
}

/**
 * Resolve a label from cache, fallback to ID if not found
 */
export function resolveLabelForId(filterKey: string, id: string | number): string {
  const cacheKey = `${filterKey}:${id}`;
  return labelCache.get(cacheKey) || String(id);
}

/**
 * Mapping from gf_* keys to human-readable filter names
 */
export const FILTER_NAME_MAP: Record<string, string> = {
  gf_supplier: 'Supplier',
  gf_product_category: 'Product Category',
  gf_therapeutic_class: 'Therapeutic Class',
  gf_buyer: 'Buyer',
  gf_category_manager: 'Category Manager',
  gf_material: 'Material',
  gf_gcn: getGcnLabel(),
  gf_formulary: 'Formulary',
  gf_formulary_program: 'Formulary Program',
};

/**
 * Read global filters from URL query params (gf_* keys only)
 * Reconstructs {id, label} objects using label cache
 */
export function readGFfromUrl(search: string): GlobalFilters {
  const p = new URLSearchParams(search);
  const out: GlobalFilters = {};

  p.forEach((v, k) => {
    if (k.startsWith('gf_')) {
      const id = v;
      const label = resolveLabelForId(k, id);
      const filterValue: FilterValue = { id, label };

      // Check if key already exists (for multi-value params)
      if (out[k]) {
        if (Array.isArray(out[k])) {
          (out[k] as FilterValue[]).push(filterValue);
        } else {
          out[k] = [out[k] as FilterValue, filterValue];
        }
      } else {
        out[k] = filterValue;
      }
    }
  });

  return out;
}

/**
 * Write global filters to URL (only serialize IDs, not full objects)
 */
export function writeGFtoUrl(
  prevSearch: string,
  gf: GlobalFilters,
  method: 'replace' | 'push' = 'replace'
) {
  const p = new URLSearchParams(prevSearch);

  // Remove all existing gf_* keys
  [...p.keys()].forEach(k => {
    if (k.startsWith('gf_')) p.delete(k);
  });

  // Add new gf_* keys (only IDs, not objects)
  Object.entries(gf).forEach(([k, v]) => {
    if (!k.startsWith('gf_')) return;

    if (Array.isArray(v)) {
      v.forEach((item: FilterValue) => {
        if (item && item.id) {
          p.append(k, String(item.id));
          // Cache the label for future lookups
          cacheLabelForId(k, item.id, item.label);
        }
      });
    } else if (v && typeof v === 'object' && 'id' in v) {
      const item = v as FilterValue;
      if (item.id !== '' && item.id !== null && item.id !== undefined) {
        p.set(k, String(item.id));
        // Cache the label for future lookups
        cacheLabelForId(k, item.id, item.label);
      }
    }
  });

  const s = toWafSafeQueryString(p);
  const url = s ? `${location.pathname}?${s}` : location.pathname;

  if (method === 'push') {
    history.pushState(null, '', url);
  } else {
    history.replaceState(null, '', url);
  }
}

/**
 * Read global filters from localStorage
 */
export function readGFfromLS(): GlobalFilters {
  try {
    const data = JSON.parse(localStorage.getItem(LS_KEY) || '{}');
    // Populate cache with labels from localStorage
    Object.entries(data).forEach(([k, v]) => {
      if (Array.isArray(v)) {
        v.forEach((item: FilterValue) => {
          if (item && item.id && item.label) {
            cacheLabelForId(k, item.id, item.label);
          }
        });
      } else if (v && typeof v === 'object' && 'id' in v) {
        const item = v as FilterValue;
        if (item.id && item.label) {
          cacheLabelForId(k, item.id, item.label);
        }
      }
    });
    return data;
  } catch {
    return {};
  }
}

/**
 * Write global filters to localStorage (with full {id, label} objects)
 */
export function writeGFtoLS(gf: GlobalFilters) {
  localStorage.setItem(LS_KEY, JSON.stringify(gf));
}

/**
 * Merge URL and localStorage filters (URL wins on conflicts)
 */
export function mergePriorityUrl(urlGF: GlobalFilters, lsGF: GlobalFilters): GlobalFilters {
  return { ...lsGF, ...urlGF };
}
