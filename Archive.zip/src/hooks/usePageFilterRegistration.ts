import { useId, useLayoutEffect, type ReactNode } from "react";
import { usePageFiltersActions, type PageFiltersRegistrationOptions } from "@/contexts/PageFiltersContext";

/**
 * Registers page filter UI with ManageLayout. Pass a memoized `slot` so registration
 * updates only when filter props actually change.
 *
 * Uses actions-only context so the registering component does not re-render when REGISTER
 * updates layout state (avoids effect ↔ setState loops).
 */
export function usePageFilterRegistration(slot: ReactNode, options: PageFiltersRegistrationOptions): void {
  const { registerPageFilters, unregisterPageFilters } = usePageFiltersActions();
  const registrationId = useId();
  const { hasActiveFilters, onClearAllFilters } = options;

  useLayoutEffect(() => {
    registerPageFilters(slot, registrationId, { hasActiveFilters, onClearAllFilters });

    return () => unregisterPageFilters(registrationId);
  }, [slot, registrationId, hasActiveFilters, onClearAllFilters, registerPageFilters, unregisterPageFilters]);
}
