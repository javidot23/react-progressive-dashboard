import { useQuery } from "@tanstack/react-query";
import { riskModelDescriptionService } from "@/lib/apiServices";

function formatModelNameForDisplay(modelName: string | null | undefined): string {
  if (modelName == null || typeof modelName !== "string") return "";
  return modelName.replace(/_/g, " ").replace(/-/g, " ");
}

function modelTypeToCategoryTitle(modelType: string): string {
  if (modelType === "category_risk_group") return "Category Risk";
  if (modelType === "composite_risk_group") return "Composite Risk";
  if (modelType.startsWith("base_model_")) {
    const suffix = modelType.replace("base_model_", "");
    return suffix.charAt(0).toUpperCase() + suffix.slice(1) + " Risk";
  }
  return modelType.replace(/_/g, " ");
}

export interface RiskCategoryType {
  type: string;
  title: string;
}

export const MAIN_RISK_GROUP_TYPES = [
  "base_model_operational",
  "base_model_market",
  "base_model_sales",
  "base_model_regulatory",
  "base_model_location",
] as const;

export const ALLOWED_TOP_LEVEL_RISK_GROUP_TYPES = [...MAIN_RISK_GROUP_TYPES] as const;

export interface EnrichedRiskMetadata {
  original_risk_type: string;
  risk_type: string;
  risk_description: string;
  display_name: string;
}

export const useRiskModelDescriptions = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ["risk-model-descriptions"],
    queryFn: async () => {
      const response = await riskModelDescriptionService.getRiskModelDescriptions();
      if (!response.data.success || !Array.isArray(response.data.data)) {
        return { byModelName: {} as Record<string, { model_type: string; model_description: string; display_name: string }> };
      }
      const byModelName: Record<string, { model_type: string; model_description: string; display_name: string }> = {};
      for (const item of response.data.data) {
        if (!byModelName[item.model_name]) {
          byModelName[item.model_name] = {
            model_type: item.model_type,
            model_description: item.model_description,
            display_name: item.display_name,
          };
        }
      }
      return { byModelName };
    },
  });

  const riskCategoryTypes: RiskCategoryType[] = ALLOWED_TOP_LEVEL_RISK_GROUP_TYPES.map(type => ({
    type,
    title: modelTypeToCategoryTitle(type),
  }));

  const getEnrichedMetadata = (riskType: string | null | undefined): EnrichedRiskMetadata => {
    const safeType = riskType ?? "";
    const meta = data?.byModelName?.[safeType];
    return {
      original_risk_type: safeType,
      risk_type: meta?.model_type ?? safeType,
      risk_description: meta?.model_description ?? formatModelNameForDisplay(safeType),
      display_name: meta?.display_name ?? formatModelNameForDisplay(safeType),
    };
  };

  const enrichRiskData = <T extends { risk_type: string }>(rawItems: T[]): (T & EnrichedRiskMetadata)[] => {
    return rawItems.map(item => ({
      ...item,
      ...getEnrichedMetadata(item.risk_type),
    }));
  };

  const mapRiskTypeToModelType = (riskType: string): string => {
    return getEnrichedMetadata(riskType).risk_type;
  };

  return {
    isLoading,
    error,
    riskCategoryTypes,
    getEnrichedMetadata,
    enrichRiskData,
    mapRiskTypeToModelType,
  };
};
