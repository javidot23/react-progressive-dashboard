import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { serializeInventoryFilters, deserializeInventoryFilters } from "@/lib/inventoryFilterUtils";

export const useInventoryFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const [filters, setFiltersState] = useState(() => {
    return deserializeInventoryFilters(searchParams);
  });

  const setFilters = (newFilters: any) => {
    setFiltersState(newFilters);

    const currentParams = new URLSearchParams(searchParams);
    const newParams = serializeInventoryFilters(newFilters);

    const inventoryFilterKeys = [
      'ordering', 'material_mat_nbr',
      'dc_min', 'dc_max',
      'dc_low_min', 'dc_low_max',
      'doh_days_min', 'doh_days_max', 'active_doh_zone',
      'sortBy',
      'dc_plants_ordering',
    ];

    inventoryFilterKeys.forEach(key => currentParams.delete(key));


    newParams.forEach((value, key) => {
      currentParams.set(key, value);
    });

    setSearchParams(currentParams, { replace: true });
  };


  useEffect(() => {
    const newFilters = deserializeInventoryFilters(searchParams);
    setFiltersState(newFilters);
  }, [searchParams]);

  return {
    filters,
    setFilters,
  };
};
