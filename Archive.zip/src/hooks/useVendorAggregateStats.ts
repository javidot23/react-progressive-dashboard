import { useQuery } from "@tanstack/react-query";
import { vendorAggregateStatsService } from "@/lib/apiServices";

export const useVendorAggregateStats = () => {
  return useQuery({
    queryKey: ["vendor", "aggregate-stats"],
    queryFn: async () => {
      const response = await vendorAggregateStatsService.getVendorAggregateStats();
      return response.data.data;
    },
  });
};
