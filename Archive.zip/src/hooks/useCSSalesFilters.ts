import { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import { getCSalesTabFromParams } from "@/constants/csSalesTabs";
import { getDateRangeFromCurrentPeriod, getDateRangeFromHistoricalPeriod } from "@/lib/csSalesDateUtils";

const DEFAULT_PREFIX = "cssales_";

function getDefaultDateRange(): { date_from: string; date_to: string } {
  const range = getDateRangeFromHistoricalPeriod("Last 12 months");
  return range ?? { date_from: "", date_to: "" };
}

function getDefaultDateRangeForCurrent(): { date_from: string; date_to: string } {
  const range = getDateRangeFromCurrentPeriod("MTD");
  return range ? { date_from: range.date_from, date_to: range.date_to } : getDefaultDateRange();
}

const DEFAULT_DATE_RANGE = getDefaultDateRange();

function serializeDateRange(filters: { date_from: string; date_to: string }, prefix: string): URLSearchParams {
  const params = new URLSearchParams();
  if (filters.date_from) params.set(`${prefix}date_from`, filters.date_from);
  if (filters.date_to) params.set(`${prefix}date_to`, filters.date_to);
  return params;
}

function deserializeDateRange(
  searchParams: URLSearchParams,
  tab: "historical" | "current",
  prefix: string
): { date_from: string; date_to: string } {
  const defaults = tab === "current" ? getDefaultDateRangeForCurrent() : getDefaultDateRange();
  const date_from = searchParams.get(`${prefix}date_from`) ?? defaults.date_from;
  const date_to = searchParams.get(`${prefix}date_to`) ?? defaults.date_to;
  return { date_from, date_to };
}

export function useCSSalesFilters(options?: { urlPrefix?: string }) {
  const prefix = options?.urlPrefix ?? DEFAULT_PREFIX;
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = getCSalesTabFromParams(searchParams);

  const [dateRange, setDateRangeState] = useState<{ date_from: string; date_to: string }>(() =>
    deserializeDateRange(searchParams, tab, prefix)
  );

  const setDateRange = useCallback(
    (newRange: { date_from: string; date_to: string }) => {
      setDateRangeState(newRange);
      const params = new URLSearchParams(searchParams);
      if (prefix) {
        for (const key of [...params.keys()]) {
          if (key.startsWith(prefix)) params.delete(key);
        }
      } else {
        params.delete("date_from");
        params.delete("date_to");
      }
      const newParams = serializeDateRange(newRange, prefix);
      newParams.forEach((value, key) => params.set(key, value));
      setSearchParams(params, { replace: true });
    },
    [searchParams, setSearchParams, prefix]
  );

  useEffect(() => {
    setDateRangeState(deserializeDateRange(searchParams, tab, prefix));
  }, [searchParams, tab, prefix]);

  useEffect(() => {
    const dateFromKey = `${prefix}date_from`;
    const dateToKey = `${prefix}date_to`;
    const hasDateParams = searchParams.has(dateFromKey) || searchParams.has(dateToKey);
    if (!hasDateParams) {
      const defaultRange = tab === "current" ? getDefaultDateRangeForCurrent() : DEFAULT_DATE_RANGE;
      setDateRangeState(defaultRange);
      const params = new URLSearchParams(searchParams);
      params.set(dateFromKey, defaultRange.date_from);
      params.set(dateToKey, defaultRange.date_to);
      setSearchParams(params, { replace: true });
    }
  }, [tab, searchParams, setSearchParams, prefix]);

  const hasActiveDateFilters =
    tab === "historical" &&
    (dateRange.date_from !== DEFAULT_DATE_RANGE.date_from || dateRange.date_to !== DEFAULT_DATE_RANGE.date_to);

  const clearDateRange = useCallback(() => {
    setDateRange(DEFAULT_DATE_RANGE);
  }, [setDateRange]);

  return {
    tab,
    dateRange,
    setDateRange,
    hasActiveDateFilters,
    clearDateRange,
    defaultDateRange: DEFAULT_DATE_RANGE,
  };
}
