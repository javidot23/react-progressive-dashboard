import { useQuery } from '@tanstack/react-query';
import apiClient from '@/lib/apiClient';

export interface AuthMeProfile {
  id: string;
  displayName?: string;
  mail?: string;
  userPrincipalName?: string;
  givenName?: string;
  surname?: string;
  jobTitle?: string;
  photoDataUrl?: string;
  department?: string;
}

interface ApiProfileResponse {
  id: string;
  displayName?: string;
  mail?: string;
  userPrincipalName?: string;
  givenName?: string;
  surname?: string;
  jobTitle?: string;
  department?: string;
  profilePicture?: string;
  photoDataUrl?: string;
}

const mapApiResponseToProfile = (payload: ApiProfileResponse): AuthMeProfile => ({
  id: payload.id,
  displayName: payload.displayName,
  mail: payload.mail,
  userPrincipalName: payload.userPrincipalName,
  givenName: payload.givenName,
  surname: payload.surname,
  jobTitle: payload.jobTitle,
  department: payload.department,
  photoDataUrl: payload.profilePicture || payload.photoDataUrl,
});

export const PROFILE_QUERY_KEY = ['auth', 'me'] as const;

export const useProfile = () => {
  const query = useQuery<AuthMeProfile>({
    queryKey: PROFILE_QUERY_KEY,
    queryFn: async () => {
      const res = await apiClient.get('/auth/me/');
      const payload = res?.data?.data ?? res?.data;
      return mapApiResponseToProfile(payload);
    },
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });

  return {
    profile: query.data,
    isLoading: query.isLoading,
    error: (query.error as Error) || null,
    refetch: query.refetch,
  };
};

export default useProfile;
