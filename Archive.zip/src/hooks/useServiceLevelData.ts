import type { ServiceLevelPlantData } from "@/lib/apiServices";
import {
  getDefaultServiceLevelPlantsDateRange,
  useServiceLevelPlantsQuery,
} from "@/hooks/queries/useServiceLevelQueries";

export interface ServiceLevelDataHook {
  data: ServiceLevelPlantData[];
  loading: boolean;
  error: string | null;
  refetch: () => void;
}

export const useServiceLevelData = (): ServiceLevelDataHook => {
  const query = useServiceLevelPlantsQuery();

  return {
    data: query.data ?? [],
    loading: query.isPending,
    error: query.error ? (query.error instanceof Error ? query.error.message : "Failed to fetch service level data") : null,
    refetch: () => {
      void query.refetch();
    },
  };
};

export { getDefaultServiceLevelPlantsDateRange };
