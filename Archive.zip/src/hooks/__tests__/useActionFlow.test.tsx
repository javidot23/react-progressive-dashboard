import "@testing-library/jest-dom";
import { act, renderHook } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MemoryRouter } from "react-router-dom";
import React from "react";

import { useActionFlow, NO_ACTION_TYPE } from "../useActionFlow";
import { toast } from "@/lib/toast";

jest.mock("@/lib/toast", () => ({
  toast: {
    success: jest.fn(),
    error: jest.fn(),
    dismiss: jest.fn(),
  },
}));

const mockMutateAsync = jest.fn();

jest.mock("@/hooks/queries/useActionMutation", () => ({
  __esModule: true,
  default: () => ({
    mutateAsync: (...args: unknown[]) => mockMutateAsync(...args),
    isPending: false,
  }),
}));

jest.mock("@/hooks/queries", () => ({
  issuesQueryKeys: { all: ["issues"] as const },
  materialsQueryKeys: { byVendor: (id: number) => ["materials", "vendor", id] as const },
  materialActionHistoryQueryKeys: { all: ["material-action-history"] as const },
  issueByIdQueryKeys: { all: ["issue-by-id"] as const },
}));

jest.mock("@/hooks/queries/useRemoveActionMutation", () => ({
  __esModule: true,
  default: () => ({
    mutate: jest.fn(),
    isPending: false,
  }),
}));

jest.mock("@/contexts/AuthContext", () => ({
  useAuth: () => ({ user: { entra_id: "u1" } }),
}));

jest.mock("@/lib/materialActionOwnership", () => ({
  isMaterialActionOwner: () => true,
}));

jest.mock("@/lib/actionTracking", () => ({
  incrementCompletedActionsCount: jest.fn(() => 11),
  shouldShowDecisionRationaleModal: jest.fn(() => false),
}));

const mockSubmitDecisionRationale = jest.fn();
jest.mock("@/services/actionService", () => ({
  submitDecisionRationale: (...args: unknown[]) => mockSubmitDecisionRationale(...args),
}));

import { incrementCompletedActionsCount, shouldShowDecisionRationaleModal } from "@/lib/actionTracking";

const material = {
  id: 1,
  mat_nbr: "MAT-1",
  name: "Material",
  vendor: { id: 10, name: "V", driving_risk: "" },
  risk_rating: 1,
  driving_risk: "Operational",
  dollars_at_risk: 0,
} as import("@/lib/types").MaterialWithIssues;

function createWrapper() {
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });
  return function Wrapper({ children }: { children: React.ReactNode }) {
    return (
      <QueryClientProvider client={client}>
        <MemoryRouter>{children}</MemoryRouter>
      </QueryClientProvider>
    );
  };
}

describe("useActionFlow grouped toasts", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.mocked(incrementCompletedActionsCount).mockReturnValue(11);
    jest.mocked(shouldShowDecisionRationaleModal).mockReturnValue(false);
    mockMutateAsync.mockResolvedValue({ id: 99 });
  });

  it("shows action-applied toast immediately when decision rationale modal does not open", async () => {
    const { result } = renderHook(() => useActionFlow({ material, issueNbr: "ISS-1", vendorId: 1 }), {
      wrapper: createWrapper(),
    });

    await act(async () => {
      await result.current.handleActionClick(NO_ACTION_TYPE);
    });

    expect(toast.success).toHaveBeenCalledTimes(1);
    expect(toast.success).toHaveBeenCalledWith({
      title: "Action applied",
      description: "No action required was recorded.",
    });
    expect(result.current.modalState.type).toBe("closed");
  });
});
