import "@testing-library/jest-dom";
import { hasActiveImpactedMaterialFilters, useImpactedMaterialSelection } from "../useImpactedMaterialSelection";
import { renderHook, act } from "@testing-library/react";
import type { IssueImpactedMaterialApiData } from "@/types/granularityIssue";

const materials: IssueImpactedMaterialApiData[] = [
  {
    id: 1,
    mat_nbr: "MAT-1",
    name: "A",
    ndc: "1",
    vendor: "V",
    vendor_nbr: "N",
    risk_rating: 0.5,
    driving_risk: "x",
    dollars_at_risk: 10,
  },
  {
    id: 2,
    mat_nbr: "MAT-2",
    name: "B",
    ndc: "2",
    vendor: "V",
    vendor_nbr: "N",
    risk_rating: 0.5,
    driving_risk: "x",
    dollars_at_risk: 20,
  },
];

describe("hasActiveImpactedMaterialFilters", () => {
  it("returns false for default filters", () => {
    expect(hasActiveImpactedMaterialFilters({ ordering: "-risk_adjusted_value" })).toBe(false);
  });

  it("returns true when a range filter is set", () => {
    expect(
      hasActiveImpactedMaterialFilters({
        ordering: "-risk_adjusted_value",
        risk_rating_min: 0.5,
        risk_rating_max: 1,
      })
    ).toBe(true);
  });
});

describe("useImpactedMaterialSelection", () => {
  it("defaults to all grain selected with no exclusions", () => {
    const { result } = renderHook(() =>
      useImpactedMaterialSelection({
        materials,
        materialsTotal: 72,
        impactedCount: 72,
        matFilters: { ordering: "-risk_adjusted_value" },
      })
    );
    expect(result.current.applyToWholeGrain).toBe(true);
    expect(result.current.selectedCount).toBe(72);
    expect(result.current.grainExcludedCount).toBe(0);
  });

  it("tracks exclusions across the grain without breaking whole-grain apply", () => {
    const { result } = renderHook(() =>
      useImpactedMaterialSelection({
        materials,
        materialsTotal: 72,
        impactedCount: 72,
        matFilters: { ordering: "-risk_adjusted_value" },
      })
    );
    act(() => result.current.toggle("MAT-1"));
    expect(result.current.applyToWholeGrain).toBe(false);
    expect(result.current.selectedCount).toBe(71);
    expect(result.current.grainExcludedCount).toBe(1);
  });

  it("scopes to filtered total when mat filters are active", () => {
    const { result } = renderHook(() =>
      useImpactedMaterialSelection({
        materials,
        materialsTotal: 5,
        impactedCount: 40,
        matFilters: {
          ordering: "-risk_adjusted_value",
          risk_rating_min: 0.5,
          risk_rating_max: 1,
        },
      })
    );
    expect(result.current.applyToWholeGrain).toBe(false);
    expect(result.current.actionScopeTotal).toBe(5);
    expect(result.current.selectedCount).toBe(5);
  });
});
