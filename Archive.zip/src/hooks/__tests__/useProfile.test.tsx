import { renderHook, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useProfile } from "@/hooks/useProfile";
import React from "react";

const mockApiClient = {
  get: jest.fn(),
};

jest.mock("@/lib/apiClient", () => ({
  __esModule: true,
  default: {
    get: (...args: unknown[]) => mockApiClient.get(...args),
  },
}));

const mockProfileResponse = {
  id: "user-123",
  displayName: "John Doe",
  mail: "john.doe@example.com",
  givenName: "John",
  surname: "Doe",
  userPrincipalName: "john.doe@example.com",
  jobTitle: "Software Engineer",
  profilePicture: "https://example.com/photo.jpg",
};

const createWrapper = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: 0,
      },
    },
  });

  return ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
  );
};

describe("useProfile", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("fetches profile on mount", async () => {
    mockApiClient.get.mockResolvedValue({
      data: { data: mockProfileResponse },
    });

    const { result } = renderHook(() => useProfile(), {
      wrapper: createWrapper(),
    });

    expect(result.current.isLoading).toBe(true);

    await waitFor(() => {
      expect(result.current.isLoading).toBe(false);
    });

    expect(mockApiClient.get).toHaveBeenCalledTimes(1);
    expect(mockApiClient.get).toHaveBeenCalledWith("/auth/me/");
    expect(result.current.profile).toEqual({
      id: "user-123",
      displayName: "John Doe",
      mail: "john.doe@example.com",
      givenName: "John",
      surname: "Doe",
      userPrincipalName: "john.doe@example.com",
      jobTitle: "Software Engineer",
      photoDataUrl: "https://example.com/photo.jpg",
    });
  });

  it("maps profilePicture to photoDataUrl", async () => {
    mockApiClient.get.mockResolvedValue({
      data: { data: mockProfileResponse },
    });

    const { result } = renderHook(() => useProfile(), {
      wrapper: createWrapper(),
    });

    await waitFor(() => {
      expect(result.current.profile?.photoDataUrl).toBe("https://example.com/photo.jpg");
    });
  });

  it("handles API error", async () => {
    const error = new Error("API Error");
    mockApiClient.get.mockRejectedValue(error);

    const { result } = renderHook(() => useProfile(), {
      wrapper: createWrapper(),
    });

    await waitFor(
      () => {
        expect(result.current.isLoading).toBe(false);
        expect(result.current.error).toBeTruthy();
      },
      { timeout: 5000 }
    );
  });
});
