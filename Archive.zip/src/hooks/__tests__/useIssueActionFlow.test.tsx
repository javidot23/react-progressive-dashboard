import "@testing-library/jest-dom";
import { act, renderHook, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MemoryRouter } from "react-router-dom";
import React from "react";

import { useIssueActionFlow, NO_ACTION_TYPE, SWITCH_MANUFACTURER_TYPE } from "../useIssueActionFlow";
import type { PotentialAction } from "@/lib/types";

const mockMutateAsync = jest.fn();
const mockNavigate = jest.fn();

jest.mock("@/lib/toast", () => ({
  toast: { success: jest.fn(), error: jest.fn(), dismiss: jest.fn() },
}));

jest.mock("@/hooks/queries/useActionMutation", () => ({
  useActionMutation: () => ({
    mutateAsync: (...args: unknown[]) => mockMutateAsync(...args),
    isPending: false,
  }),
}));

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: () => mockNavigate,
}));

const materials = [
  { id: 1, mat_nbr: "MAT-1", name: "A", dollarsAtRisk: 10 },
  { id: 2, mat_nbr: "MAT-2", name: "B", dollarsAtRisk: 20 },
  { id: 3, mat_nbr: "MAT-3", name: "C", dollarsAtRisk: 30 },
];

const potentialAction: PotentialAction = {
  id: 1,
  paction_nbr: "PA-1",
  issue_nbr: "ISS-1",
  action_type: "Operational",
  recommendation: "Put Item to Bid",
  recommendation_type_nbr: "26",
  action_category: "Strategic",
  recommended_action_flag: true,
  status: null,
  module: "React",
  created_at: "",
  updated_at: "",
  material: "",
};

function wrapper() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={client}>
      <MemoryRouter>{children}</MemoryRouter>
    </QueryClientProvider>
  );
}

function setup(params: Partial<Parameters<typeof useIssueActionFlow>[0]> = {}) {
  return renderHook(
    () =>
      useIssueActionFlow({
        issueId: 100,
        issueNbr: "ISS-1",
        selectedMaterials: materials,
        applyToWholeGrain: true,
        selectedCount: 3,
        totalCount: 3,
        aggregate: { riskRating: 0.8, drivingRisk: "x", dollarsAtRisk: 60 },
        ...params,
      }),
    { wrapper: wrapper() }
  );
}

beforeEach(() => {
  jest.clearAllMocks();
  mockMutateAsync.mockResolvedValue({ id: 1, created: [{}, {}, {}], skipped: [] });
});

describe("useIssueActionFlow", () => {
  it("omits mat_nbrs when applying to whole grain", async () => {
    const { result } = setup({ applyToWholeGrain: true });
    act(() => result.current.handleActionClick("26", potentialAction));
    expect(result.current.modalState.type).toBe("keepInMind");
    await act(async () => {
      result.current.handleKeepInMindContinue();
    });
    await waitFor(() => expect(mockMutateAsync).toHaveBeenCalled());
    expect(mockMutateAsync.mock.calls[0][0]).toMatchObject({
      issueNbr: "ISS-1",
      matNbrs: undefined,
      potentialActionNbr: "PA-1",
    });
  });

  it("sends the selected mat_nbrs when it is a subset", async () => {
    const { result } = setup({
      applyToWholeGrain: false,
      selectedCount: 2,
      selectedMaterials: [materials[0], materials[2]],
    });
    act(() => result.current.handleActionClick("26", potentialAction));
    await act(async () => {
      result.current.handleKeepInMindContinue();
    });
    await waitFor(() => expect(mockMutateAsync).toHaveBeenCalled());
    expect(mockMutateAsync.mock.calls[0][0].matNbrs).toEqual(["MAT-1", "MAT-3"]);
  });

  it("resolves mat_nbrs via resolveMatNbrs when not applying to whole grain", async () => {
    const resolveMatNbrs = jest.fn().mockResolvedValue(["MAT-1", "MAT-2", "MAT-3"]);
    const { result } = setup({
      applyToWholeGrain: false,
      selectedCount: 3,
      selectedMaterials: [],
      resolveMatNbrs,
    });
    act(() => result.current.handleActionClick("26", potentialAction));
    await act(async () => {
      result.current.handleKeepInMindContinue();
    });
    await waitFor(() => expect(mockMutateAsync).toHaveBeenCalled());
    expect(resolveMatNbrs).toHaveBeenCalled();
    expect(mockMutateAsync.mock.calls[0][0].matNbrs).toEqual(["MAT-1", "MAT-2", "MAT-3"]);
  });

  it("posts immediately for No Action Required without opening a modal", async () => {
    const { result } = setup();
    await act(async () => {
      result.current.handleActionClick(NO_ACTION_TYPE);
    });
    await waitFor(() => expect(mockMutateAsync).toHaveBeenCalled());
    expect(result.current.modalState.type).toBe("closed");
    expect(mockMutateAsync.mock.calls[0][0].actionType).toBe(NO_ACTION_TYPE);
  });

  it("navigates to substitution analysis when exactly one material is selected", () => {
    const { result } = setup({
      applyToWholeGrain: false,
      selectedCount: 1,
      selectedMaterials: [materials[0]],
    });
    act(() => result.current.handleActionClick(SWITCH_MANUFACTURER_TYPE, potentialAction));
    expect(mockNavigate).toHaveBeenCalledTimes(1);
    expect(mockNavigate.mock.calls[0][0]).toContain("/react/substitution-analysis");
    expect(mockMutateAsync).not.toHaveBeenCalled();
  });

  it("guards bulk substitution: does nothing when more than one material is selected", () => {
    const { result } = setup({
      applyToWholeGrain: false,
      selectedCount: 2,
      selectedMaterials: [materials[0], materials[1]],
    });
    act(() => result.current.handleActionClick(SWITCH_MANUFACTURER_TYPE, potentialAction));
    expect(mockNavigate).not.toHaveBeenCalled();
    expect(mockMutateAsync).not.toHaveBeenCalled();
  });
});
