import { useState, useEffect, useRef } from 'react';
import { vendorsService } from '@/lib/apiServices';

const pendingVendorRequests = new Map<string, Promise<any>>();

let cacheCleanupIntervalId: ReturnType<typeof setInterval> | undefined;
let cacheCleanupSubscriberCount = 0;
let cacheCleanupConfig: { map: Map<string, Promise<any>>; maxSize: number } | null =
  null;

function startPendingCacheCleanup(
  map: Map<string, Promise<any>>,
  maxSize: number,
  intervalMs: number
) {
  cacheCleanupConfig = { map, maxSize };
  cacheCleanupSubscriberCount += 1;
  if (cacheCleanupIntervalId === undefined) {
    cacheCleanupIntervalId = setInterval(() => {
      if (
        cacheCleanupConfig &&
        cacheCleanupConfig.map.size > cacheCleanupConfig.maxSize
      ) {
        cacheCleanupConfig.map.clear();
      }
    }, intervalMs);
  }
}

function stopPendingCacheCleanup() {
  cacheCleanupSubscriberCount -= 1;
  if (cacheCleanupSubscriberCount <= 0) {
    if (cacheCleanupIntervalId !== undefined) {
      clearInterval(cacheCleanupIntervalId);
      cacheCleanupIntervalId = undefined;
    }
    cacheCleanupSubscriberCount = 0;
    cacheCleanupConfig = null;
  }
}

interface UseVendorFromListParams {
  vendorId: number;
}

interface VendorFromList {
  id: number;
  name: string;
  vendor_nbr: string;
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  risk_rating: number;
  driving_risk: string;
  created_at: string;
  updated_at: string;
  materials_at_risk?: number;
  total_materials?: number;
  sales_volume?: number | null;
  sales_amount?: number | null;
  risk_adjusted_value?: number | null;
  inbound_fill_rate?: number | null;
  outbound_fill_rate?: number | null;
  product_damages_rate?: number | null;
  otif_percentage?: number | null;
  overall_score?: number | null;
  asn_timeliness?: number | null;
  asn_essential?: number | null;
  vendor_group?: string;
  cat_mgr_list?: string[];
  buyer_list?: string[];
  service_levels_90_days?: Array<{
    material__vendor_id?: string;
    date: string;
    avg_fill_rate: number;
    total_order_qty?: number;
    total_received_qty?: number;
  }>;
}

interface UseVendorFromListReturn {
  vendor: VendorFromList | null;
  loading: boolean;
  error: string | null;
}

export function useVendorFromList({
  vendorId
}: UseVendorFromListParams): UseVendorFromListReturn {
  const [vendor, setVendor] = useState<VendorFromList | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const requestIdRef = useRef<string | null>(null);
  const isMountedRef = useRef(true);
  const retryTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    startPendingCacheCleanup(pendingVendorRequests, 5, 30_000);
    return () => stopPendingCacheCleanup();
  }, []);

  useEffect(() => {
    isMountedRef.current = true;

    const fetchVendor = async (retryCount = 0) => {
      try {
        if (!isMountedRef.current) return;
        setLoading(true);
        setError(null);

        const requestKey = `vendor-by-id-${vendorId}`;

        if (pendingVendorRequests.has(requestKey)) {
          const response = await pendingVendorRequests.get(requestKey)!;

          if (!isMountedRef.current) return;
          if (response.data.success) {
            setVendor(response.data.data);
          } else {
            setError(`Vendor with ID ${vendorId} not found`);
          }
          return;
        }

        requestIdRef.current = requestKey;

        const requestPromise =
          vendorsService.getVendorByIdWithServiceLevels(vendorId);
        pendingVendorRequests.set(requestKey, requestPromise);

        const response = await requestPromise;

        pendingVendorRequests.delete(requestKey);

        if (!isMountedRef.current) return;
        if (requestIdRef.current === requestKey) {
          if (response.data.success) {
            setVendor(response.data.data);
          } else {
            setError('API returned unsuccessful response for vendor data');
          }
        }
      } catch (err: any) {
        console.error('Error fetching vendor by ID:', err);

        const requestKey = `vendor-by-id-${vendorId}`;
        pendingVendorRequests.delete(requestKey);

        let errorMessage = 'Failed to fetch vendor data';

        if (err.code === 'ECONNABORTED') {
          errorMessage = 'Request timed out. Please try again.';
        } else if (err.response) {
          if (err.response.status === 404) {
            errorMessage = `Vendor with ID ${vendorId} not found`;
          } else {
            errorMessage = `Server error: ${err.response.status} ${err.response.statusText}`;
          }
        } else if (err.request) {
          errorMessage =
            'Network error. Please check your connection and try again.';
        }

        if (
          retryCount < 2 &&
          (err.code === 'ECONNABORTED' || !err.response) &&
          isMountedRef.current
        ) {
          retryTimeoutRef.current = setTimeout(() => {
            retryTimeoutRef.current = null;
            if (isMountedRef.current) {
              fetchVendor(retryCount + 1);
            }
          }, 1000 * (retryCount + 1));
          return;
        }

        if (!isMountedRef.current) return;
        if (requestIdRef.current === requestKey) {
          setError(errorMessage);
        }
      } finally {
        if (isMountedRef.current) {
          setLoading(false);
        }
      }
    };

    if (vendorId && vendorId > 0) {
      fetchVendor();
    } else {
      setLoading(false);
    }

    return () => {
      isMountedRef.current = false;
      if (retryTimeoutRef.current !== null) {
        clearTimeout(retryTimeoutRef.current);
        retryTimeoutRef.current = null;
      }
    };
  }, [vendorId]);

  return {
    vendor,
    loading,
    error
  };
}
