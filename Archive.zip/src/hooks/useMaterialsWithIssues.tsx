import { useState, useEffect, useRef } from 'react';
import { materialsWithIssuesService } from '@/lib/apiServices';
import type { MaterialWithIssues } from '@/lib/types';

const pendingRequests = new Map<string, Promise<any>>();

let cacheCleanupIntervalId: ReturnType<typeof setInterval> | undefined;
let cacheCleanupSubscriberCount = 0;
let cacheCleanupConfig: { map: Map<string, Promise<any>>; maxSize: number } | null =
  null;

function startPendingCacheCleanup(
  map: Map<string, Promise<any>>,
  maxSize: number,
  intervalMs: number
) {
  cacheCleanupConfig = { map, maxSize };
  cacheCleanupSubscriberCount += 1;
  if (cacheCleanupIntervalId === undefined) {
    cacheCleanupIntervalId = setInterval(() => {
      if (
        cacheCleanupConfig &&
        cacheCleanupConfig.map.size > cacheCleanupConfig.maxSize
      ) {
        cacheCleanupConfig.map.clear();
      }
    }, intervalMs);
  }
}

function stopPendingCacheCleanup() {
  cacheCleanupSubscriberCount -= 1;
  if (cacheCleanupSubscriberCount <= 0) {
    if (cacheCleanupIntervalId !== undefined) {
      clearInterval(cacheCleanupIntervalId);
      cacheCleanupIntervalId = undefined;
    }
    cacheCleanupSubscriberCount = 0;
    cacheCleanupConfig = null;
  }
}

interface UseMaterialsWithIssuesParams {
  vendorId: number | null;
  limit?: number;
  offset?: number;
}

interface UseMaterialsWithIssuesReturn {
  materials: MaterialWithIssues[];
  loading: boolean;
  error: string | null;
  totalCount: number;
  hasMore: boolean;
  loadMore: () => void;
  refresh: () => void;
}

export function useMaterialsWithIssues({
  vendorId,
  limit = 10,
  offset = 0
}: UseMaterialsWithIssuesParams): UseMaterialsWithIssuesReturn {
  const [materials, setMaterials] = useState<MaterialWithIssues[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [currentOffset, setCurrentOffset] = useState(offset);
  const [hasMore, setHasMore] = useState(false);
  const requestIdRef = useRef<string | null>(null);
  const isMountedRef = useRef(true);
  const retryTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    startPendingCacheCleanup(pendingRequests, 10, 30_000);
    return () => stopPendingCacheCleanup();
  }, []);

  const fetchMaterials = async (isLoadMore = false, retryCount = 0) => {
    try {
      if (!isMountedRef.current) return;
      setLoading(true);
      setError(null);

      const offsetToUse = isLoadMore ? currentOffset : 0;
      const requestKey = `materials-${vendorId}-${limit}-${offsetToUse}`;

      if (pendingRequests.has(requestKey)) {
        const response = await pendingRequests.get(requestKey)!;

        if (!isMountedRef.current) return;
        if (response.data.success) {
          const newMaterials = response.data.data.results;

          if (isLoadMore) {
            setMaterials(prev => [...prev, ...newMaterials]);
          } else {
            setMaterials(newMaterials);
          }

          setTotalCount(response.data.data.count);
          setHasMore(response.data.data.next !== null);

          if (isLoadMore) {
            setCurrentOffset(prev => prev + limit);
          } else {
            setCurrentOffset(limit);
          }
        }
        return;
      }

      requestIdRef.current = requestKey;

      const requestPromise = materialsWithIssuesService.getMaterialsWithIssues(
        vendorId!,
        limit,
        offsetToUse
      );

      pendingRequests.set(requestKey, requestPromise);

      const response = await requestPromise;

      pendingRequests.delete(requestKey);

      if (!isMountedRef.current) return;
      if (requestIdRef.current === requestKey) {
        if (response.data.success) {
          const newMaterials = response.data.data.results;

          if (isLoadMore) {
            setMaterials(prev => [...prev, ...newMaterials]);
          } else {
            setMaterials(newMaterials);
          }

          setTotalCount(response.data.data.count);
          setHasMore(response.data.data.next !== null);

          if (isLoadMore) {
            setCurrentOffset(prev => prev + limit);
          } else {
            setCurrentOffset(limit);
          }
        } else {
          setError('API returned unsuccessful response');
        }
      }
    } catch (err: any) {
      console.error('Error fetching materials with issues:', err);

      const offsetToUse = isLoadMore ? currentOffset : 0;
      const requestKey = `materials-${vendorId}-${limit}-${offsetToUse}`;
      pendingRequests.delete(requestKey);

      let errorMessage = 'Failed to fetch materials with issues';

      if (err.code === 'ECONNABORTED') {
        errorMessage = 'Request timed out. Please try again.';
      } else if (err.response) {
        errorMessage = `Server error: ${err.response.status} ${err.response.statusText}`;
      } else if (err.request) {
        errorMessage =
          'Network error. Please check your connection and try again.';
      }

      if (
        retryCount < 2 &&
        (err.code === 'ECONNABORTED' || !err.response) &&
        isMountedRef.current
      ) {
        retryTimeoutRef.current = setTimeout(() => {
          retryTimeoutRef.current = null;
          if (isMountedRef.current) {
            fetchMaterials(isLoadMore, retryCount + 1);
          }
        }, 1000 * (retryCount + 1));
        return;
      }

      if (!isMountedRef.current) return;
      if (requestIdRef.current === requestKey) {
        setError(errorMessage);
      }
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  };

  const loadMore = () => {
    if (!loading && hasMore) {
      fetchMaterials(true);
    }
  };

  const refresh = () => {
    setCurrentOffset(0);
    fetchMaterials(false);
  };

  useEffect(() => {
    isMountedRef.current = true;

    if (vendorId && vendorId > 0) {
      fetchMaterials(false);
    } else {
      setMaterials([]);
      setTotalCount(0);
      setHasMore(false);
      setLoading(false);
      setError(null);
    }

    return () => {
      isMountedRef.current = false;
      if (retryTimeoutRef.current !== null) {
        clearTimeout(retryTimeoutRef.current);
        retryTimeoutRef.current = null;
      }
    };
  }, [vendorId, limit]);

  return {
    materials,
    loading,
    error,
    totalCount,
    hasMore,
    loadMore,
    refresh
  };
}
