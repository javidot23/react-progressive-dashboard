/**
 * Unit tests for ``fetchFilterRanges``.
 *
 * Mocks ``apiClient`` so we can assert the params forwarded to axios (module
 * + keys + page params) and the response unwrapping logic. The service MUST
 * pass params via ``config.params`` so the global-filters axios interceptor
 * can inspect/modify them — this is verified directly below.
 */
import { buildFilterRangesRequestParams, fetchFilterRanges } from "@/services/filterRangesService";

jest.mock("@/lib/apiClient", () => ({
  __esModule: true,
  default: { get: jest.fn() },
}));

import apiClient from "@/lib/apiClient";

const mockedGet = apiClient.get as jest.MockedFunction<typeof apiClient.get>;

describe("fetchFilterRanges", () => {
  beforeEach(() => {
    mockedGet.mockReset();
  });

  it("calls the endpoint via apiClient.get with params in axios config", async () => {
    mockedGet.mockResolvedValueOnce({
      data: {
        success: true,
        data: { module: "issue", ranges: { risk_score: { min: 0, max: 92 } } },
      },
    } as any);

    const result = await fetchFilterRanges({
      module: "issue",
      keys: ["risk_score"],
    });

    expect(mockedGet).toHaveBeenCalledTimes(1);
    const [url, config] = mockedGet.mock.calls[0]!;
    // URL must NOT bake the query string — the axios interceptor inspects
    // config.params and would miss params encoded into the URL.
    expect(url).toBe("/filter-ranges/");
    expect(config).toEqual({
      params: { module: "issue", keys: "risk_score" },
    });
    expect(result.ranges.risk_score).toEqual({ min: 0, max: 92 });
  });

  it("forwards page-level params (and skips empty values)", async () => {
    mockedGet.mockResolvedValueOnce({
      data: { success: true, data: { module: "inventory", ranges: {} } },
    } as any);

    await fetchFilterRanges({
      module: "inventory",
      keys: ["dc_low"],
      params: { threshold: 0.6, supplier: "", vendor_nbr: undefined, label: "x" },
    });

    const config = mockedGet.mock.calls[0]![1] as { params: Record<string, string> };
    expect(config.params).toEqual({
      module: "inventory",
      keys: "dc_low",
      threshold: "0.6",
      label: "x",
    });
    expect(config.params).not.toHaveProperty("supplier");
    expect(config.params).not.toHaveProperty("vendor_nbr");
  });

  it("supports an empty keys array (= no keys requested)", async () => {
    mockedGet.mockResolvedValueOnce({
      data: { success: true, data: { module: "issue", ranges: {} } },
    } as any);

    await fetchFilterRanges({ module: "issue", keys: [] });

    const config = mockedGet.mock.calls[0]![1] as { params: Record<string, string> };
    expect(config.params).toEqual({ module: "issue", keys: "" });
  });

  it("omits the keys param entirely when keys is undefined", async () => {
    mockedGet.mockResolvedValueOnce({
      data: { success: true, data: { module: "issue", ranges: {} } },
    } as any);

    await fetchFilterRanges({ module: "issue" });

    const config = mockedGet.mock.calls[0]![1] as { params: Record<string, string> };
    expect(config.params).toEqual({ module: "issue" });
  });

  it("unwraps the SuccessJsonResponse envelope", async () => {
    mockedGet.mockResolvedValueOnce({
      data: {
        success: true,
        data: {
          module: "material",
          ranges: { risk_adjusted_value: { min: 0, max: 1234 } },
        },
      },
    } as any);

    const result = await fetchFilterRanges({ module: "material" });
    expect(result.module).toBe("material");
    expect(result.ranges.risk_adjusted_value.max).toBe(1234);
  });

  it("accepts a non-wrapped response shape (test/dev compatibility)", async () => {
    mockedGet.mockResolvedValueOnce({
      data: {
        module: "issue",
        ranges: { risk_score: { min: 0, max: 50 } },
      },
    } as any);

    const result = await fetchFilterRanges({ module: "issue" });
    expect(result.ranges.risk_score.max).toBe(50);
  });

  it("forwards all_issues params including granularity_type scoping", async () => {
    mockedGet.mockResolvedValueOnce({
      data: {
        success: true,
        data: {
          module: "all_issues",
          ranges: {
            effective_risk_adjusted_value: { min: 0, max: 86578 },
            effective_dollars_at_risk: { min: 0, max: 99769 },
            effective_risk_rating: { min: 0, max: 87 },
            impacted_material_count: { min: 0, max: 1 },
          },
        },
      },
    } as any);

    const result = await fetchFilterRanges({
      module: "all_issues",
      keys: ["effective_risk_adjusted_value", "effective_dollars_at_risk", "impacted_material_count"],
      params: { granularity_type: "gcn" },
    });

    const config = mockedGet.mock.calls[0]![1] as { params: Record<string, string> };
    expect(config.params).toEqual({
      module: "all_issues",
      keys: "effective_risk_adjusted_value,effective_dollars_at_risk,impacted_material_count",
      granularity_type: "gcn",
    });
    expect(result.ranges.effective_dollars_at_risk.max).toBe(99769);
  });

  it("forwards issue_impacted_materials params scoped by issue_id", async () => {
    mockedGet.mockResolvedValueOnce({
      data: {
        success: true,
        data: {
          module: "issue_impacted_materials",
          ranges: {
            risk_adjusted_value: { min: 0, max: 14649 },
            dollars_at_risk: { min: 0, max: 77096 },
            risk_score: { min: 0, max: 19 },
          },
        },
      },
    } as any);

    const result = await fetchFilterRanges({
      module: "issue_impacted_materials",
      keys: ["risk_adjusted_value", "dollars_at_risk"],
      params: { issue_id: 60 },
    });

    const config = mockedGet.mock.calls[0]![1] as { params: Record<string, string> };
    expect(config.params).toEqual({
      module: "issue_impacted_materials",
      keys: "risk_adjusted_value,dollars_at_risk",
      issue_id: "60",
    });
    expect(result.ranges.risk_score.max).toBe(19);
  });

  it("throws on a malformed payload", async () => {
    mockedGet.mockResolvedValueOnce({ data: { success: false } } as any);
    await expect(fetchFilterRanges({ module: "issue" })).rejects.toThrow(/missing data/);
  });
});

describe("buildFilterRangesRequestParams", () => {
  it("normalizes module / keys / params into a flat string-record", () => {
    expect(
      buildFilterRangesRequestParams({
        module: "purchase_order_failed_scans",
        keys: ["a", "b"],
        params: { days: 90, supplier: "1", empty: "", missing: undefined, n: null },
      })
    ).toEqual({
      module: "purchase_order_failed_scans",
      keys: "a,b",
      days: "90",
      supplier: "1",
    });
  });

  it("omits keys when undefined and preserves empty-array semantics", () => {
    expect(buildFilterRangesRequestParams({ module: "issue" })).toEqual({ module: "issue" });
    expect(buildFilterRangesRequestParams({ module: "issue", keys: [] })).toEqual({ module: "issue", keys: "" });
  });

  it("drops boolean values defensively (the backend's numeric parsers fail on them)", () => {
    // The public type forbids booleans, but tests must hold the line in
    // case a caller bypasses the type checker (e.g. via ``any``).
    expect(
      buildFilterRangesRequestParams({
        module: "purchase_order_failed_scans",
        params: {
          days: 90,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          stale: true as any,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          fresh: false as any,
        },
      })
    ).toEqual({ module: "purchase_order_failed_scans", days: "90" });
  });
});
