import { MaterialWithIssues } from "@/lib/types";
import apiClient from "@/lib/apiClient";

export const fetchMaterialsWithIssues = async (
  vendorId: number,
  page: number,
  pageSize: number,
  filters: Record<string, any> = {},
  signal?: AbortSignal
): Promise<{ results: MaterialWithIssues[]; hasMore: boolean; total: number }> => {
  // Build query parameters
  const params: Record<string, any> = {
    limit: pageSize,
    offset: (page - 1) * pageSize,
  };

  // Add ordering
  if (filters.ordering) {
    params.ordering = filters.ordering;
  }

  // Temporarily disable API filtering for risk score to test frontend filtering
  // Add filter parameters if they exist (excluding risk rating filters for now)
  Object.entries(filters).forEach(([key, value]) => {
    if (
      value !== null &&
      value !== undefined &&
      value !== "" &&
      key !== "ordering" &&
      key !== "risk_rating_min" &&
      key !== "risk_rating_max"
    ) {
      params[key] = value;
    }
  });

  const response = await apiClient.get(`/vendor/${vendorId}/materials-with-issues/`, { params, signal });
  const results: MaterialWithIssues[] = response.data?.data?.results ?? [];
  const total = response.data?.data?.count ?? 0;

  return {
    results,
    hasMore: Boolean(response.data?.data?.next),
    total,
  };
};
