import apiClient from "@/lib/apiClient";
import { VendorRawData } from "@/lib/vendorUtils";

// Cache for driving risk options to prevent duplicate calls
let drivingRiskCache: { data: string[] | null; promise: Promise<string[]> | null } = {
  data: null,
  promise: null,
};

let materialDrivingRiskCache: { data: string[] | null; promise: Promise<string[]> | null } = {
  data: null,
  promise: null,
};

export const fetchVendors = async (
  page: number,
  pageSize: number,
  filters: Record<string, any>,
  signal?: AbortSignal
): Promise<{ results: VendorRawData[]; hasMore: boolean; total: number }> => {
  // Build query parameters
  const params: Record<string, any> = {
    limit: pageSize,
    offset: (page - 1) * pageSize,
  };

  // Add ordering
  if (filters.ordering) {
    params.ordering = filters.ordering;
  }

  // Add filter parameters if they exist
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "" && key !== "ordering") {
      params[key] = value;
    }
  });

  const response = await apiClient.get("/vendor/details/", { params, signal });
  const results: VendorRawData[] = response.data?.data?.results ?? [];
  const total = response.data?.data?.count ?? 0;

  return {
    results,
    hasMore: Boolean(response.data?.data?.next),
    total,
  };
};

export const fetchDrivingRiskOptions = async (): Promise<string[]> => {
  // Return cached data if available
  if (drivingRiskCache.data) {
    return drivingRiskCache.data;
  }

  // Return existing promise if one is in progress
  if (drivingRiskCache.promise) {
    return drivingRiskCache.promise;
  }

  // Create new promise
  drivingRiskCache.promise = (async () => {
    try {
      const response = await apiClient.get("/vendor/driving-risk/");
      const parsed = response.data;

      if (parsed.success && Array.isArray(parsed.data)) {
        const result = parsed.data.map((item: { driving_risk: string }) => item.driving_risk);
        drivingRiskCache.data = result;
        return result;
      }

      return [];
    } finally {
      drivingRiskCache.promise = null;
    }
  })();

  return drivingRiskCache.promise;
};

export const fetchMaterialDrivingRiskOptions = async (): Promise<string[]> => {
  // Return cached data if available
  if (materialDrivingRiskCache.data) {
    return materialDrivingRiskCache.data;
  }

  // Return existing promise if one is in progress
  if (materialDrivingRiskCache.promise) {
    return materialDrivingRiskCache.promise;
  }

  // Create new promise
  materialDrivingRiskCache.promise = (async () => {
    try {
      const response = await apiClient.get("/material/driving-risk/");
      const parsed = response.data;

      if (parsed.success && Array.isArray(parsed.data)) {
        const result = parsed.data.map((item: { driving_risk: string }) => item.driving_risk);
        materialDrivingRiskCache.data = result;
        return result;
      }

      return [];
    } finally {
      materialDrivingRiskCache.promise = null;
    }
  })();

  return materialDrivingRiskCache.promise;
};
