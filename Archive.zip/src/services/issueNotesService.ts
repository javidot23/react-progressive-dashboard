import apiClient from "@/lib/apiClient";

export interface IssueNoteUserData {
  name?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  role?: string;
  [key: string]: unknown;
}

export interface IssueNote {
  id: string;
  issue_id?: string | number;
  content: string;
  user_id: string;
  user_data?: IssueNoteUserData | null;
  issue_nbr?: string;
  mat_nbr?: string;
  created_at: string;
  updated_at: string;
  is_my_note: boolean;
  parent_id?: string | null;
}

export interface IssueNotesListPayload {
  count: number;
  next: string | null;
  previous: string | null;
  results: IssueNote[];
}

export interface IssueNotesListResponse {
  success?: boolean;
  data: IssueNotesListPayload;
}

export interface IssueNoteEnvelopeResponse {
  success?: boolean;
  data: IssueNote;
}

export interface CreateIssueNoteRequest {
  content: string;
}

export interface UpdateIssueNoteRequest {
  content: string;
}

function normalizeIssueNote(note: IssueNote): IssueNote {
  return {
    ...note,
    id: String(note.id),
    ...(note.issue_id !== undefined && note.issue_id !== null ? { issue_id: note.issue_id } : {}),
  };
}

function unwrapListResponse(raw: unknown): IssueNotesListPayload {
  let payload: IssueNotesListPayload;
  if (raw && typeof raw === "object" && "data" in raw) {
    const envelope = raw as IssueNotesListResponse;
    if (envelope.data && Array.isArray(envelope.data.results)) {
      payload = envelope.data;
    } else {
      throw new Error("Invalid issue notes list response");
    }
  } else if (raw && typeof raw === "object" && "results" in raw) {
    payload = raw as IssueNotesListPayload;
  } else {
    throw new Error("Invalid issue notes list response");
  }
  return {
    ...payload,
    results: payload.results.map(n => normalizeIssueNote(n as IssueNote)),
  };
}

function unwrapNoteResponse(raw: unknown): IssueNote {
  let note: IssueNote;
  if (raw && typeof raw === "object" && "data" in raw) {
    const envelope = raw as IssueNoteEnvelopeResponse;
    if (envelope.data && typeof envelope.data === "object" && "id" in envelope.data) {
      note = envelope.data as IssueNote;
    } else {
      throw new Error("Invalid issue note response");
    }
  } else if (raw && typeof raw === "object" && "id" in raw) {
    note = raw as IssueNote;
  } else {
    throw new Error("Invalid issue note response");
  }
  return normalizeIssueNote(note);
}

export const issueNotesService = {
  async listIssueNotes(issueId: string, limit = 20, offset = 0, signal?: AbortSignal): Promise<IssueNotesListPayload> {
    const params = new URLSearchParams({
      limit: String(limit),
      offset: String(offset),
    });
    const response = await apiClient.get(`/notes/${encodeURIComponent(issueId)}/notes/?${params.toString()}`, {
      signal,
    });
    return unwrapListResponse(response.data);
  },

  async getIssueNote(noteId: string): Promise<IssueNote> {
    const response = await apiClient.get(`/notes/${encodeURIComponent(noteId)}/`);
    return unwrapNoteResponse(response.data);
  },

  async createIssueNote(issueId: string, body: CreateIssueNoteRequest): Promise<IssueNote> {
    const trimmed = body.content.trim();
    if (!trimmed) {
      throw new Error("Content cannot be empty");
    }
    const response = await apiClient.post(`/notes/${encodeURIComponent(issueId)}/notes/`, {
      content: trimmed,
    });
    return unwrapNoteResponse(response.data);
  },

  async updateIssueNote(noteId: string, body: UpdateIssueNoteRequest): Promise<IssueNote> {
    const trimmed = body.content.trim();
    if (!trimmed) {
      throw new Error("Content cannot be empty");
    }
    const response = await apiClient.patch(`/notes/${encodeURIComponent(noteId)}/`, {
      content: trimmed,
    });
    return unwrapNoteResponse(response.data);
  },

  async deleteIssueNote(noteId: string): Promise<void> {
    await apiClient.delete(`/notes/${encodeURIComponent(noteId)}/`);
  },
};

export async function listIssueNotes(
  issueId: string,
  limit = 20,
  offset = 0,
  signal?: AbortSignal
): Promise<IssueNotesListPayload> {
  return issueNotesService.listIssueNotes(issueId, limit, offset, signal);
}

export async function getIssueNote(noteId: string): Promise<IssueNote> {
  return issueNotesService.getIssueNote(noteId);
}

export async function createIssueNote(issueId: string, body: CreateIssueNoteRequest): Promise<IssueNote> {
  return issueNotesService.createIssueNote(issueId, body);
}

export async function updateIssueNote(noteId: string, body: UpdateIssueNoteRequest): Promise<IssueNote> {
  return issueNotesService.updateIssueNote(noteId, body);
}

export async function deleteIssueNote(noteId: string): Promise<void> {
  return issueNotesService.deleteIssueNote(noteId);
}
