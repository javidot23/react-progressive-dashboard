// This service is no longer needed for the read-only profile page.
// Kept as a thin forwarder in case of external imports; can be deleted later.
export {};
