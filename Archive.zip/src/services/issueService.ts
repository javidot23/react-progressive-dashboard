import apiClient from "@/lib/apiClient";
import type { IssueNote } from "@/services/issueNotesService";
import type { IssueAtGranularityApiData, IssueImpactedMaterialApiData } from "@/types/granularityIssue";

export interface IssueApiData {
  id: number;
  issue_id: string;
  issue_nbr: string;
  status: string;
  description: string;
  start_date: string;
  act_required_date: string;
  created_at: string;
  updated_at: string;
  risk_adjusted_value: number;
  actions: any[];
  potential_actions?: any[];
  material: {
    id: number;
    ndc: string;
    name: string;
    mat_nbr: string;
    ean_n4_nbr_11: string;
    risk_rating: number;
    driving_risk: string;
    dollars_at_risk: number;
    xplant_mat_stat?: string;
    vendor: {
      id: number;
      name: string;
      driving_risk: string;
      vendor_nbr?: string;
    };
  };
  last_note: IssueNote | null;
  notes_count: number;
}

export interface FetchIssuesParams {
  page: number;
  pageSize: number;
  filters: Record<string, any>;
  module?: string;
  signal?: AbortSignal;
}

export interface FetchIssuesResult {
  results: IssueApiData[];
  hasMore: boolean;
  total: number;
}

export const fetchIssues = async ({ page, pageSize, filters, module, signal }: FetchIssuesParams): Promise<FetchIssuesResult> => {
  const offset = (page - 1) * pageSize;
  const queryParams = new URLSearchParams();

  queryParams.append("limit", pageSize.toString());
  queryParams.append("offset", offset.toString());
  queryParams.append("ordering", filters.ordering || "-risk_adjusted_value");

  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "" && key !== "ordering") {
      queryParams.append(key, value.toString());
    }
  });

  // Add module filter if provided
  if (module) {
    queryParams.append("module", module);
  }

  const response = await apiClient.get(`/issue/?${queryParams.toString()}`, { signal });
  const data = response.data;

  if (data.success && data.data && Array.isArray(data.data.results)) {
    return {
      results: data.data.results,
      hasMore: data.data.next !== null,
      total: data.data.count || 0,
    };
  }

  throw new Error("API response indicates failure or missing results");
};

export const fetchIssueById = async (id: number, signal?: AbortSignal): Promise<IssueApiData> => {
  const response = await apiClient.get(`/issue/${id}/`, { signal });
  const data = response.data;

  if (data.success && data.data) {
    return data.data;
  }

  throw new Error("API response indicates failure or missing issue data");
};

// ---------------------------------------------------------------------------
// Native-granularity issues (GET /issue/all/)
// ---------------------------------------------------------------------------

export interface FetchGranularityIssuesResult {
  results: IssueAtGranularityApiData[];
  hasMore: boolean;
  total: number;
}

/**
 * Lists issues at their original granularity (material / gcn / ndc / fei / hicl),
 * with grain-aware aggregated ("effective") metrics and the driving event.
 * Mirrors `fetchIssues` but targets `/issue/all/` and defaults ordering to
 * `-effective_risk_adjusted_value`. `granularity_type` and other grain filters
 * are passed through the generic `filters` object.
 */
export const fetchGranularityIssues = async ({
  page,
  pageSize,
  filters,
  module,
  signal,
}: FetchIssuesParams): Promise<FetchGranularityIssuesResult> => {
  const offset = (page - 1) * pageSize;
  const queryParams = new URLSearchParams();

  queryParams.append("limit", pageSize.toString());
  queryParams.append("offset", offset.toString());
  queryParams.append("ordering", filters.ordering || "-effective_risk_adjusted_value");

  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "" && key !== "ordering") {
      queryParams.append(key, value.toString());
    }
  });

  if (module) {
    queryParams.append("module", module);
  }

  const response = await apiClient.get(`/issue/all/?${queryParams.toString()}`, { signal });
  const data = response.data;

  if (data.success && data.data && Array.isArray(data.data.results)) {
    return {
      results: data.data.results,
      hasMore: data.data.next !== null,
      total: data.data.count || 0,
    };
  }

  throw new Error("API response indicates failure or missing results");
};

export interface FetchIssueImpactedMaterialsParams {
  issueId: number;
  page: number;
  pageSize: number;
  /** ordering + range filters (risk_adjusted_value_min/max, risk_rating_min/max, dollars_at_risk_min/max, ordering). */
  filters?: Record<string, unknown>;
  signal?: AbortSignal;
}

export interface FetchIssueImpactedMaterialsResult {
  results: IssueImpactedMaterialApiData[];
  hasMore: boolean;
  total: number;
}

/** Materials impacted by an issue, resolved at the issue's grain (GET /issue/<id>/materials/). */
export const fetchIssueImpactedMaterials = async ({
  issueId,
  page,
  pageSize,
  filters = {},
  signal,
}: FetchIssueImpactedMaterialsParams): Promise<FetchIssueImpactedMaterialsResult> => {
  const offset = (page - 1) * pageSize;
  const params: Record<string, string | number> = {
    limit: pageSize,
    offset,
    ordering: (filters.ordering as string) || "-risk_adjusted_value",
  };
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "" && key !== "ordering") {
      params[key] = value as string | number;
    }
  });

  const response = await apiClient.get(`/issue/${issueId}/materials/`, {
    params,
    signal,
  });
  const data = response.data;

  if (data.success && data.data && Array.isArray(data.data.results)) {
    return {
      results: data.data.results,
      hasMore: data.data.next !== null,
      total: data.data.count || 0,
    };
  }

  throw new Error("API response indicates failure or missing results");
};

/** Fetch every mat_nbr for an issue's materials list (paginated), optionally scoped by filters. */
export const fetchAllIssueImpactedMaterialNbrs = async ({
  issueId,
  filters = {},
  pageSize = 50,
  signal,
}: {
  issueId: number;
  filters?: Record<string, unknown>;
  pageSize?: number;
  signal?: AbortSignal;
}): Promise<string[]> => {
  const matNbrs: string[] = [];
  let page = 1;
  let hasMore = true;

  while (hasMore) {
    const result = await fetchIssueImpactedMaterials({
      issueId,
      page,
      pageSize,
      filters,
      signal,
    });
    for (const row of result.results) {
      if (row.mat_nbr) matNbrs.push(row.mat_nbr);
    }
    hasMore = result.hasMore;
    page += 1;
  }

  return matNbrs;
};

/** One issue at granularity (GET /issue/<id>/), typed as the granularity serializer. */
export const fetchGranularityIssueById = async (id: number, signal?: AbortSignal): Promise<IssueAtGranularityApiData> => {
  const response = await apiClient.get(`/issue/${id}/`, { signal });
  const data = response.data;

  if (data.success && data.data) {
    return data.data;
  }

  throw new Error("API response indicates failure or missing issue data");
};
