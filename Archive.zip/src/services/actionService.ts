/**
 * Action Service
 * Handles API calls related to issue actions
 */

import apiClient from '@/lib/apiClient';

export interface CreateActionRequest {
  issue_nbr: string;
  /** Single material (back-compat). Prefer `mat_nbrs` for granularity issues. */
  mat_nbr?: string;
  /** Materials to act on. Omit to act on ALL materials of the issue's grain; subset acts on only those. */
  mat_nbrs?: string[];
  potential_action_nbr?: string;
  substituted_material_nbr?: string;
  material_risk_rating?: number;
  material_driving_risk?: string;
  material_dollars_at_risk?: number;
  action?: string;
}

export interface CreateActionResponse {
  success: boolean;
  data: {
    id: number;
    issue_number: string;
    user_id: string;
    user: {
      id: string;
      first_name: string;
      last_name: string;
    };
    created_at: string;
    updated_at: string;
    potential_action: any;
    action: string | null;
    substituted_material: any;
    material_number: string;
    material_name: string;
    vendor_name: string;
    /** Present on multi-material creates: the actions created / skipped. */
    created?: any[];
    skipped?: any[];
  };
}


export const createAction = async (actionData: CreateActionRequest): Promise<CreateActionResponse> => {
  try {
    const payload: CreateActionRequest = {
      issue_nbr: actionData.issue_nbr,
      material_risk_rating: actionData.material_risk_rating,
      material_driving_risk: actionData.material_driving_risk,
      material_dollars_at_risk: actionData.material_dollars_at_risk,
    };
    // Prefer the multi-material `mat_nbrs`; fall back to single `mat_nbr` for back-compat.
    // Omitting both signals "all materials of the issue's grain" to the backend.
    if (actionData.mat_nbrs && actionData.mat_nbrs.length > 0) {
      payload.mat_nbrs = actionData.mat_nbrs;
    } else if (actionData.mat_nbr) {
      payload.mat_nbr = actionData.mat_nbr;
    }
    if (actionData.potential_action_nbr) {
      payload.potential_action_nbr = actionData.potential_action_nbr;
    }
    if (actionData.substituted_material_nbr) {
      payload.substituted_material_nbr = actionData.substituted_material_nbr;
    }
    if (actionData.action) {
      payload.action = actionData.action;
    }

    const response = await apiClient.post('/action/create/', payload);
    return response.data;
  } catch (error) {
    console.error('Error creating action:', error);
    throw error;
  }
};
export interface DecisionRationaleRequest {
  time_to_complete: string;
  decision_rationale: string;
}

export interface DecisionRationaleResponse {
  success: boolean;
  data?: any;
}

export const submitDecisionRationale = async (
  actionId: number,
  rationaleData: DecisionRationaleRequest
): Promise<DecisionRationaleResponse> => {
  try {
    const response = await apiClient.patch(
      `/action/${actionId}/decision-feedback/`,
      rationaleData
    );
    return response.data;
  } catch (error) {
    console.error('Error submitting decision rationale:', error);
    throw error;
  }
};

export interface DeleteActionResponse {
  success: boolean;
  data?: {
    /** Present when a logical taken action maps to multiple material-level rows. */
    deleted_count?: number;
    deleted?: unknown[];
  };
}

/** Identifies a logical taken action at issue granularity (Issue ID + Part Number). */
export interface DeleteTakenActionRequest {
  issue_id: number;
  part_number: string;
}

/**
 * Deletes an action by id. Pass `logicalAction` on issue drill-through to remove every
 * material-level row for that taken action (same endpoint, Issue ID + Part Number body).
 */
export const deleteAction = async (
  actionId: number,
  logicalAction?: DeleteTakenActionRequest
): Promise<DeleteActionResponse> => {
  try {
    const response = await apiClient.delete(`/action/${actionId}/`, {
      data: logicalAction,
    });
    return response.data;
  } catch (error) {
    console.error('Error deleting action:', error);
    throw error;
  }
};
