import apiClient from "@/lib/apiClient";

export interface UserSettingsPayload {
  inbound_service_level_target?: number | string | null;
  risk_threshold?: number | string | null;
  products_omit_goal?: number | string | null;
  value_at_risk_target: number | null;
  unfilled_percentage_target: number | null;
  days_on_hand?: number | string | null;
}

export interface UserSettingsResponse {
  inbound_service_level_target?: number | string | null;
  risk_threshold?: number | string | null;
  products_omit_goal?: number | string | null;
  days_on_hand?: number | string | null;
  value_at_risk_target: number | null;
  unfilled_percentage_target: number | null;
}

const basePath = "/user-setting/me/";

export const getMySettings = async (): Promise<UserSettingsResponse> => {
  const res = await apiClient.get(basePath);
  const payload = res?.data?.data ?? res?.data;
  return payload as UserSettingsResponse;
};

export const updateMySettings = async (payload: UserSettingsPayload): Promise<UserSettingsResponse> => {
  const res = await apiClient.put(basePath, payload);
  const responsePayload = res?.data?.data ?? res?.data;
  return responsePayload as UserSettingsResponse;
};

export const patchMySettings = async (payload: Partial<UserSettingsPayload>): Promise<UserSettingsResponse> => {
  const res = await apiClient.patch(basePath, payload);
  const responsePayload = res?.data?.data ?? res?.data;
  return responsePayload as UserSettingsResponse;
};
