import apiClient from "@/lib/apiClient";

/** Mirror of the modules registered in ``api/filter_ranges/range_definitions.py``. */
export type FilterRangeModule =
  | "issue"
  | "all_issues"
  | "issue_impacted_materials"
  | "material"
  | "inventory"
  | "purchase_order"
  | "purchase_history"
  | "purchase_order_failed_scans"
  | "quarantine_sgtin"
  | "vendor_scorecard"
  | "product_family"
  | "corporate_chain"
  | "order_issue"
  | "vendor_plan";

export interface FilterRangeBounds {
  min: number;
  max: number;
}

export type FilterRangesByKey = Record<string, FilterRangeBounds>;

export interface FilterRangesResponse {
  module: FilterRangeModule;
  ranges: FilterRangesByKey;
}

export interface FetchFilterRangesParams {
  module: FilterRangeModule;
  /** Optional subset of keys. ``undefined`` means "all keys for the module". */
  keys?: readonly string[];
  /**
   * Page-level filters (supplier, threshold, days, …). Global ``gf_*``
   * filters are added by the axios interceptor. Booleans are rejected —
   * the backend parses numeric params with ``float``/``int`` and silently
   * falls back on ``"true"``/``"false"``.
   */
  params?: Record<string, string | number | undefined | null>;
}

/**
 * Build the axios ``params`` bag for ``fetchFilterRanges``: ``module`` is
 * always set, ``keys`` is joined when provided, and caller params are
 * stringified with empty/null/undefined/boolean values dropped.
 */
export function buildFilterRangesRequestParams({ module, keys, params }: FetchFilterRangesParams): Record<string, string> {
  const requestParams: Record<string, string> = { module };

  if (keys !== undefined) {
    requestParams.keys = keys.join(",");
  }

  if (params) {
    for (const [key, value] of Object.entries(params)) {
      if (value === undefined || value === null || value === "") continue;
      if (typeof value === "boolean") continue;
      requestParams[key] = String(value);
    }
  }

  return requestParams;
}

/**
 * Fetch the live ``min``/``max`` for every range slider on a page. Params
 * are sent via axios config so the global-filter interceptor can see them.
 */
export async function fetchFilterRanges(args: FetchFilterRangesParams, signal?: AbortSignal): Promise<FilterRangesResponse> {
  const response = await apiClient.get("/filter-ranges/", {
    params: buildFilterRangesRequestParams(args),
    signal,
  });
  const body = response.data;

  // SuccessJsonResponse wrapper.
  if (body && typeof body === "object" && "success" in body && body.success) {
    return body.data as FilterRangesResponse;
  }
  // Unwrapped response (tests, raw backends).
  if (body && typeof body === "object" && "ranges" in body) {
    return body as FilterRangesResponse;
  }

  throw new Error("Filter ranges response missing data");
}
