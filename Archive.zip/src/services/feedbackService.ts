import apiClient from "@/lib/apiClient";

export type FeedbackStatus = "open" | "in_progress" | "resolved" | "closed";

export interface FeedbackUser {
  id: string;
  first_name: string;
  last_name: string;
}

export interface Feedback {
  id: number;
  user: FeedbackUser;
  feedback: string;
  module: string;
  page: string;
  subtab: string;
  status: FeedbackStatus;
  screenshot: string | null;
  created_at: string;
  updated_at: string;
}

export interface FeedbackListResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: Feedback[];
  };
}

export interface FeedbackResponse {
  success: boolean;
  data: Feedback;
}

export interface CreateFeedbackRequest {
  feedback: string;
  module: string;
  page: string;
  subtab: string;
  screenshot: string | null;
}

export interface UpdateFeedbackRequest {
  feedback?: string;
  status?: FeedbackStatus;
  module?: string;
  page?: string;
  subtab?: string;
}

export interface FeedbackFilterParams {
  status?: string;
  module?: string;
  page?: string;
  user?: string;
}

export interface FeedbackFiltersResponse {
  success: boolean;
  data: {
    users: FeedbackUser[];
    statuses: string[];
    modules: string[];
    pages: string[];
  };
}

export const getFeedbackFilters = async (signal?: AbortSignal): Promise<FeedbackFiltersResponse> => {
  const response = await apiClient.get("/user-feedback/filters/", { signal });
  return response.data;
};

export const listFeedback = async (
  page = 1,
  pageSize = 10,
  filters?: FeedbackFilterParams,
  signal?: AbortSignal
): Promise<FeedbackListResponse> => {
  const offset = (page - 1) * pageSize;
  const params = new URLSearchParams({
    limit: pageSize.toString(),
    offset: offset.toString(),
  });
  if (filters) {
    Object.entries(filters).forEach(([key, value]) => {
      if (value) params.append(key, value);
    });
  }
  const response = await apiClient.get(`/user-feedback/?${params.toString()}`, { signal });
  return response.data;
};

export const createFeedback = async (data: CreateFeedbackRequest): Promise<FeedbackResponse> => {
  const response = await apiClient.post("/user-feedback/", data);
  return response.data;
};

export const updateFeedback = async (id: number, data: UpdateFeedbackRequest): Promise<FeedbackResponse> => {
  const response = await apiClient.patch(`/user-feedback/${id}/`, data);
  return response.data;
};

export const deleteFeedback = async (id: number): Promise<void> => {
  await apiClient.delete(`/user-feedback/${id}/`);
};
