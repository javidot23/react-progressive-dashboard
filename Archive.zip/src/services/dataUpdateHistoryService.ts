import apiClient from '@/lib/apiClient';

export interface DataUpdateHistoryItem {
  table_name: string;
  last_updated: string;
}

export interface DataUpdateHistoryResponse {
  success: boolean;
  data: DataUpdateHistoryItem[];
}

const basePath = '/data-update-history/';

export const getDataUpdateHistory = async (): Promise<DataUpdateHistoryItem[]> => {
  const res = await apiClient.get(basePath);
  // Handle both nested and direct response structures (similar to userSettingsService)
  const responseData = res?.data?.data ?? res?.data;
  // The API returns { success: true, data: [...] }, so we need to extract the data array
  if (responseData && typeof responseData === 'object' && 'data' in responseData && Array.isArray(responseData.data)) {
    return responseData.data as DataUpdateHistoryItem[];
  }
  // If responseData is already an array, return it
  if (Array.isArray(responseData)) {
    return responseData as DataUpdateHistoryItem[];
  }
  return [];
};
