/**
 * Build-time lazy imports.
 *
 * Each import is guarded by a __TENANT_CONFIG__ constant that Vite injects at
 * build time. Rollup dead-code-eliminates the false branch, so the chunk is
 * never included in builds where the feature/module is disabled.
 *
 * Keep this file import-free from React components so it can be statically
 * analysed by the bundler without side-effects.
 */
import { lazy } from "react";

const Noop = () => null;

// ─── Always-included pages ────────────────────────────────────────────────────

export const Disclaimer = lazy(() => import("@/pages/Disclaimer"));
export const InfoPage = lazy(() => import("@/pages/InfoPage"));
export const LoginPage = lazy(() => import("@/pages/Login"));
export const NotFoundPage = lazy(() => import("@/pages/NotFoundPage"));
export const OverviewPage = lazy(() => import("@/pages/OverviewPage"));
export const StratiumOverviewPage = lazy(() => import("@/pages/stratium/StratiumOverviewPage"));
export const ManagePage = lazy(() => import("@/pages/manage/ManagePage"));
export const StratiumManagePage = lazy(() => import("@/pages/manage/stratium/StratiumManagePage"));
export const SalesToForecast = lazy(() => import("@/pages/manage/demand/sales-to-forecast/SalesToForecast"));
export const POPerformance = lazy(() => import("@/pages/manage/supply/po-performance/POPerformance"));
export const Scorecard = lazy(() => import("@/pages/manage/supply/scorecard/Scorecard"));
export const ScorecardProductPage = lazy(() => import("@/pages/manage/supply/scorecard/ScorecardProductPage"));
export const ManageOrdersAltServe = lazy(() => import("@/pages/manage/orders/ManageOrdersAltServe"));
export const ManagePagePlaceholder = lazy(() => import("@/components/molecules/ManagePagePlaceholder"));
export const UserProfilePage = lazy(() => import("@/pages/profile/UserProfilePage"));
export const ExportActionsPage = lazy(() => import("@/pages/ExportActionsPage"));
export const ReactPage = lazy(() => import("@/pages/ReactPage"));
export const StratiumReactPage = lazy(() => import("@/pages/stratium/StratiumReactPage"));
export const MaterialDrillThroughPage = lazy(() => import("@/pages/MaterialDrillThroughPage"));
export const IssueDrillThroughPage = lazy(() => import("@/pages/IssueDrillThroughPage"));
export const MaterialDetailPage = lazy(() => import("@/pages/MaterialDetailPage"));
export const Plan = lazy(() => import("@/pages/Plan"));
export const StratiumPlanPage = lazy(() => import("@/pages/stratium/StratiumPlanPage"));
export const PlanProductPage = lazy(() => import("@/pages/PlanProductPage"));

// ─── Glossary (lazy to keep CSV out of critical path) ─────────────────────────

export const Glossary = lazy(() => import("@/components/molecules/Glossary").then(m => ({ default: m.Glossary })));

// ─── Feature-gated ────────────────────────────────────────────────────────────

export const DisruptionsMap = __TENANT_CONFIG__.features.disruptionsMap ? lazy(() => import("@/pages/DisruptionsMap")) : Noop;

export const CustomLists = __TENANT_CONFIG__.features.customLists ? lazy(() => import("@/pages/CustomLists")) : Noop;

export const ProductSubstitutionAnalysis = __TENANT_CONFIG__.features.productSubstitutionAnalysis
  ? lazy(() => import("@/pages/ProductSubstitutionAnalysis"))
  : Noop;

// ─── Vendor-only pages (stratium.vendor) ───────────────────────────────────────────
// These page files must be copied from the dev branch.
// Until then, they render null when the module flag is off anyway.

// ─── Vendor-only: Formulary Change Tracking ───────────────────────────────────

export const FormularyChangeTrackingProduct = __TENANT_CONFIG__.modules.manageFormularyChangeTracking
  ? lazy(() => import("@/pages/manage/formulary-change-tracking/FormularyChangeTrackingProductPage"))
  : Noop;

// ─── Vendor-only: Chargebacks ─────────────────────────────────────────────────

export const ChargebacksDco = __TENANT_CONFIG__.modules.manageChargebacks
  ? lazy(() => import("@/pages/manage/chargebacks/Dco"))
  : Noop;

export const ChargebacksValidation = __TENANT_CONFIG__.modules.manageChargebacks
  ? lazy(() => import("@/pages/manage/chargebacks/Validation"))
  : Noop;

// ─── Vendor-only: Secure Supply Chain ─────────────────────────────────────────

export const SSCQuarantine = __TENANT_CONFIG__.modules.manageSecureSupplyChain
  ? lazy(() => import("@/pages/manage/secure-supply-chain/QuarantineMonitoring"))
  : Noop;

export const SSCSerialization = __TENANT_CONFIG__.modules.manageSecureSupplyChain
  ? lazy(() => import("@/pages/manage/secure-supply-chain/SerializationReadiness"))
  : Noop;

// ─── Vendor-only: Sales sub-pages ─────────────────────────────────────────────

export const ManageCSSalesChangeTracking = __TENANT_CONFIG__.modules.manageCSSalesChangeTracking
  ? lazy(() => import("@/pages/manage/sales/ManageCSSalesChangeTrackingPage"))
  : Noop;

export const ManageForecastComparison = __TENANT_CONFIG__.modules.manageForecastComparison
  ? lazy(() => import("@/pages/manage/sales/ForecastComparisonPage"))
  : Noop;
