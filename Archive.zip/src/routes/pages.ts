/**
 * Lazy page imports.
 *
 * Feature/module availability is enforced at the route level via runtime
 * tenant portal flags (`useTenantContextQuery`), not build-time guards.
 */
import { lazy } from "react";

// ─── Always-included pages ────────────────────────────────────────────────────

export const Disclaimer = lazy(() => import("@/pages/Disclaimer"));
export const InfoPage = lazy(() => import("@/pages/InfoPage"));
export const LoginPage = lazy(() => import("@/pages/Login"));
export const NotFoundPage = lazy(() => import("@/pages/NotFoundPage"));
export const OverviewPage = lazy(() => import("@/pages/OverviewPage"));
export const StratiumOverviewPage = lazy(() => import("@/pages/stratium/StratiumOverviewPage"));
export const ManagePage = lazy(() => import("@/pages/manage/ManagePage"));
export const StratiumManagePage = lazy(() => import("@/pages/manage/stratium/StratiumManagePage"));
export const HighDemandProductsPage = lazy(() => import("@/pages/manage/demand/HighDemandProductsPage"));
export const SalesToForecast = lazy(() => import("@/pages/manage/demand/sales-to-forecast/SalesToForecast"));
export const POPerformance = lazy(() => import("@/pages/manage/supply/po-performance/POPerformance"));
export const ManageOrdersAltServe = lazy(() => import("@/pages/manage/orders/ManageOrdersAltServe"));
export const ManagePagePlaceholder = lazy(() => import("@/components/molecules/ManagePagePlaceholder"));
export const UserProfilePage = lazy(() => import("@/pages/profile/UserProfilePage"));
export const ExportActionsPage = lazy(() => import("@/pages/ExportActionsPage"));
export const ReactPage = lazy(() => import("@/pages/ReactPage"));
export const StratiumReactPage = lazy(() => import("@/pages/stratium/StratiumReactPage"));
export const MaterialDrillThroughPage = lazy(() => import("@/pages/MaterialDrillThroughPage"));
export const IssueDrillThroughPage = lazy(() => import("@/pages/IssueDrillThroughPage"));
export const MaterialDetailPage = lazy(() => import("@/pages/MaterialDetailPage"));
export const Plan = lazy(() => import("@/pages/Plan"));
export const StratiumPlanPage = lazy(() => import("@/pages/stratium/StratiumPlanPage"));
export const PlanProductPage = lazy(() => import("@/pages/PlanProductPage"));

// ─── Glossary (lazy to keep CSV out of critical path) ─────────────────────────

export const Glossary = lazy(() => import("@/components/molecules/Glossary").then(m => ({ default: m.Glossary })));

// ─── Feature / module pages (gated in AppRoutes) ──────────────────────────────

export const DisruptionsMap = lazy(() => import("@/pages/DisruptionsMap"));
export const CustomLists = lazy(() => import("@/pages/CustomLists"));
export const ProductSubstitutionAnalysis = lazy(() => import("@/pages/ProductSubstitutionAnalysis"));

export const FormularyChangeTrackingProduct = lazy(
  () => import("@/pages/manage/formulary-change-tracking/FormularyChangeTrackingProductPage")
);

export const ChargebacksDco = lazy(() => import("@/pages/manage/chargebacks/Dco"));
export const ChargebacksValidation = lazy(() => import("@/pages/manage/chargebacks/Validation"));

export const SSCQuarantine = lazy(() => import("@/pages/manage/secure-supply-chain/QuarantineMonitoring"));
export const SSCSerialization = lazy(() => import("@/pages/manage/secure-supply-chain/SerializationReadiness"));

export const ManageCSSalesChangeTracking = lazy(() => import("@/pages/manage/sales/ManageCSSalesChangeTrackingPage"));
export const ManageForecastComparison = lazy(() => import("@/pages/manage/sales/ForecastComparisonPage"));
