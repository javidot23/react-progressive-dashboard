import { Suspense } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import ProtectedRoute from '@/components/ProtectedRoute';
import { useTenantConfig } from '@/tenant';
import { FeedbackFAB } from '@/components/molecules/FeedbackFAB';
import * as Pages from './pages';

function RootRedirect() {
  const { search } = useLocation();
  return <Navigate to={`/overview${search}`} replace />;
}

function protect(element: React.ReactElement) {
  return <ProtectedRoute>{element}</ProtectedRoute>;
}

export function AppRoutes() {
  const { isFeatureEnabled, isModuleEnabled } = useTenantConfig();

  return (
    <Suspense fallback={null}>
      <Routes>
        {/* ── Universal ─────────────────────────────────────────────────── */}
        <Route path="/" element={<RootRedirect />} />
        <Route path="/login" element={<Pages.LoginPage />} />
        <Route path="/disclaimer" element={<Pages.Disclaimer />} />
        <Route path="/glossary" element={<Pages.Glossary />} />
        <Route path="/info" element={<Pages.InfoPage />} />
        <Route path="/overview" element={protect(<Pages.OverviewPage />)} />
        <Route path="/react" element={protect(<Pages.ReactPage />)} />
        <Route path="/react/product/:issueId" element={protect(<Pages.MaterialDrillThroughPage />)} />
        <Route path="/react/issue/:issueId" element={protect(<Pages.IssueDrillThroughPage />)} />
        <Route path="/react/material/:materialId" element={protect(<Pages.MaterialDetailPage />)} />
        <Route path="/plan" element={protect(<Pages.Plan />)} />
        <Route path="/plan/vendor/:vendorId" element={protect(<Pages.PlanProductPage />)} />
        <Route path="/profile" element={protect(<Pages.UserProfilePage />)} />
        <Route path="/export-actions" element={protect(<Pages.ExportActionsPage />)} />

        {/* ── Feature-gated ─────────────────────────────────────────────── */}
        {isFeatureEnabled('disruptionsMap') && (
          <Route path="/disruptions-map" element={protect(<Pages.DisruptionsMap />)} />
        )}
        {isFeatureEnabled('customLists') && (
          <Route path="/custom-lists" element={protect(<Pages.CustomLists />)} />
        )}
        {isFeatureEnabled('productSubstitutionAnalysis') && (
          <Route
            path="/react/substitution-analysis"
            element={protect(<Pages.ProductSubstitutionAnalysis />)}
          />
        )}

        {/* ── Manage shell (always accessible) ──────────────────────────── */}
        <Route path="/manage" element={protect(<Pages.ManagePage />)}>
          <Route index element={<Navigate to="overview" replace />} />
          <Route path="overview" element={<Pages.ManageOverview />} />

          <Route path="demand">
            <Route index element={<Navigate to="overview" replace />} />
            <Route path="overview" element={<Pages.ManageDemandPage />} />
            <Route path="sales-to-forecast" element={<Pages.SalesToForecast />} />
          </Route>

          <Route path="supply">
            <Route index element={<Navigate to="overview" replace />} />
            <Route path="overview" element={<Pages.ManageSupplyOverview />} />
            <Route path="po-performance" element={<Pages.POPerformance />} />
            <Route path="scorecard" element={<Pages.Scorecard />} />
          </Route>

          {isModuleEnabled('manageOrders') && (
            <Route path="orders">
              <Route index element={<Navigate to="overview" replace />} />
              <Route path="overview" element={<Pages.ManageOrdersPage />} />
              <Route path="alt-serve" element={<Pages.ManageOrdersAltServe />} />
            </Route>
          )}

          <Route path="sales">
            <Route index element={<Navigate to="overview" replace />} />
            <Route path="overview" element={<Pages.ManageSalesPage />} />
            {isModuleEnabled('manageCSSalesChangeTracking') && (
              <Route path="cs-sales-change-tracking" element={<Pages.ManageCSSalesChangeTracking />} />
            )}
            {isModuleEnabled('manageForecastComparison') && (
              <Route path="forecast-comparison" element={<Pages.ManageForecastComparison />} />
            )}
          </Route>

          <Route path="inventory">
            <Route index element={<Navigate to="overview" replace />} />
            <Route path="overview" element={<Pages.ManageInventory />} />
          </Route>

          <Route path="distribution">
            <Route index element={<Navigate to="overview" replace />} />
            <Route path="overview" element={<Pages.ManagePagePlaceholder />} />
          </Route>

          {/* ── Module-gated manage sections ──────────────────────────── */}
          {isModuleEnabled('manageSupplyManagement') && (
            <Route path="supply-management">
              <Route index element={<Pages.SupplyManagement />} />
            </Route>
          )}

          {/* ── Vendor-only sections (stratium.vendor) ─────────────────────── */}
          {isModuleEnabled('manageFTS') && (
            <Route path="fts">
              <Route index element={<Navigate to="mitigation" replace />} />
              <Route path="mitigation" element={<Pages.FTSMitigation />} />
              {/* FTS Validation temporarily disabled — restore with pages.ts lazy import */}
              {/* <Route path="validation" element={<Pages.FTSValidation />} /> */}
            </Route>
          )}

          {isModuleEnabled('manageChargebacks') && (
            <Route path="chargebacks">
              <Route index element={<Navigate to="overview" replace />} />
              <Route path="overview" element={<Pages.ChargebacksOverview />} />
              <Route path="dco" element={<Pages.ChargebacksDco />} />
              <Route path="validation" element={<Pages.ChargebacksValidation />} />
            </Route>
          )}

          {isModuleEnabled('manageFormularyChangeTracking') && (
            <Route path="formulary-change-tracking">
              <Route index element={<Pages.FormularyChangeTracking />} />
              <Route path=":productId" element={<Pages.FormularyChangeTrackingProduct />} />
              <Route path="product/:slug/:cellKey" element={<Pages.FormularyChangeTrackingProduct />} />
            </Route>
          )}

          {isModuleEnabled('manageSecureSupplyChain') && (
            <Route path="secure-supply-chain">
              <Route index element={<Navigate to="inbound-scans" replace />} />
              <Route path="inbound-scans" element={<Pages.SSCInboundScans />} />
              <Route path="quarantine" element={<Pages.SSCQuarantine />} />
              <Route path="serialization" element={<Pages.SSCSerialization />} />
            </Route>
          )}
        </Route>

        {/* Scorecard product detail — outside the ManagePage shell */}
        <Route
          path="/manage/supply/scorecard/:id"
          element={protect(<Pages.ScorecardProductPage />)}
        />

        <Route path="*" element={<Pages.NotFoundPage />} />
      </Routes>

      <FeedbackFAB />
    </Suspense>
  );
}
