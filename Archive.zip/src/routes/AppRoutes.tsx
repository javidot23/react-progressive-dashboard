import { Suspense } from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import ProtectedRoute from "@/components/ProtectedRoute";
import { useTenantConfig } from "@/tenant";
import { FeedbackFAB } from "@/components/molecules/FeedbackFAB";
import { getAvailableManagePrimaryRoutes, managePrimaryRedirects } from "@/pages/manage/stratium/managePrimarySections";
import { getManageNavigationSearch } from "@/pages/manage/stratium/manageNavigationSearch";
import * as Pages from "./pages";

function RootRedirect() {
  const { search } = useLocation();
  return <Navigate to={`/overview${search}`} replace />;
}

function CanonicalManageRedirect({ to }: { to: string }) {
  const { search } = useLocation();
  return <Navigate to={{ pathname: to, search: getManageNavigationSearch(search) }} replace />;
}

function protect(element: React.ReactElement) {
  return <ProtectedRoute>{element}</ProtectedRoute>;
}

export function AppRoutes() {
  const { isFeatureEnabled, isModuleEnabled, tenantId } = useTenantConfig();
  const managePrimaryRoutes = getAvailableManagePrimaryRoutes({ isModuleEnabled, tenantId });

  return (
    <Suspense fallback={null}>
      <Routes>
        {/* ── Universal ─────────────────────────────────────────────────── */}
        <Route path="/" element={<RootRedirect />} />
        <Route path="/login" element={<Pages.LoginPage />} />
        <Route path="/disclaimer" element={<Pages.Disclaimer />} />
        <Route path="/glossary" element={<Pages.Glossary />} />
        <Route path="/info" element={<Pages.InfoPage />} />
        <Route path="/overview" element={protect(<Pages.StratiumOverviewPage />)} />
        <Route path="/react" element={protect(<Pages.StratiumReactPage />)} />
        <Route path="/react/product/:issueId" element={protect(<Pages.MaterialDrillThroughPage />)} />
        <Route path="/react/issue/:issueId" element={protect(<Pages.IssueDrillThroughPage />)} />
        <Route path="/react/material/:materialId" element={protect(<Pages.MaterialDetailPage />)} />
        <Route path="/plan" element={protect(<Pages.StratiumPlanPage />)} />
        <Route path="/plan/vendor/:vendorId" element={protect(<Pages.PlanProductPage />)} />
        <Route path="/profile" element={protect(<Pages.UserProfilePage />)} />
        <Route path="/export-actions" element={protect(<Pages.ExportActionsPage />)} />

        {/* ── Feature-gated ─────────────────────────────────────────────── */}
        {isFeatureEnabled("disruptionsMap") && <Route path="/disruptions-map" element={protect(<Pages.DisruptionsMap />)} />}
        {isFeatureEnabled("customLists") && <Route path="/custom-lists" element={protect(<Pages.CustomLists />)} />}
        {isFeatureEnabled("productSubstitutionAnalysis") && (
          <Route path="/react/substitution-analysis" element={protect(<Pages.ProductSubstitutionAnalysis />)} />
        )}

        {/* ── Manage primary document ───────────────────────────────────── */}
        <Route path="/manage" element={<CanonicalManageRedirect to="/manage/summary" />} />
        {managePrimaryRedirects.map(redirect => (
          <Route key={redirect.from} path={redirect.from} element={<CanonicalManageRedirect to={redirect.to} />} />
        ))}
        {managePrimaryRoutes.map(route => (
          <Route key={route.id} path={route.path} element={protect(<Pages.StratiumManagePage />)} />
        ))}

        {/* Secondary Manage pages keep the current ManagePage/ManageLayout shell. */}
        <Route element={protect(<Pages.ManagePage />)}>
          <Route path="/manage/demand/sales-to-forecast" element={<Pages.SalesToForecast />} />
          <Route path="/manage/supply/po-performance" element={<Pages.POPerformance />} />
          <Route path="/manage/supply/scorecard" element={<Pages.Scorecard />} />
          {isModuleEnabled("manageOrders") && <Route path="/manage/orders/alt-serve" element={<Pages.ManageOrdersAltServe />} />}
          {isModuleEnabled("manageCSSalesChangeTracking") && (
            <Route path="/manage/sales/cs-sales-change-tracking" element={<Pages.ManageCSSalesChangeTracking />} />
          )}
          {isModuleEnabled("manageForecastComparison") && (
            <Route path="/manage/sales/forecast-comparison" element={<Pages.ManageForecastComparison />} />
          )}
          <Route path="/manage/distribution/overview" element={<Pages.ManagePagePlaceholder />} />
          {isModuleEnabled("manageChargebacks") && (
            <>
              <Route path="/manage/chargebacks/dco" element={<Pages.ChargebacksDco />} />
              <Route path="/manage/chargebacks/validation" element={<Pages.ChargebacksValidation />} />
            </>
          )}
          {isModuleEnabled("manageFormularyChangeTracking") && (
            <>
              <Route
                path="/manage/formulary-change-tracking/product/:slug/:cellKey"
                element={<Pages.FormularyChangeTrackingProduct />}
              />
              <Route path="/manage/formulary-change-tracking/:productId" element={<Pages.FormularyChangeTrackingProduct />} />
            </>
          )}
          {isModuleEnabled("manageSecureSupplyChain") && (
            <>
              <Route path="/manage/secure-supply-chain/quarantine" element={<Pages.SSCQuarantine />} />
              <Route path="/manage/secure-supply-chain/serialization" element={<Pages.SSCSerialization />} />
            </>
          )}
        </Route>

        {/* Scorecard product detail — outside the ManagePage shell */}
        <Route path="/manage/supply/scorecard/:id" element={protect(<Pages.ScorecardProductPage />)} />

        <Route path="*" element={<Pages.NotFoundPage />} />
      </Routes>

      <FeedbackFAB />
    </Suspense>
  );
}
