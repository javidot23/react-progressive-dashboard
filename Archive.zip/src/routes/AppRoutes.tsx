import { Suspense } from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import ProtectedRoute from "@/components/ProtectedRoute";
import { FeedbackFAB } from "@/components/molecules/FeedbackFAB";
import { ROUTES } from "@/constants/routes";
import { selectTenantPortalFlags, useTenantContextQuery } from "@/tenant";
import { getAvailableManagePrimaryRoutes, managePrimaryRedirects } from "@/pages/manage/stratium/managePrimarySections";
import { getManageNavigationSearch } from "@/pages/manage/stratium/manageNavigationSearch";
import * as Pages from "./pages";

function RootRedirect() {
  const { search } = useLocation();
  return <Navigate to={`/overview${search}`} replace />;
}

function CanonicalManageRedirect({ to }: { to: string }) {
  const { search } = useLocation();
  return <Navigate to={{ pathname: to, search: getManageNavigationSearch(search) }} replace />;
}

function protect(element: React.ReactElement) {
  return <ProtectedRoute>{element}</ProtectedRoute>;
}

export function AppRoutes() {
  const { data: flags } = useTenantContextQuery(selectTenantPortalFlags);
  const managePrimaryRoutes = getAvailableManagePrimaryRoutes(flags);

  return (
    <Suspense fallback={null}>
      <Routes>
        <Route path="/" element={<RootRedirect />} />
        <Route path="/login" element={<Pages.LoginPage />} />
        <Route path="/disclaimer" element={<Pages.Disclaimer />} />
        <Route path="/glossary" element={<Pages.Glossary />} />
        <Route path="/info" element={<Pages.InfoPage />} />
        <Route path="/overview" element={protect(<Pages.StratiumOverviewPage />)} />
        <Route path="/react" element={protect(<Pages.StratiumReactPage />)} />
        <Route path="/react/product/:issueId" element={protect(<Pages.MaterialDrillThroughPage />)} />
        <Route path="/react/issue/:issueId" element={protect(<Pages.IssueDrillThroughPage />)} />
        <Route path="/react/material/:materialId" element={protect(<Pages.MaterialDetailPage />)} />
        <Route path="/plan" element={protect(<Pages.StratiumPlanPage />)} />
        <Route path="/plan/vendor/:vendorId" element={protect(<Pages.PlanProductPage />)} />
        <Route path="/profile" element={protect(<Pages.UserProfilePage />)} />
        <Route path="/export-actions" element={protect(<Pages.ExportActionsPage />)} />

        {flags && <Route path="/disruptions-map" element={protect(<Pages.DisruptionsMap />)} />}
        {flags?.features.customLists && <Route path="/custom-lists" element={protect(<Pages.CustomLists />)} />}
        {flags?.features.productSubstitutionAnalysis && (
          <Route path={ROUTES.REACT_SUBSTITUTION} element={protect(<Pages.ProductSubstitutionAnalysis />)} />
        )}

        {/* ── Manage primary document ───────────────────────────────────── */}
        <Route path="/manage" element={<CanonicalManageRedirect to="/manage/summary" />} />
        {managePrimaryRedirects.map(redirect => (
          <Route key={redirect.from} path={redirect.from} element={<CanonicalManageRedirect to={redirect.to} />} />
        ))}
        {managePrimaryRoutes.map(route => (
          <Route key={route.id} path={route.path} element={protect(<Pages.StratiumManagePage />)} />
        ))}
        <Route path="/manage/demand/high-demand-products" element={protect(<Pages.HighDemandProductsPage />)} />

        {/* Secondary Manage pages keep the current ManagePage/ManageLayout shell. */}
        <Route element={protect(<Pages.ManagePage />)}>
          <Route path="/manage/demand/sales-to-forecast" element={<Pages.SalesToForecast />} />
          <Route path="/manage/supply/po-performance" element={<Pages.POPerformance />} />
          {flags?.isVendor && <Route path="/manage/orders/alt-serve" element={<Pages.ManageOrdersAltServe />} />}
          {flags?.modules.manageCSSalesChangeTracking && (
            <Route path="/manage/sales/cs-sales-change-tracking" element={<Pages.ManageCSSalesChangeTracking />} />
          )}
          {flags?.modules.manageForecastComparison && (
            <Route path="/manage/sales/forecast-comparison" element={<Pages.ManageForecastComparison />} />
          )}
          <Route path="/manage/distribution/overview" element={<Pages.ManagePagePlaceholder />} />
          {flags?.modules.manageChargebacks && (
            <>
              <Route path="/manage/chargebacks/dco" element={<Pages.ChargebacksDco />} />
              <Route path="/manage/chargebacks/validation" element={<Pages.ChargebacksValidation />} />
            </>
          )}
          {flags?.modules.manageFormularyChangeTracking && (
            <>
              <Route
                path="/manage/formulary-change-tracking/product/:slug/:cellKey"
                element={<Pages.FormularyChangeTrackingProduct />}
              />
              <Route path="/manage/formulary-change-tracking/:productId" element={<Pages.FormularyChangeTrackingProduct />} />
            </>
          )}
          {flags?.modules.manageSecureSupplyChain && (
            <>
              <Route path="/manage/secure-supply-chain/quarantine" element={<Pages.SSCQuarantine />} />
              <Route path="/manage/secure-supply-chain/serialization" element={<Pages.SSCSerialization />} />
            </>
          )}
        </Route>

        {/* Scorecard product detail — outside the ManagePage shell */}
        <Route path="/manage/summary/otif-exceptions" element={protect(<Pages.OtifExceptionsPage />)} />
        <Route path="/manage/summary/sales-history" element={protect(<Pages.SalesHistoryPage />)} />
        <Route
          path="/manage/summary/products-with-unfilled-quantity"
          element={protect(<Pages.ProductsWithUnfilledQuantityPage />)}
        />
        <Route path="/manage/summary/products-outside-threshold" element={protect(<Pages.ProductsOutsideThresholdPage />)} />

        <Route path="*" element={<Pages.NotFoundPage />} />
      </Routes>

      <FeedbackFAB />
    </Suspense>
  );
}
