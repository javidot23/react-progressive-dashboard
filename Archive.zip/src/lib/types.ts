// Keep existing types: StatCardData, CountryRisk, ServiceLevelData, RiskListItem

export type RiskLevel = "Critical" | "High" | "Medium" | "Low" | "Watch";

// KPI Trend Point for mini charts in stat cards
export type KPITrendPoint = {
  period_start: string;
  period_end: string;
  value: number;
  metrics?: Record<string, number>;
};

// KPI Trend data for stat cards
export type KPITrendData = {
  kpi?: string;
  unit?: string;
  points: KPITrendPoint[];
};

export type StatCardData = {
  title: string;
  value: string;
  change?: string;
  changeType?: "increase" | "decrease" | "neutral";
  icon?: React.ComponentType<React.SVGProps<SVGSVGElement>> | React.ReactNode; // React component type for the icon
  iconBgColor?: string; // Tailwind CSS class for background color
  customIconPath?: string; // Path to custom icon file (SVG)
  trend?: KPITrendData; // Optional trend data for mini sparkline chart
  chartData?: number[]; // Array of data points for the trend chart
  chartXLabels?: string[]; // Optional x-axis labels for the chart
  chartColor?: string; // Optional color for the chart line
  chartValueFormatter?: (value: number | null) => string; // Optional formatter for chart values
  sparklineValueFormatter?: (value: number | null) => string; // Optional formatter for mini sparkline tooltip
  tooltip?: string; // Tooltip text for info icon
};

export type CountryRisk = {
  name: string;
  flag: string;
  riskLevel: "high" | "medium" | "low";
  riskValue: number;
};

export type ServiceLevelData = {
  name: string;
  highImpact: number;
  mediumImpact: number;
};

// New type for Inbound Fill Rate Trend
export type InboundServiceLevelData = {
  day: string;
  highImpact: number; // dark purple bars (top section)
  mediumImpact: number; // light purple bars (bottom section)
  serviceLevel: number; // blue line (percentage)
  goal: number; // dashed line (95%)
};

export type ServiceLevelTableRow = {
  date: string;
  performance: string;
  vsTarget: string;
  volume: string;
  keyDriver: string;
};

export type RiskListItem = {
  initials: string;
  name: string;
  description: string;
  risk: RiskLevel;
  riskRating?: number; // Optional risk rating value for color mapping
  ndc?: string; // National Drug Code
  id?: number; // Material/vendor ID for modal
  dollarsAtRisk?: number; // Total/material dollars at risk
  riskAdjustedValue?: number; // Pre-computed risk-adjusted value (from vendor API)
  vendorNbr?: string; // Vendor number for supplier display
  vendorName?: string; // Vendor name (for materials, from API)
  materialGroup?: string;
  matNbr?: string;
  productFamily?: string;
};

// New types for React Page
export type AIInsight = {
  title: string;
  description: string;
  predictedImpact?: string;
};

export type IssueItem = {
  id: string;
  vendor: string;
  productName: string;
  productDetails: string;
  riskLevel: RiskLevel;
  riskExposureValue: string;
  riskExposureBase: string;
  primaryRiskDriver: string;
  actionStatus: "ACTION REQUIRED" | "ACTION REVIEWED" | "UNDER REVIEW" | "RESOLVED";
  aiRecommendation: {
    title: string;
    suggestion: string;
    details?: string[];
    cost?: string;
    buttons: { text: string; variant: "default" | "outline-solid" | "secondary" }[];
  };
  selected?: boolean;
};

export type RiskAlternative = {
  name: string;
  description: string;
  costChange: string; // e.g., "-15% cost", "+8% cost"
  costChangeType: "saving" | "increase";
};

// Update StatCardData to be more flexible for different icons/colors if needed,
// or create a new type if structures diverge significantly. For now, reusing.
// Example: Add optional icon color if it's not just background.
export type ReactStatCardData = StatCardData & {
  iconColor?: string; // e.g. "text-green-500" for the icon itself
};

// Material with Issues API types
export type ActionCategory = "Tactical" | "Strategic" | "Operational";

export interface PotentialAction {
  id: number;
  paction_nbr: string;
  issue_nbr: string;
  action_type: string;
  recommendation: string;
  recommendation_type_nbr: string;
  action_category?: ActionCategory | string | null;
  recommended_action_flag: boolean | null;
  status: string | null;
  module: string;
  created_at: string;
  updated_at: string;
  material: string;
}

export interface SubstitutedMaterial {
  mat_nbr: string;
  name: string;
  vendor_name: string;
  vendor_nbr?: string;
}

export interface MaterialAction {
  id: number;
  issue_nbr: string;
  user_id: string;
  /** Populated from API when available; may be null after partial/error responses. */
  user: {
    id: string;
    first_name: string;
    last_name: string;
  } | null;
  created_at: string;
  updated_at: string;
  potential_action: PotentialAction | null;
  action: string | null;
  substituted_material: SubstitutedMaterial | null;
  material_number: string;
  material_name: string;
  vendor_name: string;
  vendor_nbr?: string;
  /** Populated after decision-feedback PATCH (nested shape from GET/PATCH action payloads). */
  decision_feedback?: {
    time_to_complete?: string;
    decision_rationale?: string | null;
  } | null;
  /** Legacy/flat shape if API ever inlines rationale without nesting. */
  decision_rationale?: string | null;
}

// Dashboard data types
export interface CountryVendor {
  id: number;
  vendor_id: number;
  vendor_nbr: string;
  name: string;
  vendor_name: string;
  country: string;
  city: string;
  latitude: number;
  longitude: number;
  risk_rating: number;
  risk_score: number;
  driving_risk: string;
  created_at: string;
  updated_at: string;
  avg_fill_rate: number;
  issues_count: number;
  materials_at_risk?: number;
  total_materials?: number;
}

export interface CountryIssueData {
  country: string;
  country_name: string;
  issueCount: number;
  riskLevel: string;
  open_issues_count: number;
  vendors: CountryVendor[];
}

export interface PlantLeadTimeData {
  data: {
    results: Array<{
      plant_id: number;
      plant_nbr: string;
      plant_name: string;
      avg_lead_time_days: number;
      material_count: number;
    }>;
  };
}

export interface PlantOrderStatsData {
  data: {
    results: Array<{
      plant?: string;
      plant__name?: string;
      plant__plant_nbr?: string;
      plant_id?: number;
      plant_nbr?: string;
      plant_name?: string;
      total_orders: number;
      substituted_count?: number;
      substitution_count?: number;
      substituted_percent?: number;
      substitution_percentage?: number;
      alt_served_count?: number;
      alt_serve_count?: number;
      alt_served_percent?: number;
      alt_serve_percentage?: number;
      total_materials?: number;
    }>;
  };
}

export interface SalesComparisonData {
  data: Array<{
    month: string;
    last_year_sales: number;
    current_year_sales: number;
  }>;
}

export interface FulfillmentTrendData {
  data: Array<{
    week_start: string;
    unshipped_quantity: number;
    fulfillment_percentage: number;
  }>;
}

export interface WeeklyPerformanceData {
  data: Array<{
    week_start: string;
    week_end?: string;
    demand_qty: number;
    forecast_qty: number;
  }>;
}

export interface FilledOrderedUnitsData {
  data: Array<{
    material_group: string;
    filled_units: number | string;
    ordered_units: number | string;
  }>;
}

export interface MaterialGroupUnitsData {
  data: Array<{
    week_start: string;
    brand_ordered_units?: number;
    generic_ordered_units: number;
    otc_ordered_units?: number;
  }>;
}

export interface ClassOfTradeFilledRateData {
  data: Array<{
    class_of_trade: string;
    fill_rate?: number | string;
    filled_units?: number | string;
    ordered_units?: number | string;
    filled_qty?: number | string;
    ordered_qty?: number | string;
  }>;
}

export interface DemandTrendData {
  data: Array<{
    week_start: string;
    total_orders: number;
    perfect_order_rate?: number;
    alt_served_percentage?: number;
    substituted_percentage?: number;
  }>;
}

export interface MaterialOmitCountsData {
  data: {
    monthly_data: Array<{
      month: string;
      omit_count: number;
      fill_rate: number;
    }>;
  };
}

export interface InventoryBandsData {
  data: {
    /** Latest period band totals (not blended across the 90-day trend). */
    low: number;
    acceptable: number;
    overstock: number;
    no_forecast: number;
    /** Latest-period average days on hand. */
    average_doh?: number;
    weekly: Array<{
      week_start: string;
      low: number;
      acceptable: number;
      overstock: number;
      no_forecast: number;
    }>;
  };
}

export interface MaterialOrderQuantityRow {
  material_id?: string | number | null;
  mat_nbr?: string | number | null;
  material_name?: string | null;
  name?: string | null;
  ordered_qty?: number | string | null;
  total_order_qty?: number | string | null;
  filled_qty?: number | string | null;
  fill_rate?: number | string | null;
  perfect_line_rate?: number | string | null;
  imperfect_lines?: number | string | null;
  unpredictable_demand?: number | string | null;
  demand_variability?: number | string | null;
  total_demand_mtd?: number | string | null;
  material_status?: string | null;
  product_status?: string | null;
  status?: string | null;
  formulary?: string | null;
  formulary_status?: string | null;
  shortage_likelihood?: string | null;
  shortage_status?: string | null;
  shortage_risk?: string | null;
}

export interface CustomerOrderQuantityRow {
  customer_id?: string | number | null;
  customer_name?: string | null;
  cust_nbr?: string | number | null;
  cust_nbr_name?: string | null;
  ordered_qty?: number | string | null;
  total_order_qty?: number | string | null;
  filled_qty?: number | string | null;
  fill_rate?: number | string | null;
  perfect_line_rate?: number | string | null;
  imperfect_lines?: number | string | null;
  unpredictable_demand?: number | string | null;
  demand_variability?: number | string | null;
}

export interface MaterialOrderQuantitiesData {
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: MaterialOrderQuantityRow[];
  };
}

export interface MaterialOrderQuantitiesMtdRow {
  material_number: string;
  material_name: string;
  ndc: string;
  total_demand_mtd_units: number;
  fill_rate_percentage: number;
  material_status: string;
  formulary: string[];
}

export interface MaterialOrderQuantitiesMtdData {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: MaterialOrderQuantitiesMtdRow[];
  };
}

export interface CustomerOrderQuantitiesData {
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: CustomerOrderQuantityRow[];
  };
}

export interface PurchaseOrderDetailData {
  po_number: string;
  as_of_date: string;
  anticipated_date: string;
  received_qty: number;
  original_order_qty: number;
}

export interface MaterialWithContractSalesData {
  results: Array<{
    material_id?: string;
    material_name?: string;
    name?: string;
    mat_nbr?: string;
    total_sales_qty?: number;
    contract_sales?: Array<{
      contract_id: string;
      contract_name?: string;
      sales_amount: number;
    }>;
  }>;
  count?: number;
  next?: string | null;
}

export interface MaterialIssue {
  id: number;
  actions: MaterialAction[];
  potential_actions?: PotentialAction[];
  issue_id: string;
  issue_nbr?: string;
  status: string;
  description: string;
  start_date: string;
  act_required_date: string;
  created_at: string;
  updated_at: string;
  material: number;
}

export interface MaterialDetails {
  id: number;
  name: string;
  ndc?: string;
  material_id?: string;
  risk_score: number;
  primary_risk: string;
  risk_adjusted_value: string;
  action_status: "Reviewed" | "Not Reviewed" | "In Progress";
}

export interface MaterialWithIssues {
  id: number;
  vendor: {
    id: number;
    vendor_nbr: string;
    name: string;
    country: string;
    city: string;
    latitude: number;
    longitude: number;
    risk_rating: number;
    driving_risk: string;
    created_at: string;
    updated_at: string;
  };
  mat_nbr: string;
  name: string;
  /** Material plant status code; e.g. AC, UM (mapped to description in UI) */
  xplant_mat_stat?: string;
  created_at: string;
  updated_at: string;
  risk_rating: number;
  driving_risk: string;
  dollars_at_risk: number;
  omits: number;
  ean_n4_nbr_11: string;
  saleable_qty_on_hand: number;
  qty_ordered: number;
  forecast_qty_7day: number;
  cost_per_unit: number;
  market_share: number;
  open_issues: MaterialIssue[];

  // Computed fields for display
  risk_score?: number;
  primary_risk?: string;
  risk_adjusted_value?: string;
  action_status?: "Reviewed" | "Not Reviewed" | "In Progress";
  ndc?: string;
  material_id?: string;
}

export interface MaterialsWithIssuesResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: MaterialWithIssues[];
  };
}
