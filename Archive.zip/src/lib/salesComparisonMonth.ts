const FULL_MONTH_NAME_TO_NUM: Record<string, number> = {
  january: 1,
  february: 2,
  march: 3,
  april: 4,
  may: 5,
  june: 6,
  july: 7,
  august: 8,
  september: 9,
  october: 10,
  november: 11,
  december: 12,
};

export function resolveSalesComparisonMonthNum(month: string, monthNum?: number | null): number | undefined {
  if (typeof monthNum === "number" && Number.isFinite(monthNum)) {
    const m = Math.trunc(monthNum);
    if (m >= 1 && m <= 12) return m;
  }
  if (month == null || month === "") return undefined;
  const trimmed = String(month).trim();
  const lower = trimmed.toLowerCase();

  const direct = FULL_MONTH_NAME_TO_NUM[lower];
  if (direct != null) return direct;
  for (const [full, num] of Object.entries(FULL_MONTH_NAME_TO_NUM)) {
    if (lower.includes(full)) return num;
  }

  const parts = trimmed.split("-");
  let monthKey: string | undefined;
  if (parts.length > 1) {
    const digits = parts[1].replace(/\D/g, "");
    monthKey = digits.length ? digits.padStart(2, "0").slice(-2) : undefined;
  }
  if (!monthKey) {
    const digits = trimmed.replace(/\D/g, "");
    monthKey = digits.length >= 2 ? digits.slice(-2).padStart(2, "0") : digits.padStart(2, "0");
  }
  const parsedKey = parseInt(monthKey, 10);
  if (!Number.isNaN(parsedKey) && parsedKey >= 1 && parsedKey <= 12) return parsedKey;

  const parsed = Date.parse(trimmed);
  if (!Number.isNaN(parsed)) {
    const m = new Date(parsed).getUTCMonth() + 1;
    if (m >= 1 && m <= 12) return m;
  }

  return undefined;
}

export function isSalesComparisonMonthWithoutCurrentData(
  currentYearSales: number,
  resolvedMonth: number | undefined,
  now: Date = new Date()
): boolean {
  if (currentYearSales !== 0) return false;
  if (resolvedMonth == null || resolvedMonth < 1 || resolvedMonth > 12) return false;
  const calendarMonth = now.getMonth() + 1;
  return resolvedMonth >= calendarMonth;
}

/** True when this point is the ongoing calendar month for the displayed year (current-year sales are month-to-date vs. a full month in the prior year). */
export function isIncompleteCurrentYearMonth(
  displayYear: number,
  resolvedMonth: number | undefined,
  now: Date = new Date()
): boolean {
  if (resolvedMonth == null || resolvedMonth < 1 || resolvedMonth > 12) return false;
  return displayYear === now.getFullYear() && resolvedMonth === now.getMonth() + 1;
}

export function formatSalesComparisonMonthYearLabel(monthNum: number, year: number, locale = "en-US"): string {
  const d = new Date(year, monthNum - 1, 1);
  return d.toLocaleDateString(locale, { month: "long", year: "numeric" });
}

export function isPartialMonthSalesComparison(resolvedMonth: number | undefined, now: Date): boolean {
  if (resolvedMonth == null || resolvedMonth < 1 || resolvedMonth > 12) return false;
  return resolvedMonth === now.getMonth() + 1;
}

export const SALES_COMPARISON_NO_COMPARISON_BAR_VALUE = -18;

export interface SalesComparisonApiRow {
  month: string;
  month_num?: number;
  last_year_sales: number;
  current_year_sales: number;
}

export interface SalesComparisonPctChangeRow {
  month: string;
  sales: number;
  lastYear: number;
  currentYear: number;
  percentageChange: number;
  noComparison: boolean;
  partialMonthComparison: boolean;
}

export function buildSalesComparisonPercentageChangeRows(
  items: ReadonlyArray<SalesComparisonApiRow>,
  formatMonthLabel: (month: string) => string,
  options?: { now?: Date; noComparisonBarValue?: number }
): SalesComparisonPctChangeRow[] {
  const now = options?.now ?? new Date();
  const noComparisonBarValue = options?.noComparisonBarValue ?? SALES_COMPARISON_NO_COMPARISON_BAR_VALUE;

  return items.map(item => {
    const lastYear = item.last_year_sales || 0;
    const currentYear = item.current_year_sales || 0;
    const resolvedMonth = resolveSalesComparisonMonthNum(item.month, item.month_num);
    const partialMonthComparison = isPartialMonthSalesComparison(resolvedMonth, now);
    const incompleteOrFuture = isSalesComparisonMonthWithoutCurrentData(currentYear, resolvedMonth, now);
    const noComparison = (lastYear === 0 && currentYear === 0) || incompleteOrFuture;

    let percentageChange = 0;
    if (!noComparison) {
      if (lastYear > 0) {
        percentageChange = ((currentYear - lastYear) / lastYear) * 100;
      } else if (currentYear > 0) {
        percentageChange = 100;
      }
    }

    const roundedPct = Math.round(percentageChange * 100) / 100;

    return {
      month: formatMonthLabel(item.month),
      sales: noComparison ? noComparisonBarValue : roundedPct,
      lastYear,
      currentYear,
      percentageChange: roundedPct,
      noComparison,
      partialMonthComparison,
    };
  });
}
