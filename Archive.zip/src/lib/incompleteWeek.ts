/** Visual opacity for weekly chart bars (and line dots) when the week is still in progress. */
export const INCOMPLETE_WEEK_BAR_OPACITY = 0.45;

export function startOfLocalDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

/** Format a Date as YYYY-MM-DD in the local calendar (matches API week strings). */
export function formatYmdLocalDate(d: Date): string {
  const y = d.getFullYear();
  const m = d.getMonth() + 1;
  const day = d.getDate();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${y}-${pad(m)}-${pad(day)}`;
}

/** True when today (local) falls within [weekStart, weekEnd] inclusive. */
export function isIncompleteWeek(weekStart: Date, weekEnd: Date, now: Date = new Date()): boolean {
  const today = startOfLocalDay(now);
  const start = startOfLocalDay(weekStart);
  const end = startOfLocalDay(weekEnd);
  return today >= start && today <= end;
}

/**
 * Parse API week-start (YYYY-MM-DD or ISO) as local calendar day; week end is start + 6 days.
 */
export function weekBoundsFromStartDateString(dateStr: string): { weekStart: Date; weekEnd: Date } {
  const part = dateStr.split("T")[0];
  const parts = part.split("-").map(Number);
  const y = parts[0];
  const m = parts[1];
  const d = parts[2];
  if (y == null || m == null || d == null || Number.isNaN(y) || Number.isNaN(m) || Number.isNaN(d)) {
    const fallback = new Date(dateStr);
    const weekStart = startOfLocalDay(fallback);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);
    return { weekStart, weekEnd };
  }
  const weekStart = new Date(y, m - 1, d);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);
  return { weekStart, weekEnd };
}

export function computeIsIncompleteWeekFromApiWeekStart(dateStr: string, now?: Date): boolean {
  const { weekStart, weekEnd } = weekBoundsFromStartDateString(dateStr);
  return isIncompleteWeek(weekStart, weekEnd, now);
}

function parseYmdLocal(dateStr: string): Date {
  const part = dateStr.split("T")[0];
  const parts = part.split("-").map(Number);
  const y = parts[0];
  const m = parts[1];
  const d = parts[2];
  if (y == null || m == null || d == null || Number.isNaN(y) || Number.isNaN(m) || Number.isNaN(d)) {
    return startOfLocalDay(new Date(dateStr));
  }
  return new Date(y, m - 1, d);
}

/** Uses API week_start and week_end so the range matches backend week boundaries. */
export function computeIsIncompleteWeekFromWeekStartEnd(weekStartStr: string, weekEndStr: string, now?: Date): boolean {
  const { weekStart } = weekBoundsFromStartDateString(weekStartStr);
  const weekEnd = parseYmdLocal(weekEndStr);
  return isIncompleteWeek(weekStart, weekEnd, now);
}
