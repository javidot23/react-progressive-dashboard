// URL Query Parameter utilities for Issue Filters
export const serializeIssueFilters = (filters: any, preserveGlobalFilters: boolean = true): URLSearchParams => {
  const params = new URLSearchParams();

  // Preserve existing global filters (gf_*) from current URL if requested
  if (preserveGlobalFilters && typeof window !== "undefined") {
    const currentParams = new URLSearchParams(window.location.search);
    currentParams.forEach((value, key) => {
      if (key.startsWith("gf_")) {
        params.append(key, value);
      }
    });
  }

  // Add local filter params
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "" && !(key === "ordering" && value === "-risk_adjusted_value")) {
      // Special handling for boolean values
      if (key === "has_no_actions") {
        params.set(key, value.toString());
      } else {
        params.set(key, value.toString());
      }
    }
  });

  return params;
};

export const deserializeIssueFilters = (searchParams: URLSearchParams): any => {
  const filters = {
    ordering: "-risk_adjusted_value",
    risk_rating_min: null as number | null,
    risk_rating_max: null as number | null,
    driving_risk: null as string | null,
    dollars_at_risk_min: null as number | null,
    dollars_at_risk_max: null as number | null,
    has_no_actions: undefined as boolean | undefined,
    risk_adjusted_value_min: null as number | null,
    risk_adjusted_value_max: null as number | null,
  };

  // Parse URL parameters
  for (const [key, value] of searchParams.entries()) {
    if (key in filters) {
      if (key === "ordering") {
        (filters as any)[key] = value;
      } else if (key === "driving_risk") {
        // Handle driving_risk as string
        (filters as any)[key] = value;
      } else if (key === "has_no_actions") {
        // Handle has_no_actions as boolean
        (filters as any)[key] = value === "true";
      } else {
        // Convert numeric values
        const numValue = Number(value);
        if (!isNaN(numValue)) {
          (filters as any)[key] = numValue;
        }
      }
    }
  }

  return filters;
};
