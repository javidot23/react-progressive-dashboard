﻿import apiClient from "@/lib/apiClient";
import { AxiosResponse } from "axios";
import type { LogoutResponse } from "@/lib/authUrls";

export type { LogoutResponse } from "@/lib/authUrls";

// Example API service functions
// These demonstrate how to use the configured Axios instance

// Generic API response type
export interface ApiResponse<T = unknown> {
  data: T;
  message?: string;
  success: boolean;
}

// Example: User-related API calls
export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

export const userService = {
  // Get current user profile
  getCurrentUser: (signal?: AbortSignal): Promise<AxiosResponse<ApiResponse<User>>> => {
    return apiClient.get("/auth/me", { signal });
  },

  // Update user profile
  updateProfile: (userData: Partial<User>): Promise<AxiosResponse<ApiResponse<User>>> => {
    return apiClient.put("/users/profile", userData);
  },

  // Get all users
  getUsers: (params?: { page?: number; limit?: number }, signal?: AbortSignal): Promise<AxiosResponse<ApiResponse<User[]>>> => {
    return apiClient.get("/users", { params, signal });
  },
};

/** BFF session logout (use AuthContext.logout in app code). */
export const authService = {
  logout: (): Promise<AxiosResponse<LogoutResponse>> => {
    return apiClient.post("/logout/");
  },
};

// Example: Supply Chain Risk Management API calls
export interface RiskData {
  id: string;
  riskLevel: "low" | "medium" | "high" | "critical";
  description: string;
  impact: number;
  probability: number;
  mitigationPlan?: string;
  createdAt: string;
  updatedAt: string;
}

// Weekly Open Count API Response
export interface WeeklyOpenCountResponse {
  success: boolean;
  data?: {
    current_week_count: number;
    previous_week_count: number;
    week_start_date: string;
    previous_week_start_date: string;
    current_week_requires_action_count: number;
  };
  error?: string;
  message?: string;
}

// KPI Query Parameters
export interface KPIQueryParams {
  start_date?: string;
  end_date?: string;
  aggregation?: "day" | "week" | "month";
  material?: string;
}

// KPI Trend Point structure
export interface KPITrendPoint {
  period_start: string;
  period_end: string;
  value: number;
  metrics?: Record<string, number>;
}

// KPI Trend data structure
export interface KPITrendData {
  kpi?: string;
  unit?: string;
  points: KPITrendPoint[];
}

// Today Snapshot API Response (Open Issues KPI)
export interface TodaySnapshotResponse {
  success: boolean;
  data?: {
    open_issues: number;
    total_issues: number;
    snapshot_date: string;
    kpi_value?: number;
    kpi_total?: number;
    trend?: KPITrendData;
  };
  error?: string;
  message?: string;
}

// OTIF API Response
export interface OtifResponse {
  success: boolean;
  data?: Array<{
    this_week_otif?: number;
    last_week_otif?: number;
    last_30_days_otif?: number;
    previous_30_days_otif?: number;
    kpi_value?: number;
    kpi_previous_value?: number;
    trend?: KPITrendData;
  }>;
  error?: string;
  message?: string;
}

// Weekly Risk Analysis API Response
export interface WeeklyRiskAnalysisResponse {
  success: boolean;
  data?: {
    aggregate_risk_score: number;
    total_dollars_at_risk: number;
    products_count: number;
    period: {
      week_start: string;
      week_end: string;
      analysis_date: string;
    };
  };
  error?: string;
  message?: string;
}

// Material Risk Weekly Averages API Response
export interface MaterialRiskWeeklyAveragesResponse {
  success: boolean;
  data: {
    average_risk_score_this_week: number;
    average_risk_score_last_week: number;
    average_dollars_at_risk_this_week: number;
    average_dollars_at_risk_last_week: number;
    risk_score_this_week?: number;
    risk_score_last_week?: number;
    risk_score_out_of?: number;
    period: {
      this_week_start: string;
      this_week_end: string;
      last_week_start: string;
      last_week_end: string;
    };
    kpi_value?: number;
    kpi_previous_value?: number;
    trend?: KPITrendData;
  };
  error?: string;
  message?: string;
}

// Service Level Analysis API Response
export interface ServiceLevelAnalysisResponse {
  success: boolean;
  data: {
    this_week_average: number;
    last_week_average: number;
  };
}

// Supply Chain Events API Response
export interface SupplyChainEvent {
  id: number;
  event_id: string;
  type: string;
  type_description: string;
  status: string;
  start_date: string;
  end_date: string | null;
  latitude: number | null;
  longitude: number | null;
  city: string | null;
  state: string | null;
  country: string | null;
  created_at: string;
  updated_at: string;
  material?: number;
  mat_nbr?: MaterialNumber;
  metadata?: string;
  scrm_mat_grp?: string;
}

export interface SupplyChainEventsResponse {
  success: boolean;
  data:
    | {
        events: SupplyChainEvent[];
      }
    | SupplyChainEvent[];
}

// Supply Chain Events with Location API Response
export interface SupplyChainEventWithLocation {
  id: number;
  event_id: string;
  type: string;
  type_description: string;
  status: string;
  start_date: string;
  end_date: string | null;
  latitude: number;
  longitude: number;
  mat_nbr: {
    id: number;
    vendor: string;
    mat_nbr: string;
    name: string;
    risk_rating: number;
    driving_risk: string;
    dollars_at_risk: number;
    ndc: string;
    [key: string]: any;
  };
  metadata: string;
  created_at: string;
  updated_at: string;
}

export interface SupplyChainEventsWithLocationResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: SupplyChainEventWithLocation[];
  };
}

// Supply Chain Events - Detailed Event Response (with mat_nbr and related_events)
export interface MaterialNumber {
  id: number;
  vendor: string;
  vendor_nbr?: string;
  mat_nbr: string;
  name: string;
  created_at: string;
  updated_at: string;
  risk_rating: number;
  driving_risk: string;
  dollars_at_risk: number;
  ndc: string;
  saleable_qty_on_hand: number;
  unrestricted_qty_on_hand: number;
  forecast_qty_7day: number;
  cost_per_unit: number;
  market_share: number;
  material_group: string;
  cat_mgr_name: string;
  cat_mgr_nbr: string;
  buyer_name: string;
  buyer_cd: string;
  product_family: string;
  otif_percentage: number;
  delivery_deviation: number;
  outbound_fill_rate: number;
  fdb_gcn_seq_nbr: string;
  hic3_therapy_class: string;
  dollars_at_risk_this_week: number;
  dollars_at_risk_prev_week: number;
  xplant_mat_stat: string;
  scrm_mat_grp: string;
}

export interface DetailedSupplyChainEvent {
  id: number;
  event_id: string;
  type: string;
  type_description: string;
  status: string;
  start_date: string;
  end_date: string | null;
  latitude: number | null;
  longitude: number | null;
  city: string | null;
  state: string | null;
  country: string | null;
  mat_nbr: MaterialNumber;
  metadata: string;
  created_at: string;
  updated_at: string;
  related_events?: DetailedSupplyChainEvent[];
}

export interface DetailedSupplyChainEventResponse {
  success: boolean;
  data: DetailedSupplyChainEvent;
  error?: string;
  message?: string;
}

// Top Riskiest Vendors API Response
export interface RiskiestVendor {
  id: number;
  vendor_nbr: string;
  name: string;
  country: string;
  city: string;
  latitude: number;
  longitude: number;
  risk_rating: number;
  driving_risk: string;
  vendor_group?: string;
  created_at: string;
  updated_at: string;
}

export interface TopRiskiestVendorsResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: RiskiestVendor[];
  };
}

// Critical Products API Response
export interface CriticalProduct {
  id: number;
  mat_nbr: string;
  name: string;
  created_at: string;
  updated_at: string;
  risk_rating: number;
  driving_risk: string;
  dollars_at_risk: number;
  omits: number;
  ean_n4_nbr_11: string;
  saleable_qty_on_hand: number;
  qty_ordered: number;
  forecast_qty_7day: number;
  cost_per_unit: number;
  market_share: number;
  vendor: number;
  material_group?: string;
}

export interface CriticalProductsResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: CriticalProduct[];
  };
}

// Top Riskiest Materials API Response (from issue/top-riskiest-materials endpoint)
export interface TopRiskiestMaterial {
  id: number;
  vendor: string;
  mat_nbr: string;
  name: string;
  created_at: string;
  updated_at: string;
  risk_rating: number;
  driving_risk: string;
  dollars_at_risk: number;
  ndc: string;
  saleable_qty_on_hand: number;
  unrestricted_qty_on_hand: number;
  forecast_qty_7day: number;
  cost_per_unit: number;
  market_share: number;
  material_group: string;
  cat_mgr_name: string;
  cat_mgr_nbr: string;
  buyer_name: string;
  buyer_cd: string;
  product_family: string;
  otif_percentage: number;
  delivery_deviation: number;
  outbound_fill_rate: number;
  fdb_gcn_seq_nbr: string;
  hic3_therapy_class: string;
  dollars_at_risk_this_week: number;
  dollars_at_risk_prev_week: number;
}

export interface TopRiskiestMaterialsResponse {
  success: boolean;
  data: {
    materials: TopRiskiestMaterial[];
  };
}

// Service Level Trend API Response
export interface ServiceLevelTrendData {
  date: string;
  data_type: "actual" | "projected";
  fill_rate_pct: number;
  actual_fill_rate_pct: number;
  total_received_qty: number;
  predicted_additional_qty: number;
  total_order_qty: number;
  vendor?: string | null;
}

export interface ServiceLevelTrendResponse {
  success: boolean;
  data: ServiceLevelTrendData[];
}

export const riskService = {
  // Get all risks
  getRisks: (
    params?: {
      page?: number;
      limit?: number;
      riskLevel?: string;
      sortBy?: string;
      sortOrder?: "asc" | "desc";
    },
    signal?: AbortSignal
  ): Promise<AxiosResponse<ApiResponse<RiskData[]>>> => {
    return apiClient.get("/risks", { params, signal });
  },

  // Get risk by ID
  getRiskById: (id: string, signal?: AbortSignal): Promise<AxiosResponse<ApiResponse<RiskData>>> => {
    return apiClient.get(`/risks/${id}`, { signal });
  },

  // Create new risk
  createRisk: (riskData: Omit<RiskData, "id" | "createdAt" | "updatedAt">): Promise<AxiosResponse<ApiResponse<RiskData>>> => {
    return apiClient.post("/risks", riskData);
  },

  // Update risk
  updateRisk: (id: string, riskData: Partial<RiskData>): Promise<AxiosResponse<ApiResponse<RiskData>>> => {
    return apiClient.put(`/risks/${id}`, riskData);
  },

  // Delete risk
  deleteRisk: (id: string): Promise<AxiosResponse<ApiResponse<null>>> => {
    return apiClient.delete(`/risks/${id}`);
  },
};

// Example: Dashboard/Analytics API calls
export interface DashboardStats {
  totalRisks: number;
  criticalRisks: number;
  mitigatedRisks: number;
  pendingRisks: number;
  riskTrend: Array<{
    date: string;
    count: number;
    level: string;
  }>;
}

export const dashboardService = {
  // Get dashboard statistics
  getStats: (
    dateRange?: { from: string; to: string },
    signal?: AbortSignal
  ): Promise<AxiosResponse<ApiResponse<DashboardStats>>> => {
    return apiClient.get("/dashboard/stats", { params: dateRange, signal });
  },

  // Get risk trends
  getRiskTrends: (
    period: "7d" | "30d" | "90d" | "1y",
    signal?: AbortSignal
  ): Promise<AxiosResponse<ApiResponse<Array<{ date: string; count: number; level: string }>>>> => {
    return apiClient.get(`/dashboard/trends/${period}`, { signal });
  },
};

// Generic API functions for common operations
export const apiService = {
  // Generic GET request
  get: <T = unknown>(url: string, params?: Record<string, unknown>): Promise<AxiosResponse<ApiResponse<T>>> => {
    return apiClient.get(url, { params });
  },

  // Generic POST request
  post: <T = unknown>(url: string, data?: Record<string, unknown>): Promise<AxiosResponse<ApiResponse<T>>> => {
    return apiClient.post(url, data);
  },

  // Generic PUT request
  put: <T = unknown>(url: string, data?: Record<string, unknown>): Promise<AxiosResponse<ApiResponse<T>>> => {
    return apiClient.put(url, data);
  },

  // Generic PATCH request
  patch: <T = unknown>(url: string, data?: Record<string, unknown>): Promise<AxiosResponse<ApiResponse<T>>> => {
    return apiClient.patch(url, data);
  },

  // Generic DELETE request
  delete: <T = unknown>(url: string): Promise<AxiosResponse<ApiResponse<T>>> => {
    return apiClient.delete(url);
  },
};

// Add to existing services
export const issuesService = {
  // Get weekly open count
  getWeeklyOpenCount: (signal?: AbortSignal): Promise<AxiosResponse<WeeklyOpenCountResponse>> => {
    return apiClient.get("/issue/weekly-open-count/", { signal });
  },

  getOtifToday: (): Promise<AxiosResponse<OtifResponse>> => {
    return apiClient.get("/service-level/otif-week-summary/");
  },

  getOtif30DaySummary: (params?: KPIQueryParams, signal?: AbortSignal): Promise<AxiosResponse<OtifResponse>> => {
    return apiClient.get("/service-level/otif-30day-summary/", { params, signal });
  },

  getTodaySnapshot: (params?: KPIQueryParams, signal?: AbortSignal): Promise<AxiosResponse<TodaySnapshotResponse>> => {
    return apiClient.get("/issue/today-snapshot/", { params, signal });
  },

  // Get OTIF trends for OTIF Performance Over Time chart
  getOtifTrends: (): Promise<
    AxiosResponse<
      ApiResponse<
        Array<{
          day: string;
          on_time_count: number;
          in_full_count: number;
          otif_percentage: number;
          total_materials: number;
        }>
      >
    >
  > => {
    return apiClient.get("/service-level/otif-trends/");
  },

  // Get weekly OTIF trends for OTIF Performance Over Time chart
  getWeeklyOtifTrends: (signal?: AbortSignal): Promise<AxiosResponse<ApiResponse<WeeklyOtifTrendData[]>>> => {
    return apiClient.get("/purchase-order/weekly-otif-trends/", { signal });
  },

  // Get OTIF trends for specific material
  getMaterialOtifTrends: (
    materialId: number,
    signal?: AbortSignal
  ): Promise<AxiosResponse<ApiResponse<MaterialOtifTrendData[]>>> => {
    return apiClient.get(`/purchase-order/otif-trends/${materialId}/`, { signal });
  },

  // Get weekly OTIF line counts for OTIF Performance Over Time chart
  getWeeklyOtifLineCounts: (
    signal?: AbortSignal
  ): Promise<
    AxiosResponse<
      ApiResponse<
        Array<{
          year: number;
          week: number;
          otif_count: number;
          ot_but_not_if_count: number;
          if_but_not_ot_count: number;
          not_ot_or_if_count: number;
          total_lines: number;
          otif_percentage: number;
        }>
      >
    >
  > => {
    return apiClient.get("/purchase-order/weekly-otif-line-counts/", { signal });
  },

  // Get top riskiest materials
  getTopRiskiestMaterials: (limit: number = 3): Promise<AxiosResponse<TopRiskiestMaterialsResponse>> => {
    return apiClient.get(`/issue/top-riskiest-materials/?limit=${limit}`);
  },

  // Add other issue-related endpoints as needed
  getIssuesList: (params?: {
    page?: number;
    limit?: number;
    status?: string;
    risk_level?: string;
  }): Promise<
    AxiosResponse<
      ApiResponse<
        Array<{
          id: string;
          status: string;
          risk_level: string;
          description: string;
          created_at: string;
          updated_at: string;
        }>
      >
    >
  > => {
    return apiClient.get("/issues/", { params });
  },

  getIssueById: (
    id: string
  ): Promise<
    AxiosResponse<
      ApiResponse<{
        id: string;
        status: string;
        risk_level: string;
        description: string;
        created_at: string;
        updated_at: string;
      }>
    >
  > => {
    return apiClient.get(`/issues/${id}/`);
  },

  updateIssueStatus: (
    id: string,
    status: string
  ): Promise<
    AxiosResponse<
      ApiResponse<{
        id: string;
        status: string;
      }>
    >
  > => {
    return apiClient.patch(`/issues/${id}/`, { status });
  },

  getValueAtRiskTrend: (params?: KPIQueryParams): Promise<AxiosResponse<ApiResponse<any>>> => {
    return apiClient.get("/issue/value-at-risk-trend/", { params });
  },
};

// Weekly OTIF Trend API types
export interface WeeklyOtifTrendData {
  year: number;
  week: number;
  on_time_count: number;
  in_full_count: number;
  otif_count: number;
  total_orders: number;
}

// Material OTIF Trend API types
export interface MaterialOtifTrendData {
  day: string;
  on_time_count: number;
  in_full_count: number;
  otif_count: number;
  total_materials: number;
  material_status: string | null;
}

// Service Level API types
export interface Plant {
  id: number;
  plant_nbr: string;
  name: string;
  city: string;
  state: string;
  postal_code: string;
  longitude: number;
  latitude: number;
  default_lead_time: number;
  coverage_zip_codes: string[];
  created_at: string;
  updated_at: string;
}

export interface ServiceLevel {
  date: string;
  fill_rate: number;
  total_order_qty: number;
  total_received_qty: number;
}

export interface ServiceLevelPlantData {
  plant: Plant;
  service_levels: ServiceLevel[];
}

export interface ServiceLevelResponse {
  success: boolean;
  data: ServiceLevelPlantData[];
}

export interface PlantFromGraphProperties {
  iso_3166_1_alpha_3_country_code?: string;
  plant_category?: string;
  street_house_nbr?: string;
  coverage_zip_codes: string;
  city: string;
  latitude: number;
  sap_vendor_number?: string;
  state_or_province: string;
  plant: string;
  plant_name: string;
  sap_customer_number?: string;
  longitude: number;
  postal_code: string;
}

export interface PlantFromGraph {
  node_id: number;
  labels: string[];
  id: number | null;
  name: string | null;
  city: string;
  state: string | null;
  postal_code: string;
  longitude: number;
  latitude: number;
  properties: PlantFromGraphProperties;
}

export interface ServiceLevelFromGraph {
  date: string;
  fill_rate: number;
  total_order_qty: number;
  total_received_qty: number;
  in_full_units: number;
  on_time_units: number;
  on_order_qty: number;
  otif_percentage: number;
  total_omit_qty: number;
}

export interface ServiceLevelPlantDataFromGraph {
  plant: PlantFromGraph;
  service_levels: ServiceLevelFromGraph[];
}

export interface ServiceLevelFromGraphResponse {
  success: boolean;
  data: ServiceLevelPlantDataFromGraph[];
}

// Service Level API service
export const serviceLevelService = {
  // Get service level plants data
  getServiceLevelPlants: (
    params?: { start_date?: string; end_date?: string },
    signal?: AbortSignal
  ): Promise<AxiosResponse<ServiceLevelResponse>> => {
    return apiClient.get("/service-level/plants/", { params, signal });
  },
  // Get service level plants data from graph
  getServiceLevelPlantsFromGraph: (
    params?: { start_date?: string; end_date?: string },
    signal?: AbortSignal
  ): Promise<AxiosResponse<ServiceLevelFromGraphResponse>> => {
    return apiClient.get("/service-level/plants/from-graph/", { params, signal });
  },
};

// Risk Analysis Service
export const riskAnalysisService = {
  // Get weekly risk analysis
  getWeeklyRiskAnalysis: (): Promise<AxiosResponse<WeeklyRiskAnalysisResponse>> => {
    return apiClient.get("/material/weekly-risk-analysis/");
  },
  // Get material risk weekly averages
  getMaterialRiskWeeklyAverages: (
    params?: KPIQueryParams,
    signal?: AbortSignal
  ): Promise<AxiosResponse<MaterialRiskWeeklyAveragesResponse>> => {
    return apiClient.get("/material-risk/weekly-averages/", { params, signal });
  },
};

// Service Level Analysis Service
export const serviceLevelAnalysisService = {
  // Get weekly service level analysis
  getWeeklyServiceLevelAnalysis: (signal?: AbortSignal): Promise<AxiosResponse<ServiceLevelAnalysisResponse>> => {
    return apiClient.get("/service-level/weekly-analysis/", { signal });
  },
};

// Supply Chain Events Service
export const supplyChainEventsService = {
  // Get latest supply chain events
  getLatestEvents: (limit: number = 10, signal?: AbortSignal): Promise<AxiosResponse<SupplyChainEventsResponse>> => {
    return apiClient.get(`/supply-chain-event/latest-events/?limit=${limit}`, { signal });
  },

  // Get events for top-riskiest materials (used by OverviewPage insights)
  getTopRiskiestMaterialsEvents: (signal?: AbortSignal): Promise<AxiosResponse<SupplyChainEventsResponse>> => {
    return apiClient.get("/supply-chain-events/top-riskiest-materials-events/", { signal });
  },

  // Get a single event with full detail
  getSupplyChainEvent: (
    eventId: number | string,
    signal?: AbortSignal
  ): Promise<AxiosResponse<DetailedSupplyChainEventResponse>> => {
    return apiClient.get(`/supply-chain-events/${eventId}/`, { signal });
  },

  // Get supply chain events with location
  getEventsWithLocation: (
    params?: {
      limit?: number;
      offset?: number;
      status?: string;
      has_location?: boolean;
    },
    signal?: AbortSignal
  ): Promise<AxiosResponse<SupplyChainEventsWithLocationResponse>> => {
    const queryParams = new URLSearchParams();
    if (params?.limit) queryParams.append("limit", params.limit.toString());
    if (params?.offset) queryParams.append("offset", params.offset.toString());
    if (params?.status) queryParams.append("status", params.status);
    if (params?.has_location) queryParams.append("has_location", params.has_location.toString());
    return apiClient.get(`/supply-chain-events/?${queryParams.toString()}`, { signal });
  },

  getMaterialSupplyChainEvents: (
    matNbr: string,
    params?: {
      limit?: number;
      offset?: number;
      status?: string;
    },
    signal?: AbortSignal
  ): Promise<AxiosResponse<MaterialSupplyChainEventsResponse>> => {
    const queryParams = new URLSearchParams();
    if (params?.limit != null) queryParams.append("limit", params.limit.toString());
    if (params?.offset != null) queryParams.append("offset", params.offset.toString());
    if (params?.status) queryParams.append("status", params.status);
    const query = queryParams.toString();
    const suffix = query ? `?${query}` : "";
    return apiClient.get(`/supply-chain-events/material/${encodeURIComponent(matNbr)}/${suffix}`, {
      signal,
    });
  },

  getIssueDrivingEvent: (issueId: number, signal?: AbortSignal): Promise<AxiosResponse<DetailedSupplyChainEventResponse>> => {
    return apiClient.get(`/supply-chain-events/issue/${issueId}/`, { signal });
  },
};

export interface MaterialSupplyChainEventsResponse {
  success: boolean;
  data: PaginatedResults<SupplyChainEvent>;
  message?: string;
  error?: string;
}

// Vendor Detail API Response
export interface VendorDetail {
  id: number;
  vendor_nbr: string;
  name: string;
  country: string;
  city: string;
  latitude: number;
  longitude: number;
  risk_rating: number;
  driving_risk: string;
  vendor_group?: string;
  created_at: string;
  updated_at: string;
  service_levels_90_days?: Array<{
    material__vendor_id?: string;
    date: string;
    avg_fill_rate: number;
    total_order_qty?: number;
    total_received_qty?: number;
  }>;
  materials_at_risk: number;
  total_materials: number;
  sales_volume?: number | null;
  sales_amount?: number | null;
  risk_adjusted_value?: number | null;
  total_dollars_at_risk?: number | null;
  // Scorecard fields (present when fetched from scorecard endpoint)
  inbound_fill_rate?: number;
  outbound_fill_rate?: number;
  product_damages_rate?: number;
  otif_percentage?: number;
  overall_score?: number;
  asn_timeliness?: number;
  asn_essential?: number;
  cat_mgr_list?: string[];
  buyer_list?: string[];
  high_risk_materials_count?: number;
  medium_risk_materials_count?: number;
  issues_last_24h_count?: number;
  issues_with_actions_last_24h_count?: number;
}

export interface VendorDetailResponse {
  success: boolean;
  data: VendorDetail;
  message?: string;
}

// Top Riskiest Vendors Service
export const vendorsService = {
  // Get top riskiest vendors
  getTopRiskiestVendors: (limit: number = 38, offset: number = 0): Promise<AxiosResponse<TopRiskiestVendorsResponse>> => {
    return apiClient.get(`/vendor/?limit=${limit}&offset=${offset}&ordering=-risk_rating`);
  },

  // Get vendor details by ID
  getVendorById: (id: number): Promise<AxiosResponse<VendorDetailResponse>> => {
    return apiClient.get(`/vendor/${id}/`);
  },

  // Get vendor details with service levels by ID
  getVendorByIdWithServiceLevels: (
    id: number,
    signal?: AbortSignal
  ): Promise<
    AxiosResponse<
      VendorDetailResponse & {
        service_levels?: Array<{
          date: string;
          avg_fill_rate: number;
        }>;
      }
    >
  > => {
    return apiClient.get(`/vendor/${id}/with-service-levels/`, { signal });
  },

  // Get vendor details from vendor list
  getVendorDetails: (
    limit: number = 10,
    offset: number = 0,
    ordering?: string,
    signal?: AbortSignal
  ): Promise<
    AxiosResponse<{
      success: boolean;
      data: {
        count: number;
        next: string | null;
        previous: string | null;
        results: VendorDetail[];
      };
      message?: string;
    }>
  > => {
    const params: Record<string, string> = {
      limit: limit.toString(),
      offset: offset.toString(),
    };
    if (ordering) {
      params.ordering = ordering;
    }
    const queryString = new URLSearchParams(params).toString();
    return apiClient.get(`/vendor/details/?${queryString}`, { signal });
  },
};

// Service Level Trend Service
export const serviceLevelTrendService = {
  // Get service level trend data
  getServiceLevelTrend: (
    startDate: string,
    endDate: string,
    signal?: AbortSignal
  ): Promise<AxiosResponse<ServiceLevelTrendResponse>> => {
    return apiClient.get(`/service-level/predicted-fill-rate/?start_date=${startDate}&end_date=${endDate}`, { signal });
  },
};

// Material Substitutes API Response - from-graph endpoint (flat result items)
export interface MaterialSubstituteFromGraphItem {
  mat_nbr: string;
  sub_mat_nbr: string;
  name: string | null;
  dollars_at_risk: number | null;
  market_share: number | null;
  forecast_qty_7day: number | null;
  saleable_qty_on_hand: number | null;
  cost_per_unit: number | null;
  vendor_nbr: string | null;
  vendor_name: string | null;
  substitute_material_rank: number;
  material_formularies: { mat_nbr: string; parent_program: string }[];
  available_plants_count: number;
}

export interface MaterialSubstitutesFromGraphResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: MaterialSubstituteFromGraphItem[];
  };
}

export interface MaterialFormularyEntry {
  id?: number;
  name?: string | null;
  mat_nbr?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  parent_program?: string | null;
  sales_group?: string | null;
  program?: string | null;
  program_description?: string | null;
  contract_number?: string | null;
  material?: string | null;
}

export interface MaterialPlantRef {
  plant_nbr: string;
  name: string;
}

export interface NextPoDelivery {
  predicted_delv_date?: string | null;
  anticipated_date?: string | null;
  plant?: MaterialPlantRef | null;
}

export interface MaterialVendorDetail {
  id: number;
  vendor_nbr: string;
  name: string;
  vendor_parent_name?: string | null;
  city?: string | null;
  state?: string | null;
  country?: string | null;
  vendor_group?: string | null;
  dea_number?: string | null;
  is_active?: boolean | null;
  risk_rating?: number | null;
  buyer_name?: string | null;
  buyer_list?: string[] | null;
  cat_mgr_list?: string[] | null;
  overall_score?: number | null;
  otif_percentage?: number | null;
  inbound_fill_rate?: number | null;
  outbound_fill_rate?: number | null;
  asn_timeliness?: number | null;
  asn_essential?: number | null;
  product_damages_rate?: number | null;
}

export interface MaterialSubstitutionDetailsResponse {
  success: boolean;
  data: {
    material: {
      id: number;
      mat_nbr: string;
      name: string;
      risk_rating: number;
      driving_risk: string;
      dollars_at_risk: number;
      saleable_qty_on_hand: number;
      unrestricted_qty_on_hand?: number;
      forecast_qty_7day: number;
      cost_per_unit: number;
      market_share: number | null;
      buyer_comment_notes?: string | null;
      omits?: number;
      ndc?: string;
      product_family?: string;
      category?: string;
      manufacturer?: string;
      manufacturer_name?: string;
      api?: string | null;
      form_cd?: string | null;
      route_cd_interpretation?: string | null;
      unit_strength_qty?: string | number | null;
      unit_strength_type_cd?: string | null;
      scrm_mat_grp?: string | null;
      material_group?: string | null;
      xplant_mat_stat?: string | null;
      hic3_therapy_class?: string | null;
      days_on_hand?: number | string | null;
      mnftr_avail_note_desc?: string | null;
      dollars_at_risk_this_week?: number | null;
      dollars_at_risk_prev_week?: number | null;
      inj_flg?: string | boolean | null;
      who_essential_flg?: string | boolean | null;
      dqsa_exempt_flg?: string | boolean | null;
      fee_for_service_flg?: number | boolean | string | null;
      avg_shortage_duration?: number | null;
      material_formularies?: MaterialFormularyEntry[] | null;
      next_po_delivery?: NextPoDelivery | null;
      vendor?: MaterialVendorDetail | number;
    };
    material_formularies: MaterialFormularyEntry[];
    available_plants_count: number;
    next_po_delivery?: NextPoDelivery | null;
  };
}

// Material Substitutes Service
export const materialSubstitutesService = {
  // Get material substitutes by material ID (from-graph endpoint)
  getMaterialSubstitutes: (
    materialId: number,
    limit: number = 10,
    offset: number = 0,
    additionalParams?: string
  ): Promise<AxiosResponse<MaterialSubstitutesFromGraphResponse>> => {
    let url = `/material-substitute/${materialId}/from-graph/?limit=${limit}&offset=${offset}`;
    if (additionalParams) {
      url += `&${additionalParams}`;
    }
    return apiClient.get(url);
  },

  // Get original material details for substitution analysis
  getMaterialSubstituteDetails: (
    materialId: number,
    signal?: AbortSignal
  ): Promise<AxiosResponse<MaterialSubstitutionDetailsResponse>> => {
    return apiClient.get(`/material-substitute/${materialId}/details/`, { signal });
  },

  // Get material substitutes by material ID (legacy REST endpoint â€” used for variant portal)
  getMaterialSubstitutesLegacy: (materialId: number, limit: number = 10, offset: number = 0): Promise<AxiosResponse<any>> => {
    return apiClient.get(`/material-substitute/${materialId}/`, { params: { limit, offset } });
  },
};

// Import the new types
import type { MaterialsWithIssuesResponse } from "./types";

// Materials with Issues Service
export const materialsWithIssuesService = {
  // Get materials with issues by vendor ID
  getMaterialsWithIssues: (
    vendorId: number,
    limit: number = 10,
    offset: number = 0
  ): Promise<AxiosResponse<MaterialsWithIssuesResponse>> => {
    const url = `/vendor/${vendorId}/materials-with-issues/?limit=${limit}&offset=${offset}`;
    return apiClient.get(url);
  },
};

// Material Risk API Response
export interface MaterialRiskData {
  id: number;
  risk_type: string;
  risk_rating: number;
  time_horizon: number;
  created_at: string;
  updated_at: string;
  material: number;
  status_date?: string;
  dollars_at_risk?: number | null;
}

export interface MaterialRiskResponse {
  success: boolean;
  data: MaterialRiskData[];
  message?: string;
  error?: string;
}

// Material Risk Service
export const materialRiskService = {
  // Get material risk data by material ID
  getMaterialRisk: (materialId: number, signal?: AbortSignal): Promise<AxiosResponse<MaterialRiskResponse>> => {
    return apiClient.get(`/material-risk/${materialId}/`, { signal });
  },
};

// Material Summary API Response
export interface MaterialSummaryItem {
  material_id: string;
  material_name: string;
  mat_nbr: string;
  material_description: string;
  units_ordered: number;
  units_received_on_time: number;
  units_received_late: number;
  units_not_received: number;
  inbound_fill_rate: number;
  total_orders: number;
}

export interface MaterialSummaryResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: MaterialSummaryItem[];
  };
}

// Material Summary Service
export const materialSummaryService = {
  // Get material summary data
  getMaterialSummary: (
    limit: number = 10,
    offset: number = 0,
    ordering: string = "-units_ordered",
    filters: Record<string, any> = {},
    options?: { signal?: AbortSignal }
  ): Promise<AxiosResponse<MaterialSummaryResponse>> => {
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append("limit", limit.toString());
    queryParams.append("offset", offset.toString());
    queryParams.append("ordering", ordering);

    // Add filter parameters
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== "" && key !== "ordering") {
        queryParams.append(key, value.toString());
      }
    });

    return apiClient.get(`/service-level/material-summary/?${queryParams.toString()}`, {
      signal: options?.signal,
    });
  },
};

// Vendor Aggregate Stats API Response
export interface VendorAggregateStats {
  overall_risk_score: number;
  average_inbound_fill_rate: number;
  average_otif_percentage: number;
  average_score: number;
  total_vendors: number;
}

export interface VendorAggregateStatsResponse {
  success: boolean;
  data: VendorAggregateStats;
  error?: string;
  message?: string;
}

// Vendor Aggregate Stats Service
export const vendorAggregateStatsService = {
  // Get vendor aggregate statistics
  getVendorAggregateStats: (): Promise<AxiosResponse<VendorAggregateStatsResponse>> => {
    return apiClient.get("/vendor/aggregate-stats/");
  },
};

// Vendor List API Response
export interface VendorListItem {
  id: number;
  vendor_nbr: string;
  name: string;
  country: string;
  city: string;
  latitude: number;
  longitude: number;
  risk_rating: number;
  driving_risk: string;
  inbound_fill_rate: number;
  product_damages_rate: number;
  otif_percentage: number;
  overall_score: number;
  asn_timeliness: number;
  asn_essential: number;
  asn_technical_integration: number;
  asn_desired: number;
  created_at: string;
  updated_at: string;
}

export interface VendorListResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: VendorListItem[];
  };
  error?: string;
  message?: string;
}

// Vendor List Filters
export interface VendorListFilters {
  // Pagination & Sorting
  limit?: number;
  offset?: number;
  ordering?: string;

  // Text Filters
  name?: string;
  vendor_nbr?: string;
  driving_risk?: string;

  // Risk & Performance Filters
  risk_rating_min?: number;
  risk_rating_max?: number;
  inbound_fill_rate_min?: number;
  inbound_fill_rate_max?: number;
  otif_percentage_min?: number;
  otif_percentage_max?: number;
  overall_score_min?: number;
  overall_score_max?: number;
  asn_timeliness_min?: number;
  asn_timeliness_max?: number;
  asn_essential_min?: number;
  asn_essential_max?: number;

  // Product Damages Filter
  product_damages_rate_min?: number;
  product_damages_rate_max?: number;
}

// Vendor List Service
export const vendorListService = {
  // Get vendor list with filters
  getVendorList: (filters: VendorListFilters = {}): Promise<AxiosResponse<VendorListResponse>> => {
    // Build query parameters
    const queryParams = new URLSearchParams();

    // Add all filter parameters
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== "") {
        queryParams.append(key, value.toString());
      }
    });

    const url = `/vendor/?${queryParams.toString()}`;
    return apiClient.get(url);
  },
};

// Vendor Scorecard API Response
export interface VendorScorecardData {
  id: number;
  sales_amount: number;
  total_omits: number;
  total_materials: number | null;
  gcns_supplied: number;
  product_families: number;
  number_of_pos: number;
  vendor_nbr: string;
  name: string;
  country: string;
  city: string;
  latitude: number;
  longitude: number;
  risk_rating: number;
  driving_risk: string;
  inbound_fill_rate: number;
  outbound_fill_rate: number;
  product_damages_rate: number;
  otif_percentage: number;
  overall_score: number;
  asn_timeliness: number;
  asn_essential: number;
  asn_technical_integration?: number;
  asn_desired?: number;
  in_full_rate?: number;
  on_time_percentage?: number;
  avg_days_late?: number;
  vendor_group: string;
  cat_mgr_list: string[];
  buyer_list: string[];
  created_at: string;
  updated_at: string;
}

export interface VendorScorecardResponse {
  success: boolean;
  data: VendorScorecardData;
  error?: string;
  message?: string;
}

// Vendor Weekly Metrics API Response
export interface WeeklyMetric {
  year: number;
  week: number;
  week_start: string;
  inbound_fill_rate: number;
  otif_percentage: number;
  outbound_fill_rate: number;
  total_order_qty: number;
  total_raw_service_qty: number;
}

export interface VendorWeeklyMetricsResponse {
  success: boolean;
  data: {
    vendor: {
      id: number;
      vendor_nbr: string;
      name: string;
    };
    metrics: WeeklyMetric[];
  };
  error?: string;
  message?: string;
}

// Vendor Scorecard Service
export const vendorScorecardService = {
  // Get vendor scorecard by Supplier Number
  getVendorScorecard: (vendorNbr: string): Promise<AxiosResponse<VendorScorecardResponse>> => {
    const url = `/vendor/${vendorNbr}/scorecard/`;
    return apiClient.get(url);
  },

  // Get vendor weekly metrics by Supplier Number
  getVendorWeeklyMetrics: (vendorNbr: string): Promise<AxiosResponse<VendorWeeklyMetricsResponse>> => {
    const url = `/vendor/${vendorNbr}/scorecard/weekly-metrics/`;
    return apiClient.get(url);
  },
};

// Purchase Order History API Response
export interface PurchaseOrderHistoryItem {
  id: number;
  material: {
    id: number;
    mat_nbr: string;
    name: string;
    created_at: string;
    updated_at: string;
    risk_rating: number;
    driving_risk: string;
    dollars_at_risk: number;
    omits: number;
    ean_n4_nbr_11: string;
    saleable_qty_on_hand: number;
    unrestricted_qty_on_hand: number;
    qty_ordered: number;
    forecast_qty_7day: number;
    cost_per_unit: number;
    market_share: number;
    vendor: number;
  };
  plant: {
    id: number;
    plant_nbr: string;
    name: string;
    city: string;
    state: string;
    postal_code: string;
    longitude: number;
    latitude: number;
    default_lead_time: number;
    coverage_zip_codes: string[];
    created_at: string;
    updated_at: string;
  };
  po_create_date: string;
  po_grace_due_date: string;
  po_number: string;
  po_line_number: string | null;
  units_ordered: number;
  total_units_received: number;
  ordered_date: string;
  anticipated_date: string;
  original_order_qty: number;
  received_qty: number;
  units_received_on_time: number | null;
  units_received_late: number | null;
  units_not_received: number;
  created_at: string;
  updated_at: string;
}

export interface PurchaseOrderHistoryResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: PurchaseOrderHistoryItem[];
  };
}

// Orders Received Relative to Due Date API Response
export interface OrdersReceivedRelativeToDueDateItem {
  id: number;
  material: {
    id: number;
    mat_nbr: string;
    name: string;
    created_at: string;
    updated_at: string;
    risk_rating: number;
    driving_risk: string;
    dollars_at_risk: number;
    omits: number;
    ean_n4_nbr_11: string;
    saleable_qty_on_hand: number;
    unrestricted_qty_on_hand: number;
    qty_ordered: number;
    forecast_qty_7day: number;
    cost_per_unit: number;
    market_share: number;
    vendor: number;
  };
  plant: {
    id: number;
    plant_nbr: string;
    name: string;
    city: string;
    state: string;
    postal_code: string;
    longitude: number;
    latitude: number;
    default_lead_time: number;
    coverage_zip_codes: string[];
    created_at: string;
    updated_at: string;
  };
  po_number: string;
  original_order_qty: number;
  received_qty: number;
  buffered_late_flag: boolean;
  buffered_otif_flag: boolean;
  buffered_ot_flag: boolean;
  expected_delivery_days: number;
  ordered_date: string;
  as_of_date: string;
  if_flag: boolean;
  damaged_flag: boolean;
  anticipated_date: string;
  created_at: string;
  updated_at: string;
}

export interface OrdersReceivedRelativeToDueDateResponse {
  success: boolean;
  data: OrdersReceivedRelativeToDueDateItem[];
}

export interface MaterialPOSnapshotItem {
  id: number;
  po_number: string;
  po_line_number: string | null;
  as_of_date: string;
  anticipated_date: string;
  received_qty: number;
  original_order_qty: number;
}

export interface MaterialPOSnapshotsResponse {
  success: boolean;
  data: MaterialPOSnapshotItem[];
}

export const purchaseOrderHistoryService = {
  // Get purchase order history by material ID
  getPurchaseOrderHistory: (
    materialId: number,
    limit: number = 10,
    offset: number = 0,
    ordering: string = "ordered_date",
    filters: Record<string, any> = {},
    options?: { signal?: AbortSignal }
  ): Promise<AxiosResponse<PurchaseOrderHistoryResponse>> => {
    const queryParams = new URLSearchParams();
    queryParams.append("limit", limit.toString());
    queryParams.append("offset", offset.toString());
    queryParams.append("material_id", materialId.toString());
    queryParams.append("ordering", ordering);

    Object.entries(filters).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== "" && key !== "ordering") {
        queryParams.append(key, value.toString());
      }
    });

    return apiClient.get(`/purchase-order/?${queryParams.toString()}`, {
      signal: options?.signal,
    });
  },

  getMaterialPOSnapshots: (materialId: string | number): Promise<AxiosResponse<MaterialPOSnapshotsResponse>> => {
    return apiClient.get(`/purchase-order/material/${materialId}/snapshots/`);
  },
};

// Product Family Scorecard API Response
export interface ProductFamilyScorecardItem {
  product_family: string;
  po_quantity: number;
  average_otif: number;
  average_delivery_deviation: number;
  average_outbound_fill_rate: number;
}

export interface ProductFamilyScorecardResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: ProductFamilyScorecardItem[];
  };
  message?: string;
  error?: string;
}

// Product Family Scorecard Filters
export interface ProductFamilyScorecardFilters {
  // Sorting
  ordering?: string;

  // Search Filters
  product_family?: string;

  // Numeric Filters
  po_quantity_min?: number;
  po_quantity_max?: number;
  average_otif_min?: number;
  average_otif_max?: number;
  average_delivery_deviation_min?: number;
  average_delivery_deviation_max?: number;
  average_outbound_fill_rate_min?: number;
  average_outbound_fill_rate_max?: number;
}

// Product Family API Response
export interface ProductFamilyItem {
  id: number;
  product_family: string;
}

export interface ProductFamilyResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: ProductFamilyItem[];
  };
  message?: string;
  error?: string;
}

// Product Family Service
export const productFamilyService = {
  // Get product family list for dropdowns (from material/product-family/ endpoint)
  getProductFamilies: (
    search?: string,
    limit: number = 10,
    offset: number = 0,
    vendor_id?: number
  ): Promise<AxiosResponse<ProductFamilyResponse>> => {
    const queryParams = new URLSearchParams();
    queryParams.append("limit", limit.toString());
    queryParams.append("offset", offset.toString());

    if (search) {
      queryParams.append("product_family", search);
    }

    if (vendor_id !== undefined && vendor_id !== null) {
      queryParams.append("vendor_id", vendor_id.toString());
    }

    const queryString = queryParams.toString();
    return apiClient.get(`/material/product-family/?${queryString}`);
  },
};

// Product Family Scorecard Service
export const productFamilyScorecardService = {
  // Get product family scorecard data
  getProductFamilyScorecard: (
    limit: number = 10,
    offset: number = 0,
    ordering: string = "po_quantity",
    filters: ProductFamilyScorecardFilters = {},
    vendor_id?: number
  ): Promise<AxiosResponse<ProductFamilyScorecardResponse>> => {
    const queryParams = new URLSearchParams();
    queryParams.append("limit", limit.toString());
    queryParams.append("offset", offset.toString());
    queryParams.append("ordering", ordering);

    if (vendor_id !== undefined && vendor_id !== null) {
      queryParams.append("vendor_id", vendor_id.toString());
    }

    Object.entries(filters).forEach(([key, value]) => {
      if (key !== "ordering" && value !== null && value !== undefined && value !== "") {
        queryParams.append(key, value.toString());
      }
    });

    return apiClient.get(`/material/product-family/scorecard/?${queryParams.toString()}`);
  },
};

// Materials Low Inventory API Response
export interface MaterialsLowInventoryResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: {
      material_id: number;
      mat_nbr: string;
      ndc?: string;
      material_description: string;
      material_status?: string | null;
      dc_count: number;
      outbound_fill_rate: number;
      doh_days?: number | string | null;
      doo_days?: number | string | null;
      plants_no_stock?: number;
      plants_stockout?: number;
      plants_in_range?: number;
      plants_overstock?: number;
    }[];
  };
}

// Materials Low Inventory Filters
export interface MaterialsLowInventoryFilters {
  limit?: number;
  offset?: number | null;
  material?: string;
  dc_min?: number;
  dc_max?: number;
  doh_days_min?: number;
  doh_days_max?: number;
  doo_days_min?: number;
  doo_days_max?: number;
  outbound_fill_rate_min?: number;
  outbound_fill_rate_max?: number;
  range_low?: number;
  range_high?: number;
  ordering?: string;
}

export const materialsLowInventoryService = {
  getMaterialsLowInventory: (
    params?: MaterialsLowInventoryFilters,
    signal?: AbortSignal
  ): Promise<AxiosResponse<MaterialsLowInventoryResponse>> => {
    return apiClient.get("/demand-forecast/materials-low-inventory/", { params, signal });
  },
};

// DC Inventory API Response (using materials/{mat_nbr}/plants endpoint)
export interface DCInventoryResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: {
      plant_id: number;
      plant_nbr: string;
      plant_name: string;
      saleable_qty_on_hand_latest: number;
      unrestricted_qty_on_hand_latest: number;
      qty_ordered_sum: number | null;
      shipped_qty_sum: number;
      received_qty_sum: number;
      on_order_qty_sum: number;
      transfer_in_qty_sum: number;
      transfer_out_qty_sum: number;
      outbound_fill_rate: number | null;
      forecast_28day: number;
      doh_days: number | string | null;
    }[];
  };
}

// DC Inventory Filters
export interface DCInventoryFilters {
  limit?: number;
  offset?: number | null;
  /**
   * Django-style ordering for `/demand-forecast/materials/{mat_nbr}/plants/`.
   * UI exposes: plant__plant_nbr, outbound_fill_rate, saleable_qty_on_hand_latest,
   * on_order_qty_sum (prefix with `-` for descending).
   * Other serializer fields may still be orderable server-side but are not offered in the UI.
   */
  ordering?: string;
}

export const dcInventoryService = {
  getDCInventory: (
    matNbr: string,
    params?: DCInventoryFilters,
    signal?: AbortSignal
  ): Promise<AxiosResponse<DCInventoryResponse>> => {
    return apiClient.get(`/demand-forecast/materials/${matNbr}/plants/`, { params, signal });
  },
};

export interface MaterialPlantCustomerRow {
  cust_nbr: string;
  customer_name: string | null;
  cust_corp_chain_nbr: string | null;
  cust_corp_chain_name: string | null;
  order_qty: number;
  shipped_qty: number;
  omit_qty: number;
  imperfect_lines: number;
  sales_amount: string | null;
  outbound_fill_rate: number | null;
}

export interface MaterialPlantCustomersResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: MaterialPlantCustomerRow[];
  };
}

export interface MaterialPlantCustomersFilters {
  limit?: number;
  offset?: number | null;
  ordering?: string;
  from_date?: string;
  to_date?: string;
}

export const materialPlantCustomersService = {
  getCustomers: (
    matNbr: string,
    plantNbr: string,
    params?: MaterialPlantCustomersFilters,
    signal?: AbortSignal
  ): Promise<AxiosResponse<MaterialPlantCustomersResponse>> => {
    return apiClient.get(
      `/order-transaction/materials/${matNbr}/plants/${plantNbr}/customers/`,
      { params, signal }
    );
  },
};

// Weekly Supply API Response
export interface WeeklySupplyResponse {
  success: boolean;
  data: {
    week_start: string;
    on_hand_qty: number;
    on_order_qty: number;
    forecast_7day_week: number;
    doh_days: number;
    doo_days: number;
  }[];
}

export interface WeeklySupplyFilters {
  ordering?: string;
  material?: string;
}

export const weeklySupplyService = {
  getWeeklySupply: (params?: WeeklySupplyFilters, signal?: AbortSignal): Promise<AxiosResponse<WeeklySupplyResponse>> => {
    return apiClient.get("/demand-forecast/weekly-supply/", { params, signal });
  },
};

interface WeeklyInboundOutboundData {
  week_start: string;
  inbound_qty: number;
  outbound_qty: number;
  inbound_fill_rate: number;
  outbound_fill_rate: number;
}

interface WeeklyTransfersData {
  week_start: string;
  transfer_in_qty: number;
  transfer_out_qty: number;
}

export const weeklyInboundOutboundService = {
  getWeeklyInboundOutboundPerformance: (): Promise<AxiosResponse<ApiResponse<WeeklyInboundOutboundData[]>>> => {
    return apiClient.get("/demand-forecast/weekly-inbound-outbound-performance/");
  },
};

export const weeklyTransfersService = {
  getWeeklyTransfers: (): Promise<AxiosResponse<ApiResponse<WeeklyTransfersData[]>>> => {
    return apiClient.get("/demand-forecast/weekly-transfers/", { params: { ordering: "week_start" } });
  },
};


// Customer Corp Chain Service
export interface CustomerCorpChainFilters {
  limit?: number;
  offset?: number;
  ordering?: string;
  name?: string;
  cust_corp_chain_nbr?: string;
}

export interface CustomerCorpChain {
  id: number;
  cust_corp_chain_nbr: string;
  name: string;
  sales_org: string | null;
  created_at: string;
  updated_at: string;
}

export interface CustomerCorpChainResponse {
  success: boolean;
  data?: {
    count: number;
    next: string | null;
    previous: string | null;
    results: CustomerCorpChain[];
  };
}

export const customerCorpChainService = {
  getCustomers: (params?: CustomerCorpChainFilters): Promise<AxiosResponse<CustomerCorpChainResponse>> => {
    return apiClient.get("/customer-corp-chain/", { params });
  },
};

// User Action Log API Response
export interface UserAction {
  id: number;
  issue_nbr: string;
  user_id: string;
  user: {
    id: string;
    first_name: string;
    last_name: string;
  } | null;
  created_at: string;
  updated_at: string;
  potential_action: {
    id: number;
    paction_nbr: string;
    issue_nbr: string;
    action_type: string;
    recommendation: string;
    recommendation_type_nbr: string;
    action_category?: string | null;
    recommended_action_flag: any;
    status: any;
    module: string;
    created_at: string;
    updated_at: string;
    material: string;
  } | null;
  action: string | null;
  substituted_material: {
    mat_nbr: string;
    name: string;
    vendor_name: string;
    vendor_nbr?: string;
  } | null;
  material_number: string;
  material_name: string;
  vendor_name: string;
  vendor_nbr?: string;
  material_context?: Record<string, unknown>;
  decision_feedback?: Record<string, unknown>;
  user_info?: Record<string, unknown>;
  issue?: {
    id: number;
    issue_nbr: string;
    status: string;
    start_date?: string;
    created_at: string;
    updated_at: string;
    material_number?: string;
    material_name?: string;
  } | null;
  action_type?: string;
  recommendation?: string;
  module?: string;
  status?: string | null;
}

export interface UserActionsResponse {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: UserAction[];
  };
}

// User Action Log Service
export const userActionService = {
  // Get user actions for today
  getUserActions: (
    limit: number = 10,
    offset: number = 0,
    createdAtDate?: string,
    createdAtAfter?: string,
    createdAtBefore?: string,
    signal?: AbortSignal
  ): Promise<AxiosResponse<UserActionsResponse>> => {
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append("limit", limit.toString());
    queryParams.append("offset", offset.toString());

    if (createdAtDate) {
      queryParams.append("created_at_date", createdAtDate);
    }

    if (createdAtAfter) {
      queryParams.append("created_at_after", createdAtAfter);
    }

    if (createdAtBefore) {
      queryParams.append("created_at_before", createdAtBefore);
    }

    return apiClient.get(`/action/?${queryParams.toString()}`, { signal });
  },

  getMaterialActions: (
    materialNbr: string,
    params?: {
      limit?: number;
      offset?: number;
      created_at_after?: string;
    },
    signal?: AbortSignal
  ): Promise<AxiosResponse<UserActionsResponse>> => {
    const queryParams = new URLSearchParams();
    if (params?.limit != null) queryParams.append("limit", params.limit.toString());
    if (params?.offset != null) queryParams.append("offset", params.offset.toString());
    if (params?.created_at_after) queryParams.append("created_at_after", params.created_at_after);
    const query = queryParams.toString();
    const suffix = query ? `?${query}` : "";
    return apiClient.get(`/action/material/${encodeURIComponent(materialNbr)}/${suffix}`, { signal });
  },

  // Export user actions as CSV
  exportUserActions: (createdAtAfter: string, createdAtBefore: string): Promise<AxiosResponse<Blob>> => {
    return apiClient.get(`/action/export/?created_at_after=${createdAtAfter}&created_at_before=${createdAtBefore}`, {
      responseType: "blob",
    });
  },
};

// Purchase Order Line Performance and Service Level API Response
export interface LinePerformanceAndServiceLevelData {
  on_time_percentage: number;
  in_full_percentage: number;
  units_on_order: number;
  inbound_fill_rate: number;
}

export interface LinePerformanceAndServiceLevelResponse {
  success: boolean;
  data: LinePerformanceAndServiceLevelData;
  error?: string;
  message?: string;
}

// Purchase Order Line Performance and Service Level Service
export const linePerformanceAndServiceLevelService = {
  // Get line performance and service level KPIs
  getLinePerformanceAndServiceLevel: (): Promise<AxiosResponse<LinePerformanceAndServiceLevelResponse>> => {
    return apiClient.get("/purchase-order/line-performance-and-service-level/");
  },
};

// Demand Planning and Outbound Unfilled Rate API Response
export interface DemandPlanningAndOutboundUnfilledRateData {
  demand_planning_rate: number;
  outbound_unfilled_rate: number;
}

export interface DemandPlanningAndOutboundUnfilledRateResponse {
  success: boolean;
  data: DemandPlanningAndOutboundUnfilledRateData;
  error?: string;
  message?: string;
}

// Demand Planning and Outbound Unfilled Rate Service
export const demandPlanningAndOutboundUnfilledRateService = {
  // Get demand planning and outbound unfilled rate KPIs
  getDemandPlanningAndOutboundUnfilledRate: (): Promise<AxiosResponse<DemandPlanningAndOutboundUnfilledRateResponse>> => {
    console.log("API Request: Fetching demand planning and outbound unfilled rate KPIs");
    return apiClient.get("/demand-forecast/demand-planning-and-outbound-unfilled-rate/");
  },
};

export interface AltServeOverallStatsResponse {
  success: boolean;
  data: any;
  error?: string;
  message?: string;
}

export interface OrderTransactionKPIsResponse {
  success: boolean;
  data: any;
  error?: string;
  message?: string;
}

export const orderTransactionService = {
  getAltServeSubstitutedOverallStats: (): Promise<AxiosResponse<AltServeOverallStatsResponse>> => {
    return apiClient.get("/order-transaction/alt-serve-substituted-overall-stats/");
  },

  getAltServedOrderQtyByStatusAndCostRange: (): Promise<AxiosResponse<any>> => {
    return apiClient.get("/order-transaction/alt-served-order-qty-by-status-and-cost-range/");
  },

  getAltServedUnitsByType: (): Promise<AxiosResponse<any>> => {
    return apiClient.get("/order-transaction/alt-served-units-by-type/");
  },

  getAltServedMaterialStatusBreakdown: (): Promise<AxiosResponse<any>> => {
    return apiClient.get("/order-transaction/alt-served-material-status-breakdown/");
  },

  getAltServedBreakdownAnalysis: (): Promise<AxiosResponse<any>> => {
    return apiClient.get("/order-transaction/alt-served-breakdown-analysis/");
  },

  getAltServedMaterialsByStatus: (category: string): Promise<AxiosResponse<any>> => {
    return apiClient.get(`/order-transaction/alt-served-materials-by-status/${encodeURIComponent(category)}/`);
  },

  getKPIs: (): Promise<AxiosResponse<OrderTransactionKPIsResponse>> => {
    return apiClient.get("/order-transaction/kpis/");
  },

  getSubstitutionAltServeKPIs: (): Promise<
    AxiosResponse<{
      success: boolean;
      data: {
        total_materials: number;
        materials_with_substitution: number;
        substitution_percent: number;
        materials_with_alt_serve: number;
        alt_serve_percent: number;
      };
    }>
  > => {
    return apiClient.get("/order-transaction/substitution-alt-serve-kpis/");
  },

  getMaterialGroupAltServeTrend: (): Promise<AxiosResponse<MaterialGroupAltServeTrendResponse>> => {
    return apiClient.get("/order-transaction/material-group-alt-serve-trend/");
  },

  getMaterialGroupSubstitutedTrend: (): Promise<AxiosResponse<MaterialGroupSubstitutedTrendResponse>> => {
    return apiClient.get("/order-transaction/material-group-substituted-trend/");
  },

  /** Forecast comparison page â€” weekly unit sales by sales group (deduplicated weeks across both 4-week windows). */
  getWeeklySalesBySalesGroup: (params: {
    current_week: string;
    previous_week: string;
  }): Promise<AxiosResponse<ApiResponse<WeeklySalesBySalesGroupWeek[]>>> => {
    return apiClient.get("/order-transaction/weekly-sales-by-sales-group/", { params });
  },
};

/** Row from GET /order-transaction/weekly-sales-by-sales-group/ */
export interface WeeklySalesByGroupEntry {
  sales_group: string;
  sales_amount: number;
  total_order_qty: number;
  total_shipped_qty: number;
}

export interface WeeklySalesBySalesGroupWeek {
  week_start: string;
  sales: WeeklySalesByGroupEntry[];
}

export interface MaterialForecastComparisonFormulary {
  id: number;
  parent_program: string;
  program: string;
  contract_number: string;
  sales_group: string;
}

export interface MaterialForecastComparisonPeriodMetrics {
  week: string;
  sales_28d_prior: number;
  forecast_28d_prior: number;
  shipped_qty_28d_prior: number;
}

export interface MaterialForecastComparisonDetailPayload {
  formularies: MaterialForecastComparisonFormulary[];
  current_period: MaterialForecastComparisonPeriodMetrics;
  previous_period: MaterialForecastComparisonPeriodMetrics;
}

export type CsSalesMetricField = string | number;

export interface SalesTimelineMonthlyItem {
  year: number;
  month: number;
  sales_amount: CsSalesMetricField;
  total_order_qty: CsSalesMetricField;
  total_shipped_qty: CsSalesMetricField;
}

export interface SalesTimelineWeeklyItem {
  week_start: string;
  sales_amount: CsSalesMetricField;
  total_order_qty: CsSalesMetricField;
  total_shipped_qty: CsSalesMetricField;
}

export type SalesTimelineItem = SalesTimelineMonthlyItem | SalesTimelineWeeklyItem;

export function isSalesTimelineWeeklyItem(item: SalesTimelineItem): item is SalesTimelineWeeklyItem {
  return "week_start" in item && typeof item.week_start === "string" && item.week_start.length > 0;
}

export interface SalesTimelineResponse {
  success: boolean;
  data: SalesTimelineItem[];
}

export interface StateSalesComparisonItem {
  state: string;
  current_period_sales: CsSalesMetricField;
  previous_period_sales: CsSalesMetricField;
  current_period_order_qty: CsSalesMetricField;
  previous_period_order_qty: CsSalesMetricField;
  current_period_shipped_qty: CsSalesMetricField;
  previous_period_shipped_qty: CsSalesMetricField;
}

export interface MaterialSalesComparisonItem {
  mat_nbr: string;
  material_name: string;
  current_period_sales: CsSalesMetricField;
  previous_period_sales: CsSalesMetricField;
  current_period_order_qty: CsSalesMetricField;
  previous_period_order_qty: CsSalesMetricField;
  current_period_shipped_qty: CsSalesMetricField;
  previous_period_shipped_qty: CsSalesMetricField;
}

export interface SalesGroupComparisonItem {
  sales_group: string;
  current_period_sales: CsSalesMetricField;
  previous_period_sales: CsSalesMetricField;
  current_period_order_qty: CsSalesMetricField;
  previous_period_order_qty: CsSalesMetricField;
  current_period_shipped_qty: CsSalesMetricField;
  previous_period_shipped_qty: CsSalesMetricField;
}

export interface CustomerSalesComparisonItem {
  cust_corp_chain_nbr: string;
  customer_name: string;
  current_period_sales: CsSalesMetricField;
  previous_period_sales: CsSalesMetricField;
  current_period_order_qty: CsSalesMetricField;
  previous_period_order_qty: CsSalesMetricField;
  current_period_shipped_qty: CsSalesMetricField;
  previous_period_shipped_qty: CsSalesMetricField;
}

export interface PaginatedSalesComparisonResponse<T> {
  success: boolean;
  data: {
    count: number;
    next: string | null;
    previous: string | null;
    results: T[];
  };
}

export interface CsSalesHistoricalParams {
  end_year?: number;
  end_month?: number;
  months?: number;
  state?: string;
  federal_cs_ind?: string;
  exclude_federal_cs_ind?: string;
  limit?: number;
  offset?: number;
}

export interface CsSalesCurrentParams {
  current_start_date: string;
  current_end_date: string;
  previous_start_date: string;
  previous_end_date: string;
  state?: string;
  federal_cs_ind?: string;
  exclude_federal_cs_ind?: string;
  limit?: number;
  offset?: number;
}

export const csSalesApi = {
  getSalesTimeline: (
    tab: "historical" | "current",
    params: CsSalesHistoricalParams | CsSalesCurrentParams
  ): Promise<AxiosResponse<SalesTimelineResponse>> => {
    const base = tab === "historical" ? "/order-transaction-aggregated" : "/order-transaction";
    return apiClient.get(`${base}/sales-timeline/`, { params });
  },

  getSalesComparisonByState: (
    tab: "historical" | "current",
    params: CsSalesHistoricalParams | CsSalesCurrentParams
  ): Promise<AxiosResponse<{ success: boolean; data: StateSalesComparisonItem[] }>> => {
    const base = tab === "historical" ? "/order-transaction-aggregated" : "/order-transaction";
    return apiClient.get(`${base}/sales-comparison/by-state/`, { params });
  },

  getSalesComparisonByMaterial: (
    tab: "historical" | "current",
    params: CsSalesHistoricalParams | CsSalesCurrentParams
  ): Promise<AxiosResponse<PaginatedSalesComparisonResponse<MaterialSalesComparisonItem>>> => {
    const base = tab === "historical" ? "/order-transaction-aggregated" : "/order-transaction";
    return apiClient.get(`${base}/sales-comparison/by-material/`, { params });
  },

  getSalesComparisonBySalesGroup: (
    tab: "historical" | "current",
    params: CsSalesHistoricalParams | CsSalesCurrentParams
  ): Promise<AxiosResponse<{ success: boolean; data: SalesGroupComparisonItem[] }>> => {
    const base = tab === "historical" ? "/order-transaction-aggregated" : "/order-transaction";
    return apiClient.get(`${base}/sales-comparison/by-sales-group/`, { params });
  },

  getSalesComparisonByCustomer: (
    tab: "historical" | "current",
    params: CsSalesHistoricalParams | CsSalesCurrentParams
  ): Promise<AxiosResponse<PaginatedSalesComparisonResponse<CustomerSalesComparisonItem>>> => {
    const base = tab === "historical" ? "/order-transaction-aggregated" : "/order-transaction";
    return apiClient.get(`${base}/sales-comparison/by-customer/`, { params });
  },
};

// Fail to Supply (FTS) Mitigation
export interface FtsTrendPoint {
  date: string; // YYYY-MM-DD
  value: number; // percentage 0-100
}

export interface PaginatedResults<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

export interface FederalCsIndicatorItem {
  federal_cs_ind: string;
}

export interface FederalCsIndicatorResponse {
  success: boolean;
  data: PaginatedResults<FederalCsIndicatorItem>;
}

export const federalCsIndicatorService = {
  getFederalCsIndicators: (params?: { limit?: number; offset?: number }): Promise<AxiosResponse<FederalCsIndicatorResponse>> =>
    apiClient.get("/material/federal-cs-indicator/", {
      params: { limit: 50, offset: 0, ...params },
    }),
};

export interface FtsMaterialRow {
  mat_nbr: string;
  material_name: string;
  /** National drug code when provided by the API (some responses use `material_ndc` instead). */
  ndc?: string | null;
  material_ndc?: string | null;
  omits_qty: number;
  sales_amount: string;
  prxo_service_level_trend: FtsTrendPoint[];
  pharmagen_service_level_trend: FtsTrendPoint[];
  total_service_level_trend: FtsTrendPoint[];
  fill_rate_trend: FtsTrendPoint[];
}

export interface FtsMaterialsResponse {
  success: boolean;
  data: PaginatedResults<FtsMaterialRow>;
  message?: string;
  error?: string;
}

export interface FtsPlantRow {
  plant_nbr: string;
  plant_name: string;
  prxo_missed_lines: number;
  pgen_missed_lines: number;
  total_missed_lines: number;
  total_missed_lines_pct: number;
  outbound_fill_rate: number;
  service_level: number;
  omit_qty: number;
  demand_qty: number;
  ordered_lines: number;
}

export interface FtsPlantsResponse {
  success: boolean;
  data: PaginatedResults<FtsPlantRow>;
  message?: string;
  error?: string;
}

export interface FtsMaterialsParams {
  from_date?: string;
  to_date?: string;
  ordering?: string;
  limit?: number;
  offset?: number;
  supplier?: string;
  product_family?: string;
  therapeutic_class?: string;
  buyer?: string;
  category_manager?: string;
  material?: string;
  gcn?: string;
  formulary?: string;
}

export interface FtsPlantsParams {
  from_date?: string;
  to_date?: string;
  ordering?: string;
  limit?: number;
  offset?: number;
  prxo_missed_lines_min?: number;
  prxo_missed_lines_max?: number;
  pgen_missed_lines_min?: number;
  pgen_missed_lines_max?: number;
  total_missed_lines_min?: number;
  total_missed_lines_max?: number;
  total_missed_lines_pct_min?: number;
  total_missed_lines_pct_max?: number;
  outbound_fill_rate_min?: number;
  outbound_fill_rate_max?: number;
  service_level_min?: number;
  service_level_max?: number;
  omit_qty_min?: number;
  omit_qty_max?: number;
  demand_qty_min?: number;
  demand_qty_max?: number;
  ordered_lines_min?: number;
  ordered_lines_max?: number;
}

export const failToSupplyService = {
  getMaterials: (params?: FtsMaterialsParams, signal?: AbortSignal): Promise<AxiosResponse<FtsMaterialsResponse>> => {
    return apiClient.get("/order-transaction/fail-to-supply/materials/", { params, signal });
  },
  getPlants: (matNbr: string, params?: FtsPlantsParams): Promise<AxiosResponse<FtsPlantsResponse>> => {
    return apiClient.get(`/order-transaction/fail-to-supply/materials/${encodeURIComponent(matNbr)}/plants/`, { params });
  },
};

export const demandForecastService = {
  getWeeklyForecastGroups: (): Promise<AxiosResponse<any>> => {
    return apiClient.get("/demand-forecast/weekly-forecast-groups/");
  },

  getInventoryOnEachPlant: (substitutionId: number | string): Promise<AxiosResponse<any>> => {
    return apiClient.get(`/demand-forecast/inventory-on-each-plant/${substitutionId}/`);
  },

  getDemandPlanningAndOutboundUnfilledRate: (): Promise<AxiosResponse<DemandPlanningAndOutboundUnfilledRateResponse>> => {
    return apiClient.get("/demand-forecast/demand-planning-and-outbound-unfilled-rate/");
  },

  getMaterialForecastComparisonDetail: (
    matNbr: string,
    params: { current_week: string; previous_week: string }
  ): Promise<AxiosResponse<ApiResponse<MaterialForecastComparisonDetailPayload>>> => {
    return apiClient.get(`/demand-forecast/materials/${encodeURIComponent(matNbr)}/forecast-comparison-detail/`, {
      params,
    });
  },
};

export interface RiskModelDescription {
  id: number;
  model_name: string;
  model_description: string;
  model_type: string;
  display_name: string;
  created_at: string;
  updated_at: string;
}
export interface RiskModelDescriptionResponse {
  success: boolean;
  data: RiskModelDescription[];
}
export const riskModelDescriptionService = {
  getRiskModelDescriptions: (): Promise<AxiosResponse<RiskModelDescriptionResponse>> => {
    return apiClient.get("/risk-model-description/");
  },
};

export const materialFormularyService = {
  getUniqueMaterialFormulary: (): Promise<AxiosResponse<any>> => {
    return apiClient.get("/material-formulary/unique/");
  },
};

export type FormularySalesGroup = "PRxO" | "PGEN";

export interface FormularySwitchSummaryItem {
  initial_program_code: string | null;
  final_program_code: string | null;
  initial_sales_group: string | null;
  final_sales_group: string | null;
  count: number;
}

export interface FormularySwitchDetailItem {
  id: number;
  mat_nbr: string;
  material_name: string;
  initial_program_code: string | null;
  initial_sales_group: string | null;
  final_program_code: string | null;
  final_sales_group: string | null;
  change_date: string;
}

export interface FormularySwitchesResponse {
  count: number;
  next: string | null;
  previous: string | null;
  results: FormularySwitchDetailItem[];
}

export const formularyChangeTrackingService = {
  getSwitchSummary: (
    params: {
      involves_sales_group: FormularySalesGroup;
      days?: number;
    },
    signal?: AbortSignal
  ): Promise<AxiosResponse<ApiResponse<FormularySwitchSummaryItem[]>>> =>
    apiClient.get("/material-formulary-change/switches/summary/", { params, signal }),
  getSwitches: (params: {
    from_program?: string;
    to_program?: string;
    involves_sales_group: FormularySalesGroup;
    from_sales_group?: string;
    to_sales_group?: string;
    limit?: number;
    offset?: number;
    days?: number;
  }): Promise<AxiosResponse<ApiResponse<FormularySwitchesResponse>>> =>
    apiClient.get("/material-formulary-change/switches/", { params }),
};

export const drivingRiskService = {
  getVendorDrivingRisk: (): Promise<AxiosResponse<any>> => {
    return apiClient.get("/vendor/driving-risk/");
  },

  getMaterialDrivingRisk: (): Promise<AxiosResponse<any>> => {
    return apiClient.get("/material/driving-risk/");
  },
};

export interface LookupFilters {
  limit?: number;
  offset?: number;
  mat_nbr?: string;
  name?: string;
  vendor_nbr?: string;
  plant_nbr?: string;
}

export const lookupService = {
  getMaterials: (params?: LookupFilters): Promise<AxiosResponse<any>> => {
    return apiClient.get("/material/", { params });
  },

  getVendors: (params?: LookupFilters): Promise<AxiosResponse<any>> => {
    return apiClient.get("/vendor/", { params });
  },

  getPlants: (params?: LookupFilters): Promise<AxiosResponse<any>> => {
    return apiClient.get("/plant/", { params });
  },
};

/** Manage → Chargebacks — shared summary KPIs (rolling window) */
export interface ChargebacksSummaryData {
  contract_sales_amount: string;
  contract_sales_qty: string;
  chargeback_amount: string;
}

export interface ChargebacksSummaryParams {
  days?: number;
  supplier_nbr?: string;
  direct_mat_nbr?: string;
}

/** DCO trend â€” weekly average DCO + overall mean */
export interface ChargebacksDcoTrendPoint {
  week: string;
  average_dco: number | null;
}

export interface ChargebacksDcoTrendData {
  overall_average_dco: number | null;
  trend: ChargebacksDcoTrendPoint[];
}

/** Validation timeliness / unvalidated duration bucket rows */
export interface ChargebacksBucketRow {
  bucket: string;
  count: number;
}

export interface ChargebacksSupplierMaterialParams {
  days?: number;
  supplier_nbr?: string;
  direct_mat_nbr?: string;
}

export interface ChargebacksGenerationStatusParams {
  days?: number;
  vendor_nbr?: string;
}

export interface ChargebacksSalesVsTrendPoint {
  week: string;
  contract_sales_amount: string;
  chargeback_amount: string;
}

export interface ChargebacksGenerationStatusRow {
  week_bucket: string;
  chargebacks_generated_units: string;
  not_generated_units: string;
}

export interface ChargebacksMissingRow {
  vendor_nbr: string;
  vendor_name: string;
  material_name: string;
  material_id: string;
  ndc: string;
  invoice_date: string;
  invoice_number: string;
  manufacturer_contract_name: string;
  contract_sales_and_rebill_qty: string;
  contract_sales_and_rebill_amount: string;
}

export interface ChargebacksMissingParams {
  days?: number;
  supplier_nbr?: string;
  direct_mat_nbr?: string;
  ordering?: string;
  limit?: number;
  offset?: number;
}

export interface ChargebacksMissingPaginator {
  count: number;
  next: string | null;
  previous: string | null;
  results: ChargebacksMissingRow[];
}

export interface ChargebacksRejectionsParams {
  days?: number;
  supplier_nbr?: string;
  direct_mat_nbr?: string;
  rejection_reason?: string;
  ordering?: string;
  limit?: number;
  offset?: number;
}

export const chargebackService = {
  getContractSalesVsChargebackAmount: (): Promise<AxiosResponse<ApiResponse<unknown>>> => apiClient.get("/chargeback/overview/"),
  getSalesVsChargebacksTrend: ({
    params,
    signal,
  }: {
    params?: ChargebacksSupplierMaterialParams;
    signal?: AbortSignal;
  } = {}): Promise<AxiosResponse<ApiResponse<ChargebacksSalesVsTrendPoint[]>>> =>
    apiClient.get("/chargebacks/sales-vs-chargebacks-trend/", { params, signal: signal ?? undefined }),
  getChargebacksGenerationStatus: ({
    params,
    signal,
  }: {
    params?: ChargebacksGenerationStatusParams;
    signal?: AbortSignal;
  } = {}): Promise<AxiosResponse<ApiResponse<ChargebacksGenerationStatusRow[]>>> =>
    apiClient.get("/chargebacks/generation-status/", { params, signal: signal ?? undefined }),
  getChargebacksMissing: ({
    params,
    signal,
  }: {
    params?: ChargebacksMissingParams;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<ChargebacksMissingPaginator>>> =>
    apiClient.get("/chargebacks/missing/", { params, signal: signal ?? undefined }),
  getSummary: ({
    params,
    signal,
  }: {
    params?: ChargebacksSummaryParams;
    signal?: AbortSignal;
  } = {}): Promise<AxiosResponse<ApiResponse<ChargebacksSummaryData>>> =>
    apiClient.get("/chargebacks/summary/", { params, signal: signal ?? undefined }),
  getDcoTrends: ({
    params,
    signal,
  }: {
    params?: ChargebacksSupplierMaterialParams;
    signal?: AbortSignal;
  } = {}): Promise<AxiosResponse<ApiResponse<ChargebacksDcoTrendData>>> =>
    apiClient.get("/chargebacks/dco-trend/", { params: params ?? {}, signal: signal ?? undefined }),
  getValidationTimeliness: ({
    params,
    signal,
  }: {
    params?: ChargebacksSupplierMaterialParams;
    signal?: AbortSignal;
  } = {}): Promise<AxiosResponse<ApiResponse<ChargebacksBucketRow[]>>> =>
    apiClient.get("/chargebacks/validation-timeliness/", { params, signal: signal ?? undefined }),
  getUnvalidatedDuration: ({
    params,
    signal,
  }: {
    params?: ChargebacksSupplierMaterialParams;
    signal?: AbortSignal;
  } = {}): Promise<AxiosResponse<ApiResponse<ChargebacksBucketRow[]>>> =>
    apiClient.get("/chargebacks/unvalidated-duration/", { params, signal: signal ?? undefined }),
  getRejectionVolume: ({
    params,
    signal,
  }: {
    params?: ChargebacksSupplierMaterialParams;
    signal?: AbortSignal;
  } = {}): Promise<AxiosResponse<ApiResponse<unknown>>> =>
    apiClient.get("/chargebacks/rejection-volume/", { params: params ?? {}, signal: signal ?? undefined }),
  getRejectionReasons: ({
    params,
    signal,
  }: {
    params?: ChargebacksSupplierMaterialParams;
    signal?: AbortSignal;
  } = {}): Promise<AxiosResponse<ApiResponse<unknown>>> =>
    apiClient.get("/chargebacks/rejection-reasons/", { params: params ?? {}, signal: signal ?? undefined }),
  getRejections: ({
    params,
    signal,
  }: {
    params?: ChargebacksRejectionsParams;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<unknown>>> =>
    apiClient.get("/chargebacks/rejections/", { params, signal: signal ?? undefined }),
};

export interface InboundScansKPIsResponse {
  total_scans: number;
  successful_scans: number;
  unsuccessful_scans: number;
}

export interface WeeklyHistoryItem {
  week_start: string;
  total_scans: number;
  successful_scans: number;
  success_rate: number;
}

export interface FailedPurchaseOrderApiItem {
  purchase_order_number: string;
  total_failed_scans: number;
  lot_expiration_errors: number;
  expiration_errors: number;
  sgtin_not_found_errors: number;
  null_failure_errors: number;
  expired_product_errors: number;
  wrong_dated_scan_errors: number;
  lot_errors: number;
  missing_gtin_errors: number;
}

export interface FailedPurchaseOrdersResponse {
  count: number;
  next: string | null;
  previous: string | null;
  results: FailedPurchaseOrderApiItem[];
}

/** EPCIS coverage KPIs by distinct materials (serialization readiness). */
export interface MaterialEpcisKpisData {
  /** Distinct active products in the catalog (normal + WEE). */
  total_mat_count: number;
  /** Of the catalog products, those flagged as WEE. */
  total_wee_mat_count: number;
  /** Distinct products actually received within the lookback window. */
  total_mats_received_count: number;
  materials_with_epcis: number;
  materials_without_epcis: number;
  epcis_coverage_pct: number;
}

/**
 * EPCIS coverage KPIs by received quantity (serialization readiness).
 * Coverage is measured by purchase-order line, not units; a line with any
 * failed scan is flagged as an issue rather than counted as covered.
 */
export interface ReceivedQtyEpcisKpisData {
  total_received_qty: number;
  total_lines: number;
  lines_with_epcis: number;
  lines_with_issues: number;
  lines_without_data: number;
  epcis_coverage_pct: number;
}

export interface MaterialEpcisWeeklyTrendItem {
  week_start: string;
  total_materials: number;
  materials_with_epcis: number;
  materials_without_epcis: number;
  epcis_coverage_pct: number;
}

export interface ReceivedQtyEpcisWeeklyTrendItem {
  week_start: string;
  total_received_qty: number;
  total_lines: number;
  lines_with_epcis: number;
  lines_with_issues: number;
  lines_without_data: number;
  epcis_coverage_pct: number;
}

export interface EpcisOnOrderByDaysRangeItem {
  days_range: string;
  original_qty: number;
  received_qty: number;
  epcis_count: number;
  epcis_order_qty: string | number | null;
  epcis_net_po_value?: string | number | null;
  outstanding_qty: number;
  outstanding_qty_no_epcis: number;
  outstanding_qty_with_epcis: number;
  outstanding_amt?: string | number | null;
  outstanding_amt_no_epcis?: string | number | null;
  outstanding_amt_with_epcis?: string | number | null;
}

export interface EpcisOnOrderNoEpcisLineItem {
  po_number: string;
  po_line_number: number | null;
  material: string;
  material_description: string;
  supplier: string;
  dqsa_exempt_flg: string;
  xplant_mat_stat: string;
  plant: string;
  expected_delivery_days: number;
  anticipated_date: string;
  days_range: string;
  original_order_qty: number;
  received_qty: number;
  epcis_serial_count: number;
  epcis_record_present: boolean;
  outstanding_qty_no_epcis: number;
  outstanding_amt_no_epcis: string | number | null;
}

export type EpcisOnOrderNoEpcisLinesResponse = PaginatedResults<EpcisOnOrderNoEpcisLineItem>;

export const inboundScansService = {
  getInboundScansKPIs: ({
    params,
    signal,
  }: {
    params?: Record<string, unknown>;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<InboundScansKPIsResponse>>> =>
    apiClient.get("/inbound-serialization-scans/kpis/", { params, signal: signal ?? undefined }),
  getWeeklyHistory: ({
    params,
    signal,
  }: {
    params?: Record<string, unknown>;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<WeeklyHistoryItem[]>>> =>
    apiClient.get("/inbound-serialization-scans/weekly-history/", { params, signal: signal ?? undefined }),
  getFailedPurchaseOrders: ({
    params,
    signal,
  }: {
    params?: {
      days?: number;
      limit?: number;
      offset?: number;
      ordering?: string;
      total_failed_scans_min?: number;
      total_failed_scans_max?: number;
      sgtin_not_found_errors_min?: number;
      sgtin_not_found_errors_max?: number;
      lot_errors_min?: number;
      lot_errors_max?: number;
      expiration_errors_min?: number;
      expiration_errors_max?: number;
      [key: string]: unknown;
    };
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<FailedPurchaseOrdersResponse>>> =>
    apiClient.get("/inbound-serialization-scans/failed-purchase-orders/", {
      params,
      signal: signal ?? undefined,
    }),
  getMaterialEpcisKpis: ({
    params,
    signal,
  }: {
    params?: Record<string, unknown>;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<MaterialEpcisKpisData>>> =>
    apiClient.get("/inbound-serialization-scans/material-epcis-kpis/", {
      params,
      signal: signal ?? undefined,
    }),
  getMaterialEpcisWeeklyTrend: ({
    params,
    signal,
  }: {
    params?: Record<string, unknown>;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<MaterialEpcisWeeklyTrendItem[]>>> =>
    apiClient.get("/inbound-serialization-scans/material-epcis-weekly-trend/", {
      params,
      signal: signal ?? undefined,
    }),
  getReceivedQtyEpcisKpis: ({
    params,
    signal,
  }: {
    params?: Record<string, unknown>;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<ReceivedQtyEpcisKpisData>>> =>
    apiClient.get("/inbound-serialization-scans/received-qty-epcis-kpis/", {
      params,
      signal: signal ?? undefined,
    }),
  getReceivedQtyEpcisWeeklyTrend: ({
    params,
    signal,
  }: {
    params?: Record<string, unknown>;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<ReceivedQtyEpcisWeeklyTrendItem[]>>> =>
    apiClient.get("/inbound-serialization-scans/received-qty-epcis-weekly-trend/", {
      params,
      signal: signal ?? undefined,
    }),
};

export const epcisSerialAssignmentsService = {
  getOnOrderByDaysRange: ({
    params,
    signal,
  }: {
    params?: { days?: number; [key: string]: unknown };
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<EpcisOnOrderByDaysRangeItem[]>>> =>
    apiClient.get("/epcis-serial-assignments/on-order-by-days-range/", {
      params,
      signal: signal ?? undefined,
    }),
  getOnOrderNoEpcisLines: ({
    params,
    signal,
  }: {
    params?: {
      days?: number;
      days_range?: string;
      limit?: number;
      offset?: number;
      [key: string]: unknown;
    };
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<EpcisOnOrderNoEpcisLinesResponse>>> =>
    apiClient.get("/epcis-serial-assignments/on-order-no-epcis-lines/", {
      params,
      signal: signal ?? undefined,
    }),
};

export const outboundScansService = {
  getWeeklyHistory: ({
    params,
    signal,
  }: {
    params?: Record<string, unknown>;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<WeeklyHistoryItem[]>>> =>
    apiClient.get("/outbound-serialization-scans/weekly-history/", { params, signal: signal ?? undefined }),
};

export const returnsScansService = {
  getWeeklyHistory: ({
    params,
    signal,
  }: {
    params?: Record<string, unknown>;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<WeeklyHistoryItem[]>>> =>
    apiClient.get("/returns-serialization-scans/weekly-history/", { params, signal: signal ?? undefined }),
};

export interface QuarantineSgtinRow {
  material_id: string;
  material_name: string;
  ndc: string;
  sgtin: string;
  lead_time: number;
  /** ISO date or datetime; aligns with sort field `original_created_date`. */
  original_created_date?: string | null;
  original_created_at?: string | null;
}

export interface QuarantinePaginator<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

export interface QuarantineSgtinsParams {
  tab?: string;
  days?: number;
  plant_nbr?: string;
  quarantine_action?: string;
  status_code?: string;
  date_from?: string;
  date_to?: string;
  lead_time_min?: number;
  lead_time_max?: number;
  ordering?: string;
  limit?: number;
  offset?: number;
}

export interface QuarantineMovementTimelineSummary {
  date: string;
  entered_quarantine: number;
  entered_quarantine_qty: number | null;
  entered_quarantine_amt: string | null;
  current_quarantine: number;
  current_quarantine_qty: number | null;
  current_quarantine_amt: string | null;
  returned_sgtins: number;
  returned_sgtins_qty: number | null;
  returned_sgtins_amt: string | null;
  inventory_sgtins: number;
  inventory_sgtins_qty: number | null;
  inventory_sgtins_amt: string | null;
}

export interface QuarantineMovementTimelineDailyPoint {
  event_date: string;
  entered_quarantine: number;
  current_quarantine: number;
  returned_sgtins: number;
  inventory_sgtins: number;
  cumulative_entered: number;
  cumulative_returned: number;
  cumulative_to_inventory: number;
}

export interface QuarantineMovementTimelineData {
  summary: QuarantineMovementTimelineSummary;
  daily: QuarantineMovementTimelineDailyPoint[];
}

export interface QuarantineMovementTimelineParams {
  date?: string;
  days?: number;
}

export interface QuarantineMovementDetailItem {
  process_date: string;
  sgtin: string;
}

export interface QuarantineMovementDetailData {
  date: string;
  entered: QuarantineMovementDetailItem[];
  current: QuarantineMovementDetailItem[];
  returned: QuarantineMovementDetailItem[];
  inventory: QuarantineMovementDetailItem[];
}

export interface QuarantineByMaterialRow {
  material_id: string;
  material_name: string;
  entered_quarantine: number;
  entered_quarantine_amt: string | null;
  current_quarantine: number;
  returned_sgtins: number;
  inventory_sgtins: number;
  percentage: number;
}

export interface QuarantineByPlantRow {
  plant_nbr: string;
  distribution_center: string;
  entered_quarantine: number;
  entered_quarantine_amt: string | null;
  current_quarantine: number;
  returned_sgtins: number;
  inventory_sgtins: number;
  percentage: number;
}

export interface QuarantineByMaterialPlantParams {
  date?: string;
  days?: number;
  limit?: number;
  offset?: number;
}

export const quarantineService = {
  getSgtins: ({
    params,
    signal,
  }: {
    params?: QuarantineSgtinsParams;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<QuarantinePaginator<QuarantineSgtinRow>>>> =>
    apiClient.get("/quarantine/sgtins/", { params, signal: signal ?? undefined }),

  getMovementTimeline: ({
    params,
    signal,
  }: {
    params?: QuarantineMovementTimelineParams;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<QuarantineMovementTimelineData>>> =>
    apiClient.get("/quarantine/movement-timeline/", { params, signal: signal ?? undefined }),

  getMovementDetail: ({
    params,
    signal,
  }: {
    params: { date: string };
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<QuarantineMovementDetailData>>> =>
    apiClient.get("/quarantine/movement-detail/", { params, signal: signal ?? undefined }),

  getByMaterial: ({
    params,
    signal,
  }: {
    params?: QuarantineByMaterialPlantParams;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<QuarantinePaginator<QuarantineByMaterialRow>>>> =>
    apiClient.get("/quarantine/by-material/", { params, signal: signal ?? undefined }),

  getByPlant: ({
    params,
    signal,
  }: {
    params?: QuarantineByMaterialPlantParams;
    signal?: AbortSignal;
  }): Promise<AxiosResponse<ApiResponse<QuarantinePaginator<QuarantineByPlantRow>>>> =>
    apiClient.get("/quarantine/by-plant/", { params, signal: signal ?? undefined }),
};

// â”€â”€â”€ Material Group Alt Serve Trend â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

export interface MaterialGroupAltServeTrendWeeklyRow {
  week_start: string;
  week_end?: string;
  brand_alt_served_percentage?: number;
  generic_alt_served_percentage?: number;
  otc_alt_served_percentage?: number;
  [group: string]: number | string | undefined;
}

export interface MaterialGroupAltServeTrendTotalsByGroup {
  material_group: number;
  alt_served_count: number;
  alt_served_percentage: number;
  [key: string]: any;
}

/** Full response shape (includes success + data envelope) so components can store response.data directly */
export interface MaterialGroupAltServeTrendResponse {
  success: boolean;
  data: {
    weekly_data: MaterialGroupAltServeTrendWeeklyRow[];
    totals_by_group: MaterialGroupAltServeTrendTotalsByGroup[];
    overall_stats?: {
      total_orders?: number;
      alt_served_orders?: number;
    };
  };
}

// â”€â”€â”€ Material Group Substituted Trend â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

export interface MaterialGroupSubstitutedTrendWeeklyRow {
  week_start: string;
  week_end?: string;
  brand_substituted_percentage?: number;
  generic_substituted_percentage?: number;
  otc_substituted_percentage?: number;
  [group: string]: number | string | undefined;
}

export interface MaterialGroupSubstitutedTrendTotalsByGroup {
  material_group: number;
  substituted_count: number;
  substituted_percentage: number;
  [key: string]: any;
}

/** Full response shape (includes success + data envelope) so components can store response.data directly */
export interface MaterialGroupSubstitutedTrendResponse {
  success: boolean;
  data: {
    weekly_data: MaterialGroupSubstitutedTrendWeeklyRow[];
    totals_by_group: MaterialGroupSubstitutedTrendTotalsByGroup[];
    overall_stats?: {
      total_orders?: number;
      substituted_orders?: number;
    };
  };
}

// â”€â”€â”€ Custom Lists â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

export interface CustomList {
  id?: string;
  name: string;
  description?: string;
  public?: boolean;
  color?: string;
  icon?: string;
  items_count?: number;
  material_count?: number;
  created_at?: string;
  updated_at?: string;
  materials?: Array<{ mat_nbr: string; name: string }>;
}

export const customListsService = {
  getCustomLists: (params?: {
    limit?: number;
    offset?: number;
    ordering?: string;
  }): Promise<
    AxiosResponse<ApiResponse<{ results: CustomList[]; count: number; next: string | null; previous: string | null }>>
  > => apiClient.get("/custom-lists/", { params }),

  getCustomListDetails: (listId: string): Promise<AxiosResponse<ApiResponse<CustomList>>> =>
    apiClient.get(`/custom-lists/${listId}/`),

  createCustomList: (data: { name: string; description?: string }): Promise<AxiosResponse<ApiResponse<CustomList>>> =>
    apiClient.post("/custom-lists/", data),

  updateCustomList: (
    listId: string,
    data: { name?: string; description?: string }
  ): Promise<AxiosResponse<ApiResponse<CustomList>>> => apiClient.patch(`/custom-lists/${listId}/`, data),

  deleteCustomList: (listId: string): Promise<AxiosResponse<void>> => apiClient.delete(`/custom-lists/${listId}/`),

  addMaterials: (
    listId: string,
    payload: { entity_ids?: string[]; mat_nbrs?: string[] }
  ): Promise<AxiosResponse<ApiResponse<CustomList>>> => apiClient.put(`/custom-lists/${listId}/items/sync/`, payload),

  customListKpiStats: (): Promise<AxiosResponse<ApiResponse<any>>> => apiClient.get("/custom-lists/stats/"),
};

export interface CascadingOptionFilters {
  limit?: number;
  offset?: number;
  search?: string;
  mat_nbr?: string;
  mat_nbr__in?: string;
  vendor_nbr?: string;
  vendor_nbr__in?: string;
  plant_nbr?: string;
  plant_nbr__in?: string;
  cust_corp_chain_nbr?: string;
  cust_corp_chain_nbr__in?: string;
}

export interface CascadingMaterialOption {
  mat_nbr: string;
  name: string;
}

export interface CascadingVendorOption {
  vendor_nbr: string;
  name: string;
}

export interface CascadingPlantOption {
  plant_nbr: string;
  name: string;
}

export interface CascadingCustomerOption {
  cust_corp_chain_nbr: string;
  name: string;
}

export interface CascadingOptionsResponse<T> {
  success: boolean;
  data?: {
    count: number;
    next: string | null;
    previous: string | null;
    results: T[];
  };
}

export const cascadingOptionsService = {
  getMaterialOptions: (
    params?: CascadingOptionFilters
  ): Promise<AxiosResponse<CascadingOptionsResponse<CascadingMaterialOption>>> => {
    return apiClient.get("/material/", { params });
  },

  getVendorOptions: (
    params?: CascadingOptionFilters
  ): Promise<AxiosResponse<CascadingOptionsResponse<CascadingVendorOption>>> => {
    return apiClient.get("/vendor/", { params });
  },

  getPlantOptions: (params?: CascadingOptionFilters): Promise<AxiosResponse<CascadingOptionsResponse<CascadingPlantOption>>> => {
    return apiClient.get("/plant/", { params });
  },

  getCustomerOptions: (
    params?: CascadingOptionFilters
  ): Promise<AxiosResponse<CascadingOptionsResponse<CascadingCustomerOption>>> => {
    return apiClient.get("/customer-corp-chain/", { params });
  },
};
