import type { ProductSalesData } from "@/components/manage/sales/TotalUnitSalesDataTable";
import type { CsSalesMetricField } from "@/lib/apiServices";
import { parseCsSalesMetric } from "@/lib/csSalesValueParse";

export type CsSalesComparisonMetricsRow = {
  current_period_sales: CsSalesMetricField;
  previous_period_sales: CsSalesMetricField;
  current_period_order_qty: CsSalesMetricField;
  previous_period_order_qty: CsSalesMetricField;
};

export function mapCsSalesComparisonRows<T extends CsSalesComparisonMetricsRow>(
  items: T[],
  isDollars: boolean,
  getProductName: (row: T) => string
): ProductSalesData[] {
  return items.map(item => {
    const curSales = parseCsSalesMetric(item.current_period_sales);
    const prevSales = parseCsSalesMetric(item.previous_period_sales);
    const curQty = parseCsSalesMetric(item.current_period_order_qty);
    const prevQty = parseCsSalesMetric(item.previous_period_order_qty);
    const current = isDollars ? curSales : curQty;
    const previous = isDollars ? prevSales : prevQty;
    const percentChange = previous > 0 ? ((current - previous) / previous) * 100 : current > 0 ? 100 : 0;
    const displayValueRaw = (isDollars ? curSales : curQty).toLocaleString(undefined, {
      minimumFractionDigits: isDollars ? 2 : 0,
    });
    const displayPreviousRaw = (isDollars ? prevSales : prevQty).toLocaleString(undefined, {
      minimumFractionDigits: isDollars ? 2 : 0,
    });
    const displayValue = isDollars ? `$${displayValueRaw}` : displayValueRaw;
    const displayPrevious = isDollars ? `$${displayPreviousRaw}` : displayPreviousRaw;
    return {
      productName: getProductName(item),
      salesCurrentPeriod: displayValue,
      salesPreviousPeriod: displayPrevious,
      percentChange,
    };
  });
}
