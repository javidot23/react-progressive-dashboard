export interface InboundRow {
  date: string; // e.g. "2025-08-28"
  total_order_qty: number | null;
  total_received_qty: number | null;
  fill_rate: number | null; // 0..1
}

export interface InboundPoint {
  x: string; // date label
  orderQty: number;
  shippedQty: number;
  serviceLevelPct: number; // 0..100
}

export function toInboundServiceLevelSeries(rows: InboundRow[]): InboundPoint[] {
  return rows.map(r => {
    const orderQty = r.total_order_qty ?? 0;
    const receivedQty = r.total_received_qty ?? 0;
    const fillRate = orderQty > 0 ? (receivedQty / orderQty) * 100 : 0;
    return {
      x: r.date,
      orderQty,
      shippedQty: receivedQty,
      serviceLevelPct: fillRate,
    };
  });
}
