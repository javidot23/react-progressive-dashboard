import { formatDrillThroughDate } from "@/lib/materialDrillThroughUtils";
import type { DrivingEvent } from "@/types/granularityIssue";

export type DrivingEventStatusTone = "active" | "closed" | "neutral";

const ACTIVE_STATUSES = new Set(["ACTIVE", "OPEN"]);
const CLOSED_STATUSES = new Set(["CLOSED"]);

export function getDrivingEventStatusTone(status?: string | null): DrivingEventStatusTone {
  const normalized = (status ?? "").trim().toUpperCase();
  if (CLOSED_STATUSES.has(normalized)) return "closed";
  if (ACTIVE_STATUSES.has(normalized)) return "active";
  return "neutral";
}

export function getDrivingEventStatusLabel(status?: string | null): string {
  const normalized = (status ?? "").trim();
  if (!normalized) return "Unknown";

  const upper = normalized.toUpperCase();
  if (upper === "ACTIVE") return "Active";
  if (upper === "OPEN") return "Open";
  if (upper === "CLOSED") return "Closed";

  return normalized.charAt(0).toUpperCase() + normalized.slice(1).toLowerCase();
}

export function getDrivingEventAccentColor(tone: DrivingEventStatusTone): string {
  switch (tone) {
    case "active":
      return "#E22F00";
    case "closed":
      return "#8A8A8A";
    default:
      return "#FFA400";
  }
}

export function getDrivingEventStatusPillClassName(tone: DrivingEventStatusTone): string {
  switch (tone) {
    case "active":
      return "border border-[#E22F0054] bg-[#FCD9D1] text-[#E22F00]";
    case "closed":
      return "border border-ui-border-primary bg-ui-background-primary text-ui-text-secondary";
    default:
      return "border border-[#FFA40054] bg-[#FFF4E0] text-[#B45309]";
  }
}

export function formatDrivingEventLocation(event: DrivingEvent | null | undefined): string {
  if (!event) return "";
  return [event.city, event.state, event.country].filter(Boolean).join(", ");
}

export function formatDrivingEventDateRange(event: DrivingEvent): string | null {
  if (!event.start_date) return null;

  const eventClosed = getDrivingEventStatusTone(event.status) === "closed";
  let dates = formatDrillThroughDate(event.start_date);

  if (event.end_date) {
    dates += ` → ${formatDrillThroughDate(event.end_date)}`;
  } else if (!eventClosed) {
    dates += " · Ongoing";
  }

  return dates;
}

export function formatDrivingEventSummary(event: DrivingEvent | null | undefined): string {
  if (!event) return "-";

  const parts: string[] = [];
  if (event.type) parts.push(event.type);

  const statusLabel = getDrivingEventStatusLabel(event.status);
  if (statusLabel !== "Unknown") parts.push(statusLabel);

  const location = formatDrivingEventLocation(event);
  if (location) parts.push(location);

  const dates = formatDrivingEventDateRange(event);
  if (dates) parts.push(dates);

  if (event.event_id) parts.push(event.event_id);
  return parts.join(" · ");
}
