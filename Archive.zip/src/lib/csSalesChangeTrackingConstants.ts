export const STATE_ABBREVIATION_TO_NAME: Record<string, string> = {
  AL: "Alabama",
  AK: "Alaska",
  AZ: "Arizona",
  AR: "Arkansas",
  CA: "California",
  CO: "Colorado",
  CT: "Connecticut",
  DE: "Delaware",
  FL: "Florida",
  GA: "Georgia",
  HI: "Hawaii",
  ID: "Idaho",
  IL: "Illinois",
  IN: "Indiana",
  IA: "Iowa",
  KS: "Kansas",
  KY: "Kentucky",
  LA: "Louisiana",
  ME: "Maine",
  MD: "Maryland",
  MA: "Massachusetts",
  MI: "Michigan",
  MN: "Minnesota",
  MS: "Mississippi",
  MO: "Missouri",
  MT: "Montana",
  NE: "Nebraska",
  NV: "Nevada",
  NH: "New Hampshire",
  NJ: "New Jersey",
  NM: "New Mexico",
  NY: "New York",
  NC: "North Carolina",
  ND: "North Dakota",
  OH: "Ohio",
  OK: "Oklahoma",
  OR: "Oregon",
  PA: "Pennsylvania",
  PR: "Puerto Rico",
  RI: "Rhode Island",
  SC: "South Carolina",
  SD: "South Dakota",
  TN: "Tennessee",
  TX: "Texas",
  UT: "Utah",
  VT: "Vermont",
  VA: "Virginia",
  WA: "Washington",
  WV: "West Virginia",
  WI: "Wisconsin",
  WY: "Wyoming",
  DC: "District of Columbia",
  FM: "Federated States of Micronesia",
};

export const MONTH_ABBREV: Record<string, string> = {
  "01": "Jan",
  "02": "Feb",
  "03": "Mar",
  "04": "Apr",
  "05": "May",
  "06": "Jun",
  "07": "Jul",
  "08": "Aug",
  "09": "Sep",
  "10": "Oct",
  "11": "Nov",
  "12": "Dec",
};

export const formatWeekLabel = (weekStart: string): string => {
  const d = new Date(weekStart);
  const month = String(d.getMonth() + 1).padStart(2, "0");
  return `${MONTH_ABBREV[month] ?? month} ${d.getDate()}`;
};

/** X-axis label for monthly CS sales timeline bars (matches API year/month). */
export function formatMonthYearChartLabel(year: number, month: number): string {
  return `${MONTH_ABBREV[String(month).padStart(2, "0")] ?? month} ${year}`;
}

export const MAP_CONFIG = {
  center: [35, -96] as [number, number],
  zoom: 4,
  minZoom: 2,
  maxZoom: 6,
  maxBounds: [
    [0, -180],
    [72, -40],
  ] as [[number, number], [number, number]],
};

export const MAP_HEIGHT = 440;
export const BORDER_COLOR = "#CACACA";
export const DEFAULT_BORDER_WEIGHT = 0.8;
export const HOVER_BORDER_WEIGHT = 1;
export const DEFAULT_FILL_OPACITY = 0.8;
export const HOVER_FILL_OPACITY = 0.9;
export const EMPTY_STATE_COLOR = "#E8E8E8";

export interface GeoJSONFeature {
  properties?: { NAME?: string; name?: string; STATE_NAME?: string };
}

export const getStateNameFromFeature = (feature: GeoJSONFeature): string =>
  feature?.properties?.name || feature?.properties?.NAME || feature?.properties?.STATE_NAME || "";

const MAP_STATE_COLOR_LOW = [140, 126, 215] as const;
const MAP_STATE_COLOR_HIGH = [70, 30, 150] as const;

export const calculateStateSalesFillColor = (currentValue: number, minVal: number, maxVal: number): string => {
  if (maxVal <= minVal) {
    return `rgb(${MAP_STATE_COLOR_HIGH[0]}, ${MAP_STATE_COLOR_HIGH[1]}, ${MAP_STATE_COLOR_HIGH[2]})`;
  }
  const t = Math.max(0, Math.min(1, (currentValue - minVal) / (maxVal - minVal)));
  const r = Math.round(MAP_STATE_COLOR_LOW[0] + (MAP_STATE_COLOR_HIGH[0] - MAP_STATE_COLOR_LOW[0]) * t);
  const g = Math.round(MAP_STATE_COLOR_LOW[1] + (MAP_STATE_COLOR_HIGH[1] - MAP_STATE_COLOR_LOW[1]) * t);
  const b = Math.round(MAP_STATE_COLOR_LOW[2] + (MAP_STATE_COLOR_HIGH[2] - MAP_STATE_COLOR_LOW[2]) * t);
  return `rgb(${r}, ${g}, ${b})`;
};

export const DOLLAR_SALES_MAP_LEGEND_COLORS = {
  highSales: `rgb(${MAP_STATE_COLOR_HIGH[0]}, ${MAP_STATE_COLOR_HIGH[1]}, ${MAP_STATE_COLOR_HIGH[2]})`,
  lowSales: `rgb(${MAP_STATE_COLOR_LOW[0]}, ${MAP_STATE_COLOR_LOW[1]}, ${MAP_STATE_COLOR_LOW[2]})`,
} as const;

export const repositionRemoteStates = (geoJsonData: unknown): unknown => {
  const transformedData = JSON.parse(JSON.stringify(geoJsonData)) as {
    features?: Array<{ properties?: Record<string, unknown>; geometry?: { type: string; coordinates: unknown } }>;
  };
  if (!transformedData.features) return transformedData;
  const remoteStatesConfig = [
    {
      name: "Alaska",
      centerLng: -150,
      centerLat: 65,
      targetLng: -100,
      targetLat: 22.8,
      scale: 0.35,
    },
    {
      name: "Hawaii",
      centerLng: -156,
      centerLat: 20.5,
      targetLng: -118,
      targetLat: 23.4,
      scale: 1.45,
    },
    {
      name: "Puerto Rico",
      centerLng: -66.5,
      centerLat: 18.2,
      targetLng: -89,
      targetLat: 21.8,
      scale: 1.0,
    },
  ];
  transformedData.features = transformedData.features.map(
    (feature: { properties?: Record<string, unknown>; geometry?: { type: string; coordinates: unknown } }) => {
      const stateName = String(feature?.properties?.name || feature?.properties?.NAME || "");
      const config = remoteStatesConfig.find(c => c.name === stateName);
      if (config && feature.geometry) {
        const { centerLng, centerLat, targetLng, targetLat, scale } = config;
        const transformAroundCenter = (coords: unknown): unknown => {
          if (!Array.isArray(coords)) return coords;
          if (coords.length === 2 && typeof coords[0] === "number" && typeof coords[1] === "number") {
            const scaledLng = (coords[0] - centerLng) * scale + centerLng + (targetLng - centerLng);
            const scaledLat = (coords[1] - centerLat) * scale + centerLat + (targetLat - centerLat);
            return [scaledLng, scaledLat];
          }
          return coords.map((coord: unknown) => transformAroundCenter(coord));
        };
        if (feature.geometry.type === "Polygon") {
          feature.geometry.coordinates = transformAroundCenter(feature.geometry.coordinates);
        } else if (feature.geometry.type === "MultiPolygon") {
          feature.geometry.coordinates = (feature.geometry.coordinates as unknown[]).map((polygon: unknown) =>
            transformAroundCenter(polygon)
          );
        }
      }
      return feature;
    }
  );
  return transformedData;
};
