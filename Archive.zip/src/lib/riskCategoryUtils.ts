import type { MaterialRiskData } from "@/lib/apiServices";
import type { EnrichedRiskMetadata, RiskCategoryType } from "@/hooks/useRiskModelDescriptions";
import { MAIN_RISK_GROUP_TYPES } from "@/hooks/useRiskModelDescriptions";
import { buildDrivingRiskTimeline, type DrivingRiskTimelineItem } from "@/lib/materialDrillThroughUtils";

export const CATEGORY_SCORE_TIME_HORIZON = 30;

export const MODEL_TYPE_TO_CATEGORY_SCORE_TYPE: Record<string, string> = {
  base_model_operational: "category_risk_operational",
  base_model_market: "category_risk_market",
  base_model_sales: "category_risk_sales",
  base_model_regulatory: "category_risk_regulatory",
  base_model_location: "category_risk_location",
};

export type EnrichedMaterialRiskRow = MaterialRiskData & EnrichedRiskMetadata;

export interface RiskCategorySummary {
  type: string;
  title: string;
  icon: string;
  score: number;
  subtitle?: string;
}

/** Category scores and composite rows — not shown in the contributor timeline. */
export function isAggregateOrCategoryRiskRow(item: EnrichedMaterialRiskRow): boolean {
  const original = item.original_risk_type;
  if (original.startsWith("category_risk_")) return true;
  if (original === "composite_risk_model" || item.risk_type === "composite_risk_group") return true;
  if ((MAIN_RISK_GROUP_TYPES as readonly string[]).includes(original as (typeof MAIN_RISK_GROUP_TYPES)[number])) {
    return true;
  }
  if (original.startsWith("base_model_")) return true;
  return false;
}

export function isContributorRiskRow(item: EnrichedMaterialRiskRow): boolean {
  return !isAggregateOrCategoryRiskRow(item);
}

export function getMaxHorizonContributors<T extends EnrichedMaterialRiskRow>(factors: T[]): T[] {
  const byRiskType = new Map<string, T>();

  factors.forEach(factor => {
    const existing = byRiskType.get(factor.original_risk_type);
    if (!existing || factor.time_horizon > existing.time_horizon) {
      byRiskType.set(factor.original_risk_type, factor);
    }
  });

  return Array.from(byRiskType.values()).sort((a, b) => b.risk_rating - a.risk_rating);
}

export function buildRiskCategorySummaries(
  riskData: EnrichedMaterialRiskRow[],
  riskCategoryTypes: RiskCategoryType[],
  options?: { vendorName?: string; iconByType?: Record<string, string>; defaultIcon?: string }
): RiskCategorySummary[] {
  const iconByType = options?.iconByType ?? {};
  const defaultIcon = options?.defaultIcon ?? "";

  return riskCategoryTypes
    .filter(({ type }) => type.startsWith("base_model_"))
    .map(({ type, title }) => {
      const categoryScoreType = MODEL_TYPE_TO_CATEGORY_SCORE_TYPE[type];
      const categoryScoreFactor = riskData.find(
        risk => risk.original_risk_type === categoryScoreType && risk.time_horizon === CATEGORY_SCORE_TIME_HORIZON
      );

      return {
        type,
        title,
        icon: iconByType[type] ?? defaultIcon,
        score: categoryScoreFactor ? Math.round(categoryScoreFactor.risk_rating * 100) : 0,
        subtitle: type === "base_model_operational" && options?.vendorName ? `${options.vendorName} (Ctrl)` : undefined,
      };
    });
}

export function buildContributorTimeline(riskData: EnrichedMaterialRiskRow[]): DrivingRiskTimelineItem[] {
  return buildDrivingRiskTimeline(riskData.filter(isContributorRiskRow));
}

export function getRiskScoreColor(score: number): string {
  const normalizedScore = score / 100;
  if (normalizedScore <= 0.4) return "var(--Cencora-success-500-dark, #059669)";
  if (normalizedScore <= 0.8) return "var(--Cencora-warning-600-dark, #D97706)";
  return "var(--Cencora-danger-500-core, #DC2626)";
}
