// URL Query Parameter utilities for Material Filters
export const serializeMaterialFilters = (filters: any, preserveGlobalFilters: boolean = true): URLSearchParams => {
  const params = new URLSearchParams();

  // Preserve existing global filters (gf_*) from current URL if requested
  if (preserveGlobalFilters && typeof window !== "undefined") {
    const currentParams = new URLSearchParams(window.location.search);
    currentParams.forEach((value, key) => {
      if (key.startsWith("gf_")) {
        params.append(key, value);
      }
    });
  }

  // Add local filter params
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "") {
      params.set(key, value.toString());
    }
  });

  return params;
};

export const deserializeMaterialFilters = (searchParams: URLSearchParams): any => {
  const filters: Record<string, any> = {
    ordering: "-risk_adjusted_value",
    mat_nbr: "",
    risk_rating_min: null as number | null,
    risk_rating_max: null as number | null,
    primary_risk: "",
    risk_adjusted_value_min: null as number | null,
    risk_adjusted_value_max: null as number | null,
  };

  const stringKeys = new Set(["ordering", "primary_risk", "mat_nbr"]);

  // Parse URL parameters
  for (const [key, value] of searchParams.entries()) {
    if (key in filters) {
      if (stringKeys.has(key)) {
        filters[key] = value;
      } else {
        const numValue = Number(value);
        if (!isNaN(numValue)) {
          filters[key] = numValue;
        }
      }
    }
  }

  // Use default ordering if no ordering was provided in URL or if it's empty
  if (!searchParams.has("ordering") || !filters.ordering) {
    filters.ordering = "-risk_adjusted_value";
  }

  return filters;
};
