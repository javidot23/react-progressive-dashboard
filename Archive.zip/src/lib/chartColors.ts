/**
 * Shared chart color system for analytics visualizations.
 *
 * Colors resolve through CSS custom properties so they stay aligned with the
 * design-system tokens.
 *
 * Charts may use the default palettes or override colors per series via
 * `getSeriesColors` / `resolveSeriesColor`.
 */

/** CSS-variable backed categorical series (1–9). */
export const CHART_SERIES_PALETTE = [
  "var(--color-data-categorical-1)",
  "var(--color-data-categorical-2)",
  "var(--color-data-categorical-3)",
  "var(--color-data-categorical-4)",
  "var(--color-data-categorical-5)",
  "var(--color-data-categorical-6)",
  "var(--color-data-categorical-7)",
  "var(--color-data-categorical-8)",
  "var(--color-data-categorical-9)",
] as const;

export type ChartSeriesPalette = readonly string[];

export const chartPrimaryColors = {
  main: "var(--color-chart-data-primary)",
  light: "var(--color-chart-data-secondary)",
  accent: "var(--color-chart-data-tertiary)",
  muted: "var(--color-chart-data-quaternary)",
} as const;

export const chartSecondaryColors = {
  main: "var(--color-chart-data-tertiary)",
  light: "var(--color-chart-data-secondary)",
  dark: "var(--color-chart-data-primary)",
} as const;

export const chartSemanticColors = {
  success: "var(--cds-color-success-500)",
  warning: "var(--cds-color-warning-600)",
  danger: "var(--cds-color-danger-500)",
  info: "var(--cds-color-highlight-300)",
} as const;

export const chartNeutralColors = {
  axis: "var(--color-ui-text-muted)",
  grid: "var(--cds-color-border-primary)",
  reference: "var(--cds-color-core-gray-600)",
  background: "var(--color-ui-background-primary)",
  surface: "var(--color-ui-background-secondary)",
  text: "var(--color-ui-text-secondary)",
} as const;

export const chartRiskColors = {
  high: "var(--color-chart-risk-high)",
  medium: "var(--color-chart-risk-medium)",
  low: "var(--color-chart-risk-low)",
  critical: "var(--color-chart-risk-critical)",
} as const;

export const chartGeographyColors = {
  highImpact: "var(--color-chart-geography-high-impact)",
  mediumImpact: "var(--color-chart-geography-medium-impact)",
  lowImpact: "var(--color-chart-geography-low-impact)",
  riskMedium: "var(--color-chart-geography-risk-medium)",
} as const;

/** Named palettes reusable across chart types. */
export const chartPalettes = {
  /** Default multi-series categorical palette. */
  categorical: CHART_SERIES_PALETTE,
  /** Brand-forward primary/secondary emphasis. */
  brand: [chartPrimaryColors.main, chartPrimaryColors.light, chartPrimaryColors.accent, chartPrimaryColors.muted] as const,
  /** Status-oriented series (success → danger). */
  semantic: [
    chartSemanticColors.success,
    chartSemanticColors.info,
    chartSemanticColors.warning,
    chartSemanticColors.danger,
  ] as const,
  /** Risk severity scale. */
  risk: [chartRiskColors.critical, chartRiskColors.high, chartRiskColors.medium, chartRiskColors.low] as const,
  /** Geography / impact scale. */
  geography: [
    chartGeographyColors.highImpact,
    chartGeographyColors.mediumImpact,
    chartGeographyColors.lowImpact,
    chartGeographyColors.riskMedium,
  ] as const,
} as const;

export type ChartPaletteName = keyof typeof chartPalettes;

export type GetSeriesColorsOptions = {
  /** Named palette or custom color list. Defaults to `categorical`. */
  palette?: ChartPaletteName | ChartSeriesPalette;
  /** Per-index or per-key color overrides. */
  overrides?: Partial<Record<number, string>> | Record<string, string>;
  /** Optional series keys — when provided, overrides may be keyed by series id. */
  seriesKeys?: string[];
};

function resolvePalette(palette: ChartPaletteName | ChartSeriesPalette | undefined): ChartSeriesPalette {
  if (!palette) return chartPalettes.categorical;
  if (typeof palette === "string") return chartPalettes[palette];
  return palette;
}

/**
 * Resolve a single series color by index (wraps around the palette).
 */
export function resolveSeriesColor(index: number, palette?: ChartPaletteName | ChartSeriesPalette, override?: string): string {
  if (override) return override;
  const colors = resolvePalette(palette);
  if (colors.length === 0) return chartPrimaryColors.main;
  return colors[((index % colors.length) + colors.length) % colors.length]!;
}

/**
 * Build an ordered list of series colors for `count` series, applying overrides.
 */
export function getSeriesColors(count: number, options: GetSeriesColorsOptions = {}): string[] {
  const { palette, overrides = {}, seriesKeys } = options;
  const resolved = resolvePalette(palette);

  return Array.from({ length: Math.max(0, count) }, (_, index) => {
    const keyOverride = seriesKeys?.[index] != null ? (overrides as Record<string, string>)[seriesKeys[index]!] : undefined;
    const indexOverride = (overrides as Partial<Record<number, string>>)[index];
    return resolveSeriesColor(index, resolved, keyOverride ?? indexOverride);
  });
}

/**
 * Map series keys → colors using the shared palette + optional overrides.
 */
export function mapSeriesColors(
  seriesKeys: string[],
  options: Omit<GetSeriesColorsOptions, "seriesKeys"> = {}
): Record<string, string> {
  const colors = getSeriesColors(seriesKeys.length, {
    ...options,
    seriesKeys,
  });
  return Object.fromEntries(seriesKeys.map((key, i) => [key, colors[i]!]));
}

/** Full shared chart color system surface. */
export const chartColorSystem = {
  primary: chartPrimaryColors,
  secondary: chartSecondaryColors,
  semantic: chartSemanticColors,
  neutral: chartNeutralColors,
  risk: chartRiskColors,
  geography: chartGeographyColors,
  series: CHART_SERIES_PALETTE,
  palettes: chartPalettes,
  resolveSeriesColor,
  getSeriesColors,
  mapSeriesColors,
} as const;

export type ChartColorSystem = typeof chartColorSystem;

export default chartColorSystem;
