export const TARGET_SERVICE_LEVEL = 0.95;

export type OrderedLinesServiceStatus = "meets_target" | "below_target" | "no_data";

export interface OrderedLinesServiceInput {
  ordered_lines: number;
  total_missed_lines: number;
}

/** Same shape as dashboard/API contract: ratios 0–1 for missed_lines_pct and service_level when data exists. */
export interface OrderedLinesServiceMetrics {
  missed_lines_pct: number | null;
  service_level: number | null;
  threshold_missed_lines: number | null;
  status: OrderedLinesServiceStatus;
}

/** Horizontal position (0–100) of the max-missed share for the target service level. */
export function orderedLinesThresholdMarkerPercent(): number {
  return (1 - TARGET_SERVICE_LEVEL) * 100;
}

export function computeOrderedLinesServiceMetrics(input: OrderedLinesServiceInput): OrderedLinesServiceMetrics {
  const { ordered_lines, total_missed_lines } = input;

  if (ordered_lines === 0) {
    return {
      missed_lines_pct: null,
      service_level: null,
      threshold_missed_lines: null,
      status: "no_data",
    };
  }

  const missed_lines_pct = total_missed_lines / ordered_lines;
  const service_level = 1 - missed_lines_pct;
  const threshold_missed_lines = ordered_lines * (1 - TARGET_SERVICE_LEVEL);
  const status: OrderedLinesServiceStatus = total_missed_lines <= threshold_missed_lines ? "meets_target" : "below_target";

  return {
    missed_lines_pct,
    service_level,
    threshold_missed_lines,
    status,
  };
}
