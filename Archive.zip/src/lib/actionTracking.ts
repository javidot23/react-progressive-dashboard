/**
 * Utility functions for tracking completed actions
 */

const ACTION_COUNT_STORAGE_KEY = "stratium:completedActionsCount";

/**
 * Gets the current count of completed actions from localStorage
 */
export const getCompletedActionsCount = (): number => {
  try {
    const count = localStorage.getItem(ACTION_COUNT_STORAGE_KEY);
    if (!count) return 0;
    const parsed = parseInt(count, 10);
    return isNaN(parsed) ? 0 : parsed;
  } catch (error) {
    console.error("Failed to get completed actions count:", error);
    return 0;
  }
};

/**
 * Increments the completed actions count and returns the new count
 */
export const incrementCompletedActionsCount = (): number => {
  try {
    const currentCount = getCompletedActionsCount();
    // If current count is invalid (NaN or 0), start from 0
    const validCount = isNaN(currentCount) ? 0 : currentCount;
    const newCount = validCount + 1;
    localStorage.setItem(ACTION_COUNT_STORAGE_KEY, newCount.toString());
    return newCount;
  } catch (error) {
    console.error("Failed to increment completed actions count:", error);
    return 0;
  }
};

/**
 * Resets the completed actions count (useful for fixing corrupted data)
 */
export const resetCompletedActionsCount = (): void => {
  try {
    localStorage.setItem(ACTION_COUNT_STORAGE_KEY, "0");
  } catch (error) {
    console.error("Failed to reset completed actions count:", error);
  }
};

// Returns true if count is a multiple of 10, or if it's the first action

export const shouldShowDecisionRationaleModal = (actionType: string, currentCount: number): boolean => {
  // Always show for "no_action_required"
  if (actionType === "no_action_required") {
    return true;
  }

  // For other actions, show every 10 actions (at 10, 20, 30, etc.)
  // For testing purposes, replace 10 with any number you want to test
  return currentCount > 0 && currentCount % 10 === 0;
};
