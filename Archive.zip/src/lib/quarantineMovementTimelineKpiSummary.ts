import type { QuarantineMovementTimelineDailyPoint, QuarantineMovementTimelineSummary } from "@/lib/apiServices";

export type QuarantineMovementTimelineKpiSource = "summary" | "daily";

export interface QuarantineTimelineKpiMetrics {
  sgtins: number;
  qty: number | null;
  amt: string | null;
}

export interface QuarantineMovementTimelineKpiDisplay {
  entered: QuarantineTimelineKpiMetrics;
  current: QuarantineTimelineKpiMetrics;
  returned: QuarantineTimelineKpiMetrics;
  inventory: QuarantineTimelineKpiMetrics;
  kpiReferenceDate: string;
  kpiSource: QuarantineMovementTimelineKpiSource;
}

function summaryCountsAllZero(summary: QuarantineMovementTimelineSummary): boolean {
  return (
    summary.entered_quarantine <= 0 &&
    summary.current_quarantine <= 0 &&
    summary.returned_sgtins <= 0 &&
    summary.inventory_sgtins <= 0
  );
}

export function buildQuarantineMovementTimelineKpiDisplay(
  summary: QuarantineMovementTimelineSummary,
  daily: QuarantineMovementTimelineDailyPoint[]
): QuarantineMovementTimelineKpiDisplay {
  const last = daily.length > 0 ? daily[daily.length - 1] : undefined;

  if (last && summaryCountsAllZero(summary)) {
    return {
      entered: {
        sgtins: last.cumulative_entered,
        qty: summary.entered_quarantine_qty,
        amt: summary.entered_quarantine_amt,
      },
      current: {
        sgtins: last.current_quarantine,
        qty: summary.current_quarantine_qty,
        amt: summary.current_quarantine_amt,
      },
      returned: {
        sgtins: last.cumulative_returned,
        qty: summary.returned_sgtins_qty,
        amt: summary.returned_sgtins_amt,
      },
      inventory: {
        sgtins: last.cumulative_to_inventory,
        qty: summary.inventory_sgtins_qty,
        amt: summary.inventory_sgtins_amt,
      },
      kpiReferenceDate: last.event_date,
      kpiSource: "daily",
    };
  }

  return {
    entered: {
      sgtins: summary.entered_quarantine,
      qty: summary.entered_quarantine_qty,
      amt: summary.entered_quarantine_amt,
    },
    current: {
      sgtins: summary.current_quarantine,
      qty: summary.current_quarantine_qty,
      amt: summary.current_quarantine_amt,
    },
    returned: {
      sgtins: summary.returned_sgtins,
      qty: summary.returned_sgtins_qty,
      amt: summary.returned_sgtins_amt,
    },
    inventory: {
      sgtins: summary.inventory_sgtins,
      qty: summary.inventory_sgtins_qty,
      amt: summary.inventory_sgtins_amt,
    },
    kpiReferenceDate: summary.date,
    kpiSource: "summary",
  };
}
