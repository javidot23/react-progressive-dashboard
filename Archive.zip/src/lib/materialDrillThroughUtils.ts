import type { MaterialRiskData } from "@/lib/apiServices";
import type { EnrichedRiskMetadata } from "@/hooks/useRiskModelDescriptions";
import type { MaterialWithIssues } from "@/lib/types";
import type { RiskLevel } from "@/lib/types";
import type { IssueApiData } from "@/services/issueService";

import { NavigateFunction } from "react-router-dom";
import { ROUTES } from "@/constants/routes";
import type { IssueNote } from "@/services/issueNotesService";

/** Query param passed on first navigation so material APIs can load before issue fetch completes. */
export const MATERIAL_DRILL_MATERIAL_ID_QUERY_KEY = "materialId";

export interface MaterialDrillThroughIssueContext {
  materialId?: number;
  /** Open issue primary key (`IssueData.id`) — ties Notes on drill-through to the same issue row as React cards */
  id?: number;
  mat_nbr?: string;
  productName?: string;
  riskLevel?: number;
  dollarsAtRisk?: number;
  drivingRisk?: string;
  drivingRiskRaw?: string;
  isNewIssue?: boolean;
  actionStatus?: string;
  lastNote?: IssueNote | null;
  notesCount?: number;
  ndc?: string;
  vendorNbr?: string;
  issueNbr?: string;
  potentialActions?: unknown[];
  actions?: unknown[];
  /** Where the user came from — drives the drill-through back button. */
  from?: "issue" | "feed";
  /** The issue drill-through to return to when `from === "issue"`. */
  originIssueId?: number;
}

export function navigateToMaterialDrillThrough(navigate: NavigateFunction, issue: MaterialDrillThroughIssueContext): void {
  const issueId = issue.id;
  if (!issueId) return;

  const materialQuery =
    issue.materialId != null && issue.materialId > 0 ? `?${MATERIAL_DRILL_MATERIAL_ID_QUERY_KEY}=${issue.materialId}` : "";

  navigate(`${ROUTES.REACT_MATERIAL}/${issueId}${materialQuery}`, {
    state: {
      materialId: issue.materialId,
      matNbr: issue.mat_nbr,
      productName: issue.productName,
      riskLevel: issue.riskLevel,
      dollarsAtRisk: issue.dollarsAtRisk,
      drivingRisk: issue.drivingRiskRaw ?? issue.drivingRisk,
      isNewIssue: issue.isNewIssue,
      actionStatus: issue.actionStatus,
      issueId: issue.id,
      issueNbr: issue.issueNbr,
      potentialActions: issue.potentialActions,
      actions: issue.actions,
      lastNote: issue.lastNote ?? null,
      notesCount: issue.notesCount ?? 0,
      ndc: issue.ndc,
      vendorNbr: issue.vendorNbr,
      from: issue.from,
      originIssueId: issue.originIssueId,
    } satisfies MaterialDrillThroughLocationState,
  });
}

export interface MaterialDrillThroughLocationState {
  materialId?: number;
  matNbr?: string;
  productName?: string;
  riskLevel?: number;
  dollarsAtRisk?: number;
  drivingRisk?: string;
  isNewIssue?: boolean;
  actionStatus?: string;
  issueId?: number;
  issueNbr?: string;
  potentialActions?: unknown[];
  actions?: unknown[];
  lastNote?: IssueNote | null;
  notesCount?: number;
  ndc?: string;
  vendorNbr?: string;
  from?: "issue" | "feed";
  originIssueId?: number;
}

export interface DrivingRiskTimelineItem {
  id: number;
  /** Primary sort key — status_date, then updated_at / created_at */
  date: string;
  riskTypeLabel: string;
  description: string;
  riskLevel: RiskLevel;
  riskRating: number;
  /** Raw ISO date string for status_date when present */
  statusDate: string | null;
}

/** Matches React issue cards: issue is "new" when created on the current local calendar day. */
export function isIssueCreatedToday(createdAt: string | undefined): boolean {
  if (!createdAt) return false;
  const today = new Date();
  const issueDate = new Date(createdAt);
  return (
    today.getFullYear() === issueDate.getFullYear() &&
    today.getMonth() === issueDate.getMonth() &&
    today.getDate() === issueDate.getDate()
  );
}

export function isIssueActionResolved(actions: unknown[] | null | undefined, fallbackReviewed = false): boolean {
  return Boolean(actions?.length) || fallbackReviewed;
}

export function getTimelineRiskLevel(riskRating: number): RiskLevel {
  if (riskRating >= 0.9) return "Critical";
  if (riskRating >= 0.8) return "High";
  if (riskRating >= 0.6) return "Medium";
  return "Low";
}

const RISK_LEVEL_STYLES: Record<RiskLevel, { bg: string; text: string; border: string }> = {
  Critical: { bg: "bg-red-100", text: "text-red-800", border: "border-red-300" },
  High: { bg: "bg-red-50", text: "text-red-700", border: "border-red-200" },
  Medium: { bg: "bg-yellow-100", text: "text-yellow-800", border: "border-yellow-300" },
  Low: { bg: "bg-green-100", text: "text-green-800", border: "border-green-300" },
  Watch: { bg: "bg-gray-100", text: "text-gray-700", border: "border-gray-300" },
};

export function getTimelineRiskLevelStyles(level: RiskLevel) {
  return RISK_LEVEL_STYLES[level] ?? RISK_LEVEL_STYLES.Watch;
}

/**
 * One timeline entry per material-risk API row. Labels/descriptions match
 * MaterialRiskDriverModal (`enrichRiskData` → display_name, risk_description).
 */
export function buildDrivingRiskTimeline(riskData: Array<MaterialRiskData & EnrichedRiskMetadata>): DrivingRiskTimelineItem[] {
  return riskData
    .map(item => {
      const dateSource = item.status_date ?? item.updated_at ?? item.created_at;
      const statusDate = item.status_date ?? null;

      return {
        id: item.id,
        date: dateSource,
        riskTypeLabel: item.display_name || item.original_risk_type || item.risk_type,
        description: item.risk_description || "",
        riskLevel: getTimelineRiskLevel(item.risk_rating),
        riskRating: item.risk_rating,
        statusDate,
      };
    })
    .sort((a, b) => {
      const tb = new Date(b.date.includes("T") ? b.date : `${b.date}T12:00:00`).getTime();
      const ta = new Date(a.date.includes("T") ? a.date : `${a.date}T12:00:00`).getTime();
      if (tb !== ta) return tb - ta;
      return b.riskRating - a.riskRating;
    });
}

export function formatDrillThroughDate(iso: string): string {
  const d = new Date(iso.includes("T") ? iso : `${iso}T12:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

/** e.g. "Apr 10" for timeline labels */
export function formatTimelineShortDate(iso: string): string {
  const d = new Date(iso.includes("T") ? iso : `${iso}T12:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export function formatChartDate(iso: string): string {
  const d = new Date(iso.includes("T") ? iso : `${iso}T12:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/** Maps issue list API row to MaterialWithIssues for ActionButtonGroup (same as React IssueCard). */
export function issueToMaterialWithIssues(
  issue: IssueApiData,
  materialId: number,
  matNbr: string,
  riskRating: number,
  drivingRiskRaw: string | undefined,
  dollarsAtRisk: number
): MaterialWithIssues {
  const vendor = issue.material?.vendor;
  return {
    id: materialId || issue.material?.id || issue.id,
    mat_nbr: matNbr || issue.material?.mat_nbr,
    name: issue.material?.name ?? matNbr,
    risk_rating: riskRating,
    driving_risk: drivingRiskRaw ?? issue.material?.driving_risk ?? "",
    dollars_at_risk: dollarsAtRisk,
    open_issues: [
      {
        id: issue.id,
        actions: issue.actions ?? [],
        potential_actions: issue.potential_actions ?? [],
        issue_id: String(issue.id),
        issue_nbr: issue.issue_nbr,
        status: issue.status ?? "open",
        description: issue.description ?? "",
        start_date: issue.start_date ?? "",
        act_required_date: issue.act_required_date ?? "",
        material: materialId,
        vendor: vendor as MaterialWithIssues["vendor"],
        created_at: issue.created_at ?? "",
        updated_at: issue.updated_at ?? "",
        action_status: issue.actions?.length ? "Reviewed" : "Not Reviewed",
      },
    ],
    vendor: vendor as MaterialWithIssues["vendor"],
  } as unknown as MaterialWithIssues;
}

export function buildNavIssueFallback(
  navIssueId: number,
  navState: MaterialDrillThroughLocationState,
  materialId: number,
  matNbr: string,
  riskRating: number,
  dollarsAtRisk: number,
  materialVendor?: { id: number; name: string; driving_risk?: string }
): IssueApiData {
  return {
    id: navIssueId,
    issue_id: String(navIssueId),
    issue_nbr: navState.issueNbr ?? "",
    status: "OPEN",
    description: "",
    start_date: "",
    act_required_date: "",
    created_at: "",
    updated_at: "",
    risk_adjusted_value: 0,
    actions: (navState.actions as IssueApiData["actions"]) ?? [],
    potential_actions: (navState.potentialActions as IssueApiData["potential_actions"]) ?? [],
    material: {
      id: materialId,
      ndc: navState.ndc ?? "",
      name: navState.productName ?? "",
      mat_nbr: matNbr,
      ean_n4_nbr_11: "",
      risk_rating: riskRating,
      driving_risk: navState.drivingRisk ?? "",
      dollars_at_risk: dollarsAtRisk,
      vendor: {
        id: materialVendor?.id ?? 0,
        name: materialVendor?.name ?? "",
        driving_risk: materialVendor?.driving_risk ?? navState.drivingRisk ?? "",
      },
    },
    last_note: navState.lastNote ?? null,
    notes_count: navState.notesCount ?? 0,
  };
}
