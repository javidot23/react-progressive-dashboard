# Toast notifications

Centralized toast UI for success, error, warning, and info messages. Rendering is wired once via [`ToastViewport`](../components/molecules/ToastViewport.tsx) in [`App.tsx`](../App.tsx); feature code triggers toasts imperatively—no duplicate providers per route.

## API

Import the imperative helpers from `@/lib/toast`:

```ts
import { toast } from "@/lib/toast";
```

| Method                         | Behavior                                                           |
| ------------------------------ | ------------------------------------------------------------------ |
| `toast.success(opts)`          | Green success variant                                              |
| `toast.error(opts)`            | Danger / error variant (assertive `aria-live`)                     |
| `toast.info(opts)`             | Informational variant (neutral / highlight surface)                |
| `toast.warning(opts)`          | Warning variant (assertive `aria-live`)                            |
| `toast.dismiss(id?)`           | Remove one toast by id; omit id to dismiss all                     |
| `toast.promise(promise, msgs)` | Optional loading info toast (`duration: 0`), then success or error |

### Options (`ToastInput`)

Same shape as a stored toast omitting `variant` / `id` (unless you supply an explicit id):

- `title` — required headline
- `description` — optional body text
- `duration` — ms until auto-dismiss; default **4500**. Use **`0`** for sticky until manual dismiss or `toast.promise` loading rows.
- `action` — optional `{ label, onClick }`; runs handler then dismisses the toast.

### Examples

```ts
import { toast } from "@/lib/toast";
import { getErrorMessage } from "@/lib/getErrorMessage";

toast.success({ title: "Saved" });

toast.error({
  title: "Couldn't apply action",
  description: getErrorMessage(error),
});

toast.warning({ title: "Connection unstable", description: "Retrying shortly…" });

toast.info({
  title: "Undo available",
  action: { label: "Undo", onClick: undo },
});

const id = toast.info({ title: "Working…", duration: 0 });
// later:
toast.dismiss(id);

toast.dismiss(); // clears the whole queue

await toast.promise(saveAction(), {
  loading: "Saving…",
  success: data => `Saved ${data}`,
  error: err => `Save failed: ${getErrorMessage(err)}`,
});
```

### Hook alias

[`useToast`](../hooks/useToast.ts) returns `{ toast }` for ergonomics or test doubles:

```ts
const { toast } = useToast();
toast.success({ title: "Done" });
```

## Behavior notes

- **Queue cap:** [`MAX_TOASTS`](../stores/toastStore.ts) (currently `5`). Oldest toasts drop when enqueueing beyond the limit.
- **Pause on hover/focus:** Auto-dismiss countdown pauses while the pointer rests on a toast or while focus stays inside it; it resumes after leave/blur outside the toast.
- **Keyboard:** Focus can move into a toast (`tabIndex={-1}` on the toast root). **Escape** dismisses the toast when handled on that root subtree.
- **Motion:** Existing transitions respect `motion-reduce:transition-none`.

## Accessibility

- Errors and warnings use `role="alert"` and `aria-live="assertive"`.
- Success and info use `role="status"` and `aria-live="polite"`.
- Icons are decorative (`aria-hidden`); dismiss control has `"Dismiss notification"`.
- The viewport container is `role="region"` with `aria-label="Notifications"`.

## Design system styling

Toast surfaces intentionally use **soft semantic backgrounds** (`background-*-secondary` where applicable / highlight-secondary for info) so they remain distinct from saturated badge or banner treatments. Typography and spacing rely on CDS tokens wired through [`tailwind.config.js`](../../tailwind.config.js).

| Variant   | Container classes (semantic intent)                                                                            |
| --------- | -------------------------------------------------------------------------------------------------------------- |
| `success` | `border-border-success` `bg-background-success-secondary` `text-text-success` `shadow-status-success`          |
| `error`   | `border-border-danger` `bg-background-danger-secondary` `text-text-danger` `shadow-status-error`               |
| `warning` | `border-border-warning` `bg-background-warning-secondary` `text-text-warning` `shadow-status-warning`          |
| `info`    | `border-border-brand-secondary` `bg-background-highlight-secondary` `text-text-highlight` `shadow-status-info` |

Secondary actions reuse the semantic text accent per variant (`text-text-success`, `text-text-danger`, etc.). Interactive chrome follows UI tokens (`focus-visible:ring-ui-border-focus`, `hover:bg-ui-background-muted` on the dismiss control).

## Wiring mutations (TanStack Query v5)

Global success/error toasts for mutations are wired via `MutationCache` on the shared [`queryClient`](./queryClient.ts).

### Declarative `meta` on `useMutation`

Typing is augmented in `queryClient.ts` (`Register.mutationMeta`):

```ts
useMutation({
  mutationFn: saveThing,
  meta: {
    successMessage: "Saved",
    errorMessage: "Couldn't save",
    silent: true,
  },
});
```

`successMessage` and `errorMessage` may be strings or `(data, variables) => string` / `(error, variables) => string`.

- If `meta` is missing or `silent: true`, no global toast runs for that mutation lifecycle.
- Success: only `toast.success({ title })` when `successMessage` resolves to a non-empty string (no default success title).
- Errors: `toast.error({ title, description })` uses `description: getErrorMessage(error)` from [`getErrorMessage`](./getErrorMessage.ts). Missing `errorMessage` uses title `"Something went wrong"`.

### Opt-out hooks

Some surfaces already show inline errors or success strings; those hooks expose a **`{ silent?: boolean }`** option so callers keep old UX without doubling toasts:

- [`useCreateFeedbackMutation`](../hooks/queries/useFeedbackMutations.ts) — [`FeedbackFAB`](../components/molecules/FeedbackFAB.tsx) passes `{ silent: true }`.
- [`useCreateIssueNoteMutation` / `useUpdateIssueNoteMutation` / `useDeleteIssueNoteMutation`](../hooks/queries/useIssueNotesMutations.ts) — [`IssueNotesPopover`](../components/molecules/IssueNotesPopover.tsx) passes `{ silent: true }` on create/update/delete.

### Imperative grouping (action + rationale)

[`useActionFlow`](../hooks/useActionFlow.ts) and [`ProductSubstitutionAnalysis`](../pages/ProductSubstitutionAnalysis.tsx) combine **POST /action/create/** with optional **PATCH decision rationale** into a single success toast when both run in one flow.

### Writes outside `useMutation`

Settings and profile PATCH/PUT helpers call `toast.success` / `toast.error` at the callsite—for example thresholds in [`ManageThresholds`](../pages/profile/ManageThresholds.tsx) and goal editors in overview cards (`ServiceLevelCard`, `ValueAtRiskTrendCard`, `UnfilledPercentageTrendCard`).
