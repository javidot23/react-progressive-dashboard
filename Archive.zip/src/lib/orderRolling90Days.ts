/** Inclusive calendar-day window of exactly 90 days ending today (local). */
export function getRolling90DayInclusiveApiParams(): { date_from: string; date_to: string } {
  const end = new Date();
  end.setHours(0, 0, 0, 0);
  const start = new Date(end);
  start.setDate(start.getDate() - 89);
  const fmt = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  return { date_from: fmt(start), date_to: fmt(end) };
}
