export const CS_SALES_CHANGE_TRACKING_PAGINATION_RESET = {
  materialOffset: 0,
  customerOffset: 0,
} as const;
