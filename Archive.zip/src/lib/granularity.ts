import { getGcnLabel, getGcnPlantLabel } from "@/lib/gcnLabels";
import { formatCurrencyCompact, getMaterialStatusDescription } from "@/lib/utils";
import type {
  GranularityType,
  IssueAtGranularityApiData,
  GranularityIssueView,
} from "@/types/granularityIssue";

const RISK_PERCENTAGE_MULTIPLIER = 100;
const CRITICAL_RISK_THRESHOLD = 0.7;
const EMPTY_RISK_EXPOSURE = "- / -";
const DEFAULT_MATERIAL_TYPE = "Material";

/** Display label for each grain (matches the design's level-filter labels). */
const STATIC_GRANULARITY_LABELS: Record<Exclude<GranularityType, "gcn" | "gcn_plant">, string> = {
  material: "Material",
  material_plant: "Material·Plant",
  ndc: "NDC",
  fei: "Facility·FEI",
  hicl: "HICL",
  unknown: "Issue",
};

/** Segmented level-filter options → `granularity_type` query value ("" = All Levels). */
export function getGranularityLevelOptions(): { key: string; label: string; value: string }[] {
  return [
    { key: "all", label: "All Levels", value: "" },
    { key: "material", label: "Material", value: "material" },
    { key: "ndc", label: "NDC", value: "ndc" },
    { key: "gcn", label: getGcnLabel(), value: "gcn" },
    { key: "gcn_plant", label: getGcnPlantLabel(), value: "gcn_plant" },
    { key: "fei", label: "Facility·FEI", value: "fei" },
    { key: "hicl", label: "HICL", value: "hicl" },
  ];
}

export function getGranularityLabel(type: GranularityType | undefined): string {
  if (type === "gcn") return getGcnLabel();
  if (type === "gcn_plant") return getGcnPlantLabel();
  return STATIC_GRANULARITY_LABELS[type ?? "unknown"] ?? STATIC_GRANULARITY_LABELS.unknown;
}

/** The populated grain identifier column for a given issue (mono value shown in the LevelChip). */
export function getGranularityValue(api: IssueAtGranularityApiData): string {
  switch (api.granularity_type) {
    case "material":
    case "material_plant": {
      const mat = api.material?.mat_nbr ?? "";
      return api.plant ? `${mat}:${api.plant}` : mat;
    }
    case "gcn":
      return api.fdb_gcn_seq_nbr ?? "";
    case "gcn_plant":
      return api.fdb_gcn_seq_nbr ? `${api.fdb_gcn_seq_nbr}:${api.plant ?? ""}` : "";
    case "ndc":
      return api.ndc ?? "";
    case "fei":
      return api.fei_number ?? "";
    case "hicl":
      return api.hicl ?? "";
    default:
      return "";
  }
}

/**
 * Maps a `GET /issue/all/` row to the shared feed view-model. For a material
 * grain, nested `material` fields populate the single-material layout; for
 * aggregated grains the effective (grain-aware) metrics drive the card.
 */
export function mapGranularityIssue(
  api: IssueAtGranularityApiData,
  getEnrichedMetadata: (riskType: string) => { display_name: string }
): GranularityIssueView {
  const material = api.material;
  const impactedCount = api.impacted_material_count ?? (material ? 1 : 0);
  const isSingleMaterial =
    impactedCount === 1 && (api.granularity_type === "material" || api.granularity_type === "material_plant");

  const effectiveRiskRating = api.effective_risk_rating ?? material?.risk_rating ?? 0;
  const riskLevel = Math.round(effectiveRiskRating * RISK_PERCENTAGE_MULTIPLIER);
  const effectiveDollarsAtRisk = api.effective_dollars_at_risk ?? material?.dollars_at_risk ?? 0;
  const riskAdjusted = api.effective_risk_adjusted_value ?? effectiveRiskRating * effectiveDollarsAtRisk;

  const riskExposure = effectiveDollarsAtRisk
    ? `${formatCurrencyCompact(Math.round(riskAdjusted))} / ${formatCurrencyCompact(effectiveDollarsAtRisk, true)}`
    : EMPTY_RISK_EXPOSURE;

  const drivingRiskRaw = material?.driving_risk ?? api.driving_event?.type ?? "";
  const drivingRisk = drivingRiskRaw ? getEnrichedMetadata(drivingRiskRaw).display_name || drivingRiskRaw : "-";

  const createdSource = api.date_identified ?? api.created_at ?? api.start_date ?? "";
  const createdAt = createdSource
    ? new Date(createdSource).toLocaleDateString("en-US", { day: "2-digit", month: "short", year: "numeric" })
    : "-";

  const today = new Date();
  const issueDate = createdSource ? new Date(createdSource) : null;
  const isNewIssue = Boolean(
    issueDate &&
      today.getFullYear() === issueDate.getFullYear() &&
      today.getMonth() === issueDate.getMonth() &&
      today.getDate() === issueDate.getDate()
  );

  const xplantMatStat = material?.xplant_mat_stat ?? undefined;

  return {
    id: api.id,
    issueNbr: api.issue_nbr,

    granularityType: api.granularity_type,
    granularityLabel: getGranularityLabel(api.granularity_type),
    granularityValue: getGranularityValue(api),
    isSingleMaterial,
    impactedMaterialCount: impactedCount,

    riskLevel,
    effectiveRiskRating,
    effectiveDollarsAtRisk,
    riskExposure,

    drivingRisk,
    drivingRiskRaw,
    drivingEvent: api.driving_event,

    status: api.status,
    group: api.group,
    persona: api.persona,
    dateIdentified: api.date_identified,
    createdAt,
    isNewIssue,
    hasActions: api.has_actions ?? Boolean(api.actions?.length),
    actionStatus: (api.has_actions ?? Boolean(api.actions?.length)) ? "Reviewed" : "Not Reviewed",
    isCritical: effectiveRiskRating > CRITICAL_RISK_THRESHOLD,
    ...(api.actions ? { actions: api.actions } : {}),
    ...(api.potential_actions ? { potentialActions: api.potential_actions } : {}),
    lastNote: api.last_note,
    notesCount: api.notes_count,

    // Material-grain detail (falls back gracefully for aggregated grains)
    productName: material?.name ?? api.driving_event?.type ?? getGranularityLabel(api.granularity_type),
    material: DEFAULT_MATERIAL_TYPE,
    mat_nbr: material?.mat_nbr ?? "",
    ndc: material?.ndc ?? api.ndc ?? "",
    ean: material?.ean_n4_nbr_11 ?? "",
    materialId: material?.id,
    dollarsAtRisk: effectiveDollarsAtRisk,
    vendorName: material?.vendor?.name,
    vendorNbr: material?.vendor?.vendor_nbr ?? undefined,
    vendorId: material?.vendor?.id,
    xplantMatStat,
    xplantMatStatDesc: getMaterialStatusDescription(xplantMatStat),
  };
}
