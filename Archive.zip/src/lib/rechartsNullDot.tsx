import type { ReactElement } from "react";

/**
 * Recharts 3 Line `dot` / `activeDot` renderers must return an SVG element, not `null`.
 */
export function rechartsNullDot(cx?: number, cy?: number): ReactElement<SVGElement> {
  const x = cx ?? 0;
  const y = cy ?? 0;
  return <circle cx={x} cy={y} r={0} fill="none" stroke="none" pointerEvents="none" aria-hidden />;
}
