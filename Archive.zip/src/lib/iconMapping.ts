// Icon mapping from existing SVG files to CDS icon names
export const ICON_MAPPING: Record<string, string> = {
  // Alert and warning icons
  "alert-icon.svg": "alert-circle",
  "alert-triangle.svg": "alert-triangle",
  "alarm-bell.svg": "alarm-bell",

  // Check and success icons
  "check-shield.svg": "check-shield",
  "target-correct.svg": "target-correct",

  // Task and list icons
  "task-list-disable.svg": "task-list-disable",
  "task-list-pen.svg": "task-list-pen",

  // Delivery and shipping icons
  "delivery-truck.svg": "delivery-truck",
  "shipment-upload.svg": "shipment-upload",

  // Financial icons
  "discount-dollar-dash.svg": "discount-dollar-dash",

  // Communication icons
  "megaphone.svg": "megaphone",
  "messages-bubble-square-star.svg": "messages-bubble-square-star",

  // User and people icons
  "multiple-users-1.svg": "multiple-users-1",

  // File and document icons
  "common-file-text-edit.svg": "common-file-text-edit",

  // Shopping and commerce icons
  "shopping-cart-empty.svg": "shopping-cart-empty",

  // Warehouse and storage icons
  "warehouse-packages.svg": "warehouse-packages",

  // Pin and location icons
  "pin.svg": "pin",

  // Pill and medication icons
  "pill.svg": "pill",

  // Custom icons that might not have direct CDS equivalents
  "cencora-logo.svg": "cencora-logo", // This might need to remain as SVG
  "market_score.svg": "market_score", // This might need to remain as SVG
  "potential_substituties.svg": "potential_substituties", // This might need to remain as SVG
  "days_on_hand.svg": "days_on_hand", // This might need to remain as SVG
  "mwidcs.svg": "mwidcs", // This might need to remain as SVG
};

// CDS library mapping for different icon types
export const LIBRARY_MAPPING: Record<string, "cds-ui" | "cds-ui-regular" | "cds-ui-semibold" | "cds-expressive"> = {
  // UI icons (default)
  "alert-circle": "cds-ui",
  "alert-triangle": "cds-ui",
  "alarm-bell": "cds-ui",
  "check-shield": "cds-ui",
  "target-correct": "cds-ui",
  "task-list-disable": "cds-ui",
  "task-list-pen": "cds-ui",
  "delivery-truck": "cds-ui",
  "shipment-upload": "cds-ui",
  "discount-dollar-dash": "cds-ui",
  megaphone: "cds-ui",
  "messages-bubble-square-star": "cds-ui",
  "multiple-users-1": "cds-ui",
  "common-file-text-edit": "cds-ui",
  "shopping-cart-empty": "cds-ui",
  "warehouse-packages": "cds-ui",
  pin: "cds-ui",
  pill: "cds-ui",

  // Expressive icons for larger, more prominent use
  calendar: "cds-expressive",
  "information-circle": "cds-expressive",
  search: "cds-expressive",
  star: "cds-expressive",
};
