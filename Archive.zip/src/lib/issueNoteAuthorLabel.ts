import type { IssueNote } from "@/services/issueNotesService";

const UUID_LIKE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function isUuidLike(s: string): boolean {
  return UUID_LIKE.test(s.trim());
}

export function issueNoteAuthorLabel(note: IssueNote): string {
  const u = note.user_data;

  const single = u?.name?.trim();
  if (single && !isUuidLike(single)) return single;

  const legacy = [u?.first_name, u?.last_name]
    .map(x => (typeof x === "string" ? x.trim() : ""))
    .filter(Boolean)
    .join(" ");
  if (legacy) return legacy;

  const email = u?.email?.trim();
  if (email) {
    const at = email.indexOf("@");
    return at > 0 ? email.slice(0, at) : email;
  }

  const uid = note.user_id?.trim();
  if (uid && !isUuidLike(uid)) return uid;

  return "Unknown";
}
