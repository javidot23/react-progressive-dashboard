import { granularityIssueAppliedFiltersConfig } from "@/lib/filterConfigs";

export type GranularityIssueFilters = typeof granularityIssueAppliedFiltersConfig.defaultFilters;

const DEFAULT_FILTERS: GranularityIssueFilters = {
  ...granularityIssueAppliedFiltersConfig.defaultFilters,
};

/** Map legacy /react bookmark params (material-level keys) to grain-aware equivalents. */
export const LEGACY_KEY_MIGRATION: Record<string, string> = {
  risk_rating_min: "effective_risk_rating_min",
  risk_rating_max: "effective_risk_rating_max",
  risk_adjusted_value_min: "effective_risk_adjusted_value_min",
  risk_adjusted_value_max: "effective_risk_adjusted_value_max",
  dollars_at_risk_min: "effective_dollars_at_risk_min",
  dollars_at_risk_max: "effective_dollars_at_risk_max",
};

function isDefaultValue(key: string, value: unknown): boolean {
  if (!(key in DEFAULT_FILTERS)) return false;
  return value === (DEFAULT_FILTERS as Record<string, unknown>)[key];
}

export const serializeGranularityIssueFilters = (
  filters: GranularityIssueFilters,
  preserveGlobalFilters: boolean = true
): URLSearchParams => {
  const params = new URLSearchParams();

  if (preserveGlobalFilters && typeof window !== "undefined") {
    const currentParams = new URLSearchParams(window.location.search);
    currentParams.forEach((value, key) => {
      if (key.startsWith("gf_")) {
        params.append(key, value);
      }
    });
  }

  Object.entries(filters).forEach(([key, value]) => {
    if (value === null || value === undefined || value === "") return;
    if (isDefaultValue(key, value)) return;
    params.set(key, value.toString());
  });

  return params;
};

export const deserializeGranularityIssueFilters = (searchParams: URLSearchParams): GranularityIssueFilters => {
  const filters: GranularityIssueFilters = { ...DEFAULT_FILTERS };

  for (const [key, value] of searchParams.entries()) {
    if (key.startsWith("gf_")) continue;

    const targetKey = LEGACY_KEY_MIGRATION[key] ?? key;
    if (!(targetKey in filters)) continue;

    // Skip legacy key when the effective key is already present in the URL.
    const migratedKey = LEGACY_KEY_MIGRATION[key];
    if (migratedKey && searchParams.has(migratedKey)) {
      continue;
    }

    if (targetKey === "ordering" || targetKey === "group") {
      (filters as Record<string, unknown>)[targetKey] = value;
    } else if (targetKey === "has_no_actions") {
      (filters as Record<string, unknown>)[targetKey] = value === "true";
    } else {
      const numValue = Number(value);
      if (!isNaN(numValue)) {
        (filters as Record<string, unknown>)[targetKey] = numValue;
      }
    }
  }

  return filters;
};

/** URL keys owned by granularity issue filters (current + legacy aliases). */
export const GRANULARITY_ISSUE_FILTER_URL_KEYS = [
  ...Object.keys(DEFAULT_FILTERS),
  ...Object.keys(LEGACY_KEY_MIGRATION),
] as const;

/** Merge serialized filters into existing params, preserving level/view/gf_* and other non-filter keys. */
export const mergeGranularityIssueFiltersIntoParams = (
  currentParams: URLSearchParams,
  filters: GranularityIssueFilters
): URLSearchParams => {
  const params = new URLSearchParams(currentParams);
  for (const key of GRANULARITY_ISSUE_FILTER_URL_KEYS) {
    params.delete(key);
  }
  const filterParams = serializeGranularityIssueFilters(filters, false);
  filterParams.forEach((value, key) => params.set(key, value));
  return params;
};
