/**
 * Utility functions for Scorecard filter percentage conversions
 *
 * Database stores values as normalized decimals (0.0-1.0)
 * UI displays values as percentages (0-100%)
 */

/**
 * Convert decimal value (0.0-1.0) to percentage (0-100)
 * @param decimal - Decimal value between 0.0 and 1.0
 * @returns Percentage value between 0 and 100
 */
export const decimalToPercentage = (decimal: number): number => {
  return Math.round(decimal * 100 * 100) / 100; // Round to 2 decimal places
};

/**
 * Convert percentage value (0-100) to decimal (0.0-1.0)
 * @param percentage - Percentage value between 0 and 100
 * @returns Decimal value between 0.0 and 1.0
 */
export const percentageToDecimal = (percentage: number): number => {
  return Math.round(percentage * 100) / 10000; // Round to 4 decimal places for precision
};

/**
 * Format percentage for display
 * @param percentage - Percentage value
 * @returns Formatted percentage string with % symbol
 */
export const formatPercentage = (percentage: number): string => {
  return `${percentage.toFixed(2)}%`;
};

/**
 * Convert filter values from database format (decimals) to UI format (percentages)
 * @param filters - Filters object with decimal values
 * @returns Filters object with percentage values for display
 */
export const convertFiltersToUI = (filters: Record<string, any>): Record<string, any> => {
  const uiFilters = { ...filters };

  // Fields that need percentage conversion
  const percentageFields = [
    'overall_score_min',
    'overall_score_max',
    'otif_percentage_min',
    'otif_percentage_max',
    'inbound_fill_rate_min',
    'inbound_fill_rate_max',
    'asn_timeliness_min',
    'asn_timeliness_max',
    'asn_essential_min',
    'asn_essential_max',
    'product_damages_rate_min',
    'product_damages_rate_max',
  ];

  percentageFields.forEach(field => {
    if (uiFilters[field] !== undefined && uiFilters[field] !== null) {
      uiFilters[field] = decimalToPercentage(uiFilters[field]);
    }
  });

  return uiFilters;
};

/**
 * Convert filter values from UI format (percentages) to database format (decimals)
 * @param filters - Filters object with percentage values
 * @returns Filters object with decimal values for API
 */
export const convertFiltersToAPI = (filters: Record<string, any>): Record<string, any> => {
  const apiFilters = { ...filters };

  // Fields that need decimal conversion
  const percentageFields = [
    'overall_score_min',
    'overall_score_max',
    'otif_percentage_min',
    'otif_percentage_max',
    'inbound_fill_rate_min',
    'inbound_fill_rate_max',
    'asn_timeliness_min',
    'asn_timeliness_max',
    'asn_essential_min',
    'asn_essential_max',
    'product_damages_rate_min',
    'product_damages_rate_max',
  ];

  percentageFields.forEach(field => {
    if (apiFilters[field] !== undefined && apiFilters[field] !== null) {
      apiFilters[field] = percentageToDecimal(apiFilters[field]);
    }
  });

  return apiFilters;
};

/**
 * Check if a field requires percentage conversion
 * @param fieldName - Name of the filter field
 * @returns True if the field should be converted between decimal and percentage
 */
export const isPercentageField = (fieldName: string): boolean => {
  const percentageFields = [
    'overall_score_min',
    'overall_score_max',
    'otif_percentage_min',
    'otif_percentage_max',
    'inbound_fill_rate_min',
    'inbound_fill_rate_max',
    'asn_timeliness_min',
    'asn_timeliness_max',
    'asn_essential_min',
    'asn_essential_max',
    'product_damages_rate_min',
    'product_damages_rate_max',
  ];

  return percentageFields.includes(fieldName);
};

/**
 * Get the display value for a filter field
 * @param fieldName - Name of the filter field
 * @param value - Raw value from filters
 * @returns Formatted display value
 */
export const getFilterDisplayValue = (fieldName: string, value: any): string => {
  if (value === undefined || value === null) return '';

  if (isPercentageField(fieldName)) {
    return formatPercentage(decimalToPercentage(value));
  }

  return value.toString();
};
