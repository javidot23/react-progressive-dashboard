import { useToastStore, type ToastItem, type ToastVariant } from "@/stores/toastStore";

const DEFAULT_DURATION_MS = 4500;

function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `toast_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
}

export type ToastInput = Omit<ToastItem, "id" | "variant"> & {
  id?: string;
  duration?: number;
};

function push(variant: ToastVariant) {
  return (opts: ToastInput): string => {
    const { id: explicitId, duration = DEFAULT_DURATION_MS, ...rest } = opts;
    const id = explicitId ?? newId();
    const item: ToastItem = {
      id,
      variant,
      duration,
      ...rest,
    };
    useToastStore.getState().addToast(item);
    return id;
  };
}

export const toast = {
  success: push("success"),
  error: push("error"),
  info: push("info"),
  warning: push("warning"),
  dismiss(id?: string) {
    if (id) {
      useToastStore.getState().dismiss(id);
    } else {
      useToastStore.getState().dismissAll();
    }
  },
  async promise<T>(
    promise: Promise<T>,
    messages: {
      loading?: string;
      success: string | ((data: T) => string);
      error: string | ((err: unknown) => string);
    }
  ): Promise<T> {
    const loadingId = messages.loading ? push("info")({ title: messages.loading, duration: 0 }) : undefined;

    try {
      const data = await promise;
      if (loadingId) useToastStore.getState().dismiss(loadingId);
      const text = typeof messages.success === "function" ? messages.success(data) : messages.success;
      push("success")({ title: text });
      return data;
    } catch (err: unknown) {
      if (loadingId) useToastStore.getState().dismiss(loadingId);
      const text = typeof messages.error === "function" ? messages.error(err) : messages.error;
      push("error")({ title: text });
      throw err;
    }
  },
};
