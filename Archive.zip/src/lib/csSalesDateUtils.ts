/**
 * Date computation utilities for CS Sales filters.
 *
 * Current tab: Last week, Week to date, Month to date, Last month.
 * Historical tab: Last 3/6/12 Months (API uses end_year, end_month, months).
 *
 * MTD comparison: e.g. March 17, 2026
 *   - Current period: March 1 - March 17
 *   - Previous period: February 1 - February 17 (same calendar day, previous month)
 */

export interface DateRange {
  date_from: string;
  date_to: string;
}

export interface CurrentPeriodWithComparison {
  date_from: string;
  date_to: string;
  previous_date_from: string;
  previous_date_to: string;
}

export interface HistoricalApiParams {
  end_year: number;
  end_month: number;
  months: number;
}

export interface CurrentApiParams {
  current_start_date: string;
  current_end_date: string;
  previous_start_date: string;
  previous_end_date: string;
}

function toDateString(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/** Get Monday of the week containing the given date (week starts Monday). */
function getMondayOfWeek(d: Date): Date {
  const result = new Date(d);
  const day = result.getDay();
  const diff = day === 0 ? -6 : 1 - day; // Adjust for Sunday = 0
  result.setDate(result.getDate() + diff);
  return result;
}

/**
 * Get API params for Historical tab (end_year, end_month, months).
 * Anchors to the most recent **complete** calendar month (not the in-progress month).
 */
export function getHistoricalApiParams(
  period: string,
  refDate: Date = new Date()
): HistoricalApiParams | null {
  const monthsMap: Record<string, number> = {
    "Last 3 months": 3,
    "Last 6 months": 6,
    "Last 12 months": 12,
  };
  const months = monthsMap[period];
  if (months == null) return null;

  const lastComplete = new Date(refDate.getFullYear(), refDate.getMonth(), 0);
  return {
    end_year: lastComplete.getFullYear(),
    end_month: lastComplete.getMonth() + 1,
    months,
  };
}

/**
 * Get API params for Current tab (current_start_date, etc.).
 * Maps period label to the four required date params.
 */
export function getCurrentApiParams(
  period: string,
  refDate: Date = new Date()
): CurrentApiParams | null {
  const range = getDateRangeFromCurrentPeriod(period, refDate);
  if (!range) return null;
  return {
    current_start_date: range.date_from,
    current_end_date: range.date_to,
    previous_start_date: range.previous_date_from,
    previous_end_date: range.previous_date_to,
  };
}

/**
 * Compute date range for Current tab period selection.
 * Returns current period and previous period for comparison.
 * Supports: Last week, Week to date, Month to date, Last month (and legacy: Today, Last 7 Days, Last 30 Days, MTD).
 */
export function getDateRangeFromCurrentPeriod(
  period: string,
  refDate: Date = new Date()
): CurrentPeriodWithComparison | null {
  const today = toDateString(refDate);

  // "Month to date" - same as MTD
  if (period === "Month to date" || period === "MTD") {
    const currentFrom = new Date(refDate.getFullYear(), refDate.getMonth(), 1);
    const prevMonth = new Date(refDate.getFullYear(), refDate.getMonth() - 1, 1);
    const dayOfMonth = refDate.getDate();
    const lastDayOfPrevMonth = new Date(refDate.getFullYear(), refDate.getMonth(), 0).getDate();
    const prevMonthDay = Math.min(dayOfMonth, lastDayOfPrevMonth);
    const previousTo = new Date(refDate.getFullYear(), refDate.getMonth() - 1, prevMonthDay);
    return {
      date_from: toDateString(currentFrom),
      date_to: today,
      previous_date_from: toDateString(prevMonth),
      previous_date_to: toDateString(previousTo),
    };
  }

  // "Last week" - Mon-Sun of most recent completed week; previous = week before
  if (period === "Last week") {
    const thisMonday = getMondayOfWeek(refDate);
    const lastWeekEnd = new Date(thisMonday);
    lastWeekEnd.setDate(lastWeekEnd.getDate() - 1);
    const lastWeekStart = new Date(lastWeekEnd);
    lastWeekStart.setDate(lastWeekStart.getDate() - 6);
    const prevWeekEnd = new Date(lastWeekStart);
    prevWeekEnd.setDate(prevWeekEnd.getDate() - 1);
    const prevWeekStart = new Date(prevWeekEnd);
    prevWeekStart.setDate(prevWeekStart.getDate() - 6);
    return {
      date_from: toDateString(lastWeekStart),
      date_to: toDateString(lastWeekEnd),
      previous_date_from: toDateString(prevWeekStart),
      previous_date_to: toDateString(prevWeekEnd),
    };
  }

  // "Week to date" - Mon of current week → today; previous = same span, one week prior
  if (period === "Week to date") {
    const thisMonday = getMondayOfWeek(refDate);
    const prevWeekMonday = new Date(thisMonday);
    prevWeekMonday.setDate(prevWeekMonday.getDate() - 7);
    const daysDiff = Math.round((refDate.getTime() - thisMonday.getTime()) / (1000 * 60 * 60 * 24));
    const prevWeekEnd = new Date(prevWeekMonday);
    prevWeekEnd.setDate(prevWeekEnd.getDate() + daysDiff);
    return {
      date_from: toDateString(thisMonday),
      date_to: today,
      previous_date_from: toDateString(prevWeekMonday),
      previous_date_to: toDateString(prevWeekEnd),
    };
  }

  // "Last month" - Full previous calendar month; previous = month before that
  if (period === "Last month") {
    const prevMonth = new Date(refDate.getFullYear(), refDate.getMonth() - 1, 1);
    const lastDayPrevMonth = new Date(refDate.getFullYear(), refDate.getMonth(), 0);
    const monthBefore = new Date(refDate.getFullYear(), refDate.getMonth() - 2, 1);
    const lastDayMonthBefore = new Date(refDate.getFullYear(), refDate.getMonth() - 1, 0);
    return {
      date_from: toDateString(prevMonth),
      date_to: toDateString(lastDayPrevMonth),
      previous_date_from: toDateString(monthBefore),
      previous_date_to: toDateString(lastDayMonthBefore),
    };
  }

  // Legacy presets (for backward compatibility)
  if (period === "Today") {
    const sameDayLastYear = new Date(refDate);
    sameDayLastYear.setFullYear(sameDayLastYear.getFullYear() - 1);
    return {
      date_from: today,
      date_to: today,
      previous_date_from: toDateString(sameDayLastYear),
      previous_date_to: toDateString(sameDayLastYear),
    };
  }

  if (period === "Last 7 Days") {
    const from = new Date(refDate);
    from.setDate(from.getDate() - 7);
    const prevTo = new Date(from);
    prevTo.setDate(prevTo.getDate() - 1);
    const prevFrom = new Date(prevTo);
    prevFrom.setDate(prevFrom.getDate() - 6);
    return {
      date_from: toDateString(from),
      date_to: today,
      previous_date_from: toDateString(prevFrom),
      previous_date_to: toDateString(prevTo),
    };
  }

  if (period === "Last 30 Days") {
    const from = new Date(refDate);
    from.setDate(from.getDate() - 30);
    const prevTo = new Date(from);
    prevTo.setDate(prevTo.getDate() - 1);
    const prevFrom = new Date(prevTo);
    prevFrom.setDate(prevFrom.getDate() - 29);
    return {
      date_from: toDateString(from),
      date_to: today,
      previous_date_from: toDateString(prevFrom),
      previous_date_to: toDateString(prevTo),
    };
  }

  return null;
}

/**
 * Check if a date range matches a Current tab preset; returns preset name or null.
 */
export function getMatchingCurrentPeriod(
  date_from: string,
  date_to: string,
  refDate: Date = new Date()
): string | null {
  const presets = ["Last week", "Week to date", "Month to date", "Last month", "Today", "Last 7 Days", "Last 30 Days", "MTD"] as const;
  for (const preset of presets) {
    const range = getDateRangeFromCurrentPeriod(preset, refDate);
    if (range && range.date_from === date_from && range.date_to === date_to) return preset;
  }
  return null;
}

/**
 * Compute comparison period for a custom date range (same length, immediately before).
 * Used when user selects custom dates on Current tab.
 */
export function getComparisonPeriodForCustomRange(
  date_from: string,
  date_to: string
): CurrentPeriodWithComparison | null {
  const from = new Date(date_from);
  const to = new Date(date_to);
  if (isNaN(from.getTime()) || isNaN(to.getTime()) || from > to) return null;

  const daysDiff = Math.round((to.getTime() - from.getTime()) / (1000 * 60 * 60 * 24));
  const prevTo = new Date(from);
  prevTo.setDate(prevTo.getDate() - 1);
  const prevFrom = new Date(prevTo);
  prevFrom.setDate(prevFrom.getDate() - daysDiff);

  return {
    date_from,
    date_to,
    previous_date_from: prevFrom.toISOString().slice(0, 10),
    previous_date_to: prevTo.toISOString().slice(0, 10),
  };
}

/**
 * Compute date range for Historical tab period selection.
 * Custom Range returns null (handled via dateRange state from picker).
 */
export function getDateRangeFromHistoricalPeriod(
  period: string,
  refDate: Date = new Date()
): DateRange | null {
  const to = toDateString(refDate);
  const from = new Date(refDate);

  if (period === "Custom Range") {
    return null;
  }

  if (period === "Last 3 months") {
    from.setMonth(from.getMonth() - 3);
  } else if (period === "Last 6 months") {
    from.setMonth(from.getMonth() - 6);
  } else if (period === "Last 12 months") {
    from.setMonth(from.getMonth() - 12);
  } else if (period === "Previous 12 Months") {
    from.setFullYear(from.getFullYear() - 1);
    from.setMonth(from.getMonth() - 12);
    const toDate = new Date(refDate);
    toDate.setFullYear(toDate.getFullYear() - 1);
    return { date_from: toDateString(from), date_to: toDateString(toDate) };
  } else if (period === "YTD") {
    from.setMonth(0);
    from.setDate(1);
  } else if (period === "Same Period Last Year") {
    from.setFullYear(from.getFullYear() - 1);
    from.setMonth(from.getMonth() - 12);
    const toDate = new Date(refDate);
    toDate.setFullYear(toDate.getFullYear() - 1);
    return { date_from: toDateString(from), date_to: toDateString(toDate) };
  } else {
    return null;
  }

  return { date_from: toDateString(from), date_to: to };
}

/**
 * Check if a date range matches a Historical tab preset; returns preset name or null.
 */
export function getMatchingHistoricalPeriod(
  date_from: string,
  date_to: string,
  refDate: Date = new Date()
): string | null {
  const presets = ["Last 3 months", "Last 6 months", "Last 12 months", "Previous 12 Months", "YTD", "Same Period Last Year"] as const;
  for (const preset of presets) {
    const range = getDateRangeFromHistoricalPeriod(preset, refDate);
    if (range && range.date_from === date_from && range.date_to === date_to) return preset;
  }
  return null;
}

export function isWithin90DayWindow(date_from: string, date_to: string, refDate: Date = new Date()): boolean {
  const from = new Date(date_from);
  const to = new Date(date_to);
  const cutoff = new Date(refDate);
  cutoff.setDate(cutoff.getDate() - 90);
  return from >= cutoff && to <= refDate && from <= to;
}
