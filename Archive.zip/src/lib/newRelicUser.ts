interface NewRelicWindow extends Window {
  newrelic?: {
    setUserId: (userId: string | null) => void;
    setCustomAttribute: (name: string, value: string | number | boolean | null, persist?: boolean) => void;
  };
}

declare const window: NewRelicWindow;

/**
 * Set user information in New Relic Browser monitoring
 */
export function setNewRelicUser(user: {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
}) {
  if (typeof window !== 'undefined' && window.newrelic) {
    const nr = window.newrelic;

    if (user.id) {
      nr.setUserId(user.id);
    }

    if (user.email) {
      nr.setCustomAttribute('userEmail', user.email, true);
    }
    if (user.firstName) {
      nr.setCustomAttribute('userFirstName', user.firstName, true);
    }
    if (user.lastName) {
      nr.setCustomAttribute('userLastName', user.lastName, true);
    }
  }
}

/**
 * Clear user information from New Relic (on logout)
 */
export function clearNewRelicUser() {
  if (typeof window !== 'undefined' && window.newrelic) {
    const nr = window.newrelic;
    nr.setUserId(null);
    nr.setCustomAttribute('userEmail', null);
    nr.setCustomAttribute('userFirstName', null);
    nr.setCustomAttribute('userLastName', null);
  }
}
