import { isVariantFamily } from "@/tenant";

/** User-facing singular label for the GCN / product-family concept. */
export function getGcnLabel(): string {
  return isVariantFamily() ? "Product Family" : "GCN";
}

/** User-facing plural label for the GCN / product-family concept. */
export function getGcnPluralLabel(): string {
  return isVariantFamily() ? "Product Families" : "GCNs";
}

/** Default “all” filter value for the GCN / product-family filter. */
export function getAllGcnLabel(): string {
  return isVariantFamily() ? "All Product Families" : "All GCN";
}

export function getGcnNumberLabel(): string {
  return isVariantFamily() ? "Product Family Number" : "GCN Number";
}

export function getGcnDescriptionLabel(): string {
  return isVariantFamily() ? "Product Family Description" : "GCN Description";
}

export function getMaterialInGcnLabel(): string {
  return isVariantFamily() ? "Material in Product Family" : "Material in GCN";
}

export function getGcnPlantLabel(): string {
  return isVariantFamily() ? "Product Family·Plant" : "GCN·Plant";
}

export function getGcnPluralSuppliedLabel(): string {
  return isVariantFamily() ? "Product Families Supplied" : "GCNs Supplied";
}

/** Lowercase search hint used in material search placeholders. */
export function getGcnSearchHint(): string {
  return isVariantFamily() ? "product family" : "gcn";
}

export function getMaterialSearchPlaceholder(): string {
  return `Search by name, nbr, ndc or ${getGcnSearchHint()}`;
}
