/** User-facing singular label for the product-family concept. */
export function getGcnLabel(): string {
  return "Product Family";
}

/** User-facing plural label for the product-family concept. */
export function getGcnPluralLabel(): string {
  return "Product Families";
}

/** Default “all” filter value for the product-family filter. */
export function getAllGcnLabel(): string {
  return "All Product Families";
}

export function getGcnNumberLabel(): string {
  return "Product Family Number";
}

export function getGcnDescriptionLabel(): string {
  return "Product Family Description";
}

export function getMaterialInGcnLabel(): string {
  return "Material in Product Family";
}

export function getGcnPlantLabel(): string {
  return "Product Family·Plant";
}

export function getGcnPluralSuppliedLabel(): string {
  return "Product Families Supplied";
}

/** Lowercase search hint used in material search placeholders. */
export function getGcnSearchHint(): string {
  return "product family";
}

export function getMaterialSearchPlaceholder(): string {
  return `Search by name, nbr, ndc or ${getGcnSearchHint()}`;
}
