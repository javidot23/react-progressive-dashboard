export type PaginatedPageResult<T> = {
  results: T[];
  count: number;
  next: string | null;
};

export type FetchAllPaginatedOptions<T> = {
  /** Fetch one page. `offset` is the number of rows already loaded. */
  fetchPage: (args: { limit: number; offset: number; signal?: AbortSignal }) => Promise<PaginatedPageResult<T>>;
  pageSize?: number;
  /** Hard cap to avoid unbounded memory use on huge result sets. */
  maxRows?: number;
  signal?: AbortSignal;
};

/**
 * Walk a DRF-style paginated endpoint until exhausted (or `maxRows` is reached).
 */
export async function fetchAllPaginated<T>({
  fetchPage,
  pageSize = 500,
  maxRows = 10_000,
  signal,
}: FetchAllPaginatedOptions<T>): Promise<T[]> {
  const rows: T[] = [];
  let offset = 0;
  let total = Number.POSITIVE_INFINITY;

  while (rows.length < maxRows && offset < total) {
    if (signal?.aborted) {
      throw new DOMException("The operation was aborted.", "AbortError");
    }

    const page = await fetchPage({ limit: pageSize, offset, signal });
    total = typeof page.count === "number" ? page.count : rows.length + (page.results?.length ?? 0);
    const batch = page.results ?? [];
    if (batch.length === 0) break;

    const remaining = maxRows - rows.length;
    rows.push(...batch.slice(0, remaining));

    if (!page.next || batch.length === 0) break;
    offset += batch.length;
  }

  return rows;
}
