/** Minimal fields to determine whether the current user created an action. */
export type ActionOwnerFields = {
  user_id?: string;
  user?: { id?: string } | null;
};

/** True if the signed-in user created this action (matches API user id / Entra id fields). */
export function isMaterialActionOwner(action: ActionOwnerFields, entraId: string | undefined | null): boolean {
  if (!entraId) return false;
  if (action.user_id === entraId) return true;
  if (action.user?.id === entraId) return true;
  return false;
}
