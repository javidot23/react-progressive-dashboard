const MONTH_NAMES = [
  "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
  "JUL", "AUG", "SEP", "OCT", "NOV", "DEC",
];

function formatMonthLabel(year: number, month: number): string {
  const monthName = MONTH_NAMES[month - 1] ?? "???";
  return `${monthName} ${year}`;
}

/**
 * Parses a YYYY-MM string and returns { year, month }.
 * Falls back to current date if invalid.
 */
function parseSelectedMonth(selectedMonth: string): { year: number; month: number } {
  const match = selectedMonth?.match(/^(\d{4})-(\d{2})$/);
  if (match) {
    const year = parseInt(match[1], 10);
    const month = parseInt(match[2], 10);
    if (month >= 1 && month <= 12) {
      return { year, month };
    }
  }
  const now = new Date();
  return { year: now.getFullYear(), month: now.getMonth() + 1 };
}

/**
 * Returns the previous month for a given year/month.
 */
function getPreviousMonth(year: number, month: number): { year: number; month: number } {
  if (month === 1) {
    return { year: year - 1, month: 12 };
  }
  return { year, month: month - 1 };
}

export interface MonthColumns {
  selectedMonth: string;
  selectedMonthKey: string;
  previousMonths: string[];
  previousMonthKeys: string[];
  allMonthKeys: string[];
}

/**
 * Derives month column labels and keys from a selected month (YYYY-MM).
 * Returns the selected month formatted as "AUG 2025" and 6 previous months.
 */
/** Inclusive calendar range for selected month plus `monthsBack` prior months (default 6). */
export function getDateRangeForMonthWindow(
  selectedMonth: string,
  monthsBack = 6
): { fromDate: string; toDate: string } {
  const { year, month } = parseSelectedMonth(selectedMonth);
  const toDate = `${year}-${String(month).padStart(2, "0")}-${String(
    new Date(year, month, 0).getDate()
  ).padStart(2, "0")}`;

  let fromYear = year;
  let fromMonth = month - monthsBack;
  while (fromMonth <= 0) {
    fromMonth += 12;
    fromYear -= 1;
  }
  const fromDate = `${fromYear}-${String(fromMonth).padStart(2, "0")}-01`;
  return { fromDate, toDate };
}

export function getDefaultSelectedMonth(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

export function getMonthColumns(selectedMonth: string): MonthColumns {
  const { year, month } = parseSelectedMonth(selectedMonth);
  const selectedMonthKey = `${year}-${String(month).padStart(2, "0")}`;
  const selectedMonthLabel = formatMonthLabel(year, month);

  const previousMonths: string[] = [];
  const previousMonthKeys: string[] = [];
  let currentYear = year;
  let currentMonth = month;

  for (let i = 0; i < 6; i++) {
    const prev = getPreviousMonth(currentYear, currentMonth);
    currentYear = prev.year;
    currentMonth = prev.month;
    previousMonthKeys.push(`${currentYear}-${String(currentMonth).padStart(2, "0")}`);
    previousMonths.push(formatMonthLabel(currentYear, currentMonth));
  }

  const allMonthKeys = [selectedMonthKey, ...previousMonthKeys];

  return {
    selectedMonth: selectedMonthLabel,
    selectedMonthKey,
    previousMonths,
    previousMonthKeys,
    allMonthKeys,
  };
}
