import { MutationCache, QueryClient, QueryClientConfig } from "@tanstack/react-query";
import { getErrorMessage } from "@/lib/getErrorMessage";
import { toast } from "@/lib/toast";

declare module "@tanstack/react-query" {
  interface Register {
    mutationMeta: {
      successMessage?: string | ((data: unknown, variables: unknown) => string);
      errorMessage?: string | ((error: unknown, variables: unknown) => string);
      silent?: boolean;
    };
  }
}

const queryClientConfig: QueryClientConfig = {
  defaultOptions: {
    queries: {
      staleTime: 60_000,
      refetchOnWindowFocus: false,
      retry: (failureCount, error: unknown) => {
        const status = (error as { response?: { status?: number } })?.response?.status;
        if (status === 401 || status === 403) {
          return false;
        }
        return failureCount < 2;
      },
    },
  },
};

export function createToastMutationCache(): MutationCache {
  return new MutationCache({
    onSuccess: (data, variables, _ctx, mutation) => {
      const meta = mutation.meta;
      if (!meta || meta.silent) return;
      const msg = typeof meta.successMessage === "function" ? meta.successMessage(data, variables) : meta.successMessage;
      if (msg) toast.success({ title: msg });
    },
    onError: (error, variables, _ctx, mutation) => {
      const meta = mutation.meta;
      if (meta?.silent) return;
      const title =
        typeof meta?.errorMessage === "function"
          ? meta.errorMessage(error, variables)
          : (meta?.errorMessage ?? "Something went wrong");
      toast.error({ title, description: getErrorMessage(error) });
    },
  });
}

const mutationCache = createToastMutationCache();

export const queryClient = new QueryClient({ ...queryClientConfig, mutationCache });
