import { type DropdownConfig, type FiltersConfig } from "@/components/atoms/Filters";
import { AppliedFiltersConfig } from "@/components/atoms/AppliedFilters";
import { tenantHasControlledSubstances } from "@/lib/csScheduleFilter";
import { DEFAULT_DC_PLANTS_ORDERING } from "@/lib/inventoryFilterUtils";
import { fetchDrivingRiskOptions } from "@/services/vendorService";
import { productFamilyService } from "@/lib/apiServices";
import apiClient from "@/lib/apiClient";
import { isCustomerPortal, isVendorPortal } from "@/tenant";

/** Tighter Plan / Plan Product bounds, `$` range labels, and “Sales Volume & Quantity” — `stratium.vendor` only. */
function isVendorPortalPlanFilters(): boolean {
  return isVendorPortal();
}

/** Customer portal non-vendor (`stratium.customer`, not vendor portal). */
function isCustomerPortalNonVendorTenant(): boolean {
  return isCustomerPortal() && !isVendorPortal();
}

// Materials Alt-Served and Substituted API functions with search and infinite scroll support
export const fetchMaterialStatusOptions = async (): Promise<{
  options: string[];
  hasMore: boolean;
}> => {
  // Static material status options
  const staticOptions = [
    "Discontinued by ABC",
    "Temp Unavail from Mfg",
    "Active",
    "Discontinued by Mfg",
    "New",
    "Allocated by Mfg",
    "LongTerm Unavail from Mfg",
  ];

  return { options: staticOptions, hasMore: false };
};

// New API functions that return numbers for filtering but display names
export const fetchMaterialOptionsWithNumbers = async (
  search?: string,
  offset: number = 0,
  limit: number = 20
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    // const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("search", search);
    }

    const response = await apiClient.get(`/material/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      // Return material numbers for filtering (like original OrderFilters.tsx)
      const options = data.data.results.map((item: any) => item.mat_nbr).filter(Boolean);
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching material options:", error);
    return { options: [], hasMore: false };
  }
};

export const fetchSupplierOptionsWithNumbers = async (
  search?: string,
  offset: number = 0,
  limit: number = 20
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("name", search);
    }

    const response = await apiClient.get(`/vendor/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      const options = data.data.results.map((item: any) => item.vendor_nbr).filter(Boolean);
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching supplier options:", error);
    return { options: [], hasMore: false };
  }
};

export const fetchVendorOptionsForScorecard = async (
  search?: string,
  offset: number = 0,
  limit: number = 10
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("search", search);
    }

    const response = await apiClient.get(`/vendor/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      const options = data.data.results
        .map((item: any) => {
          if (item.vendor_nbr && item.name) {
            return `(${item.vendor_nbr}) ${item.name}`;
          }
          return item.name || item.vendor_nbr;
        })
        .filter(Boolean);
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching vendor options for scorecard:", error);
    return { options: [], hasMore: false };
  }
};

export const fetchPrimaryDCOptionsWithNumbers = async (
  search?: string,
  offset: number = 0,
  limit: number = 20
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    // const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("name", search);
    }

    const response = await apiClient.get(`/plant/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      // Return DC Numbers for filtering (like original OrderFilters.tsx)
      const options = data.data.results.map((item: any) => item.plant_nbr.toString()).filter(Boolean);
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching primary DC options:", error);
    return { options: [], hasMore: false };
  }
};

/** Plant list options as `(plant_nbr) Name` for quarantine SGTIN filters — value parses back to `plant_nbr` via `storeMapping`. */
export const fetchQuarantinePlantOptionsWithNameAndId = async (
  search?: string,
  offset: number = 0,
  limit: number = 20
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("name", search);
    }

    const response = await apiClient.get(`/plant/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      const options = data.data.results
        .map((item: { plant_nbr?: string | number; name?: string }) => {
          const nbr = item.plant_nbr != null ? String(item.plant_nbr) : "";
          if (!nbr) return null;
          const name = String(item.name ?? "").trim() || nbr;
          return `(${nbr}) ${name}`;
        })
        .filter(Boolean) as string[];
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching quarantine DC options:", error);
    return { options: [], hasMore: false };
  }
};

export const fetchSecondaryDCOptionsWithNumbers = async (
  search?: string,
  offset: number = 0,
  limit: number = 20
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("name", search);
    }

    const response = await apiClient.get(`/plant/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      // Return DC Numbers for filtering (like original OrderFilters.tsx)
      const options = data.data.results.map((item: any) => item.plant_nbr.toString()).filter(Boolean);
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching secondary DC options:", error);
    return { options: [], hasMore: false };
  }
};

export const fetchMaterialOptions = async (
  search?: string,
  offset: number = 0,
  limit: number = 20
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("search", search);
    }

    const response = await apiClient.get(`/material/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      // Return material names for display, but we'll need to handle the mat_nbr mapping in the component
      const options = data.data.results.map((item: any) => item.name).filter(Boolean);
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching material options:", error);
    return { options: [], hasMore: false };
  }
};

export const fetchSupplierOptions = async (
  search?: string,
  offset: number = 0,
  limit: number = 20
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("name", search);
    }

    const response = await apiClient.get(`/vendor/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      // Return Supplier Numbers for filtering, but display names
      const options = data.data.results.map((item: any) => item.vendor_nbr).filter(Boolean);
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching supplier options:", error);
    return { options: [], hasMore: false };
  }
};

export const fetchPrimaryDCOptions = async (
  search?: string,
  offset: number = 0,
  limit: number = 20
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("name", search);
    }

    const response = await apiClient.get(`/plant/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      // Return DC Numbers for filtering
      const options = data.data.results.map((item: any) => item.plant_nbr.toString()).filter(Boolean);
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching primary DC options:", error);
    return { options: [], hasMore: false };
  }
};

export const fetchSecondaryDCOptions = async (
  search?: string,
  offset: number = 0,
  limit: number = 20
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
    const params = new URLSearchParams();
    params.append("limit", limit.toString());
    params.append("offset", offset.toString());
    if (search) {
      params.append("name", search);
    }

    const response = await apiClient.get(`/plant/?${params.toString()}`);
    const data = response.data;

    if (data.success && data.data?.results) {
      // Return DC Numbers for filtering
      const options = data.data.results.map((item: any) => item.plant_nbr.toString()).filter(Boolean);
      const hasMore = data.data.next !== null;
      return { options, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching secondary DC options:", error);
    return { options: [], hasMore: false };
  }
};

// VENDOR FILTERS CONFIG
export const vendorFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Supplier Name", value: "name" },
    { label: "Risk Score", value: "risk_rating" },
    { label: "Driving Risk", value: "driving_risk" },
    { label: "Risk Adjusted Value", value: "risk_adjusted_value" },
    { label: "Sales Quantity", value: "sales_volume" },
    { label: "Materials at Risk", value: "materials_at_risk" },
    { label: "Sales Amount", value: "sales_amount" },
  ],
  presetRanges: [
    {
      key: "risk_rating",
      label: "Risk Score",
      minKey: "risk_rating_min",
      maxKey: "risk_rating_max",
      presets: {
        "Highly Unlikely": { min: 0.0, max: 0.2 },
        Unlikely: { min: 0.21, max: 0.4 },
        "Even Chance": { min: 0.41, max: 0.6 },
        Likely: { min: 0.61, max: 0.8 },
        "Highly Likely": { min: 0.81, max: 1.0 },
      },
    },
  ],
  dropdowns: [
    {
      key: "driving_risk",
      label: "Driving Risk",
      options: fetchDrivingRiskOptions,
    },
  ],
  ranges: [
    {
      key: "risk_adjusted_value",
      label: "Risk Adjusted Value",
      min: 0,
      max: isVendorPortalPlanFilters() ? 200_000_000 : 1_000_000_000,
      step: 1,
      minKey: "risk_adjusted_value_min",
      maxKey: "risk_adjusted_value_max",
      ...(isVendorPortalPlanFilters() ? { valueDisplayPrefix: "$" } : {}),
      children: [],
    },
    {
      key: "sales_volume_qty",
      label: isVendorPortalPlanFilters() ? "Sales Amount & Quantity" : "Sales Amount & QTY Range",
      min: 0,
      max: isVendorPortalPlanFilters() ? 30_000_000 : isCustomerPortalNonVendorTenant() ? 300_000_000 : 1_000_000_000,
      step: 1,
      minKey: "sales_volume_qty_min",
      maxKey: "sales_volume_qty_max",
      children: [
        {
          key: "sales_amount",
          label: "Sales Amount",
          min: 0,
          max: isVendorPortalPlanFilters() ? 30_000_000 : isCustomerPortalNonVendorTenant() ? 300_000_000 : 10_000_000_000,
          step: 1,
          minKey: "sales_amount_min",
          maxKey: "sales_amount_max",
          ...(isVendorPortalPlanFilters() ? { valueDisplayPrefix: "$" } : {}),
        },
        {
          key: "sales_volume",
          label: "Sales Quantity",
          min: 0,
          max: isVendorPortalPlanFilters() ? 5_000_000 : isCustomerPortalNonVendorTenant() ? 300_000_000 : 1_000_000_000,
          step: 1,
          minKey: "sales_volume_min",
          maxKey: "sales_volume_max",
        },
      ],
    },
    {
      key: "materials_at_risk",
      label: "Materials At Risk",
      min: 0,
      max: isVendorPortalPlanFilters() ? 300 : 1_000_000,
      step: 1,
      minKey: "materials_at_risk_min",
      maxKey: "materials_at_risk_max",
      children: [],
    },
  ],
};

const vendorRaLabel = (): string => "Risk Adjusted Value";
const vendorSalesVolLabel = (): string => "Sales Amount";

export const vendorAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    search: "", // Search has its own toolbar control — hide from chips
    limit: "", // Hide limit from applied filters
    offset: "", // Hide offset from applied filters
    risk_rating_min: "Risk Score",
    risk_rating_max: "Risk Score",
    primary_risk: "Driving Risk",
    driving_risk: "Driving Risk",
    dollars_at_risk_min: vendorRaLabel(),
    dollars_at_risk_max: vendorRaLabel(),
    risk_adjusted_value_min: vendorRaLabel(),
    risk_adjusted_value_max: vendorRaLabel(),
    sales_amount_min: vendorSalesVolLabel(),
    sales_amount_max: vendorSalesVolLabel(),
    sales_volume_min: "Sales Quantity",
    sales_volume_max: "Sales Quantity",
    materials_at_risk_min: "Materials At Risk",
    materials_at_risk_max: "Materials At Risk",
    has_no_actions: "Action Status",
  },
  fieldLabels: {
    name: "Name",
    risk_rating: "Risk Score",
    driving_risk: "Driving Risk",
    risk_adjusted_value: vendorRaLabel(),
    sales_volume: "Sales Quantity",
    materials_at_risk: "Materials At Risk",
    sales_amount: vendorSalesVolLabel(),
    material__vendor__name: "Supplier Name",
    material__risk_rating: "Risk Score",
    material__driving_risk: "Driving Risk",
    material__dollars_at_risk: vendorRaLabel(),
    material__sales_volume: "Sales Quantity",
    material__materials_at_risk: "Materials at Risk",
    material__sales_amt: vendorSalesVolLabel(),
  },
  defaultFilters: {
    search: "",
    risk_rating_min: null,
    risk_rating_max: null,
    primary_risk: "",
    ordering: "-risk_rating,-risk_adjusted_value",
  },
  riskRatingRanges: {
    "Highly Unlikely": { min: 0.0, max: 0.2 },
    Unlikely: { min: 0.21, max: 0.4 },
    "Even Chance": { min: 0.41, max: 0.6 },
    Likely: { min: 0.61, max: 0.8 },
    "Highly Likely": { min: 0.81, max: 1.0 },
  },
};

export const contractSalesWithoutChargebacksFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Invoice Date (newest first)", value: "-invoice_date" },
    { label: "Invoice Date (oldest first)", value: "invoice_date" },
    { label: "Amount (high to low)", value: "-contract_sales_and_rebill_amount" },
    { label: "Amount (low to high)", value: "contract_sales_and_rebill_amount" },
    { label: "Quantity (high to low)", value: "-contract_sales_and_rebill_qty" },
    { label: "Quantity (low to high)", value: "contract_sales_and_rebill_qty" },
  ],
  ranges: [],
};

export const contractSalesWithoutChargebacksAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
  },
  fieldLabels: {
    invoice_date: "Invoice Date (oldest first)",
    "-invoice_date": "Invoice Date (newest first)",
    contract_sales_and_rebill_amount: "Amount (low to high)",
    "-contract_sales_and_rebill_amount": "Amount (high to low)",
    contract_sales_and_rebill_qty: "Quantity (low to high)",
    "-contract_sales_and_rebill_qty": "Quantity (high to low)",
  },
  defaultFilters: {
    ordering: "-invoice_date",
  },
};

export const purchaseOrdersFailedScansFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "PO No.", value: "req_po_nbr" },
    { label: "Failed Scans", value: "total_failed_scans" },
    { label: "SGTN Error", value: "sgtin_not_found_errors" },
    { label: "Lot No. Error", value: "lot_errors" },
    { label: "Exp. Date Error", value: "expiration_errors" },
  ],
  ranges: [
    {
      key: "total_failed_scans",
      label: "Failed Scans",
      min: 0,
      max: 5000,
      step: 1,
      minKey: "total_failed_scans_min",
      maxKey: "total_failed_scans_max",
      children: [],
    },
    {
      key: "sgtin_not_found_errors",
      label: "SGTN Error",
      min: 0,
      max: 5000,
      step: 1,
      minKey: "sgtin_not_found_errors_min",
      maxKey: "sgtin_not_found_errors_max",
      children: [],
    },
    {
      key: "lot_errors",
      label: "Lot No. Error",
      min: 0,
      max: 5000,
      step: 1,
      minKey: "lot_errors_min",
      maxKey: "lot_errors_max",
      children: [],
    },
    {
      key: "expiration_errors",
      label: "Exp. Date Error",
      min: 0,
      max: 5000,
      step: 1,
      minKey: "expiration_errors_min",
      maxKey: "expiration_errors_max",
      children: [],
    },
  ],
};

export const purchaseOrdersFailedScansAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    total_failed_scans_min: "Failed Scans (Min)",
    total_failed_scans_max: "Failed Scans (Max)",
    sgtin_not_found_errors_min: "SGTN Error (Min)",
    sgtin_not_found_errors_max: "SGTN Error (Max)",
    lot_errors_min: "Lot No. Error (Min)",
    lot_errors_max: "Lot No. Error (Max)",
    expiration_errors_min: "Exp. Date Error (Min)",
    expiration_errors_max: "Exp. Date Error (Max)",
  },
  fieldLabels: {
    req_po_nbr: "PO No.",
    total_failed_scans: "Failed Scans",
    sgtin_not_found_errors: "SGTN Error",
    lot_errors: "Lot No. Error",
    expiration_errors: "Exp. Date Error",
  },
  defaultFilters: {
    ordering: "-total_failed_scans",
    total_failed_scans_min: null,
    total_failed_scans_max: null,
    sgtin_not_found_errors_min: null,
    sgtin_not_found_errors_max: null,
    lot_errors_min: null,
    lot_errors_max: null,
    expiration_errors_min: null,
    expiration_errors_max: null,
  },
};

// CHARGEBACK VALIDATION TABLE FILTERS CONFIG
export const chargebackValidationFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Debit Memo Date", value: "dm_post_date" },
    { label: "Chargeback Qty", value: "chbk_qty" },
    { label: "Submitted Amount", value: "abc_req_amt" },
  ],
  ranges: [],
};

export const chargebackValidationAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    rejection_reason: "Rejection reason",
  },
  fieldLabels: {
    dm_post_date: "Debit Memo Date",
    chbk_qty: "Chargeback Qty",
    abc_req_amt: "Submitted Amount",
  },
  defaultFilters: {
    ordering: "-dm_post_date",
    rejection_reason: "",
  },
};

/** CS Sales period options for Historical tab — UI labels match API doc (`months`: 3 / 6 / 12). */
export const CS_SALES_HISTORICAL_PERIOD_OPTIONS = ["Last 3 months", "Last 6 months", "Last 12 months"] as const;

/** CS Sales period options for Current tab (API spec presets). */
export const CS_SALES_CURRENT_PERIOD_OPTIONS = ["Last week", "Week to date", "Month to date", "Last month"] as const;

/** CS Sales measure options (shared). */
export const CS_SALES_MEASURE_OPTIONS = ["Dollar", "Quantity"] as const;

/** Mapping from federal_cs_ind code to display label. */
export const CS_SCHEDULE_MAPPING: Record<string, string> = {
  "2": "Schedule 2",
  "2N": "Schedule 2 Non-Narc",
  "3": "Schedule 3",
  "3N": "Schedule 3 Non-Narc",
  "4": "Schedule 4",
  "5": "Schedule 5",
  NC: "Not Controlled",
};

const csScheduleDescToCode = Object.fromEntries(Object.entries(CS_SCHEDULE_MAPPING).map(([k, v]) => [v, k]));

function buildCsScheduleDropdown(federalCsIndicators: string[]): DropdownConfig {
  const scheduleOptions = federalCsIndicators.map(code => CS_SCHEDULE_MAPPING[code] ?? code);
  return {
    key: "federal_cs_ind",
    label: "Filter by schedule",
    options: scheduleOptions,
    disableSearch: true,
    storeMapping: async (display: string) => csScheduleDescToCode[display] ?? display,
    displayMapping: async (code: string) => CS_SCHEDULE_MAPPING[code] ?? code,
  };
}

const csSalesMeasureDropdown: DropdownConfig = {
  key: "measure",
  label: "Select Measure",
  options: [...CS_SALES_MEASURE_OPTIONS],
  disableSearch: true,
};

/** Sales change tracking filters config (measure + period + optional filter by schedule). */
export function buildCsSalesFiltersConfig(
  tab: "historical" | "current",
  federalCsIndicators: string[]
): FiltersConfig {
  const periodDropdown: DropdownConfig = {
    key: "period",
    label: "Select Period",
    options: tab === "historical" ? [...CS_SALES_HISTORICAL_PERIOD_OPTIONS] : [...CS_SALES_CURRENT_PERIOD_OPTIONS],
    disableSearch: true,
  };

  const showCsSchedule = tenantHasControlledSubstances(federalCsIndicators);
  const dropdowns: DropdownConfig[] = [csSalesMeasureDropdown, periodDropdown];
  if (showCsSchedule) {
    dropdowns.push(buildCsScheduleDropdown(federalCsIndicators));
  }

  return {
    sortOptions: [],
    dropdowns,
    customOrder: showCsSchedule ? ["measure", "period", "federal_cs_ind"] : ["measure", "period"],
  };
}

/** Sales overview filters config (CS schedule filter only, when tenant has controlled substances). */
export function buildManageSalesFiltersConfig(federalCsIndicators: string[]): FiltersConfig {
  const showCsSchedule = tenantHasControlledSubstances(federalCsIndicators);
  const dropdowns: DropdownConfig[] = showCsSchedule ? [buildCsScheduleDropdown(federalCsIndicators)] : [];

  return {
    sortOptions: [],
    dropdowns,
    customOrder: showCsSchedule ? ["federal_cs_ind"] : [],
  };
}

/** Sales overview applied filters config. */
export function buildManageSalesAppliedFiltersConfig(): AppliedFiltersConfig {
  return {
    filterLabels: {
      federal_cs_ind: "Filter by schedule",
      ordering: "",
    },
    fieldLabels: {},
    defaultFilters: {},
  };
}

/** Sales change tracking applied filters config. */
export function buildCsSalesAppliedFiltersConfig(
  tab: "historical" | "current",
  _period?: string,
  _defaultDateRange?: { date_from: string; date_to: string }
): AppliedFiltersConfig {
  const baseLabels = {
    measure: "Select Measure",
    period: "Select Period",
    exclude_federal_cs_ind: "Exclude schedule",
    federal_cs_ind: "Filter by schedule",
    ordering: "",
    date_from: "",
    date_to: "",
    selectedState: "State",
    state: "State",
  };

  if (tab === "historical") {
    return {
      filterLabels: baseLabels,
      fieldLabels: {},
      defaultFilters: {
        measure: "Dollar",
        period: "Last 12 months",
      },
    };
  }

  return {
    filterLabels: {
      ...baseLabels,
      previous_date_from: "",
      previous_date_to: "",
    },
    fieldLabels: {},
    defaultFilters: {
      measure: "Dollar",
      period: "Month to date",
    },
  };
}

// FTS MATERIAL EXPOSURE FILTERS CONFIG
export const ftsMaterialExposureFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Material NDC", value: "material_ndc" },
    { label: "Material Description", value: "material_description" },
    { label: "FTS Exposure", value: "fts_exposure" },
    { label: "FTS Quantity", value: "fts_quantity" },
  ],
  ranges: [],
};

export const ftsMaterialExposureAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
  },
  fieldLabels: {
    material_ndc: "Material NDC",
    material_description: "Material Description",
    fts_exposure: "FTS Exposure",
    fts_quantity: "FTS Quantity",
  },
  defaultFilters: {
    ordering: "-fts_exposure",
  },
};

// CORPORATE CHAIN FILTERS CONFIG
export const corporateChainFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Chain Name", value: "name" },
    { label: "Perfect Order Rate", value: "perfect_order_rate" },
    { label: "Total Orders", value: "total_orders_30day" },
    { label: "Imperfect Orders", value: "total_imperfect_30day" },
  ],
  ranges: [
    {
      key: "perfect_order_rate",
      label: "Perfect Order Rate %",
      min: 0,
      max: 100,
      step: 1,
      minKey: "perfect_order_rate_min",
      maxKey: "perfect_order_rate_max",
    },
  ],
};

export const corporateChainAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    limit: "", // Hide limit from applied filters
    offset: "", // Hide offset from applied filters
    perfect_order_rate_min: "Perfect Order Rate",
    perfect_order_rate_max: "Perfect Order Rate",
  },
  fieldLabels: {
    name: "Chain Name",
    perfect_order_rate: "Perfect Order Rate",
    total_orders_30day: "Total Orders",
    total_imperfect_30day: "Imperfect Orders",
  },
  defaultFilters: {
    ordering: "-perfect_order_rate",
    perfect_order_rate_min: null,
    perfect_order_rate_max: null,
  },
};

// ISSUE FILTERS CONFIG
export const issueFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Material Name", value: "material__name" },
    { label: "Risk Score", value: "material__risk_rating" },
    { label: "Driving Risk", value: "material__driving_risk" },
    { label: "Created Date", value: "created_at" },
    { label: "Action Status", value: "has_actions" },
    { label: "Risk Adjusted Value", value: "risk_adjusted_value" },
  ],
  presetRanges: [
    {
      key: "risk_rating",
      label: "Risk Score",
      minKey: "risk_rating_min",
      maxKey: "risk_rating_max",
      presets: {
        "Highly Unlikely": { min: 0.0, max: 0.2 },
        Unlikely: { min: 0.21, max: 0.4 },
        "Even Chance": { min: 0.41, max: 0.6 },
        Likely: { min: 0.61, max: 0.8 },
        "Highly Likely": { min: 0.81, max: 1.0 },
      },
    },
  ],
  ranges: [
    {
      key: "risk_adjusted_value",
      label: "Risk Adjusted Value",
      min: 0,
      max: 10000000,
      step: 1,
      minKey: "risk_adjusted_value_min",
      maxKey: "risk_adjusted_value_max",
    },
  ],
  dropdowns: [
    {
      key: "driving_risk",
      label: "Driving Risk",
      options: [], // Will be passed dynamically
    },
    {
      key: "has_no_actions",
      label: "Action Status",
      options: ["All", "Not Reviewed", "Reviewed"],
    },
  ],
};

export const issueAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    risk_rating_min: "Risk Score",
    risk_rating_max: "Risk Score",
    driving_risk: "Driving Risk",
    has_no_actions: "Action Status",
    risk_adjusted_value_min: "Risk Adjusted Value",
    risk_adjusted_value_max: "Risk Adjusted Value",
  },
  fieldLabels: {
    material__name: "Material Name",
    material__risk_rating: "Risk Score",
    material__driving_risk: "Driving Risk",
    created_at: "Created Date",
    has_actions: "Action Status",
    risk_adjusted_value: "Risk Adjusted Value",
  },
  defaultFilters: {
    ordering: "-risk_adjusted_value",
    risk_rating_min: null,
    risk_rating_max: null,
    driving_risk: null,
    has_no_actions: undefined,
    risk_adjusted_value_min: null,
    risk_adjusted_value_max: null,
  },
  riskRatingRanges: {
    "Highly Unlikely": { min: 0.0, max: 0.2 },
    Unlikely: { min: 0.21, max: 0.4 },
    "Even Chance": { min: 0.41, max: 0.6 },
    Likely: { min: 0.61, max: 0.8 },
    "Highly Likely": { min: 0.81, max: 1.0 },
  },
};

// NATIVE-GRANULARITY ISSUE FILTERS CONFIG (feed — GET /issue/all/)
// Grain-aware sort + ranges over the effective_* / impacted_material_count params.
// UI labels never say "effective" (that's only the API param name). Kept separate
// from `issueFiltersConfig` so the material-level Manage pages are unaffected.

/** Tenant-aware upper bound for the aggregate $ / risk-adjusted ranges (mirrors ReactPage's prior inline max). */
function granularityValueMax(): number {
  if (isVendorPortal()) return 10_000_000;
  if (isCustomerPortal()) return 50_000_000;
  return 100_000_000;
}

const GRANULARITY_RISK_PRESETS = {
  "Highly Unlikely": { min: 0.0, max: 0.2 },
  Unlikely: { min: 0.21, max: 0.4 },
  "Even Chance": { min: 0.41, max: 0.6 },
  Likely: { min: 0.61, max: 0.8 },
  "Highly Likely": { min: 0.81, max: 1.0 },
};

/** Static group values for GET /issue/all/ ``group`` filter. */
export const GRANULARITY_ISSUE_GROUP_OPTIONS = [
  "RO",
  "ROSS/Account Services",
  "SGS",
  "ROSS",
] as const;

export const granularityIssueFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Risk Adjusted Value", value: "effective_risk_adjusted_value" },
    { label: "Value at Risk", value: "effective_dollars_at_risk" },
    { label: "Risk Score", value: "effective_risk_rating" },
    { label: "Materials Affected", value: "impacted_material_count" },
    { label: "Date Identified", value: "date_identified" },
    { label: "Material Name", value: "material__name" },
  ],
  presetRanges: [
    {
      key: "effective_risk_rating",
      label: "Risk Score",
      minKey: "effective_risk_rating_min",
      maxKey: "effective_risk_rating_max",
      presets: GRANULARITY_RISK_PRESETS,
    },
  ],
  ranges: [
    {
      key: "effective_risk_adjusted_value",
      label: "Risk Adjusted Value",
      min: 0,
      max: granularityValueMax(),
      step: 1,
      minKey: "effective_risk_adjusted_value_min",
      maxKey: "effective_risk_adjusted_value_max",
    },
    {
      key: "effective_dollars_at_risk",
      label: "Value at Risk",
      min: 0,
      max: granularityValueMax(),
      step: 1,
      minKey: "effective_dollars_at_risk_min",
      maxKey: "effective_dollars_at_risk_max",
    },
    {
      key: "impacted_material_count",
      label: "Materials Affected",
      min: 0,
      max: 500,
      step: 1,
      minKey: "impacted_material_count_min",
      maxKey: "impacted_material_count_max",
    },
  ],
  dropdowns: [
    { key: "group", label: "Group", options: [...GRANULARITY_ISSUE_GROUP_OPTIONS] },
    {
      key: "has_no_actions",
      label: "Action Status",
      options: ["All", "Not Reviewed", "Reviewed"],
    },
  ],
};

export const granularityIssueAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    effective_risk_rating_min: "Risk Score",
    effective_risk_rating_max: "Risk Score",
    effective_risk_adjusted_value_min: "Risk Adjusted Value",
    effective_risk_adjusted_value_max: "Risk Adjusted Value",
    effective_dollars_at_risk_min: "Value at Risk",
    effective_dollars_at_risk_max: "Value at Risk",
    impacted_material_count_min: "Materials Affected",
    impacted_material_count_max: "Materials Affected",
    group: "Group",
    has_no_actions: "Action Status",
  },
  fieldLabels: {
    effective_risk_adjusted_value: "Risk Adjusted Value",
    effective_dollars_at_risk: "Value at Risk",
    effective_risk_rating: "Risk Score",
    impacted_material_count: "Materials Affected",
    date_identified: "Date Identified",
    material__name: "Material Name",
  },
  defaultFilters: {
    ordering: "-effective_risk_adjusted_value",
    effective_risk_rating_min: null,
    effective_risk_rating_max: null,
    effective_risk_adjusted_value_min: null,
    effective_risk_adjusted_value_max: null,
    effective_dollars_at_risk_min: null,
    effective_dollars_at_risk_max: null,
    impacted_material_count_min: null,
    impacted_material_count_max: null,
    group: null,
    has_no_actions: undefined,
  },
  riskRatingRanges: GRANULARITY_RISK_PRESETS,
};

// NATIVE-GRANULARITY IMPACTED-MATERIALS FILTERS CONFIG (GET /issue/<id>/materials/)
// Server-side ordering + risk/$/RAV ranges on a single issue's materials.
export const impactedMaterialsFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Risk Adjusted Value", value: "risk_adjusted_value" },
    { label: "Risk Score", value: "risk_rating" },
    { label: "Value at Risk", value: "dollars_at_risk" },
    { label: "Material Name", value: "name" },
    { label: "Material #", value: "mat_nbr" },
  ],
  presetRanges: [
    {
      key: "risk_rating",
      label: "Risk Score",
      minKey: "risk_rating_min",
      maxKey: "risk_rating_max",
      presets: GRANULARITY_RISK_PRESETS,
    },
  ],
  ranges: [
    {
      key: "risk_adjusted_value",
      label: "Risk Adjusted Value",
      min: 0,
      max: granularityValueMax(),
      step: 1,
      minKey: "risk_adjusted_value_min",
      maxKey: "risk_adjusted_value_max",
    },
    {
      key: "dollars_at_risk",
      label: "Value at Risk",
      min: 0,
      max: granularityValueMax(),
      step: 1,
      minKey: "dollars_at_risk_min",
      maxKey: "dollars_at_risk_max",
    },
  ],
};

export const impactedMaterialsAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    risk_rating_min: "Risk Score",
    risk_rating_max: "Risk Score",
    risk_adjusted_value_min: "Risk Adjusted Value",
    risk_adjusted_value_max: "Risk Adjusted Value",
    dollars_at_risk_min: "Value at Risk",
    dollars_at_risk_max: "Value at Risk",
  },
  fieldLabels: {
    risk_adjusted_value: "Risk Adjusted Value",
    risk_rating: "Risk Score",
    dollars_at_risk: "Value at Risk",
    name: "Material Name",
    mat_nbr: "Material #",
  },
  defaultFilters: {
    ordering: "-risk_adjusted_value",
    risk_rating_min: null,
    risk_rating_max: null,
    risk_adjusted_value_min: null,
    risk_adjusted_value_max: null,
    dollars_at_risk_min: null,
    dollars_at_risk_max: null,
  },
  riskRatingRanges: GRANULARITY_RISK_PRESETS,
};

// MATERIAL FILTERS CONFIG
export const materialFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Material Name", value: "name" },
    { label: "Risk Score", value: "risk_score" },
    { label: "Driving Risk", value: "primary_risk" },
    { label: "Risk Adjusted Value", value: "risk_adjusted_value" },
    { label: "Action Status", value: "action_status" },
  ],
  presetRanges: [
    {
      key: "risk_rating",
      label: "Risk Score",
      minKey: "risk_rating_min",
      maxKey: "risk_rating_max",
      presets: {
        "Highly Unlikely": { min: 0.0, max: 20 },
        Unlikely: { min: 21, max: 40 },
        "Even Chance": { min: 41, max: 60 },
        Likely: { min: 61, max: 80 },
        "Highly Likely": { min: 81, max: 100 },
      },
    },
  ],
  dropdowns: [
    {
      key: "primary_risk",
      label: "Driving Risk",
      options: fetchDrivingRiskOptions,
    },
  ],
  ranges: [
    {
      key: "risk_adjusted_value",
      label: "Risk Adjusted Value",
      min: 0,
      max: isVendorPortalPlanFilters() ? 30_000_000 : 10_000_000,
      step: 1,
      minKey: "risk_adjusted_value_min",
      maxKey: "risk_adjusted_value_max",
      ...(isVendorPortalPlanFilters() ? { valueDisplayPrefix: "$" } : {}),
    },
  ],
};

export function getMaterialFiltersConfigWithMaterialSearch(vendorId: number | null): FiltersConfig {
  const materialDropdown = {
    key: "mat_nbr",
    label: "Material",
    searchPlaceholder: "Search by name, nbr or NDC...",
    options: async (search?: string, offset?: number, limit?: number) => {
      if (!vendorId) return { options: [] as string[], hasMore: false };
      const params: Record<string, any> = {
        limit: limit ?? 10,
        offset: offset ?? 0,
        vendor_id: vendorId,
      };
      if (search) params.search = search;
      const res = await apiClient.get("/material/", { params });
      const results = res.data?.data?.results ?? res.data?.results ?? [];
      const mapped = results.map((m: any) => `(${m.mat_nbr}) ${m.name || m.material_name || ""}`);
      const total = res.data?.data?.count ?? 0;
      return { options: mapped, hasMore: (offset ?? 0) + mapped.length < total };
    },
  };

  const dropdowns = [materialDropdown, ...(materialFiltersConfig.dropdowns ?? [])];

  const customOrder = [
    materialDropdown.key,
    ...(materialFiltersConfig.presetRanges?.map(p => p.key) ?? []),
    ...(materialFiltersConfig.dropdowns?.map(d => d.key) ?? []),
    ...(materialFiltersConfig.ranges?.map(r => r.key) ?? []),
  ];

  return {
    ...materialFiltersConfig,
    dropdowns,
    customOrder,
  };
}

const materialRaLabel = (): string => "Risk Adjusted Value";

export const materialAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    mat_nbr: "Material",
    risk_rating_min: "Risk Score",
    risk_rating_max: "Risk Score",
    primary_risk: "Driving Risk",
    risk_adjusted_value_min: materialRaLabel(),
    risk_adjusted_value_max: materialRaLabel(),
  },
  fieldLabels: {
    name: "Material Name",
    mat_nbr: "Material",
    risk_score: "Risk Score",
    primary_risk: "Driving Risk",
    risk_adjusted_value: materialRaLabel(),
    action_status: "Action Status",
  },
  defaultFilters: {
    ordering: "",
    mat_nbr: "",
    risk_rating_min: null,
    risk_rating_max: null,
    primary_risk: "",
    risk_adjusted_value_min: null,
    risk_adjusted_value_max: null,
  },
  riskRatingRanges: {
    "Highly Unlikely": { min: 0.0, max: 20 },
    Unlikely: { min: 21, max: 40 },
    "Even Chance": { min: 41, max: 60 },
    Likely: { min: 61, max: 80 },
    "Highly Likely": { min: 81, max: 100 },
  },
};

// PURCHASE ORDER FILTERS CONFIG
export const purchaseOrderFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Material Name", value: "material_name" },
    { label: "Units Ordered", value: "units_ordered" },
    { label: "Units Received On Time", value: "units_received_on_time" },
    { label: "Units Received Late", value: "units_received_late" },
    { label: "Units Not Received", value: "units_not_received" },
    { label: "Inbound Fill Rate", value: "inbound_fill_rate" },
  ],
  ranges: [
    {
      key: "units_ordered",
      label: "Units Ordered",
      min: 1,
      max: 5000000,
      step: 1,
      minKey: "units_ordered_min",
      maxKey: "units_ordered_max",
    },
    {
      key: "units_on_time",
      label: "Units On Time",
      min: 0,
      max: 5000000,
      step: 1,
      minKey: "units_received_on_time_min",
      maxKey: "units_received_on_time_max",
    },
    {
      key: "units_late",
      label: "Units Received Late",
      min: 0,
      max: 5000000,
      step: 1,
      minKey: "units_received_late_min",
      maxKey: "units_received_late_max",
    },
    {
      key: "units_not_received",
      label: "Units Not Received",
      min: 0,
      max: 5000000,
      step: 1,
      minKey: "units_not_received_min",
      maxKey: "units_not_received_max",
    },
    {
      key: "inbound_fill_rate",
      label: "Inbound Fill Rate",
      min: 0,
      max: 100,
      step: 1,
      minKey: "inbound_fill_rate_min",
      maxKey: "inbound_fill_rate_max",
      valueTransform: {
        displayToStore: (value: number) => Math.round(Math.min(1, Math.max(0, value / 100)) * 10000) / 10000, // Round to 4 decimal places to avoid precision issues
        storeToDisplay: (value: number) => Math.round(Math.min(100, Math.max(0, value * 100))), // Round to nearest integer for percentage display
      },
    },
  ],
};

export const purchaseOrderAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    units_ordered_min: "Units Ordered",
    units_ordered_max: "Units Ordered",
    units_received_on_time_min: "Units On Time",
    units_received_on_time_max: "Units On Time",
    units_received_late_min: "Units Received Late",
    units_received_late_max: "Units Received Late",
    units_not_received_min: "Units Not Received",
    units_not_received_max: "Units Not Received",
    inbound_fill_rate_min: "Fill Rate",
    inbound_fill_rate_max: "Fill Rate",
  },
  fieldLabels: {
    material_name: "Material Name",
    units_ordered: "Units Ordered",
    units_received_on_time: "Units On Time",
    units_received_late: "Units Late",
    units_not_received: "Units Not Received",
    inbound_fill_rate: "Fill Rate",
  },
  defaultFilters: {
    ordering: "-units_ordered",
    units_ordered_min: null,
    units_ordered_max: null,
    units_received_on_time_min: null,
    units_received_on_time_max: null,
    units_received_late_min: null,
    units_received_late_max: null,
    units_not_received_min: null,
    units_not_received_max: null,
    inbound_fill_rate_min: null,
    inbound_fill_rate_max: null,
  },
};

// PURCHASE HISTORY FILTERS CONFIG
export const purchaseHistoryFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Units Ordered", value: "original_order_qty" },
    { label: "Total Units Received", value: "received_qty" },
    { label: "Units Received On Time", value: "units_received_on_time" },
    { label: "Units Received Late", value: "units_received_late" },
    { label: "Units Not Received", value: "units_not_received" },
    { label: "PO Create Date", value: "ordered_date" },
    { label: "PO Grace Due Date", value: "anticipated_date" },
  ],
  ranges: [
    {
      key: "po_units_ordered",
      label: "Units Ordered",
      min: 0,
      max: 5000000,
      step: 1,
      minKey: "original_order_qty_min",
      maxKey: "original_order_qty_max",
    },
    {
      key: "total_units_received",
      label: "Total Units Received",
      min: 0,
      max: 5000000,
      step: 1,
      minKey: "received_qty_min",
      maxKey: "received_qty_max",
    },
    {
      key: "po_units_on_time",
      label: "Units On Time",
      min: 0,
      max: 5000000,
      step: 1,
      minKey: "units_received_on_time_min",
      maxKey: "units_received_on_time_max",
    },
    {
      key: "po_units_late",
      label: "Units Received Late",
      min: 0,
      max: 5000000,
      step: 1,
      minKey: "units_received_late_min",
      maxKey: "units_received_late_max",
    },
    {
      key: "po_units_not_received",
      label: "Units Not Received",
      min: 0,
      max: 5000000,
      step: 1,
      minKey: "units_not_received_min",
      maxKey: "units_not_received_max",
    },
  ],
};

export const purchaseHistoryAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    material_id: "", // Hide material_id from applied filters
    original_order_qty_min: "Units Ordered",
    original_order_qty_max: "Units Ordered",
    received_qty_min: "Total Received",
    received_qty_max: "Total Received",
    units_received_on_time_min: "Units On Time",
    units_received_on_time_max: "Units On Time",
    units_received_late_min: "Units Received Late",
    units_received_late_max: "Units Received Late",
    units_not_received_min: "Units Not Received",
    units_not_received_max: "Units Not Received",
  },
  fieldLabels: {
    material__name: "Material Name",
    ordered_date: "PO Create Date",
    anticipated_date: "PO Grace Due Date",
    original_order_qty: "Units Ordered",
    received_qty: "Total Received",
    units_received_on_time: "Units On Time",
    units_received_late: "Units Late",
    units_not_received: "Units Not Received",
  },
  defaultFilters: {
    ordering: "ordered_date",
    original_order_qty_min: null,
    original_order_qty_max: null,
    received_qty_min: null,
    received_qty_max: null,
    units_received_on_time_min: null,
    units_received_on_time_max: null,
    units_received_late_min: null,
    units_received_late_max: null,
    units_not_received_min: null,
    units_not_received_max: null,
  },
};

export const quarantineSgtinFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Material Id", value: "material_id" },
    { label: "Original Created Date", value: "original_created_date" },
    { label: "Lead Time", value: "lead_time" },
  ],
  ranges: [
    {
      key: "lead_time",
      label: "Lead Time (days)",
      min: 0,
      max: 365,
      step: 1,
      minKey: "lead_time_min",
      maxKey: "lead_time_max",
      children: [],
    },
  ],
  dropdowns: [
    {
      key: "plant_nbr",
      label: "Distribution center",
      options: fetchQuarantinePlantOptionsWithNameAndId,
      displayMapping: async (plantNbr: string) => {
        try {
          const response = await apiClient.get(`/plant/?plant_nbr=${encodeURIComponent(plantNbr)}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            const row = data.data.results[0];
            const nbr = String(row.plant_nbr ?? plantNbr);
            const name = String(row.name ?? "").trim() || nbr;
            return `(${nbr}) ${name}`;
          }
          return plantNbr;
        } catch {
          return plantNbr;
        }
      },
      storeMapping: async (display: string) => {
        const fromLabel = display.match(/^\(([^)]+)\)\s*/);
        if (fromLabel) return fromLabel[1].trim();
        try {
          const response = await apiClient.get(`/plant/?name=${encodeURIComponent(display)}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            return String(data.data.results[0].plant_nbr);
          }
        } catch {
          /* ignore */
        }
        return display;
      },
    },
  ],
  /** Sort renders first; then DC, then lead time range. */
  customOrder: ["plant_nbr", "lead_time"],
};

export const quarantineSgtinAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    plant_nbr: "Distribution center",
    status_code: "Status code",
    lead_time_min: "Lead time (days)",
    lead_time_max: "Lead time (days)",
    date_from: "",
    date_to: "",
  },
  dateRangePairs: [{ fromKey: "date_from", toKey: "date_to", label: "Event date range" }],
  fieldLabels: {
    material_id: "Material Id",
    original_created_date: "Original Created Date",
    lead_time: "Lead Time",
  },
  defaultFilters: {
    ordering: "-original_created_date",
    plant_nbr: "",
    status_code: "",
    date_from: null,
    date_to: null,
    lead_time_min: null,
    lead_time_max: null,
  },
};

/** Sort only — `/order-transaction/material-order-quantities/` (full Stratium: columns match Materials in High Demand table). */
export const materialOrderQuantitiesFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Material Name", value: "material_name" },
    { label: "Material ID", value: "mat_nbr" },
    { label: "Total Order Qty", value: "total_order_qty" },
    { label: "Perfect Line Rate %", value: "perfect_line_rate" },
    { label: "Imperfect Lines", value: "imperfect_lines" },
    { label: "Unpredictable Demand Lines", value: "unpredictable_demand" },
    { label: "Demand Planning Imperfect Lines", value: "demand_variability" },
  ],
};

export const materialOrderQuantitiesAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: { ordering: "Sort" },
  fieldLabels: {
    material_name: "Material Name",
    mat_nbr: "Material ID",
    total_order_qty: "Total Order Qty",
    perfect_line_rate: "Perfect Line Rate %",
    imperfect_lines: "Imperfect Lines",
    unpredictable_demand: "Unpredictable Demand Lines",
    demand_variability: "Demand Planning Imperfect Lines",
  },
  defaultFilters: {
    ordering: "-total_order_qty",
  },
};

export const materialOrderQuantitiesVariantFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Material Name", value: "material_name" },
    { label: "Material ID", value: "mat_nbr" },
    { label: "Total Order Qty", value: "total_order_qty" },
    { label: "Fill Rate %", value: "fill_rate" },
  ],
};

export const materialOrderQuantitiesVariantAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: { ordering: "Sort" },
  fieldLabels: {
    material_name: "Material Name",
    mat_nbr: "Material ID",
    total_order_qty: "Total Order Qty",
    fill_rate: "Fill Rate %",
  },
  defaultFilters: {
    ordering: "-total_order_qty",
  },
};

export const soldToPartyOrderQuantitiesFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Customer Name", value: "cust_nbr_name" },
    { label: "Customer ID", value: "cust_nbr" },
    { label: "Total Order Qty", value: "total_order_qty" },
    { label: "Perfect Line Rate %", value: "perfect_line_rate" },
    { label: "Imperfect Lines", value: "imperfect_lines" },
    { label: "Unpredictable Demand Lines", value: "unpredictable_demand" },
    { label: "Demand Planning Imperfect Lines", value: "demand_variability" },
  ],
};

export const soldToPartyOrderQuantitiesAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: { ordering: "Sort" },
  fieldLabels: {
    cust_nbr_name: "Customer Name",
    cust_nbr: "Customer ID",
    total_order_qty: "Total Order Qty",
    perfect_line_rate: "Perfect Line Rate %",
    imperfect_lines: "Imperfect Lines",
    unpredictable_demand: "Unpredictable Demand Lines",
    demand_variability: "Demand Planning Imperfect Lines",
  },
  defaultFilters: {
    ordering: "-total_order_qty",
  },
};

export const soldToPartyOrderQuantitiesVendorUpstreamFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Customer Name", value: "cust_nbr_name" },
    { label: "Customer ID", value: "cust_nbr" },
    { label: "Total Order Qty", value: "total_order_qty" },
    { label: "Fill Rate %", value: "fill_rate" },
  ],
};

export const soldToPartyOrderQuantitiesVendorUpstreamAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: { ordering: "Sort" },
  fieldLabels: {
    cust_nbr_name: "Customer Name",
    cust_nbr: "Customer ID",
    total_order_qty: "Total Order Qty",
    fill_rate: "Fill Rate %",
  },
  defaultFilters: {
    ordering: "-total_order_qty",
  },
};

export const scorecardFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Overall Score", value: "overall_score" },
    { label: "OTIF", value: "otif_percentage" },
    { label: "Inbound Fill Rate", value: "inbound_fill_rate" },
    { label: "ASN Timeliness", value: "asn_timeliness" },
    { label: "ASN Essential", value: "asn_essential" },
    { label: "Product Damage Rate", value: "product_damages_rate" },
  ],
  customOrder: [
    "vendor_nbr",
    "inbound_fill_rate",
    "overall_score",
    "otif_percentage",
    "product_damages_rate",
    "asn_timeliness",
    "asn_essential",
  ],
  dropdowns: [
    {
      key: "vendor_nbr",
      label: "Supplier",
      options: fetchVendorOptionsForScorecard,
      searchPlaceholder: "Search by name or nbr",
      displayMapping: async (vendorNbr: string) => {
        try {
          const response = await apiClient.get(`/vendor/?vendor_nbr=${vendorNbr}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            const vendor = data.data.results[0];
            return `(${vendor.vendor_nbr}) ${vendor.name}` || vendorNbr;
          }
          return vendorNbr;
        } catch (error) {
          console.error("Error fetching Supplier Name:", error);
          return vendorNbr;
        }
      },
      storeMapping: async (formattedValue: string) => {
        try {
          const match = formattedValue.match(/^\((\d+)\)\s*(.+)$/);
          if (match) {
            const vendorNbr = match[1];
            return vendorNbr;
          }
          // Fallback: try to find by name if format doesn't match
          const response = await apiClient.get(`/vendor/?name=${formattedValue}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            return data.data.results[0].vendor_nbr || formattedValue;
          }
          return formattedValue;
        } catch (error) {
          console.error("Error fetching Supplier Number:", error);
          return formattedValue;
        }
      },
    },
  ],
  ranges: [
    {
      key: "inbound_fill_rate",
      label: "Inbound Fill Rate (%)",
      min: 0,
      max: 100,
      step: 1,
      minKey: "inbound_fill_rate_min",
      maxKey: "inbound_fill_rate_max",
      valueTransform: {
        displayToStore: (value: number) => Math.min(1, Math.max(0, value / 100)), // Convert percentage to decimal, clamp to 0-1
        storeToDisplay: (value: number) => Math.min(100, Math.max(0, value * 100)), // Convert decimal to percentage, clamp to 0-100
      },
    },
    {
      key: "overall_score",
      label: "Overall Score (%)",
      min: 0,
      max: 100,
      step: 1,
      minKey: "overall_score_min",
      maxKey: "overall_score_max",
      valueTransform: {
        displayToStore: (value: number) => Math.min(1, Math.max(0, value / 100)), // Convert percentage to decimal, clamp to 0-1
        storeToDisplay: (value: number) => Math.min(100, Math.max(0, value * 100)), // Convert decimal to percentage, clamp to 0-100
      },
    },
    {
      key: "otif_percentage",
      label: "OTIF (%)",
      min: 0,
      max: 100,
      step: 1,
      minKey: "otif_percentage_min",
      maxKey: "otif_percentage_max",
      valueTransform: {
        displayToStore: (value: number) => Math.min(1, Math.max(0, value / 100)), // Convert percentage to decimal, clamp to 0-1
        storeToDisplay: (value: number) => Math.min(100, Math.max(0, value * 100)), // Convert decimal to percentage, clamp to 0-100
      },
    },
    {
      key: "product_damages_rate",
      label: "Product Damage Rate (%)",
      min: 0,
      max: 100,
      step: 1,
      minKey: "product_damages_rate_min",
      maxKey: "product_damages_rate_max",
      valueTransform: {
        displayToStore: (value: number) => Math.min(1, Math.max(0, value / 100)), // Convert percentage to decimal, clamp to 0-1
        storeToDisplay: (value: number) => Math.min(100, Math.max(0, value * 100)), // Convert decimal to percentage, clamp to 0-100
      },
    },
    {
      key: "asn_timeliness",
      label: "ASN Timeliness (%)",
      min: 0,
      max: 100,
      step: 1,
      minKey: "asn_timeliness_min",
      maxKey: "asn_timeliness_max",
      valueTransform: {
        displayToStore: (value: number) => Math.min(1, Math.max(0, value / 100)), // Convert percentage to decimal, clamp to 0-1
        storeToDisplay: (value: number) => Math.min(100, Math.max(0, value * 100)), // Convert decimal to percentage, clamp to 0-100
      },
    },
    {
      key: "asn_essential",
      label: "ASN Essential (%)",
      min: 0,
      max: 100,
      step: 1,
      minKey: "asn_essential_min",
      maxKey: "asn_essential_max",
      valueTransform: {
        displayToStore: (value: number) => Math.min(1, Math.max(0, value / 100)), // Convert percentage to decimal, clamp to 0-1
        storeToDisplay: (value: number) => Math.min(100, Math.max(0, value * 100)), // Convert decimal to percentage, clamp to 0-100
      },
    },
  ],
};

export const scorecardAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    limit: "", // Hide limit from applied filters
    offset: "", // Hide offset from applied filters
    vendor_nbr: "Supplier",
    overall_score_min: "Overall Score (%)",
    overall_score_max: "Overall Score (%)",
    otif_percentage_min: "OTIF (%)",
    otif_percentage_max: "OTIF (%)",
    inbound_fill_rate_min: "Inbound Fill Rate (%)",
    inbound_fill_rate_max: "Inbound Fill Rate (%)",
    asn_timeliness_min: "ASN Timeliness (%)",
    asn_timeliness_max: "ASN Timeliness (%)",
    asn_essential_min: "ASN Essential (%)",
    asn_essential_max: "ASN Essential (%)",
    product_damages_rate_min: "Product Damage Rate (%)",
    product_damages_rate_max: "Product Damage Rate (%)",
  },
  fieldLabels: {
    overall_score: "Overall Score (%)",
    otif_percentage: "OTIF (%)",
    inbound_fill_rate: "Inbound Fill Rate (%)",
    asn_timeliness: "ASN Timeliness (%)",
    asn_essential: "ASN Essential (%)",
    product_damages_rate: "Product Damage Rate (%)",
  },
  defaultFilters: {
    limit: 10,
    offset: 0,
    ordering: "-overall_score",
    vendor_nbr: null,
    overall_score_min: null,
    overall_score_max: null,
    otif_percentage_min: null,
    otif_percentage_max: null,
    inbound_fill_rate_min: null,
    inbound_fill_rate_max: null,
    asn_timeliness_min: null,
    asn_timeliness_max: null,
    asn_essential_min: null,
    asn_essential_max: null,
    product_damages_rate_min: null,
    product_damages_rate_max: null,
  },
};

// ORDER ISSUE DETAILS FILTERS CONFIG - Working with enhanced generic Filters.tsx
export const orderIssueFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Created Date", value: "ord_created_date" },
    { label: "Material Status", value: "material_status" },
    { label: "Order Quantity", value: "total_order_qty" },
  ],
  customOrder: ["material_status", "material_mat_nbr", "vendor_nbr", "ar_plant_nbr", "plant_nbr", "total_order_qty"],
  dropdowns: [
    {
      key: "material_status",
      label: "Material Status",
      options: fetchMaterialStatusOptions,
    },
    {
      key: "material_mat_nbr",
      label: "Material",
      options: fetchMaterialOptionsWithNumbers,
      displayMapping: async (matNbr: string) => {
        // Convert material number to material name for display with mat_nbr prefix
        try {
          //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
          const response = await apiClient.get(`/material/?mat_nbr=${matNbr}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            const material = data.data.results[0];
            return `(${material.mat_nbr}) ${material.name || matNbr}`;
          }
          return matNbr;
        } catch (error) {
          console.error("Error fetching material name:", error);
          return matNbr;
        }
      },
      storeMapping: async (materialName: string) => {
        // Convert material name to material number for storage
        try {
          //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
          const response = await apiClient.get(`/material/?name=${materialName}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            return data.data.results[0].mat_nbr || materialName;
          }
          return materialName;
        } catch (error) {
          console.error("Error fetching material number:", error);
          return materialName;
        }
      },
    },
    {
      key: "vendor_nbr",
      label: "Supplier",
      options: fetchSupplierOptionsWithNumbers,
      displayMapping: async (vendorNbr: string) => {
        // Convert Supplier Number to Supplier Name for display
        try {
          //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
          const response = await apiClient.get(`/vendor/?vendor_nbr=${vendorNbr}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            return data.data.results[0].name || vendorNbr;
          }
          return vendorNbr;
        } catch (error) {
          console.error("Error fetching Supplier Name:", error);
          return vendorNbr;
        }
      },
      storeMapping: async (vendorName: string) => {
        // Convert Supplier Name to Supplier Number for storage
        try {
          //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
          const response = await apiClient.get(`/vendor/?name=${vendorName}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            return data.data.results[0].vendor_nbr || vendorName;
          }
          return vendorName;
        } catch (error) {
          console.error("Error fetching Supplier Number:", error);
          return vendorName;
        }
      },
    },
    {
      key: "ar_plant_nbr",
      label: "Primary DC",
      options: fetchPrimaryDCOptionsWithNumbers,
      displayMapping: async (plantNbr: string) => {
        // Convert DC Number to DC Name for display
        try {
          //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
          const response = await apiClient.get(`/plant/?plant_nbr=${plantNbr}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            return data.data.results[0].name || plantNbr;
          }
          return plantNbr;
        } catch (error) {
          console.error("Error fetching DC Name:", error);
          return plantNbr;
        }
      },
      storeMapping: async (plantName: string) => {
        // Convert DC Name to DC Number for storage
        try {
          //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
          const response = await apiClient.get(`/plant/?name=${plantName}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            return data.data.results[0].plant_nbr.toString() || plantName;
          }
          return plantName;
        } catch (error) {
          console.error("Error fetching DC Number:", error);
          return plantName;
        }
      },
    },
    {
      key: "plant_nbr",
      label: "Secondary DC",
      options: fetchSecondaryDCOptionsWithNumbers,
      displayMapping: async (plantNbr: string) => {
        // Convert DC Number to DC Name for display
        try {
          //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
          const response = await apiClient.get(`/plant/?plant_nbr=${plantNbr}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            return data.data.results[0].name || plantNbr;
          }
          return plantNbr;
        } catch (error) {
          console.error("Error fetching DC Name:", error);
          return plantNbr;
        }
      },
      storeMapping: async (plantName: string) => {
        // Convert DC Name to DC Number for storage
        try {
          //     const baseUrl = process.env.VITE_API_BASE_URL || 'http://localhost:8000';
          const response = await apiClient.get(`/plant/?name=${plantName}`);
          const data = response.data;
          if (data.success && data.data?.results?.[0]) {
            return data.data.results[0].plant_nbr.toString() || plantName;
          }
          return plantName;
        } catch (error) {
          console.error("Error fetching DC Number:", error);
          return plantName;
        }
      },
    },
  ],
  ranges: [
    {
      key: "total_order_qty",
      label: "Order Quantity",
      min: 0,
      max: 10000,
      step: 1,
      minKey: "total_order_qty_min",
      maxKey: "total_order_qty_max",
    },
  ],
};

export const orderIssueAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    material_status: "Material Status",
    material_mat_nbr: "Material",
    vendor_nbr: "Supplier",
    ar_plant_nbr: "Primary DC",
    plant_nbr: "Secondary DC",
    total_order_qty_min: "Order Quantity",
    total_order_qty_max: "Order Quantity",
  },
  fieldLabels: {
    ord_created_date: "Created Date",
    material_status: "Material Status",
    material__mat_nbr: "Material",
    vendor_nbr: "Supplier",
    ar_plant_nbr: "Primary DC",
    plant_nbr: "Secondary DC",
    total_order_qty: "Order Quantity",
  },
  defaultFilters: {
    ordering: "ord_created_date",
    material_status: "",
    material_mat_nbr: "",
    vendor_nbr: "",
    ar_plant_nbr: "",
    plant_nbr: "",
    total_order_qty_min: null,
    total_order_qty_max: null,
  },
};

// PRODUCT FAMILY FILTERS CONFIG
export const fetchProductFamilyOptions = async (
  search?: string,
  offset: number = 0,
  limit: number = 10,
  vendor_id?: number
): Promise<{ options: string[]; hasMore: boolean }> => {
  try {
    // Fetch product families with pagination
    const response = await productFamilyService.getProductFamilies(search, limit, offset, vendor_id);

    if (response.data.success) {
      // API returns paginated response with results array
      const data = response.data.data;
      const productFamilies = data?.results || [];

      // Extract product family names from the response
      const familyNames = productFamilies.map((item: any) => item.product_family).filter((name: string) => name);

      // Check if there are more results
      const hasMore = data?.next !== null && data?.next !== undefined;

      return { options: familyNames, hasMore };
    }
    return { options: [], hasMore: false };
  } catch (error) {
    console.error("Error fetching product family options:", error);
    return { options: [], hasMore: false };
  }
};

export const productFamilyFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Product Family", value: "product_family" },
    { label: "PO Quantity", value: "po_quantity" },
    { label: "OTIF %", value: "average_otif" },
    { label: "Delivery Deviation", value: "average_delivery_deviation" },
    { label: "Outbound Fill Rate", value: "average_outbound_fill_rate" },
  ],
  customOrder: ["product_family", "po_quantity", "average_otif", "average_delivery_deviation", "average_outbound_fill_rate"],
  dropdowns: [
    {
      key: "product_family",
      label: "Product Family",
      options: fetchProductFamilyOptions,
      disableSearch: false, // Enable search and pagination
    },
  ],
  ranges: [
    {
      key: "po_quantity",
      label: "PO Quantity",
      min: 0,
      max: 3000000,
      step: 1000,
      minKey: "po_quantity_min",
      maxKey: "po_quantity_max",
    },
    {
      key: "average_otif",
      label: "OTIF %",
      min: 0,
      max: 100,
      step: 1,
      minKey: "average_otif_min",
      maxKey: "average_otif_max",
      valueTransform: {
        displayToStore: (value: number) => Math.min(1, Math.max(0, value / 100)), // Convert percentage to decimal, clamp to 0-1
        storeToDisplay: (value: number) => Math.min(100, Math.max(0, value * 100)), // Convert decimal to percentage, clamp to 0-100
      },
    },
    {
      key: "average_delivery_deviation",
      label: "Delivery Deviation",
      min: -50,
      max: 50,
      step: 1,
      minKey: "average_delivery_deviation_min",
      maxKey: "average_delivery_deviation_max",
    },
    {
      key: "average_outbound_fill_rate",
      label: "Outbound Fill Rate %",
      min: 0,
      max: 100,
      step: 1,
      minKey: "average_outbound_fill_rate_min",
      maxKey: "average_outbound_fill_rate_max",
      valueTransform: {
        displayToStore: (value: number) => Math.min(1, Math.max(0, value / 100)), // Convert percentage to decimal, clamp to 0-1
        storeToDisplay: (value: number) => Math.min(100, Math.max(0, value * 100)), // Convert decimal to percentage, clamp to 0-100
      },
    },
  ],
};

export const productFamilyAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    product_family: "Product Family",
    po_quantity_min: "PO Quantity",
    po_quantity_max: "PO Quantity",
    average_otif_min: "OTIF %",
    average_otif_max: "OTIF %",
    average_delivery_deviation_min: "Delivery Deviation",
    average_delivery_deviation_max: "Delivery Deviation",
    average_outbound_fill_rate_min: "Outbound Fill Rate %",
    average_outbound_fill_rate_max: "Outbound Fill Rate %",
  },
  fieldLabels: {
    product_family: "Product Family",
    po_quantity: "PO Quantity",
    average_otif: "OTIF %",
    average_delivery_deviation: "Delivery Deviation",
    average_outbound_fill_rate: "Outbound Fill Rate %",
  },
  defaultFilters: {
    ordering: "-po_quantity", // Match the original default ordering
    product_family: "",
    po_quantity_min: null,
    po_quantity_max: null,
    average_otif_min: null,
    average_otif_max: null,
    average_delivery_deviation_min: null,
    average_delivery_deviation_max: null,
    average_outbound_fill_rate_min: null,
    average_outbound_fill_rate_max: null,
  },
};

export const inventoryAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    dc_plants_ordering: "DC inventory order",
    material_mat_nbr: "Material Number",
    dc_min: "DC Count (min)",
    dc_max: "DC Count (max)",
    doh_days_min: "Days on Hand (min)",
    doh_days_max: "Days on Hand (max)",
    active_doh_zone: "Days on Hand zone",
    sortBy: "",
  },
  fieldLabels: {
    dc_name: "Distribution Center",
    plant__plant_nbr: "Distribution Center Id",
    dc_count: "DC Count",
    outbound_fill_rate: "Outbound Fill Rate",
    forecast_28day: "28 Day Forecast",
    saleable_qty_on_hand_latest: "On Hand Quantity",
    unrestricted_qty_on_hand_latest: "Unrestricted Quantity On Hand",
    qty_ordered_sum: "Total Quantity Ordered",
    received_qty_sum: "Total Quantity Received",
    on_order_qty_sum: "On Order Quantity",
    transfer_in_qty_sum: "Total Quantity Transferred In",
    transfer_out_qty_sum: "Total Quantity Transferred Out",
    doh_days: "Days on Hand",
    doo_days: "Days on Order",
  },
  defaultFilters: {
    ordering: "-dc_count",
    dc_plants_ordering: DEFAULT_DC_PLANTS_ORDERING,
    material_mat_nbr: "",
    outbound_fill_rate_min: null,
    outbound_fill_rate_max: null,
    sortBy: "doh_days",
  },
};

// Formulary Change Tracking – material list filters (Sort + Filter)
export const formularyMaterialFiltersConfig: FiltersConfig = {
  sortOptions: [
    { label: "Material", value: "material" },
    { label: "Material Id", value: "material_id" },
    { label: "NDC", value: "ndc" },
    { label: "Date", value: "date" },
  ],
  dropdowns: [
    { key: "filter1", label: "Filter", options: ["Select an option..."], disableSearch: true },
    { key: "filter2", label: "Filter", options: ["Select an option..."], disableSearch: true },
  ],
};

export const formularyMaterialAppliedFiltersConfig: AppliedFiltersConfig = {
  filterLabels: {
    ordering: "Sort",
    filter1: "Filter",
    filter2: "Filter",
  },
  fieldLabels: {},
  defaultFilters: {
    ordering: "",
    filter1: "",
    filter2: "",
  },
};
