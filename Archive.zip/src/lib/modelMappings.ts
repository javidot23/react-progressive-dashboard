// Mapping from API model_name to model_type derived from APP_DB_ER.csv
// Keep this list in sync with backend model registry
export const modelNameToModelType: Record<string, string> = {
  "srm_fdacompliance-model-TARGET-shortage_n180d-GRANULARITY-ndcgroup": "base_model_regulatory",
  "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-ndcgroup": "base_model_regulatory",
  category_risk_market: "category_risk_group",
  category_risk_operational: "category_risk_group",
  category_risk_location: "category_risk_group",
  composite_risk_model: "composite_risk_group",
  volcano: "base_model_location",
  tsunami: "base_model_location",
  landslide: "base_model_location",
  vendor_competitive_landscape_12month: "base_model_market",
  "srm_fdacompliance-model-TARGET-shortage_n180d-GRANULARITY-gcn": "base_model_regulatory",
  "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-gcn": "base_model_regulatory",
  demand_type: "base_model_sales",
  "srm-bottlenecks-base-model": "base_model_operational",
  cyclone: "base_model_location",
  scrm_cps_3month: "base_model_operational",
  river_flood: "base_model_location",
  earthquake: "base_model_location",
  urban_flood: "base_model_location",
  water_scarcity: "base_model_location",
  forecast_error_model: "base_model_operational",
  seasonality_risk_model: "base_model_operational",
  extreme_heat: "base_model_location",
  wildfire: "base_model_location",
  coastal_flood: "base_model_location",
};

export const modelNameToDescription: Record<string, string> = {
  "srm_fdacompliance-model-TARGET-shortage_n180d-GRANULARITY-gcn":
    "Regulatory Risk from FDA Compliance Impact over the next 180 days",
  "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-gcn":
    "Regulatory Risk from FDA Compliance Impact over the next 90 days",
  "srm_fdacompliance-model-TARGET-shortage_n180d-GRANULARITY-ndcgroup":
    "Regulatory Risk from FDA Compliance Impact over the next 180 days",
  "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-ndcgroup":
    "Regulatory Risk from FDA Compliance Impact over the next 90 days",
  "srm-bottlenecks-base-model": "Operational Risk due to Supply Chain Bottlenecks",
  vendor_competitive_landscape_12month: "Market Risk of Vendor Exit from Market Landscape",
  forecast_error_model: "Operational Risk of Large Forecast Errors",
  urban_flood: "Location Risk of Flooding in Urban Environment",
  composite_risk_model: "Composite Risk Model",
  seasonality_risk_model: "Operational Risk due to Seasonality in the demand for this product",
  category_risk_operational: "Categorical Operational Risk",
  category_risk_location: "Categorical Location Risk",
  coastal_flood: "Location Risk of Coastal Flooding",
  water_scarcity: "Location Risk of Water Scarcity",
  cyclone: "Location Risk of Cyclone or Hurricane",
  scrm_cps_3month: "Operational Risk of Cascading Product Shortage",
  category_risk_market: "Categorical Market Risk",
  river_flood: "Location Risk of River Flooding",
  demand_type: "Sales Risk due to Demand Patterns",
  earthquake: "Location Risk of Earthquake",
  extreme_heat: "Location Risk of Extreme Heat",
  wildfire: "Location Risk of Wildfire",
  tsunami: "Location Risk of Tsunami",
  landslide: "Location Risk of Landslides",
  volcano: "Location Risk of Volcano",
};

export const modelNameToDisplayName: Record<string, string> = {
  "srm_fdacompliance-model-TARGET-shortage_n180d-GRANULARITY-gcn": "FDA Compliance Risk",
  "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-gcn": "FDA Compliance Risk",
  "srm_fdacompliance-model-TARGET-shortage_n180d-GRANULARITY-ndcgroup": "FDA Compliance Risk",
  "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-ndcgroup": "FDA Compliance Risk",
  "srm-bottlenecks-base-model": "Supply Chain Bottleneck Risk",
  vendor_competitive_landscape_12month: "Vendor Competitive Landscape",
  forecast_error_model: "Forecast Error Risk",
  urban_flood: "Natural Disaster Risk - Urban Flooding",
  composite_risk_model: "Overall Aggregate Supply Chain Risk",
  seasonality_risk_model: "Seasonal Demand Pattern",
  category_risk_operational: "Operations Categorical Aggregate Risk",
  category_risk_location: "Location Categorical Aggregate Risk",
  coastal_flood: "Natural Disaster Risk - Coastal Flooding",
  water_scarcity: "Natural Disaster Risk - Water Scarcity",
  cyclone: "Natural Disaster Risk - Cyclone",
  scrm_cps_3month: "Cascading Product Shortage Risk",
  category_risk_market: "Market Categorical Aggregate Risk",
  river_flood: "Natural Disaster Risk - River Flooding",
  demand_type: "Demand Pattern Sales Risk",
  earthquake: "Natural Disaster Risk - Earthquake",
  extreme_heat: "Natural Disaster Risk - Extreme Heat",
  wildfire: "Natural Disaster Risk - Wildfire",
  tsunami: "Natural Disaster Risk - Tsunami",
  landslide: "Natural Disaster Risk - Landslide",
  volcano: "Natural Disaster Risk - Volcano",
};

export function mapRiskTypeToModelType(riskTypeFromApi: string): string {
  return modelNameToModelType[riskTypeFromApi] ?? riskTypeFromApi;
}

export function getModelDescription(modelName: string): string {
  return modelNameToDescription[modelName] ?? modelName;
}

export function getModelDisplayName(modelName: string): string {
  return modelNameToDisplayName[modelName] ?? modelName;
}
