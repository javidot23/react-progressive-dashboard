import { AxiosInstance, InternalAxiosRequestConfig } from "axios";
import { getGlobalFilters, FilterValue } from "@/stores/slices/globalFilters";
import { toWafSafeQueryString } from "@/lib/queryStringUtils";

// Route patterns for different modes
const APPLY = [/^\/overview(\/|$)/, /^\/react(\/|$)/, /^\/plan(\/|$)/];

const SHOW_DISABLED: RegExp[] = [];

const IGNORE = [
  /^\/react\/product(\/|$)/,
  /^\/react\/issue(\/|$)/,
  /^\/react\/material(\/|$)/,
  /^\/plan\/product(\/|$)/,
  /^\/manage(\/|$)/,
];

/**
 * Determine the mode for the current route
 */
function modeFor(path: string): "APPLY" | "SHOW_DISABLED" | "IGNORE" {
  if (IGNORE.some(r => r.test(path))) return "IGNORE";
  if (SHOW_DISABLED.some(r => r.test(path))) return "SHOW_DISABLED";
  if (APPLY.some(r => r.test(path))) return "APPLY";
  return "IGNORE";
}

/** True when the request URL is the tenant context endpoint (never attach gf_*). */
export function isTenantContextRequestUrl(url: string): boolean {
  return /\/tenants\/context\/?($|\?)/i.test(url.toLowerCase());
}

/**
 * Check if a specific endpoint should be excluded on certain pages
 */
function isPageSpecificExclusion(path: string, url: string): boolean {
  const lowerUrl = url.toLowerCase();

  if (isTenantContextRequestUrl(lowerUrl)) {
    return true;
  }

  // On Overview, skip "Current vs Prior" API
  if (/^\/manage\/overview/.test(path) && /current-vs-prior/i.test(url)) {
    return true;
  }

  // On Overview, skip "Plant Order Stats" API
  if (/^\/manage\/overview/.test(path) && /plant-order-stats/i.test(lowerUrl)) {
    return true;
  }

  // Might remove this later
  if (/^\/manage\/overview/.test(path) && /substitution-alt-serve-kpis/i.test(lowerUrl)) {
    return true;
  }

  // On Sales, skip "Total Unit Sales Per Month"
  if (/^\/manage\/sales/.test(path) && /total-unit-sales-per-month/i.test(url)) {
    return true;
  }

  // On Supply Overview, skip "OTIF Performance Over Time"
  if (/^\/manage\/supply/.test(path) && /otif[-_ ]?over[-_ ]?time/i.test(lowerUrl)) {
    return true;
  }

  return false;
}

/** A filter's own picker endpoint must not receive that filter (it would filter its own options). */
export function getExcludedParamForFilterSource(url: string): string | null {
  const lowerUrl = url.toLowerCase();

  // Page data, not filter pickers: risk-rated material/vendor lists
  if (lowerUrl.includes("ordering=-risk_rating") && (lowerUrl.includes("/material/") || lowerUrl.includes("/vendor/"))) {
    return null;
  }

  // More specific patterns first (e.g. /material/gcn/ before /material/)
  if (lowerUrl.includes("/material/group/")) return "product_category";
  if (lowerUrl.includes("/material/gcn/")) return "gcn";
  if (lowerUrl.includes("/material-formulary/unique/")) return "formulary";
  if (lowerUrl.includes("/xplant-mat-stat/")) return "xplant_mat_stat";
  if (lowerUrl.includes("/custom-lists/")) return "custom_list";

  // Material list picker (has search/limit; not group, gcn, etc.)
  if (lowerUrl.includes("/material/") && (lowerUrl.includes("search=") || lowerUrl.includes("limit="))) return "material";
  // Vendor/supplier list picker
  if (lowerUrl.includes("/vendor/") && (lowerUrl.includes("search=") || lowerUrl.includes("limit="))) return "supplier_nbr";

  return null;
}

/**
 * Map gf_* keys to unified backend parameter keys
 */
const GF_TO_BACKEND_MAP: Record<string, string> = {
  gf_custom_list: "custom_list",
  gf_material: "material",
  gf_gcn: "gcn",
  gf_supplier: "supplier_nbr",
  gf_product_category: "product_category",
  gf_formulary: "formulary",
  gf_material_status: "xplant_mat_stat",
  gf_who_essential: "who_essential",
};

/**
 * Extract IDs from FilterValue objects and decode URL-encoded values
 */
function extractIds(value: any): string {
  if (value && typeof value === "object" && "id" in value) {
    const id = String((value as FilterValue).id);
    // Decode URL-encoded values (like %2C for commas)
    try {
      return decodeURIComponent(id);
    } catch (e) {
      // If decoding fails, return the original value
      return id;
    }
  }

  const stringValue = String(value);
  // Decode URL-encoded values (like %2C for commas)
  try {
    return decodeURIComponent(stringValue);
  } catch (e) {
    // If decoding fails, return the original value
    return stringValue;
  }
}

/**
 * Map global filters to unified backend parameters
 * Single value: param=value (e.g. supplier_nbr=41243423)
 * Multiple values: param=v1,v2,v3 (e.g. supplier_nbr=124234,3425352,34235345)
 */
export function mapGFToBackend(gfParams: Record<string, any>): Record<string, string> {
  const out: Record<string, string> = {};

  Object.entries(gfParams).forEach(([k, v]) => {
    if (!k.startsWith("gf_")) return;

    const backendKey = GF_TO_BACKEND_MAP[k];
    if (!backendKey) return;

    // Multi-value format: { ids: string[], labels: string[] }
    if (v && typeof v === "object" && "ids" in v && Array.isArray(v.ids)) {
      if (v.ids.length === 1) {
        out[backendKey] = String(v.ids[0]);
      } else if (v.ids.length > 1) {
        out[`${backendKey}`] = v.ids.join(",");
      }
      return;
    }

    // Legacy single value: { id: string, label: string }
    out[backendKey] = extractIds(v);
  });

  return out;
}

/**
 * Merge global and local params (component params win on conflicts)
 */
function mergeParams(globalParams: Record<string, string>, localParams: Record<string, any>): Record<string, any> {
  // Start with global params
  const result: Record<string, any> = { ...globalParams };

  // Override with local params (component wins)
  Object.entries(localParams).forEach(([key, value]) => {
    result[key] = value;
  });

  return result;
}

/**
 * Parse query params from a URL string
 */
function parseUrlParams(url: string): Record<string, string> {
  const params: Record<string, string> = {};

  // Split URL to get query string
  const queryString = url.includes("?") ? url.split("?")[1] : "";

  if (!queryString) return params;

  // Parse query string
  const searchParams = new URLSearchParams(queryString);
  searchParams.forEach((value, key) => {
    params[key] = value;
  });

  return params;
}

/**
 * Reconstruct URL with new params
 */
function reconstructUrl(url: string, params: Record<string, any>): string {
  // Split the URL into base path and query string
  const [basePath, existingQuery] = url.split("?");

  // Build new search params
  const searchParams = new URLSearchParams(existingQuery || "");

  // Add/update with merged params
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      const stringValue = String(value);
      // Decode URL-encoded values before setting
      try {
        const decodedValue = decodeURIComponent(stringValue);
        searchParams.set(key, decodedValue);
      } catch (e) {
        // If decoding fails, use the original value
        searchParams.set(key, stringValue);
      }
    }
  });

  const search = toWafSafeQueryString(searchParams);
  return search ? `${basePath}?${search}` : basePath;
}

/**
 * Install the global filters interceptor on the axios client
 */
export function installGlobalFiltersInterceptor(client: AxiosInstance) {
  client.interceptors.request.use((config: InternalAxiosRequestConfig) => {
    // Skip if global filters are disabled
    if (import.meta.env.VITE_ENABLE_GLOBAL_FILTERS === "false") {
      return config;
    }

    // Only apply to GET requests (configurable, but typical for filters)
    if (config.method && config.method.toUpperCase() !== "GET") {
      return config;
    }

    const path = location.pathname || "";
    const mode = modeFor(path);
    const reqUrl = config.url || "";

    // Skip if route mode is not APPLY
    if (mode !== "APPLY") {
      return config;
    }

    // Skip if this endpoint is page-specific excluded
    if (isPageSpecificExclusion(path, reqUrl)) {
      return config;
    }

    // Read global filters from Zustand store (SINGLE SOURCE OF TRUTH)
    let gf: Record<string, any> = {};
    try {
      gf = getGlobalFilters();
    } catch (e) {
      // Fallback to localStorage only if store read fails (shouldn't happen)
      console.warn("[GF Interceptor] Failed to read from store, falling back to localStorage:", e);
      try {
        gf = JSON.parse(localStorage.getItem("global_filters") || "{}");
      } catch (e2) {
        console.warn("[GF Interceptor] Failed to parse localStorage:", e2);
      }
    }

    // If no global filters, nothing to do
    if (Object.keys(gf).length === 0) {
      return config;
    }

    // Map gf_* keys to unified backend parameters (IDs only)
    let globalParams = mapGFToBackend(gf);

    // Don't apply a filter to its own dropdown API (e.g. material picker must not receive material=)
    const excludedParam = getExcludedParamForFilterSource(reqUrl);
    if (excludedParam) {
      delete globalParams[excludedParam];
    }

    // Get existing local params from config.params
    const localParamsFromConfig = (config.params || {}) as Record<string, any>;

    // Check if URL has embedded query params
    let localParamsFromUrl: Record<string, any> = {};
    if (reqUrl.includes("?")) {
      localParamsFromUrl = parseUrlParams(reqUrl);
    }

    // Merge: component params win on conflicts
    const localParams = { ...localParamsFromConfig, ...localParamsFromUrl };
    const merged = mergeParams(globalParams, localParams);

    // If URL had embedded params, reconstruct it with merged params
    if (reqUrl.includes("?")) {
      config.url = reconstructUrl(reqUrl, merged);
      config.params = {};
    } else {
      const searchParams = new URLSearchParams();
      Object.entries(merged).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          searchParams.set(key, String(value));
        }
      });
      const qs = toWafSafeQueryString(searchParams);
      config.url = qs ? `${reqUrl}?${qs}` : reqUrl;
      config.params = {};
    }

    return config;
  });
}

/**
 * Get the current mode for display purposes
 */
export function getCurrentMode(): "APPLY" | "SHOW_DISABLED" | "IGNORE" {
  return modeFor(location.pathname || "");
}
