import type { MaterialAction } from "@/lib/types";

/** Safe display name for who performed an action — never throws (handles null API user objects). */
export function formatMaterialActionActorLabel(action: unknown): string {
  try {
    if (action == null || typeof action !== "object") return "Unknown user";
    const user = (action as { user?: unknown }).user;
    if (user == null || typeof user !== "object") return "Unknown user";
    const rec = user as Record<string, unknown>;
    const first = typeof rec.first_name === "string" ? rec.first_name.trim() : "";
    const last = typeof rec.last_name === "string" ? rec.last_name.trim() : "";
    const combined = `${first} ${last}`.trim();
    return combined || "Unknown user";
  } catch {
    return "Unknown user";
  }
}

function parseActionInstant(iso: string | null | undefined): Date | null {
  try {
    if (iso == null || iso === "") return null;
    const date = new Date(iso);
    return Number.isNaN(date.getTime()) ? null : date;
  } catch {
    return null;
  }
}

export function formatMaterialActionDateOnly(iso: string | null | undefined): string {
  const date = parseActionInstant(iso);
  if (!date) return "unknown date";
  try {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return "unknown date";
  }
}

export function formatMaterialActionTimeOnly(iso: string | null | undefined): string {
  const date = parseActionInstant(iso);
  if (!date) return "unknown time";
  try {
    return date.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  } catch {
    return "unknown time";
  }
}

/**
 * Rationale from the feedback modal — prefers API shape `decision_feedback.decision_rationale`
 * (e.g. PATCH `action/{id}/decision-feedback/` response), then flat `decision_rationale`.
 */
export function getNoActionDecisionRationale(action: unknown): string | null {
  try {
    if (action == null || typeof action !== "object") return null;
    const a = action as Record<string, unknown>;
    const nested = a.decision_feedback;
    if (nested != null && typeof nested === "object") {
      const dr = (nested as Record<string, unknown>).decision_rationale;
      if (typeof dr === "string" && dr.trim() !== "") return dr.trim();
    }
    const flat = a.decision_rationale;
    if (typeof flat === "string" && flat.trim() !== "") return flat.trim();
    return null;
  } catch {
    return null;
  }
}

/** Combined date + time (legacy single-string tooltip lines). */
export function formatMaterialActionTimestamp(iso: string | null | undefined): string {
  const date = parseActionInstant(iso);
  if (!date) return "unknown date";
  try {
    return `${formatMaterialActionDateOnly(iso)}, at ${formatMaterialActionTimeOnly(iso)}`;
  } catch {
    return "unknown date";
  }
}

/** Short plain-language summary of what was done — never throws. */
export function getMaterialActionSummaryText(action: MaterialAction): string {
  try {
    const sub = action?.substituted_material;
    if (sub && typeof sub.vendor_name === "string") {
      const vendorDisplay = `${sub.vendor_name}${sub.vendor_nbr ? ` • ${sub.vendor_nbr}` : ""}`;
      return `Switched vendor to ${vendorDisplay}`;
    }
    const pa = action?.potential_action;
    if (pa && typeof pa.recommendation === "string") {
      return `Performed action: ${pa.recommendation}`;
    }
    if (action?.action === "no_action") {
      return "Marked as no action required";
    }
    return "Performed action";
  } catch {
    return "Action recorded";
  }
}
