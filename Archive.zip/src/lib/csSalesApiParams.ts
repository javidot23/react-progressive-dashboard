import type { CSalesTab } from "@/constants/csSalesTabs";
import type { CsSalesCurrentParams, CsSalesHistoricalParams } from "@/lib/apiServices";
import type { CSalesFilters } from "@/hooks/manage/sales/cs-sales-query-keys";
import { getCurrentApiParams, getHistoricalApiParams } from "@/lib/csSalesDateUtils";

export function buildCsSalesPeriodParams(
  tab: CSalesTab,
  filters?: CSalesFilters
): CsSalesHistoricalParams | CsSalesCurrentParams | null {
  const period = filters?.period ?? (tab === "historical" ? "Last 12 months" : "Month to date");
  const federal_cs_ind = filters?.federal_cs_ind;
  if (tab === "historical") {
    const hist = getHistoricalApiParams(period);
    if (!hist) return null;
    return { ...hist, state: filters?.state, federal_cs_ind };
  }
  const curr = getCurrentApiParams(period);
  if (!curr) return null;
  return { ...curr, state: filters?.state, federal_cs_ind };
}
