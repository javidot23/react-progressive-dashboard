export function computeMapTooltipPlacement(
  x: number,
  y: number,
  containerW: number,
  containerH: number,
  tooltipW: number,
  tooltipH: number,
  options?: { gap?: number; edgePadding?: number }
): { left: number; top: number; transform: string } {
  const gap = options?.gap ?? 12;
  const pad = options?.edgePadding ?? 8;

  const w = Math.max(tooltipW, 1);
  const h = Math.max(tooltipH, 1);

  let left = x + gap;
  if (left + w > containerW - pad) {
    left = x - w - gap;
  }
  left = Math.max(pad, Math.min(left, containerW - w - pad));

  const fitsAbove = y >= h + gap + pad;
  const fitsBelow = y + h + gap <= containerH - pad;

  let top: number;
  let transform: string;

  if (fitsAbove) {
    top = y - gap;
    transform = "translateY(-100%)";
  } else if (fitsBelow) {
    top = y + gap;
    transform = "none";
  } else {
    top = Math.max(pad, Math.min(y - h / 2, containerH - h - pad));
    transform = "none";
  }

  return { left, top, transform };
}
