interface GeoJSONFeature {
  type: string;
  id?: string;
  properties?: Record<string, unknown>;
  geometry: {
    type: "Polygon" | "MultiPolygon";
    coordinates: number[][][] | number[][][][];
  };
}

interface GeoJSONFeatureCollection {
  type: "FeatureCollection";
  features: GeoJSONFeature[];
}

function transformCoords(
  coords: number[][][] | number[][][][],
  centerLng: number,
  centerLat: number,
  scale: number,
  targetLng: number,
  targetLat: number
): number[][][] | number[][][][] {
  const transformPoint = (lng: number, lat: number): [number, number] => {
    const newLng = (lng - centerLng) * scale + targetLng;
    const newLat = (lat - centerLat) * scale + targetLat;
    return [newLng, newLat];
  };

  const transformRing = (ring: number[][]): number[][] => ring.map(([lng, lat]) => transformPoint(lng, lat));

  const transformPolygon = (polygon: number[][][]): number[][][] => polygon.map(ring => transformRing(ring));

  const isMultiPolygon = coords.length > 0 && Array.isArray(coords[0][0]) && Array.isArray(coords[0][0][0]);

  if (isMultiPolygon) {
    return (coords as number[][][][]).map(polygon => transformPolygon(polygon));
  }
  return transformPolygon(coords as number[][][]);
}

export function transformUsStatesForMainlandView(geojson: GeoJSONFeatureCollection): GeoJSONFeatureCollection {
  const features = geojson.features.map(feature => {
    const stateName = (feature.properties?.name as string) || "";

    if (stateName === "Alaska") {
      const centerLng = -153;
      const centerLat = 64;
      const scale = 0.25;
      const targetLng = -116;
      const targetLat = 24;

      return {
        ...feature,
        geometry: {
          ...feature.geometry,
          coordinates: transformCoords(feature.geometry.coordinates, centerLng, centerLat, scale, targetLng, targetLat),
        },
      };
    }

    if (stateName === "Hawaii") {
      const centerLng = -155.5;
      const centerLat = 20;
      const scale = 1.0;
      const targetLng = -120;
      const targetLat = 22;

      return {
        ...feature,
        geometry: {
          ...feature.geometry,
          coordinates: transformCoords(feature.geometry.coordinates, centerLng, centerLat, scale, targetLng, targetLat),
        },
      };
    }

    return feature;
  });

  return { ...geojson, features };
}
