// URL Query Parameter utilities for Purchase Order Filters

export const serializePurchaseOrderFilters = (filters: any, preserveGlobalFilters: boolean = true): URLSearchParams => {
  const params = new URLSearchParams();

  // Preserve existing global filters (gf_*) from current URL if requested
  if (preserveGlobalFilters && typeof window !== "undefined") {
    const currentParams = new URLSearchParams(window.location.search);
    currentParams.forEach((value, key) => {
      if (key.startsWith("gf_")) {
        params.append(key, value);
      }
    });
  }

  // Add local filter params
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "") {
      params.set(key, value.toString());
    }
  });

  return params;
};

export const deserializePurchaseOrderFilters = (searchParams: URLSearchParams): any => {
  const filters = {
    ordering: "-units_ordered",
    // All required filters for material-summary API
    units_ordered_min: null as number | null,
    units_ordered_max: null as number | null,
    units_received_on_time_min: null as number | null,
    units_received_on_time_max: null as number | null,
    units_received_late_min: null as number | null,
    units_received_late_max: null as number | null,
    units_not_received_min: null as number | null,
    units_not_received_max: null as number | null,
    inbound_fill_rate_min: null as number | null,
    inbound_fill_rate_max: null as number | null,
  };

  // Parse URL parameters
  for (const [key, value] of searchParams.entries()) {
    if (key in filters) {
      if (key === "ordering") {
        // Only use URL parameter if it's a valid Purchase Order field
        const validPOFields = [
          "material_name",
          "units_ordered",
          "units_received_on_time",
          "units_received_late",
          "units_not_received",
          "inbound_fill_rate",
        ];
        const field = value.startsWith("-") ? value.substring(1) : value;
        if (validPOFields.includes(field)) {
          (filters as any)[key] = value;
        }
      } else {
        // Convert numeric values
        const numValue = Number(value);
        if (!isNaN(numValue)) {
          (filters as any)[key] = numValue;
        }
      }
    }
  }

  return filters;
};

// URL Query Parameter utilities for Purchase History Filters

export const serializePurchaseHistoryFilters = (filters: any, preserveGlobalFilters: boolean = true): URLSearchParams => {
  const params = new URLSearchParams();

  // Preserve existing global filters (gf_*) from current URL if requested
  if (preserveGlobalFilters && typeof window !== "undefined") {
    const currentParams = new URLSearchParams(window.location.search);
    currentParams.forEach((value, key) => {
      if (key.startsWith("gf_")) {
        params.append(key, value);
      }
    });
  }

  // Add local filter params
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "") {
      params.set(key, value.toString());
    }
  });

  return params;
};

export const deserializePurchaseHistoryFilters = (searchParams: URLSearchParams): any => {
  const filters = {
    ordering: "ordered_date",
    material_id: null as string | null,
    // All required filters for purchase-order API
    original_order_qty_min: null as number | null,
    original_order_qty_max: null as number | null,
    received_qty_min: null as number | null,
    received_qty_max: null as number | null,
    units_received_on_time_min: null as number | null,
    units_received_on_time_max: null as number | null,
    units_received_late_min: null as number | null,
    units_received_late_max: null as number | null,
    units_not_received_min: null as number | null,
    units_not_received_max: null as number | null,
  };

  // Parse URL parameters
  for (const [key, value] of searchParams.entries()) {
    if (key in filters) {
      if (key === "ordering") {
        // Only use URL parameter if it's a valid Purchase History field
        const validPHFields = [
          "ordered_date",
          "anticipated_date",
          "original_order_qty",
          "received_qty",
          "units_received_on_time",
          "units_received_late",
          "units_not_received",
        ];
        const field = value.startsWith("-") ? value.substring(1) : value;
        if (validPHFields.includes(field)) {
          (filters as any)[key] = value;
        }
      } else if (key === "material_id") {
        (filters as any)[key] = value;
      } else {
        // Convert numeric values
        const numValue = Number(value);
        if (!isNaN(numValue)) {
          (filters as any)[key] = numValue;
        }
      }
    }
  }

  return filters;
};
