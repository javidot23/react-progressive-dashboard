import { formatUsDateFromIso } from "@/lib/usFormat";

export function formatRelativeTimeShort(isoString: string): string {
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return isoString;

  const now = Date.now();
  const diffMs = now - d.getTime();
  if (diffMs < 0) return formatUsDateFromIso(isoString);

  const sec = Math.floor(diffMs / 1000);
  if (sec < 60) return "now";

  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;

  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;

  const day = Math.floor(hr / 24);
  if (day < 7) return `${day}d ago`;

  return formatUsDateFromIso(isoString);
}
