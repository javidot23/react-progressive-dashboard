/**
 * Types for the "issues at native granularity" feature.
 *
 * The backend now surfaces each issue at the level it was originally recorded
 * (material / gcn / ndc / fei / hicl / *_plant) instead of collapsing everything
 * to the material level. This module holds:
 *  - the raw API shapes for `GET /issue/all/` and `GET /issue/<id>/materials/`, and
 *  - `GranularityIssueView`, the single view-model the feed card and table consume
 *    (replacing the three drifting local `IssueData` interfaces).
 */

import type { IssueNote } from "@/services/issueNotesService";

/** Grain a supply-chain issue can be recorded at (from `IssueAtGranularitySerializer`). */
export type GranularityType = "material" | "material_plant" | "gcn" | "gcn_plant" | "ndc" | "fei" | "hicl" | "unknown";

/** Driving supply-chain event (SupplyChainEventMinimalSerializer). */
export interface DrivingEvent {
  id: number;
  event_id: string;
  type: string;
  type_description: string | null;
  status: string;
  start_date: string | null;
  end_date: string | null;
  latitude: number | null;
  longitude: number | null;
  city: string | null;
  state: string | null;
  country: string | null;
  mat_nbr: string | null;
  metadata: string | null;
  scrm_mat_grp: string | null;
  created_at?: string;
  updated_at?: string;
}

/** Vendor as nested on a material row. */
export interface GranularityVendor {
  id: number;
  name: string;
  driving_risk?: string;
  vendor_nbr?: string | null;
}

/**
 * Full nested material (MaterialWithVendorSerializer) — populated only for the
 * `material` / `material_plant` grains; `null` for gcn/ndc/fei/hicl.
 */
export interface GranularityIssueMaterial {
  id: number;
  mat_nbr: string;
  name: string;
  ndc: string | null;
  ean_n4_nbr_11?: string | null;
  risk_rating: number;
  driving_risk: string;
  dollars_at_risk: number;
  xplant_mat_stat?: string | null;
  fdb_gcn_seq_nbr?: string | null;
  vendor?: GranularityVendor | null;
}

/** A row from `GET /issue/all/` (IssueAtGranularityListSerializer). */
export interface IssueAtGranularityApiData {
  id: number;
  issue_nbr: string;
  event_id: string | null;
  status: string;
  date_identified: string | null;
  start_date: string | null;
  granularity_type: GranularityType;

  // Grain identifier columns — only the one matching the grain is populated.
  fdb_gcn_seq_nbr: string | null;
  ndc: string | null;
  fei_number: string | null;
  hicl: string | null;
  hicl_description: string | null;
  plant: string | null;
  material: GranularityIssueMaterial | null;

  // Grain-aware aggregated ("effective") metrics.
  impacted_material_count: number;
  effective_risk_rating: number;
  effective_dollars_at_risk: number;
  effective_risk_adjusted_value: number;

  driving_event: DrivingEvent | null;
  has_actions: boolean;
  /** Full action records — present on `GET /issue/<id>/` only. */
  actions?: unknown[];
  /** Recommended actions — present on `GET /issue/<id>/` only. */
  potential_actions?: unknown[];
  notes_count: number;
  last_note: IssueNote | null;
  group: string | null;
  persona: string | null;
  created_at?: string;
  updated_at?: string;
}

/**
 * A material impacted by an issue (IssueImpactedMaterialSerializer = all Material
 * columns + vendor + vendor_nbr). Explicit fields are the ones the UI reads; the
 * serializer returns `__all__`, so extra columns may be present.
 */
export interface IssueImpactedMaterialApiData {
  id: number;
  mat_nbr: string;
  name: string;
  ndc: string | null;
  vendor: string | null;
  vendor_nbr: string | null;
  risk_rating: number;
  driving_risk: string;
  dollars_at_risk: number;
  /** Annotated on the impacted-materials response (risk_rating * dollars_at_risk). */
  risk_adjusted_value?: number | null;
  dollars_at_risk_this_week?: number;
  dollars_at_risk_prev_week?: number;
  market_share?: number | null;
  saleable_qty_on_hand?: number | null;
  unrestricted_qty_on_hand?: number | null;
  forecast_qty_7day?: number | null;
  unfilled_qty?: number | null;
  cost_per_unit?: number | null;
  avg_shortage_duration?: number | null;
  otif_percentage?: number | null;
  material_group?: string | null;
  product_family?: string | null;
  fdb_gcn_seq_nbr?: string | null;
  hicl?: string | null;
  hicl_description?: string | null;
  xplant_mat_stat?: string | null;
  who_essential_flg?: boolean | null;
  inj_flg?: boolean | null;
  short_date_flg?: boolean | null;
  drop_ship_flg?: boolean | null;
  fee_for_service_flg?: boolean | null;
  dqsa_exempt_flg?: boolean | null;
  [key: string]: unknown;
}

/**
 * Single view-model consumed by the feed card and table. Superset of the former
 * material-only `IssueData` (kept for the single-material path) plus the
 * granularity fields the mixed feed needs.
 */
export interface GranularityIssueView {
  // Identity
  id: number;
  issueNbr?: string;

  // Grain — optional so legacy material-only producers (e.g. Manage — Supply
  // Management, which reuses IssueCard/IssueTableView) still satisfy the type
  // and render the single-material layout. The native-granularity feed populates them.
  granularityType?: GranularityType;
  /** Human label for the grain, e.g. "GCN", "NDC", "Facility·FEI". */
  granularityLabel?: string;
  /** The populated grain identifier (mono), e.g. GCN seq / NDC / FEI / HICL / mat_nbr. */
  granularityValue?: string;
  /** count === 1 → route straight to the per-material drill-through. */
  isSingleMaterial?: boolean;
  impactedMaterialCount?: number;

  // Aggregated metrics
  riskLevel: number; // round(effective_risk_rating * 100), 0–100
  effectiveRiskRating?: number; // 0–1
  effectiveDollarsAtRisk?: number;
  riskExposure: string; // formatted "$X / $Y" (or aggregate $)

  // Driving risk / event
  drivingRisk: string;
  drivingRiskRaw?: string;
  drivingEvent?: DrivingEvent | null;

  // Issue context
  status?: string;
  group?: string | null;
  persona?: string | null;
  dateIdentified?: string | null;
  createdAt: string; // pre-formatted display date
  isNewIssue: boolean;
  actionStatus: string;
  isCritical: boolean;
  hasActions: boolean;
  /** Full action records when mapped from `GET /issue/<id>/`. */
  actions?: unknown[];
  potentialActions?: unknown[];
  lastNote?: IssueNote | null;
  notesCount?: number;

  // Material-grain detail (present when the grain is a single material)
  productName: string;
  material: string;
  mat_nbr: string;
  ndc: string;
  ean: string;
  materialId?: number;
  dollarsAtRisk?: number;
  vendorName?: string;
  vendorNbr?: string;
  vendorId?: number;
  xplantMatStat?: string;
  xplantMatStatDesc?: string;
}
