import { isSalesTimelineWeeklyItem, type SalesTimelineItem } from "@/lib/apiServices";
import { formatMonthYearChartLabel, formatWeekLabel } from "@/lib/csSalesChangeTrackingConstants";
import { getDateRangeFromCurrentPeriod, getHistoricalApiParams } from "@/lib/csSalesDateUtils";

export type SalesTimelineHighlightAxisRanges = {
  ppStartLabel: string | null;
  ppEndLabel: string | null;
  cpStartLabel: string | null;
  cpEndLabel: string | null;
};

const EMPTY: SalesTimelineHighlightAxisRanges = {
  ppStartLabel: null,
  ppEndLabel: null,
  cpStartLabel: null,
  cpEndLabel: null,
};

function ymKey(year: number, month: number): string {
  return `${year}-${String(month).padStart(2, "0")}`;
}

/** Last N calendar months ending at (endYear, endMonth), and the same N months one year earlier. */
function historicalCompareMonthKeys(
  endYear: number,
  endMonth: number,
  monthsCount: number
): { cpKeys: Set<string>; ppKeys: Set<string> } {
  const cpMonths: { year: number; month: number }[] = [];
  let y = endYear;
  let m = endMonth;
  for (let i = 0; i < monthsCount; i++) {
    cpMonths.push({ year: y, month: m });
    m -= 1;
    if (m < 1) {
      m = 12;
      y -= 1;
    }
  }
  return {
    cpKeys: new Set(cpMonths.map(({ year, month }) => ymKey(year, month))),
    ppKeys: new Set(cpMonths.map(({ year, month }) => ymKey(year - 1, month))),
  };
}

function parseYmdLocal(ymd: string): Date {
  const [y, m, d] = ymd.split("-").map(Number);
  return new Date(y, m - 1, d);
}

function addDaysLocal(d: Date, days: number): Date {
  const out = new Date(d);
  out.setDate(out.getDate() + days);
  return out;
}

/** Monday 00:00 local of the ISO-style week containing `d` (week starts Monday). */
function getMondayContaining(d: Date): Date {
  const result = new Date(d);
  const day = result.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  result.setDate(result.getDate() + diff);
  return result;
}

/** Monday-based week overlaps [from, to] inclusive on calendar dates. */
function weekOverlapsRange(weekStartYmd: string, rangeFromYmd: string, rangeToYmd: string): boolean {
  const ws = parseYmdLocal(weekStartYmd);
  const we = addDaysLocal(ws, 6);
  const rf = parseYmdLocal(rangeFromYmd);
  const rt = parseYmdLocal(rangeToYmd);
  return ws <= rt && we >= rf;
}

/** How many Monday-based week buckets intersect a date range (matches chart granularity). */
function countWeekBarsOverlappingRange(rangeFromYmd: string, rangeToYmd: string): number {
  const rf = parseYmdLocal(rangeFromYmd);
  const rt = parseYmdLocal(rangeToYmd);
  let monday = getMondayContaining(rf);
  let count = 0;
  while (monday.getTime() <= rt.getTime()) {
    const sunday = addDaysLocal(monday, 6);
    if (sunday.getTime() >= rf.getTime()) {
      count++;
    }
    monday = addDaysLocal(monday, 7);
  }
  return count;
}

function collectWeeklyLabelsInOrder(timelineData: readonly SalesTimelineItem[]): {
  labels: string[];
  weekStarts: string[];
} {
  const labels: string[] = [];
  const weekStarts: string[] = [];
  for (const item of timelineData) {
    if (!isSalesTimelineWeeklyItem(item)) continue;
    weekStarts.push(item.week_start);
    labels.push(formatWeekLabel(item.week_start));
  }
  return { labels, weekStarts };
}

function toAxisRange(pp: string[], cp: string[]): SalesTimelineHighlightAxisRanges {
  return {
    ppStartLabel: pp.length ? pp[0] : null,
    ppEndLabel: pp.length ? pp[pp.length - 1] : null,
    cpStartLabel: cp.length ? cp[0] : null,
    cpEndLabel: cp.length ? cp[cp.length - 1] : null,
  };
}

/**
 * X-axis category labels spanning PP vs CP comparison windows for the sales timeline charts.
 */
export function computeSalesTimelineHighlightAxisRanges(
  activeTab: "historical" | "current",
  period: string,
  timelineData: readonly SalesTimelineItem[]
): SalesTimelineHighlightAxisRanges {
  const hasMonthly = timelineData.some(item => !isSalesTimelineWeeklyItem(item));

  if (activeTab === "historical" && hasMonthly) {
    const hist = getHistoricalApiParams(period);
    if (hist == null) return EMPTY;
    const { cpKeys, ppKeys } = historicalCompareMonthKeys(hist.end_year, hist.end_month, hist.months);
    const pp: string[] = [];
    const cp: string[] = [];
    for (const item of timelineData) {
      if (isSalesTimelineWeeklyItem(item)) continue;
      const key = ymKey(item.year, item.month);
      const label = formatMonthYearChartLabel(item.year, item.month);
      if (ppKeys.has(key)) pp.push(label);
      if (cpKeys.has(key)) cp.push(label);
    }
    return toAxisRange(pp, cp);
  }

  if (activeTab === "current") {
    const ranges = getDateRangeFromCurrentPeriod(period);
    if (ranges == null) return EMPTY;

    const { labels, weekStarts } = collectWeeklyLabelsInOrder(timelineData);
    if (labels.length === 0) return EMPTY;

    const nPp = countWeekBarsOverlappingRange(ranges.previous_date_from, ranges.previous_date_to);
    const nCp = countWeekBarsOverlappingRange(ranges.date_from, ranges.date_to);

    const pp: string[] = [];
    const cp: string[] = [];
    for (let i = 0; i < weekStarts.length; i++) {
      const ws = weekStarts[i];
      const label = labels[i];
      const inPp = weekOverlapsRange(ws, ranges.previous_date_from, ranges.previous_date_to);
      const inCp = weekOverlapsRange(ws, ranges.date_from, ranges.date_to);
      if (inPp && inCp) {
        pp.push(label);
      } else if (inPp) {
        pp.push(label);
      } else if (inCp) {
        cp.push(label);
      }
    }

    // Rolling-window payload: comparison may extend past the last returned week (e.g. MTD CP in April
    // but series ends in March). Fill missing side using the expected week counts from the API ranges.
    if (cp.length === 0 && nCp > 0) {
      const k = Math.min(nCp, labels.length);
      cp.push(...labels.slice(labels.length - k));
    }
    if (pp.length === 0 && nPp > 0) {
      const beforeCp = labels.length - cp.length;
      const from = Math.max(0, beforeCp - nPp);
      pp.push(...labels.slice(from, beforeCp));
    }

    return toAxisRange(pp, cp);
  }

  return EMPTY;
}
