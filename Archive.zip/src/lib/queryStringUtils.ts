/**
 * Serialize URLSearchParams for Azure App Gateway / WAF compatibility.
 *
 * URLSearchParams encodes `/` as %2F and `,` as %2C. Common WAF rules (e.g. OWASP
 * REQUEST-920) block %2F in query strings as a path-traversal defense. Our backend
 * expects raw slashes and commas in filter values (e.g. variant portal product family names
 * like "butalb/acetaminophen/caffeine---TABLET").
 */
export function toWafSafeQueryString(params: URLSearchParams): string {
  return params.toString().replace(/%2C/gi, ",").replace(/%2F/gi, "/");
}
