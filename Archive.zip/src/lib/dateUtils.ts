/** Local date utilities - no external date libraries. YYYY-MM-DD format. */

const ISO_REGEX = /^\d{4}-\d{2}-\d{2}$/;

export function dateToISO(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseISO(str: string | null | undefined): Date | null {
  if (!str || typeof str !== "string" || !ISO_REGEX.test(str)) return null;
  const d = new Date(str + "T12:00:00");
  return isNaN(d.getTime()) ? null : d;
}

export function isValidISO(str: string | null | undefined): boolean {
  return parseISO(str) !== null;
}

export function startOfWeek(d: Date): Date {
  const copy = new Date(d);
  const day = copy.getDay();
  const diff = copy.getDate() - day + (day === 0 ? -6 : 1);
  copy.setDate(diff);
  copy.setHours(0, 0, 0, 0);
  return copy;
}

export function endOfWeek(d: Date): Date {
  const start = startOfWeek(d);
  const end = new Date(start);
  end.setDate(end.getDate() + 6);
  end.setHours(23, 59, 59, 999);
  return end;
}

export function startOfMonth(d: Date): Date {
  const copy = new Date(d);
  copy.setDate(1);
  copy.setHours(0, 0, 0, 0);
  return copy;
}

export function endOfMonth(d: Date): Date {
  const copy = new Date(d);
  copy.setMonth(copy.getMonth() + 1, 0);
  copy.setHours(23, 59, 59, 999);
  return copy;
}

export function subWeeks(d: Date, n: number): Date {
  const copy = new Date(d);
  copy.setDate(copy.getDate() - 7 * n);
  return copy;
}

export function subMonths(d: Date, n: number): Date {
  const copy = new Date(d);
  copy.setMonth(copy.getMonth() - n);
  return copy;
}

export function isSameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

export function isBeforeOrSame(a: Date, b: Date): boolean {
  return a.getTime() <= b.getTime();
}

export function isAfter(a: Date, b: Date): boolean {
  return a.getTime() > b.getTime();
}

export function minDate(...dates: Date[]): Date {
  return new Date(Math.min(...dates.map(d => d.getTime())));
}

export function maxDate(...dates: Date[]): Date {
  return new Date(Math.max(...dates.map(d => d.getTime())));
}

export function getToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

export function getYesterdayIso(): string {
  const yesterday = getToday();
  yesterday.setDate(yesterday.getDate() - 1);
  return dateToISO(yesterday);
}

export const DEFAULT_MIN_DATE = new Date(2000, 0, 1);

/**
 * Safely format a YYYY-MM-DD API date string for display.
 * Uses parseISO (noon local time) to avoid the UTC-midnight timezone shift where
 * bare `new Date("YYYY-MM-DD")` can display one day behind for users in UTC-offset timezones.
 * Always use this (or parseISO) when rendering API date strings. Never use `new Date(apiDateStr)` directly for display.
 */
export function formatApiDate(
  dateStr: string | null | undefined,
  options: Intl.DateTimeFormatOptions = { month: "short", day: "numeric" }
): string {
  const d = parseISO(dateStr);
  if (!d) return "";
  return d.toLocaleDateString("en-US", options);
}

export function formatDateRangeDisplay(fromValue: string, toValue: string): string {
  const from = parseISO(fromValue);
  const to = parseISO(toValue);
  if (!from || !to) return "";
  if (isAfter(from, to)) return "";
  return `${from.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })} – ${to.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`;
}

export function isValidDateRange(fromValue: string, toValue: string): boolean {
  const from = parseISO(fromValue);
  const to = parseISO(toValue);
  if (!from || !to) return false;
  if (isAfter(from, to)) return false;
  return true;
}
