import axios, {
  AxiosInstance,
  AxiosResponse,
  InternalAxiosRequestConfig,
  AxiosError,
} from 'axios';
import { installGlobalFiltersInterceptor } from './globalFiltersInterceptor';
import {
  redirectToLogin,
  getApiBaseUrlFromEnv,
  isPublicAuthPath,
} from './authUrls';

declare module 'axios' {
  interface AxiosRequestConfig {
    /** When true, 401 does not trigger full-page redirect to /auth/login/. */
    skipAuthRedirect?: boolean;
  }
}

export type ApiRequestConfig = InternalAxiosRequestConfig;

// Event emitter for auth failures (policy 401s, etc.)
type AuthFailureListener = () => void;
let authFailureListeners: AuthFailureListener[] = [];

let authRedirectSuppressed = false;

export function suppressAuthRedirects(): void {
  authRedirectSuppressed = true;
}

export function resetAuthRedirectSuppression(): void {
  authRedirectSuppressed = false;
}

export function shouldRedirectOnUnauthorized(
  config?: { skipAuthRedirect?: boolean } | null
): boolean {
  if (authRedirectSuppressed) return false;
  if (config?.skipAuthRedirect) return false;
  if (isPublicAuthPath()) return false;
  return true;
}

export const onAuthFailure = (callback: AuthFailureListener) => {
  authFailureListeners.push(callback);
  return () => {
    authFailureListeners = authFailureListeners.filter((cb) => cb !== callback);
  };
};

const notifyAuthFailure = () => {
  authFailureListeners.forEach((callback) => callback());
};

const UNSAFE_METHODS = new Set(['post', 'put', 'patch', 'delete']);

function getCsrfToken(): string | null {
  if (typeof document === 'undefined') return null;
  const match = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]*)/);
  if (!match) return null;
  try {
    return decodeURIComponent(match[1]);
  } catch {
    return match[1];
  }
}

const apiClient: AxiosInstance = axios.create({
  baseURL: getApiBaseUrlFromEnv(),
  timeout: 120000,
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const method = (config.method ?? 'get').toLowerCase();
    if (UNSAFE_METHODS.has(method)) {
      const csrf = getCsrfToken();
      if (csrf) {
        config.headers.set('X-CSRFToken', csrf);
      } else if (import.meta.env.DEV) {
        console.warn('[apiClient] Missing csrftoken cookie for', method.toUpperCase(), config.url);
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

interface ApiErrorBody {
  code?: string;
  error?: string;
  success?: boolean;
  type?: string;
}

export const DOMAIN_NOT_ALLOWED_CODE = 'domain_not_allowed';
export const EMAIL_NOT_ALLOWED_CODE = 'email_not_allowed';

export class DomainNotAllowedError extends Error {
  code = DOMAIN_NOT_ALLOWED_CODE;
  constructor(message: string = 'Access denied') {
    super(message);
    this.name = 'DomainNotAllowedError';
  }
}

export class EmailNotAllowedError extends Error {
  code = EMAIL_NOT_ALLOWED_CODE;
  constructor(message: string = 'Access denied') {
    super(message);
    this.name = 'EmailNotAllowedError';
  }
}

apiClient.interceptors.response.use(
  (response: AxiosResponse) => response,
  async (error: AxiosError) => {
    const errorBody = error.response?.data as ApiErrorBody | undefined;

    if (error.response?.status === 401 && errorBody?.code === DOMAIN_NOT_ALLOWED_CODE) {
      notifyAuthFailure();
      return Promise.reject(new DomainNotAllowedError(errorBody.error || 'Access denied'));
    }

    if (error.response?.status === 401 && errorBody?.code === EMAIL_NOT_ALLOWED_CODE) {
      notifyAuthFailure();
      return Promise.reject(new EmailNotAllowedError(errorBody.error || 'Access denied'));
    }

    if (error.response?.status === 401) {
      if (shouldRedirectOnUnauthorized(error.config)) {
        redirectToLogin();
      }
      const authError = new Error('SESSION_EXPIRED');
      authError.name = 'AuthenticationError';
      return Promise.reject(authError);
    }

    if (error.response?.status === 403) {
      console.warn('Access forbidden - insufficient permissions');
    }

    return Promise.reject(error);
  }
);

installGlobalFiltersInterceptor(apiClient);

export { redirectToLogin } from './authUrls';
export default apiClient;
