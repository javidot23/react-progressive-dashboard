import { useManageSalesCsFilterStore, getManageSalesCsFilterVersion } from "@/stores/manageSalesCsFilterStore";

export const MANAGE_SALES_OVERVIEW_PATH = "/manage/sales/overview";

export function tenantHasControlledSubstances(indicators: string[]): boolean {
  return indicators.some(code => code !== "NC");
}

export function buildCsScheduleApiParams(federal_cs_ind?: string): { federal_cs_ind?: string } {
  if (!federal_cs_ind) return {};
  return { federal_cs_ind };
}

export function isManageSalesOverviewRoute(): boolean {
  return typeof location !== "undefined" && location.pathname.startsWith(MANAGE_SALES_OVERVIEW_PATH);
}

/** CS schedule params for Sales Overview API calls (only on overview route). */
export function getManageSalesOverviewCsParams(): { federal_cs_ind?: string } {
  if (!isManageSalesOverviewRoute()) return {};
  const { federal_cs_ind } = useManageSalesCsFilterStore.getState();
  return buildCsScheduleApiParams(federal_cs_ind);
}

export function isSalesOverviewCacheStale(
  cachedGfVersion: number | undefined,
  currentGfVersion: number,
  cachedCsVersion: number | undefined
): boolean {
  const gfStale = cachedGfVersion !== undefined && cachedGfVersion !== currentGfVersion;
  const csStale =
    isManageSalesOverviewRoute() && cachedCsVersion !== undefined && cachedCsVersion !== getManageSalesCsFilterVersion();
  return gfStale || csStale;
}

export function attachSalesOverviewCacheVersions<T>(data: T, gfVersion: number): T {
  const stamped = data as T & { _gfVersion?: number; _csFilterVersion?: number };
  stamped._gfVersion = gfVersion;
  if (isManageSalesOverviewRoute()) {
    stamped._csFilterVersion = getManageSalesCsFilterVersion();
  }
  return stamped;
}
