import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { MaterialWithIssues } from "@/lib/types";
import { VendorListFilters } from "@/lib/apiServices";
import { getDrivingRiskLabel } from "@/lib/drivingRiskLabels";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const formatDateTime = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

export const transformMaterialsData = (
  materialsWithIssues: MaterialWithIssues[],
  getDisplayName?: (risk: string) => string
): MaterialWithIssues[] => {
  return materialsWithIssues.map(material => {
    const primaryRiskLabel = getDisplayName
      ? (getDisplayName(material.driving_risk) ?? material.driving_risk)
      : getDrivingRiskLabel(material.driving_risk);
    return {
      ...material,
      risk_score: Math.round(material.risk_rating * 100),
      primary_risk: primaryRiskLabel,
      risk_adjusted_value: `$${Math.round(material.dollars_at_risk)}`,
      action_status:
        material.open_issues.length > 0 ? "Not Reviewed" : ("Reviewed" as "Reviewed" | "Not Reviewed" | "In Progress"),
      ndc: material.ndc || material.ean_n4_nbr_11,
      material_id: material.mat_nbr,
    };
  });
};

export const formatCurrency = (value: string | number | undefined, showDashForZero: boolean = false): string => {
  if (!value || value === 0) return showDashForZero ? "-" : "$0";

  const numValue = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(numValue)) return showDashForZero ? "-" : "$0";

  return `$${numValue.toLocaleString()}`;
};

export const formatNumber = (
  value: string | number | undefined,
  options: { showDashForZero?: boolean; prefix?: string; suffix?: string } = {}
): string => {
  const { showDashForZero = false, prefix = "", suffix = "" } = options;

  if (!value || value === 0) return showDashForZero ? "-" : `${prefix}0${suffix}`;

  const numValue = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(numValue)) return showDashForZero ? "-" : `${prefix}0${suffix}`;

  let formattedValue: string;

  if (numValue >= 1_000_000) {
    formattedValue = `${(numValue / 1_000_000).toFixed(2)}M`;
  } else if (numValue >= 1_000) {
    formattedValue = `${(numValue / 1_000).toFixed(2)}K`;
  } else {
    formattedValue = numValue.toLocaleString("en-US", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    });
  }

  return `${prefix}${formattedValue}${suffix}`;
};

export const formatCurrencyCompact = (value: string | number | undefined, showDashForZero: boolean = false): string => {
  return formatNumber(value, { showDashForZero, prefix: "$" });
};

/**
 * Maps xplant_mat_stat code to its description
 * @param code - The xplant_mat_stat code (e.g., "AC", "UM", "AM", etc.)
 * @returns The description string or the original code if not found
 */
export const getMaterialStatusDescription = (code: string | undefined | null): string => {
  if (!code) return "-";

  const statusMap: Record<string, string> = {
    AC: "Active",
    UM: "Temp Unavail from Mfg",
    AM: "Allocated by Mfg",
    NW: "New",
    DB: "Discontinued by ABC",
    TM: "LongTerm Unavail from Mfg",
    DM: "Discontinued by Mfg",
  };

  return statusMap[code] || code;
};

/** Material group / product category codes — display names for global filters and UI. */
const PRODUCT_CATEGORY_LABELS: Record<string, string> = {
  BRX: "Branded RX (BRX)",
  GMR: "General Merchandise (GMR)",
  GRX: "Generic RX (GRX)",
  HBC: "Branded HBC (HBC)",
  HBG: "Generic HBC (HBG)",
  HHC: "Home Health Care (HHC)",
  MSU: "Medical Supplies (MSU)",
  MRX: "Medical Device Rx (MRX)",
  NMA: "Non Material (NMA)",
  OTC: "Branded OTC (OTC)",
  OTG: "Generic OTC (OTG)",
  SSU: "Stores Supplies (SSU)",
  "01": "Warengruppe 1 (01)",
  "02": "Warengruppe 2 (02)",
};

export const getProductCategoryLabel = (code: string | undefined | null): string => {
  if (code == null || code === "") return "-";
  const key = code.trim();
  return PRODUCT_CATEGORY_LABELS[key] ?? key;
};

/** Contract type codes from `/material-formulary/unique/` share the same material-group mapping. */
export const getFormularyContractTypeLabel = getProductCategoryLabel;

export interface RiskRatingColors {
  label: string;
  verticalLineClass: string;
  labelBackgroundClass: string;
  labelBorderClass: string;
  labelTextClass: string;
}

/**
 * Maps risk rating to appropriate colors and label text
 * @param riskRating - Risk rating value between 0 and 1
 * @returns Object containing label text and CSS classes for styling
 */
export function getRiskRatingColors(riskRating: number): RiskRatingColors {
  if (riskRating >= 0.0 && riskRating <= 0.2) {
    return {
      label: "Highly Unlikely",
      verticalLineClass: "bg-green-600",
      labelBackgroundClass: "bg-green-50",
      labelBorderClass: "border-core-green-500",
      labelTextClass: "text-core-green-600",
    };
  } else if (riskRating >= 0.21 && riskRating <= 0.4) {
    return {
      label: "Unlikely",
      verticalLineClass: "bg-green-600",
      labelBackgroundClass: "bg-green-50",
      labelBorderClass: "border-core-green-500",
      labelTextClass: "text-core-green-600",
    };
  } else if (riskRating >= 0.41 && riskRating <= 0.6) {
    return {
      label: "Even Chance",
      verticalLineClass: "bg-warning-600",
      labelBackgroundClass: "bg-warning-50",
      labelBorderClass: "border-warning-500",
      labelTextClass: "text-warning-600",
    };
  } else if (riskRating >= 0.61 && riskRating <= 0.8) {
    return {
      label: "Likely",
      verticalLineClass: "bg-warning-600",
      labelBackgroundClass: "bg-warning-50",
      labelBorderClass: "border-warning-500",
      labelTextClass: "text-warning-600",
    };
  } else if (riskRating >= 0.81 && riskRating <= 1.0) {
    return {
      label: "Highly Likely",
      verticalLineClass: "bg-red-600",
      labelBackgroundClass: "bg-danger-50",
      labelBorderClass: "border-danger-200",
      labelTextClass: "text-danger-600",
    };
  } else {
    // Fallback for invalid values
    return {
      label: "Unknown",
      verticalLineClass: "bg-core-gray-300",
      labelBackgroundClass: "bg-core-gray-50",
      labelBorderClass: "border-core-gray-200",
      labelTextClass: "text-core-gray-500",
    };
  }
}

/**
 * Maps risk rating to reversed colors and label text (high scores = green, low scores = red)
 * @param riskRating - Risk rating value between 0 and 1
 * @returns Object containing label text and CSS classes for styling
 */
export function getReversedRiskRatingColors(riskRating: number): RiskRatingColors {
  if (riskRating >= 0.0 && riskRating <= 0.2) {
    return {
      label: "Highly Unlikely",
      verticalLineClass: "bg-red-600",
      labelBackgroundClass: "bg-danger-50",
      labelBorderClass: "border-danger-200",
      labelTextClass: "text-danger-600",
    };
  } else if (riskRating >= 0.21 && riskRating <= 0.4) {
    return {
      label: "Unlikely",
      verticalLineClass: "bg-red-600",
      labelBackgroundClass: "bg-danger-50",
      labelBorderClass: "border-danger-200",
      labelTextClass: "text-danger-600",
    };
  } else if (riskRating >= 0.41 && riskRating <= 0.6) {
    return {
      label: "Even Chance",
      verticalLineClass: "bg-warning-600",
      labelBackgroundClass: "bg-warning-50",
      labelBorderClass: "border-warning-500",
      labelTextClass: "text-warning-600",
    };
  } else if (riskRating >= 0.61 && riskRating <= 0.8) {
    return {
      label: "Likely",
      verticalLineClass: "bg-green-600",
      labelBackgroundClass: "bg-green-50",
      labelBorderClass: "border-green-500",
      labelTextClass: "text-green-600",
    };
  } else if (riskRating >= 0.81 && riskRating <= 1.0) {
    return {
      label: "Highly Likely",
      verticalLineClass: "bg-green-600",
      labelBackgroundClass: "bg-green-50",
      labelBorderClass: "border-green-500",
      labelTextClass: "text-green-600",
    };
  } else {
    // Fallback for invalid values
    return {
      label: "Unknown",
      verticalLineClass: "bg-core-gray-300",
      labelBackgroundClass: "bg-core-gray-50",
      labelBorderClass: "border-core-gray-200",
      labelTextClass: "text-core-gray-500",
    };
  }
}

/**
 * Serializes filter object to URL search parameters
 * Excludes pagination parameters (limit, offset) and empty values
 */
export const serializeFiltersToUrl = (filters: VendorListFilters, preserveGlobalFilters: boolean = true): URLSearchParams => {
  const params = new URLSearchParams();

  // Preserve existing global filters (gf_*) from current URL if requested
  if (preserveGlobalFilters && typeof window !== "undefined") {
    const currentParams = new URLSearchParams(window.location.search);
    currentParams.forEach((value, key) => {
      if (key.startsWith("gf_")) {
        params.append(key, value);
      }
    });
  }

  Object.entries(filters).forEach(([key, value]) => {
    // Skip pagination parameters and empty values
    if (key === "limit" || key === "offset" || value === null || value === undefined || value === "") {
      return;
    }

    // Convert numbers to strings
    if (typeof value === "number") {
      params.set(key, value.toString());
    } else if (typeof value === "string") {
      params.set(key, value);
    }
  });

  return params;
};

/**
 * Deserializes URL search parameters to filter object
 */
export const deserializeFiltersFromUrl = (searchParams: URLSearchParams): Partial<VendorListFilters> => {
  const filters: Partial<VendorListFilters> = {};

  // Define numeric filter keys
  const numericKeys = [
    "risk_rating_min",
    "risk_rating_max",
    "inbound_fill_rate_min",
    "inbound_fill_rate_max",
    "otif_percentage_min",
    "otif_percentage_max",
    "overall_score_min",
    "overall_score_max",
    "asn_timeliness_min",
    "asn_timeliness_max",
    "asn_essential_min",
    "asn_essential_max",
    "product_damages_rate_min",
    "product_damages_rate_max",
  ];

  searchParams.forEach((value, key) => {
    if (numericKeys.includes(key)) {
      const numValue = parseFloat(value);
      if (!isNaN(numValue)) {
        // Clamp percentage values to reasonable range (0-1 for backend)
        if (
          key.includes("product_damages_rate") ||
          key.includes("asn_timeliness") ||
          key.includes("asn_essential") ||
          key.includes("inbound_fill_rate") ||
          key.includes("average_otif") ||
          key.includes("average_outbound_fill_rate")
        ) {
          (filters as any)[key] = Math.min(1, Math.max(0, numValue));
        } else {
          (filters as any)[key] = numValue;
        }
      }
    } else {
      (filters as any)[key] = value;
    }
  });

  return filters;
};

/**
 * Updates URL with current filters without causing page reload
 */
export const updateUrlWithFilters = (filters: VendorListFilters) => {
  const params = serializeFiltersToUrl(filters);
  const newSearch = params.toString();
  const newUrl = `${window.location.pathname}${newSearch ? `?${newSearch}` : ""}`;

  // Use replaceState to avoid adding to browser history
  window.history.replaceState({}, "", newUrl);
};

/**
 * Formats a percentage for U.S. English display: up to `fractionDigits` decimals, trailing zeros omitted.
 * Use for UI only — keep raw API numbers in state; avoid Math.round on sensitive metrics.
 */
export function formatPercentageDisplay(value: number, fractionDigits = 2): string {
  const formatted = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: fractionDigits,
  }).format(value);
  return `${formatted}%`;
}
