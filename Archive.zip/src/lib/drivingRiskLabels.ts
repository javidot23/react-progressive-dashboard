export const drivingRiskLabels: Partial<Record<string, string>> = {
  category_risk_market: "Categorical Market Risk",
  category_risk_operational: "Categorical Operational Risk",
  category_risk_location: "Categorical Location Risk",
  composite_risk_model: "Composite Risk Model",
  volcano: "Location Risk of Volcano",
  tsunami: "Location Risk of Tsunami",
  landslide: "Location Risk of Landslides",
  cyclone: "Location Risk of Cyclone or Hurricane",
  earthquake: "Location Risk of Earthquake",
  wildfire: "Location Risk of Wildfire",
  river_flood: "Location Risk of River Flooding",
  urban_flood: "Location Risk of Flooding in Urban Environment",
  water_scarcity: "Location Risk of Water Scarcity",
  coastal_flood: "Location Risk of Coastal Flooding",
  extreme_heat: "Location Risk of Extreme Heat",
  forecast_error_model: "Operational Risk of Large Forecast Errors",
  demand_type: "Sales Risk due to Demand Patterns",
  scrm_cps_3month: "Operational Risk of Cascading Product Shortage",
  vendor_competitive_landscape_12month: "Market Risk of Vendor Exit from Market Landscape",
  "srm-bottlenecks-base-model": "Operational Risk due to Supply Chain Bottlenecks",
  "srm_fdacompliance-model-TARGET-shortage_n180d-GRANULARITY-gcn":
    "Regulatory Risk from FDA Compliance Impact over the next 180 days",
  "srm_fdacompliance-model-TARGET-shortage_n180d-GRANULARITY-ndcgroup":
    "Regulatory Risk from FDA Compliance Impact over the next 180 days",
  "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-ndcgroup":
    "Regulatory Risk from FDA Compliance Impact over the next 90 days",
  "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-gcn":
    "Regulatory Risk from FDA Compliance Impact over the next 90 days",
};

export type DrivingRisk = keyof typeof drivingRiskLabels;

export const getDrivingRiskLabel = (risk: DrivingRisk | undefined | null, optional?: string): string =>
  (risk && drivingRiskLabels[risk]) ?? optional ?? risk ?? "";

/** Lowercase words that stay lowercase when not the first word (title-style risk labels). */
const DRIVING_RISK_SMALL_WORDS = new Set([
  "a",
  "an",
  "the",
  "and",
  "or",
  "but",
  "nor",
  "as",
  "at",
  "by",
  "for",
  "from",
  "in",
  "into",
  "of",
  "on",
  "onto",
  "over",
  "to",
  "vs",
  "per",
]);

function preserveDrivingRiskToken(word: string): string | null {
  if (/^[A-Z]{2,5}$/.test(word)) return word;
  if (/^\d/.test(word)) return word;
  return null;
}

function titleCaseDrivingRiskWord(word: string, allowSmallLowercase: boolean): string {
  const preserved = preserveDrivingRiskToken(word);
  if (preserved !== null) return preserved;
  const lower = word.toLowerCase();
  if (allowSmallLowercase && DRIVING_RISK_SMALL_WORDS.has(lower)) return lower;
  return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
}

/**
 * Normalizes driving-risk labels to a consistent title-style capitalization for dropdowns and chips.
 */
export function formatDrivingRiskDropdownLabel(text: string): string {
  const trimmed = text.trim();
  if (!trimmed) return "";

  const words = trimmed.split(/\s+/);
  let isFirstToken = true;

  return words
    .map(word => {
      if (word.includes("-")) {
        return word
          .split("-")
          .map(part => {
            const out = titleCaseDrivingRiskWord(part, !isFirstToken);
            isFirstToken = false;
            return out;
          })
          .join("-");
      }
      const out = titleCaseDrivingRiskWord(word, !isFirstToken);
      isFirstToken = false;
      return out;
    })
    .join(" ");
}
