export interface ZipCodeCoordinates {
  zipCode: string;
  latitude: number;
  longitude: number;
  city?: string;
  state?: string;
}

let zipcodesModule: typeof import("zipcodes") | null = null;

async function getZipcodesModule(): Promise<typeof import("zipcodes")> {
  if (!zipcodesModule) {
    zipcodesModule = await import("zipcodes");
  }
  return zipcodesModule;
}

export async function getRealZipCodeCoordinates(zipCode: string): Promise<ZipCodeCoordinates | null> {
  const cleanZip = zipCode.replace(/[^0-9]/g, "").substring(0, 5);

  try {
    const zipcodes = await getZipcodesModule();
    const zipData = zipcodes.lookup(cleanZip);

    if (zipData) {
      return {
        zipCode: cleanZip,
        latitude: zipData.latitude,
        longitude: zipData.longitude,
        city: zipData.city,
        state: zipData.state,
      };
    }

    return null;
  } catch {
    return null;
  }
}

export function generateApproximateZipCoordinates(
  zipCodes: string[],
  plantLatitude: number,
  plantLongitude: number,
  radiusKm: number = 150
): ZipCodeCoordinates[] {
  return zipCodes.map((zipCode, index) => {
    const cleanZip = zipCode.replace(/[^0-9]/g, "").substring(0, 5);

    const zipSeed = parseInt(cleanZip) % 1000;
    const seedRandom = (seed: number) => ((seed * 9301 + 49297) % 233280) / 233280;

    const patterns = [
      () => {
        const angle = (index / zipCodes.length) * 2 * Math.PI + (zipSeed / 1000) * Math.PI;
        const distanceVariation = 0.3 + seedRandom(zipSeed) * 0.7;
        const distance = radiusKm * distanceVariation;
        const radiusInDegrees = distance / 111;
        return {
          lat: plantLatitude + radiusInDegrees * Math.cos(angle),
          lng: plantLongitude + radiusInDegrees * Math.sin(angle),
        };
      },
      () => {
        const gridSize = Math.ceil(Math.sqrt(zipCodes.length));
        const row = Math.floor(index / gridSize);
        const col = index % gridSize;
        const spacing = (radiusKm * 2) / (gridSize + 1) / 111;
        const variation = (seedRandom(zipSeed) - 0.5) * 0.2 * spacing;
        return {
          lat: plantLatitude - radiusKm / 111 + (row + 1) * spacing + variation,
          lng: plantLongitude - radiusKm / 111 + (col + 1) * spacing + variation,
        };
      },
      () => {
        const angle = seedRandom(zipSeed) * 2 * Math.PI;
        const distance = radiusKm * (0.2 + seedRandom(zipSeed + 100) * 0.8);
        const radiusInDegrees = distance / 111;
        return {
          lat: plantLatitude + radiusInDegrees * Math.cos(angle),
          lng: plantLongitude + radiusInDegrees * Math.sin(angle),
        };
      },
    ];

    const patternIndex = index % patterns.length;
    const coords = patterns[patternIndex]();

    return {
      zipCode: cleanZip,
      latitude: coords.lat,
      longitude: coords.lng,
      city: `Coverage Area ${index + 1}`,
      state: "Approximate",
    };
  });
}
interface PlantData {
  plant: {
    name: string;
    latitude: number;
    longitude: number;
    coverage_zip_codes?: string[];
  };
}

export async function generateAllZipCoordinatesInstantly(plantData: PlantData[]): Promise<Map<string, ZipCodeCoordinates>> {
  const allZipCoordinates = new Map<string, ZipCodeCoordinates>();

  for (const data of plantData) {
    const { plant } = data;

    if (plant.coverage_zip_codes && plant.coverage_zip_codes.length > 0) {
      for (const zipCode of plant.coverage_zip_codes) {
        const realCoords = await getRealZipCodeCoordinates(zipCode);

        if (realCoords) {
          allZipCoordinates.set(realCoords.zipCode, realCoords);
        } else {
          // Fallback to approximate coordinates if real ones not found
          const approximateCoords = generateApproximateZipCoordinates([zipCode], plant.latitude, plant.longitude, 120);

          if (approximateCoords.length > 0) {
            const coord = approximateCoords[0];
            allZipCoordinates.set(coord.zipCode, coord);
          }
        }
      }
    }
  }

  return allZipCoordinates;
}
