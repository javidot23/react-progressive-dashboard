export const US_LOCALE = "en-US";
export const US_TIMEZONE = "America/New_York";

export const US_TIMEZONE_SHORT_LABEL = "ET";

const usMediumDate: Intl.DateTimeFormatOptions = {
  month: "short",
  day: "numeric",
  year: "numeric",
  timeZone: US_TIMEZONE,
};

export function formatUsDateFromIso(isoString: string): string {
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return isoString;
  return d.toLocaleDateString(US_LOCALE, usMediumDate);
}

const usMediumDateTime: Intl.DateTimeFormatOptions = {
  year: "numeric",
  month: "short",
  day: "numeric",
  hour: "numeric",
  minute: "2-digit",
  hour12: true,
  timeZone: US_TIMEZONE,
};

export function formatUsDateTimeFromIso(isoString: string): string {
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return isoString;
  return d.toLocaleString(US_LOCALE, usMediumDateTime);
}

export function formatUsDateFromYmd(ymd: string): string {
  const trimmed = ymd.trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(trimmed);
  if (match) {
    const y = Number(match[1]);
    const mo = Number(match[2]) - 1;
    const day = Number(match[3]);
    const d = new Date(Date.UTC(y, mo, day, 12, 0, 0));
    return d.toLocaleDateString(US_LOCALE, usMediumDate);
  }
  return formatUsDateFromIso(trimmed);
}

export function formatUsDateFromYmdOrEmDash(ymd: string): string {
  if (!ymd?.trim()) return "—";
  return formatUsDateFromYmd(ymd.trim());
}

export function formatUsGroupedDecimalString(value: string, maxFractionDigits: number, emptyDisplay = "—"): string {
  const n = parseFloat(value);
  if (!Number.isFinite(n)) return value?.trim() || emptyDisplay;
  return n.toLocaleString(US_LOCALE, { minimumFractionDigits: 0, maximumFractionDigits: maxFractionDigits });
}

export function formatUsInteger(value: number): string {
  return Math.round(value).toLocaleString(US_LOCALE);
}

const compactNumberFmt = new Intl.NumberFormat(US_LOCALE, {
  notation: "compact",
  maximumFractionDigits: 2,
});

export function formatUsCompactCount(value: number): string {
  if (!Number.isFinite(value)) return formatUsInteger(0);
  if (Math.abs(value) < 1000) return formatUsInteger(value);
  return compactNumberFmt.format(value);
}

const usCurrencyFormatter = new Intl.NumberFormat(US_LOCALE, {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

export function formatUsCurrency(value: number): string {
  if (!Number.isFinite(value)) return usCurrencyFormatter.format(0);
  return usCurrencyFormatter.format(value);
}

/** USD for chargeback / invoice line amounts that may include more than two decimal places. */
const usCurrencyLineItemFormatter = new Intl.NumberFormat(US_LOCALE, {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 6,
});

export function formatUsCurrencyLineItem(value: number): string {
  if (!Number.isFinite(value)) return usCurrencyLineItemFormatter.format(0);
  return usCurrencyLineItemFormatter.format(value);
}

/** USD from API string/number; empty → $0.00 line-item style; invalid → em dash. */
export function formatUsUsdLineItemFromApiValue(value: string | number | null | undefined): string {
  if (value === undefined || value === null || value === "") return formatUsCurrencyLineItem(0);
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (!Number.isFinite(num)) return "—";
  return formatUsCurrencyLineItem(num);
}

const usOptionalFraction1 = new Intl.NumberFormat(US_LOCALE, {
  maximumFractionDigits: 2,
  minimumFractionDigits: 0,
});

export function formatUsOptionalDecimal1(value: number): string {
  if (!Number.isFinite(value)) return "—";
  return usOptionalFraction1.format(value);
}

export function formatUsPercentAxisTick(value: number): string {
  if (!Number.isFinite(value)) return "—";
  const rounded = Math.round(value * 100) / 100;
  return `${rounded.toLocaleString(US_LOCALE, { maximumFractionDigits: 2, minimumFractionDigits: 0 })}%`;
}

export function formatUsChartWeekLabel(value: string): string {
  const trimmed = value.trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(trimmed)) return formatUsDateFromYmd(trimmed);
  return formatUsDateFromIso(trimmed);
}

const usShortMonthDay: Intl.DateTimeFormatOptions = {
  month: "short",
  day: "numeric",
  timeZone: US_TIMEZONE,
};

export function formatUsShortMonthDayFromYmd(value: string): string {
  const trimmed = value.trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(trimmed);
  if (match) {
    const y = Number(match[1]);
    const mo = Number(match[2]) - 1;
    const day = Number(match[3]);
    const d = new Date(Date.UTC(y, mo, day, 12, 0, 0));
    return d.toLocaleDateString(US_LOCALE, usShortMonthDay);
  }
  const d = new Date(trimmed);
  if (!Number.isNaN(d.getTime())) {
    return d.toLocaleDateString(US_LOCALE, usShortMonthDay);
  }
  return trimmed;
}

const usLongDate: Intl.DateTimeFormatOptions = {
  month: "long",
  day: "numeric",
  year: "numeric",
  timeZone: US_TIMEZONE,
};

export function formatUsLongDateFromYmd(value: string): string {
  const trimmed = value.trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(trimmed);
  if (match) {
    const y = Number(match[1]);
    const mo = Number(match[2]) - 1;
    const day = Number(match[3]);
    const d = new Date(Date.UTC(y, mo, day, 12, 0, 0));
    return d.toLocaleDateString(US_LOCALE, usLongDate);
  }
  return formatUsDateFromIso(trimmed);
}
