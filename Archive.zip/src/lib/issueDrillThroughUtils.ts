import type { NavigateFunction } from "react-router-dom";
import { ROUTES } from "@/constants/routes";
import type { DrivingEvent, GranularityIssueView, GranularityType } from "@/types/granularityIssue";

/**
 * Issue-summary payload passed via `location.state` on the way into the issue
 * drill-through, so the page renders instantly before `GET /issue/<id>/` resolves.
 */
export interface IssueDrillThroughLocationState {
  issueId?: number;
  issueNbr?: string;
  granularityType?: GranularityType;
  granularityLabel?: string;
  granularityValue?: string;
  title?: string;
  status?: string;
  group?: string | null;
  persona?: string | null;
  dateIdentified?: string | null;
  drivingRisk?: string;
  drivingRiskRaw?: string;
  effectiveRiskRating?: number;
  effectiveDollarsAtRisk?: number;
  impactedMaterialCount?: number;
  drivingEvent?: DrivingEvent | null;
  potentialActions?: unknown[];
  actions?: unknown[];
}

/**
 * Instant-render context for the inspect-only material detail page, reached by
 * clicking an impacted material inside an issue drill-through.
 */
export interface MaterialDetailLocationState {
  matNbr?: string;
  name?: string;
  ndc?: string;
  vendorName?: string;
  vendorNbr?: string;
  riskLevel?: number;
  dollarsAtRisk?: number;
  /** The issue drill-through to return to ("Back to issue"). */
  originIssueId?: number;
  from?: "issue";
}

/** Navigate to the material-centric (inspect-only) detail page. */
export function navigateToMaterialDetail(
  navigate: NavigateFunction,
  params: { materialId: number } & MaterialDetailLocationState
): void {
  const { materialId, matNbr, ...rest } = params;
  if (!materialId) return;
  const query = matNbr ? `?matNbr=${encodeURIComponent(matNbr)}` : "";
  navigate(`${ROUTES.REACT_MATERIAL_DETAIL}/${materialId}${query}`, {
    state: { matNbr, ...rest } satisfies MaterialDetailLocationState,
  });
}

/** Navigate from the feed to the issue drill-through (multi-material issues). */
export function navigateToIssueDrillThrough(navigate: NavigateFunction, issue: GranularityIssueView): void {
  if (!issue.id) return;

  navigate(`${ROUTES.REACT_ISSUE}/${issue.id}`, {
    state: {
      issueId: issue.id,
      issueNbr: issue.issueNbr,
      granularityType: issue.granularityType,
      granularityLabel: issue.granularityLabel,
      granularityValue: issue.granularityValue,
      title: issue.productName,
      status: issue.status,
      group: issue.group,
      persona: issue.persona,
      dateIdentified: issue.dateIdentified,
      drivingRisk: issue.drivingRisk,
      drivingRiskRaw: issue.drivingRiskRaw,
      effectiveRiskRating: issue.effectiveRiskRating,
      effectiveDollarsAtRisk: issue.effectiveDollarsAtRisk,
      impactedMaterialCount: issue.impactedMaterialCount,
      drivingEvent: issue.drivingEvent ?? null,
      potentialActions: issue.potentialActions,
      actions: issue.actions,
    } satisfies IssueDrillThroughLocationState,
  });
}
