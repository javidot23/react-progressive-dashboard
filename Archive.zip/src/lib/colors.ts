const cdsColorBrand700 = "#461e96";
const cdsColorBrand900 = "#211359";
const cdsColorBrand400 = "#8c7ed7";
const cdsColorBrand600 = "#593ab1";
const cdsColorBrand200 = "#c1bbee";

const cdsColorSuccess500 = "#007f50";
const cdsColorSuccess50 = "#d8fee7";
const cdsColorSuccess600 = "#095f3b";
const cdsColorSuccess200 = "#00dc8c";
const cdsColorWarning300 = "#faeb1e";
const cdsColorWarning100 = "#fff8ba";
const cdsColorWarning800 = "#c2551f";
const cdsColorWarning600 = "#ffa400";
const cdsColorDanger500 = "#e22f00";
const cdsColorDanger100 = "#fcd9d1";
const cdsColorDanger600 = "#9e2305";

const cdsColorHighlight300 = "#00b4e6";
const cdsColorHighlight50 = "#e7f7ff";
const cdsColorHighlight600 = "#005c98";
const cdsColorHighlight400 = "#0391d7";
const cdsColorHighlight100 = "#b7e8fe";
const cdsColorHighlight500 = "#0073be";
const cdsColorHighlight700 = "#043e67";

const cdsColorNeutral500 = "#6e6e6e";
const cdsColorNeutral200 = "#cacaca";

const cdsColorInteractivePrimary = "#461e96";
const cdsColorInteractivePrimaryHover = "#351b7a";
const cdsColorInteractivePrimaryActive = "#211359";

const cdsColorTextPrimary = "#3b3b3b";
const cdsColorTextSecondary = "#6e6e6e";
const cdsColorTextLink = "#461e96";

const cdsColorBackgroundPrimary = "#ffffff";
const cdsColorBackgroundSecondary = "#f5f5f5";

const cdsColorBorderPrimary = "#e8e8e8";
const cdsColorBorderSecondary = "#cacaca";

const cdsColorDataCategorical01 = "#461e96";
const cdsColorDataCategorical02 = "#0391d7";

const cdsColorCoreMagenta500 = "#e6008c";
const cdsColorCoreYellow700 = "#dd7005";
const cdsColorCoreGray600 = "#525252";

export const brandColors = {
  primary: {
    main: cdsColorBrand700,
    light: cdsColorBrand400,
    dark: cdsColorBrand900,
    surface: cdsColorBrand600,
  },

  secondary: {
    main: cdsColorHighlight400,
    light: cdsColorBrand200,
    dark: cdsColorHighlight600,
  },
} as const;

export const statusColors = {
  success: {
    main: cdsColorSuccess500,
    light: cdsColorSuccess50,
    dark: cdsColorSuccess600,
    bright: cdsColorSuccess200,
  },

  warning: {
    main: cdsColorWarning300,
    light: cdsColorWarning100,
    dark: cdsColorWarning800,
    accent: cdsColorWarning600,
  },

  error: {
    main: cdsColorDanger500,
    light: cdsColorDanger100,
    dark: cdsColorDanger600,
    text: cdsColorDanger500,
  },

  info: {
    main: cdsColorHighlight300,
    light: cdsColorHighlight50,
    dark: cdsColorHighlight600,
    darker: cdsColorHighlight600,
    accent: cdsColorHighlight400,
    border: cdsColorHighlight100,
    surface: cdsColorHighlight50,
  },

  alert: {
    main: cdsColorDanger100,
    border: cdsColorDanger100,
    icon: cdsColorDanger600,
  },
} as const;

export const chartColors = {
  risk: {
    high: cdsColorDataCategorical01,
    medium: cdsColorDataCategorical02,
    low: cdsColorCoreMagenta500,
    critical: cdsColorDanger500,
  },

  data: {
    primary: cdsColorDataCategorical01,
    secondary: cdsColorBrand200,
    tertiary: cdsColorDataCategorical02,
    quaternary: cdsColorCoreGray600,
  },

  geography: {
    highImpact: cdsColorDataCategorical01,
    mediumImpact: cdsColorDataCategorical02,
    lowImpact: cdsColorCoreMagenta500,
    riskMedium: cdsColorCoreYellow700,
  },
} as const;

/** Re-export shared CSS-variable chart system (palettes, series helpers). */
export { chartColorSystem, chartPalettes, getSeriesColors, mapSeriesColors, resolveSeriesColor } from "./chartColors";

export const uiColors = {
  text: {
    primary: cdsColorTextPrimary,
    secondary: cdsColorTextSecondary,
    muted: cdsColorNeutral500,
    link: cdsColorTextLink,
    accent: cdsColorBrand700,
  },

  background: {
    primary: cdsColorBackgroundPrimary,
    secondary: cdsColorBackgroundSecondary,
    surface: cdsColorBackgroundSecondary,
    muted: cdsColorNeutral200,
    neutral: cdsColorBackgroundSecondary,
  },

  border: {
    primary: cdsColorBorderPrimary,
    secondary: cdsColorBorderSecondary,
    accent: cdsColorHighlight400,
    focus: cdsColorBrand700,
  },

  interactive: {
    hover: cdsColorInteractivePrimaryHover,
    focus: cdsColorInteractivePrimary,
    active: cdsColorInteractivePrimaryActive,
  },
} as const;

export const componentColors = {
  status: {
    actionRequired: {
      bg: cdsColorDanger100,
      text: cdsColorDanger500,
      border: cdsColorDanger500,
    },
    actionReviewed: {
      bg: cdsColorSuccess50,
      text: cdsColorSuccess500,
      border: cdsColorSuccess500,
    },
    underReview: {
      bg: cdsColorWarning100,
      text: cdsColorWarning800,
      border: cdsColorWarning800,
    },
  },

  riskBadge: {
    critical: cdsColorDanger500,
    high: cdsColorWarning800,
    medium: cdsColorWarning800,
    low: cdsColorNeutral500,
  },
} as const;

export const colors = {
  brand: brandColors,
  status: statusColors,
  chart: chartColors,
  ui: uiColors,
  component: componentColors,
} as const;

export function getColor(path: string): string {
  const parts = path.split(".");
  let value: any = colors;

  for (const part of parts) {
    value = value?.[part];
  }

  if (typeof value !== "string") {
    console.warn(`Color path "${path}" not found, falling back to primary`);
    return colors.brand.primary.main;
  }

  return value;
}

export function getCSSVar(path: string): string {
  const cssVarMap: Record<string, string> = {
    "brand.primary.main": "var(--cds-color-brand-700)",
    "brand.primary.light": "var(--cds-color-brand-400)",
    "brand.primary.dark": "var(--cds-color-brand-900)",
    "brand.primary.surface": "var(--cds-color-brand-600)",
    "brand.secondary.main": "var(--cds-color-highlight-400)",
    "brand.secondary.light": "var(--cds-color-brand-200)",
    "brand.secondary.dark": "var(--cds-color-highlight-600)",
    "status.success.main": "var(--cds-color-success-500)",
    "status.success.light": "var(--cds-color-success-50)",
    "status.success.dark": "var(--cds-color-success-600)",
    "status.success.bright": "var(--cds-color-success-200)",
    "status.warning.main": "var(--cds-color-warning-300)",
    "status.warning.light": "var(--cds-color-warning-100)",
    "status.warning.dark": "var(--cds-color-warning-800)",
    "status.warning.accent": "var(--cds-color-warning-600)",
    "status.error.main": "var(--cds-color-danger-500)",
    "status.error.light": "var(--cds-color-danger-100)",
    "status.error.dark": "var(--cds-color-danger-600)",
    "status.error.text": "var(--cds-color-danger-500)",
    "status.info.main": "var(--cds-color-highlight-300)",
    "status.info.light": "var(--cds-color-highlight-50)",
    "status.info.dark": "var(--cds-color-highlight-600)",
    "ui.text.primary": "var(--cds-color-text-primary)",
    "ui.text.secondary": "var(--cds-color-text-secondary)",
    "ui.text.link": "var(--cds-color-text-link)",
    "ui.background.primary": "var(--cds-color-background-primary)",
    "ui.background.secondary": "var(--cds-color-background-secondary)",
    "ui.border.primary": "var(--cds-color-border-primary)",
    "ui.border.secondary": "var(--cds-color-border-secondary)",
  };

  return cssVarMap[path] || `var(--cds-color-${path.replace(/\./g, "-")})`;
}

export function generateCSSCustomProperties(): Record<string, string> {
  const properties: Record<string, string> = {};

  function flatten(obj: any, prefix = ""): void {
    Object.keys(obj).forEach(key => {
      const value = obj[key];
      const newKey = prefix ? `${prefix}-${key}` : key;

      if (typeof value === "string" && value.startsWith("#")) {
        properties[`--color-${newKey}`] = value;
      } else if (typeof value === "object" && value !== null) {
        flatten(value, newKey);
      }
    });
  }

  flatten(colors);
  return properties;
}

export function hexToRgb(hexColor: string): string {
  const hex = hexColor.replace("#", "");
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  return `${r} ${g} ${b}`;
}

export const themePresets = {
  default: colors,

  alternative: {
    ...colors,
    brand: {
      ...colors.brand,
      primary: {
        main: cdsColorHighlight500,
        light: cdsColorHighlight300,
        dark: cdsColorHighlight700,
        surface: cdsColorHighlight400,
      },
    },
  },
} as const;

export type ColorPath =
  | "brand.primary.main"
  | "brand.primary.light"
  | "brand.primary.dark"
  | "status.success.main"
  | "status.warning.main"
  | "status.error.main"
  | "ui.text.primary"
  | "ui.background.primary";

export type ColorTheme = typeof colors;

export default colors;
