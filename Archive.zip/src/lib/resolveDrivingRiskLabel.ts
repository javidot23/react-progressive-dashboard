import { drivingRiskLabels } from "@/lib/drivingRiskLabels";

/** Lookup built from `/risk-model-description/` keyed by `model_name`. */
export type RiskModelNameLookup = Record<
  string,
  { model_type: string; model_description: string; display_name: string }
>;

export function formatDrivingRiskFallback(modelName: string | null | undefined): string {
  if (modelName == null || typeof modelName !== "string") return "";
  return modelName.replace(/_/g, " ").replace(/-/g, " ");
}

/**
 * Prefer API `display_name`, then static {@link drivingRiskLabels}, then formatted code.
 */
export function resolveDrivingRiskLabel(
  code: string | null | undefined,
  byModelName?: RiskModelNameLookup | null
): string {
  const c = code ?? "";
  if (!c) return "";
  const fromApi = byModelName?.[c]?.display_name?.trim();
  if (fromApi) return fromApi;
  const staticLabel = drivingRiskLabels[c];
  if (staticLabel) return staticLabel;
  return formatDrivingRiskFallback(c);
}
