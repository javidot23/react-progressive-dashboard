export type CSSalesChangeTrackingTab = "historical" | "current";

const ANALYSIS_CARD = {
  historical: {
    subtitle:
      'Monthly totals for your selected period. The lower chart compares each month to the previous month in the series (not the same "prior period" as the comparison tables).',
    tooltip:
      "Top chart: monthly sales or order quantity from pre-aggregated data for your selected period. Lower chart: percent change from the prior month in that series only. Tables below compare the current period to the prior period.",
  },
  current: {
    subtitle:
      'Weekly totals for your selected period. The lower chart compares each week to the prior week in the series (not the same "prior period" as the comparison tables).',
    tooltip:
      "Top chart: weekly sales or order quantity for your selected period. Lower chart: percent change from the prior week in that series only. Tables below compare the current period to the prior period.",
  },
} as const;

export function getCsSalesAnalysisCardSubtitle(tab: CSSalesChangeTrackingTab): string {
  return ANALYSIS_CARD[tab].subtitle;
}

export function getCsSalesAnalysisCardTooltip(tab: CSSalesChangeTrackingTab): string {
  return ANALYSIS_CARD[tab].tooltip;
}

const PERCENT_CHANGE_LABELS = {
  historical: {
    periodAxis: "Period",
    priorValue: "Previous month (in chart)",
    currentValue: "This month (in chart)",
    yAxisLabel: "% Change",
    chartPercentChangeLabel: "% Change",
  },
  current: {
    periodAxis: "Period",
    priorValue: "Previous week (in chart)",
    currentValue: "This week (in chart)",
    yAxisLabel: "% Change",
    chartPercentChangeLabel: "% Change",
  },
} as const;

export function getCsSalesPercentChangeChartLabels(tab: CSSalesChangeTrackingTab) {
  return PERCENT_CHANGE_LABELS[tab];
}

const COMPARISON_TABLE = {
  historical: {
    subtitleByTitle: (title: string) =>
      `Comparison for the selected monthly period. ${title} — values and bars are for the current page only.`,
    tooltipByTitle: (title: string) =>
      `${title} for the selected historical period (pre-aggregated monthly data). The bar encodes percent change from center (0%): red left (negative) / green right (positive); each half is 0–100% with values beyond ±100% filling that half.`,
  },
  current: {
    subtitleByTitle: (title: string) =>
      `Weekly transaction data (~90-day window). ${title} — values and bars are for the current page only.`,
    tooltipByTitle: (title: string) =>
      `${title} from the rolling 90-day order transaction window. The bar encodes percent change from center (0%): red left (negative) / green right (positive); each half is 0–100% with values beyond ±100% filling that half.`,
  },
} as const;

const CS_COMPARISON_TABLE_TITLES = new Set([
  "Total Unit Sales by Material",
  "Total Unit Sales by Sales Group",
  "Total Unit Sales by Corporate Chain",
]);

export const CS_CHANGE_TRACKING_MATERIAL_TABLE_DESCRIPTION =
  "Material totals vs prior period for your filters.";

export const CS_CHANGE_TRACKING_SALES_GROUP_TABLE_DESCRIPTION =
  "Sales group vs prior period. Bar = % change from center (red left / green right); each half is 0–100%, beyond ±100% saturates.";

export const CS_CHANGE_TRACKING_CORPORATE_CHAIN_TABLE_DESCRIPTION =
  "Corporate chain vs prior period. Bar = % change from center (red left / green right); each half is 0–100%, beyond ±100% saturates.";

export function isCsSalesComparisonTableTitle(title: string): boolean {
  return CS_COMPARISON_TABLE_TITLES.has(title);
}

export function getCsSalesComparisonTableSubtitle(tab: CSSalesChangeTrackingTab, title: string): string {
  return COMPARISON_TABLE[tab].subtitleByTitle(title);
}

export function getCsSalesComparisonTableTooltip(tab: CSSalesChangeTrackingTab, title: string): string {
  return COMPARISON_TABLE[tab].tooltipByTitle(title);
}

const STATE_MAP_CARD_DESCRIPTION =
  "State-level comparison of period-over-period change for your selected filters. Hover over a state to see details.";

export function getCsSalesStateMapCardSubtitle(_tab: CSSalesChangeTrackingTab): string {
  return STATE_MAP_CARD_DESCRIPTION;
}

export function getCsSalesStateMapCardTooltip(_tab: CSSalesChangeTrackingTab): string {
  return STATE_MAP_CARD_DESCRIPTION;
}
