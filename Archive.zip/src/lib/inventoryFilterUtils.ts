// URL Query Parameter utilities for Inventory Filters

/** `ordering` param for `/demand-forecast/materials/{mat_nbr}/plants/` — only fields exposed in the DC table Order control */
export const DC_PLANTS_ORDER_FIELDS = [
  "plant__plant_nbr",
  "outbound_fill_rate",
  "saleable_qty_on_hand_latest",
  "on_order_qty_sum",
] as const;

export const DEFAULT_DC_PLANTS_ORDERING = "plant__plant_nbr";

export const VALID_INVENTORY_ORDER_FIELDS = [
  "dc_count",
  "outbound_fill_rate",
  "doh_days",
  "doo_days",
  "plants_no_stock",
  "plants_stockout",
  "plants_in_range",
  "plants_overstock",
] as const;

export const INVENTORY_SORT_OPTIONS: { label: string; value: (typeof VALID_INVENTORY_ORDER_FIELDS)[number] }[] = [
  { label: "DC Count", value: "dc_count" },
  { label: "Outbound fill rate", value: "outbound_fill_rate" },
  { label: "Days on Hand", value: "doh_days" },
  { label: "Days on Order", value: "doo_days" },
  { label: "No stock DCs", value: "plants_no_stock" },
  { label: "Stockout DCs", value: "plants_stockout" },
  { label: "In range DCs", value: "plants_in_range" },
  { label: "Overstock DCs", value: "plants_overstock" },
];

/** Map legacy ordering field names from bookmarks to the current API contract. */
export function normalizeInventoryOrdering(value: string): string {
  if (value === "-dc_low_count") return "-dc_count";
  if (value === "dc_low_count") return "dc_count";
  return value;
}

export function isValidInventoryOrdering(value: string): boolean {
  const normalized = normalizeInventoryOrdering(value);
  const field = normalized.startsWith("-") ? normalized.substring(1) : normalized;
  return (VALID_INVENTORY_ORDER_FIELDS as readonly string[]).includes(field);
}

export function isValidDcPlantsOrdering(value: string | undefined | null): value is string {
  if (value == null || value === "") return false;
  const field = value.startsWith("-") ? value.slice(1) : value;
  return (DC_PLANTS_ORDER_FIELDS as readonly string[]).includes(field);
}

export const serializeInventoryFilters = (filters: any): URLSearchParams => {
  const params = new URLSearchParams();

  // Define default values - don't add these to URL if they match
  const defaults: any = {
    sortBy: "doh_days",
    material_mat_nbr: "",
    dc_min: null,
    dc_max: null,
    doh_days_min: null,
    doh_days_max: null,
    active_doh_zone: null,
    ordering: "-dc_count",
    dc_plants_ordering: DEFAULT_DC_PLANTS_ORDERING,
  };

  Object.entries(filters).forEach(([key, value]) => {
    // Only add to URL if:
    // 1. Value is not null/undefined/empty string
    // 2. Value is different from the default value
    if (
      value !== null &&
      value !== undefined &&
      value !== "" &&
      value !== defaults[key]
    ) {
      params.set(key, value.toString());
    }
  });

  return params;
};

export const deserializeInventoryFilters = (searchParams: URLSearchParams): any => {
  const filters = {
    sortBy: "doh_days",
    material_mat_nbr: "",
    dc_min: null as number | null,
    dc_max: null as number | null,
    doh_days_min: null as number | null,
    doh_days_max: null as number | null,
    active_doh_zone: null as string | null,
    ordering: "-dc_count",
    dc_plants_ordering: DEFAULT_DC_PLANTS_ORDERING,
  };

  // Parse URL parameters
  for (const [key, value] of searchParams.entries()) {
    if (key === "ordering") {
      const normalized = normalizeInventoryOrdering(value);
      if (isValidInventoryOrdering(normalized)) {
        filters.ordering = normalized;
      }
      continue;
    }

    // Legacy URL keys from before dc_low_* rename
    if (key === "dc_low_min") {
      const numValue = Number(value);
      if (!isNaN(numValue)) {
        filters.dc_min = numValue;
      }
      continue;
    }
    if (key === "dc_low_max") {
      const numValue = Number(value);
      if (!isNaN(numValue)) {
        filters.dc_max = numValue;
      }
      continue;
    }

    if (key in filters) {
      if (key === "dc_plants_ordering") {
        if (isValidDcPlantsOrdering(value)) {
          (filters as any)[key] = value;
        }
      } else if (key === "material_mat_nbr" || key === "active_doh_zone") {
        (filters as any)[key] = value;
      } else if (key === "sortBy") {
        (filters as any)[key] = value;
      } else if (key === "doh_days_min" || key === "doh_days_max" || key === "dc_min" || key === "dc_max") {
        const numValue = Number(value);
        if (!isNaN(numValue)) {
          (filters as any)[key] = numValue;
        }
      }
    }
  }

  return filters;
};
