/** SAP AaaS profile link helpers (OIDC runs server-side under BFF). */

export function getAaaSProfileUrl(): string | null {
  const domain = import.meta.env.VITE_CDC_DOMAIN || "";
  if (!domain) return null;

  const cleanDomain = domain.replace(/\/$/, "");
  return `${cleanDomain}/pages/profile`;
}
