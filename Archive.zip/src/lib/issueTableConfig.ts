import type { NavigateFunction } from "react-router-dom";
import type { TableColumn } from "@/components/molecules/ReorderTableModal";
import { navigateToMaterialDrillThrough } from "@/lib/materialDrillThroughUtils";
import { navigateToIssueDrillThrough } from "@/lib/issueDrillThroughUtils";
import type { GranularityIssueView } from "@/types/granularityIssue";

export type IssueFeedTableScope = "material" | "aggregated" | "mixed";

/** Maps React page granularity filter → table column preset. */
export function resolveIssueFeedTableScope(granularityLevel: string): IssueFeedTableScope {
  if (!granularityLevel) return "mixed";
  if (granularityLevel === "material" || granularityLevel === "material_plant") return "material";
  return "aggregated";
}

const sharedIssueColumns = (): TableColumn[] => [
  // { id: "granularity_level", label: "Level", visible: true },
  { id: "granularity_value", label: "Identifier", visible: true },
  { id: "group", label: "Group", visible: true },
  { id: "issue_status", label: "Issue Status", visible: true },
  { id: "driving_event", label: "Driving Event", visible: true },
  { id: "materials_impacted", label: "Materials Impacted", visible: true },
  { id: "risk_score", label: "Risk Score", visible: true },
  { id: "primary_risk", label: "Driving Risk", visible: true },
  { id: "risk_adjusted_value", label: "Risk Adjusted Value / Value at Risk", visible: true },
  { id: "notes", label: "Notes", visible: true },
  { id: "action_status", label: "Action Status", visible: true },
  { id: "created_date", label: "Identified", visible: true },
  { id: "persona", label: "Persona", visible: false },
  { id: "recommended_actions", label: "Recommended Actions", visible: true },
];

const materialDetailColumns = (): TableColumn[] => [
  { id: "material_id", label: "Material ID", visible: true },
  { id: "material_status", label: "Material Status", visible: true },
  { id: "vendor_name", label: "Vendor", visible: true },
  { id: "vendor_nbr", label: "Vendor Id", visible: true },
  { id: "ndc", label: "NDC", visible: true },
];

/** Default columns for the React native-granularity issue feed table. */
export function getDefaultIssueFeedColumns(scope: IssueFeedTableScope): TableColumn[] {
  if (scope === "material") {
    return [
      { id: "issue_name", label: "Material Name", visible: true, locked: true },
      ...materialDetailColumns(),
      ...sharedIssueColumns(),
    ];
  }

  if (scope === "aggregated") {
    return [{ id: "issue_name", label: "Issue", visible: true, locked: true }, ...sharedIssueColumns()];
  }

  return [
    { id: "issue_name", label: "Issue", visible: true, locked: true },
    ...sharedIssueColumns(),
    ...materialDetailColumns().map(column => ({ ...column, visible: false })),
  ];
}

export function getIssueDisplayTitle(issue: GranularityIssueView): string {
  const isSingleMaterial = issue.isSingleMaterial ?? true;
  return isSingleMaterial ? issue.productName : `${issue.granularityLabel ?? "Issue"} ${issue.granularityValue ?? ""}`.trim();
}

export function getIssueCtaLabel(issue: GranularityIssueView): string {
  const isSingleMaterial = issue.isSingleMaterial ?? true;
  const impactedCount = issue.impactedMaterialCount ?? 1;
  return isSingleMaterial ? "View material and take action" : `View ${impactedCount} materials and take action`;
}

export function openIssueDrillThrough(navigate: NavigateFunction, issue: GranularityIssueView): void {
  if (issue.isSingleMaterial ?? true) {
    navigateToMaterialDrillThrough(navigate, issue);
  } else {
    navigateToIssueDrillThrough(navigate, issue);
  }
}

export { formatDrivingEventLocation, formatDrivingEventSummary } from "@/lib/drivingEventDisplay";

/** Normalize legacy IssueTableView scopes to feed presets. */
export function normalizeIssueTableScope(
  viewScope: "material" | "gcn" | "product" | "aggregated" | "mixed" = "material"
): IssueFeedTableScope {
  if (viewScope === "mixed") return "mixed";
  if (viewScope === "aggregated" || viewScope === "gcn" || viewScope === "product") return "aggregated";
  return "material";
}
