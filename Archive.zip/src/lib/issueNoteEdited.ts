const DEFAULT_EDIT_THRESHOLD_MS = 1000;

export function issueNoteShowsEditedLabel(
  createdAtIso: string,
  updatedAtIso: string,
  thresholdMs: number = DEFAULT_EDIT_THRESHOLD_MS
): boolean {
  if (createdAtIso === updatedAtIso) return false;

  const createdMs = Date.parse(createdAtIso);
  const updatedMs = Date.parse(updatedAtIso);
  if (Number.isNaN(createdMs) || Number.isNaN(updatedMs)) {
    return createdAtIso !== updatedAtIso;
  }

  return Math.abs(updatedMs - createdMs) > thresholdMs;
}
