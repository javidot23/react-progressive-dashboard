import type { UserAction } from "@/lib/apiServices";
import { getNoActionDecisionRationale } from "@/lib/materialActionDisplay";
import { formatDrillThroughDate } from "@/lib/materialDrillThroughUtils";
import { formatCurrencyCompact } from "@/lib/utils";

export type ActionHistoryDotTone = "neutral" | "warning" | "danger" | "success";

export const ACTION_HISTORY_DOT_STYLES: Record<
  ActionHistoryDotTone,
  { ring: string; inner: string }
> = {
  neutral: { ring: "bg-[#E5E7EB]", inner: "bg-[#9CA3AF]" },
  warning: { ring: "bg-[#FFEDD5]", inner: "bg-[#F97316]" },
  danger: { ring: "bg-[#FEE2E2]", inner: "bg-[#EF4444]" },
  success: { ring: "bg-[#D1FAE5]", inner: "bg-[#22C55E]" },
};

export function getActionHistoryDotTone(actionLabel: string): ActionHistoryDotTone {
  const lower = actionLabel.toLowerCase();
  if (
    lower.includes("mitigat") ||
    lower.includes("order placed") ||
    lower.includes("expedited")
  ) {
    return "success";
  }
  if (
    lower.includes("alert") ||
    lower.includes("shortage") ||
    lower.includes("capacity")
  ) {
    return "danger";
  }
  if (
    lower.includes("risk score") ||
    lower.includes("formulary") ||
    lower.includes("increased") ||
    lower.includes("reached")
  ) {
    return "warning";
  }
  return "neutral";
}

export function formatActionHistoryActor(user: UserAction["user"]): string {
  if (!user?.first_name && !user?.last_name) {
    return "System";
  }
  return `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim();
}

const ACTION_HISTORY_LABEL_OVERRIDES: Record<string, string> = {
  no_action: "No Action",
  no_action_required: "No Action Required",
};

export function formatActionHistoryLabel(raw: string | null | undefined): string {
  const trimmed = raw?.trim();
  if (!trimmed) return "";
  const normalized = trimmed.toLowerCase().replace(/\s+/g, "_");
  return ACTION_HISTORY_LABEL_OVERRIDES[normalized] ?? trimmed;
}

export function getActionHistoryLabel(action: UserAction): string {
  const fromAction = formatActionHistoryLabel(action.action);
  if (fromAction) return fromAction;
  const fromPotential = action.potential_action?.recommendation?.trim();
  if (fromPotential) return fromPotential;
  return "Action recorded";
}

export function formatActionHistoryDate(iso: string): string {
  return formatDrillThroughDate(iso);
}

function readNumericField(source: Record<string, unknown>, keys: string[]): number | null {
  for (const key of keys) {
    const value = source[key];
    if (typeof value === "number" && Number.isFinite(value)) return value;
  }
  return null;
}

/** Snapshot fields stored on the action when it was taken (material_context or legacy flat keys). */
export function getActionHistoryHoverDetails(action: UserAction): {
  materialAtRiskValue: string;
  riskScore: string;
  decisionRationale: string;
} {
  const ctx =
    action.material_context != null && typeof action.material_context === "object"
      ? action.material_context
      : {};

  const dollarsAtRisk = readNumericField(ctx, [
    "material_dollars_at_risk",
    "dollars_at_risk",
    "material_at_risk_value",
  ]);

  const riskRating = readNumericField(ctx, [
    "material_risk_rating",
    "risk_rating",
    "risk_score",
  ]);

  const materialAtRiskValue =
    dollarsAtRisk != null && dollarsAtRisk > 0 ? formatCurrencyCompact(dollarsAtRisk) : "—";

  let riskScore = "—";
  if (riskRating != null) {
    const score = riskRating <= 1 ? Math.round(riskRating * 100) : Math.round(riskRating);
    riskScore = `${score} / 100`;
  }

  const rationale = getNoActionDecisionRationale(action);

  return {
    materialAtRiskValue,
    riskScore,
    decisionRationale: rationale ?? "—",
  };
}

export function actionHistoryHasHoverDetails(action: UserAction): boolean {
  const { materialAtRiskValue, riskScore, decisionRationale } = getActionHistoryHoverDetails(action);
  return materialAtRiskValue !== "—" || riskScore !== "—" || decisionRationale !== "—";
}
