import React from "react";

export interface VendorRawData {
  id: number;
  name: string;
  materials_at_risk?: number;
  total_materials?: number;
  sales_volume?: number | null;
  sales_amount?: number | null;
  risk_adjusted_value?: number | null;
  service_levels_90_days?: Array<{
    material__vendor_id?: string;
    date: string;
    avg_fill_rate: number;
    total_order_qty?: number;
    total_received_qty?: number;
  }>;
  vendor_nbr: string;
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  risk_rating: number;
  driving_risk: string;
  created_at: string;
  updated_at: string;
}

export interface CardBadge {
  className: string;
  text: string;
}

export interface VendorCard {
  title: string;
  subtitle?: string;
  value: string;
  chart?: React.ReactNode;
  chartHeight?: string;
  hasHeader?: boolean;
  badge?: CardBadge;
}

// Number formatting utility
export const formatNumber = (num: number): string => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(2) + "M";
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(2) + "K";
  }
  return num.toLocaleString("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
};

type FormatStyles = "currency" | "decimal" | "percent" | "unit";

export const formatTwoDecimal = (amount: number, style: FormatStyles = "decimal") => {
  return new Intl.NumberFormat("en-US", {
    style,
    currency: "USD",
    notation: "compact",
    compactDisplay: "short",
    maximumFractionDigits: 2,
  }).format(amount);
};

export const roundToTwoDecimals = (number: number) => Math.round((number + Number.EPSILON) * 100) / 100;

/** USD for sales column: e.g. $636.59M (2 decimals in M/K tiers). */
function formatSalesCurrencyUsd(amount: number): string {
  if (amount >= 1_000_000) {
    return `$${(amount / 1_000_000).toFixed(2)}M`;
  }
  if (amount >= 1_000) {
    return `$${(amount / 1_000).toFixed(2)}K`;
  }
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

/** Unit count for sales column: e.g. 5.8M (matches compact K/M style). */
function formatSalesUnitsCompact(qty: number): string {
  if (qty >= 1_000_000) {
    return `${(qty / 1_000_000).toFixed(2)}M`;
  }
  if (qty >= 1_000) {
    return `${(qty / 1_000).toFixed(2)}K`;
  }
  return qty.toLocaleString("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
}

/** e.g. $636.59M / 5.8M */
export function formatSalesRevenueAndQuantity(
  salesAmount: number | null | undefined,
  salesVolume: number | null | undefined
): string {
  if (salesAmount != null && salesVolume != null && salesAmount && salesVolume) {
    return `${formatSalesCurrencyUsd(salesAmount)} / ${formatSalesUnitsCompact(salesVolume)}`;
  }
  return "- / -";
}

// Determine risk badge based on risk_rating value
export const getRiskBadge = (riskRating: number) => {
  if (riskRating >= 0.0 && riskRating <= 0.2) {
    return {
      text: "Highly Unlikely",
      bgColor: "bg-green-100",
      textColor: "text-green-700",
      borderColor: "border-green-700",
      hexColor: "#16a34a", // green-600 for bar chart
    };
  } else if (riskRating >= 0.21 && riskRating <= 0.4) {
    return {
      text: "Unlikely",
      bgColor: "bg-green-100",
      textColor: "text-green-700",
      borderColor: "border-green-700",
      hexColor: "#16a34a", // green-600 for bar chart
    };
  } else if (riskRating >= 0.41 && riskRating <= 0.6) {
    return {
      text: "Even Chance",
      bgColor: "bg-yellow-100",
      textColor: "text-yellow-700",
      borderColor: "border-yellow-700",
      hexColor: "#FFA400", // yellow for bar chart
    };
  } else if (riskRating >= 0.61 && riskRating <= 0.8) {
    return {
      text: "Likely",
      bgColor: "bg-yellow-100",
      textColor: "text-yellow-700",
      borderColor: "border-yellow-700",
      hexColor: "#FFA400", // yellow for bar chart
    };
  } else {
    // 0.81 - 1.0 (Highly Likely)
    return {
      text: "Highly Likely",
      bgColor: "bg-red-100",
      textColor: "text-red-700",
      borderColor: "border-red-700",
      hexColor: "#dc2626", // red for bar chart
    };
  }
};

// URL Query Parameter utilities
export const serializeFilters = (filters: any, preserveGlobalFilters: boolean = true): URLSearchParams => {
  const params = new URLSearchParams();

  // Preserve existing global filters (gf_*) from current URL if requested
  if (preserveGlobalFilters && typeof window !== "undefined") {
    const currentParams = new URLSearchParams(window.location.search);
    currentParams.forEach((value, key) => {
      if (key.startsWith("gf_")) {
        params.append(key, value);
      }
    });
  }

  // Add local filter params
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== "") {
      params.set(key, value.toString());
    }
  });

  return params;
};

export const deserializeFilters = (searchParams: URLSearchParams): any => {
  const filters = {
    search: "",
    ordering: "-risk_rating,-risk_adjusted_value",
    risk_rating_min: null as number | null,
    risk_rating_max: null as number | null,
    driving_risk: "",
    primary_risk: "",
    risk_adjusted_value_min: null as number | null,
    risk_adjusted_value_max: null as number | null,
    sales_amount_min: null as number | null,
    sales_amount_max: null as number | null,
    sales_volume_min: null as number | null,
    sales_volume_max: null as number | null,
    materials_at_risk_min: null as number | null,
    materials_at_risk_max: null as number | null,
  };

  // Parse URL parameters
  for (const [key, value] of searchParams.entries()) {
    if (key in filters) {
      if (key === "ordering" || key === "driving_risk" || key === "primary_risk" || key === "search") {
        (filters as any)[key] = value;
      } else {
        // Convert numeric values
        const numValue = Number(value);
        if (!isNaN(numValue)) {
          (filters as any)[key] = numValue;
        }
      }
    }
  }

  return filters;
};
