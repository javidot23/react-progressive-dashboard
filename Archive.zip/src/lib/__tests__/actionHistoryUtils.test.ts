import { actionHistoryHasHoverDetails, getActionHistoryHoverDetails } from "@/lib/actionHistoryUtils";
import type { UserAction } from "@/lib/apiServices";

const baseAction: UserAction = {
  id: 1,
  issue_nbr: "ISS-1",
  user_id: "u1",
  user: { id: "u1", first_name: "Jane", last_name: "Doe" },
  created_at: "2026-05-19T09:00:00Z",
  updated_at: "2026-05-19T09:00:00Z",
  potential_action: null,
  action: "no_action",
  substituted_material: null,
  material_number: "MAT-1",
  material_name: "Test",
  vendor_name: "Vendor",
};

describe("getActionHistoryHoverDetails", () => {
  it("reads material snapshot and decision rationale from action payload", () => {
    const action: UserAction = {
      ...baseAction,
      material_context: {
        material_dollars_at_risk: 125000,
        material_risk_rating: 0.72,
      },
      decision_feedback: {
        decision_rationale: "Supplier confirmed recovery within 2 weeks.",
      },
    };

    const details = getActionHistoryHoverDetails(action);

    expect(details.materialAtRiskValue).toContain("$125");
    expect(details.riskScore).toBe("72 / 100");
    expect(details.decisionRationale).toBe("Supplier confirmed recovery within 2 weeks.");
    expect(actionHistoryHasHoverDetails(action)).toBe(true);
  });

  it("returns em dash placeholders when snapshot fields are missing", () => {
    const details = getActionHistoryHoverDetails(baseAction);
    expect(details.materialAtRiskValue).toBe("—");
    expect(details.riskScore).toBe("—");
    expect(details.decisionRationale).toBe("—");
    expect(actionHistoryHasHoverDetails(baseAction)).toBe(false);
  });
});
