import {
  shouldRedirectOnUnauthorized,
  suppressAuthRedirects,
  resetAuthRedirectSuppression,
} from "@/lib/apiClient";

describe("shouldRedirectOnUnauthorized", () => {
  const originalPathname = window.location.pathname;

  afterEach(() => {
    resetAuthRedirectSuppression();
    window.history.replaceState({}, "", originalPathname || "/");
  });

  it("redirects on protected routes by default", () => {
    window.history.replaceState({}, "", "/overview");
    expect(shouldRedirectOnUnauthorized()).toBe(true);
  });

  it("does not redirect when skipAuthRedirect is set", () => {
    window.history.replaceState({}, "", "/overview");
    expect(shouldRedirectOnUnauthorized({ skipAuthRedirect: true })).toBe(false);
  });

  it("does not redirect on public auth paths", () => {
    window.history.replaceState({}, "", "/login");
    expect(shouldRedirectOnUnauthorized()).toBe(false);
  });

  it("does not redirect while auth redirects are suppressed (logout)", () => {
    window.history.replaceState({}, "", "/overview");
    suppressAuthRedirects();
    expect(shouldRedirectOnUnauthorized()).toBe(false);
  });
});
