import { buildCsSalesFiltersConfig, buildManageSalesFiltersConfig } from "@/lib/filterConfigs";

describe("buildCsSalesFiltersConfig", () => {
  it("includes only measure and period when no federal indicators are provided", () => {
    const config = buildCsSalesFiltersConfig("historical", []);

    expect(config.dropdowns?.map(d => d.key)).toEqual(["measure", "period"]);
    expect(config.customOrder).toEqual(["measure", "period"]);
  });

  it("includes only measure and period when only NC is available", () => {
    const config = buildCsSalesFiltersConfig("current", ["NC"]);

    expect(config.dropdowns?.map(d => d.key)).toEqual(["measure", "period"]);
    expect(config.customOrder).toEqual(["measure", "period"]);
  });

  it("includes filter by schedule dropdown when controlled substances exist", () => {
    const config = buildCsSalesFiltersConfig("current", ["2", "NC"]);

    expect(config.dropdowns?.map(d => d.key)).toEqual(["measure", "period", "federal_cs_ind"]);
    expect(config.customOrder).toEqual(["measure", "period", "federal_cs_ind"]);

    const scheduleDropdown = config.dropdowns?.find(d => d.key === "federal_cs_ind");
    expect(scheduleDropdown?.label).toBe("Filter by schedule");
    expect(scheduleDropdown?.options).toEqual(["Schedule 2", "Not Controlled"]);
  });

  it("uses historical period options for the historical tab", () => {
    const config = buildCsSalesFiltersConfig("historical", []);

    const periodDropdown = config.dropdowns?.find(d => d.key === "period");
    expect(periodDropdown?.options).toEqual(["Last 3 months", "Last 6 months", "Last 12 months"]);
  });

  it("uses current period options for the current tab", () => {
    const config = buildCsSalesFiltersConfig("current", []);

    const periodDropdown = config.dropdowns?.find(d => d.key === "period");
    expect(periodDropdown?.options).toEqual(["Last week", "Week to date", "Month to date", "Last month"]);
  });
});

describe("buildManageSalesFiltersConfig", () => {
  it("returns no dropdowns when only NC is available", () => {
    const config = buildManageSalesFiltersConfig(["NC"]);

    expect(config.dropdowns).toEqual([]);
    expect(config.customOrder).toEqual([]);
  });

  it("returns schedule dropdown when controlled substances exist", () => {
    const config = buildManageSalesFiltersConfig(["2", "NC"]);

    expect(config.dropdowns?.map(d => d.key)).toEqual(["federal_cs_ind"]);
    expect(config.customOrder).toEqual(["federal_cs_ind"]);
    expect(config.dropdowns?.[0]?.label).toBe("Filter by schedule");
  });
});
