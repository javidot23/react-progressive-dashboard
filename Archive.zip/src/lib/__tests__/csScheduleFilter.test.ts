import {
  buildCsScheduleApiParams,
  tenantHasControlledSubstances,
} from "@/lib/csScheduleFilter";

describe("csScheduleFilter", () => {
  describe("tenantHasControlledSubstances", () => {
    it("returns false when only NC is present", () => {
      expect(tenantHasControlledSubstances(["NC"])).toBe(false);
    });

    it("returns false for an empty list", () => {
      expect(tenantHasControlledSubstances([])).toBe(false);
    });

    it("returns true when any non-NC schedule is present", () => {
      expect(tenantHasControlledSubstances(["NC", "2"])).toBe(true);
      expect(tenantHasControlledSubstances(["3"])).toBe(true);
    });
  });

  describe("buildCsScheduleApiParams", () => {
    it("returns empty object when no schedule is selected", () => {
      expect(buildCsScheduleApiParams()).toEqual({});
      expect(buildCsScheduleApiParams("")).toEqual({});
    });

    it("returns federal_cs_ind when a schedule is selected", () => {
      expect(buildCsScheduleApiParams("NC")).toEqual({ federal_cs_ind: "NC" });
      expect(buildCsScheduleApiParams("2")).toEqual({ federal_cs_ind: "2" });
    });
  });
});
