import { toWafSafeQueryString } from '../queryStringUtils';

describe('toWafSafeQueryString', () => {
  it('leaves slashes unencoded for WAF-safe query strings', () => {
    const params = new URLSearchParams();
    params.set('gcn', 'butalb/acetaminophen/caffeine---TABLET');

    expect(toWafSafeQueryString(params)).toBe(
      'gcn=butalb/acetaminophen/caffeine---TABLET'
    );
  });

  it('leaves commas unencoded for multi-value filter params', () => {
    const params = new URLSearchParams();
    params.set('supplier_nbr', '124234,3425352,34235345');

    expect(toWafSafeQueryString(params)).toBe('supplier_nbr=124234,3425352,34235345');
  });

  it('handles global filter URL params with slashes', () => {
    const params = new URLSearchParams();
    params.set('gf_gcn', 'butalb/acetaminophen/caffeine---TABLET');

    expect(toWafSafeQueryString(params)).toBe(
      'gf_gcn=butalb/acetaminophen/caffeine---TABLET'
    );
  });

  it('still encodes other reserved characters like spaces and ampersands', () => {
    const params = new URLSearchParams();
    params.set('search', 'foo & bar');

    expect(toWafSafeQueryString(params)).toBe('search=foo+%26+bar');
  });
});
