import {
  buildContributorTimeline,
  buildRiskCategorySummaries,
  isAggregateOrCategoryRiskRow,
  isContributorRiskRow,
} from "@/lib/riskCategoryUtils";
import type { EnrichedMaterialRiskRow } from "@/lib/riskCategoryUtils";

const riskCategoryTypes = [
  { type: "base_model_operational", title: "Operational Risk" },
  { type: "base_model_market", title: "Market Risk" },
];

function row(
  partial: Partial<EnrichedMaterialRiskRow> & Pick<EnrichedMaterialRiskRow, "id" | "original_risk_type" | "risk_type">
): EnrichedMaterialRiskRow {
  return {
    id: partial.id,
    risk_type: partial.risk_type,
    original_risk_type: partial.original_risk_type,
    risk_rating: partial.risk_rating ?? 0.5,
    time_horizon: partial.time_horizon ?? 30,
    created_at: "2026-01-01",
    updated_at: "2026-01-01",
    material: 1,
    risk_description: partial.risk_description ?? "",
    display_name: partial.display_name ?? partial.original_risk_type,
    status_date: partial.status_date,
  };
}

describe("riskCategoryUtils", () => {
  it("treats category_risk rows as aggregates, not contributors", () => {
    const categoryRow = row({
      id: 1,
      original_risk_type: "category_risk_operational",
      risk_type: "category_risk_group",
    });
    expect(isAggregateOrCategoryRiskRow(categoryRow)).toBe(true);
    expect(isContributorRiskRow(categoryRow)).toBe(false);
  });

  it("treats mapped leaf models as contributors", () => {
    const contributor = row({
      id: 2,
      original_risk_type: "forecast_error_model",
      risk_type: "base_model_operational",
      display_name: "Forecast Error",
    });
    expect(isContributorRiskRow(contributor)).toBe(true);
  });

  it("builds category summaries from category_risk scores at 30-day horizon", () => {
    const data = [
      row({
        id: 10,
        original_risk_type: "category_risk_operational",
        risk_type: "category_risk_group",
        risk_rating: 0.75,
        time_horizon: 30,
      }),
      row({
        id: 11,
        original_risk_type: "forecast_error_model",
        risk_type: "base_model_operational",
        risk_rating: 0.8,
      }),
    ];

    const summaries = buildRiskCategorySummaries(data, riskCategoryTypes);
    expect(summaries[0].score).toBe(75);
    expect(summaries[0].title).toBe("Operational Risk");
  });

  it("excludes aggregates from contributor timeline", () => {
    const data = [
      row({
        id: 10,
        original_risk_type: "category_risk_operational",
        risk_type: "category_risk_group",
        risk_rating: 0.75,
        time_horizon: 30,
      }),
      row({
        id: 2,
        original_risk_type: "forecast_error_model",
        risk_type: "base_model_operational",
        display_name: "Forecast Error",
        risk_rating: 0.8,
      }),
    ];

    const timeline = buildContributorTimeline(data);
    expect(timeline).toHaveLength(1);
    expect(timeline[0].riskTypeLabel).toBe("Forecast Error");
  });
});
