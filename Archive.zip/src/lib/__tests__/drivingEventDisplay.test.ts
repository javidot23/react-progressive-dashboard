import {
  formatDrivingEventDateRange,
  formatDrivingEventSummary,
  getDrivingEventStatusLabel,
  getDrivingEventStatusTone,
} from "@/lib/drivingEventDisplay";
import type { DrivingEvent } from "@/types/granularityIssue";

const baseEvent: DrivingEvent = {
  id: 1,
  event_id: "EVT-1",
  type: "Hurricane",
  type_description: "Category 4 storm approaching Gulf Coast",
  status: "ACTIVE",
  start_date: "2026-01-01",
  end_date: null,
  latitude: null,
  longitude: null,
  city: "Miami",
  state: "FL",
  country: "USA",
  mat_nbr: null,
  metadata: null,
  scrm_mat_grp: null,
};

describe("drivingEventDisplay", () => {
  it("normalizes status tone and labels", () => {
    expect(getDrivingEventStatusTone("ACTIVE")).toBe("active");
    expect(getDrivingEventStatusTone("CLOSED")).toBe("closed");
    expect(getDrivingEventStatusTone("MONITORING")).toBe("neutral");
    expect(getDrivingEventStatusLabel("ACTIVE")).toBe("Active");
    expect(getDrivingEventStatusLabel("OPEN")).toBe("Open");
    expect(getDrivingEventStatusLabel("CLOSED")).toBe("Closed");
  });

  it("formats date ranges with ongoing suffix for active events", () => {
    expect(formatDrivingEventDateRange(baseEvent)).toMatch(/Ongoing/);
  });

  it("builds a readable summary string", () => {
    const summary = formatDrivingEventSummary(baseEvent);
    expect(summary).toContain("Hurricane");
    expect(summary).toContain("Active");
    expect(summary).toContain("Miami, FL, USA");
    expect(summary).toContain("EVT-1");
  });
});
