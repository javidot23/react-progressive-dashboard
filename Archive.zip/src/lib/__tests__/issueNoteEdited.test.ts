import { issueNoteShowsEditedLabel } from "@/lib/issueNoteEdited";

describe("issueNoteShowsEditedLabel", () => {
  it("returns false when strings are identical", () => {
    const t = "2026-05-04T10:55:14.027034Z";
    expect(issueNoteShowsEditedLabel(t, t)).toBe(false);
  });

  it("returns false for sub-second jitter under default threshold", () => {
    expect(
      issueNoteShowsEditedLabel(
        "2026-05-04T10:55:14.027034Z",
        "2026-05-04T10:55:14.027046Z",
      ),
    ).toBe(false);
  });

  it("returns false for small ms drift within threshold", () => {
    expect(
      issueNoteShowsEditedLabel(
        "2026-05-04T10:57:20.828234Z",
        "2026-05-04T10:57:20.828255Z",
      ),
    ).toBe(false);
  });

  it("returns true when updated is materially later than created", () => {
    expect(
      issueNoteShowsEditedLabel(
        "2026-05-04T10:50:35.163783Z",
        "2026-05-04T12:36:04.315036Z",
      ),
    ).toBe(true);
  });

  it("falls back to string inequality when a value is not parseable as a date", () => {
    expect(issueNoteShowsEditedLabel("not-a-date", "not-a-date")).toBe(false);
    expect(issueNoteShowsEditedLabel("not-a-date", "also-bad")).toBe(true);
  });
});
