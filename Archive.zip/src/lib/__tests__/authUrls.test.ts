import { getEndSessionUrl } from "@/lib/authUrls";

describe("getEndSessionUrl", () => {
  it("reads end_session_url from the standard success/data envelope", () => {
    expect(
      getEndSessionUrl({
        success: true,
        data: { end_session_url: "https://idp.example/logout?id_token_hint=abc" },
      }),
    ).toBe("https://idp.example/logout?id_token_hint=abc");
  });

  it("returns null when nested end_session_url is null", () => {
    expect(
      getEndSessionUrl({
        success: true,
        data: { end_session_url: null },
      }),
    ).toBeNull();
  });

  it("returns null when nested end_session_url is empty", () => {
    expect(
      getEndSessionUrl({
        success: true,
        data: { end_session_url: "" },
      }),
    ).toBeNull();
  });

  it("falls back to a flat end_session_url for resilience", () => {
    expect(
      getEndSessionUrl({
        end_session_url: "https://idp.example/logout",
      }),
    ).toBe("https://idp.example/logout");
  });

  it("prefers nested end_session_url over flat", () => {
    expect(
      getEndSessionUrl({
        success: true,
        data: { end_session_url: "https://nested.example/logout" },
        end_session_url: "https://flat.example/logout",
      }),
    ).toBe("https://nested.example/logout");
  });

  it("returns null for undefined or empty body", () => {
    expect(getEndSessionUrl(undefined)).toBeNull();
    expect(getEndSessionUrl(null)).toBeNull();
    expect(getEndSessionUrl({})).toBeNull();
  });
});
