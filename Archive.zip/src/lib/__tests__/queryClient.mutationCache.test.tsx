import "@testing-library/jest-dom";
import { act, renderHook } from "@testing-library/react";
import { QueryClient, QueryClientProvider, useMutation } from "@tanstack/react-query";
import React from "react";
import { createToastMutationCache } from "@/lib/queryClient";
import { toast } from "@/lib/toast";

jest.mock("@/lib/toast", () => ({
  toast: {
    success: jest.fn(),
    error: jest.fn(),
    dismiss: jest.fn(),
  },
}));

function wrapperWithCache(client: QueryClient) {
  return function Wrapper({ children }: { children: React.ReactNode }) {
    return <QueryClientProvider client={client}>{children}</QueryClientProvider>;
  };
}

describe("createToastMutationCache", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("shows success toast when meta.successMessage is a string", async () => {
    const client = new QueryClient({
      mutationCache: createToastMutationCache(),
      defaultOptions: { mutations: { retry: false } },
    });
    const { result } = renderHook(
      () =>
        useMutation({
          mutationFn: async () => "ok",
          meta: { successMessage: "Saved" },
        }),
      { wrapper: wrapperWithCache(client) }
    );

    await act(async () => {
      await result.current.mutateAsync();
    });

    expect(toast.success).toHaveBeenCalledWith({ title: "Saved" });
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("invokes function successMessage with data and variables", async () => {
    const client = new QueryClient({
      mutationCache: createToastMutationCache(),
      defaultOptions: { mutations: { retry: false } },
    });
    const successMessage = jest.fn((data: unknown, variables: unknown) => `v-${variables}-${data}`);

    const { result } = renderHook(
      () =>
        useMutation({
          mutationFn: async (v: string) => `d-${v}`,
          meta: { successMessage },
        }),
      { wrapper: wrapperWithCache(client) }
    );

    await act(async () => {
      await result.current.mutateAsync("x");
    });

    expect(successMessage).toHaveBeenCalledWith("d-x", "x");
    expect(toast.success).toHaveBeenCalledWith({ title: "v-x-d-x" });
  });

  it("shows error toast with meta.errorMessage and getErrorMessage description", async () => {
    const client = new QueryClient({
      mutationCache: createToastMutationCache(),
      defaultOptions: { mutations: { retry: false } },
    });
    const { result } = renderHook(
      () =>
        useMutation({
          mutationFn: async () => {
            throw new Error("boom");
          },
          meta: { errorMessage: "Write failed" },
        }),
      { wrapper: wrapperWithCache(client) }
    );

    await act(async () => {
      try {
        await result.current.mutateAsync();
      } catch {
        /* expected */
      }
    });

    expect(toast.error).toHaveBeenCalledWith(
      expect.objectContaining({
        title: "Write failed",
        description: "boom",
      })
    );
    expect(toast.success).not.toHaveBeenCalled();
  });

  it("skips success and error toasts when meta.silent is true", async () => {
    const client = new QueryClient({
      mutationCache: createToastMutationCache(),
      defaultOptions: { mutations: { retry: false } },
    });
    const { result } = renderHook(
      () =>
        useMutation({
          mutationFn: async () => {
            throw new Error("quiet");
          },
          meta: { silent: true, successMessage: "Nope", errorMessage: "Never" },
        }),
      { wrapper: wrapperWithCache(client) }
    );

    await act(async () => {
      try {
        await result.current.mutateAsync();
      } catch {
        /* expected */
      }
    });

    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("defaults error title to Something went wrong when errorMessage omitted", async () => {
    const client = new QueryClient({
      mutationCache: createToastMutationCache(),
      defaultOptions: { mutations: { retry: false } },
    });
    const { result } = renderHook(
      () =>
        useMutation({
          mutationFn: async () => {
            throw new Error("x");
          },
        }),
      { wrapper: wrapperWithCache(client) }
    );

    await act(async () => {
      try {
        await result.current.mutateAsync();
      } catch {
        /* expected */
      }
    });

    expect(toast.error).toHaveBeenCalledWith(
      expect.objectContaining({
        title: "Something went wrong",
      })
    );
  });
});
