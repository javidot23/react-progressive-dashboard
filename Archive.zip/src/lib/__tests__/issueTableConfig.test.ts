import {
  getDefaultIssueFeedColumns,
  getIssueCtaLabel,
  getIssueDisplayTitle,
  resolveIssueFeedTableScope,
} from "@/lib/issueTableConfig";
import type { GranularityIssueView } from "@/types/granularityIssue";

describe("issueTableConfig", () => {
  const aggregatedIssue: GranularityIssueView = {
    id: 10,
    productName: "HICL 16030",
    material: "Material",
    mat_nbr: "",
    ndc: "",
    ean: "",
    createdAt: "Jul 04, 2026",
    riskLevel: 87,
    drivingRisk: "PO Delivery Interruption",
    riskExposure: "$71.61K / $77.84K",
  actionStatus: "Not Reviewed",
  isCritical: true,
  isNewIssue: false,
  hasActions: false,
  granularityType: "hicl",
    granularityLabel: "HICL",
    granularityValue: "16030",
    isSingleMaterial: false,
    impactedMaterialCount: 1,
    group: "ROSS/Account Services",
    persona: "ROSS/Account Services",
    drivingEvent: {
      id: 1,
      event_id: "SCE-12346841",
      type: "PO Delivery Interruption",
      type_description: null,
      status: "OPEN",
      start_date: "2026-06-07",
      end_date: null,
      latitude: null,
      longitude: null,
      city: null,
      state: null,
      country: null,
      mat_nbr: null,
      metadata: null,
      scrm_mat_grp: null,
    },
  };

  it("resolves table scopes from granularity filters", () => {
    expect(resolveIssueFeedTableScope("")).toBe("mixed");
    expect(resolveIssueFeedTableScope("material")).toBe("material");
    expect(resolveIssueFeedTableScope("material_plant")).toBe("material");
    expect(resolveIssueFeedTableScope("gcn")).toBe("aggregated");
    expect(resolveIssueFeedTableScope("ndc")).toBe("aggregated");
    expect(resolveIssueFeedTableScope("hicl")).toBe("aggregated");
  });

  it("includes card-parity columns for aggregated issues", () => {
    const columns = getDefaultIssueFeedColumns("aggregated").map(column => column.id);
    expect(columns).toEqual(
      expect.arrayContaining([
        "issue_name",
        "granularity_value",
        "group",
        "issue_status",
        "driving_event",
        "materials_impacted",
        "risk_score",
        "primary_risk",
        "risk_adjusted_value",
        "notes",
        "action_status",
        "created_date",
        "recommended_actions",
      ]),
    );
  });

  it("builds aggregated issue titles and CTA labels like the card", () => {
    expect(getIssueDisplayTitle(aggregatedIssue)).toBe("HICL 16030");
    expect(getIssueCtaLabel(aggregatedIssue)).toBe("View 1 materials and take action");
  });
});
