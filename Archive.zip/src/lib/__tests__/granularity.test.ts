import { mapGranularityIssue, getGranularityValue, getGranularityLabel } from "@/lib/granularity";
import type { IssueAtGranularityApiData } from "@/types/granularityIssue";

const identity = (riskType: string) => ({ display_name: `Display: ${riskType}` });

function makeIssue(overrides: Partial<IssueAtGranularityApiData> = {}): IssueAtGranularityApiData {
  return {
    id: 1,
    issue_nbr: "ISS-1",
    event_id: "SCE-1",
    status: "OPEN",
    date_identified: "2020-01-01",
    start_date: "2020-01-01",
    granularity_type: "gcn",
    fdb_gcn_seq_nbr: null,
    ndc: null,
    fei_number: null,
    hicl: null,
    hicl_description: null,
    plant: null,
    material: null,
    impacted_material_count: 5,
    effective_risk_rating: 0.87,
    effective_dollars_at_risk: 99594.34,
    effective_risk_adjusted_value: 86647.07,
    driving_event: null,
    has_actions: false,
    notes_count: 0,
    last_note: null,
    group: null,
    persona: null,
    ...overrides,
  };
}

describe("getGranularityValue", () => {
  it("returns the GCN seq for a gcn grain", () => {
    expect(getGranularityValue(makeIssue({ granularity_type: "gcn", fdb_gcn_seq_nbr: "635410" }))).toBe("635410");
  });

  it("joins gcn:plant for a gcn_plant grain", () => {
    expect(
      getGranularityValue(makeIssue({ granularity_type: "gcn_plant", fdb_gcn_seq_nbr: "68508", plant: "220" }))
    ).toBe("68508:220");
  });

  it("returns the ndc / fei / hicl identifiers per grain", () => {
    expect(getGranularityValue(makeIssue({ granularity_type: "ndc", ndc: "12345-678-90" }))).toBe("12345-678-90");
    expect(getGranularityValue(makeIssue({ granularity_type: "fei", fei_number: "3013023419" }))).toBe("3013023419");
    expect(getGranularityValue(makeIssue({ granularity_type: "hicl", hicl: "11814" }))).toBe("11814");
  });

  it("returns the mat_nbr for a material grain", () => {
    const issue = makeIssue({
      granularity_type: "material",
      material: { id: 9, mat_nbr: "10178153", name: "Drug", ndc: "1", risk_rating: 0.5, driving_risk: "x", dollars_at_risk: 1 },
    });
    expect(getGranularityValue(issue)).toBe("10178153");
  });
});

describe("getGranularityLabel", () => {
  it("maps known grains and falls back to 'Issue'", () => {
    expect(getGranularityLabel("gcn")).toBe("GCN");
    expect(getGranularityLabel("fei")).toBe("Facility·FEI");
    expect(getGranularityLabel("unknown")).toBe("Issue");
    expect(getGranularityLabel(undefined)).toBe("Issue");
  });
});

describe("mapGranularityIssue", () => {
  it("maps an aggregated (gcn) issue with effective metrics", () => {
    const view = mapGranularityIssue(
      makeIssue({ granularity_type: "gcn", fdb_gcn_seq_nbr: "635410", impacted_material_count: 5 }),
      identity
    );
    expect(view.granularityLabel).toBe("GCN");
    expect(view.granularityValue).toBe("635410");
    expect(view.isSingleMaterial).toBe(false);
    expect(view.impactedMaterialCount).toBe(5);
    expect(view.riskLevel).toBe(87);
    expect(view.effectiveDollarsAtRisk).toBe(99594.34);
  });

  it("treats a single material grain as single-material and surfaces nested material detail", () => {
    const view = mapGranularityIssue(
      makeIssue({
        granularity_type: "material",
        impacted_material_count: 1,
        material: {
          id: 421,
          mat_nbr: "10001234",
          name: "Example Drug 50mg",
          ndc: "12345-678-90",
          ean_n4_nbr_11: "E11",
          risk_rating: 0.87,
          driving_risk: "FDA Inspection",
          dollars_at_risk: 99594.34,
          xplant_mat_stat: "AC",
          vendor: { id: 7, name: "Acme Pharma", vendor_nbr: "V-0099" },
        },
      }),
      identity
    );
    expect(view.isSingleMaterial).toBe(true);
    expect(view.mat_nbr).toBe("10001234");
    expect(view.productName).toBe("Example Drug 50mg");
    expect(view.vendorName).toBe("Acme Pharma");
    expect(view.vendorNbr).toBe("V-0099");
    expect(view.materialId).toBe(421);
  });

  it("enriches driving risk via the metadata resolver", () => {
    const view = mapGranularityIssue(
      makeIssue({ driving_event: { ...eventStub, type: "FDA Inspection" } }),
      identity
    );
    expect(view.drivingRisk).toBe("Display: FDA Inspection");
  });

  it("flags today's issues as new", () => {
    const today = new Date().toISOString().slice(0, 10);
    const view = mapGranularityIssue(makeIssue({ date_identified: today }), identity);
    expect(view.isNewIssue).toBe(true);
  });

  it("maps has_actions to action status and hasActions on the view", () => {
    const reviewed = mapGranularityIssue(makeIssue({ has_actions: true }), identity);
    expect(reviewed.hasActions).toBe(true);
    expect(reviewed.actionStatus).toBe("Reviewed");

    const notReviewed = mapGranularityIssue(makeIssue({ has_actions: false }), identity);
    expect(notReviewed.hasActions).toBe(false);
    expect(notReviewed.actionStatus).toBe("Not Reviewed");
  });
});

const eventStub = {
  id: 1,
  event_id: "SCE-1",
  type: "FDA Inspection",
  type_description: null,
  status: "OPEN",
  start_date: "2020-01-01",
  end_date: null,
  latitude: null,
  longitude: null,
  city: null,
  state: null,
  country: null,
  mat_nbr: null,
  metadata: null,
  scrm_mat_grp: null,
};
