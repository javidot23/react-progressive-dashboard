import {
  serializeGranularityIssueFilters,
  deserializeGranularityIssueFilters,
  mergeGranularityIssueFiltersIntoParams,
} from "@/lib/granularityIssueFilterUtils";
import { granularityIssueAppliedFiltersConfig } from "@/lib/filterConfigs";

describe("granularityIssueFilterUtils", () => {
  const defaults = granularityIssueAppliedFiltersConfig.defaultFilters;

  it("defaults ordering to -effective_risk_adjusted_value, not material-level keys", () => {
    const filters = deserializeGranularityIssueFilters(new URLSearchParams());
    expect(filters.ordering).toBe("-effective_risk_adjusted_value");
    expect(filters.ordering).not.toBe("-risk_adjusted_value");
  });

  it("omits default ordering from serialized URL params", () => {
    const params = serializeGranularityIssueFilters(defaults);
    expect(params.get("ordering")).toBeNull();
  });

  it("serializes and deserializes effective_* range filters", () => {
    const filters = {
      ...defaults,
      effective_risk_rating_min: 0.61,
      effective_risk_rating_max: 0.8,
      effective_risk_adjusted_value_min: 1000,
      effective_risk_adjusted_value_max: 50000,
      effective_dollars_at_risk_min: 2000,
      effective_dollars_at_risk_max: 100000,
      impacted_material_count_min: 2,
      impacted_material_count_max: 10,
    };

    const params = serializeGranularityIssueFilters(filters);
    expect(params.get("effective_risk_rating_min")).toBe("0.61");
    expect(params.get("effective_risk_rating_max")).toBe("0.8");
    expect(params.get("effective_risk_adjusted_value_min")).toBe("1000");
    expect(params.get("effective_dollars_at_risk_max")).toBe("100000");
    expect(params.get("impacted_material_count_min")).toBe("2");

    const restored = deserializeGranularityIssueFilters(params);
    expect(restored.effective_risk_rating_min).toBe(0.61);
    expect(restored.effective_risk_rating_max).toBe(0.8);
    expect(restored.effective_risk_adjusted_value_min).toBe(1000);
    expect(restored.effective_risk_adjusted_value_max).toBe(50000);
    expect(restored.effective_dollars_at_risk_min).toBe(2000);
    expect(restored.effective_dollars_at_risk_max).toBe(100000);
    expect(restored.impacted_material_count_min).toBe(2);
    expect(restored.impacted_material_count_max).toBe(10);
  });

  it("serializes non-default ordering and group", () => {
    const filters = {
      ...defaults,
      ordering: "-effective_dollars_at_risk",
      group: "SGS",
    };
    const params = serializeGranularityIssueFilters(filters);
    expect(params.get("ordering")).toBe("-effective_dollars_at_risk");
    expect(params.get("group")).toBe("SGS");

    const restored = deserializeGranularityIssueFilters(params);
    expect(restored.ordering).toBe("-effective_dollars_at_risk");
    expect(restored.group).toBe("SGS");
  });

  it("serializes group values containing slashes", () => {
    const filters = { ...defaults, group: "ROSS/Account Services" };
    const params = serializeGranularityIssueFilters(filters);
    expect(params.get("group")).toBe("ROSS/Account Services");

    const restored = deserializeGranularityIssueFilters(params);
    expect(restored.group).toBe("ROSS/Account Services");
  });

  it("migrates legacy material-level URL keys to effective_* equivalents", () => {
    const params = new URLSearchParams({
      risk_rating_min: "0.21",
      risk_rating_max: "0.4",
      risk_adjusted_value_min: "5000",
      dollars_at_risk_max: "99999",
      ordering: "-risk_adjusted_value",
    });

    const restored = deserializeGranularityIssueFilters(params);
    expect(restored.effective_risk_rating_min).toBe(0.21);
    expect(restored.effective_risk_rating_max).toBe(0.4);
    expect(restored.effective_risk_adjusted_value_min).toBe(5000);
    expect(restored.effective_dollars_at_risk_max).toBe(99999);
    expect(restored.ordering).toBe("-risk_adjusted_value");
  });

  it("prefers effective_* keys over legacy keys when both are present", () => {
    const params = new URLSearchParams({
      risk_rating_min: "0.21",
      effective_risk_rating_min: "0.61",
    });

    const restored = deserializeGranularityIssueFilters(params);
    expect(restored.effective_risk_rating_min).toBe(0.61);
  });

  it("mergeGranularityIssueFiltersIntoParams preserves level and view", () => {
    const current = new URLSearchParams({
      level: "gcn",
      view: "card",
      gf_vendor_nbr: "123",
      ordering: "-effective_risk_adjusted_value",
    });
    const filters = {
      ...defaults,
      group: "SGS",
    };
    const merged = mergeGranularityIssueFiltersIntoParams(current, filters);
    expect(merged.get("level")).toBe("gcn");
    expect(merged.get("view")).toBe("card");
    expect(merged.get("gf_vendor_nbr")).toBe("123");
    expect(merged.get("group")).toBe("SGS");
  });

  it("serializes and deserializes has_no_actions as a boolean", () => {
    const notReviewed = { ...defaults, has_no_actions: true as boolean | undefined };
    const notReviewedParams = serializeGranularityIssueFilters(notReviewed);
    expect(notReviewedParams.get("has_no_actions")).toBe("true");
    expect(deserializeGranularityIssueFilters(notReviewedParams).has_no_actions).toBe(true);

    const reviewed = { ...defaults, has_no_actions: false as boolean | undefined };
    const reviewedParams = serializeGranularityIssueFilters(reviewed);
    expect(reviewedParams.get("has_no_actions")).toBe("false");
    expect(deserializeGranularityIssueFilters(reviewedParams).has_no_actions).toBe(false);
  });

  it("omits has_no_actions from serialized URL params when undefined (All)", () => {
    const params = serializeGranularityIssueFilters(defaults);
    expect(params.get("has_no_actions")).toBeNull();
  });
});
