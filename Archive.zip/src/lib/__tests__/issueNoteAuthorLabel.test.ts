import { issueNoteAuthorLabel } from "@/lib/issueNoteAuthorLabel";
import type { IssueNote } from "@/services/issueNotesService";

function baseNote(overrides: Partial<IssueNote> = {}): IssueNote {
  return {
    id: "1",
    content: "x",
    user_id: "user",
    created_at: "",
    updated_at: "",
    is_my_note: false,
    ...overrides,
  };
}

describe("issueNoteAuthorLabel", () => {
  it("uses first + last name when present", () => {
    expect(
      issueNoteAuthorLabel(
        baseNote({
          user_data: { first_name: "Mentor", last_name: "Aliu" },
        })
      )
    ).toBe("Mentor Aliu");
  });

  it("falls back to email local-part", () => {
    expect(
      issueNoteAuthorLabel(
        baseNote({
          user_data: { email: "mentor.aliu@example.com" },
        })
      )
    ).toBe("mentor.aliu");
  });

  it("does not show raw UUID as author when name is missing", () => {
    const uid = "f0d457cf-9d69-4be6-b9f9-363b6bd5f8d7";
    expect(issueNoteAuthorLabel(baseNote({ user_id: uid }))).toBe("Unknown");
  });
});
