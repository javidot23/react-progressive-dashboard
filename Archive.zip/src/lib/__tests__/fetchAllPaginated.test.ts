import { fetchAllPaginated } from "@/lib/fetchAllPaginated";

describe("fetchAllPaginated", () => {
  it("aggregates multiple pages until next is null", async () => {
    const fetchPage = jest
      .fn()
      .mockResolvedValueOnce({
        results: [{ id: 1 }, { id: 2 }],
        count: 3,
        next: "page-2",
      })
      .mockResolvedValueOnce({
        results: [{ id: 3 }],
        count: 3,
        next: null,
      });

    const rows = await fetchAllPaginated({ fetchPage, pageSize: 2 });

    expect(rows).toEqual([{ id: 1 }, { id: 2 }, { id: 3 }]);
    expect(fetchPage).toHaveBeenCalledTimes(2);
    expect(fetchPage).toHaveBeenNthCalledWith(1, expect.objectContaining({ limit: 2, offset: 0 }));
    expect(fetchPage).toHaveBeenNthCalledWith(2, expect.objectContaining({ limit: 2, offset: 2 }));
  });

  it("respects maxRows", async () => {
    const fetchPage = jest.fn().mockResolvedValue({
      results: [{ id: 1 }, { id: 2 }, { id: 3 }],
      count: 10,
      next: "page-2",
    });

    const rows = await fetchAllPaginated({ fetchPage, pageSize: 3, maxRows: 2 });

    expect(rows).toEqual([{ id: 1 }, { id: 2 }]);
    expect(fetchPage).toHaveBeenCalledTimes(1);
  });
});
