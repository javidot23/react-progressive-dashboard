import { mapGFToBackend, getCurrentMode } from '../globalFiltersInterceptor';

describe('getCurrentMode route gating', () => {
  const setPath = (path: string) => window.history.pushState({}, '', path);

  it('applies global filters on the React feed', () => {
    setPath('/react');
    expect(getCurrentMode()).toBe('APPLY');
  });

  it('ignores global filters on the issue drill-through (issue-scoped data)', () => {
    setPath('/react/issue/123');
    expect(getCurrentMode()).toBe('IGNORE');
  });

  it('ignores global filters on the material drill-through', () => {
    setPath('/react/product/123');
    expect(getCurrentMode()).toBe('IGNORE');
  });

  it('ignores global filters on the material-centric detail page', () => {
    setPath('/react/material/421');
    expect(getCurrentMode()).toBe('IGNORE');
  });
});

describe('mapGFToBackend', () => {
  it('maps gf_supplier_parent to supplier_parent', () => {
    const result = mapGFToBackend({
      gf_supplier_parent: { ids: ['PARENT001'], labels: ['Parent Corp Alpha'] },
    });
    expect(result).toEqual({ supplier_parent: 'PARENT001' });
  });

  it('maps multiple supplier_parent values as comma-separated', () => {
    const result = mapGFToBackend({
      gf_supplier_parent: { ids: ['PARENT001', 'PARENT002'], labels: ['Alpha', 'Beta'] },
    });
    expect(result).toEqual({ supplier_parent: 'PARENT001,PARENT002' });
  });

  it('maps legacy single-value supplier_parent format', () => {
    const result = mapGFToBackend({
      gf_supplier_parent: { id: 'PARENT001', label: 'Parent Corp Alpha' },
    });
    expect(result).toEqual({ supplier_parent: 'PARENT001' });
  });

  it('includes supplier_parent alongside other filters', () => {
    const result = mapGFToBackend({
      gf_supplier: { ids: ['VEN001'], labels: ['Vendor 1'] },
      gf_supplier_parent: { ids: ['PARENT001'], labels: ['Parent Corp'] },
      gf_product_category: { id: 'Oncology', label: 'Oncology' },
    });
    expect(result).toEqual({
      supplier_nbr: 'VEN001',
      supplier_parent: 'PARENT001',
      product_category: 'Oncology',
    });
  });

  it('ignores keys not starting with gf_', () => {
    const result = mapGFToBackend({
      supplier_parent: { id: 'PARENT001', label: 'Parent' },
    });
    expect(result).toEqual({});
  });

  it('maps gf_fee_for_service to fee_for_service with 0/1 values', () => {
    expect(mapGFToBackend({ gf_fee_for_service: { id: '1', label: 'Yes' } })).toEqual({
      fee_for_service: '1',
    });
    expect(mapGFToBackend({ gf_fee_for_service: { id: '0', label: 'No' } })).toEqual({
      fee_for_service: '0',
    });
  });
});
