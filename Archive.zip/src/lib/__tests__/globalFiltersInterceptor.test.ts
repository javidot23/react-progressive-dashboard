import {
  mapGFToBackend,
  getCurrentMode,
  getExcludedParamForFilterSource,
  isTenantContextRequestUrl,
} from "../globalFiltersInterceptor";

describe("getExcludedParamForFilterSource", () => {
  it.each([
    ["/custom-lists/?limit=10&offset=0", "custom_list"],
    ["/material/group/?limit=10", "product_category"],
    ["/material/gcn/?limit=10", "gcn"],
    ["/material-formulary/unique/?limit=10", "formulary"],
    ["/material/xplant-mat-stat/?limit=10", "xplant_mat_stat"],
    ["/material/?search=abc", "material"],
    ["/vendor/?search=abc", "supplier_nbr"],
  ])("excludes a filter from its own picker request: %s", (url, expected) => {
    expect(getExcludedParamForFilterSource(url)).toBe(expected);
  });

  it("does not exclude anything for page data requests", () => {
    expect(getExcludedParamForFilterSource("/issues/?status=OPEN")).toBeNull();
  });
});

describe("isTenantContextRequestUrl", () => {
  it("matches the tenants context endpoint with or without trailing slash/query", () => {
    expect(isTenantContextRequestUrl("/tenants/context/")).toBe(true);
    expect(isTenantContextRequestUrl("/api/tenants/context")).toBe(true);
    expect(isTenantContextRequestUrl("/tenants/context/?x=1")).toBe(true);
    expect(isTenantContextRequestUrl("/tenants/list/")).toBe(false);
    expect(isTenantContextRequestUrl("/filter-ranges/")).toBe(false);
  });
});

describe("getCurrentMode route gating", () => {
  const setPath = (path: string) => window.history.pushState({}, "", path);

  it("applies global filters on the React feed", () => {
    setPath("/react");
    expect(getCurrentMode()).toBe("APPLY");
  });

  it("ignores global filters on the issue drill-through (issue-scoped data)", () => {
    setPath("/react/issue/123");
    expect(getCurrentMode()).toBe("IGNORE");
  });

  it("ignores global filters on the material drill-through", () => {
    setPath("/react/product/123");
    expect(getCurrentMode()).toBe("IGNORE");
  });

  it("ignores global filters on the material-centric detail page", () => {
    setPath("/react/material/421");
    expect(getCurrentMode()).toBe("IGNORE");
  });
});

describe("mapGFToBackend", () => {
  it("maps allowed multi-value filters", () => {
    const result = mapGFToBackend({
      gf_supplier: { ids: ["VEN001", "VEN002"], labels: ["Vendor 1", "Vendor 2"] },
      gf_product_category: { id: "Oncology", label: "Oncology" },
      gf_who_essential: { id: "1", label: "Yes" },
    });
    expect(result).toEqual({
      supplier_nbr: "VEN001,VEN002",
      product_category: "Oncology",
      who_essential: "1",
    });
  });

  it("maps legacy single-value supplier format", () => {
    const result = mapGFToBackend({
      gf_supplier: { id: "VEN001", label: "Vendor 1" },
    });
    expect(result).toEqual({ supplier_nbr: "VEN001" });
  });

  it("ignores keys not starting with gf_", () => {
    const result = mapGFToBackend({
      supplier_nbr: { id: "VEN001", label: "Vendor" },
    });
    expect(result).toEqual({});
  });

  it("drops removed Stratium filter keys", () => {
    const result = mapGFToBackend({
      gf_supplier_parent: { ids: ["PARENT001"], labels: ["Parent Corp"] },
      gf_buyer: { id: "Buyer A", label: "Buyer A" },
      gf_injectable: { id: "1", label: "Yes" },
      gf_supplier: { ids: ["VEN001"], labels: ["Vendor 1"] },
    });
    expect(result).toEqual({ supplier_nbr: "VEN001" });
  });
});
