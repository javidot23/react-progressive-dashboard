import { toast } from "@/lib/toast";
import { useToastStore } from "@/stores/toastStore";

describe("toast lib", () => {
  beforeEach(() => {
    useToastStore.setState({ toasts: [] });
  });

  const variants = ["success", "error", "info", "warning"] as const;

  it.each(variants)("toast.%s sets variant on the pushed item", v => {
    toast[v]({ title: "Hello" });
    const items = useToastStore.getState().toasts;
    expect(items).toHaveLength(1);
    expect(items[0]?.variant).toBe(v);
    expect(items[0]?.title).toBe("Hello");
    expect(items[0]?.duration).toBe(4500);
  });

  it("accepts explicit duration including 0", () => {
    toast.success({ title: "Sticky", duration: 0 });
    expect(useToastStore.getState().toasts[0]?.duration).toBe(0);
  });

  it("dismiss(id) removes one toast", () => {
    toast.info({ title: "A" });
    const id = toast.warning({ title: "B" });
    toast.dismiss(id);
    expect(useToastStore.getState().toasts.map(t => t.title)).toEqual(["A"]);
  });

  it("dismiss() without id clears all", () => {
    toast.success({ title: "One" });
    toast.error({ title: "Two" });
    toast.dismiss();
    expect(useToastStore.getState().toasts).toEqual([]);
  });

  it("toast.promise shows loading, then success", async () => {
    const p = Promise.resolve(42);
    await toast.promise(p, {
      loading: "Loading…",
      success: d => `Done: ${d}`,
      error: "Failed",
    });
    const final = useToastStore.getState().toasts;
    expect(final).toHaveLength(1);
    expect(final[0]?.variant).toBe("success");
    expect(final[0]?.title).toBe("Done: 42");
  });

  it("toast.promise shows loading, then error on rejection", async () => {
    const p = Promise.reject(new Error("boom"));
    await expect(
      toast.promise(p, {
        loading: "Wait",
        success: "OK",
        error: e => (e instanceof Error ? e.message : "err"),
      })
    ).rejects.toThrow("boom");
    const final = useToastStore.getState().toasts;
    expect(final).toHaveLength(1);
    expect(final[0]?.variant).toBe("error");
    expect(final[0]?.title).toBe("boom");
  });
});
