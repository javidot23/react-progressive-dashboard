import { downloadCsv, toCsv, type CsvColumn } from "@/lib/csv";

type SampleRow = {
  name: string;
  amount: number;
  note?: string | null;
};

const COLUMNS: CsvColumn<SampleRow>[] = [
  { key: "name", header: "Name" },
  { key: "amount", header: "Amount" },
  { key: "note", header: "Note" },
];

describe("toCsv", () => {
  it("emits headers in column order", () => {
    const csv = toCsv([{ name: "Retail", amount: 2000, note: "ok" }], COLUMNS);
    expect(csv.split("\n")[0]).toBe("Name,Amount,Note");
  });

  it("emits headers only when rows are empty", () => {
    expect(toCsv([], COLUMNS)).toBe("Name,Amount,Note");
  });

  it("serializes row values", () => {
    const csv = toCsv(
      [
        { name: "Retail", amount: 2000, note: "ok" },
        { name: "Hospital", amount: 3000, note: null },
      ],
      COLUMNS
    );
    expect(csv).toBe(["Name,Amount,Note", "Retail,2000,ok", "Hospital,3000,"].join("\n"));
  });

  it("escapes quotes, commas, and newlines", () => {
    const csv = toCsv(
      [
        { name: 'Acme "Co"', amount: 1, note: "a,b" },
        { name: "Line", amount: 2, note: "first\nsecond" },
      ],
      COLUMNS
    );
    expect(csv).toBe(["Name,Amount,Note", '"Acme ""Co""",1,"a,b"', 'Line,2,"first\nsecond"'].join("\n"));
  });

  it("uses value mapper over key", () => {
    const columns: CsvColumn<SampleRow>[] = [
      { key: "name", header: "Name" },
      {
        key: "amount",
        header: "Doubled",
        value: row => row.amount * 2,
      },
    ];
    expect(toCsv([{ name: "A", amount: 5 }], columns)).toBe("Name,Doubled\nA,10");
  });

  it("treats null and undefined cells as empty fields", () => {
    const columns: CsvColumn<SampleRow>[] = [
      { key: "name", header: "Name" },
      { key: "note", header: "Note" },
      { header: "Missing", value: () => undefined },
    ];
    expect(toCsv([{ name: "A", amount: 1, note: null }], columns)).toBe("Name,Note,Missing\nA,,");
  });
});

describe("downloadCsv", () => {
  const originalCreateObjectURL = window.URL.createObjectURL;
  const originalRevokeObjectURL = window.URL.revokeObjectURL;

  beforeEach(() => {
    window.URL.createObjectURL = jest.fn(() => "blob:mock-url");
    window.URL.revokeObjectURL = jest.fn();
  });

  afterEach(() => {
    window.URL.createObjectURL = originalCreateObjectURL;
    window.URL.revokeObjectURL = originalRevokeObjectURL;
    jest.restoreAllMocks();
  });

  it("creates a downloadable link and revokes the object URL", () => {
    const click = jest.fn();
    const anchor = {
      href: "",
      download: "",
      click,
    };

    jest.spyOn(document, "createElement").mockReturnValue(anchor as unknown as HTMLAnchorElement);
    jest.spyOn(document.body, "appendChild").mockImplementation(node => node);
    jest.spyOn(document.body, "removeChild").mockImplementation(node => node);

    downloadCsv("sample.csv", "Name,Amount\nRetail,2000");

    expect(window.URL.createObjectURL).toHaveBeenCalledWith(expect.any(Blob));
    const blob = (window.URL.createObjectURL as jest.Mock).mock.calls[0][0] as Blob;
    expect(blob.type).toBe("text/csv;charset=utf-8");
    expect(anchor.href).toBe("blob:mock-url");
    expect(anchor.download).toBe("sample.csv");
    expect(click).toHaveBeenCalled();
    expect(document.body.appendChild).toHaveBeenCalledWith(anchor);
    expect(document.body.removeChild).toHaveBeenCalledWith(anchor);
    expect(window.URL.revokeObjectURL).toHaveBeenCalledWith("blob:mock-url");
  });
});
