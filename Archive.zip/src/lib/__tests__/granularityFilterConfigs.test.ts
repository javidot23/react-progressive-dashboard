import {
  granularityIssueFiltersConfig,
  granularityIssueAppliedFiltersConfig,
  impactedMaterialsFiltersConfig,
  impactedMaterialsAppliedFiltersConfig,
} from "@/lib/filterConfigs";

describe("granularityIssueFiltersConfig (feed — /issue/all/)", () => {
  it("offers the Materials Affected sort (impacted_material_count)", () => {
    const opt = granularityIssueFiltersConfig.sortOptions.find(o => o.value === "impacted_material_count");
    expect(opt).toEqual({ label: "Materials Affected", value: "impacted_material_count" });
  });

  it("offers grain-aware metric sorts", () => {
    const values = granularityIssueFiltersConfig.sortOptions.map(o => o.value);
    expect(values).toEqual(
      expect.arrayContaining([
        "effective_risk_adjusted_value",
        "effective_dollars_at_risk",
        "effective_risk_rating",
        "impacted_material_count",
        "date_identified",
        "material__name",
      ])
    );
  });

  it("never shows the word 'effective' in UI labels", () => {
    for (const o of granularityIssueFiltersConfig.sortOptions) {
      expect(o.label.toLowerCase()).not.toContain("effective");
    }
    for (const label of Object.values(granularityIssueAppliedFiltersConfig.fieldLabels)) {
      expect(String(label).toLowerCase()).not.toContain("effective");
    }
  });

  it("exposes grain-aware ranges incl. Materials Affected", () => {
    const rangeKeys = (granularityIssueFiltersConfig.ranges ?? []).map(r => r.minKey);
    expect(rangeKeys).toEqual(
      expect.arrayContaining([
        "effective_risk_adjusted_value_min",
        "effective_dollars_at_risk_min",
        "impacted_material_count_min",
      ])
    );
  });

  it("defaults ordering to risk-adjusted value, high→low", () => {
    expect(granularityIssueAppliedFiltersConfig.defaultFilters.ordering).toBe("-effective_risk_adjusted_value");
  });

  it("exposes risk score preset ranges for applied filter chips", () => {
    expect(granularityIssueAppliedFiltersConfig.riskRatingRanges).toEqual(
      expect.objectContaining({
        Likely: { min: 0.61, max: 0.8 },
      })
    );
  });

  it("offers a Group dropdown with the known group values", () => {
    const groupDropdown = granularityIssueFiltersConfig.dropdowns?.find(d => d.key === "group");
    expect(groupDropdown?.label).toBe("Group");
    expect(groupDropdown?.options).toEqual(["RO", "ROSS/Account Services", "SGS", "ROSS"]);
  });

  it("offers an Action Status dropdown with reviewed / not reviewed options", () => {
    const actionStatusDropdown = granularityIssueFiltersConfig.dropdowns?.find(d => d.key === "has_no_actions");
    expect(actionStatusDropdown?.label).toBe("Action Status");
    expect(actionStatusDropdown?.options).toEqual(["All", "Not Reviewed", "Reviewed"]);
    expect(granularityIssueAppliedFiltersConfig.defaultFilters.has_no_actions).toBeUndefined();
    expect(granularityIssueAppliedFiltersConfig.filterLabels.has_no_actions).toBe("Action Status");
  });
});

describe("impactedMaterialsFiltersConfig (/issue/<id>/materials/)", () => {
  it("offers risk-adjusted value / risk / $ / name / mat_nbr sorts", () => {
    const values = impactedMaterialsFiltersConfig.sortOptions.map(o => o.value);
    expect(values).toEqual(
      expect.arrayContaining(["risk_adjusted_value", "risk_rating", "dollars_at_risk", "name", "mat_nbr"])
    );
  });

  it("exposes the risk/$/RAV range filters", () => {
    const rangeKeys = (impactedMaterialsFiltersConfig.ranges ?? []).map(r => r.minKey);
    expect(rangeKeys).toEqual(expect.arrayContaining(["risk_adjusted_value_min", "dollars_at_risk_min"]));
  });

  it("defaults ordering to risk-adjusted value, high→low", () => {
    expect(impactedMaterialsAppliedFiltersConfig.defaultFilters.ordering).toBe("-risk_adjusted_value");
  });
});
