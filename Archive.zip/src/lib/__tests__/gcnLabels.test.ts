import {
  getAllGcnLabel,
  getGcnDescriptionLabel,
  getGcnLabel,
  getGcnNumberLabel,
  getGcnPlantLabel,
  getGcnPluralLabel,
  getGcnPluralSuppliedLabel,
  getGcnSearchHint,
  getMaterialInGcnLabel,
  getMaterialSearchPlaceholder,
} from "@/lib/gcnLabels";

describe("gcnLabels", () => {
  it("returns Product Family terminology", () => {
    expect(getGcnLabel()).toBe("Product Family");
    expect(getGcnPluralLabel()).toBe("Product Families");
    expect(getAllGcnLabel()).toBe("All Product Families");
    expect(getGcnNumberLabel()).toBe("Product Family Number");
    expect(getGcnDescriptionLabel()).toBe("Product Family Description");
    expect(getMaterialInGcnLabel()).toBe("Material in Product Family");
    expect(getGcnPlantLabel()).toBe("Product Family·Plant");
    expect(getGcnPluralSuppliedLabel()).toBe("Product Families Supplied");
    expect(getGcnSearchHint()).toBe("product family");
    expect(getMaterialSearchPlaceholder()).toBe("Search by name, nbr, ndc or product family");
  });
});
