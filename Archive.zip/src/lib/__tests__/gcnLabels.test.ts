import {
  getAllGcnLabel,
  getGcnDescriptionLabel,
  getGcnLabel,
  getGcnNumberLabel,
  getGcnPlantLabel,
  getGcnPluralLabel,
  getGcnPluralSuppliedLabel,
  getGcnSearchHint,
  getMaterialInGcnLabel,
  getMaterialSearchPlaceholder,
} from "@/lib/gcnLabels";

jest.mock("@/tenant", () => ({
  isVariantFamily: jest.fn(),
}));

const mockIsVariantFamily = jest.requireMock("@/tenant").isVariantFamily as jest.Mock;

describe("gcnLabels", () => {
  afterEach(() => {
    mockIsVariantFamily.mockReset();
  });

  describe("Stratium labels", () => {
    beforeEach(() => {
      mockIsVariantFamily.mockReturnValue(false);
    });

    it("returns GCN terminology for Stratium", () => {
      expect(getGcnLabel()).toBe("GCN");
      expect(getGcnPluralLabel()).toBe("GCNs");
      expect(getAllGcnLabel()).toBe("All GCN");
      expect(getGcnNumberLabel()).toBe("GCN Number");
      expect(getGcnDescriptionLabel()).toBe("GCN Description");
      expect(getMaterialInGcnLabel()).toBe("Material in GCN");
      expect(getGcnPlantLabel()).toBe("GCN·Plant");
      expect(getGcnPluralSuppliedLabel()).toBe("GCNs Supplied");
      expect(getGcnSearchHint()).toBe("gcn");
      expect(getMaterialSearchPlaceholder()).toBe("Search by name, nbr, ndc or gcn");
    });
  });

  describe("Variant portal labels", () => {
    beforeEach(() => {
      mockIsVariantFamily.mockReturnValue(true);
    });

    it("returns Product Family terminology for variant portal", () => {
      expect(getGcnLabel()).toBe("Product Family");
      expect(getGcnPluralLabel()).toBe("Product Families");
      expect(getAllGcnLabel()).toBe("All Product Families");
      expect(getGcnNumberLabel()).toBe("Product Family Number");
      expect(getGcnDescriptionLabel()).toBe("Product Family Description");
      expect(getMaterialInGcnLabel()).toBe("Material in Product Family");
      expect(getGcnPlantLabel()).toBe("Product Family·Plant");
      expect(getGcnPluralSuppliedLabel()).toBe("Product Families Supplied");
      expect(getGcnSearchHint()).toBe("product family");
      expect(getMaterialSearchPlaceholder()).toBe("Search by name, nbr, ndc or product family");
    });
  });
});
