export type CsvColumn<T> = {
  key?: keyof T;
  header: string;
  value?: (row: T) => string | number | null | undefined;
};

function escapeCsvCell(value: string | number | null | undefined): string {
  if (value == null) return "";
  const s = String(value);
  if (/[",\n\r]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function resolveCell<T>(row: T, column: CsvColumn<T>): string | number | null | undefined {
  if (column.value) {
    return column.value(row);
  }
  if (column.key !== undefined) {
    return row[column.key] as string | number | null | undefined;
  }
  return undefined;
}

/**
 * Serialize rows to CSV with an explicit column schema.
 * Always emits a header row, including when `rows` is empty.
 */
export function toCsv<T>(rows: T[], columns: CsvColumn<T>[]): string {
  const header = columns.map(c => escapeCsvCell(c.header)).join(",");
  if (rows.length === 0) {
    return header;
  }
  const body = rows.map(row =>
    columns.map(column => escapeCsvCell(resolveCell(row, column))).join(",")
  );
  return [header, ...body].join("\n");
}

/**
 * Trigger a browser download of a CSV string.
 */
export function downloadCsv(filename: string, csvString: string): void {
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8" });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
}
