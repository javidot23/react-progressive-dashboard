/**
 * BFF auth navigation URLs — must match axios `baseURL` (VITE_API_BASE_URL).
 * Login uses top-level navigation only; never fetch/axios.
 */

export interface LogoutResponse {
  success?: boolean;
  data?: {
    end_session_url?: string | null;
  };
  end_session_url?: string | null;
}

export function getEndSessionUrl(body: LogoutResponse | null | undefined): string | null {
  const nested = body?.data?.end_session_url;
  if (typeof nested === "string" && nested.length > 0) {
    return nested;
  }
  const flat = body?.end_session_url;
  if (typeof flat === "string" && flat.length > 0) {
    return flat;
  }
  return null;
}

export function getApiBaseUrlFromEnv(): string {
  return (import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000/api").trim();
}

/** Resolved API base (absolute URL, no trailing slash). */
export function getAuthBaseUrl(): string {
  const raw = getApiBaseUrlFromEnv().replace(/\/$/, "");
  if (/^https?:\/\//i.test(raw)) {
    return raw;
  }
  const path = raw.startsWith("/") ? raw : `/${raw}`;
  return `${window.location.origin}${path}`.replace(/\/$/, "");
}

export function getLoginUrl(): string {
  return `${getAuthBaseUrl()}/login/start/`;
}

export function redirectToLogin(): void {
  window.location.assign(getLoginUrl());
}

/** SPA routes where an unauthenticated /auth/me/ should not auto-redirect to the IdP. */
const PUBLIC_AUTH_PATHS = new Set(["/login", "/disclaimer", "/glossary", "/info"]);

export function isPublicAuthPath(pathname: string = window.location.pathname): boolean {
  return PUBLIC_AUTH_PATHS.has(pathname);
}
