import { AuthProvider } from "@/contexts/AuthContext";
import { useSyncGlobalFilters } from "@/hooks/useSyncGlobalFilters";
import ErrorBoundary from "@/components/ErrorBoundary";
import { ToastViewport } from "@/components/molecules/ToastViewport";
import { AppRoutes } from "@/routes/AppRoutes";
import { useMedalliaPageView } from "./integrations/medallia/useMedalliaPageView";

function App() {
  useSyncGlobalFilters();
  useMedalliaPageView();

  return (
    <ErrorBoundary>
      <AuthProvider>
        <ToastViewport />
        <AppRoutes />
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;
