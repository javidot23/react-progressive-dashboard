import "@testing-library/jest-dom";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter } from "react-router-dom";
import React, { useEffect, useState } from "react";

// Mock the API client
const mockApiClient = {
  get: jest.fn(),
  post: jest.fn(),
  defaults: {
    baseURL: process.env.VITE_API_BASE_URL || "http://localhost:8000",
  },
};

jest.mock("@/lib/apiClient", () => ({
  apiClient: mockApiClient,
}));

// Mock user data
const mockUserData = {
  id: "user-123",
  displayName: "John Doe",
  mail: "john.doe@example.com",
  givenName: "John",
  surname: "Doe",
  userPrincipalName: "john.doe@example.com",
  jobTitle: "Software Engineer",
  mobilePhone: "+1234567890",
};

const mockGraphResponse = {
  id: "graph-user-123",
  displayName: "Graph User Name",
  mail: "graph.user@example.com",
  givenName: "Graph",
  surname: "User",
  userPrincipalName: "graph.user@example.com",
  jobTitle: "Senior Engineer",
  mobilePhone: "+1234567890",
};

interface UserData {
  id: string;
  displayName: string;
  mail: string;
  givenName: string;
  surname: string;
  userPrincipalName: string;
  jobTitle?: string;
  mobilePhone?: string;
}

// Mock UserProfile component
const MockUserProfile = () => {
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchUserProfile = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await mockApiClient.get("/auth/me/");
      setUserData(response.data);
    } catch (err: any) {
      setError(err.response?.data?.error || "Failed to fetch user profile");
    } finally {
      setLoading(false);
    }
  };

  const refreshProfile = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await mockApiClient.post("/auth/me/refresh/");
      setUserData(response.data);
    } catch (err: any) {
      setError(err.response?.data?.error || "Failed to refresh profile");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserProfile();
  }, []);

  return (
    <div data-testid="user-profile">
      <h1>User Profile</h1>

      {loading && <div data-testid="loading">Loading...</div>}

      {error && (
        <div data-testid="error" role="alert">
          Error: {error}
        </div>
      )}

      {userData && (
        <div data-testid="user-data">
          <div data-testid="user-id">{userData.id}</div>
          <div data-testid="user-display-name">{userData.displayName}</div>
          <div data-testid="user-email">{userData.mail}</div>
          <div data-testid="user-first-name">{userData.givenName}</div>
          <div data-testid="user-last-name">{userData.surname}</div>
          <div data-testid="user-principal-name">{userData.userPrincipalName}</div>
          {userData.jobTitle && <div data-testid="user-job-title">{userData.jobTitle}</div>}
          {userData.mobilePhone && <div data-testid="user-phone">{userData.mobilePhone}</div>}
        </div>
      )}

      <button data-testid="refresh-button" onClick={refreshProfile} disabled={loading}>
        Refresh Profile
      </button>
    </div>
  );
};

// Test wrapper with providers
const TestWrapper = ({ children }: { children: React.ReactNode }) => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: 0,
      },
    },
  });

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>{children}</BrowserRouter>
    </QueryClientProvider>
  );
};

describe("UserProfile", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("Rendering", () => {
    it("renders all main components", () => {
      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: mockUserData,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      expect(screen.getByTestId("user-profile")).toBeInTheDocument();
      expect(screen.getByText("User Profile")).toBeInTheDocument();
      expect(screen.getByTestId("refresh-button")).toBeInTheDocument();
    });

    it("displays correct user profile data", async () => {
      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: mockUserData,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      expect(screen.getByTestId("user-id")).toHaveTextContent("user-123");
      expect(screen.getByTestId("user-display-name")).toHaveTextContent("John Doe");
      expect(screen.getByTestId("user-email")).toHaveTextContent("john.doe@example.com");
      expect(screen.getByTestId("user-first-name")).toHaveTextContent("John");
      expect(screen.getByTestId("user-last-name")).toHaveTextContent("Doe");
    });

    it("displays Graph API data when available", async () => {
      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: mockGraphResponse,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      expect(screen.getByTestId("user-display-name")).toHaveTextContent("Graph User Name");
      expect(screen.getByTestId("user-email")).toHaveTextContent("graph.user@example.com");
      expect(screen.getByTestId("user-job-title")).toHaveTextContent("Senior Engineer");
    });
  });

  describe("Data Loading", () => {
    it("shows loading state", () => {
      mockApiClient.get.mockImplementation(() => new Promise(() => {})); // Never resolves

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      expect(screen.getByTestId("loading")).toBeInTheDocument();
    });

    it("hides loading state when data is loaded", async () => {
      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: mockUserData,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      expect(screen.queryByTestId("loading")).not.toBeInTheDocument();
    });

    it("disables refresh button when loading", async () => {
      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: mockUserData,
      });

      mockApiClient.post.mockImplementation(() => new Promise(() => {})); // Never resolves

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      const refreshButton = screen.getByTestId("refresh-button");
      await userEvent.click(refreshButton);

      expect(refreshButton).toBeDisabled();
    });
  });

  describe("Error Handling", () => {
    it("displays error message when API fails", async () => {
      const errorResponse = {
        response: {
          status: 401,
          data: {
            success: false,
            error: "Authentication required",
          },
        },
      };

      mockApiClient.get.mockRejectedValue(errorResponse);

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("error")).toBeInTheDocument();
      });

      expect(screen.getByText("Error: Authentication required")).toBeInTheDocument();
    });

    it("displays error message for server errors", async () => {
      const errorResponse = {
        response: {
          status: 500,
          data: {
            success: false,
            error: "Database connection failed",
          },
        },
      };

      mockApiClient.get.mockRejectedValue(errorResponse);

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("error")).toBeInTheDocument();
      });

      expect(screen.getByText("Error: Database connection failed")).toBeInTheDocument();
    });

    it("displays error message for network timeout", async () => {
      const errorResponse = {
        response: {
          status: 500,
          data: {
            success: false,
            error: "Request timeout",
          },
        },
      };

      mockApiClient.get.mockRejectedValue(errorResponse);

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("error")).toBeInTheDocument();
      });

      expect(screen.getByText("Error: Request timeout")).toBeInTheDocument();
    });
  });

  describe("Profile Refresh", () => {
    it("refreshes profile successfully", async () => {
      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: mockUserData,
      });

      mockApiClient.post.mockResolvedValue({
        status: 200,
        data: mockGraphResponse,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      // Initial data
      expect(screen.getByTestId("user-display-name")).toHaveTextContent("John Doe");

      // Click refresh button
      const refreshButton = screen.getByTestId("refresh-button");
      await userEvent.click(refreshButton);

      // Wait for refresh to complete
      await waitFor(() => {
        expect(screen.getByTestId("user-display-name")).toHaveTextContent("Graph User Name");
      });

      expect(mockApiClient.post).toHaveBeenCalledWith("/auth/me/refresh/");
    });

    it("handles refresh errors gracefully", async () => {
      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: mockUserData,
      });

      const errorResponse = {
        response: {
          status: 500,
          data: {
            success: false,
            error: "Failed to retrieve data from Microsoft Graph",
          },
        },
      };

      mockApiClient.post.mockRejectedValue(errorResponse);

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      // Click refresh button
      const refreshButton = screen.getByTestId("refresh-button");
      await userEvent.click(refreshButton);

      await waitFor(() => {
        expect(screen.getByTestId("error")).toBeInTheDocument();
      });

      expect(screen.getByText("Error: Failed to retrieve data from Microsoft Graph")).toBeInTheDocument();
    });
  });

  describe("Edge Cases", () => {
    it("handles empty user names correctly", async () => {
      const emptyNameData = {
        id: "user-123",
        displayName: "", // Empty display name
        mail: "user@example.com",
        givenName: "",
        surname: "",
        userPrincipalName: "user@example.com",
      };

      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: emptyNameData,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      expect(screen.getByTestId("user-display-name")).toHaveTextContent("");
      expect(screen.getByTestId("user-first-name")).toHaveTextContent("");
      expect(screen.getByTestId("user-last-name")).toHaveTextContent("");
    });

    it("handles special characters in names correctly", async () => {
      const specialCharData = {
        id: "user-123",
        displayName: "José María O'Connor-Smith",
        mail: "jose@example.com",
        givenName: "José María",
        surname: "O'Connor-Smith",
        userPrincipalName: "jose@example.com",
      };

      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: specialCharData,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      expect(screen.getByTestId("user-display-name")).toHaveTextContent("José María O'Connor-Smith");
      expect(screen.getByTestId("user-first-name")).toHaveTextContent("José María");
      expect(screen.getByTestId("user-last-name")).toHaveTextContent("O'Connor-Smith");
    });

    it("handles large user data efficiently", async () => {
      const largeUserData = {
        id: "large-user",
        displayName: "A".repeat(100) + " " + "B".repeat(100),
        mail: "large@test.com",
        givenName: "A".repeat(100),
        surname: "B".repeat(100),
        userPrincipalName: "large@test.com",
        jobTitle: "C".repeat(200),
      };

      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: largeUserData,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      expect(screen.getByTestId("user-display-name")).toHaveTextContent("A".repeat(100) + " " + "B".repeat(100));
      expect(screen.getByTestId("user-job-title")).toHaveTextContent("C".repeat(200));
    });

    it("handles malformed API response gracefully", async () => {
      const malformedData = {
        id: "user-123",
        displayName: "John Doe",
        // Missing required fields
      };

      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: malformedData,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      expect(screen.getByTestId("user-id")).toHaveTextContent("user-123");
      expect(screen.getByTestId("user-display-name")).toHaveTextContent("John Doe");
    });
  });

  describe("Accessibility", () => {
    it("has proper ARIA attributes for error messages", async () => {
      const errorResponse = {
        response: {
          status: 401,
          data: {
            success: false,
            error: "Authentication required",
          },
        },
      };

      mockApiClient.get.mockRejectedValue(errorResponse);

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("error")).toBeInTheDocument();
      });

      const errorElement = screen.getByTestId("error");
      expect(errorElement).toHaveAttribute("role", "alert");
    });

    it("supports keyboard navigation for buttons", async () => {
      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: mockUserData,
      });

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      const refreshButton = screen.getByTestId("refresh-button");

      // Focus the button
      refreshButton.focus();
      expect(refreshButton).toHaveFocus();

      // Press Enter key
      fireEvent.keyDown(refreshButton, { key: "Enter", code: "Enter" });

      // Button should be clickable
      expect(refreshButton).not.toBeDisabled();
    });
  });

  describe("Performance", () => {
    it("renders within acceptable time", async () => {
      mockApiClient.get.mockResolvedValue({
        status: 200,
        data: mockUserData,
      });

      const startTime = Date.now();

      render(
        <TestWrapper>
          <MockUserProfile />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByTestId("user-data")).toBeInTheDocument();
      });

      const endTime = Date.now();
      const renderTime = endTime - startTime;

      expect(renderTime).toBeLessThan(1000); // Less than 1 second
    });
  });
});
