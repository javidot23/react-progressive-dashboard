import { mockStatCardsData, overviewApiHandlers } from "./apiMocks";

describe("API Mocks", () => {
  it("should export mock data and handlers", () => {
    expect(Array.isArray(mockStatCardsData)).toBe(true);
    expect(Array.isArray(overviewApiHandlers)).toBe(true);
  });
});
