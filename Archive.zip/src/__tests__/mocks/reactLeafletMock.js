// Mock for react-leaflet components
// This mock prevents Jest from trying to parse the ES modules in react-leaflet
const React = require('react');

const MapContainer = ({ children }) => {
  return React.createElement('div', { 'data-testid': 'map-container' }, children);
};

const TileLayer = () => {
  return React.createElement('div', { 'data-testid': 'tile-layer' });
};

const Marker = () => {
  return React.createElement('div', { 'data-testid': 'marker' });
};

const Circle = () => {
  return React.createElement('div', { 'data-testid': 'circle' });
};

const GeoJSON = () => {
  return React.createElement('div', { 'data-testid': 'geo-json' });
};

const useMap = () => ({
  setView: jest.fn(),
  fitBounds: jest.fn(),
  eachLayer: jest.fn(),
  removeLayer: jest.fn(),
  addLayer: jest.fn(),
  getSize: jest.fn(() => ({ x: 800, y: 600 })),
});

const useMapEvent = jest.fn();
const useMapEvents = jest.fn();

module.exports = {
  __esModule: true,
  MapContainer,
  TileLayer,
  Marker,
  Circle,
  GeoJSON,
  useMap,
  useMapEvent,
  useMapEvents,
};
