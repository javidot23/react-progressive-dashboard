export const testBaseURL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";
