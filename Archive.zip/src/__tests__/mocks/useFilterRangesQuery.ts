/**
 * Shared jest mock factory for ``useFilterRangesQuery``. Pass ``{ key: max }``
 * to seed values; default returns an empty success state.
 */
export function createUseFilterRangesQueryMock(maxes: Record<string, number> = {}) {
  const ranges = Object.fromEntries(
    Object.entries(maxes).map(([key, max]) => [key, { min: 0, max }]),
  );
  return {
    useFilterRangesQuery: jest.fn(() => ({
      ranges,
      maxes,
      getMax: (key: string, fallback: number = 0) => maxes[key] ?? fallback,
      isLoading: false,
      isFetching: false,
      isSuccess: true,
      isError: false,
      error: null,
      refetch: jest.fn(),
    })),
  };
}
