import { http, HttpResponse } from "msw";
import { testBaseURL } from "./testBaseURL";

export const mockStatCardsData = [
  {
    id: 1,
    title: "Open Issues",
    value: "92.5%",
    change: "+2.5%",
    changeType: "increase" as const,
    icon: "target-correct",
  },
  {
    id: 2,
    title: "Service Level",
    value: "95.2%",
    change: "-1.2%",
    changeType: "decrease" as const,
    icon: "check-shield",
  },
  {
    id: 3,
    title: "Cost Savings",
    value: "$2.4M",
    change: "+15%",
    changeType: "increase" as const,
    icon: "discount-dollar-dash",
  },
];

export const mockVendorsData = [
  {
    id: 1,
    name: "Acme Manufacturing",
    vendorNbr: "VEN001",
    riskRating: 0.92,
    drivingRisk: "Supply chain disruption in Asia",
  },
  {
    id: 2,
    name: "Global Supplies Inc",
    vendorNbr: "VEN002",
    riskRating: 0.85,
    drivingRisk: "Financial instability",
  },
];

export const mockCriticalProductsData = [
  {
    id: 1,
    name: "Critical Component A",
    matNbr: "MAT001",
    riskRating: 0.88,
    drivingRisk: "Single source supplier",
  },
  {
    id: 2,
    name: "Essential Material B",
    matNbr: "MAT002",
    riskRating: 0.75,
    drivingRisk: "High demand volatility",
  },
];

export const mockServiceLevelData = [
  {
    month: "Jan 2024",
    serviceLevel: 95,
    goal: 98,
    highImpact: 1200,
    mediumImpact: 800,
  },
  {
    month: "Feb 2024",
    serviceLevel: 97,
    goal: 98,
    highImpact: 1400,
    mediumImpact: 700,
  },
];

export const mockOTIFData = {
  thisWeekOtif: 0.925,
  lastWeekOtif: 0.9,
  chartData: [
    { week: "Week 1", onTime: 85, inFull: 95 },
    { week: "Week 2", onTime: 90, inFull: 92 },
    { week: "Week 3", onTime: 88, inFull: 94 },
    { week: "Week 4", onTime: 92, inFull: 89 },
  ],
};

export const mockTwoWeekSummary = {
  totalOrders: 1250,
  onTimeDeliveries: 1156,
  lateDeliveries: 94,
  performanceScore: 92.5,
};

export const mockWeeklyRiskAnalysis = {
  highRiskItems: 15,
  mediumRiskItems: 42,
  lowRiskItems: 183,
  totalItems: 240,
  riskTrend: "decreasing",
};

export const overviewApiHandlers = [
  http.get(`${testBaseURL}/dashboard/stats`, () => {
    return HttpResponse.json({
      data: mockStatCardsData,
    });
  }),

  http.get(`${testBaseURL}/vendors/top-risky`, () => {
    return HttpResponse.json({
      data: mockVendorsData,
    });
  }),

  http.get(`${testBaseURL}/products/critical`, () => {
    return HttpResponse.json({
      data: mockCriticalProductsData,
    });
  }),

  http.get(`${testBaseURL}/service-level/data`, () => {
    return HttpResponse.json({
      data: mockServiceLevelData,
    });
  }),

  http.get(`${testBaseURL}/otif/performance`, () => {
    return HttpResponse.json({
      data: mockOTIFData,
    });
  }),

  http.get(`${testBaseURL}/summary/two-week`, () => {
    return HttpResponse.json({
      data: mockTwoWeekSummary,
    });
  }),

  http.get(`${testBaseURL}/risk/weekly-analysis`, () => {
    return HttpResponse.json({
      data: mockWeeklyRiskAnalysis,
    });
  }),

  http.get(`${testBaseURL}/geography/risks`, () => {
    return HttpResponse.json({
      data: [],
    });
  }),

  http.get(`${testBaseURL}/dashboard/stats/error`, () => {
    return HttpResponse.json({ error: "Failed to fetch dashboard stats" }, { status: 500 });
  }),

  http.get(`${testBaseURL}/vendors/top-risky/error`, () => {
    return HttpResponse.json({ error: "Failed to fetch vendors data" }, { status: 500 });
  }),

  http.get(`${testBaseURL}/network-error`, () => {
    return HttpResponse.error();
  }),
];
