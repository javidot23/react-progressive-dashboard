// src/__tests__/mocks/server.ts
import {setupServer} from "msw/node";
import {handlers} from "./handlers";

export const server = setupServer(...handlers);

// Additional test utilities for integration tests
export const setupTestServer = () => {
  beforeAll(() => server.listen({ onUnhandledRequest: 'warn' }));
  afterEach(() => server.resetHandlers());
  afterAll(() => server.close());
};
