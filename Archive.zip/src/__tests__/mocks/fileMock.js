// Mock for image and SVG files
// This file mocks image imports to return empty strings

// For string imports (default)
const mockString = "";

// For React component imports
const ReactComponent = function MockImageComponent(props) {
  return null;
};

// Create the mock module
const mockModule = {
  __esModule: true,
  default: mockString,
  ReactComponent: ReactComponent,
  // For named exports
  url: mockString,
  toString: () => mockString,
};

// Export for CommonJS
module.exports = mockModule;

// Export for ES modules
if (typeof module.exports === "object") {
  module.exports.default = mockModule.default;
  module.exports.ReactComponent = mockModule.ReactComponent;
  module.exports.__esModule = true;
  module.exports.url = mockModule.url;
  module.exports.toString = mockModule.toString;
}
