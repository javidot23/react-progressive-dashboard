import { http, HttpResponse } from "msw";
import {
  mockStatCardsData,
  mockVendorsData,
  mockCriticalProductsData,
  mockServiceLevelData,
  mockOTIFData,
  //  if you want to prepare real mock data for the new handlers, add them here
  // mockDrivingRiskData,
  // mockServiceLevelPlantsData,
} from "./apiMocks";

export const handlers = [
  // Active tenant context — cookie session BFF
  http.get(/.*\/tenants\/context\/($|\?)/, () => {
    return HttpResponse.json({
      success: true,
      data: {
        tenant_uuid: "11111111-1111-1111-1111-111111111111",
        tenant_code: "stratium",
        tenant_name: "Stratium",
        tenant_type: "customer_vendor",
        entitlement_tier: "premium",
        is_federated: false,
      },
    });
  }),

  // Dashboard Stats API - use regex to match any base URL
  http.get(/.*\/dashboard\/stats$/, () => {
    return HttpResponse.json({ data: mockStatCardsData });
  }),

  // Vendors API - use regex to match any base URL
  http.get(/.*\/vendors\/top-risky$/, () => {
    return HttpResponse.json({ data: mockVendorsData });
  }),

  // Critical Products API - use regex to match any base URL
  http.get(/.*\/products\/critical$/, () => {
    return HttpResponse.json({ data: mockCriticalProductsData });
  }),

  // Service Level API - use regex to match any base URL
  http.get(/.*\/service-level\/data$/, () => {
    return HttpResponse.json({ data: mockServiceLevelData });
  }),

  // OTIF Performance API - use regex to match any base URL
  http.get(/.*\/otif-performance$/, () => {
    return HttpResponse.json({ data: mockOTIFData });
  }),

  //  NEW HANDLER: Driving Risk API
  http.get(/.*\/material\/driving-risk\/$/, () => {
    return HttpResponse.json({
      data: [], // or replace with mockDrivingRiskData if you define it
    });
  }),

  //  NEW HANDLER: Service Level Plants API
  http.get(/.*\/service-level\/plants\/$/, () => {
    return HttpResponse.json({
      data: [], // or replace with mockServiceLevelPlantsData if you define it
    });
  }),

  //  NEW HANDLER: Material Formulary Unique API
  http.get(/.*\/material-formulary\/unique$/, () => {
    return HttpResponse.json({
      success: true,
      data: [
        { id: 1, name: "Aspirin 100mg", mat_nbr: "ASP001" },
        { id: 2, name: "Ibuprofen 200mg", mat_nbr: "IBU002" },
        { id: 3, name: "Acetaminophen 500mg", mat_nbr: "ACE003" },
      ],
    });
  }),

  // Material Formulary Program Descriptions API
  http.get(/.*\/material-formulary\/unique-program-descriptions/, () => {
    return HttpResponse.json({
      success: true,
      data: [{ name: "GOVT" }, { name: "PRXO GENERICS SELECT" }, { name: "Pharmagen Carveout" }],
    });
  }),

  // Issues at native granularity — GET /issue/all/
  http.get(/.*\/issue\/all\/(\?.*)?$/, ({ request }) => {
    const url = new URL(request.url);
    const grain = url.searchParams.get("granularity_type");
    const results = [
      {
        id: 1783,
        issue_nbr: "ISS-749539",
        event_id: "SCE-76928032",
        status: "OPEN",
        date_identified: "2026-06-24",
        start_date: "2026-06-24",
        granularity_type: grain || "gcn",
        fdb_gcn_seq_nbr: "635410",
        ndc: null,
        fei_number: null,
        hicl: null,
        hicl_description: null,
        plant: null,
        material: null,
        impacted_material_count: 3,
        effective_risk_rating: 0.87,
        effective_dollars_at_risk: 99594.34,
        effective_risk_adjusted_value: 86647.07,
        driving_event: {
          id: 1683,
          event_id: "SCE-76928032",
          type: "FDA Inspection Classification",
          type_description: null,
          status: "OPEN",
          start_date: "2026-06-19T16:29:36Z",
          end_date: null,
          latitude: null,
          longitude: null,
          city: null,
          state: null,
          country: null,
          mat_nbr: null,
          metadata: null,
          scrm_mat_grp: null,
        },
        has_actions: false,
        notes_count: 0,
        last_note: null,
        group: null,
        persona: null,
      },
    ];
    return HttpResponse.json({
      success: true,
      data: { count: results.length, next: null, previous: null, results },
    });
  }),

  // Impacted materials for an issue — GET /issue/:id/materials/
  http.get(/.*\/issue\/\d+\/materials\/(\?.*)?$/, () => {
    const results = [
      {
        id: 421,
        mat_nbr: "10001234",
        name: "Example Drug 50mg",
        vendor: "Acme Pharma",
        vendor_nbr: "V-0099",
        risk_rating: 0.87,
        driving_risk: "FDA Inspection",
        dollars_at_risk: 99594.34,
        ndc: "12345-678-90",
        saleable_qty_on_hand: 1200,
        unfilled_qty: 212,
        otif_percentage: 96.5,
        material_group: "Generic",
        who_essential_flg: true,
      },
    ];
    return HttpResponse.json({
      success: true,
      data: { count: results.length, next: null, previous: null, results },
    });
  }),

  // Create action — POST /action/create/ (accepts mat_nbr or mat_nbrs)
  http.post(/.*\/action\/create\/$/, async ({ request }) => {
    const body = (await request.json().catch(() => ({}))) as { mat_nbrs?: string[]; mat_nbr?: string };
    const matNbrs = body.mat_nbrs ?? (body.mat_nbr ? [body.mat_nbr] : []);
    return HttpResponse.json(
      {
        success: true,
        data: { created: matNbrs.map((m: string) => ({ mat_nbr: m })), skipped: [] },
      },
      { status: 201 }
    );
  }),

  http.delete(/.*\/action\/\d+\/$/, async ({ request }) => {
    const body = (await request.json().catch(() => null)) as {
      issue_id?: number;
      part_number?: string;
    } | null;
    if (body?.issue_id != null && body?.part_number) {
      return HttpResponse.json({
        success: true,
        data: { deleted_count: 5 },
      });
    }
    return HttpResponse.json({ success: true });
  }),

  // Issue detail — GET /issue/:id/
  http.get(/.*\/issue\/\d+\/$/, ({ request }) => {
    const match = request.url.match(/\/issue\/(\d+)\//);
    const id = match ? Number(match[1]) : 0;
    return HttpResponse.json({
      success: true,
      data: {
        id,
        issue_nbr: `ISS-${id}`,
        status: "OPEN",
        start_date: "2026-05-19",
        created_at: "2026-05-19T09:00:00Z",
        updated_at: "2026-05-19T09:00:00Z",
        actions: [
          {
            id: 456,
            issue_nbr: `ISS-${id}`,
            user_id: "user-entra-id",
            user: {
              id: "user-entra-id",
              first_name: "Jane",
              last_name: "Doe",
              email: "jane.doe@example.com",
            },
            created_at: "2026-05-19T09:00:00Z",
            updated_at: "2026-05-19T09:00:00Z",
            potential_action: {},
            action: "no_action",
            substituted_material: null,
            material_number: "MAT-001",
            material_name: "Example Material",
            vendor_name: "Example Vendor",
            material_context: {},
            decision_feedback: {},
            user_info: {},
          },
        ],
        potential_actions: [],
        material: {},
        risk_adjusted_value: 123.45,
        notes_count: 0,
        last_note: null,
      },
    });
  }),

  //  NEW HANDLER: Issues API - handles /issue/ endpoints
  http.get(/.*\/issue\/$/, () => {
    return HttpResponse.json({
      success: true,
      data: {
        results: [
          {
            id: 1,
            material: {
              id: 1,
              name: "Test Material 1",
              risk_rating: 0.8,
              primary_risk: "Operational",
            },
            issue_type: "Supply Disruption",
            severity: "High",
            status: "Active",
            created_at: "2024-01-01T00:00:00Z",
            updated_at: "2024-01-01T00:00:00Z",
          },
          {
            id: 2,
            material: {
              id: 2,
              name: "Test Material 2",
              risk_rating: 0.6,
              primary_risk: "Environmental",
            },
            issue_type: "Quality Issue",
            severity: "Medium",
            status: "Resolved",
            created_at: "2024-01-02T00:00:00Z",
            updated_at: "2024-01-02T00:00:00Z",
          },
        ],
        count: 2,
        next: null,
        previous: null,
      },
    });
  }),

  //  NEW HANDLER: Order Transaction KPIs API
  http.get(/.*\/order-transaction\/kpis\/$/, () => {
    return HttpResponse.json({
      success: true,
      data: {
        total_orders: 1000,
        total_units: 5000,
        alt_served_orders: 150,
        alt_served_units: 1250,
        alt_serve_rate: 85.5,
        substituted_orders: 87,
        substituted_units: 435,
        substitution_rate: 8.7,
        perfect_orders: 923,
        perfect_order_rate: 92.3,
      },
    });
  }),

  //  NEW HANDLER: Order Transaction Alt Serve/Substituted Stats API
  http.get(/.*\/order-transaction\/alt-serve-substituted-overall-stats\/$/, () => {
    return HttpResponse.json({
      success: true,
      data: [
        {
          week_start: "2024-01-01",
          total_orders: 250,
          perfect_order_rate: 92.5,
          alt_served_percentage: 6.5,
          substituted_percentage: 1.0,
        },
        {
          week_start: "2024-01-08",
          total_orders: 260,
          perfect_order_rate: 93.0,
          alt_served_percentage: 5.8,
          substituted_percentage: 1.2,
        },
        {
          week_start: "2024-01-15",
          total_orders: 245,
          perfect_order_rate: 91.8,
          alt_served_percentage: 7.2,
          substituted_percentage: 1.0,
        },
        {
          week_start: "2024-01-22",
          total_orders: 255,
          perfect_order_rate: 92.3,
          alt_served_percentage: 6.7,
          substituted_percentage: 1.0,
        },
      ],
    });
  }),

  //  NEW HANDLER: Order Transaction List API
  http.get(/.*\/order-transaction\//, () => {
    return HttpResponse.json({
      success: true,
      data: {
        count: 589,
        next: null,
        previous: null,
        results: [
          {
            id: 1,
            material: { name: "Test Material 1", mat_nbr: "12345" },
            sales_doc_nbr: "12345",
            sales_doc_itm_nbr: "001",
            material_status: "DM",
            supplier: { name: "Test Supplier 1" },
            ar_plant: { name: "Plant A" },
            plant: { name: "Plant B" },
            total_order_qty: 100,
            sub_material: { name: "Substituted Material 1" },
            substituted_material_supplier: { name: "Sub Supplier 1" },
            sub_read_code_name: "Type A",
          },
          {
            id: 2,
            material: { name: "Test Material 2", mat_nbr: "67890" },
            sales_doc_nbr: "67890",
            sales_doc_itm_nbr: "002",
            material_status: "AC",
            supplier: { name: "Test Supplier 2" },
            ar_plant: { name: "Plant C" },
            plant: { name: "Plant D" },
            total_order_qty: 200,
            sub_material: null,
            substituted_material_supplier: null,
            sub_read_code_name: null,
          },
        ],
      },
    });
  }),

  //  NEW HANDLER: Material Group Alt Serve Trend API
  http.get(/.*\/order-transaction\/material-group-alt-serve-trend\/$/, () => {
    return HttpResponse.json({
      success: true,
      data: {
        overall_stats: {
          total_orders: 1000,
          alt_served_orders: 150,
        },
        weekly_data: [
          {
            week_start: "2024-01-01",
            week_end: "2024-01-07",
            brand_alt_served_percentage: 25.5,
            generic_alt_served_percentage: 30.2,
            otc_alt_served_percentage: 20.1,
            consumer_alt_served_percentage: 24.2,
          },
          {
            week_start: "2024-01-08",
            week_end: "2024-01-14",
            brand_alt_served_percentage: 28.0,
            generic_alt_served_percentage: 32.5,
            otc_alt_served_percentage: 18.5,
            consumer_alt_served_percentage: 21.0,
          },
        ],
      },
    });
  }),

  //  NEW HANDLER: Material Group Substituted Trend API
  http.get(/.*\/order-transaction\/material-group-substituted-trend\/$/, () => {
    return HttpResponse.json({
      success: true,
      data: {
        overall_stats: {
          total_orders: 1000,
          substituted_orders: 87,
        },
        weekly_data: [
          {
            week_start: "2024-01-01",
            week_end: "2024-01-07",
            brand_substituted_percentage: 15.5,
            generic_substituted_percentage: 20.2,
            otc_substituted_percentage: 10.1,
            consumer_substituted_percentage: 14.2,
          },
          {
            week_start: "2024-01-08",
            week_end: "2024-01-14",
            brand_substituted_percentage: 18.0,
            generic_substituted_percentage: 22.5,
            otc_substituted_percentage: 8.5,
            consumer_substituted_percentage: 11.0,
          },
        ],
      },
    });
  }),

  // Risk Model Description API
  http.get(/.*\/risk-model-description\/$/, () => {
    return HttpResponse.json({ success: true, data: [] });
  }),

  // Filter Ranges API — backs ``useFilterRangesQuery`` for slider sizing on
  // many pages (issue, vendor_plan, purchase_order, corporate_chain, …).
  // We respond with an empty ``ranges`` map so consumers fall back to their
  // static defaults; tests that need specific maxes mock the hook directly.
  http.get(/.*\/filter-ranges\/?($|\?)/, ({ request }) => {
    const url = new URL(request.url);
    const module = url.searchParams.get("module") ?? "";
    return HttpResponse.json({
      success: true,
      data: { module, ranges: {} },
    });
  }),

  // Supply Chain Events - Detail by event id
  http.get(/.*\/supply-chain-events\/\d+\/$/, () => {
    return HttpResponse.json({
      success: true,
      data: {
        id: 1,
        event_id: "evt-1",
        type: "Supply Disruption",
        type_description: "Test event",
        status: "Active",
        start_date: "2024-01-01",
        end_date: null,
        latitude: null,
        longitude: null,
        city: null,
        state: null,
        country: null,
        mat_nbr: {
          id: 1,
          vendor: "Test Vendor",
          mat_nbr: "MAT001",
          name: "Test Material",
          created_at: "2024-01-01T00:00:00Z",
          updated_at: "2024-01-01T00:00:00Z",
          risk_rating: 0.5,
          driving_risk: "Test",
          dollars_at_risk: 0,
          ndc: "",
          saleable_qty_on_hand: 0,
          unrestricted_qty_on_hand: 0,
          forecast_qty_7day: 0,
          cost_per_unit: 0,
          market_share: 0,
          material_group: "",
          cat_mgr_name: "",
          cat_mgr_nbr: "",
          buyer_name: "",
          buyer_cd: "",
          product_family: "",
          otif_percentage: 0,
          delivery_deviation: 0,
          outbound_fill_rate: 0,
          fdb_gcn_seq_nbr: "",
          hic3_therapy_class: "",
          dollars_at_risk_this_week: 0,
          dollars_at_risk_prev_week: 0,
          xplant_mat_stat: "",
          scrm_mat_grp: "OTC",
        },
        metadata: "",
        created_at: "2024-01-01T00:00:00Z",
        updated_at: "2024-01-01T00:00:00Z",
        related_events: [],
      },
    });
  }),
  http.get(/.*\/auth\/me\/$/, () => {
    return HttpResponse.json({
      success: true,
      data: {
        id: "mock-id",
        mail: "mock@example.com",
        givenName: "Mock",
        surname: "User",
      },
    });
  }),
];
