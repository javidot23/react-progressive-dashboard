import { validateProductData, validateVendorData, waitForLoadingToFinish } from "./testHelpers";

describe("Test Helpers", () => {
  it("should export helper functions", () => {
    expect(typeof waitForLoadingToFinish).toBe("function");
    expect(typeof validateVendorData).toBe("function");
    expect(typeof validateProductData).toBe("function");
  });
});
