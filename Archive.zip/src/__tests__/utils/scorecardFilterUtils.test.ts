import {
  decimalToPercentage,
  percentageToDecimal,
  formatPercentage,
  isPercentageField,
  convertFiltersToUI,
  convertFiltersToAPI
} from '@/lib/scorecardFilterUtils';

describe('scorecardFilterUtils', () => {
  describe('decimalToPercentage', () => {
    it('should convert 0.0 to 0%', () => {
      expect(decimalToPercentage(0.0)).toBe(0);
    });

    it('should convert 0.5 to 50%', () => {
      expect(decimalToPercentage(0.5)).toBe(50);
    });

    it('should convert 1.0 to 100%', () => {
      expect(decimalToPercentage(1.0)).toBe(100);
    });

    it('should convert 0.25 to 25%', () => {
      expect(decimalToPercentage(0.25)).toBe(25);
    });

    it('should convert 0.123 to 12.3%', () => {
      expect(decimalToPercentage(0.123)).toBe(12.3);
    });
  });

  describe('percentageToDecimal', () => {
    it('should convert 0% to 0.0', () => {
      expect(percentageToDecimal(0)).toBe(0);
    });

    it('should convert 50% to 0.5', () => {
      expect(percentageToDecimal(50)).toBe(0.5);
    });

    it('should convert 100% to 1.0', () => {
      expect(percentageToDecimal(100)).toBe(1);
    });

    it('should convert 25% to 0.25', () => {
      expect(percentageToDecimal(25)).toBe(0.25);
    });

    it('should convert 12.3% to 0.123', () => {
      expect(percentageToDecimal(12.3)).toBe(0.123);
    });
  });

  describe('formatPercentage', () => {
    it('should format 0 as "0.00%"', () => {
      expect(formatPercentage(0)).toBe('0.00%');
    });

    it('should format 50 as "50.00%"', () => {
      expect(formatPercentage(50)).toBe('50.00%');
    });

    it('should format 12.3 as "12.30%"', () => {
      expect(formatPercentage(12.3)).toBe('12.30%');
    });
  });

  describe('isPercentageField', () => {
    it('should return true for percentage fields', () => {
      expect(isPercentageField('overall_score_min')).toBe(true);
      expect(isPercentageField('overall_score_max')).toBe(true);
      expect(isPercentageField('otif_percentage_min')).toBe(true);
      expect(isPercentageField('otif_percentage_max')).toBe(true);
      expect(isPercentageField('inbound_fill_rate_min')).toBe(true);
      expect(isPercentageField('inbound_fill_rate_max')).toBe(true);
      expect(isPercentageField('asn_timeliness_min')).toBe(true);
      expect(isPercentageField('asn_timeliness_max')).toBe(true);
      expect(isPercentageField('asn_essential_min')).toBe(true);
      expect(isPercentageField('asn_essential_max')).toBe(true);
      expect(isPercentageField('product_damages_rate_min')).toBe(true);
      expect(isPercentageField('product_damages_rate_max')).toBe(true);
    });

    it('should return false for non-percentage fields', () => {
      expect(isPercentageField('name')).toBe(false);
      expect(isPercentageField('ordering')).toBe(false);
    });
  });

  describe('convertFiltersToUI', () => {
    it('should convert decimal values to percentages for UI display', () => {
      const filters = {
        overall_score_min: 0.8,
        overall_score_max: 0.95,
        otif_percentage_min: 0.75,
        otif_percentage_max: 0.9,
        inbound_fill_rate_min: 0.5,
        inbound_fill_rate_max: 0.8,
        asn_timeliness_min: 0.25,
        product_damages_rate_min: 100,
        name: 'Test'
      };

      const uiFilters = convertFiltersToUI(filters);

      expect(uiFilters.overall_score_min).toBe(80);
      expect(uiFilters.overall_score_max).toBe(95);
      expect(uiFilters.otif_percentage_min).toBe(75);
      expect(uiFilters.otif_percentage_max).toBe(90);
      expect(uiFilters.inbound_fill_rate_min).toBe(50);
      expect(uiFilters.asn_timeliness_min).toBe(25);
      expect(uiFilters.product_damages_rate_min).toBe(10000); // Converted from 100 to 10000 (100 * 100)
      expect(uiFilters.name).toBe('Test'); // Should remain unchanged
    });
  });

  describe('convertFiltersToAPI', () => {
    it('should convert percentage values to decimals for API', () => {
      const filters = {
        overall_score_min: 80,
        overall_score_max: 95,
        otif_percentage_min: 75,
        otif_percentage_max: 90,
        inbound_fill_rate_min: 50,
        inbound_fill_rate_max: 80,
        asn_timeliness_min: 25,
        product_damages_rate_min: 100,
        name: 'Test'
      };

      const apiFilters = convertFiltersToAPI(filters);

      expect(apiFilters.overall_score_min).toBe(0.8);
      expect(apiFilters.overall_score_max).toBe(0.95);
      expect(apiFilters.otif_percentage_min).toBe(0.75);
      expect(apiFilters.otif_percentage_max).toBe(0.9);
      expect(apiFilters.inbound_fill_rate_min).toBe(0.5);
      expect(apiFilters.inbound_fill_rate_max).toBe(0.8);
      expect(apiFilters.asn_timeliness_min).toBe(0.25);
      expect(apiFilters.product_damages_rate_min).toBe(1); // Converted from 100 to 1 (100 / 100)
      expect(apiFilters.name).toBe('Test'); // Should remain unchanged
    });
  });
});
