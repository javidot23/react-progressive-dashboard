import { render } from "./testUtils";

describe("Test Utils", () => {
  it("should provide custom render function", () => {
    expect(typeof render).toBe("function");
  });
});
