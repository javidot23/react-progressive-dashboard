/**
 * Centralized text management system
 * Similar to i18n but structured around contexts (stratium, variant portals, stratium.vendor, stratium.customer)
 *
 * Pattern:
 *   - Stratium is the base/default configuration
 *   - Other tenants only define overrides
 *   - Deep merge is used to combine base + overrides
 *
 * Usage:
 *   const t = useText();
 *   <h1>{t('overview.page.section')}</h1>
 */

import { isFullFeatureSet, isVendorPortal } from "@/tenant";
import { getAllGcnLabel, getGcnLabel } from "@/lib/gcnLabels";

/**
 * Deep merge utility - merges source into target recursively
 * Returns a new object with values from source overriding values in target
 */
function deepMerge(target: any, source: any): any {
  const result = { ...target };

  for (const key in source) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      const sourceValue = source[key];
      const targetValue = result[key];

      if (
        sourceValue &&
        typeof sourceValue === "object" &&
        !Array.isArray(sourceValue) &&
        targetValue &&
        typeof targetValue === "object" &&
        !Array.isArray(targetValue)
      ) {
        result[key] = deepMerge(targetValue, sourceValue);
      } else {
        result[key] = sourceValue;
      }
    }
  }

  return result;
}

/**
 * Base text configuration (Stratium)
 * All other tenants inherit from this and override only what's different
 */
const baseTexts = {
  overview: {
    page: {
      section: "Overview",
      subtitle: "Risk analysis and resiliency insights for your supply chain operations.",
    },
    components: {
      riskListCard: {
        highRiskSuppliers: {
          title: "High-Risk Suppliers",
          description: "Lists top 3 high-risk suppliers based on risk score.",
        },
        highRiskMaterials: {
          title: "High-Risk Materials",
          description: "Lists top 3 high-risk materials based on risk score.",
        },
      },
      serviceLevelCard: {
        title: "Inbound Fill Rate Trend",
        description: "30-day performance vs. target threshold",
        tooltip:
          "This visual provides the Inbound Service Level trend with the purple bars indicating the received quantity and the light purple column displaying order quantity. The blue line indicates the overall service level for the last 90 days. The gray dotted line indicates the user-set service level goal which can be configured by clicking the modify goal button. Click view more to go to the manage tab.",
      },
      valueAtRiskTrendCard: {
        title: "Value at Risk Trend",
        description: "30-day value at risk vs. target threshold",
        tooltip:
          "This visual provides the Value at Risk trend with the purple bars indicating the risk value and the light purple column displaying total exposure. The blue line indicates the overall value at risk for the last 90 days. The gray dotted line indicates the user-set risk threshold goal which can be configured by clicking the modify goal button. Click view more to go to the manage tab.",
      },
      outboundServiceLevelCard: {
        title: "Outbound Service Level Trend",
        description: "30-day delivery performance vs. target threshold",
        tooltip:
          "This visual provides the Outbound Service Level trend showing order fulfillment to customers. The teal bars indicate shipped quantity, the light teal column displays ordered quantity. The orange line indicates the overall delivery rate for the last 30 days. The gray dotted line indicates the user-set delivery goal which can be configured by clicking the modify goal button.",
      },
    },
  },
  manage: {
    demand: {
      totalUnitSalesPerMonth: {
        title: "Demand vs. Forecast Comparison",
        subtitle: "Compare demand with system forecast to identify gaps and trends from the last 90 days.",
        tooltip: "Line Chart displaying Demand (historical sales) vs Forecast Quantity for past 90 Days",
      },
    },
    overview: {
      productOmitsTrend: {
        title: "Outbound Unfilled Quantity",
        subtitle: "Weekly unfilled quantity and fulfillment percentage for the last 90 days.",
        tooltip:
          "Bar chart showing the unfilled quantity and blue line representing the fulfillment percentage for a rolling 90 days, aggregated weekly.",
        legendUnfilled: "Unfilled Quantity",
        legendFulfillment: "Fulfillment %",
        yAxisLabel: "Quantity",
      },
      currentVsPriorSales: {
        title: "Current vs Prior Year Unit Sales",
        subtitle: "Sales increases and decreases indicated by color for current year versus prior year.",
        tooltip:
          "Stacked Bar Chart displaying Current Year/Prior Year quantity of product sold by Cencora, based on invoice creation.",
        legendCurrent: "Current Year",
        legendPrior: "Prior Year",
        legendCurrentYear: "Current Year ({year})",
        legendPriorYear: "Prior Year ({year})",
        legendPositiveChange: "Positive change (current vs prior)",
        legendNegativeChange: "Negative change (current vs prior)",
        legendPositiveChangeYear: "Positive change ({year} vs prior)",
        legendNegativeChangeYear: "Negative change ({year} vs prior)",
        tooltipPartialMonth:
          "Month-to-date for {currentYearMonth} vs the full calendar month for {priorYearMonth}.",
      },
      materialRelativeInventory: {
        title: "Material Relative Inventory",
        subtitle: "Showing how many materials fall into each inventory band per week for the last 90 days.",
        tooltip:
          "Displays current Days on Hand and the 90 day rolling trend as a stacked bar chart. Count of materials in each inventory band where Low is 0-10 DOH, Acceptable is 11-60 DOH, Overstock is 61+ DOH, and No Forecast.",
        tooltipTotalLabel: "Total Materials",
        yAxisLabel: "Number of materials",
        noDataTitle: "No Data Available",
        noDataDescription:
          "No inventory band data found for the selected filters. Try adjusting your filter criteria to see results.",
      },
      productOmitsOverview: {
        title: "Materials with Outbound Unfilled Qty",
        subtitle:
          "Displays the weekly distribution of materials across three outbound fill rate ranges over the past 90 days. Modify threshold by clicking 'Modify Goal'.",
        tooltip:
          "Displays the distinct count of materials with outbound unfilled qty out of the total number of materials ordered and outbound unfilled qty trends for a rolling 90 days as a stacked bar chart. Excess Unfills (Materials) is the number of materials with outbound fill rate below your set threshold. Allowed Unfills (Materials) is the number of materials with outbound fill rate greater than or equal to your set threshold. No Unfills (Materials) is the number of materials with outbound fill rate of 100%.",
        modifyGoalButton: "Modify Goal",
        modalTitle: "Modify Materials with Outbound Unfilled Qty Goal",
        modalDescription: "Set a new goal for the maximum allowed percentage of materials with outbound unfilled quantity.",
        modalLabel: "New Goal (%)",
        modalCancel: "Cancel",
        modalSave: "Save",
        legendExcess: "Excess Unfills (Materials)",
        legendAllowed: "Allowed Unfills (Materials)",
        legendNoOmits: "No Unfills (Materials)",
        yAxisLabel: "Materials",
        tooltipTotalLabel: "Total Materials",
        noDataTitle: "No Data Available",
        noDataDescription:
          "No material omits overview data found for the selected filters. Try adjusting your filter criteria to see results.",
        loadingMessage: "Loading chart data...",
        errorMessage: "Failed to load data",
        donutTooltip: "Number of materials with outbound unfilled quantity vs total materials ordered (distinct material count).",
        emptyStateTitle: "No Data Found",
        emptyStateDescription:
          "No current vs prior year unit sales data found for the selected filters. Try adjusting your filter criteria to see results.",
      },
    },
    supply: {
      purchaseOrdersByMaterial: {
        title: "Purchase Orders by Material",
        subtitle:
          "View purchase order performance grouped by material. Click on a material to view purchase order history details.",
        tooltip:
          "A Table displaying purchase level details by material over the last 90 days, including Material Name, Units Ordered, Units Received On Time, Units Received Late, Units Not Received, and Inbound Fill Rate.",
      },
      ordersRelative: {
        title: "Orders Received Relative to Due Date",
        subtitle: "Displays the percentage of orders received within specific day ranges relative to their due date.",
        tooltip:
          "Bar chart showing the percentage of orders received within specific day ranges relative to their anticipated delivery date. Negative values indicate early delivery, 0 indicates on-time delivery, and positive values indicate late delivery.",
      },
      otifOverTime: {
        title: "OTIF Performance Over Time of Material Bill Capsule",
        subtitle: "Displays On-Time and In-Full performance metrics over time for the selected material.",
        tooltip:
          "Combined bar and line chart showing On-Time count, In-Full count, and OTIF percentage over time. Material status is indicated by color (green for active, gray for inactive).",
      },
    },
  },
  common: {
    error: {
      tabError: "This tab has an error",
    },
  },
  filters: {
    gcn: {
      label: getGcnLabel(),
      defaultValue: getAllGcnLabel(),
    },
  },
};

const tenantOverrides = {
  variant: {
    manage: {
      demand: {
        totalUnitSalesPerMonth: {
          title: "Demand Trend",
          subtitle: "Weekly demand trends for the last 90 days.",
          tooltip: "This chart displays the total order quantity trends by week over the last 90 days.",
        },
      },
    },
  },
  "stratium.vendor": {
    manage: {
      demand: {
        totalUnitSalesPerMonth: {
          title: "Demand vs. Forecast Comparison",
          subtitle: "Compare demand with system forecast to identify gaps and trends from the last 90 days.",
          tooltip: "Line Chart displaying Demand (historical sales) vs Forecast Quantity for past 90 Days",
        },
      },
    },
  },
};

type TextStructure = typeof baseTexts;

function getTextsForContext(): TextStructure {
  if (isFullFeatureSet()) return baseTexts;

  let result = deepMerge(baseTexts, tenantOverrides.variant);

  if (isVendorPortal()) {
    result = deepMerge(result, tenantOverrides["stratium.vendor"]);
  }

  return result;
}

/**
 * Get a nested value from an object using dot notation
 */
function getNestedValue(obj: any, path: string): string {
  const keys = path.split(".");
  let value = obj;

  for (const key of keys) {
    if (value && typeof value === "object" && key in value) {
      value = value[key];
    } else {
      return path;
    }
  }

  return typeof value === "string" ? value : path;
}

const contextTexts = getTextsForContext();

export function getText(key: string): string {
  return getNestedValue(contextTexts, key);
}

/**
 * React hook for accessing text strings
 *
 * @example
 * const t = useText();
 * <h1>{t('overview.page.section')}</h1>
 */
export function useText() {
  return (key: string): string => getText(key);
}

/**
 * Direct access to all texts (for advanced use cases)
 */
export const allTexts = contextTexts;
