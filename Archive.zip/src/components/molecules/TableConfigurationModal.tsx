import React from "react";

interface TableConfigurationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCreateFilter?: () => void;
  onSelectReorderTable?: () => void;
}

export const TableConfigurationModal: React.FC<TableConfigurationModalProps> = ({
  isOpen,
  onClose,
  onSelectCreateFilter,
  onSelectReorderTable,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-9999 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        style={{
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
        onClick={onClose}
      />

      {/* Modal Card */}
      <div
        className="relative bg-white rounded-lg shadow-xl max-w-2xl w-[90vw] md:w-full mx-4"
        style={{
          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 pt-6 pb-4">
          <h2
            className="font-bold mb-2"
            style={{
              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "20px",
              fontWeight: "700",
              lineHeight: "28px",
            }}
          >
            Choose the table configuration you want to do
          </h2>
          <p
            className="text-sm"
            style={{
              color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "400",
              lineHeight: "20px",
            }}
          >
            Select one of the options below to customize your table view and improve
          </p>
        </div>

        {/* Divider */}
        <div
          className="h-px mx-6"
          style={{
            backgroundColor: "var(--cds-color-border-primary, #E0E0E0)",
          }}
        />

        {/* Options Section */}
        <div className="px-6 py-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Create Custom Filter Card */}
          <button
            onClick={() => {
              onSelectCreateFilter?.();
              onClose();
            }}
            className="flex flex-col items-center p-6 bg-white border rounded-lg hover:shadow-md transition-shadow cursor-pointer text-left"
            style={{
              borderColor: "var(--cds-color-border-primary, #E0E0E0)",
              boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
            }}
          >
            {/* Icon Container */}
            <div
              className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
              style={{
                backgroundColor: "#E9D5FF", // Light purple
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="white"
                className="w-6 h-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"
                />
              </svg>
            </div>

            {/* Title */}
            <h3
              className="font-bold mb-2 text-center w-full"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "700",
                lineHeight: "24px",
              }}
            >
              Create Custom Filter
            </h3>

            {/* Description */}
            <p
              className="text-sm text-center"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "400",
                lineHeight: "20px",
              }}
            >
              Save your favorite filter combinations so you can instantly view the exact data you need without setting up filters
              every time.
            </p>
          </button>

          {/* Reorder Table Card */}
          <button
            onClick={() => {
              onSelectReorderTable?.();
              onClose();
            }}
            className="flex flex-col items-center p-6 bg-white border rounded-lg hover:shadow-md transition-shadow cursor-pointer text-left"
            style={{
              borderColor: "var(--cds-color-border-primary, #E0E0E0)",
              boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
            }}
          >
            {/* Icon Container */}
            <div
              className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
              style={{
                backgroundColor: "#FCE7F3", // Light pink
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="white"
                className="w-6 h-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M3.75 6A2.25 2.25 0 0 1 6 3.75h2.25A2.25 2.25 0 0 1 10.5 6v2.25A2.25 2.25 0 0 1 8.25 10.5H6a2.25 2.25 0 0 1-2.25-2.25V6ZM3.75 15.75A2.25 2.25 0 0 1 6 13.5h2.25a2.25 2.25 0 0 1 2.25 2.25V18a2.25 2.25 0 0 1-2.25 2.25H6A2.25 2.25 0 0 1 3.75 18v-2.25ZM13.5 6a2.25 2.25 0 0 1 2.25-2.25H18A2.25 2.25 0 0 1 20.25 6v2.25A2.25 2.25 0 0 1 18 10.5h-2.25a2.25 2.25 0 0 1-2.25-2.25V6ZM13.5 15.75a2.25 2.25 0 0 1 2.25-2.25H18a2.25 2.25 0 0 1 2.25 2.25V18A2.25 2.25 0 0 1 18 20.25h-2.25A2.25 2.25 0 0 1 13.5 18v-2.25Z"
                />
              </svg>
            </div>

            {/* Title */}
            <h3
              className="font-bold mb-2 text-center w-full"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "700",
                lineHeight: "24px",
              }}
            >
              Reorder Table
            </h3>

            {/* Description */}
            <p
              className="text-sm text-center"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "400",
                lineHeight: "20px",
              }}
            >
              Drag columns to arrange your table however works best for you. Your layout will be saved automatically for next
              time.
            </p>
          </button>
        </div>
      </div>
    </div>
  );
};
