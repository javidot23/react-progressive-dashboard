import { FC } from "react";
import SkeletonCard from "@/components/atoms/SkeletonCard";

interface SkeletonCardGridProps {
  count?: number;
}

const SkeletonCardGrid: FC<SkeletonCardGridProps> = ({ count = 6 }) => {
  const skeletonCards = [
    { showChart: true, showBadge: false }, // Fill Rate Trend
    { showChart: true, showBadge: true }, // Risk Score
    { showChart: false, showBadge: false }, // Driving Risk
    { showChart: false, showBadge: false }, // Risk Adjusted Value
    { showChart: false, showBadge: false }, // Sales Amount
    { showChart: false, showBadge: false }, // Material Risk
  ];

  return (
    <div className="space-y-6">
      {Array.from({ length: count }).map((_, vendorIndex) => (
        <div key={vendorIndex} className="bg-white border border-gray-200 rounded-lg p-6">
          {/* Supplier Name */}
          <div className="mb-6">
            <div className="h-6 bg-gray-200 rounded w-48 animate-pulse"></div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            {skeletonCards.map((cardProps, cardIndex) => (
              <SkeletonCard key={cardIndex} showChart={cardProps.showChart} showBadge={cardProps.showBadge} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default SkeletonCardGrid;
