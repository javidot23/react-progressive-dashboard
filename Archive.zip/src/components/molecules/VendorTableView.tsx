import { VendorRawData, formatNumber, formatSalesRevenueAndQuantity, getRiskBadge } from "@/lib/vendorUtils";
import { useNavigate } from "react-router-dom";
import { InfoIcon, Pagination, RiskBadge } from "@/components/atoms";
import { useRiskModelDescriptions } from "@/hooks";
import { TableColumn } from "@/components/molecules/ReorderTableModal";

interface VendorTableViewProps {
  data: VendorRawData[];
  currentPage: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  viewScope?: "material" | "gcn" | "product";
  columns?: TableColumn[];
}

export default function VendorTableView({
  data,
  currentPage,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  viewScope: _viewScope = "material",
  columns: _columns = [],
}: VendorTableViewProps) {
  const navigate = useNavigate();
  const { getEnrichedMetadata } = useRiskModelDescriptions();

  const handleRowClick = (vendor: VendorRawData) => {
    navigate(`/plan/vendor/${vendor.id}`, { state: { vendor } });
  };

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm text-left">
          <thead className="font-bold text-ui-text-primary">
            <tr>
              <th className="px-4 py-2 w-full flex flex-row items-center gap-2 text-nowrap">
                Name
                <InfoIcon size={20} position="right" tooltip="The name is the name of the vendor." />
              </th>
              <th className="px-4 py-2 text-nowrap">Fill Rate Trend 90 Days</th>
              <th className="px-4 py-2 text-nowrap">Risk Score</th>
              <th className="px-4 py-2 text-nowrap">Driving Risk</th>
              <th className="px-4 py-2 text-nowrap">Risk Adjusted Value</th>
              <th className="px-4 py-2 text-nowrap">Sales Amount</th>
              <th className="px-4 py-2 text-nowrap">Material At Risk</th>
            </tr>
          </thead>
          <tbody>
            {data.map(vendor => {
              const serviceLevels = vendor.service_levels_90_days;
              const avgFillRate =
                serviceLevels && serviceLevels.length > 0
                  ? (
                      serviceLevels.reduce((sum: number, s: any) => {
                        const orderQty = s.total_order_qty ?? 0;
                        const receivedQty = s.total_received_qty ?? 0;
                        return sum + (orderQty > 0 ? (receivedQty / orderQty) * 100 : 0);
                      }, 0) / serviceLevels.length
                    ).toFixed(2)
                  : "93.40";
              const riskPercentage = (vendor.risk_rating * 100).toFixed(2);

              return (
                <tr
                  key={vendor.id}
                  className="border-t hover:bg-brand-primary-50 cursor-pointer"
                  onClick={() => handleRowClick(vendor)}
                >
                  <td className="px-4 py-2 font-medium text-ui-text-primary text-nowrap">
                    {vendor.name} • {vendor.vendor_nbr}
                  </td>
                  <td className="px-4 py-2 text-nowrap">AVG {avgFillRate}%</td>
                  {(() => {
                    const riskBadge = getRiskBadge(vendor.risk_rating);
                    return (
                      <td className="px-4 py-2">
                        <div className="flex flex-row items-center gap-2">
                          <div className="w-[100px] bg-gray-200 rounded-full h-1">
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: "100%",
                                backgroundColor: riskBadge.hexColor,
                              }}
                            />
                          </div>
                          <RiskBadge riskRating={vendor.risk_rating} showIcon={true} size="sm" />
                        </div>
                      </td>
                    );
                  })()}
                  <td className="px-4 py-2 text-nowrap">
                    {getEnrichedMetadata(vendor.driving_risk).display_name || vendor.driving_risk || "-"}
                  </td>
                  <td className="px-4 py-2 text-nowrap">
                    {vendor.risk_adjusted_value
                      ? `${formatNumber(
                          (Number(riskPercentage) / 100) * vendor.risk_adjusted_value
                        )} / ${formatNumber(vendor.risk_adjusted_value)}`
                      : "- / -"}
                  </td>
                  <td className="px-4 py-2 text-nowrap">
                    {formatSalesRevenueAndQuantity(vendor.sales_amount, vendor.sales_volume)}
                  </td>
                  <td className="px-4 py-2 text-nowrap">
                    {(vendor.total_materials ?? 0) > 0
                      ? `${vendor.materials_at_risk ?? 0} / ${vendor.total_materials ?? 0}`
                      : "- / -"}
                  </td>
                </tr>
              );
            })}
            {data.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-6 text-center text-ui-text-secondary">
                  No data
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Pagination
        currentPage={currentPage}
        pageSize={pageSize}
        total={total}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        itemName="Suppliers"
      />
    </div>
  );
}
