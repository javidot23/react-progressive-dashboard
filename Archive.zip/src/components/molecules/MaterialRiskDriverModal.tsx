import { useEffect, useRef, useState } from "react";
import { ModalShell } from "@/components/atoms/ModalShell";
import { getRiskBadge } from "@/lib/vendorUtils";
import { useMaterialRiskQuery } from "@/hooks/queries";
import arrowRightIcon from "@/assets/icons/right-arrow-primary.svg";
import DocumentIcon from "@/assets/icons/accounting-document.svg";
import AlertTriangleIcon from "@/assets/icons/alert-triangle-primary.svg";
import PinIcon from "@/assets/icons/pin.svg";
import CartIcon from "@/assets/icons/shopping-cart-empty.svg";
import WarehouseIcon from "@/assets/icons/warehouse-packages.svg";
import { useRiskModelDescriptions } from "@/hooks";
import { formatCurrencyCompact } from "@/lib/utils";
import {
  buildRiskCategorySummaries,
  CATEGORY_SCORE_TIME_HORIZON,
  getMaxHorizonContributors,
  getRiskScoreColor,
  MODEL_TYPE_TO_CATEGORY_SCORE_TYPE,
  type EnrichedMaterialRiskRow,
} from "@/lib/riskCategoryUtils";
import { CardLayout } from "@/components/templates";
import { CircularProgress } from "@/components/atoms";

interface MaterialRiskDriverModalProps {
  isOpen: boolean;
  onClose: () => void;
  materialName: string;
  vendorName?: string;
  overallRiskScore: number;
  dollarsAtRisk: number;
  materialId?: number;
  /** Material number (mat_nbr) for display; only this is shown in UI—Material ID is never displayed */
  materialNbr?: string | number;
  riskLevel?: number;
  drivingRisk?: string;
  ndc?: string;
}

interface ContributingFactor {
  id: number;
  original_risk_type: string;
  risk_type: string;
  risk_rating: number;
  dollars_at_risk?: number | null;
  time_horizon: number;
  status_date?: string;
  risk_description: string;
  display_name: string;
}

interface RiskCategoryData {
  type: string;
  title: string;
  icon: string;
  score: number;
  subtitle?: string;
  time_horizon?: number;
  risk_description?: string;
  contributing_factors: ContributingFactor[];
}

const MODEL_TYPE_TO_ICON: Record<string, string> = {
  base_model_operational: AlertTriangleIcon,
  base_model_market: CartIcon,
  base_model_sales: WarehouseIcon,
  base_model_regulatory: DocumentIcon,
  base_model_location: PinIcon,
};
const DEFAULT_ICON = AlertTriangleIcon;

export const MaterialRiskDriverModal: React.FC<MaterialRiskDriverModalProps> = ({
  isOpen,
  onClose,
  materialName,
  vendorName,
  overallRiskScore,
  dollarsAtRisk,
  materialId,
  materialNbr,
  riskLevel,
  drivingRisk,
  ndc,
}) => {
  const { riskCategoryTypes, enrichRiskData, getEnrichedMetadata } = useRiskModelDescriptions();
  const { riskData: rawRiskData, error } = useMaterialRiskQuery({
    materialId,
    enabled: isOpen && !!materialId,
  });

  const [expandedCategory, setExpandedCategory] = useState<RiskCategoryData | null>(null);
  const expandedSectionRef = useRef<HTMLDivElement>(null);

  void riskLevel;

  const riskData = enrichRiskData(rawRiskData);

  useEffect(() => {
    if (expandedCategory && expandedSectionRef.current) {
      expandedSectionRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [expandedCategory]);

  if (!isOpen) return null;

  const riskCategories: RiskCategoryData[] = buildRiskCategorySummaries(
    riskData as EnrichedMaterialRiskRow[],
    riskCategoryTypes,
    { vendorName, iconByType: MODEL_TYPE_TO_ICON, defaultIcon: DEFAULT_ICON }
  ).map(category => {
    const categoryScoreType = MODEL_TYPE_TO_CATEGORY_SCORE_TYPE[category.type];
    const categoryScoreFactor = riskData.find(
      risk => risk.original_risk_type === categoryScoreType && risk.time_horizon === CATEGORY_SCORE_TIME_HORIZON
    );

    const categoryContributors = (riskData as EnrichedMaterialRiskRow[]).filter(risk => risk.risk_type === category.type);

    return {
      ...category,
      time_horizon: categoryScoreFactor?.time_horizon,
      contributing_factors: getMaxHorizonContributors(categoryContributors) as ContributingFactor[],
    };
  });

  const riskBadge = getRiskBadge(overallRiskScore / 100);

  return (
    <ModalShell
      isOpen={isOpen}
      onClose={onClose}
      ariaLabelledBy="material-risk-driver-title"
      usePortal
      zIndex={99999}
      overlayClassName="fixed inset-0 flex items-center justify-center p-4 sm:p-6"
      className="flex flex-col max-h-[85vh] w-full overflow-hidden rounded-[8px] bg-[#F8F9FA] sm:w-[80%] sm:min-w-0 md:w-[80%] xl:w-250"
      lockScroll={false}
    >
      <div className="shrink-0 flex-col bg-white border-b border-[#E0E0E0]">
        <div className="flex items-center justify-between p-8">
          <div>
            <h2 id="material-risk-driver-title" className="text-lg font-semibold">
              {materialName}
            </h2>
            <span className="text-xs font-semibold text-text-secondary">
              {[
                ndc != null && ndc !== "" && `NDC: ${ndc}`,
                materialNbr != null && materialNbr !== "" && `Material Number: ${materialNbr}`,
                vendorName != null && vendorName !== "" && `Supplier: ${vendorName}`,
              ]
                .filter(Boolean)
                .join(" • ")}
            </span>
          </div>
          <button type="button" className="self-start" onClick={onClose} aria-label="Close material risk drivers">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="#111928"
              className="size-6"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain">
        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
            <p className="text-sm text-red-600">Error loading risk data: {error}</p>
          </div>
        )}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 px-6 py-4">
          <div className="bg-white border border-[#E0E0E0] rounded p-3">
            <div className="flex justify-between items-center">
              <div className="text-sm text-neutral-500 font-medium">Risk Score</div>
              <div
                className={`flex items-center ${riskBadge.bgColor} ${riskBadge.textColor} border ${riskBadge.borderColor} px-1 py-0.5 rounded text-2xs font-semibold text-nowrap`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
                  />
                </svg>
                {riskBadge.text}
              </div>
            </div>
            <div className="font-bold text-neutral-900 text-xl mt-1">{Math.round(overallRiskScore)} / 100</div>
            <div className="h-2 mt-2">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="h-2 rounded-full"
                  style={{ width: `${overallRiskScore}%`, backgroundColor: riskBadge.hexColor }}
                />
              </div>
            </div>
          </div>
          <div className="bg-white border border-[#E0E0E0] rounded p-3">
            <div className="flex flex-col items-left">
              <div className="text-sm text-neutral-500 font-medium">Risk Adjusted Value</div>
            </div>
            <div className="font-bold text-neutral-900 text-xl mt-2">
              {overallRiskScore && dollarsAtRisk
                ? `${formatCurrencyCompact(Math.round((overallRiskScore / 100) * dollarsAtRisk))}`
                : "- / -"}
            </div>
          </div>
          <div className="bg-white border border-[#E0E0E0] rounded p-3">
            <div className="flex flex-col items-left">
              <div className="text-sm text-neutral-500 font-medium">Driving Risk Category</div>
            </div>
            <div className="font-bold text-neutral-900 text-xl mt-2">
              {drivingRisk ? getEnrichedMetadata(drivingRisk).display_name || drivingRisk : "-"}
            </div>
          </div>
        </div>
        <CardLayout className="mx-6 mb-8 shadow-xs p-4" style={{ padding: 14 }}>
          {expandedCategory && (
            <div ref={expandedSectionRef} className="flex flex-col mb-4">
              <div className="flex flex-col gap-2 p-3 rounded-lg bg-white border border-[#E0E0E0] mb-3">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-primary-50 shrink-0 rounded">
                      <img src={expandedCategory.icon} alt={expandedCategory.title} className="h-6 w-6" />
                    </div>
                    <div className="flex flex-col">
                      <p className="font-semibold text-text-primary">{expandedCategory.title}</p>
                      <span className="text-sm text-text-secondary">
                        {expandedCategory.contributing_factors.length} Contributing Factor
                        {expandedCategory.contributing_factors.length !== 1 ? "s" : ""}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => setExpandedCategory(null)} className="text-neutral-500 hover:text-neutral-700">
                      <img src={arrowRightIcon} alt="Arrow Right" className="w-4 h-4 transition-transform rotate-90" />
                    </button>
                  </div>
                </div>
              </div>
              {/* Subcategories grid */}
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {expandedCategory.contributing_factors.length > 0 ? (
                  expandedCategory.contributing_factors.map((factor, index) => (
                    <div
                      key={`${factor.original_risk_type}-${index}`}
                      className="flex justify-between items-center gap-4 p-3 rounded-lg bg-[#E7F7FF] border border-[#E2E8F0]"
                    >
                      <div className="flex items-center gap-2">
                        <div className="flex flex-col gap-2">
                          <p className="font-semibold text-text-primary leading-none">
                            {factor.display_name || factor.original_risk_type?.replace(/_/g, " ").replace(/-/g, " ") || "Unknown"}
                          </p>
                          <span className="inline-flex w-fit items-center gap-1 rounded-full border border-brand-primary-100 bg-brand-primary-50 px-2 py-0.5 text-xs font-semibold text-brand-primary-main">
                            {factor.time_horizon} day horizon
                          </span>
                          <span className="text-xs leading-none text-text-secondary">
                            {factor.risk_description || "Risk model contributor"}
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-col gap-1">
                        <CircularProgress
                          value={Math.round(factor.risk_rating * 100)}
                          size={30}
                          strokeWidth={5}
                          color={getRiskScoreColor(Math.round(factor.risk_rating * 100))}
                        />
                        <p>
                          {Math.round(factor.risk_rating * 100)}/<b className="text-brand-primary-700">100</b>
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="col-span-full flex flex-col items-center justify-center py-8 px-4 rounded-lg bg-neutral-50 border border-dashed border-neutral-300">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={1.5}
                      stroke="currentColor"
                      className="w-10 h-10 text-neutral-400 mb-3"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z"
                      />
                    </svg>
                    <p className="text-sm font-medium text-neutral-500">No contributing factors available</p>
                    <p className="text-xs text-neutral-400 mt-1">
                      This risk category does not have detailed contributors to display.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {riskCategories.map(category => (
              <div key={category.type} className="flex flex-col gap-2 p-3 rounded-lg bg-white border border-[#E0E0E0]">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center flex-wrap gap-2">
                    <div className="p-1.5 bg-primary-50 shrink-0 rounded">
                      <img src={category.icon} alt={category.title} className="h-5 w-5" />
                    </div>
                    <p className="text-sm font-semibold text-text-secondary max-w-17.5">{category.title}</p>
                  </div>
                  <CircularProgress value={category.score} size={30} strokeWidth={5} color={getRiskScoreColor(category.score)} />
                </div>
                <p className="text-lg">
                  {category.score}/<b className="text-brand-primary-700">100</b>
                </p>
                <button
                  onClick={() => setExpandedCategory(expandedCategory?.type === category.type ? null : category)}
                  className={`border border-[#CACACA] hover:bg-brand-primary-50 rounded px-2 py-1 text-sm shrink-0 mt-auto w-fit ${expandedCategory?.type === category.type ? "bg-brand-primary-50" : ""}`}
                >
                  <div className="flex flex-wrap items-center gap-1">
                    <div className="text-sm font-bold text-brand-primary-main">Risk Contributors</div>
                    <img
                      src={arrowRightIcon}
                      alt="Arrow Right"
                      className={`w-4 h-4 transition-transform ${expandedCategory?.type === category.type ? "rotate-90" : ""}`}
                    />
                  </div>
                </button>
              </div>
            ))}
          </div>
        </CardLayout>
      </div>
    </ModalShell>
  );
};
