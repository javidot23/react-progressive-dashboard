import React, { useState, useRef, useEffect, useLayoutEffect, ReactNode } from 'react';
import { createPortal } from 'react-dom';

interface DropdownMenuProps {
  children: ReactNode;
}

interface DropdownMenuTriggerProps {
  children: ReactNode;
  asChild?: boolean;
}

interface DropdownMenuContentProps {
  children: ReactNode;
  triggerRef?: React.RefObject<HTMLDivElement>;
}

interface DropdownMenuItemProps {
  children: ReactNode;
  onClick?: () => void;
}

export function DropdownMenu({ children }: DropdownMenuProps) {
  const [open, setOpen] = useState(false);
  const triggerRef = useRef<HTMLDivElement>(null);
  const contentId = useRef(`dropdown-${Math.random().toString(36).substr(2, 9)}`);

  useEffect(() => {
    if (!open) return;

    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Node;
      const triggerElement = triggerRef.current;
      const contentElement = document.getElementById(contentId.current);

      if (
        triggerElement &&
        !triggerElement.contains(target) &&
        contentElement &&
        !contentElement.contains(target)
      ) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  return (
    <div className="relative">
      <div ref={triggerRef}>
        {React.Children.map(children, (child) => {
          if (React.isValidElement(child)) {
            if (child.type === DropdownMenuTrigger) {
              return React.cloneElement(child, {
                onToggle: () => setOpen(!open),
                isOpen: open
              } as any);
            }
            if (child.type === DropdownMenuContent && open) {
              return React.cloneElement(child, {
                triggerRef: triggerRef,
                onClose: () => setOpen(false),
                contentId: contentId.current,
              } as any);
            }
          }
          return null;
        })}
      </div>
    </div>
  );
}

export function DropdownMenuTrigger({
  children,
  asChild = false,
  onToggle
}: DropdownMenuTriggerProps & { onToggle?: () => void; isOpen?: boolean }) {
  if (asChild && React.isValidElement(children)) {
    return React.cloneElement(children, {
      onClick: onToggle
    } as any);
  }

  return (
    <button
      onClick={onToggle}
      className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-hidden focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
    >
      {children}
    </button>
  );
}

function calculatePosition(triggerRef: React.RefObject<HTMLDivElement> | undefined) {
  if (!triggerRef?.current) {
    return { top: -9999, left: -9999 };
  }
  const rect = triggerRef.current.getBoundingClientRect();
  const contentWidth = 224;

  return {
    top: rect.bottom + window.scrollY + 4,
    left: rect.right + window.scrollX - contentWidth,
  };
}

export function DropdownMenuContent({
  children,
  triggerRef,
  contentId,
}: DropdownMenuContentProps & { onClose?: () => void; contentId?: string }) {
  const [position, setPosition] = useState(() => calculatePosition(triggerRef));

  useLayoutEffect(() => {
    setPosition(calculatePosition(triggerRef));
  }, [triggerRef]);

  const content = (
    <div
      id={contentId}
      className="fixed w-56 bg-white border border-gray-200 rounded-md shadow-lg z-9999"
      style={{ top: position.top, left: position.left }}
    >
      {children}
    </div>
  );

  return createPortal(content, document.body);
}

export function DropdownMenuItem({ children, onClick }: DropdownMenuItemProps) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center px-4 py-2 text-sm text-left text-gray-700 hover:bg-gray-100 transition-colors"
    >
      {children}
    </button>
  );
}
