import SparkAreaLineChart from "@/components/molecules/SparkAreaLineChart";

interface KPILineChartProps {
  data: number[];
  xLabels?: string[];
  height?: number;
  color?: string;
  valueFormatter?: (value: number | null) => string;
  ariaLabel?: string;
}

export default function KPILineChart({
  data,
  xLabels,
  height = 50,
  color = "#461E96",
  valueFormatter = (value: number | null) => value?.toString() || "0",
  ariaLabel,
}: KPILineChartProps) {
  const format = (value: number) => valueFormatter(value);

  return (
    <SparkAreaLineChart
      data={data}
      xLabels={xLabels}
      height={height}
      color={color}
      valueFormatter={format}
      ariaLabel={ariaLabel}
      computeYDomain={(minValue, maxValue) => {
        const padding = (maxValue - minValue) * 0.1 || 1;
        return [Math.max(0, Math.min(minValue - padding, minValue * 0.9)), maxValue + padding];
      }}
      renderTooltip={({ labels, tooltip, tooltipPosition, containerRef, valueFormatter: fmt }) => {
        const el = containerRef.current;
        if (!el) return null;

        const containerRect = el.getBoundingClientRect();
        const tooltipWidth = 120;
        const tooltipHeight = 50;
        const cursorX = tooltipPosition.x;
        const cursorY = tooltipPosition.y;
        const offset = 15;
        const edgeMargin = 5;

        let tooltipLeft = cursorX + offset;
        if (tooltipLeft + tooltipWidth + edgeMargin > containerRect.width) {
          tooltipLeft = cursorX - tooltipWidth - offset;
          if (tooltipLeft < edgeMargin) tooltipLeft = edgeMargin;
        }
        if (tooltipLeft < edgeMargin) tooltipLeft = edgeMargin;

        let tooltipTop = cursorY - tooltipHeight / 2;
        if (tooltipTop < edgeMargin) {
          tooltipTop = edgeMargin;
        } else if (tooltipTop + tooltipHeight + edgeMargin > containerRect.height) {
          tooltipTop = containerRect.height - tooltipHeight - edgeMargin;
        }

        return (
          <div className="absolute z-50 pointer-events-none" style={{ left: `${tooltipLeft}px`, top: `${tooltipTop}px` }}>
            <div className="bg-[#211359] text-white text-xs rounded-md shadow-lg w-[120px] p-2 font-normal z-30">
              <div className="flex flex-col gap-1">
                <div className="flex justify-between">
                  <span className="text-xs">Date:</span>
                  <span className="text-xs">{labels[tooltip.index]}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs">Value:</span>
                  <span className="text-xs">{fmt(tooltip.value)}</span>
                </div>
              </div>
            </div>
          </div>
        );
      }}
    />
  );
}
