import React, { useRef, useState } from "react";
import { Button, Input } from "@/components/atoms";
import { ModalShell } from "@/components/atoms/ModalShell";
import { type CustomList } from "@/lib/apiServices";
import { useCreateCustomList } from "@/components/custom-lists/hooks/useCreateCustomList";
import { icons } from "../custom-lists/components/Icons";

const colors = ["#DDDBF7", "#B7E8FE", "#FED0E2", "#8AF6BB", "#FCD9D1", "#FFF8BA"];

const initialForm = {
  name: "",
  description: "",
  public: true,
  color: colors[0],
  icon: Object.keys(icons)[0],
};

type CreateNewListModalProps = {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (listData: { id: string; name: string; description: string }) => void;
};

export const CreateNewListModal: React.FC<CreateNewListModalProps> = ({ isOpen, onClose }) => {
  const focusRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState<CustomList>(initialForm);
  const create = useCreateCustomList();

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!form.name.trim() || create.isPending) return;
    create.mutate(form);
  };

  const handleClose = () => {
    if (create.isPending) return;
    onClose();
    setForm(initialForm);
  };

  return (
    <ModalShell
      isOpen={isOpen}
      onClose={handleClose}
      ariaLabelledBy="create-new-list-title"
      closeOnEscape={!create.isPending}
      usePortal
      zIndex={9999}
      overlayClassName="fixed inset-0 flex items-center justify-center"
      className="relative bg-white rounded-xl max-w-lg w-[90vw] md:w-full mx-4"
    >
      <div className="flex items-center justify-between px-6 pt-6 pb-4 mb-4 border-b border-[#E5E7EB]">
        <div className="flex flex-col">
          <h2 id="create-new-list-title" className="font-bold text-lg text-ui-text-primary">
            Create New Filter List
          </h2>
          <p className="text-xs text-gray-500">
            Create a new list to organize your filters and share them with your team.
          </p>
        </div>
        <button
          type="button"
          onClick={handleClose}
          disabled={create.isPending}
          className="text-gray-400 hover:text-gray-600 transition-colors p-1 self-start"
          aria-label="Close create list dialog"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6" aria-hidden>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="flex flex-col gap-6 px-6 pb-6">
          <div>
            <label htmlFor="create-list-name" className="block mb-2 text-ui-text-primary text-sm font-bold">
              List Name <span className="text-red-500">*</span>
            </label>
            <Input
              id="create-list-name"
              name="name"
              value={form.name}
              onChange={e => setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))}
              placeholder="Essential List"
              className="mb-1"
              ref={focusRef}
            />
            <span className="text-xs text-gray-500">Choose a descriptive name that your team will recognize</span>
          </div>
          <div>
            <label htmlFor="create-list-description" className="block mb-2 text-ui-text-primary text-sm font-bold">
              Description {"(Optional)"}
            </label>
            <Input
              id="create-list-description"
              name="description"
              value={form.description}
              onChange={e => setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))}
              placeholder="Medications with active or anticipated supply shortages."
            />
          </div>
          <div className="flex flex-wrap justify-between gap-2">
            <fieldset className="flex-1">
              <legend className="text-ui-text-primary text-sm font-bold">Color</legend>
              <div className="flex gap-2 flex-wrap mt-1">
                {colors.map(color => (
                  <label key={color} className="cursor-pointer">
                    <input
                      type="radio"
                      name="color"
                      value={color}
                      checked={form.color === color}
                      onChange={e => setForm(prev => ({ ...prev, color: e.target.value }))}
                      className="sr-only"
                    />
                    <span
                      className={`block w-9 h-9 rounded-lg ${form.color === color ? "ring-2 ring-[#461E96]" : ""}`}
                      style={{ backgroundColor: color }}
                    />
                  </label>
                ))}
              </div>
            </fieldset>
            <fieldset className="flex-1">
              <legend className="text-ui-text-primary text-sm font-bold">Icon</legend>
              <div className="flex gap-2 flex-wrap mt-1">
                {Object.entries(icons).map(([key, icon]) => (
                  <label key={key} className="cursor-pointer">
                    <input
                      type="radio"
                      name="icon"
                      value={key}
                      checked={form.icon === key}
                      onChange={e => setForm(prev => ({ ...prev, icon: e.target.value }))}
                      className="sr-only"
                    />
                    <span
                      className={`flex items-center justify-center w-9 h-9 rounded-lg bg-[#F8F9FC] ${form.icon === key ? "ring-2 ring-[#461E96]" : ""}`}
                    >
                      {icon}
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>
          </div>
          <div className="p-4 border border-dashed border-[#E5E7EB] bg-[#F8F9FC]">
            <p className="uppercase text-sm font-semibold text-[#6B7280]">Preview in Global Filter</p>
            <div className="flex justify-between mt-2 rounded-lg p-2 px-3 bg-white border border-[#E5E7EB]">
              <p className="font-semibold text-sm">{form.name.length === 0 ? "Essential List" : form.name}</p>
              <p className="text-xs text-text-secondary">0 medications</p>
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-3 p-4 border-t border-[#E5E7EB] bg-[#F8F9FC] rounded-b-xl">
          <Button type="button" onClick={handleClose} variant="secondary" size="sm" className="text-brand-primary-main">
            Cancel
          </Button>
          <Button type="submit" disabled={!form.name.trim() || create.isPending} variant="default" size="sm">
            Continue & Add medications
          </Button>
        </div>
      </form>
    </ModalShell>
  );
};
