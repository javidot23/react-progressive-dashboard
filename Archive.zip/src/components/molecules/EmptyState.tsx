import { ReactNode } from "react";

interface EmptyStateProps {
  icon?: ReactNode;
  title?: string;
  description?: string;
  action?: ReactNode;
}

export function EmptyState({
  icon,
  title = "No Data Available",
  description = "No data found for the selected filters. Try adjusting your filter criteria to see results.",
  action,
}: EmptyStateProps) {
  const defaultIcon = (
    <svg
      className="w-8 h-8 text-ui-text-muted"
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
      />
    </svg>
  );

  return (
    <div className="text-center py-12">
      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-ui-background-secondary mb-4">
        {icon || defaultIcon}
      </div>
      <h3 className="text-lg font-semibold text-ui-text-primary mb-2">{title}</h3>
      <p className="text-sm text-ui-text-secondary max-w-sm mx-auto mb-4">{description}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
