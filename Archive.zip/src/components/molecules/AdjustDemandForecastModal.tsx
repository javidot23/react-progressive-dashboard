import React, { useState } from "react";
import { getGcnLabel } from "@/lib/gcnLabels";

interface AdjustDemandForecastModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm?: (confirmed: boolean) => void;
  materialName?: string;
  gcn?: string;
  ndc?: string;
  materialStatus?: string;
  plantDetail?: string;
  forecastByDc?: string;
  forecastByNdc?: string;
  currentForecast?: string;
}

export const AdjustDemandForecastModal: React.FC<AdjustDemandForecastModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  materialName = "Acetaminophen 500mg Tablets",
  gcn = "12345",
  ndc = "00000-0000-00",
  materialStatus = "Active",
  plantDetail = "00000-0000-00",
  forecastByDc = "20%",
  forecastByNdc = "20%",
  currentForecast = "2,450 units/week",
}) => {
  const [isConfirmed, setIsConfirmed] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (isConfirmed && onConfirm) {
      onConfirm(true);
    }
    setIsConfirmed(false);
    onClose();
  };

  const handleClose = () => {
    setIsConfirmed(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-10000 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        style={{
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
        onClick={handleClose}
      />

      {/* Modal Card */}
      <div
        className="relative bg-white rounded-lg shadow-xl max-w-2xl w-[90vw] md:w-full mx-4 max-h-[90vh] overflow-y-auto"
        style={{
          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-6 pt-6 pb-4 border-b"
          style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-8 h-8 rounded flex items-center justify-center"
              style={{
                backgroundColor: "var(--color-brand-primary-main, #461E96)",
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="white"
                className="w-5 h-5"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 13l4-4 4 4M3 17l4-4 4 4m5-8l4-4 4 4m-4 4l4 4 4-4" />
              </svg>
            </div>
            <div>
              <h2
                className="font-bold"
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "20px",
                  fontWeight: "700",
                  lineHeight: "28px",
                }}
              >
                Adjust Demand Forecast
              </h2>
              <p
                className="text-sm mt-1"
                style={{
                  color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "400",
                  lineHeight: "20px",
                }}
              >
                Review current forecast details
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
            style={{
              fontSize: "24px",
              lineHeight: "1",
            }}
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="px-6 py-6 space-y-6">
          {/* Product Details */}
          <div>
            <h3
              className="font-semibold mb-4"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "600",
                lineHeight: "24px",
              }}
            >
              Product Details
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  MATERIAL NAME
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {materialName}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  {getGcnLabel()}
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {gcn}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  NDC
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {ndc}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  MATERIAL STATUS
                </div>
                <div>
                  <span
                    className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold"
                    style={{
                      backgroundColor: "#D8FEE7",
                      color: "#119D63",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "12px",
                      fontWeight: "600",
                    }}
                  >
                    {materialStatus}
                  </span>
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  PLANT DETAIL
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {plantDetail}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  FORECAST BY DC
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {forecastByDc}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  FORECAST BY NDC
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {forecastByNdc}
                </div>
              </div>
            </div>
          </div>

          {/* Current Demand Forecast */}
          <div>
            <h3
              className="font-semibold mb-3"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "600",
                lineHeight: "24px",
              }}
            >
              Current Demand Forecast
            </h3>
            <div
              className="p-6 rounded-lg"
              style={{
                backgroundColor: "#E3F2FD",
                border: "1px solid #BBDEFB",
              }}
            >
              <div
                className="font-bold mb-2"
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "28px",
                  fontWeight: "700",
                  lineHeight: "36px",
                }}
              >
                {currentForecast}
              </div>
              <div
                className="text-sm"
                style={{
                  color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "400",
                  lineHeight: "20px",
                }}
              >
                Aggregated across all distribution centers
              </div>
            </div>
          </div>

          {/* Why This Action? */}
          <div>
            <h3
              className="font-semibold mb-3"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "600",
                lineHeight: "24px",
              }}
            >
              Why This Action?
            </h3>
            <div
              className="p-4 rounded-lg"
              style={{
                backgroundColor: "#F3E8FF",
                border: "1px solid #E9D5FF",
              }}
            >
              <p
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "400",
                  lineHeight: "20px",
                }}
              >
                Current demand signals indicate forecast adjustment is needed to prevent potential stockouts and ensure optimal
                inventory levels across the network.
              </p>
            </div>
          </div>

          {/* Action Confirmation */}
          <div>
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={isConfirmed}
                onChange={e => setIsConfirmed(e.target.checked)}
                className="mt-1"
                style={{
                  accentColor: "var(--color-brand-primary-main, #461E96)",
                  width: "20px",
                  height: "20px",
                }}
              />
              <div>
                <div
                  className="font-medium mb-1"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  I will adjust the demand forecast for this material
                </div>
                <div
                  className="text-sm"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "400",
                    lineHeight: "16px",
                  }}
                >
                  Check this box to confirm you'll take action on this recommendation
                </div>
              </div>
            </label>
          </div>
        </div>

        {/* Footer */}
        <div
          className="flex justify-end gap-3 px-6 pb-6 border-t pt-4"
          style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}
        >
          <button
            onClick={handleClose}
            className="px-6 py-2 border rounded-md font-semibold transition-colors hover:bg-gray-50"
            style={{
              borderColor: "var(--cds-color-border-primary, #E0E0E0)",
              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "600",
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={!isConfirmed}
            className="px-6 py-2 rounded-md font-semibold text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              backgroundColor: isConfirmed
                ? "var(--color-brand-primary-main, #461E96)"
                : "var(--Cencora-neutral-expanded-500, #6E6E6E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "600",
            }}
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};
