import { useMemo, useCallback } from "react";
import ActionButton from "@/components/atoms/ActionButton";
import { KeepInMindModal } from "@/components/molecules/KeepInMindModal";
import { DecisionRationaleModal } from "@/components/molecules/DecisionRationaleModal";
import { RemoveActionConfirmModal } from "@/components/molecules/RemoveActionConfirmModal";
import { useAuth } from "@/contexts/AuthContext";
import { useActionFlow, NO_ACTION_TYPE } from "@/hooks/useActionFlow";
import { isMaterialActionOwner } from "@/lib/materialActionOwnership";
import {
  ActionCategory,
  MaterialAction,
  MaterialWithIssues,
  PotentialAction,
} from "@/lib/types";

const ACTION_CATEGORY_ORDER: ActionCategory[] = ["Tactical", "Strategic", "Operational"];

interface ActionTypeItem {
  type: string;
  /** Unique per potential-action row — used for taken/disabled UI. */
  pactionNbr: string | null;
  label: string;
  potentialAction?: PotentialAction;
}

interface ActionCategorySection {
  title?: string;
  items: ActionTypeItem[];
}

interface ActionButtonGroupProps {
  material: MaterialWithIssues;
  size?: "sm" | "md";
  layout?: "row" | "column";
  issueId?: number;
  potentialActions?: PotentialAction[];
  issueNbr?: string;
  vendorId?: number;
  groupByActionCategory?: boolean;
}

function buildRecommendationActionTypes(potentialActions: PotentialAction[]): ActionTypeItem[] {
  return potentialActions.map((pa) => ({
    type: pa.recommendation_type_nbr,
    pactionNbr: pa.paction_nbr,
    label: pa.recommendation,
    potentialAction: pa,
  }));
}

function groupActionTypesByCategory(actionTypes: ActionTypeItem[]): ActionCategorySection[] {
  const known = new Map<ActionCategory, ActionTypeItem[]>();
  const uncategorized: ActionTypeItem[] = [];

  for (const item of actionTypes) {
    const category = item.potentialAction?.action_category?.trim();
    if (category && ACTION_CATEGORY_ORDER.includes(category as ActionCategory)) {
      const key = category as ActionCategory;
      const bucket = known.get(key) ?? [];
      bucket.push(item);
      known.set(key, bucket);
    } else {
      uncategorized.push(item);
    }
  }

  const sections: ActionCategorySection[] = [];
  for (const category of ACTION_CATEGORY_ORDER) {
    const items = known.get(category);
    if (items?.length) {
      sections.push({ title: category, items });
    }
  }
  if (uncategorized.length) {
    sections.push({ items: uncategorized });
  }

  return sections;
}

const ActionButtonGroup: React.FC<ActionButtonGroupProps> = ({
  material,
  size = "md",
  layout = "row",
  issueId,
  potentialActions = [],
  issueNbr,
  vendorId,
  groupByActionCategory = false,
}) => {
  const { user } = useAuth();

  const {
    modalState,
    isSubmittingRationale,
    isActionMutationPending,
    isRemoveMutationPending,
    handleActionClick,
    handleKeepInMindContinue,
    handleDecisionRationaleSubmit,
    handleRemoveClick,
    handleRemoveConfirm,
    closeModal,
  } = useActionFlow({ material, issueId, issueNbr, vendorId });

  const recommendationActionTypes = useMemo(
    () => buildRecommendationActionTypes(potentialActions),
    [potentialActions]
  );

  const noActionType = useMemo<ActionTypeItem>(
    () => ({ type: NO_ACTION_TYPE, pactionNbr: null, label: "No Action Required" }),
    []
  );

  const actionTypes = useMemo(
    () => [...recommendationActionTypes, noActionType],
    [recommendationActionTypes, noActionType]
  );

  const categorySections = useMemo(() => {
    if (!groupByActionCategory) return null;
    return groupActionTypesByCategory(recommendationActionTypes);
  }, [groupByActionCategory, recommendationActionTypes]);

  // Collect and index all actions by unique paction_nbr (not recommendation_type_nbr).
  const { actionsByPaction, selectedPactions, noAction } = useMemo(() => {
    const allActions = material.open_issues?.flatMap((issue) => issue.actions || []) ?? [];
    const byPaction = new Map<string, MaterialAction>();
    const selected = new Set<string>();
    let noActionResult: MaterialAction | undefined;

    for (const action of allActions) {
      if (action.action === "no_action") {
        noActionResult = action;
        selected.add(NO_ACTION_TYPE);
      }
      const pactionNbr = action.potential_action?.paction_nbr;
      if (pactionNbr && !byPaction.has(pactionNbr)) {
        byPaction.set(pactionNbr, action);
        selected.add(pactionNbr);
      }
    }

    return { actionsByPaction: byPaction, selectedPactions: selected, noAction: noActionResult };
  }, [material.open_issues]);

  const getActionForSlot = (slot: string) =>
    slot === NO_ACTION_TYPE ? noAction : actionsByPaction.get(slot);

  const isSelected = useCallback(
    (slot: string) => selectedPactions.has(slot),
    [selectedPactions]
  );

  /** Only the same action row is disabled once taken (no global lock on other actions). */
  const isDisabled = useCallback(
    (slot: string) => isSelected(slot),
    [isSelected]
  );

  const canRemove = (action: MaterialAction) => isMaterialActionOwner(action, user?.entra_id);

  const renderActionItem = ({ type, pactionNbr, label, potentialAction }: ActionTypeItem) => {
    const slot = pactionNbr ?? NO_ACTION_TYPE;
    const action = getActionForSlot(slot);
    const selected = isSelected(slot);
    const showRemove = selected && action && canRemove(action);

    return (
      <div
        key={slot}
        className={
          layout === "column"
            ? "flex flex-col gap-2 sm:flex-row sm:items-center"
            : "flex items-center gap-1"
        }
      >
        <ActionButton
          actionType={type}
          label={label}
          action={action}
          checked={selected}
          disabled={isDisabled(slot)}
          grayed={type !== NO_ACTION_TYPE}
          onChange={(t, checked) => {
            if (checked && !isDisabled(slot)) handleActionClick(t, potentialAction);
          }}
          size={size}
        />
        {showRemove && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleRemoveClick(action);
            }}
            className={`flex items-center gap-2 border-2 rounded px-2 py-1 transition-all duration-200 border-neutral-200 hover:border-brand-primary-main hover:bg-purple-50 cursor-pointer ${
              size === "sm" ? "text-xs" : "text-sm"
            } font-bold text-brand-primary-main`}
            aria-label={`Remove ${label} action`}
          >
            Delete Action
          </button>
        )}
      </div>
    );
  };

  const renderCategoryHeader = (title: string) => (
    <div className="flex items-center gap-2">
      <p className="text-sm text-[#525252] whitespace-nowrap">{title}</p>
      <hr className="flex-1 border-t border-[#E0E0E0]" />
    </div>
  );

  // Early return
  if (!material.open_issues?.length) return null;

  const containerClassName =
    layout === "column"
      ? "flex flex-col gap-3 items-stretch"
      : `flex ${size === "sm" ? "gap-2" : "gap-4"} flex-wrap items-center`;

  return (
    <>
      {groupByActionCategory && categorySections ? (
        <div className="flex flex-col gap-6">
          {categorySections.map((section, index) => (
            <div key={section.title ?? `uncategorized-${index}`} className="flex flex-col gap-3">
              {section.title && renderCategoryHeader(section.title)}
              <div className={containerClassName}>{section.items.map(renderActionItem)}</div>
            </div>
          ))}
          <div className={containerClassName}>{renderActionItem(noActionType)}</div>
        </div>
      ) : (
        <div className={containerClassName}>{actionTypes.map(renderActionItem)}</div>
      )}

      {/* Modals - rendered based on discriminated union state */}
      {modalState.type === "keepInMind" && (
        <KeepInMindModal
          isOpen
          onClose={closeModal}
          onContinue={handleKeepInMindContinue}
          isSubmitting={isActionMutationPending}
        />
      )}

      {modalState.type === "removeConfirm" && (
        <RemoveActionConfirmModal
          isOpen
          onClose={closeModal}
          onConfirm={handleRemoveConfirm}
          actionDetails={modalState.action}
          isSubmitting={isRemoveMutationPending}
        />
      )}

      {modalState.type === "decisionRationale" && (
        <DecisionRationaleModal
          isOpen
          onSubmit={handleDecisionRationaleSubmit}
          isSubmitting={isSubmittingRationale}
          actionType={modalState.actionType}
          actionLabel={modalState.actionLabel}
          materialName={material.name}
          drivingRisk={material.driving_risk}
        />
      )}
    </>
  );
};

export default ActionButtonGroup;
