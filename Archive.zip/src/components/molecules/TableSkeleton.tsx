interface SkeletonColumn {
  width: string; // Tailwind width class like 'w-32', 'w-full', etc.
  type: 'text' | 'progress' | 'custom';
  customContent?: React.ReactNode;
}

interface TableSkeletonProps {
  rows?: number;
  columns: SkeletonColumn[];
  className?: string;
}

export default function TableSkeleton({
  rows = 5,
  columns,
  className = ""
}: TableSkeletonProps) {
  return (
    <>
      {Array.from({ length: rows }, (_, rowIndex) => (
        <tr key={`skeleton-row-${rowIndex}`} className={`border-t ${className}`}>
          {columns.map((column, colIndex) => (
            <td key={`skeleton-col-${colIndex}`} className="px-4 py-2 whitespace-nowrap">
              {column.type === 'text' && (
                <div className={`h-4 bg-gray-200 rounded animate-pulse ${column.width}`}></div>
              )}
              {column.type === 'progress' && (
                <div className="flex items-center gap-3 whitespace-nowrap">
                  <div className={`relative h-2 bg-neutral-100 ${column.width}`}>
                    <div className="absolute top-0 left-0 h-2 bg-gray-200 animate-pulse w-full rounded"></div>
                  </div>
                </div>
              )}
              {column.type === 'custom' && column.customContent}
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}
