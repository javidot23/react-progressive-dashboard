import React from "react";
import { ModalShell } from "@/components/atoms/ModalShell";

/** Optional summary for issue-level (multi-material) actions. */
export interface KeepInMindActionSummary {
  actionLabel?: string;
  actionType?: string;
  /** Materials the action will apply to. */
  appliesToCount: number;
  /** Total impacted materials for the issue. */
  totalCount: number;
  /** Materials excluded (deselected). */
  excludedCount?: number;
  /** Formatted exposure covered by the action, e.g. "$1.2M". */
  exposure?: string;
}

interface KeepInMindModalProps {
  isOpen: boolean;
  onClose: () => void;
  onContinue: () => void;
  actionType?: string | null;
  materialName?: string;
  isSubmitting?: boolean;
  /** When provided, renders an action summary (how many materials will be actioned). */
  summary?: KeepInMindActionSummary;
}

export const KeepInMindModal: React.FC<KeepInMindModalProps> = ({
  isOpen,
  onClose,
  onContinue,
  isSubmitting = false,
  summary,
  // actionType,
  // materialName,
}) => {
  const getActionMessage = () => {
    return (
      <>
        You need to complete this action outside the Stratium platform. This action
        will be logged in the <strong>recent actions</strong> top bar where you
        can export the actions you took for your records.
      </>
    );

    // Don't delete this code, might use later after adding the action taken functionality
    // switch (actionType) {
    //   case "put_item_to_bid":
    //     return `Action taken for ${materialName || "this material"} - Put Item to Bid. You're not able to perform any action on this. You need to complete this action outside the Stratium platform. This action will be logged in the recent actions top bar where you can export the actions you took for your records.`;
    //   case "no_action_required":
    //     return `Action taken for ${materialName || "this material"} - No Action Required. You're not able to perform any action on this.`;
    //   default:
    //     return "Action taken. You're not able to perform any action on this.";
    // }
  };

  return (
    <ModalShell
      isOpen={isOpen}
      onClose={onClose}
      ariaLabelledBy="keep-in-mind-title"
      usePortal
      zIndex={9999999}
      overlayClassName="fixed inset-0 flex items-center justify-center"
      className="bg-white rounded-md shadow-lg mx-4 overflow-hidden w-[512px]"
    >
      <div className="flex justify-between items-center px-6 h-[56px] border-b border-gray-300 bg-white">
        <h2 id="keep-in-mind-title" className="text-lg font-semibold text-ui-text-primary">
          Keep In Mind
        </h2>
        <button
          type="button"
          onClick={onClose}
          className="text-ui-text-muted hover:text-ui-text-secondary text-2xl font-light"
          aria-label="Close Keep In Mind dialog"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={1.5}
            stroke="currentColor"
            className="size-6"
            aria-hidden
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M6 18 18 6M6 6l12 12"
            />
          </svg>
        </button>
      </div>

      {summary && (
        <div className="px-6 py-4 border-b border-gray-300 bg-background-secondary">
          <dl className="grid grid-cols-1 gap-y-2 text-sm">
            {summary.actionLabel && (
              <div className="flex justify-between gap-4">
                <dt className="text-ui-text-secondary">Action</dt>
                <dd className="font-semibold text-ui-text-primary text-right">{summary.actionLabel}</dd>
              </div>
            )}
            {summary.actionType && (
              <div className="flex justify-between gap-4">
                <dt className="text-ui-text-secondary">Action type</dt>
                <dd className="font-semibold text-ui-text-primary text-right">{summary.actionType}</dd>
              </div>
            )}
            <div className="flex justify-between gap-4">
              <dt className="text-ui-text-secondary">Applies to</dt>
              <dd className="font-semibold text-ui-text-primary text-right">
                {summary.appliesToCount} of {summary.totalCount} material{summary.totalCount === 1 ? "" : "s"}
                {summary.excludedCount ? (
                  <span className="text-[#C2551F]"> · {summary.excludedCount} excluded</span>
                ) : null}
              </dd>
            </div>
            {summary.exposure && (
              <div className="flex justify-between gap-4">
                <dt className="text-ui-text-secondary">Exposure covered</dt>
                <dd className="font-semibold text-ui-text-primary text-right">{summary.exposure}</dd>
              </div>
            )}
          </dl>
        </div>
      )}

      <div className="px-6 flex items-center min-h-[92px] py-4 border-b border-gray-300 bg-white">
        <p className="text-body-sm-font-family font-medium text-sm text-ui-text-primary">
          {getActionMessage()}
        </p>
      </div>

      <div className="flex justify-end items-center gap-2 px-6 h-[56px] bg-background-secondary">
        <button
          type="button"
          onClick={onClose}
          disabled={isSubmitting}
          className="px-4 py-2 border border-gray-300 text-ui-text-primary rounded-md hover:bg-gray-100 font-medium transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={onContinue}
          disabled={isSubmitting}
          className="px-4 py-2 bg-interactive-primary text-white rounded-md hover:bg-brand-main-800 font-medium transition-colors focus:outline-hidden focus:ring-2 focus:ring-brand-primary-main focus:ring-offset-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? "Submitting..." : "Continue"}
        </button>
      </div>
    </ModalShell>
  );
};
