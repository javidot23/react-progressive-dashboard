import { Card, CardContent, CardHeader } from "@/components/atoms/Card";

export function StatCardSkeleton() {
  return (
    <Card className="shadow-xs rounded-md" style={{ minHeight: "165px" }}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 pt-4 px-4" style={{ paddingTop: "24px" }}>
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className="flex items-center justify-center h-[35px] w-[35px] rounded bg-gray-200 animate-pulse shrink-0" />
          <div
            className="bg-gray-200 rounded animate-pulse"
            style={{
              width: "80px",
              height: "28px",
              fontFamily: "var(--text-heading-2xl-font-family, Cencora-Gilroy)",
              fontSize: "var(--text-heading-2xl-font-size, 24px)",
              lineHeight: "var(--text-heading-2xl-line-height, 28px)",
            }}
          />
        </div>
        <div
          className="bg-gray-200 rounded animate-pulse shrink ml-4 min-w-0"
          style={{ width: "120px", height: "50px", maxWidth: "120px" }}
        />
      </CardHeader>
      <CardContent className="pt-2 pb-4 px-4">
        <p className="text-sm text-transparent mb-2">
          <span className="inline-block w-32 h-[20px] bg-gray-200 rounded animate-pulse align-middle" />
        </p>
        <div className="text-xs flex items-center" style={{ minHeight: "18px" }}>
          <div className="h-3 w-3 bg-gray-200 rounded-full animate-pulse mr-1 shrink-0" />
          <span className="inline-block w-24 h-[18px] bg-gray-200 rounded animate-pulse" />
        </div>
      </CardContent>
    </Card>
  );
}
