import React, { useState } from "react";
import { getGcnLabel } from "@/lib/gcnLabels";

interface DistributionCenter {
  id: string;
  name: string;
  forecast: number;
  daysOnHand: number;
  onHandQty: number;
  onOrderQty: number;
  status: "Critical/Overstock" | "Warning" | "Healthy" | "Critical Low" | "Low" | "Overstock";
}

interface RebalanceInventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm?: (confirmed: boolean) => void;
  materialName?: string;
  gcn?: string;
  ndc?: string;
  numberOfDCs?: number;
  totalOnHand?: number;
  totalOnOrder?: number;
  avgDaysOnHand?: number;
  overstockCount?: number;
  lowStockCount?: number;
  distributionCenters?: DistributionCenter[];
}

export const RebalanceInventoryModal: React.FC<RebalanceInventoryModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  materialName = "Acetaminophen 500mg Tablets",
  gcn = "12345",
  ndc = "00000-0000-00",
  numberOfDCs = 8,
  totalOnHand = 21385,
  totalOnOrder = 4200,
  avgDaysOnHand = 21,
  overstockCount = 3,
  lowStockCount = 3,
  distributionCenters,
}) => {
  const [isConfirmed, setIsConfirmed] = useState(false);

  // Default distribution centers if none provided
  const defaultDistributionCenters: DistributionCenter[] = [
    {
      id: "DC-14",
      name: "Atlanta Distribution Center",
      forecast: 450,
      daysOnHand: 42,
      onHandQty: 5600,
      onOrderQty: 800,
      status: "Overstock",
    },
    {
      id: "DC-08",
      name: "Dallas Distribution Center",
      forecast: 520,
      daysOnHand: 35,
      onHandQty: 4800,
      onOrderQty: 1200,
      status: "Overstock",
    },
    {
      id: "DC-23",
      name: "Phoenix Distribution Center",
      forecast: 380,
      daysOnHand: 3,
      onHandQty: 450,
      onOrderQty: 200,
      status: "Critical Low",
    },
    {
      id: "DC-11",
      name: "Chicago Distribution Center",
      forecast: 620,
      daysOnHand: 8,
      onHandQty: 1650,
      onOrderQty: 500,
      status: "Low",
    },
    {
      id: "DC-05",
      name: "Seattle Distribution Center",
      forecast: 290,
      daysOnHand: 18,
      onHandQty: 1740,
      onOrderQty: 300,
      status: "Healthy",
    },
  ];

  const centers = distributionCenters || defaultDistributionCenters;

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (isConfirmed && onConfirm) {
      onConfirm(true);
    }
    setIsConfirmed(false);
    onClose();
  };

  const handleClose = () => {
    setIsConfirmed(false);
    onClose();
  };

  const formatNumber = (num: number): string => {
    return num.toLocaleString();
  };

  const getStatusColor = (status: DistributionCenter["status"]): string => {
    switch (status) {
      case "Critical/Overstock":
      case "Overstock":
      case "Critical Low":
        return "#FCE7F3"; // Pink
      case "Warning":
      case "Low":
        return "#FEF3C7"; // Yellow
      case "Healthy":
        return "#D8FEE7"; // Green
      default:
        return "#F5F5F5";
    }
  };

  const getStatusTextColor = (status: DistributionCenter["status"]): string => {
    switch (status) {
      case "Critical/Overstock":
      case "Overstock":
      case "Critical Low":
        return "#DC2626"; // Red
      case "Warning":
      case "Low":
        return "#D97706"; // Orange
      case "Healthy":
        return "#119D63"; // Green
      default:
        return "#6E6E6E";
    }
  };

  const getStatusIcon = (status: DistributionCenter["status"]) => {
    if (status === "Overstock" || status === "Critical/Overstock") {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2}
          stroke="currentColor"
          className="w-4 h-4"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 15.75l7.5-7.5 7.5 7.5" />
        </svg>
      );
    }
    if (status === "Low" || status === "Critical Low") {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2}
          stroke="currentColor"
          className="w-4 h-4"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
        </svg>
      );
    }
    if (status === "Healthy") {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2}
          stroke="currentColor"
          className="w-4 h-4"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
        </svg>
      );
    }
    return null;
  };

  return (
    <div className="fixed inset-0 z-10000 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        style={{
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
        onClick={handleClose}
      />

      {/* Modal Card */}
      <div
        className="relative bg-white rounded-lg shadow-xl max-w-6xl w-[90vw] md:w-full mx-4 max-h-[90vh] overflow-y-auto"
        style={{
          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b" style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}>
          <div className="flex items-center gap-3">
            <div
              className="w-8 h-8 rounded flex items-center justify-center"
              style={{
                backgroundColor: "var(--color-brand-primary-main, #461E96)",
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="white"
                className="w-5 h-5"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M3.75 3v11.25A2.25 2.25 0 006 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0118 16.5h-2.25m-7.5 0h7.5m-7.5 0l-1 3m8.5-3l1 3m0 0l.5 1.5m-.5-1.5h-9.5m0 0l-.5 1.5M9 11.25v1.5M12 9v3.75m3-3.75v3.75m-3 .75h.008v.008H12v-.008z"
                />
              </svg>
            </div>
            <div>
              <h2
                className="font-bold"
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "20px",
                  fontWeight: "700",
                  lineHeight: "28px",
                }}
              >
                Rebalance Inventory
              </h2>
              <p
                className="text-sm mt-1"
                style={{
                  color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "400",
                  lineHeight: "20px",
                }}
              >
                Review inventory distribution across all distribution centers
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
            style={{
              fontSize: "24px",
              lineHeight: "1",
            }}
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="px-6 py-6 space-y-6">
          {/* Product Details */}
          <div>
            <h3
              className="font-semibold mb-4"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "600",
                lineHeight: "24px",
              }}
            >
              Product Details
            </h3>
            <div className="grid grid-cols-4 gap-4 mb-4">
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  MATERIAL NAME
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {materialName}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  {getGcnLabel()}
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {gcn}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  NDC
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {ndc}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  NUMBER OF DCS
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {numberOfDCs} Distribution Centers
                </div>
              </div>
            </div>

            {/* Key Metrics Cards */}
            <div className="grid grid-cols-4 gap-4">
              {/* Total On-Hand */}
              <div
                className="p-4 rounded-lg"
                style={{
                  backgroundColor: "#E3F2FD",
                  border: "1px solid #BBDEFB",
                }}
              >
                <div
                  className="text-xs mb-2"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  TOTAL ON-HAND
                </div>
                <div
                  className="font-bold"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "24px",
                    fontWeight: "700",
                    lineHeight: "32px",
                  }}
                >
                  {formatNumber(totalOnHand)}
                </div>
              </div>

              {/* Total On-Order */}
              <div
                className="p-4 rounded-lg"
                style={{
                  backgroundColor: "#F3E8FF",
                  border: "1px solid #E9D5FF",
                }}
              >
                <div
                  className="text-xs mb-2"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  TOTAL ON-ORDER
                </div>
                <div
                  className="font-bold"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "24px",
                    fontWeight: "700",
                    lineHeight: "32px",
                  }}
                >
                  {formatNumber(totalOnOrder)}
                </div>
              </div>

              {/* Avg Days On Hand */}
              <div
                className="p-4 rounded-lg"
                style={{
                  backgroundColor: "#E8F5E9",
                  border: "1px solid #C8E6C9",
                }}
              >
                <div
                  className="text-xs mb-2"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  AVG DAYS ON HAND
                </div>
                <div
                  className="font-bold"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "24px",
                    fontWeight: "700",
                    lineHeight: "32px",
                  }}
                >
                  {avgDaysOnHand} days
                </div>
              </div>

              {/* Imbalance Alert */}
              <div
                className="p-4 rounded-lg"
                style={{
                  backgroundColor: "#FEF3C7",
                  border: "1px solid #FDE68A",
                }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                    className="w-5 h-5"
                    style={{
                      color: "#D97706",
                    }}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
                    />
                  </svg>
                  <div
                    className="text-xs font-semibold"
                    style={{
                      color: "#D97706",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "12px",
                      fontWeight: "600",
                      lineHeight: "16px",
                      textTransform: "uppercase",
                    }}
                  >
                    IMBALANCE ALERT
                  </div>
                </div>
                <div
                  className="font-bold"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "700",
                    lineHeight: "20px",
                  }}
                >
                  {overstockCount} Overstock
                </div>
                <div
                  className="font-bold"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "700",
                    lineHeight: "20px",
                  }}
                >
                  {lowStockCount} Low Stock
                </div>
              </div>
            </div>
          </div>

          {/* AI-Powered Recommendations */}
          <div>
            <h3
              className="font-semibold mb-3"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "600",
                lineHeight: "24px",
              }}
            >
              AI-Powered Recommendations (Coming in V1)
            </h3>
            <div
              className="p-4 rounded-lg"
              style={{
                backgroundColor: "#F5F5F5",
                border: "1px solid #E0E0E0",
              }}
            >
              <p
                className="mb-4"
                style={{
                  color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "400",
                  lineHeight: "20px",
                }}
              >
                Future releases will provide specific transfer recommendations based on inventory optimization algorithms.
              </p>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                    className="w-5 h-5 shrink-0 mt-0.5"
                    style={{
                      color: "var(--color-brand-primary-main, #461E96)",
                    }}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                    />
                  </svg>
                  <div>
                    <div
                      className="font-semibold mb-1"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      Transfer 2,000 units from DC-14 (Atlanta) → DC-23 (Phoenix)
                    </div>
                    <div
                      className="text-sm"
                      style={{
                        color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "12px",
                        fontWeight: "400",
                        lineHeight: "16px",
                      }}
                    >
                      <em>Impact:</em> Reduces overstock by 15 days, prevents stockout in Phoenix.
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                    className="w-5 h-5 shrink-0 mt-0.5"
                    style={{
                      color: "var(--color-brand-primary-main, #461E96)",
                    }}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                    />
                  </svg>
                  <div>
                    <div
                      className="font-semibold mb-1"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      Transfer 800 units from DC-32 (Denver) → DC-11 (Chicago)
                    </div>
                    <div
                      className="text-sm"
                      style={{
                        color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "12px",
                        fontWeight: "400",
                        lineHeight: "16px",
                      }}
                    >
                      <em>Impact:</em> Optimizes network coverage, improves days on hand balance.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Distribution Center Inventory Levels */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3
                className="font-semibold"
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "16px",
                  fontWeight: "600",
                  lineHeight: "24px",
                }}
              >
                Distribution Center Inventory Levels
              </h3>
              {/* Status Legend */}
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: "#FCE7F3" }}></div>
                  <span
                    className="text-xs"
                    style={{
                      color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "12px",
                      fontWeight: "400",
                    }}
                  >
                    Critical/Overstock
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: "#FEF3C7" }}></div>
                  <span
                    className="text-xs"
                    style={{
                      color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "12px",
                      fontWeight: "400",
                    }}
                  >
                    Warning
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: "#D8FEE7" }}></div>
                  <span
                    className="text-xs"
                    style={{
                      color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "12px",
                      fontWeight: "400",
                    }}
                  >
                    Healthy
                  </span>
                </div>
              </div>
            </div>
            <div className="overflow-x-auto border rounded-lg" style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}>
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ backgroundColor: "var(--cds-color-background-secondary, #F5F5F5)" }}>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      DISTRIBUTION CENTER
                    </th>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      FORECAST
                    </th>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      DAYS ON HAND
                    </th>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      ON-HAND QTY
                    </th>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      ON-ORDER QTY
                    </th>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      STATUS
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {centers.map((center, index) => (
                    <tr
                      key={index}
                      className="border-t"
                      style={{
                        borderColor: "var(--cds-color-border-primary, #E0E0E0)",
                        backgroundColor: getStatusColor(center.status),
                      }}
                    >
                      <td className="px-4 py-3">
                        <div
                          className="font-medium"
                          style={{
                            color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                            fontFamily: "Cencora-Gilroy",
                            fontSize: "14px",
                            fontWeight: "500",
                            lineHeight: "20px",
                          }}
                        >
                          {center.id} ({center.name})
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div
                          className="font-medium"
                          style={{
                            color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                            fontFamily: "Cencora-Gilroy",
                            fontSize: "14px",
                            fontWeight: "500",
                            lineHeight: "20px",
                          }}
                        >
                          {formatNumber(center.forecast)}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div
                          className="font-medium"
                          style={{
                            color: "#DC2626",
                            fontFamily: "Cencora-Gilroy",
                            fontSize: "14px",
                            fontWeight: "500",
                            lineHeight: "20px",
                          }}
                        >
                          {center.daysOnHand} days
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth={2}
                            stroke="currentColor"
                            className="w-4 h-4"
                            style={{
                              color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                            }}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.75 7.5h16.5m-16.5 0a1.5 1.5 0 00-1.5 1.5v12a1.5 1.5 0 001.5 1.5h16.5a1.5 1.5 0 001.5-1.5V9a1.5 1.5 0 00-1.5-1.5"
                            />
                          </svg>
                          <div
                            className="font-medium"
                            style={{
                              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                              fontFamily: "Cencora-Gilroy",
                              fontSize: "14px",
                              fontWeight: "500",
                              lineHeight: "20px",
                            }}
                          >
                            {formatNumber(center.onHandQty)}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div
                          className="font-medium"
                          style={{
                            color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                            fontFamily: "Cencora-Gilroy",
                            fontSize: "14px",
                            fontWeight: "500",
                            lineHeight: "20px",
                          }}
                        >
                          {formatNumber(center.onOrderQty)}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <span
                            className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold"
                            style={{
                              backgroundColor: getStatusColor(center.status),
                              color: getStatusTextColor(center.status),
                              fontFamily: "Cencora-Gilroy",
                              fontSize: "12px",
                              fontWeight: "600",
                            }}
                          >
                            {getStatusIcon(center.status)}
                            {center.status}
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Action Confirmation */}
          <div>
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={isConfirmed}
                onChange={(e) => setIsConfirmed(e.target.checked)}
                className="mt-1"
                style={{
                  accentColor: "var(--color-brand-primary-main, #461E96)",
                  width: "20px",
                  height: "20px",
                }}
              />
              <div>
                <div
                  className="font-medium mb-1"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  I will rebalance inventory for this material
                </div>
                <div
                  className="text-sm"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "400",
                    lineHeight: "16px",
                  }}
                >
                  Check this box to confirm you'll take action on this recommendation
                </div>
              </div>
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 px-6 pb-6 border-t pt-4" style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}>
          <button
            onClick={handleClose}
            className="px-6 py-2 border rounded-md font-semibold transition-colors hover:bg-gray-50"
            style={{
              borderColor: "var(--cds-color-border-primary, #E0E0E0)",
              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "600",
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={!isConfirmed}
            className="px-6 py-2 rounded-md font-semibold text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              backgroundColor: isConfirmed
                ? "var(--color-brand-primary-main, #461E96)"
                : "var(--Cencora-neutral-expanded-500, #6E6E6E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "600",
            }}
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};
