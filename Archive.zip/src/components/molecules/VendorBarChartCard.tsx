import { FC } from "react";

interface Vendor {
  id: number;
  name?: string;
  risk_rating?: number;
}

interface Props {
  vendor: Vendor;
  color?: string;
  fullWidth?: boolean;
}

const VendorBarChartCard: FC<Props> = ({ vendor, color, fullWidth = false }) => {
  const risk = +(vendor.risk_rating ?? 0);
  const riskPercent = Math.min(risk * 100, 100);

  return (
    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
      <div
        className="h-full rounded-full"
        style={{
          width: fullWidth ? "100%" : `${riskPercent}%`,
          backgroundColor: color || "#461E96",
        }}
      />
    </div>
  );
};

export default VendorBarChartCard;
