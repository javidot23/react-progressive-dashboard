import { useId, useMemo, useRef, useState, type ReactNode } from "react";
import { Area, AreaChart, Line, ResponsiveContainer, YAxis } from "recharts";
import { AccessibleChart } from "@/components/atoms/AccessibleChart";

export type SparkYDomain = [number, number];

export type SparkTooltipState = {
  index: number;
  value: number;
  anchorX?: number;
};

export interface SparkAreaLineChartProps {
  data: number[];
  xLabels?: string[];
  height?: number;
  color?: string;
  strokeColor?: string;
  valueFormatter?: (value: number) => string;
  computeYDomain: (min: number, max: number) => SparkYDomain;
  renderTooltip: (ctx: {
    labels: string[];
    tooltip: SparkTooltipState;
    tooltipPosition: { x: number; y: number };
    containerRef: React.RefObject<HTMLDivElement | null>;
    valueFormatter: (value: number) => string;
  }) => ReactNode;
  /** When true, sets anchorX to bucket center for above-chart tooltips */
  anchorTooltipToBucket?: boolean;
  className?: string;
  emptyPlaceholder?: ReactNode;
  /** Screen-reader description of the sparkline (P6.2). */
  ariaLabel?: string;
}

const defaultValueFormatter = (value: number) => value.toString();

export default function SparkAreaLineChart({
  data,
  xLabels,
  height = 50,
  color = "#461E96",
  strokeColor,
  valueFormatter = defaultValueFormatter,
  computeYDomain,
  renderTooltip,
  anchorTooltipToBucket = false,
  className = "relative",
  emptyPlaceholder,
  ariaLabel = "Trend sparkline chart",
}: SparkAreaLineChartProps) {
  const uid = useId().replace(/:/g, "");
  const gradientId = `spark-gradient-${uid}`;
  const lineColor = strokeColor ?? color;
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const [tooltip, setTooltip] = useState<SparkTooltipState | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });

  const labels = useMemo(() => {
    if (xLabels && xLabels.length === data.length) return xLabels;
    return data.map((_, index) => {
      const date = new Date();
      date.setDate(date.getDate() - (data.length - 1 - index));
      return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    });
  }, [data, xLabels]);

  const chartRows = useMemo(() => data.map((value, index) => ({ index, value, label: labels[index] })), [data, labels]);

  const yDomain = useMemo(() => {
    if (data.length === 0) return [0, 1] as SparkYDomain;
    const min = Math.min(...data);
    const max = Math.max(...data);
    return computeYDomain(min, max);
  }, [data, computeYDomain]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!chartContainerRef.current || data.length === 0) return;

    const rect = chartContainerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setTooltipPosition({ x, y });

    const pointWidth = rect.width / data.length;
    const dataIndex = Math.min(Math.max(0, Math.floor(x / pointWidth)), data.length - 1);

    if (dataIndex >= 0 && dataIndex < data.length) {
      setTooltip({
        index: dataIndex,
        value: data[dataIndex],
        anchorX: anchorTooltipToBucket ? (dataIndex + 0.5) * pointWidth : undefined,
      });
    }
  };

  const handleMouseLeave = () => setTooltip(null);

  if (data.length === 0) {
    return emptyPlaceholder ?? null;
  }

  return (
    <AccessibleChart ariaLabel={ariaLabel} className={className}>
      <div
        ref={chartContainerRef}
        className="relative h-full w-full"
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
      >
        <svg width="0" height="0" aria-hidden>
          <defs>
            <linearGradient id={gradientId} x1="0%" y1="0%" x2="0%" y2="130%">
              <stop offset="0%" stopColor={color} stopOpacity={0.62} />
              <stop offset="100%" stopColor="rgba(255, 255, 255, 0)" />
            </linearGradient>
          </defs>
        </svg>
        <ResponsiveContainer width="100%" height={height}>
          <AreaChart data={chartRows} margin={{ top: 12, right: 0, bottom: 7, left: 0 }}>
            <YAxis hide domain={yDomain} />
            <Area type="monotone" dataKey="value" stroke="none" fill={`url(#${gradientId})`} isAnimationActive={false} />
            <Line
              type="monotone"
              dataKey="value"
              stroke={lineColor}
              strokeWidth={3}
              dot={false}
              activeDot={{ r: 4, fill: lineColor, stroke: lineColor }}
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
        {tooltip &&
          renderTooltip({
            labels,
            tooltip,
            tooltipPosition,
            containerRef: chartContainerRef,
            valueFormatter,
          })}
      </div>
    </AccessibleChart>
  );
}
