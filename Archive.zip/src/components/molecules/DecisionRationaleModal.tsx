import React, { useState, useEffect } from "react";
import { ModalShell } from "@/components/atoms/ModalShell";

interface DecisionRationaleModalProps {
  isOpen: boolean;
  onSubmit: (data: { time_to_complete: string; decision_rationale: string }) => Promise<void>;
  isSubmitting?: boolean;
  actionType?: string;
  actionLabel?: string;
  materialName?: string;
  drivingRisk?: string;
}

const TIME_OPTIONS = [
  { value: "less_than_1_hour", label: "< 1 hour", icon: "lightning" },
  { value: "1_2_hours", label: "1-2 hours", icon: "clock", default: true },
  { value: "2_plus_hours", label: "2+ hours", icon: "clock" },
];

const DECISION_RATIONALE_OPTIONS = [
  { value: "standard_business_process", label: "This aligns with our standard business process" },
  { value: "best_mitigates_risk", label: "Best mitigates the identified risk" },
  { value: "validated_by_team", label: "Validated by team/stakeholder" },
  { value: "other", label: "Other (please specify below)" },
];

const NO_ACTION_RATIONALE_OPTIONS = [
  { value: "risk_assessment_incorrect", label: "The risk assessment is incorrect or overstated" },
  { value: "timing_not_urgent", label: "The risk exists but timing is not urgent" },
  { value: "business_process_handles", label: "Our business process handles this differently" },
  { value: "already_addressed", label: "Already addressed through alternative means" },
  { value: "other", label: "Other (please explain below - required)" },
];

const LightningIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.5}
    stroke="currentColor"
    className={className}
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
  </svg>
);

const ClockIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.5}
    stroke="currentColor"
    className={className}
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const CheckIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={2}
    stroke="currentColor"
    className={className}
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
  </svg>
);

export const DecisionRationaleModal: React.FC<DecisionRationaleModalProps> = ({
  isOpen,
  onSubmit,
  isSubmitting = false,
  actionType,
  actionLabel,
  materialName,
  drivingRisk,
}) => {
  const isNoActionRequired = actionType === "no_action_required";
  const defaultTimeOption = TIME_OPTIONS.find(opt => opt.default)?.value || TIME_OPTIONS[1].value;
  const defaultNoActionRationale = "business_process_handles";

  const [timeToTakeAction, setTimeToTakeAction] = useState<string>(defaultTimeOption);
  const [decisionRationale, setDecisionRationale] = useState<string>(
    isNoActionRequired ? defaultNoActionRationale : "standard_business_process"
  );
  const [otherRationale, setOtherRationale] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [isSubmittingLocal, setIsSubmittingLocal] = useState<boolean>(false);

  // Reset state when modal opens or action type changes
  useEffect(() => {
    if (isOpen) {
      setDecisionRationale(isNoActionRequired ? defaultNoActionRationale : "standard_business_process");
      setTimeToTakeAction(defaultTimeOption);
      setOtherRationale("");
      setError("");
      setIsSubmittingLocal(false);
    }
  }, [isOpen, isNoActionRequired, defaultTimeOption, defaultNoActionRationale]);

  // Reset local submitting state when parent isSubmitting changes to false (after completion)
  useEffect(() => {
    if (!isSubmitting) {
      setIsSubmittingLocal(false);
    }
  }, [isSubmitting]);

  const getConfirmationMessage = () => {
    if (isNoActionRequired) {
      const material = materialName || "[Material Name]";
      const risk = drivingRisk || "Operational Risk";
      return `You've indicated that no action is required for ${material} which has been flagged with an ${risk}. To help us improve our risk models and recommendations, please tell us why you're choosing not to take action.`;
    }

    // Get action label for message matching
    const label = actionLabel || "";

    // Switch Manufacturer
    if (label === "Switch Manufacturer" || actionType === "31") {
      return 'You have taken the recommended action: "Switch Manufacturer."\n\nThis action has been logged in the Recent Actions bar for your records.';
    }

    // Put Item to Bid
    if (label === "Put Item to Bid") {
      return 'You have taken the recommended action: "Put Item to Bid."\n\nThis action has been logged and is available in the Recent Actions bar for review and export.';
    }

    // Manage Supply & Inventory (Allocate)
    if (label === "Manage Supply & Inventory (Allocate)" || label === "Manage supply and inv. (i.e. Allocate)") {
      return 'You have taken the recommended action: "Manage Supply and Inventory (Allocate)."\n\nThis action has been logged in the Recent Actions bar and can be exported for your records.';
    }

    // Return empty string for other actions - only show messages for the three specified actions
    return "";
  };

  const confirmationMessage = getConfirmationMessage();

  const getRationaleOptions = () => {
    return isNoActionRequired ? NO_ACTION_RATIONALE_OPTIONS : DECISION_RATIONALE_OPTIONS;
  };

  const handleSubmit = async () => {
    // Prevent double submission
    if (isSubmitting || isSubmittingLocal) {
      return;
    }

    if (decisionRationale === "other" && !otherRationale.trim()) {
      setError(isNoActionRequired ? "Please explain your decision rationale" : "Please specify your decision rationale");
      return;
    }

    setError("");
    // Disable button immediately on click
    setIsSubmittingLocal(true);

    try {
      const options = getRationaleOptions();
      const rationaleText =
        decisionRationale === "other" ? otherRationale.trim() : options.find(opt => opt.value === decisionRationale)?.label || "";

      await onSubmit({
        time_to_complete: isNoActionRequired ? "" : getTimeOptionValue(timeToTakeAction),
        decision_rationale: rationaleText,
      });
      // Reset form on success
      setTimeToTakeAction(defaultTimeOption);
      setDecisionRationale(isNoActionRequired ? defaultNoActionRationale : "standard_business_process");
      setOtherRationale("");
      setError("");
      setIsSubmittingLocal(false);
    } catch (err) {
      setError("Failed to submit. Please try again.");
      // Re-enable button on error so user can retry
      setIsSubmittingLocal(false);
    }
  };

  const getTimeOptionValue = (value: string): string => {
    // Map UI values to API values
    const mapping: Record<string, string> = {
      less_than_1_hour: "less_than_1_hour",
      "1_2_hours": "1_2_hours",
      "2_plus_hours": "2_plus_hours",
    };
    return mapping[value] || value;
  };

  return (
    <ModalShell
      isOpen={isOpen}
      onClose={() => {}}
      ariaLabelledBy="decision-rationale-modal-title"
      closeOnEscape={false}
      usePortal
      zIndex={9999999}
      overlayClassName="fixed inset-0 flex items-center justify-center"
      className="bg-white rounded-md shadow-lg mx-4 overflow-hidden w-147.25 max-h-[90vh] flex flex-col"
    >
      <div className="flex items-center px-6 h-[56px] border-b border-gray-300 bg-white">
        <h2 id="decision-rationale-modal-title" className="text-lg font-semibold text-ui-text-primary">
          Action Completed
        </h2>
      </div>

      <div className="px-6 py-4 flex-1 overflow-y-auto">
        <div className="space-y-6">
          {/* Confirmation Message - Only show if there's a message */}
          {confirmationMessage && (
            <div>
              <p className="text-sm text-ui-text-primary whitespace-pre-line">{confirmationMessage}</p>
            </div>
          )}

          {/* Time to Make Decision Section - Only show for non-"No Action Required" */}
          {!isNoActionRequired && (
            <div>
              <div className="flex flex-row items-center space-x-1">
                <p className="text-sm font-bold text-ui-text-primary">How much time did it take you to make this decision?</p>
                {/* <p className="text-gray-500 text-xs">(optional)</p> */}
              </div>
              <p className="text-sm text-ui-text-primary mt-1 mb-2">
                This helps us understand the operational burden of each action
              </p>
              <div className="flex gap-3 mb-2">
                {TIME_OPTIONS.map(option => {
                  const isSelected = timeToTakeAction === option.value;
                  return (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => setTimeToTakeAction(option.value)}
                      disabled={isSubmitting || isSubmittingLocal}
                      className={`flex-1 flex flex-col items-center justify-center p-4 border-2 rounded-[8px] transition-colors relative ${
                        isSelected
                          ? "border-[#593AB1] bg-[#EEEDFE] text-[#593AB1]"
                          : "border-gray-300 bg-[#F1F5F9] text-[#1E293B] hover:border-gray-400"
                      } disabled:opacity-50 disabled:cursor-not-allowed`}
                    >
                      {isSelected && (
                        <div className="absolute top-2 right-2">
                          <CheckIcon className="w-5 h-5 text-white bg-[#461E96] rounded-full p-1" />
                        </div>
                      )}
                      <div className="mb-2">
                        {option.icon === "lightning" ? (
                          <LightningIcon className={`w-5 h-5 ${isSelected ? "text-[#461E96]" : "text-[#1E293B]"}`} />
                        ) : (
                          <ClockIcon className={`w-5 h-5 ${isSelected ? "text-[#461E96]" : "text-[#1E293B]"}`} />
                        )}
                      </div>
                      <span className="text-sm font-bold">{option.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Decision Rationale Section */}
          <div>
            <p className="text-sm font-bold text-ui-text-primary mb-2">
              Please share your decision rationale<span className="text-red-500">*</span>
            </p>
            <p className="text-sm text-ui-text-primary mb-3">
              {isNoActionRequired
                ? "Understanding your reasoning helps us refine our risk assessment models"
                : "Your feedback helps us improve recommendations for future scenarios"}
            </p>
            <div className="space-y-2">
              {getRationaleOptions().map(option => {
                const isSelected = decisionRationale === option.value;
                return (
                  <div
                    key={option.value}
                    className={`border  border-[#E5E5E7] px-4 py-3 rounded-[8px] flex flex-row items-center transition-colors
        ${isSelected ? "bg-[#F0EDFC] border-[#5E3FB7]" : "bg-white"}
      `}
                  >
                    <label className="flex items-center cursor-pointer w-full">
                      <input
                        type="radio"
                        name="decisionRationale"
                        value={option.value}
                        checked={isSelected}
                        onChange={e => {
                          setDecisionRationale(e.target.value);
                          if (error) setError("");
                        }}
                        disabled={isSubmitting || isSubmittingLocal}
                        className=" mr-3 w-4 h-4 accent-[#5E3FB7] focus:ring-[#5E3FB7] disabled:opacity-50 disabled:cursor-not-allowed"
                      />
                      <span className="text-sm text-ui-text-primary">{option.label}</span>
                    </label>
                  </div>
                );
              })}
            </div>
            {decisionRationale === "other" && (
              <div className="mt-3">
                <textarea
                  value={otherRationale}
                  onChange={e => {
                    setOtherRationale(e.target.value);
                    if (error) setError("");
                  }}
                  disabled={isSubmitting || isSubmittingLocal}
                  rows={3}
                  placeholder="Please specify..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-brand-primary-main focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed resize-none"
                />
              </div>
            )}
            {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
          </div>
        </div>
      </div>

      <div className="flex justify-end items-center px-6 h-[56px] bg-background-secondary border-t border-gray-300">
        <button
          onClick={handleSubmit}
          disabled={isSubmitting || isSubmittingLocal || (decisionRationale === "other" && !otherRationale.trim())}
          className="px-4 py-2 bg-interactive-primary text-white rounded-md hover:bg-brand-main-800 font-medium transition-colors focus:outline-hidden focus:ring-2 focus:ring-brand-primary-main focus:ring-offset-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting || isSubmittingLocal ? "Submitting..." : "Continue"}
        </button>
      </div>
    </ModalShell>
  );
};
