import React from "react";
import { VendorRawData } from "@/lib/vendorUtils";
import { VendorDetail } from "@/lib/apiServices";
import VendorLineChart from "@/components/molecules/VendorLineChart";
import { useRiskModelDescriptions } from "@/hooks";

interface VendorDetailCardsProps {
  vendorData: VendorRawData | VendorDetail;
  averageServiceLevel: number;
  serviceLevels: any[];
  className?: string;
}

// Individual card components
const ServiceLevelCard = ({
  vendorData,
  averageServiceLevel,
}: {
  vendorData: VendorRawData | VendorDetail;
  averageServiceLevel: number;
}) => (
  <div className="bg-white border-1 border-[#E2E8F0] shadow-xs rounded-md px-2 pt-1 h-[79px]">
    <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">90 Days Fill Rate</div>
    <div className="text-2xs text-[#6E6E6E]">AVG {averageServiceLevel > 0 ? averageServiceLevel.toFixed(2) : "0.00"}%</div>
    <div className="mt-[-10px]">
      <VendorLineChart vendor={vendorData as any} />
    </div>
  </div>
);

const PrimaryRiskCard = ({ drivingRiskLabel }: { drivingRiskLabel?: string | null }) => {
  const displayLabel = (drivingRiskLabel ?? "").trim() || "-";
  return (
    <div className="bg-white border-1 border-[#E2E8F0] shadow-xs rounded-md px-4 pt-3 h-[79px]">
      <div className="flex items-center justify-between">
        <span className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">Driving Risk</span>
      </div>
      <div className={`font-bold text-neutral-900 leading-tight ${displayLabel.length < 30 ? "mt-1" : ""}`}>{displayLabel}</div>
    </div>
  );
};

const MaterialsAtRiskCard = ({ vendorData }: { vendorData: VendorRawData | VendorDetail }) => (
  <div className="bg-white border-1 border-[#E2E8F0] shadow-xs rounded-md px-4 pt-3 h-[79px]">
    <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">Materials at Risk</div>
    <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px] mt-1">
      {vendorData.materials_at_risk?.toString() || "0"}
    </div>
  </div>
);

const NumberOfMaterialsCard = ({ vendorData }: { vendorData: VendorRawData | VendorDetail }) => (
  <div className="bg-white border-1 border-[#E2E8F0] shadow-xs rounded-md px-4 pt-3 h-[79px]">
    <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">Number of Materials</div>
    <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px] mt-1">
      {vendorData.total_materials?.toString() || "0"}
    </div>
  </div>
);

const VendorDetailCards: React.FC<VendorDetailCardsProps> = ({ vendorData, averageServiceLevel, className = "" }) => {
  const { getEnrichedMetadata } = useRiskModelDescriptions();
  const drivingRiskLabel = getEnrichedMetadata(vendorData.driving_risk).display_name || vendorData.driving_risk || "-";
  return (
    <div className={`grid gap-3 ${className}`}>
      <ServiceLevelCard vendorData={vendorData} averageServiceLevel={averageServiceLevel} />
      <PrimaryRiskCard drivingRiskLabel={drivingRiskLabel} />
      <MaterialsAtRiskCard vendorData={vendorData} />
      <NumberOfMaterialsCard vendorData={vendorData} />
    </div>
  );
};

export default VendorDetailCards;
