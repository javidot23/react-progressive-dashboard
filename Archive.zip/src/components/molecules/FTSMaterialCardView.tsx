import type { KeyboardEvent, ReactNode } from "react";
import type { FtsMaterialRow, FtsTrendPoint } from "@/lib/apiServices";
import FtsTrendLineChart from "@/components/manage/fts/FtsTrendLineChart";
import { formatFtsSalesAmount } from "@/utils/ftsMitigation";

const dcMissedLinesChevronBtnClass =
  "inline-flex shrink-0 p-0 m-0 border-0 bg-transparent text-inherit cursor-pointer rounded-sm focus:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-1";

function DcMissedLinesChevronSvg() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      strokeWidth={2}
      stroke="currentColor"
      className="w-4 h-4"
      aria-hidden
    >
      <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
    </svg>
  );
}

function avgPct(points: FtsTrendPoint[] | undefined): number | null {
  if (!points || points.length === 0) return null;
  const sum = points.reduce((acc, p) => acc + (typeof p.value === "number" ? p.value : 0), 0);
  return sum / points.length;
}

function fmtAvg(value: number | null): string {
  if (value === null || Number.isNaN(value)) return "AVG —";
  return `AVG ${value.toFixed(2)}%`;
}

function latestTrendDate(material: FtsMaterialRow): string {
  const dates: string[] = [];
  for (const arr of [
    material.prxo_service_level_trend,
    material.pharmagen_service_level_trend,
    material.total_service_level_trend,
    material.fill_rate_trend,
  ]) {
    for (const p of arr ?? []) {
      if (p?.date) dates.push(p.date);
    }
  }
  if (dates.length === 0) return "—";
  const sortedDates = [...dates].sort();
  return sortedDates[sortedDates.length - 1]!;
}

function formatAsOfDate(iso: string): string {
  if (iso === "—") return iso;
  const d = new Date(`${iso}T12:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

const renderCardHeader = (title: string) => (
  <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">{title}</div>
);

interface FTSMaterialCardViewProps {
  material: FtsMaterialRow;
  selected?: boolean;
  onMaterialSelect?: (matNbr: string) => void;
  onOpenDcMissedLines?: (matNbr: string) => void;
}

function SparkMetricTile({ title, avgLabel, points }: { title: string; avgLabel: string; points: FtsTrendPoint[] | undefined }) {
  return (
    <div className="bg-[#F5F5F5]  border border-[#CACACA] rounded-md pt-1 px-2  flex flex-col relative min-h-[90px] max-h-[90px]">
      {renderCardHeader(title)}
      <div className="text-2xs text-[#6B7280]">{avgLabel}</div>
      <div className="w-full min-w-0">
        <FtsTrendLineChart points={points} metricLabel={title} />
      </div>
    </div>
  );
}

function PlainMetricTile({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="bg-[#F5F5F5] border border-[#CACACA] rounded-md py-3 px-2 min-h-[90px] max-h-[90px] flex flex-col justify-center">
      {renderCardHeader(title)}
      <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px] mt-1 wrap-break-word leading-tight">{children}</div>
    </div>
  );
}

export default function FTSMaterialCardView({
  material,
  selected = false,
  onMaterialSelect,
  onOpenDcMissedLines,
}: FTSMaterialCardViewProps) {
  const asOf = formatAsOfDate(latestTrendDate(material));
  const ndcRaw = (material.material_ndc ?? material.ndc)?.trim();
  const ndc = ndcRaw ? ndcRaw : "—";

  const interactive = Boolean(onMaterialSelect || onOpenDcMissedLines);

  const onKeyDownCard = (e: KeyboardEvent) => {
    if (!interactive) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      (onOpenDcMissedLines ?? onMaterialSelect)?.(material.mat_nbr);
    }
  };

  const shellClass = `border border-ui-border-primary rounded-md my-3 p-4 transition-shadow ${
    selected ? "ring-2 ring-brand-primary-main ring-offset-1 shadow-xs" : ""
  } ${interactive ? "cursor-pointer hover:bg-brand-primary-50/30" : ""}`;

  const body = (
    <>
      <div className="mb-4">
        <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 flex-wrap">
          <h3 className="font-semibold text-base sm:text-lg text-ui-text-primary py-2 wrap-break-word inline-flex items-center gap-1">
            {material.material_name}
            {onOpenDcMissedLines && (
              <button
                type="button"
                className={dcMissedLinesChevronBtnClass}
                aria-label="Open DC Missed Lines for this material"
                title="Open DC Missed Lines"
                onClick={e => {
                  e.stopPropagation();
                  onOpenDcMissedLines(material.mat_nbr);
                }}
              >
                <DcMissedLinesChevronSvg />
              </button>
            )}
          </h3>
          <div className="flex items-center flex-wrap gap-x-2 gap-y-1 text-sm text-ui-text-secondary">
            <span className="hidden sm:inline" aria-hidden>
              •
            </span>
            <span className="truncate max-w-full">
              <span className="text-[#6E6E6E]">Material Id </span>
              {material.mat_nbr}
            </span>
            <span className="hidden sm:inline" aria-hidden>
              •
            </span>
            <span className="truncate max-w-full">
              <span className="text-[#6E6E6E]">NDC </span>
              {ndc}
            </span>
            <span className="hidden sm:inline" aria-hidden>
              •
            </span>
            <span className="truncate max-w-full">
              <span className="text-[#6E6E6E]">Date </span>
              {asOf}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <SparkMetricTile
          title="PRxO Service Level"
          avgLabel={fmtAvg(avgPct(material.prxo_service_level_trend))}
          points={material.prxo_service_level_trend}
        />
        <SparkMetricTile
          title="PharmaGen Service Level"
          avgLabel={fmtAvg(avgPct(material.pharmagen_service_level_trend))}
          points={material.pharmagen_service_level_trend}
        />
        <SparkMetricTile
          title="Total Service Level"
          avgLabel={fmtAvg(avgPct(material.total_service_level_trend))}
          points={material.total_service_level_trend}
        />
        <SparkMetricTile
          title="Outbound Fill Rate"
          avgLabel={fmtAvg(avgPct(material.fill_rate_trend))}
          points={material.fill_rate_trend}
        />
        <PlainMetricTile title="Omits">{material.omits_qty.toLocaleString()}</PlainMetricTile>
        <PlainMetricTile title="Sales">{formatFtsSalesAmount(material.sales_amount)}</PlainMetricTile>
      </div>
    </>
  );

  if (interactive) {
    return (
      <div
        role="button"
        tabIndex={0}
        className={shellClass}
        onClick={() => (onOpenDcMissedLines ?? onMaterialSelect)?.(material.mat_nbr)}
        onKeyDown={onKeyDownCard}
      >
        {body}
      </div>
    );
  }

  return <div className={shellClass}>{body}</div>;
}
