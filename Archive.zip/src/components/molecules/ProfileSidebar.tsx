import React from 'react';
import userIconUrl from '@/assets/icons/user-profile-icon.svg';
import signOutIconUrl from '@/assets/icons/sign-out-icon.svg';
import { cn } from '@/lib/utils';
import thresholdsIconUrl from '@/assets/icons/thresholds-icon.svg';
import preferencesIconUrl from '@/assets/icons/preferences-icon.svg';

interface SidebarItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface ProfileSidebarProps {
  activeItem: string;
  onItemClick: (itemId: string) => Promise<void> | void;
  className?: string;
}

export const ProfileSidebar: React.FC<ProfileSidebarProps> = ({
  activeItem,
  onItemClick,
  className
}) => {
  const accountItems: SidebarItem[] = [
    { id: 'general', label: 'General Information', icon: <img src={userIconUrl} className="w-4 h-4" alt="" aria-hidden="true" /> },
  ];
  const preferenceItems: SidebarItem[] = [
    { id: 'thresholds', label: 'Manage Thresholds', icon: <img src={thresholdsIconUrl} className="w-4 h-4" alt="" aria-hidden="true" /> },
    { id: 'view-preferences', label: 'View Preferences', icon: <img src={preferencesIconUrl} className="w-4 h-4" alt="" aria-hidden="true" /> },
  ];
  const dataItems: SidebarItem[] = [
    { id: 'glossary', label: 'Glossary', icon: <img src={preferencesIconUrl} className="w-4 h-4" alt="" aria-hidden="true" /> },
    { id: 'data-freshness', label: 'Data Freshness', icon: <img src={preferencesIconUrl} className="w-4 h-4" alt="" aria-hidden="true" /> },
  ];

  return (
    <div className={cn('w-64 bg-ui-background-primary border border-ui-border-primary rounded-sm', className)}>
      <div className="h-full">
        <div className="p-3 mt-2">
          <h3 className="text-lg font-semibold text-ui-text-primary">My account</h3>
        </div>

        <nav className="space-y-1">
          {accountItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onItemClick(item.id)}
              className={cn(
                'flex w-full items-center px-3 py-2 text-sm transition-colors text-left',
                activeItem === item.id
                  ? 'bg-ui-background-muted text-ui-text-primary font-medium'
                  : 'text-ui-text-secondary hover:bg-ui-background-muted hover:text-ui-text-primary'
              )}
            >
              {item.icon && <span className="mr-3">{item.icon}</span>}
              {item.label}
            </button>
          ))}
        </nav>
        <div className="my-3 border-t border-ui-border-primary" />
        <div className="px-3 mb-2">
          <h3 className="text-lg font-semibold text-ui-text-primary">Preferences</h3>
        </div>
        <nav className="space-y-1">
          {preferenceItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onItemClick(item.id)}
              className={cn(
                'flex w-full items-center px-3 py-2 text-sm transition-colors text-left',
                activeItem === item.id
                  ? 'bg-ui-background-muted text-ui-text-primary font-medium'
                  : 'text-ui-text-secondary hover:bg-ui-background-muted hover:text-ui-text-primary'
              )}
            >
              {item.icon && <span className="mr-3">{item.icon}</span>}
              {item.label}
            </button>
          ))}
        </nav>
        <div className="my-3 border-t border-ui-border-primary" />
        <div className="px-3 mb-2">
          <h3 className="text-lg font-semibold text-ui-text-primary">Data</h3>
        </div>
        <nav className="space-y-1">
          {dataItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onItemClick(item.id)}
              className={cn(
                'flex w-full items-center px-3 py-2 text-sm transition-colors text-left',
                activeItem === item.id
                  ? 'bg-ui-background-muted text-ui-text-primary font-medium'
                  : 'text-ui-text-secondary hover:bg-ui-background-muted hover:text-ui-text-primary'
              )}
            >
              {item.icon && <span className="mr-3">{item.icon}</span>}
              {item.label}
            </button>
          ))}
        </nav>

        <div className="mt-2 pt-2 border-t border-ui-border-primary">
          <button
            onClick={() => onItemClick('sign-out')}
            className="flex w-full items-center px-3 py-2 text-base rounded-md text-sm transition-colors text-left text-status-error-text hover:bg-status-error-light"
          >
            <img src={signOutIconUrl} className="w-5 h-5 mr-3" alt="" aria-hidden="true" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};
