import { useRef, useEffect, useCallback, useState } from "react";
import { LogOut, CircleUserRound } from "lucide-react";
import { useProfile } from "@/hooks/useProfile";
import { useAuth } from "@/contexts/AuthContext";

export const ProfilePictureDropdown = () => {
  const { profile } = useProfile();
  const { logout } = useAuth();
  const containerRef = useRef<HTMLDivElement>(null);

  const [isOpen, setIsOpen] = useState(false);

  const toggleIsOpen = useCallback(() => setIsOpen(prev => !prev), []);
  const handleClose = useCallback(() => setIsOpen(false), []);

  const handleKeyDown = useCallback(
    (event: React.KeyboardEvent) => {
      if (event.key === "Escape") {
        handleClose();
      }
    },
    [handleClose]
  );

  const handleBlur = useCallback(
    (event: React.FocusEvent) => {
      if (!containerRef.current?.contains(event.relatedTarget as Node)) {
        handleClose();
      }
    },
    [handleClose]
  );

  useEffect(() => {
    if (isOpen && containerRef.current) {
      containerRef.current.focus();
    }
  }, [isOpen]);

  const handleSignOut = () => {
    handleClose();
    logout();
  };

  return (
    <div ref={containerRef} className="relative ml-2" onKeyDown={handleKeyDown} onBlur={handleBlur} tabIndex={-1}>
      <button
        onClick={toggleIsOpen}
        className="transition-colors duration-200 hover:opacity-80 flex items-center justify-center"
        aria-label="User profile menu"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        {profile?.photoDataUrl ? (
          <img
            src={profile.photoDataUrl}
            alt="Profile"
            className="h-10 w-10 rounded-full object-cover border-2 border-white/30"
          />
        ) : (
          <div className="h-10 w-10 rounded-full bg-white flex items-center justify-center border-2 border-white/30">
            <CircleUserRound className="h-6 w-6 text-[#461E96]" />
          </div>
        )}
      </button>
      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-10000">
          <div className="px-3 pb-2 border-b border-gray-100">
            <p className="text-sm text-gray-600 truncate">{profile?.mail || profile?.userPrincipalName || "No email"}</p>
          </div>
          <div className="pt-1 px-1">
            <button
              onClick={handleSignOut}
              className="w-full flex items-center gap-2 px-2 py-1.5 text-left text-sm font-medium text-red-600 rounded hover:bg-red-50 transition-colors"
            >
              <LogOut className="h-4 w-4" />
              <span>Sign out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfilePictureDropdown;
