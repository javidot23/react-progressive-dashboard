import "@testing-library/jest-dom";
import React from "react";
import { render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import { TableSettingsProvider } from "@/components/atoms";
import VendorTableView from "@/components/molecules/VendorTableView";

const mockNavigate = jest.fn();
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: () => mockNavigate,
}));

jest.mock("@/hooks", () => ({
  useRiskModelDescriptions: () => {
    const labels: Record<string, string> = {
      Operational: "Operational Risk",
      Environmental: "Environmental Risk",
      Financial: "Financial Risk",
    };
    return {
      getEnrichedMetadata: (risk: string) => ({
        display_name: labels[risk] || risk,
        original_risk_type: risk,
        risk_type: risk,
        risk_description: risk,
      }),
    };
  },
}));

jest.mock("@/lib/vendorUtils", () => ({
  ...jest.requireActual("@/lib/vendorUtils"),
  formatNumber: jest.fn((num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(2)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(2)}k`;
    }
    return num.toString();
  }),
}));

const mockVendors = [
  {
    id: 1,
    name: "Test Vendor 1",
    vendor_nbr: "V001",
    city: "New York",
    country: "USA",
    risk_rating: 0.75,
    driving_risk: "Operational",
    risk_adjusted_value: 100000,
    sales_amount: 50000,
    sales_volume: 1000,
    materials_at_risk: 5,
    total_materials: 10,
    latitude: 40.7128,
    longitude: -74.006,
    created_at: "2024-01-01",
    updated_at: "2024-01-01",
    service_levels_90_days: [{ date: "2024-01-01", avg_fill_rate: 0.95, total_order_qty: 1000, total_received_qty: 950 }],
  },
  {
    id: 2,
    name: "Test Vendor 2",
    vendor_nbr: "V002",
    city: "Los Angeles",
    country: "USA",
    risk_rating: 0.45,
    driving_risk: "Environmental",
    risk_adjusted_value: 80000,
    sales_amount: 40000,
    sales_volume: 800,
    materials_at_risk: 3,
    total_materials: 8,
    latitude: 34.0522,
    longitude: -118.2437,
    created_at: "2024-01-02",
    updated_at: "2024-01-02",
    service_levels_90_days: [],
  },
];

// Mock pagination props for testing
const mockPaginationProps = {
  currentPage: 1,
  pageSize: 10,
  total: 100,
  onPageChange: jest.fn(),
  onPageSizeChange: jest.fn(),
};

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <TableSettingsProvider>
    <BrowserRouter>{children}</BrowserRouter>
  </TableSettingsProvider>
);

describe("VendorTableView", () => {
  beforeEach(() => {
    mockNavigate.mockClear();
  });

  it("renders without crashing", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByRole("table")).toBeInTheDocument();
  });

  it("displays table headers", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("Name")).toBeInTheDocument();
    expect(screen.getByText("Fill Rate Trend 90 Days")).toBeInTheDocument();
    expect(screen.getByText("Risk Score")).toBeInTheDocument();
    expect(screen.getByText("Driving Risk")).toBeInTheDocument();
    expect(screen.getByText("Risk Adjusted Value")).toBeInTheDocument();
    expect(screen.getByText("Sales Amount")).toBeInTheDocument();
    expect(screen.getByText("Material At Risk")).toBeInTheDocument();
  });

  it("displays Supplier Names", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );
  });

  it("displays risk scores as badges only (no exact numeric score)", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.queryByText("75.00 / 100")).not.toBeInTheDocument();
    expect(screen.queryByText("45.00 / 100")).not.toBeInTheDocument();
    expect(screen.getByText("Likely")).toBeInTheDocument();
    expect(screen.getByText("Even Chance")).toBeInTheDocument();
  });

  it("displays risk badges", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("Likely")).toBeInTheDocument(); // 0.75 risk
    expect(screen.getByText("Even Chance")).toBeInTheDocument(); // 0.45 risk
  });

  it("displays primary risk", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("Operational Risk")).toBeInTheDocument();
    expect(screen.getByText("Environmental Risk")).toBeInTheDocument();
  });

  it("displays fill rate for vendor with service levels", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("AVG 95.00%")).toBeInTheDocument();
  });

  it("displays default fill rate for vendor without service levels", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("AVG 93.40%")).toBeInTheDocument();
  });

  it("displays material at risk values", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("5 / 10")).toBeInTheDocument();
    expect(screen.getByText("3 / 8")).toBeInTheDocument();
  });

  it("handles empty data array", () => {
    render(
      <TestWrapper>
        <VendorTableView data={[]} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByRole("table")).toBeInTheDocument();
    // Should still show headers but no data rows
    expect(screen.getByText("Name")).toBeInTheDocument();
  });

  it("handles vendor with no risk adjusted value", () => {
    const vendorWithoutRiskValue = [
      {
        ...mockVendors[0],
        risk_adjusted_value: 0,
      },
    ];

    render(
      <TestWrapper>
        <VendorTableView data={vendorWithoutRiskValue} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("- / -")).toBeInTheDocument();
  });

  it("handles vendor with no sales data", () => {
    const vendorWithoutSales = [
      {
        ...mockVendors[0],
        sales_amount: 0,
        sales_volume: 0,
      },
    ];

    render(
      <TestWrapper>
        <VendorTableView data={vendorWithoutSales} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("- / -")).toBeInTheDocument();
  });

  it("handles vendor with no materials", () => {
    const vendorWithoutMaterials = [
      {
        ...mockVendors[0],
        total_materials: 0,
      },
    ];

    render(
      <TestWrapper>
        <VendorTableView data={vendorWithoutMaterials} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("- / -")).toBeInTheDocument();
  });

  it("displays sales amount and total sales", () => {
    render(
      <TestWrapper>
        <VendorTableView data={mockVendors} {...mockPaginationProps} />
      </TestWrapper>
    );

    expect(screen.getByText("$50.00K / 1.00K")).toBeInTheDocument();
  });
});
