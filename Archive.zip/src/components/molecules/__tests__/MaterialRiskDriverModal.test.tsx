import "@testing-library/jest-dom";
import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import * as ReactDOM from "react-dom";
import { MaterialRiskDriverModal } from "@/components/molecules/MaterialRiskDriverModal";
import { materialRiskService } from "@/lib/apiServices";

// Modal uses createPortal to render into document.body; mock so content is in the same tree for queries
jest.mock("react-dom", () => ({
  ...jest.requireActual<typeof ReactDOM>("react-dom"),
  createPortal: (node: React.ReactNode) => node,
}));

// Mock the API service
jest.mock("@/lib/apiServices", () => ({
  materialRiskService: {
    getMaterialRisk: jest.fn(),
  },
}));

// Mock the vendor utils
jest.mock("@/lib/vendorUtils", () => ({
  getRiskBadge: jest.fn(() => ({
    text: "High",
    bgColor: "bg-red-100",
    textColor: "text-red-800",
    borderColor: "border-red-200",
  })),
}));

// Mock formatCurrencyCompact
jest.mock("@/lib/utils", () => ({
  formatCurrencyCompact: jest.fn((value: number) => {
    if (value >= 1_000_000) {
      return `$${(value / 1_000_000).toFixed(2)}M`;
    } else if (value >= 1_000) {
      return `$${(value / 1_000).toFixed(2)}K`;
    }
    return `$${value.toLocaleString()}`;
  }),
}));

// Mock useRiskModelDescriptions hook (replaces direct modelMappings usage)
jest.mock("@/hooks", () => {
  const riskTypeMapping: Record<string, string> = {
    forecast_error_model: "base_model_operational",
    financial: "financial",
    vendor_competitive_landscape_12month: "base_model_market",
    patient: "patient",
    demand_type: "base_model_sales",
    "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-gcn": "base_model_regulatory",
    cyclone: "base_model_location",
    reputational: "reputational",
    composite_risk_model: "composite_risk_group",
    category_risk_operational: "category_risk_group",
    category_risk_market: "category_risk_group",
    category_risk_sales: "category_risk_group",
    category_risk_regulatory: "category_risk_group",
    category_risk_location: "category_risk_group",
  };
  const riskTypeDescriptions: Record<string, string> = {
    forecast_error_model: "Operational Risk of Large Forecast Errors",
    financial: "Financial Risk",
    vendor_competitive_landscape_12month: "Market Risk of Vendor Exit from Market Landscape",
    patient: "Patient Risk",
    demand_type: "Sales Risk due to Demand Patterns",
    "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-gcn":
      "Regulatory Risk from FDA Compliance Impact over the next 90 days",
    cyclone: "Location Risk of Cyclone or Hurricane",
    reputational: "Reputational Risk",
    composite_risk_model: "Composite Risk Model",
    category_risk_operational: "Categorical Operational Risk",
    category_risk_market: "Categorical Market Risk",
    category_risk_sales: "Categorical Sales Risk",
    category_risk_regulatory: "Categorical Regulatory Risk",
    category_risk_location: "Categorical Location Risk",
  };
  const riskTypeDisplayNames: Record<string, string> = {
    forecast_error_model: "Forecast Error Risk",
    financial: "Financial Risk",
    vendor_competitive_landscape_12month: "Vendor Competitive Landscape",
    patient: "Patient Risk",
    demand_type: "Demand Pattern Sales Risk",
    "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-gcn": "FDA Compliance Risk",
    cyclone: "Natural Disaster Risk - Cyclone",
    reputational: "Reputational Risk",
    composite_risk_model: "Overall Aggregate Supply Chain Risk",
    category_risk_operational: "Operations Categorical Aggregate Risk",
    category_risk_market: "Market Categorical Aggregate Risk",
    category_risk_sales: "Sales Categorical Aggregate Risk",
    category_risk_regulatory: "Regulatory Categorical Aggregate Risk",
    category_risk_location: "Location Categorical Aggregate Risk",
  };
  const riskCategoryTypes = [
    { type: "base_model_operational", title: "Operational Risk" },
    { type: "base_model_market", title: "Market Risk" },
    { type: "base_model_sales", title: "Sales Risk" },
    { type: "base_model_regulatory", title: "Regulatory Risk" },
    { type: "base_model_location", title: "Location Risk" },
  ];
  const enrichRiskData = (rawItems: Array<{ risk_type: string } & Record<string, unknown>>) =>
    rawItems.map(item => ({
      ...item,
      original_risk_type: item.risk_type,
      risk_type: riskTypeMapping[item.risk_type] ?? item.risk_type,
      risk_description: riskTypeDescriptions[item.risk_type] ?? item.risk_type,
      display_name: riskTypeDisplayNames[item.risk_type] ?? item.risk_type,
    }));
  const actual = jest.requireActual<typeof import("@/hooks")>("@/hooks");
  return {
    ...actual,
    useRiskModelDescriptions: () => ({
      isLoading: false,
      error: null,
      riskCategoryTypes,
      enrichRiskData,
      mapRiskTypeToModelType: (riskType: string) => riskTypeMapping[riskType] ?? riskType,
    }),
  };
});

// Mock CardLayout and CircularProgress
jest.mock("@/components/templates", () => ({
  CardLayout: ({ children, title, subtitle, className, style }: any) => (
    <div className={className} style={style} data-testid="card-layout">
      {title && <div data-testid="card-title">{title}</div>}
      {subtitle && <div data-testid="card-subtitle">{subtitle}</div>}
      {children}
    </div>
  ),
}));

jest.mock("@/components/atoms", () => ({
  CircularProgress: ({ value, size, strokeWidth, color }: any) => (
    <div data-testid="circular-progress" data-value={value} data-size={size} data-stroke-width={strokeWidth} data-color={color}>
      {value}%
    </div>
  ),
}));

// Mock SVG imports
jest.mock("@/assets/icons/accounting-document.svg", () => "accounting-document.svg");
jest.mock("@/assets/icons/alert-triangle-primary.svg", () => "alert-triangle-primary.svg");
jest.mock("@/assets/icons/composite.svg", () => "composite.svg");
jest.mock("@/assets/icons/category.svg", () => "category.svg");
jest.mock("@/assets/icons/discount-dollar-dash-primary.svg", () => "discount-dollar-dash-primary.svg");
jest.mock("@/assets/icons/messages-bubble-square-star.svg", () => "messages-bubble-square-star.svg");
jest.mock("@/assets/icons/multiple-users-primary.svg", () => "multiple-users-primary.svg");
jest.mock("@/assets/icons/pin.svg", () => "pin.svg");
jest.mock("@/assets/icons/right-arrow-primary.svg", () => "right-arrow-primary.svg");
jest.mock("@/assets/icons/shopping-cart-empty.svg", () => "shopping-cart-empty.svg");
jest.mock("@/assets/icons/warehouse-packages.svg", () => "warehouse-packages.svg");

// Test wrapper with QueryClient
const TestWrapper = ({ children }: { children: React.ReactNode }) => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: 0,
      },
    },
  });

  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
};

describe("MaterialRiskDriverModal", () => {
  const mockOnClose = jest.fn();
  const mockMaterialRiskService = materialRiskService as jest.Mocked<typeof materialRiskService>;

  const defaultProps = {
    isOpen: true,
    onClose: mockOnClose,
    materialName: "Test Material",
    vendorName: "Test Vendor",
    overallRiskScore: 75,
    dollarsAtRisk: 1000000,
    materialId: 123,
    riskLevel: 3,
  };

  const mockRiskData = [
    {
      id: 1,
      risk_type: "forecast_error_model", // maps to base_model_operational
      risk_rating: 0.8,
      dollars_at_risk: null,
      time_horizon: 30,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 2,
      risk_type: "financial", // stays as financial
      risk_rating: 0.6,
      dollars_at_risk: null,
      time_horizon: 60,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 3,
      risk_type: "vendor_competitive_landscape_12month", // maps to base_model_market
      risk_rating: 0.4,
      dollars_at_risk: null,
      time_horizon: 90,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 4,
      risk_type: "patient", // stays as patient
      risk_rating: 0.9,
      dollars_at_risk: null,
      time_horizon: 15,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 5,
      risk_type: "demand_type", // maps to base_model_sales
      risk_rating: 0.7,
      dollars_at_risk: null,
      time_horizon: 45,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 6,
      risk_type: "srm_fdacompliance-model-TARGET-shortage_n90d-GRANULARITY-gcn", // maps to base_model_regulatory
      risk_rating: 0.5,
      dollars_at_risk: null,
      time_horizon: 120,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 7,
      risk_type: "cyclone", // maps to base_model_location
      risk_rating: 0.3,
      dollars_at_risk: null,
      time_horizon: 180,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 8,
      risk_type: "reputational", // stays as reputational
      risk_rating: 0.6,
      dollars_at_risk: null,
      time_horizon: 30,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 9,
      risk_type: "composite_risk_model", // maps to composite_risk_group
      risk_rating: 0.85,
      dollars_at_risk: null,
      time_horizon: 30,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 10,
      risk_type: "category_risk_operational", // maps to category_risk_group
      risk_rating: 0.75,
      dollars_at_risk: null,
      time_horizon: 30,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 11,
      risk_type: "category_risk_market", // maps to category_risk_group
      risk_rating: 0.66,
      dollars_at_risk: null,
      time_horizon: 30,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 12,
      risk_type: "category_risk_sales", // maps to category_risk_group
      risk_rating: 0.88,
      dollars_at_risk: null,
      time_horizon: 30,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 13,
      risk_type: "category_risk_regulatory", // maps to category_risk_group
      risk_rating: 0.44,
      dollars_at_risk: null,
      time_horizon: 30,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 14,
      risk_type: "category_risk_location", // maps to category_risk_group
      risk_rating: 0.22,
      dollars_at_risk: null,
      time_horizon: 30,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
    {
      id: 15,
      risk_type: "forecast_error_model", // same model as id 1, but max horizon should win
      risk_rating: 0.2,
      dollars_at_risk: null,
      time_horizon: 360,
      status_date: "2026-01-05",
      created_at: "2026-01-05T12:07:53.703361Z",
      updated_at: "2026-01-05T12:07:53.703361Z",
      material: "123",
    },
  ];

  beforeEach(() => {
    jest.clearAllMocks();
    window.HTMLElement.prototype.scrollIntoView = jest.fn();
    mockMaterialRiskService.getMaterialRisk.mockResolvedValue({
      data: {
        success: true,
        data: mockRiskData,
      },
    } as any);
  });

  describe("Rendering", () => {
    it("renders modal when isOpen is true", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} ndc="12345" />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText("Test Material")).toBeInTheDocument();
        expect(screen.getByText(/NDC: 12345/)).toBeInTheDocument();
        expect(screen.getByText(/Supplier: Test Vendor/)).toBeInTheDocument();
      });
    });

    it("does not render modal when isOpen is false", () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} isOpen={false} />
        </TestWrapper>
      );

      expect(screen.queryByText("Test Material")).not.toBeInTheDocument();
    });
  });

  describe("Risk Score Display", () => {
    it("displays overall risk score correctly", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText("75 / 100")).toBeInTheDocument();
      });
    });

    it("displays risk badge", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText("High")).toBeInTheDocument();
      });
    });

    it("displays risk adjusted value correctly", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        // Component shows formatted currency: $755.0K (75.5% of $1M = $755K)
        expect(screen.getByText("$750.00K")).toBeInTheDocument();
      });
    });
  });

  describe("Risk Categories", () => {
    const getRiskCategoryCard = (title: string) => {
      const label = screen.getByText(title);
      const card = label.closest(".flex.flex-col.gap-2.p-3.rounded-lg");
      expect(card).toBeInTheDocument();
      return card as HTMLElement;
    };

    it("displays all risk categories", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText("Operational Risk")).toBeInTheDocument();
        expect(screen.getByText("Market Risk")).toBeInTheDocument();
        expect(screen.getByText("Sales Risk")).toBeInTheDocument();
        expect(screen.getByText("Regulatory Risk")).toBeInTheDocument();
        expect(screen.getByText("Location Risk")).toBeInTheDocument();
        expect(screen.queryByText("Composite Risk")).not.toBeInTheDocument();
        expect(screen.queryByText("Category Risk")).not.toBeInTheDocument();
      });
    });

    it("uses 30-day category aggregate scores for each risk card", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(getRiskCategoryCard("Operational Risk")).toHaveTextContent("75/100");
        expect(getRiskCategoryCard("Market Risk")).toHaveTextContent("66/100");
        expect(getRiskCategoryCard("Sales Risk")).toHaveTextContent("88/100");
        expect(getRiskCategoryCard("Regulatory Risk")).toHaveTextContent("44/100");
        expect(getRiskCategoryCard("Location Risk")).toHaveTextContent("22/100");
      });
    });

    it("displays risk scores for each category", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(
        () => {
          // Check that all categories are rendered
          expect(screen.getByText("Operational Risk")).toBeInTheDocument();
          expect(screen.getByText("Market Risk")).toBeInTheDocument();
          expect(screen.getByText("Sales Risk")).toBeInTheDocument();
          expect(screen.getByText("Regulatory Risk")).toBeInTheDocument();
          expect(screen.getByText("Location Risk")).toBeInTheDocument();
          expect(screen.queryByText("Composite Risk")).not.toBeInTheDocument();

          // Check that score elements exist (they contain "/100")
          // The component shows scores like "80/100" where 100 is in a bold tag
          const scoreElements = screen.getAllByText((_, element) => {
            const text = element?.textContent || "";
            return text.includes("/100") || text.includes("100");
          });
          expect(scoreElements.length).toBeGreaterThanOrEqual(5);
        },
        { timeout: 3000 }
      );
    });

    it("displays risk category icons", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        const operationalIcon = screen.getByAltText("Operational Risk");
        const locationIcon = screen.getByAltText("Location Risk");
        expect(operationalIcon).toBeInTheDocument();
        expect(locationIcon).toBeInTheDocument();
      });
    });

    it("dedupes contributors to max horizon and excludes category/composite rows", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(getRiskCategoryCard("Operational Risk")).toHaveTextContent("75/100");
      });

      const riskContributorButtons = screen.getAllByText("Risk Contributors");
      fireEvent.click(riskContributorButtons[0]);

      await waitFor(() => {
        expect(screen.getByText("360 day horizon")).toBeInTheDocument();
        expect(screen.getByText((_, element) => element?.textContent === "20/100")).toBeInTheDocument();
        expect(screen.queryByText("30 day horizon")).not.toBeInTheDocument();
        expect(screen.queryByText("Operations Categorical Aggregate Risk")).not.toBeInTheDocument();
        expect(screen.queryByText("Overall Aggregate Supply Chain Risk")).not.toBeInTheDocument();
      });
    });
  });

  describe("API Integration", () => {
    it("fetches risk data when modal opens", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(mockMaterialRiskService.getMaterialRisk).toHaveBeenCalledWith(123, expect.any(AbortSignal));
      });
    });

    it("does not fetch data when materialId is not provided", () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} materialId={undefined} />
        </TestWrapper>
      );

      expect(mockMaterialRiskService.getMaterialRisk).not.toHaveBeenCalled();
    });

    it("handles API errors gracefully", async () => {
      mockMaterialRiskService.getMaterialRisk.mockRejectedValue(new Error("API Error"));

      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText("Error loading risk data: API Error")).toBeInTheDocument();
      });
    });

    it("handles invalid API response format", async () => {
      mockMaterialRiskService.getMaterialRisk.mockResolvedValue({
        data: {
          success: false,
          data: "invalid",
        },
      } as any);

      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(
        () => {
          expect(screen.getByText("Test Material")).toBeInTheDocument();
        },
        { timeout: 3000 }
      );

      // Component should still render even with invalid data format
      expect(screen.queryByText(/Error loading risk data/)).not.toBeInTheDocument();
    });
  });

  describe("User Interactions", () => {
    it("closes modal when close button is clicked", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        const buttons = screen.getAllByRole("button");
        // The first button should be the close button (X button)
        const closeButton = buttons[0];
        fireEvent.click(closeButton);
        expect(mockOnClose).toHaveBeenCalledTimes(1);
      });
    });

    it("closes modal when backdrop is clicked", () => {
      const { container } = render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      const backdrop = container.querySelector(".absolute.inset-0");
      expect(backdrop).toBeInTheDocument();

      if (backdrop) {
        fireEvent.click(backdrop);
        expect(mockOnClose).toHaveBeenCalledTimes(1);
      }
    });
  });

  describe("Currency Formatting", () => {
    it("formats currency correctly", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        // Component shows formatted currency: $755.0K
        expect(screen.getByText("$750.00K")).toBeInTheDocument();
      });
    });

    it("handles zero values", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} overallRiskScore={0} dollarsAtRisk={0} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText("- / -")).toBeInTheDocument();
      });
    });

    it("handles undefined values", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} overallRiskScore={0} dollarsAtRisk={0} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText("- / -")).toBeInTheDocument();
      });
    });
  });

  describe("Risk Color Coding", () => {
    it("applies correct colors based on risk scores", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText("Operational Risk")).toBeInTheDocument();
        expect(screen.queryByText("Composite Risk")).not.toBeInTheDocument();

        const riskCategories = screen.getAllByText(/Risk$/);
        expect(riskCategories.length).toBeGreaterThan(0);
      });
    });
  });

  describe("Edge Cases", () => {
    it("handles empty risk data", async () => {
      mockMaterialRiskService.getMaterialRisk.mockResolvedValue({
        data: {
          success: true,
          data: [],
        },
      } as any);

      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(
        () => {
          // All 5 base-model categories should be rendered
          expect(screen.getByText("Operational Risk")).toBeInTheDocument();
          expect(screen.getByText("Market Risk")).toBeInTheDocument();
          expect(screen.getByText("Sales Risk")).toBeInTheDocument();
          expect(screen.getByText("Regulatory Risk")).toBeInTheDocument();
          expect(screen.getByText("Location Risk")).toBeInTheDocument();
          expect(screen.queryByText("Composite Risk")).not.toBeInTheDocument();
          expect(screen.queryByText("Category Risk")).not.toBeInTheDocument();

          // All should show 0 scores - check by finding score elements that contain "100"
          const scoreElements = screen.getAllByText((_, element) => {
            const text = element?.textContent || "";
            return text.includes("100");
          });
          expect(scoreElements.length).toBeGreaterThanOrEqual(5);
        },
        { timeout: 3000 }
      );
    });

    it("handles partial risk data", async () => {
      const partialRiskData = [
        {
          id: 1,
          risk_type: "forecast_error_model", // maps to base_model_operational
          risk_rating: 0.8,
          dollars_at_risk: null,
          time_horizon: 30,
          status_date: "2026-01-05",
          created_at: "2026-01-05T12:07:53.703361Z",
          updated_at: "2026-01-05T12:07:53.703361Z",
          material: "123",
        },
      ];

      mockMaterialRiskService.getMaterialRisk.mockResolvedValue({
        data: {
          success: true,
          data: partialRiskData,
        },
      } as any);

      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(
        () => {
          // All 5 base-model categories should be rendered
          expect(screen.getByText("Operational Risk")).toBeInTheDocument();
          expect(screen.getByText("Market Risk")).toBeInTheDocument();
          expect(screen.getByText("Sales Risk")).toBeInTheDocument();
          expect(screen.getByText("Regulatory Risk")).toBeInTheDocument();
          expect(screen.getByText("Location Risk")).toBeInTheDocument();
          expect(screen.queryByText("Composite Risk")).not.toBeInTheDocument();
          expect(screen.queryByText("Category Risk")).not.toBeInTheDocument();

          // Check that we have score elements (some will be 0, one will be 80)
          const scoreElements = screen.getAllByText((_, element) => {
            const text = element?.textContent || "";
            return text.includes("100");
          });
          expect(scoreElements.length).toBeGreaterThanOrEqual(5);
        },
        { timeout: 3000 }
      );
    });

    it("handles very high risk scores", async () => {
      const highRiskData = mockRiskData.map(risk => ({
        ...risk,
        risk_rating: 0.99,
      }));

      mockMaterialRiskService.getMaterialRisk.mockResolvedValue({
        data: {
          success: true,
          data: highRiskData,
        },
      } as any);

      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(
        () => {
          // All 5 base-model categories should be rendered
          expect(screen.getByText("Operational Risk")).toBeInTheDocument();
          expect(screen.getByText("Market Risk")).toBeInTheDocument();
          expect(screen.getByText("Sales Risk")).toBeInTheDocument();
          expect(screen.getByText("Regulatory Risk")).toBeInTheDocument();
          expect(screen.getByText("Location Risk")).toBeInTheDocument();
          expect(screen.queryByText("Composite Risk")).not.toBeInTheDocument();
          expect(screen.queryByText("Category Risk")).not.toBeInTheDocument();

          // Should have at least 5 categories showing 99 (appears as "99/100")
          const scores99 = screen.getAllByText((_, element) => {
            const text = element?.textContent || "";
            return text.includes("99") && text.includes("100");
          });
          expect(scores99.length).toBeGreaterThanOrEqual(5);
        },
        { timeout: 3000 }
      );
    });
  });

  describe("Accessibility", () => {
    it("renders material name", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        expect(screen.getByText("Test Material")).toBeInTheDocument();
      });
    });

    it("has proper button labels", async () => {
      render(
        <TestWrapper>
          <MaterialRiskDriverModal {...defaultProps} />
        </TestWrapper>
      );

      await waitFor(() => {
        const buttons = screen.getAllByRole("button");
        expect(buttons.length).toBeGreaterThan(0);
      });
    });
  });
});
