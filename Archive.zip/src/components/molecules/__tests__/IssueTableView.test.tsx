import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import IssueTableView from "@/components/molecules/IssueTableView";

const mockNavigate = jest.fn();
const mockNavigateToMaterialDrillThrough = jest.fn();
const mockNavigateToIssueDrillThrough = jest.fn();

jest.mock("react-router-dom", () => ({
  useNavigate: () => mockNavigate,
}));

jest.mock("@/lib/materialDrillThroughUtils", () => ({
  navigateToMaterialDrillThrough: (...args: unknown[]) => mockNavigateToMaterialDrillThrough(...args),
}));

jest.mock("@/lib/issueDrillThroughUtils", () => ({
  navigateToIssueDrillThrough: (...args: unknown[]) => mockNavigateToIssueDrillThrough(...args),
}));

jest.mock("@/components/atoms", () => ({
  Pagination: () => <div data-testid="pagination" />,
  RiskBadge: () => <span data-testid="risk-badge" />,
}));

jest.mock("@/components/molecules/IssueNotesTableCell", () => ({
  IssueNotesTableCell: () => <div data-testid="notes-cell" />,
}));

jest.mock("@/lib/vendorUtils", () => ({
  getRiskBadge: () => ({
    text: "High",
    bgColor: "bg-orange-50",
    textColor: "text-orange-700",
    borderColor: "border-orange-300",
    hexColor: "#F97316",
  }),
}));

const baseIssue = {
  id: 7,
  productName: "Table Material",
  material: "Material",
  ndc: "456",
  mat_nbr: "MAT-7",
  ean: "",
  createdAt: "Jan 02, 2026",
  riskLevel: 60,
  drivingRisk: "Operational",
  riskExposure: "$500 / $5K",
  actionStatus: "Not Reviewed",
  isCritical: false,
  isNewIssue: false,
  hasActions: false,
  materialId: 88,
  notesCount: 0,
};

const defaultColumns = [
  { id: "issue_name", label: "Issue", visible: true },
  { id: "primary_risk", label: "Driving Risk", visible: true },
  { id: "recommended_actions", label: "Recommended Actions", visible: true },
];

const aggregatedIssue = {
  ...baseIssue,
  isSingleMaterial: false,
  impactedMaterialCount: 3,
  granularityLabel: "NDC",
  granularityValue: "12345-678-90",
  productName: "NDC 12345-678-90",
};

describe("IssueTableView", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("shows driving risk as plain text without modal trigger", () => {
    render(
      <IssueTableView
        data={[baseIssue]}
        currentPage={1}
        pageSize={10}
        total={1}
        onPageChange={jest.fn()}
        onPageSizeChange={jest.fn()}
        columns={defaultColumns}
      />
    );

    expect(screen.getByText("Operational")).toBeInTheDocument();
    expect(screen.queryByTestId("risk-driver-modal")).not.toBeInTheDocument();
  });

  it("renders View material and take action for single-material issues", () => {
    render(
      <IssueTableView
        data={[baseIssue]}
        currentPage={1}
        pageSize={10}
        total={1}
        onPageChange={jest.fn()}
        onPageSizeChange={jest.fn()}
        columns={defaultColumns}
      />
    );

    expect(screen.getByRole("button", { name: "View material and take action" })).toBeInTheDocument();
  });

  it("renders aggregated CTA for multi-material issues", () => {
    render(
      <IssueTableView
        data={[aggregatedIssue]}
        currentPage={1}
        pageSize={10}
        total={1}
        onPageChange={jest.fn()}
        onPageSizeChange={jest.fn()}
        columns={defaultColumns}
      />
    );

    expect(screen.getByRole("button", { name: "View 3 materials and take action" })).toBeInTheDocument();
  });

  it("navigates to material drill-through when single-material CTA is clicked", async () => {
    const user = userEvent.setup();
    render(
      <IssueTableView
        data={[baseIssue]}
        currentPage={1}
        pageSize={10}
        total={1}
        onPageChange={jest.fn()}
        onPageSizeChange={jest.fn()}
        columns={defaultColumns}
      />
    );

    await user.click(screen.getByRole("button", { name: "View material and take action" }));

    expect(mockNavigateToMaterialDrillThrough).toHaveBeenCalledWith(mockNavigate, baseIssue);
  });

  it("navigates to issue drill-through when aggregated CTA is clicked", async () => {
    const user = userEvent.setup();
    render(
      <IssueTableView
        data={[aggregatedIssue]}
        currentPage={1}
        pageSize={10}
        total={1}
        onPageChange={jest.fn()}
        onPageSizeChange={jest.fn()}
        columns={defaultColumns}
      />
    );

    await user.click(screen.getByRole("button", { name: "View 3 materials and take action" }));

    expect(mockNavigateToIssueDrillThrough).toHaveBeenCalledWith(mockNavigate, aggregatedIssue);
  });
});
