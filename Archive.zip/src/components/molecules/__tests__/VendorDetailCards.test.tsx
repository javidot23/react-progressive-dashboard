import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import VendorDetailCards from "@/components/molecules/VendorDetailCards";
import { VendorRawData } from "@/lib/vendorUtils";


jest.mock("@/components/molecules/VendorLineChart", () => ({
  __esModule: true,
  default: function MockVendorLineChart({ vendor }: any) {
    return <div data-testid="vendor-line-chart">Line Chart for {vendor.name}</div>;
  },
}));

jest.mock("@/hooks", () => ({
  useRiskModelDescriptions: () => {
    const labels: Record<string, string> = {
      Operational: "Operational Risk",
      Environmental: "Environmental Risk",
      Financial: "Financial Risk",
      Medium: "Medium Risk",
    };
    return {
      getEnrichedMetadata: (risk: string) => ({
        display_name: labels[risk] || risk,
        original_risk_type: risk,
        risk_type: risk,
        risk_description: risk,
      }),
    };
  },
}));

describe("VendorDetailCards", () => {
  const mockVendor: VendorRawData = {
    id: 1,
    name: "Test Vendor",
    vendor_nbr: "V001",
    country: "USA",
    city: "New York",
    latitude: 40.7128,
    longitude: -74.0060,
    driving_risk: "Operational",
    risk_rating: 0.75,
    created_at: "2024-01-01",
    updated_at: "2024-01-01",
    service_levels_90_days: [
      { date: "2024-01-01", avg_fill_rate: 0.95, total_order_qty: 1000, total_received_qty: 950 },
      { date: "2024-01-02", avg_fill_rate: 0.92, total_order_qty: 1000, total_received_qty: 920 },
    ],
    materials_at_risk: 15,
    total_materials: 25,
    sales_volume: 1000,
    sales_amount: 50000,
    risk_adjusted_value: 37500,
  };

  describe("Rendering", () => {
    it("renders all five detail cards", () => {
      render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      expect(screen.getByText("90 Days Fill Rate")).toBeInTheDocument();
      expect(screen.getByText("Driving Risk")).toBeInTheDocument();
      expect(screen.getByText("Materials at Risk")).toBeInTheDocument();
      expect(screen.getByText("Risk Score")).toBeInTheDocument();
      expect(screen.getByText("Number of Materials")).toBeInTheDocument();
    });

    it("displays correct average service level", () => {
      render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      expect(screen.getByText("AVG 93.50%")).toBeInTheDocument();
    });

    it("displays zero service level when average is 0", () => {
      render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={0}
          serviceLevels={[]}
        />
      );

      expect(screen.getByText("AVG 0.00%")).toBeInTheDocument();
    });

    it("displays driving risk label", () => {
      render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      expect(screen.getByText("Operational Risk")).toBeInTheDocument();
    });

    it("displays materials at risk count", () => {
      render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      expect(screen.getByText("15")).toBeInTheDocument();
    });

    it("displays zero when materials_at_risk is undefined", () => {
      const vendorWithoutRisk = { ...mockVendor, materials_at_risk: undefined };
      render(
        <VendorDetailCards
          vendorData={vendorWithoutRisk}
          averageServiceLevel={93.5}
          serviceLevels={[]}
        />
      );

      const riskCards = screen.getAllByText("Materials at Risk");
      expect(riskCards[0].parentElement).toHaveTextContent("0");
    });

    it("displays risk score as percentage", () => {
      render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      expect(screen.getByText("75.00%")).toBeInTheDocument();
    });

    it("displays total materials count", () => {
      render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      expect(screen.getByText("25")).toBeInTheDocument();
    });

    it("displays zero when total_materials is undefined", () => {
      const vendorWithoutTotal = { ...mockVendor, total_materials: undefined };
      render(
        <VendorDetailCards
          vendorData={vendorWithoutTotal}
          averageServiceLevel={93.5}
          serviceLevels={[]}
        />
      );

      const totalCards = screen.getAllByText("Number of Materials");
      expect(totalCards[0].parentElement).toHaveTextContent("0");
    });
  });

  describe("Custom ClassName", () => {
    it("applies custom className to grid container", () => {
      const { container } = render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
          className="grid-cols-1 md:grid-cols-2"
        />
      );

      const gridElement = container.querySelector(".grid");
      expect(gridElement).toHaveClass("grid-cols-1");
      expect(gridElement).toHaveClass("md:grid-cols-2");
    });

    it("uses default className when not provided", () => {
      const { container } = render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      const gridElement = container.querySelector(".grid");
      expect(gridElement).toBeInTheDocument();
    });
  });

  describe("VendorLineChart Integration", () => {
    it("renders VendorLineChart in service level card", () => {
      render(
        <VendorDetailCards
          vendorData={mockVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      expect(screen.getByTestId("vendor-line-chart")).toBeInTheDocument();
      expect(screen.getByText("Line Chart for Test Vendor")).toBeInTheDocument();
    });
  });

  describe("Edge Cases", () => {
    it("handles vendor with all zero values", () => {
      const zeroVendor: VendorRawData = {
        ...mockVendor,
        risk_rating: 0,
        materials_at_risk: 0,
        total_materials: 0,
        service_levels_90_days: [] as any,
      };

      render(
        <VendorDetailCards
          vendorData={zeroVendor}
          averageServiceLevel={0}
          serviceLevels={[] as any}
        />
      );

      expect(screen.getByText("AVG 0.00%")).toBeInTheDocument();
      expect(screen.getByText("0.00%")).toBeInTheDocument();
      expect(screen.getAllByText("0")[0]).toBeInTheDocument();
    });

    it("handles vendor with high risk rating", () => {
      const highRiskVendor = { ...mockVendor, risk_rating: 0.99 };
      render(
        <VendorDetailCards
          vendorData={highRiskVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      expect(screen.getByText("99.00%")).toBeInTheDocument();
    });

    it("handles different driving risk types", () => {
      const environmentalVendor = { ...mockVendor, driving_risk: "Environmental" };
      render(
        <VendorDetailCards
          vendorData={environmentalVendor}
          averageServiceLevel={93.5}
          serviceLevels={mockVendor.service_levels_90_days || []}
        />
      );

      expect(screen.getByText("Environmental Risk")).toBeInTheDocument();
    });
  });
});
