import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ToastViewport } from "../ToastViewport";
import { useToastStore } from "@/stores/toastStore";

describe("ToastViewport", () => {
  beforeEach(() => {
    useToastStore.setState({ toasts: [] });
  });

  it("renders a notifications region.portaled content", () => {
    render(<ToastViewport />);
    expect(screen.getByRole("region", { name: /notifications/i })).toBeInTheDocument();
  });

  it("renders toasts from the store in order", () => {
    useToastStore.setState({
      toasts: [
        { id: "1", variant: "info", title: "First" },
        { id: "2", variant: "info", title: "Second", duration: 4500 },
      ],
    });
    render(<ToastViewport />);
    const titles = screen.getAllByText(/First|Second/);
    expect(titles.map(el => el.textContent)).toEqual(["First", "Second"]);
  });

  it("close button dismisses via store", async () => {
    const user = userEvent.setup();
    useToastStore.setState({
      toasts: [{ id: "x", variant: "warning", title: "Rm me" }],
    });
    render(<ToastViewport />);
    await user.click(screen.getByRole("button", { name: /dismiss notification/i }));
    expect(useToastStore.getState().toasts).toEqual([]);
  });
});
