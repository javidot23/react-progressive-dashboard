import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import { KeepInMindModal } from "../KeepInMindModal";

describe("KeepInMindModal", () => {
  const mockOnClose = jest.fn();
  const mockOnContinue = jest.fn();

  const defaultProps = {
    isOpen: true,
    onClose: mockOnClose,
    onContinue: mockOnContinue,
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("Rendering", () => {
    it("renders modal when isOpen is true", () => {
      render(<KeepInMindModal {...defaultProps} />);

      expect(screen.getByText("Keep In Mind")).toBeInTheDocument();
      expect(screen.getByText(/You need to complete this action outside the Stratium platform/)).toBeInTheDocument();
    });

    it("does not render modal when isOpen is false", () => {
      render(<KeepInMindModal {...defaultProps} isOpen={false} />);

      expect(screen.queryByText("Keep In Mind")).not.toBeInTheDocument();
    });

    it("displays the action message correctly", () => {
      render(<KeepInMindModal {...defaultProps} />);

      expect(screen.getByText(/You need to complete this action outside the Stratium platform/)).toBeInTheDocument();
      expect(screen.getByText(/recent actions/)).toBeInTheDocument();
    });
  });

  describe("Action summary (issue-level actions)", () => {
    it("shows how many materials the action applies to, with excluded count and exposure", () => {
      render(
        <KeepInMindModal
          {...defaultProps}
          summary={{
            actionLabel: "Put Item to Bid",
            appliesToCount: 2,
            totalCount: 3,
            excludedCount: 1,
            exposure: "$1.2M",
          }}
        />
      );

      expect(screen.getByText("Put Item to Bid")).toBeInTheDocument();
      expect(screen.getByText(/2 of 3 materials/)).toBeInTheDocument();
      expect(screen.getByText(/1 excluded/)).toBeInTheDocument();
      expect(screen.getByText("$1.2M")).toBeInTheDocument();
      // Still communicates the "take action outside Stratium" guidance.
      expect(screen.getByText(/You need to complete this action outside the Stratium platform/)).toBeInTheDocument();
    });

    it("omits the summary block when no summary is provided", () => {
      render(<KeepInMindModal {...defaultProps} />);
      expect(screen.queryByText(/of .* materials/)).not.toBeInTheDocument();
    });
  });

  describe("Submitting State", () => {
    it("displays 'Submitting...' text when isSubmitting is true", () => {
      render(<KeepInMindModal {...defaultProps} isSubmitting={true} />);

      expect(screen.getByText("Submitting...")).toBeInTheDocument();
      expect(screen.queryByText("Continue")).not.toBeInTheDocument();
    });

    it("disables Continue button when isSubmitting is true", () => {
      render(<KeepInMindModal {...defaultProps} isSubmitting={true} />);

      const continueButton = screen.getByRole("button", { name: /Submitting/i });
      expect(continueButton).toBeDisabled();
    });

    it("enables Continue button when isSubmitting is false", () => {
      render(<KeepInMindModal {...defaultProps} isSubmitting={false} />);

      const continueButton = screen.getByRole("button", { name: /Continue/i });
      expect(continueButton).not.toBeDisabled();
    });
  });

  describe("Accessibility", () => {
    it("has proper heading structure", () => {
      render(<KeepInMindModal {...defaultProps} />);

      const heading = screen.getByRole("heading", { level: 2 });
      expect(heading).toHaveTextContent("Keep In Mind");
    });

    it("has accessible continue button", () => {
      render(<KeepInMindModal {...defaultProps} />);

      const continueButton = screen.getByRole("button", { name: /Continue/i });
      expect(continueButton).toBeInTheDocument();
    });

    it("renders in a fixed viewport overlay when portaled", () => {
      render(<KeepInMindModal {...defaultProps} />);

      const dialog = screen.getByRole("dialog", { name: "Keep In Mind" });
      const overlay = dialog.parentElement;

      expect(overlay).toHaveClass("fixed");
      expect(overlay).not.toHaveClass("relative");
      expect(dialog).toHaveClass("z-10");
      expect(dialog).not.toHaveClass("relative");
    });
  });
});
