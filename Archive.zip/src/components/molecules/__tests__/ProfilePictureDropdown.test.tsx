import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ProfilePictureDropdown } from "@/components/molecules/ProfilePictureDropdown";

const mockLogout = jest.fn();
const mockProfile = {
  id: "user-123",
  displayName: "John Doe",
  mail: "john.doe@example.com",
  givenName: "John",
  surname: "Doe",
  photoDataUrl: null as string | null,
};

jest.mock("@/hooks/useProfile", () => ({
  useProfile: () => ({
    profile: mockProfile,
    isLoading: false,
    error: null,
  }),
}));

jest.mock("@/contexts/AuthContext", () => ({
  useAuth: () => ({
    logout: mockLogout,
  }),
}));

describe("ProfilePictureDropdown", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockProfile.displayName = "John Doe";
    mockProfile.mail = "john.doe@example.com";
    mockProfile.givenName = "John";
    mockProfile.photoDataUrl = null;
  });

  describe("Rendering", () => {
    it("renders profile button", () => {
      render(<ProfilePictureDropdown />);

      const button = screen.getByLabelText("User profile menu");
      expect(button).toBeInTheDocument();
    });

    it("renders profile image when photoDataUrl is available", () => {
      mockProfile.photoDataUrl = "data:image/png;base64,test";

      render(<ProfilePictureDropdown />);

      const img = screen.getByAltText("Profile");
      expect(img).toBeInTheDocument();
      expect(img).toHaveAttribute("src", "data:image/png;base64,test");
    });

    it("does not render dropdown menu initially", () => {
      render(<ProfilePictureDropdown />);

      expect(screen.queryByText("john.doe@example.com")).not.toBeInTheDocument();
      expect(screen.queryByText("Sign out")).not.toBeInTheDocument();
    });

    it("renders dropdown menu when opened", async () => {
      render(<ProfilePictureDropdown />);

      const button = screen.getByLabelText("User profile menu");
      await userEvent.click(button);

      expect(screen.getByText("john.doe@example.com")).toBeInTheDocument();
      expect(screen.getByText("Sign out")).toBeInTheDocument();
    });
  });

  describe("Interactions", () => {
    it("toggles dropdown when profile button is clicked", async () => {
      render(<ProfilePictureDropdown />);

      const button = screen.getByLabelText("User profile menu");

      // Open
      await userEvent.click(button);
      expect(screen.getByText("Sign out")).toBeInTheDocument();

      // Close
      await userEvent.click(button);
      expect(screen.queryByText("Sign out")).not.toBeInTheDocument();
    });

    it("calls logout and closes dropdown when sign out is clicked", async () => {
      render(<ProfilePictureDropdown />);

      const button = screen.getByLabelText("User profile menu");
      await userEvent.click(button);

      const signOutButton = screen.getByText("Sign out");
      await userEvent.click(signOutButton);

      expect(mockLogout).toHaveBeenCalledTimes(1);
      expect(screen.queryByText("Sign out")).not.toBeInTheDocument();
    });

    it("closes dropdown when Escape key is pressed", async () => {
      render(<ProfilePictureDropdown />);

      const button = screen.getByLabelText("User profile menu");
      await userEvent.click(button);

      expect(screen.getByText("Sign out")).toBeInTheDocument();

      await userEvent.keyboard("{Escape}");

      expect(screen.queryByText("Sign out")).not.toBeInTheDocument();
    });
  });

  describe("Accessibility", () => {
    it("has correct aria-expanded when closed", () => {
      render(<ProfilePictureDropdown />);

      const button = screen.getByLabelText("User profile menu");
      expect(button).toHaveAttribute("aria-expanded", "false");
    });

    it("has correct aria-expanded when open", async () => {
      render(<ProfilePictureDropdown />);

      const button = screen.getByLabelText("User profile menu");
      await userEvent.click(button);

      expect(button).toHaveAttribute("aria-expanded", "true");
    });

    it("has aria-haspopup attribute", () => {
      render(<ProfilePictureDropdown />);

      const button = screen.getByLabelText("User profile menu");
      expect(button).toHaveAttribute("aria-haspopup", "true");
    });
  });

  describe("Edge Cases", () => {
    it("displays fallback text when no email is available", async () => {
      mockProfile.mail = "";

      render(<ProfilePictureDropdown />);

      const button = screen.getByLabelText("User profile menu");
      await userEvent.click(button);

      expect(screen.getByText("No email")).toBeInTheDocument();
    });
  });
});
