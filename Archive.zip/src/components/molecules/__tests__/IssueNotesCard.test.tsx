import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import { IssueNotesCard } from "../IssueNotesCard";

jest.mock("@/components/molecules/IssueNotesPopover", () => ({
  IssueNotesPopover: () => <div data-testid="issue-notes-popover-stub" />,
}));

jest.mock("@/components/molecules/IssueNotesPagePanel", () => ({
  IssueNotesPagePanel: () => <div data-testid="issue-notes-page-panel-stub" />,
}));

describe("IssueNotesCard", () => {
  it("shows notes_count 0 and empty preview when there is no last_note", () => {
    render(<IssueNotesCard issueBackendId="149" matNbr="M1" ndc="—" hasActions={false} notesCount={0} />);

    expect(screen.getByRole("button", { name: /notes, 0 total/i })).toBeInTheDocument();
    expect(screen.getByText(/no notes yet/i)).toBeInTheDocument();
  });

  it("shows notes_count and embedded last_note preview from GET /issue/", () => {
    render(
      <IssueNotesCard
        issueBackendId="149"
        matNbr="M1"
        ndc="123"
        hasActions={false}
        notesCount={3}
        lastNote={{
          id: "19",
          content: "adding additional note",
          user_id: "f0d457cf-9d69-4be6-b9f9-363b6bd5f8d7",
          user_data: {
            email: "mentor.aliu@example.com",
            first_name: "Mentor",
            last_name: "Aliu",
          },
          created_at: "2026-05-04T11:36:58.416873Z",
          updated_at: "2026-05-04T11:36:58.416887Z",
          is_my_note: false,
        }}
      />
    );

    expect(screen.getByRole("button", { name: /notes, 3 total/i })).toBeInTheDocument();
    expect(screen.getByText("Mentor Aliu")).toBeInTheDocument();
    expect(screen.getByText(/adding additional note/)).toBeInTheDocument();
  });

  it("renders page panel when view is page", () => {
    render(<IssueNotesCard view="page" issueBackendId="149" matNbr="M1" ndc="123" hasActions={false} notesCount={2} />);

    expect(screen.getByTestId("issue-notes-page-panel-stub")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /notes/i })).not.toBeInTheDocument();
  });
});
