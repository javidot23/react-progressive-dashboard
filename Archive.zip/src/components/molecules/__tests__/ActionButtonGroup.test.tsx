import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import ActionButtonGroup from "@/components/molecules/ActionButtonGroup";
import type { MaterialWithIssues, PotentialAction } from "@/lib/types";

jest.mock("@/hooks/useActionFlow", () => ({
  NO_ACTION_TYPE: "no_action_required",
  useActionFlow: () => ({
    modalState: { type: "closed" },
    isSubmittingRationale: false,
    isActionMutationPending: false,
    isRemoveMutationPending: false,
    handleActionClick: jest.fn(),
    handleKeepInMindContinue: jest.fn(),
    handleDecisionRationaleSubmit: jest.fn(),
    handleRemoveClick: jest.fn(),
    handleRemoveConfirm: jest.fn(),
    closeModal: jest.fn(),
  }),
}));

jest.mock("@/contexts/AuthContext", () => ({
  useAuth: () => ({ user: { entra_id: "user-1" } }),
}));

jest.mock("@/lib/materialActionOwnership", () => ({
  isMaterialActionOwner: () => false,
}));

function createPotentialAction(
  overrides: Partial<PotentialAction> & Pick<PotentialAction, "recommendation_type_nbr" | "recommendation">
): PotentialAction {
  return {
    id: 1,
    paction_nbr: "PA-001",
    issue_nbr: "ISS-1",
    action_type: "test",
    recommended_action_flag: true,
    status: null,
    module: "react",
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-01-01T00:00:00Z",
    material: "MAT-1",
    ...overrides,
  };
}

function createMaterial(
  potentialActions: PotentialAction[],
  recordedActions: MaterialWithIssues["open_issues"][number]["actions"] = []
): MaterialWithIssues {
  return {
    id: 1,
    mat_nbr: "MAT-1",
    name: "Test Material",
    risk_rating: 0.5,
    driving_risk: "Operational",
    dollars_at_risk: 1000,
    open_issues: [
      {
        id: 10,
        issue_nbr: "ISS-1",
        issue_id: "10",
        status: "OPEN",
        description: "",
        start_date: "",
        act_required_date: "",
        material: 1,
        created_at: "",
        updated_at: "",
        action_status: "Not Reviewed",
        actions: recordedActions,
        potential_actions: potentialActions,
      },
    ],
  } as unknown as MaterialWithIssues;
}

describe("ActionButtonGroup", () => {
  const potentialActions = [
    createPotentialAction({
      id: 1,
      recommendation_type_nbr: "31",
      recommendation: "Operational action",
      action_category: "Operational",
    }),
    createPotentialAction({
      id: 2,
      recommendation_type_nbr: "32",
      recommendation: "Tactical action",
      action_category: "Tactical",
    }),
    createPotentialAction({
      id: 3,
      recommendation_type_nbr: "33",
      recommendation: "Strategic action",
      action_category: "Strategic",
    }),
    createPotentialAction({
      id: 4,
      recommendation_type_nbr: "34",
      recommendation: "Uncategorized action",
      action_category: null,
    }),
  ];

  it("renders category headers in Tactical, Strategic, Operational order when grouped", () => {
    render(
      <ActionButtonGroup
        material={createMaterial(potentialActions)}
        potentialActions={potentialActions}
        groupByActionCategory
        layout="column"
      />
    );

    expect(screen.getByText("Tactical", { exact: true })).toBeInTheDocument();
    expect(screen.getByText("Strategic", { exact: true })).toBeInTheDocument();
    expect(screen.getByText("Operational", { exact: true })).toBeInTheDocument();
    expect(screen.queryByText("Uncategorized", { exact: true })).not.toBeInTheDocument();

    const content = document.body.textContent ?? "";
    expect(content.indexOf("Tactical")).toBeLessThan(content.indexOf("Strategic"));
    expect(content.indexOf("Strategic")).toBeLessThan(content.indexOf("Operational"));
    expect(content.indexOf("No Action Required")).toBeGreaterThan(content.indexOf("Operational action"));
  });

  it("omits empty category sections", () => {
    const actions = [
      createPotentialAction({
        id: 1,
        recommendation_type_nbr: "31",
        recommendation: "Tactical action",
        action_category: "Tactical",
      }),
      createPotentialAction({
        id: 2,
        recommendation_type_nbr: "32",
        recommendation: "Operational action",
        action_category: "Operational",
      }),
    ];

    render(
      <ActionButtonGroup
        material={createMaterial(actions)}
        potentialActions={actions}
        groupByActionCategory
        layout="column"
      />
    );

    expect(screen.getByText("Tactical", { exact: true })).toBeInTheDocument();
    expect(screen.getByText("Operational", { exact: true })).toBeInTheDocument();
    expect(screen.queryByText("Strategic", { exact: true })).not.toBeInTheDocument();
  });

  it("renders No Action Required once at the bottom when grouped", () => {
    render(
      <ActionButtonGroup
        material={createMaterial(potentialActions)}
        potentialActions={potentialActions}
        groupByActionCategory
        layout="column"
      />
    );

    expect(screen.getAllByText("No Action Required")).toHaveLength(1);
  });

  it("does not render category headers when grouping is disabled", () => {
    render(
      <ActionButtonGroup material={createMaterial(potentialActions)} potentialActions={potentialActions} />
    );

    expect(screen.getByText("Tactical action")).toBeInTheDocument();
    expect(screen.getByText("Strategic action")).toBeInTheDocument();
    expect(screen.getByText("Operational action")).toBeInTheDocument();
    expect(screen.getByText("Uncategorized action")).toBeInTheDocument();
    expect(screen.getByText("No Action Required")).toBeInTheDocument();
    expect(screen.queryByText("Tactical", { exact: true })).not.toBeInTheDocument();
    expect(screen.queryByText("Strategic", { exact: true })).not.toBeInTheDocument();
    expect(screen.queryByText("Operational", { exact: true })).not.toBeInTheDocument();
  });

  it("marks only the actioned paction_nbr as taken when recommendation types duplicate", () => {
    const duplicateTypeActions = [
      createPotentialAction({
        id: 1,
        paction_nbr: "PA-1",
        recommendation_type_nbr: "26",
        recommendation: "Strategic duplicate type",
        action_category: "Strategic",
      }),
      createPotentialAction({
        id: 2,
        paction_nbr: "PA-2",
        recommendation_type_nbr: "26",
        recommendation: "Operational duplicate type",
        action_category: "Operational",
      }),
    ];
    const recordedActions = [
      {
        id: 99,
        action: null,
        created_at: "2026-06-01T10:00:00Z",
        user: { id: "user-1", first_name: "Jane", last_name: "Doe" },
        potential_action: { recommendation_type_nbr: "26", paction_nbr: "PA-2" },
      },
    ] as MaterialWithIssues["open_issues"][number]["actions"];

    render(
      <ActionButtonGroup
        material={createMaterial(duplicateTypeActions, recordedActions)}
        potentialActions={duplicateTypeActions}
        groupByActionCategory
        layout="column"
      />
    );

    const strategicInput = screen.getByLabelText("Strategic duplicate type").closest("label")!.querySelector("input")!;
    const operationalInput = screen
      .getByLabelText("Operational duplicate type")
      .closest("label")!
      .querySelector("input")!;

    expect(strategicInput).not.toBeDisabled();
    expect(strategicInput).not.toBeChecked();
    expect(operationalInput).toBeDisabled();
    expect(operationalInput).toBeChecked();
  });
});
