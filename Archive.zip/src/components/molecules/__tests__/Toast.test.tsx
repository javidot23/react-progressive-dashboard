import "@testing-library/jest-dom";
import { act, fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Toast } from "../Toast";
import type { ToastItem } from "@/stores/toastStore";

const base: Omit<ToastItem, "variant" | "title" | "duration"> = { id: "t1" };

describe("Toast", () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.runOnlyPendingTimers();
    jest.useRealTimers();
  });

  it("renders title and description", () => {
    const onDismiss = jest.fn();
    render(<Toast toast={{ ...base, variant: "info", title: "Hi", description: "Details" }} onDismiss={onDismiss} />);
    expect(screen.getByText("Hi")).toBeInTheDocument();
    expect(screen.getByText("Details")).toBeInTheDocument();
  });

  it("calls onDismiss when close button is clicked", async () => {
    const user = userEvent.setup({ advanceTimers: jest.advanceTimersByTime });
    const onDismiss = jest.fn();
    render(<Toast toast={{ ...base, variant: "success", title: "Ok" }} onDismiss={onDismiss} />);
    await user.click(screen.getByRole("button", { name: /dismiss notification/i }));
    expect(onDismiss).toHaveBeenCalledWith("t1");
  });

  it("auto-dismisses after duration", () => {
    const onDismiss = jest.fn();
    render(<Toast toast={{ ...base, variant: "info", title: "T", duration: 3000 }} onDismiss={onDismiss} />);
    jest.advanceTimersByTime(2999);
    expect(onDismiss).not.toHaveBeenCalled();
    jest.advanceTimersByTime(1);
    expect(onDismiss).toHaveBeenCalledWith("t1");
  });

  it("pauses auto-dismiss on mouse enter and resumes on leave", () => {
    const onDismiss = jest.fn();
    const { container } = render(
      <Toast toast={{ ...base, variant: "info", title: "T", duration: 1000 }} onDismiss={onDismiss} />
    );
    const root = container.firstChild as HTMLElement;
    act(() => {
      fireEvent.mouseEnter(root);
    });
    jest.advanceTimersByTime(5000);
    expect(onDismiss).not.toHaveBeenCalled();
    act(() => {
      fireEvent.mouseLeave(root);
    });
    jest.advanceTimersByTime(1000);
    expect(onDismiss).toHaveBeenCalledWith("t1");
  });

  it("does not auto-dismiss when duration is 0", () => {
    const onDismiss = jest.fn();
    render(<Toast toast={{ ...base, variant: "info", title: "Sticky", duration: 0 }} onDismiss={onDismiss} />);
    jest.advanceTimersByTime(60_000);
    expect(onDismiss).not.toHaveBeenCalled();
  });

  it("error variant uses alert and assertive live region", () => {
    render(<Toast toast={{ ...base, variant: "error", title: "E" }} onDismiss={jest.fn()} />);
    expect(screen.getByRole("alert")).toBeInTheDocument();
    expect(screen.getByRole("alert")).toHaveAttribute("aria-live", "assertive");
  });

  it("success variant uses status and polite live region", () => {
    render(<Toast toast={{ ...base, variant: "success", title: "S" }} onDismiss={jest.fn()} />);
    expect(screen.getByRole("status")).toBeInTheDocument();
    expect(screen.getByRole("status")).toHaveAttribute("aria-live", "polite");
  });

  it("runs action onClick then dismisses", async () => {
    const user = userEvent.setup({ advanceTimers: jest.advanceTimersByTime });
    const onAction = jest.fn();
    const onDismiss = jest.fn();
    render(
      <Toast
        toast={{
          ...base,
          variant: "info",
          title: "Act",
          action: { label: "Undo", onClick: onAction },
        }}
        onDismiss={onDismiss}
      />
    );
    await user.click(screen.getByRole("button", { name: "Undo" }));
    expect(onAction).toHaveBeenCalled();
    expect(onDismiss).toHaveBeenCalledWith("t1");
  });

  it("Escape dismisses when toast root has focus", async () => {
    const user = userEvent.setup({ advanceTimers: jest.advanceTimersByTime });
    const onDismiss = jest.fn();
    const { container } = render(<Toast toast={{ ...base, variant: "info", title: "K" }} onDismiss={onDismiss} />);
    const root = container.firstChild as HTMLElement;
    root.focus();
    await user.keyboard("{Escape}");
    expect(onDismiss).toHaveBeenCalledWith("t1");
  });
});
