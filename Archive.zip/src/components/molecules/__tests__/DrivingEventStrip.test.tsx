import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import { DrivingEventStrip } from "@/components/molecules/DrivingEventStrip";
import type { DrivingEvent } from "@/types/granularityIssue";

const baseEvent: DrivingEvent = {
  id: 1,
  event_id: "EVT-1",
  type: "Hurricane",
  type_description: "Category 4 storm approaching Gulf Coast",
  status: "ACTIVE",
  start_date: "2026-01-01",
  end_date: null,
  latitude: null,
  longitude: null,
  city: "Miami",
  state: "FL",
  country: "USA",
  mat_nbr: null,
  metadata: null,
  scrm_mat_grp: null,
};

describe("DrivingEventStrip", () => {
  it("renders structured event details with a human-readable status pill", () => {
    render(<DrivingEventStrip event={baseEvent} />);

    expect(screen.getByTestId("driving-event-strip")).toBeInTheDocument();
    expect(screen.getByText("Hurricane")).toBeInTheDocument();
    expect(screen.getByText("Active")).toBeInTheDocument();
    expect(screen.getByText("Category 4 storm approaching Gulf Coast")).toBeInTheDocument();
    expect(screen.getByText("Miami, FL, USA")).toBeInTheDocument();
    expect(screen.getByText("EVT-1")).toBeInTheDocument();
    expect(screen.getByText(/Ongoing/)).toBeInTheDocument();
  });

  it("renders a driving-risk fallback when there is no linked event", () => {
    render(<DrivingEventStrip drivingRisk="Supply disruption" />);

    expect(screen.getByTestId("driving-risk-fallback")).toBeInTheDocument();
    expect(screen.getByText("Driving risk: Supply disruption")).toBeInTheDocument();
    expect(screen.getByText("No linked supply chain event")).toBeInTheDocument();
  });

  it("renders nothing when there is neither an event nor a driving risk", () => {
    const { container } = render(<DrivingEventStrip />);
    expect(container).toBeEmptyDOMElement();
  });
});
