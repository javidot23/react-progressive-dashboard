import { render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import VendorCardView from '@/components/molecules/VendorCardView';

// Mock the chart components
jest.mock("../VendorBarChartCard", () => {
  return function MockBarChart() {
    return <div data-testid="bar-chart">Bar Chart</div>;
  };
});

jest.mock("../VendorLineChart", () => {
  return function MockLineChart() {
    return <div data-testid="line-chart">Line Chart</div>;
  };
});

jest.mock("@/hooks", () => ({
  useRiskModelDescriptions: () => ({
    getEnrichedMetadata: (risk: string) => ({
      display_name: risk || "",
      original_risk_type: risk,
      risk_type: risk,
      risk_description: risk,
    }),
  }),
}));

const mockVendor = {
  id: 1,
  name: "Test Vendor",
  vendor_nbr: "V001",
  city: "New York",
  country: "USA",
  risk_rating: 0.75,
  driving_risk: "Operational",
  risk_adjusted_value: 100000,
  sales_amount: 50000,
  sales_volume: 1000,
  materials_at_risk: 5,
  total_materials: 10,
  latitude: 40.7128,
  longitude: -74.0060,
  created_at: "2024-01-01",
  updated_at: "2024-01-01",
  service_levels_90_days: [
    { date: "2024-01-01", avg_fill_rate: 0.95, total_order_qty: 1000, total_received_qty: 950 },
    { date: "2024-01-02", avg_fill_rate: 0.92, total_order_qty: 1000, total_received_qty: 920 },
  ],
};

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <BrowserRouter>{children}</BrowserRouter>
);

describe("VendorCardView", () => {

  it("displays risk score correctly", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByText("75.00 / 100")).toBeInTheDocument();
  });

  it("displays primary risk", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByText("Operational")).toBeInTheDocument();
  });

  it("displays fill rate trend title", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByText("Fill Rate Trend 90 Days")).toBeInTheDocument();
  });

  it("displays risk score title", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByText("Risk Score")).toBeInTheDocument();
  });

  it("displays primary risk title", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByText("Driving Risk")).toBeInTheDocument();
  });

  it("displays risk adjusted value title", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByText("Risk Adjusted Value")).toBeInTheDocument();
  });

  it("displays material at risk title", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByText("Materials at Risk")).toBeInTheDocument();
  });

  it("displays material at risk value", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByText("5 / 10")).toBeInTheDocument();
  });

  it("renders chart components", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByTestId("line-chart")).toBeInTheDocument();
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument();
  });

  it("displays risk badge", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    // Risk rating 0.75 should show "Likely"
    expect(screen.getByText("Likely")).toBeInTheDocument();
  });

  it("handles vendor with no service levels", () => {
    const vendorWithoutServiceLevels = {
      ...mockVendor,
      service_levels_90_days: [],
    };

    render(
      <TestWrapper>
        <VendorCardView vendor={vendorWithoutServiceLevels} />
      </TestWrapper>
    );

    expect(screen.getByText("AVG 93.40%")).toBeInTheDocument();
  });

  it("handles vendor with no risk adjusted value", () => {
    const vendorWithoutRiskValue = {
      ...mockVendor,
      risk_adjusted_value: 0,
    };

    render(
      <TestWrapper>
        <VendorCardView vendor={vendorWithoutRiskValue} />
      </TestWrapper>
    );

    // Find the Risk Adjusted Value title
    const riskAdjustedValueTitle = screen.getByText("Risk Adjusted Value");
    // Find the parent card container by traversing up
    let cardContainer = riskAdjustedValueTitle.parentElement;
    while (cardContainer && !cardContainer.className.includes("bg-[#F5F5F5]")) {
      cardContainer = cardContainer.parentElement;
    }

    // Find all "- / -" elements and check which one is in the Risk Adjusted Value card
    const allDashElements = screen.getAllByText("- / -");
    const riskAdjustedValueElement = allDashElements.find(element =>
      cardContainer?.contains(element)
    );

    expect(riskAdjustedValueElement).toBeInTheDocument();
  });

  it("displays sales amount and total sales", () => {
    render(
      <TestWrapper>
        <VendorCardView vendor={mockVendor} />
      </TestWrapper>
    );

    expect(screen.getByText("$50.00K / 1.00K")).toBeInTheDocument();
  });
});
