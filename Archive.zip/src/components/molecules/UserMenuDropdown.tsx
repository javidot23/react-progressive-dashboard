import React, { useState, useRef, useEffect, useLayoutEffect } from "react";
import { Download, Eye } from "lucide-react";
import { Link } from "react-router-dom";
import { useIsMobile } from "@/hooks/useMobile";
import { userActionService, UserAction } from "@/lib/apiServices";
import { ROUTES } from "@/constants/routes";

interface UserMenuDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  triggerRef: React.RefObject<HTMLButtonElement | null>;
}

const getTodayDate = (): string => {
  return new Date().toISOString().split("T")[0];
};

const formatActionDate = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "a few moments ago";
  if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? "s" : ""} ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
  if (diffDays === 1) return "yesterday";
  if (diffDays < 7) return `${diffDays} days ago`;

  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
};

const getActionText = (action: UserAction): string => {
  if (action.substituted_material) {
    const fromVendor = `${action.vendor_name}${action.vendor_nbr ? ` • ${action.vendor_nbr}` : ''}`;
    const toVendor = `${action.substituted_material.vendor_name}${action.substituted_material.vendor_nbr ? ` • ${action.substituted_material.vendor_nbr}` : ''}`;
    return `You've switched Manufacturer from ${fromVendor} to ${toVendor}`;
  }
  if (action.potential_action) {
    return `You've ${action.potential_action.recommendation} for ${action.material_name}`;
  }
  if (action.action === "no_action") {
    return `You've selected No Action Required for ${action.material_name}`;
  }
  return `You've performed an action for ${action.material_name}`;
};

const LIMIT = 10;

export function UserMenuDropdown({ isOpen, onClose, triggerRef }: UserMenuDropdownProps) {
  const dropdownRef = useRef<HTMLDivElement>(null);
  const isFetchingRef = useRef(false);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 72, right: 16 });
  const [isPositioned, setIsPositioned] = useState(false);
  const isMobile = useIsMobile();
  const [activityItems, setActivityItems] = useState<UserAction[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [offset, setOffset] = useState(0);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useLayoutEffect(() => {
    if (isOpen && triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      setDropdownPosition({
        top: rect.bottom + 8,
        right: isMobile ? 16 : window.innerWidth - rect.right,
      });
      setIsPositioned(true);
    } else {
      setIsPositioned(false);
    }
  }, [isOpen, isMobile, triggerRef]);

  useEffect(() => {
    if (!isOpen) return;

    const fetchInitialActions = async () => {
      if (isFetchingRef.current) return;

      isFetchingRef.current = true;
      setLoading(true);
      setError(null);
      setActivityItems([]);
      setOffset(0);
      setHasMore(true);

      try {
        const response = await userActionService.getUserActions(LIMIT, 0, getTodayDate());

        if (response.data.success && response.data.data) {
          setActivityItems(response.data.data.results);
          setOffset(LIMIT);
          setHasMore(response.data.data.next !== null);
        }
      } catch (err) {
        console.error("Error fetching user actions:", err);
        setError("Failed to load actions. Please try again.");
      } finally {
        setLoading(false);
        isFetchingRef.current = false;
      }
    };

    fetchInitialActions();
  }, [isOpen]);

  const handleScroll = async (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    const isNearBottom = scrollTop + clientHeight >= scrollHeight - 10;

    if (!isNearBottom || !hasMore || loading || isFetchingRef.current) return;

    isFetchingRef.current = true;
    setLoading(true);

    try {
      const response = await userActionService.getUserActions(LIMIT, offset, getTodayDate());

      if (response.data.success && response.data.data) {
        setActivityItems(prev => [...prev, ...response.data.data.results]);
        setOffset(prev => prev + LIMIT);
        setHasMore(response.data.data.next !== null);
      }
    } catch (err) {
      console.error("Error fetching more actions:", err);
    } finally {
      setLoading(false);
      isFetchingRef.current = false;
    }
  };

  const handleExport = async () => {
    if (exporting) return;

    setExporting(true);
    try {
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const todayStr = today.toISOString().split("T")[0];
      const tomorrowStr = tomorrow.toISOString().split("T")[0];

      const response = await userActionService.exportUserActions(todayStr, tomorrowStr);

      const blob = new Blob([response.data], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `actions_${todayStr}_to_${tomorrowStr}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Error exporting:", err);
      alert("Failed to export actions. Please try again.");
    } finally {
      setExporting(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        triggerRef.current &&
        !triggerRef.current.contains(event.target as Node)
      ) {
        onClose();
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };

    const handleScrollClose = () => {
      if (isMobile) onClose();
    };

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEscape);
    if (isMobile) {
      window.addEventListener("scroll", handleScrollClose, { passive: true });
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
      if (isMobile) {
        window.removeEventListener("scroll", handleScrollClose);
      }
    };
  }, [isOpen, onClose, triggerRef, isMobile]);

  if (!isOpen || !isPositioned) return null;

  return (
    <div
      ref={dropdownRef}
      className="bg-ui-background-primary rounded-lg shadow-xl border border-ui-border-primary"
      style={
        isMobile
          ? {
              position: "fixed",
              top: `${dropdownPosition.top}px`,
              left: "16px",
              right: "16px",
              width: "calc(100vw - 32px)",
              maxHeight: "70vh",
              zIndex: 50,
              transform: "translate3d(0, 0, 0)",
              WebkitTransform: "translate3d(0, 0, 0)",
            }
          : {
              position: "fixed",
              top: `${dropdownPosition.top}px`,
              right: `${dropdownPosition.right}px`,
              width: "400px",
              maxHeight: "500px",
              zIndex: 50,
            }
      }
      role="dialog"
      aria-label="User action log"
    >
      <div
        className={`px-4 md:px-6 h-9 border-b border-ui-border-primary flex items-center justify-between ${isMobile ? "flex-col gap-2 py-2 h-auto" : ""}`}
      >
        <h3 className="text-base font-medium text-gray-900">User Action Log</h3>
        <button
          className={`flex items-center space-x-1 px-3 h-6 bg-white border-2 border-true-blue-700 text-true-blue-700 rounded text-sm font-medium hover:bg-true-blue-50 transition-colors ${isMobile ? "w-full justify-center" : ""} ${exporting ? "opacity-50 cursor-not-allowed" : ""}`}
          onClick={handleExport}
          disabled={exporting}
          aria-label="Export user actions as CSV"
        >
          <Download className="h-4 w-4" />
          <span>{exporting ? "Exporting..." : "Export"}</span>
        </button>
      </div>
      <div className={`py-2 max-h-80 overflow-y-auto ${isMobile ? "max-h-60" : ""}`} onScroll={handleScroll} role="list">
        {error ? (
          <div className="px-4 md:px-6 py-8 text-center text-sm text-red-600">{error}</div>
        ) : activityItems.length === 0 && !loading ? (
          <div className="px-4 md:px-6 py-8 text-center text-sm text-ui-text-secondary">No actions taken today</div>
        ) : (
          <>
            {activityItems.map(item => (
              <div
                key={item.id}
                className={`px-4 md:px-6 py-4 hover:bg-ui-background-muted transition-colors border-b border-ui-border-primary last:border-b-0 ${isMobile ? "py-3" : ""}`}
                role="listitem"
              >
                <div className="space-y-1">
                  <p className="text-sm font-medium text-ui-text-primary leading-relaxed">{getActionText(item)}</p>
                  <p className="text-xs font-medium text-brand-primary-main">{formatActionDate(item.created_at)}</p>
                </div>
              </div>
            ))}
            {loading && <div className="px-4 md:px-6 py-4 text-center text-sm text-ui-text-secondary">Loading...</div>}
          </>
        )}
      </div>
      <div
        className={`px-4 md:px-6 h-9 border-t border-ui-border-primary flex items-center justify-center ${isMobile ? "py-3 h-auto" : ""}`}
      >
        <Link
          to={ROUTES.EXPORT_ACTIONS}
          onClick={onClose}
          className={`flex items-center space-x-2 text-sm font-medium text-ui-text-secondary hover:text-ui-text-primary transition-colors no-underline ${isMobile ? "w-full py-2 justify-center" : ""}`}
        >
          <Eye className="h-4 w-4" />
          <span>View More</span>
        </Link>
      </div>
    </div>
  );
}
