import { Pagination } from "@/components/atoms";
import type { FtsMaterialRow } from "@/lib/apiServices";
import { formatFtsSalesAmount } from "@/utils/ftsMitigation";
import { useMemo } from "react";

/** Chevron + control styling aligned with DCMissedLinesTable (distribution center name cell). */
const dcMissedLinesChevronBtnClass =
  "inline-flex shrink-0 p-0 m-0 border-0 bg-transparent text-inherit cursor-pointer rounded-sm focus:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-1";

function DcMissedLinesChevronSvg() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      strokeWidth={2}
      stroke="currentColor"
      className="w-4 h-4"
      aria-hidden
    >
      <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
    </svg>
  );
}

function avgPct(points: { value: number }[] | undefined): number | null {
  if (!points || points.length === 0) return null;
  const sum = points.reduce((acc, p) => acc + (typeof p.value === "number" ? p.value : 0), 0);
  return sum / points.length;
}

/** Match Plan / Vendor table style: "AVG 93.4%" */
function fmtAvgCell(value: number | null): string {
  if (value === null || Number.isNaN(value)) return "—";
  return `AVG ${value.toFixed(2)}%`;
}

function displayNdc(material: FtsMaterialRow): string {
  const raw = (material.material_ndc ?? material.ndc)?.trim();
  return raw ? raw : "—";
}

function latestTrendDateIso(material: FtsMaterialRow): string {
  const dates: string[] = [];
  for (const arr of [
    material.prxo_service_level_trend,
    material.pharmagen_service_level_trend,
    material.total_service_level_trend,
    material.fill_rate_trend,
  ]) {
    for (const p of arr ?? []) {
      if (p?.date) dates.push(p.date);
    }
  }
  if (dates.length === 0) return "";
  const sorted = [...dates].sort();
  return sorted[sorted.length - 1]!;
}

function formatAsOfDate(iso: string): string {
  if (!iso) return "—";
  const d = new Date(`${iso}T12:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

interface FTSMaterialTableViewProps {
  data: FtsMaterialRow[];
  currentPage: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  /** When false, page size is fixed (e.g. 10 rows enforced by the API). */
  showPageSizeSelect?: boolean;
  /** Passed to Pagination when `showPageSizeSelect` is true (e.g. `[25, 50]` for FTS materials). */
  pageSizeOptions?: number[];
  onMaterialSelect?: (matNbr: string) => void;
  /** Selects material and scrolls to DC Missed Lines (arrow next to name). */
  onOpenDcMissedLines?: (matNbr: string) => void;
  selectedMatNbr?: string | null;
  /** True while fetching more pages into `data` (e.g. user opened a table page not yet loaded). */
  isPageLoading?: boolean;
}

const COL_COUNT = 10;

export default function FTSMaterialTableView({
  data,
  currentPage,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  showPageSizeSelect = true,
  pageSizeOptions,
  onMaterialSelect,
  onOpenDcMissedLines,
  selectedMatNbr,
  isPageLoading = false,
}: FTSMaterialTableViewProps) {
  const rowsOnPage = useMemo(
    () => data.slice((currentPage - 1) * pageSize, currentPage * pageSize),
    [data, currentPage, pageSize]
  );

  const pageOffset = (currentPage - 1) * pageSize;
  const emptyRowLabel =
    rowsOnPage.length > 0
      ? null
      : total === 0
        ? "No data"
        : pageOffset >= total
          ? "No data"
          : isPageLoading
            ? "Loading materials…"
            : "No data";

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm text-left">
          <thead className="font-bold text-ui-text-primary">
            <tr>
              <th className="px-4 py-2 text-nowrap">Material Name</th>
              <th className="px-4 py-2 text-nowrap">Material Id</th>
              <th className="px-4 py-2 text-nowrap">NDC</th>
              <th className="px-4 py-2 text-nowrap">Date</th>
              <th className="px-4 py-2 text-nowrap">PRxO Service Level</th>
              <th className="px-4 py-2 text-nowrap">PharmaGen Service Level</th>
              <th className="px-4 py-2 text-nowrap">Total Service Level</th>
              <th className="px-4 py-2 text-nowrap">Outbound Fill Rate</th>
              <th className="px-4 py-2 text-nowrap">Omits</th>
              <th className="px-4 py-2 text-nowrap">Sales</th>
            </tr>
          </thead>
          <tbody>
            {rowsOnPage.map(material => (
              <tr
                key={material.mat_nbr}
                className={`border-t hover:bg-brand-primary-50 ${onMaterialSelect || onOpenDcMissedLines ? "cursor-pointer" : ""} ${
                  selectedMatNbr === material.mat_nbr ? "bg-brand-primary-50" : ""
                }`}
                onClick={() => (onOpenDcMissedLines ?? onMaterialSelect)?.(material.mat_nbr)}
                role={onMaterialSelect || onOpenDcMissedLines ? "button" : undefined}
                tabIndex={onMaterialSelect || onOpenDcMissedLines ? 0 : undefined}
              >
                <td className="px-4 py-2 font-medium text-ui-text-primary text-nowrap">
                  <span className="flex items-center gap-1">
                    {material.material_name}
                    {onOpenDcMissedLines && (
                      <button
                        type="button"
                        className={dcMissedLinesChevronBtnClass}
                        aria-label="Open DC Missed Lines for this material"
                        title="Open DC Missed Lines"
                        onClick={e => {
                          e.stopPropagation();
                          onOpenDcMissedLines(material.mat_nbr);
                        }}
                      >
                        <DcMissedLinesChevronSvg />
                      </button>
                    )}
                  </span>
                </td>
                <td className="px-4 py-2 text-nowrap">{material.mat_nbr}</td>
                <td className="px-4 py-2 text-nowrap">{displayNdc(material)}</td>
                <td className="px-4 py-2 text-nowrap">{formatAsOfDate(latestTrendDateIso(material))}</td>
                <td className="px-4 py-2 text-nowrap">{fmtAvgCell(avgPct(material.prxo_service_level_trend))}</td>
                <td className="px-4 py-2 text-nowrap">{fmtAvgCell(avgPct(material.pharmagen_service_level_trend))}</td>
                <td className="px-4 py-2 text-nowrap">{fmtAvgCell(avgPct(material.total_service_level_trend))}</td>
                <td className="px-4 py-2 text-nowrap">{fmtAvgCell(avgPct(material.fill_rate_trend))}</td>
                <td className="px-4 py-2 text-nowrap">{material.omits_qty.toLocaleString()}</td>
                <td className="px-4 py-2 text-nowrap font-semibold">{formatFtsSalesAmount(material.sales_amount)}</td>
              </tr>
            ))}
            {emptyRowLabel !== null && (
              <tr>
                <td colSpan={COL_COUNT} className="px-4 py-6 text-center text-ui-text-secondary">
                  {emptyRowLabel}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Pagination
        currentPage={currentPage}
        pageSize={pageSize}
        total={total}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        showPageSizeSelect={showPageSizeSelect}
        pageSizeOptions={pageSizeOptions}
        itemName="Materials"
      />
    </div>
  );
}
