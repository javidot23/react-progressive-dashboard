interface LazyLoaderProps {
  className?: string;
  lines?: number;
}

export const LazyLoader = ({className = "", lines = 3}: LazyLoaderProps) => {
  return (
    <div
      className={`space-y-3 w-full animate-pulse ${className}`}
      role="status"
      aria-label="Loading content"
    >
      {Array.from({length: lines}).map((_, idx) => (
        <div
          key={idx}
          className="h-4 rounded bg-ui-background-hover w-full"
          style={{width: `${90 - idx * 10}%`}}
        />
      ))}
    </div>
  );
};

export default LazyLoader;
