export default function ManagePagePlaceholder() {
  return (
    <div className="p-6 text-center text-gray-500">
      <h2 className="text-2xl font-semibold mb-2">Manage</h2>
      <p className="text-lg">This page will be implemented soon.</p>
    </div>
  );
}
