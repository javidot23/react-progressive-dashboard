import { memo, useCallback, useEffect, useRef, useState } from "react";
import { AlertTriangle, CheckCircle2, Info, X, XCircle } from "lucide-react";
import type { ToastItem } from "@/stores/toastStore";

export interface ToastProps {
  toast: ToastItem;
  onDismiss: (id: string) => void;
}

type VariantStyleEntry = {
  icon: typeof CheckCircle2;
  container: string;
  iconClass: string;
  actionClass: string;
  dismissHoverClass: string;
};

const variantStyles: Record<ToastItem["variant"], VariantStyleEntry> = {
  success: {
    icon: CheckCircle2,
    container: "border-border-success bg-background-success-secondary text-text-success shadow-status-success",
    iconClass: "text-status-success-600 shrink-0",
    actionClass: "text-text-success",
    dismissHoverClass: "transition-colors hover:bg-success-700/15",
  },
  error: {
    icon: XCircle,
    container: "border-border-danger bg-background-danger-secondary text-text-danger shadow-status-error",
    iconClass: "text-status-error-main shrink-0",
    actionClass: "text-text-danger",
    dismissHoverClass: "transition-colors hover:bg-danger-600/15",
  },
  warning: {
    icon: AlertTriangle,
    container: "border-border-warning bg-background-warning-secondary text-text-warning shadow-status-warning",
    iconClass: "text-status-warning-accent shrink-0",
    actionClass: "text-text-warning",
    dismissHoverClass: "transition-colors hover:bg-warning-700/18",
  },
  info: {
    icon: Info,
    container: "border-border-brand-secondary bg-background-highlight-secondary text-text-highlight shadow-status-info",
    iconClass: "text-status-info-main shrink-0",
    actionClass: "text-text-highlight",
    dismissHoverClass: "transition-colors hover:bg-highlight-600/15",
  },
};

function ToastInner({ toast: t, onDismiss }: ToastProps) {
  const [paused, setPaused] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const styles = variantStyles[t.variant];
  const Icon = styles.icon;

  const clearTimer = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  }, []);

  const scheduleDismiss = useCallback(() => {
    clearTimer();
    const duration = t.duration ?? 0;
    if (duration <= 0) return;
    timeoutRef.current = setTimeout(() => {
      onDismiss(t.id);
    }, duration);
  }, [clearTimer, onDismiss, t.duration, t.id]);

  useEffect(() => {
    if (!paused) {
      scheduleDismiss();
    } else {
      clearTimer();
    }
    return clearTimer;
  }, [paused, scheduleDismiss, clearTimer]);

  const handleDismiss = useCallback(() => {
    onDismiss(t.id);
  }, [onDismiss, t.id]);

  const isAssertive = t.variant === "error" || t.variant === "warning";

  return (
    <div
      tabIndex={-1}
      role={isAssertive ? "alert" : "status"}
      aria-live={isAssertive ? "assertive" : "polite"}
      aria-atomic="true"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={e => {
        if (!e.currentTarget.contains(e.relatedTarget as Node | null)) {
          setPaused(false);
        }
      }}
      onKeyDown={e => {
        if (e.key === "Escape") {
          e.preventDefault();
          handleDismiss();
        }
      }}
      className={`pointer-events-auto flex w-full max-w-sm gap-3 rounded-lg border p-4 transition motion-reduce:transition-none ${styles.container}`}
    >
      <Icon className={`h-5 w-5 ${styles.iconClass}`} aria-hidden />
      <div className="min-w-0 flex-1">
        <p className="font-semibold leading-tight">{t.title}</p>
        {t.description ? <p className="mt-1 text-sm leading-snug wrap-break-word">{t.description}</p> : null}
        {t.action ? (
          <button
            type="button"
            onClick={() => {
              t.action?.onClick();
              handleDismiss();
            }}
            className={`mt-2 text-sm font-semibold ${styles.actionClass} rounded-sm underline-offset-2 hover:underline focus:outline-hidden focus-visible:ring-2 focus-visible:ring-ui-border-focus`}
          >
            {t.action.label}
          </button>
        ) : null}
      </div>
      <button
        type="button"
        onClick={handleDismiss}
        className={`shrink-0 rounded-sm p-1 text-ui-text-secondary ${styles.dismissHoverClass} focus:outline-hidden focus-visible:ring-2 focus-visible:ring-ui-border-focus`}
        aria-label="Dismiss notification"
      >
        <X className="h-4 w-4" aria-hidden />
      </button>
    </div>
  );
}

export const Toast = memo(ToastInner);
Toast.displayName = "Toast";
