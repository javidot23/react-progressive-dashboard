import React, { useState, useMemo, useEffect } from "react";
import { Card, CardContent } from "@/components/atoms/Card";
import { Input } from "@/components/atoms/Input";
import { Button } from "@/components/atoms/Button";
import { Modal } from "@/components/atoms/Modal";
import glossaryCsv from "@/assets/glossary/stratium_glossary.csv?raw";
import { Header } from "@/components/organisms";
import { useIsMobile } from "@/hooks/useMobile";
import SearchIcon from "@/assets/icons/search-primary.svg";
import glossaryBanner from "@/assets/images/glossary_banner.jpg";
import { Footer } from "@/components/atoms";
import { useLocation } from "react-router-dom";

interface GlossaryItem {
  fieldName: string;
  module: string;
  tab: string;
  fullName: string;
  definition: string;
  logicFormula: string;
  allowedValues: string;
  dataOwner: string;
  dataSteward: string;
  dataInputs: string;
  sourceOfDataInputs: string;
}

const hasAdditionalInfo = (item: GlossaryItem): boolean =>
  Boolean(item.logicFormula?.trim() || item.allowedValues?.trim());

function parseCSV(csvText: string): GlossaryItem[] {
  const items: GlossaryItem[] = [];
  const lines = csvText.split("\n");
  const expectedColumns = 15;

  const cleanString = (str: string): string => {
    return str.replace(/\uFFFD/g, '"');
  };

  let i = 1;
  let currentRow: string[] = [];
  let currentField = "";
  let inQuotedField = false;

  while (i < lines.length) {
    const line = lines[i];
    const isLastLine = i === lines.length - 1;

    for (let j = 0; j < line.length; j++) {
      const char = line[j];
      const nextChar = j < line.length - 1 ? line[j + 1] : null;

      if (char === '"') {
        if (nextChar === '"') {
          currentField += '"';
          j++;
        } else {
          inQuotedField = !inQuotedField;
        }
      } else if (char === "," && !inQuotedField) {
        currentRow.push(currentField.trim());
        currentField = "";
      } else {
        currentField += char;
      }
    }

    if (inQuotedField) {
      currentField += "\n";
    } else {
      if (currentField.trim() || currentRow.length > 0) {
        currentRow.push(currentField.trim());
        currentField = "";
      }

      const nextLine = !isLastLine ? lines[i + 1] : "";
      const looksLikeNewRecord = nextLine.trim() && /^[A-Z][^,]*,[^,]*/.test(nextLine.trim());

      if (currentRow.length >= expectedColumns || looksLikeNewRecord || isLastLine) {
        while (currentRow.length < expectedColumns) {
          currentRow.push("");
        }

        if (currentRow[0]) {
          const item: GlossaryItem = {
            fieldName: currentRow[0] || "",
            module: currentRow[1] || "",
            tab: currentRow[2] || "",
            fullName: currentRow[3] || "",
            definition: cleanString(currentRow[8] || ""),
            logicFormula: currentRow[9] || "",
            allowedValues: currentRow[10] || "",
            dataOwner: currentRow[11] || "",
            dataSteward: currentRow[12] || "",
            dataInputs: currentRow[13] || "",
            sourceOfDataInputs: currentRow[14] || "",
          };

          if (item.fieldName) {
            items.push(item);
          }
        }

        currentRow = [];
      } else {
        currentField += "\n";
      }
    }

    i++;
  }

  return items;
}

type NavItem = "All" | "Overview" | "React" | "Manage" | "Plan";
type AlphabetLetter =
  | "ALL"
  | "A"
  | "B"
  | "C"
  | "D"
  | "E"
  | "F"
  | "G"
  | "H"
  | "I"
  | "J"
  | "K"
  | "L"
  | "M"
  | "N"
  | "O"
  | "P"
  | "Q"
  | "R"
  | "S"
  | "T"
  | "U"
  | "V"
  | "W"
  | "X"
  | "Y"
  | "Z";

const getNavItemFromPath = (pathname?: string): NavItem => {
  if (!pathname) return "All";

  const path = pathname.toLowerCase();
  if (path.startsWith("/manage")) return "Manage";
  if (path.startsWith("/react")) return "React";
  if (path.startsWith("/plan")) return "Plan";
  if (path.startsWith("/overview") || path === "/overview") return "Overview";

  return "All";
};

export const Glossary: React.FC = () => {
  const { state } = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedItem, setSelectedItem] = useState<GlossaryItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [glossaryItems, setGlossaryItems] = useState<GlossaryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeNavItem, setActiveNavItem] = useState<NavItem>(() => getNavItemFromPath((state as { from?: string })?.from));
  const [activeLetter, setActiveLetter] = useState<AlphabetLetter>("ALL");
  const isMobile = useIsMobile();

  useEffect(() => {
    try {
      const items = parseCSV(glossaryCsv);
      setGlossaryItems(items);
      setIsLoading(false);
    } catch (error) {
      console.error("Error parsing glossary CSV:", error);
      setIsLoading(false);
    }
  }, []);

  const filteredItems = useMemo(() => {
    let filtered = glossaryItems;

    // Filter by active nav item
    if (activeNavItem !== "All") {
      const navItemLower = activeNavItem.toLowerCase();
      filtered = filtered.filter(
        item => item.module.toLowerCase().includes(navItemLower) || item.tab.toLowerCase().includes(navItemLower)
      );
    }

    // Filter by alphabet letter
    if (activeLetter !== "ALL") {
      const letterLower = activeLetter.toLowerCase();
      filtered = filtered.filter(item => {
        const firstChar = item.fieldName.charAt(0).toLowerCase();
        return firstChar === letterLower;
      });
    }

    // Filter by search term
    if (searchTerm.trim()) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(
        item =>
          item.fieldName.toLowerCase().includes(searchLower) ||
          item.definition.toLowerCase().includes(searchLower) ||
          item.module.toLowerCase().includes(searchLower) ||
          item.tab.toLowerCase().includes(searchLower) ||
          (item.fullName && item.fullName.toLowerCase().includes(searchLower))
      );
    }

    return filtered;
  }, [glossaryItems, searchTerm, activeNavItem, activeLetter]);

  const handleReadMore = (item: GlossaryItem) => {
    setSelectedItem(item);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedItem(null);
  };

  if (isLoading) {
    return (
      <div className="bg-white border border-ui-border-primary rounded-md p-4 md:p-6 min-h-[400px] lg:min-h-[720px]">
        <div className="text-center py-8">
          <p className="text-ui-text-secondary">Loading glossary...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <div className="w-full h-[100px] bg-[url('/src/assets/images/banner.svg')] bg-no-repeat bg-cover bg-center">
        <div className="h-full max-w-(--breakpoint-2xl) mx-auto flex items-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl md:text-3xl font-bold text-white">Glossary</h1>
        </div>
      </div>
      <div className="flex-1 w-full max-w-(--breakpoint-2xl) mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-center py-8">
          The Glossary serves as a centralized reference for key terms, concepts, and abbreviations used across the platform.
        </h2>
        <div className="bg-white border border-[#E2E8F0] rounded-[10px] p-4 md:p-6 min-h-[400px] lg:min-h-[720px] relative">
          <div
            className={`w-full border-b border-neutral-200 bg-[#F8FAFC] sticky top-[83px] z-9997 rounded-t-[16px] ${isMobile ? "overflow-visible" : ""}`}
          >
            <nav
              role="navigation"
              aria-label="Glossary navigation"
              className={`relative flex items-center justify-center pr-4 overflow-x-auto scrollbar-hide md:overflow-x-auto lg:overflow-visible`}
              style={{
                scrollbarWidth: "none",
                msOverflowStyle: "none",
                WebkitOverflowScrolling: "touch",
              }}
            >
              <div className="relative flex items-center min-w-max">
                {(["All", "Overview", "React", "Manage", "Plan"] as NavItem[]).map(item => {
                  const isActive = activeNavItem === item;
                  return (
                    <button
                      key={item}
                      onClick={() => setActiveNavItem(item)}
                      aria-label={`Filter by ${item}`}
                      aria-current={isActive ? "page" : undefined}
                      className={`relative flex items-center gap-1 px-3 sm:px-4 md:px-3 lg:px-4 py-4 text-sm transition-colors whitespace-nowrap rounded-t-[16px] ${
                        isMobile ? "touch-manipulation" : ""
                      } ${
                        isActive
                          ? "text-[#1E1E1E] font-black"
                          : "text-ui-text-heading-primary hover:text-ui-text-heading font-medium"
                      }`}
                      style={
                        isActive
                          ? {
                              background: "linear-gradient(to bottom, #461E9600 0%, #461E96 300%)",
                            }
                          : undefined
                      }
                    >
                      <span>{item}</span>
                      {isActive && (
                        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-ui-interactive-primary" aria-hidden="true" />
                      )}
                    </button>
                  );
                })}
              </div>
            </nav>
          </div>
          <div className="space-y-6 mt-6">
            <div className="w-full flex justify-center">
              <div className="relative w-[70%]">
                <div className="absolute left-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                  <img src={SearchIcon} alt="Search" className="h-4 w-4 text-gray-400" />
                </div>
                <Input
                  type="text"
                  placeholder="Search a topic/word"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="w-full pl-10"
                />
              </div>
            </div>
            <div className="w-full flex justify-center">
              <div className="w-[70%]">
                <nav
                  role="navigation"
                  aria-label="Alphabet navigation"
                  className={`relative flex items-center w-full overflow-x-auto scrollbar-hide`}
                  style={{
                    scrollbarWidth: "none",
                    msOverflowStyle: "none",
                    WebkitOverflowScrolling: "touch",
                  }}
                >
                  <div className="relative flex items-center w-full justify-center">
                    {(["ALL", ...Array.from({ length: 26 }, (_, i) => String.fromCharCode(65 + i))] as AlphabetLetter[]).map(
                      letter => {
                        const isActive = activeLetter === letter;
                        return (
                          <button
                            key={letter}
                            onClick={() => setActiveLetter(letter)}
                            aria-label={`Filter by ${letter}`}
                            aria-current={isActive ? "page" : undefined}
                            className={`relative font-semibold flex items-center justify-center flex-1 py-1 text-sm whitespace-nowrap ${
                              isMobile ? "touch-manipulation" : ""
                            }`}
                          >
                            <span>{letter}</span>
                            {isActive && (
                              <div
                                className="absolute bottom-0 left-0 right-0 h-0.5 bg-ui-interactive-primary"
                                aria-hidden="true"
                              />
                            )}
                          </button>
                        );
                      }
                    )}
                  </div>
                </nav>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-center pt-4">Glossary Terms</h2>
            {filteredItems.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-ui-text-secondary">No glossary terms found matching your search.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredItems.map((item, index) => (
                  <Card key={index} className="flex flex-col">
                    <CardContent className="p-4 flex flex-col flex-1">
                      <div className="flex-1">
                        <h3 className="text-base font-semibold text-ui-text-primary mb-2">{item.fieldName}</h3>
                        {item.fullName && <p className="text-xs text-ui-text-secondary mb-2">{item.fullName}</p>}
                        <p className="text-sm text-ui-text-secondary line-clamp-3 mb-4">
                          {item.definition || "No definition available."}
                        </p>
                      </div>
                      {hasAdditionalInfo(item) && (
                        <Button size="sm" onClick={() => handleReadMore(item)} className="w-fit">
                          Read More
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {selectedItem && (
        <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={selectedItem.fieldName} className="max-w-3xl">
          <div className="space-y-4">
            {selectedItem.fullName && (
              <div>
                <h4 className="text-sm font-semibold text-ui-text-primary mb-1">Full Name</h4>
                <p className="text-sm text-ui-text-secondary">{selectedItem.fullName}</p>
              </div>
            )}

            {(selectedItem.module || selectedItem.tab) && (
              <div>
                <h4 className="text-sm font-semibold text-ui-text-primary mb-1">Module / Tab</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedItem.module &&
                    selectedItem.module.split(",").map((module, idx) => (
                      <span
                        key={`modal-module-${idx}`}
                        className="text-xs px-2 py-1 bg-ui-background-secondary text-ui-text-secondary rounded"
                      >
                        {module.trim()}
                      </span>
                    ))}
                  {selectedItem.tab &&
                    selectedItem.tab.split(",").map((tab, idx) => (
                      <span
                        key={`modal-tab-${idx}`}
                        className="text-xs px-2 py-1 bg-ui-background-secondary text-ui-text-secondary rounded"
                      >
                        {tab.trim()}
                      </span>
                    ))}
                </div>
              </div>
            )}

            {selectedItem.definition && (
              <div>
                <h4 className="text-sm font-semibold text-ui-text-primary mb-1">Definition</h4>
                <p className="text-sm text-ui-text-secondary whitespace-pre-wrap">{selectedItem.definition}</p>
              </div>
            )}

            {selectedItem.logicFormula && (
              <div>
                <h4 className="text-sm font-semibold text-ui-text-primary mb-1">Logic/Formula</h4>
                <div className="bg-ui-background-secondary p-3 rounded-md">
                  <p className="text-sm text-ui-text-secondary whitespace-pre-wrap font-mono">{selectedItem.logicFormula}</p>
                </div>
              </div>
            )}

            {selectedItem.allowedValues && (
              <div>
                <h4 className="text-sm font-semibold text-ui-text-primary mb-1">Allowed Values</h4>
                <p className="text-sm text-ui-text-secondary whitespace-pre-wrap">{selectedItem.allowedValues}</p>
              </div>
            )}

            {selectedItem.dataOwner && (
              <div>
                <h4 className="text-sm font-semibold text-ui-text-primary mb-1">Data Owner</h4>
                <p className="text-sm text-ui-text-secondary">{selectedItem.dataOwner}</p>
              </div>
            )}

            {selectedItem.dataSteward && (
              <div>
                <h4 className="text-sm font-semibold text-ui-text-primary mb-1">Data Steward</h4>
                <p className="text-sm text-ui-text-secondary">{selectedItem.dataSteward}</p>
              </div>
            )}

            {selectedItem.dataInputs && (
              <div>
                <h4 className="text-sm font-semibold text-ui-text-primary mb-1">Data Inputs</h4>
                <p className="text-sm text-ui-text-secondary">{selectedItem.dataInputs}</p>
              </div>
            )}

            {selectedItem.sourceOfDataInputs && (
              <div>
                <h4 className="text-sm font-semibold text-ui-text-primary mb-1">Source of Data Inputs</h4>
                <p className="text-sm text-ui-text-secondary">{selectedItem.sourceOfDataInputs}</p>
              </div>
            )}
          </div>
        </Modal>
      )}
      <div className="relative w-full my-10 max-w-(--breakpoint-2xl) mx-auto px-4 sm:px-6 lg:px-8">
        <img
          src={glossaryBanner}
          alt="Glossary Banner"
          className="w-full h-[130px] object-cover rounded-xl"
        />
        <div className="absolute top-6 left-14">
          <svg width="141" height="20" viewBox="0 0 141 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.67">
              <g clipPath="url(#clip0_1409_145408)">
                <path
                  d="M136.947 0.401481V3.0119C135.341 1.08422 132.971 0 130.2 0C124.618 0 120.561 4.41757 120.561 9.99999C120.561 15.5824 124.618 20 130.2 20C132.971 20 135.341 18.9155 136.947 16.9878V19.5982H140.481V0.401481H136.947ZM130.602 16.4658C126.826 16.4658 124.256 13.6946 124.256 9.99999C124.256 6.30534 126.826 3.53424 130.602 3.53424C134.377 3.53424 136.947 6.30505 136.947 9.99999C136.947 13.6949 134.377 16.4658 130.602 16.4658ZM117.108 0.0803411L119.276 3.53422C115.501 3.53422 113.654 5.06013 113.654 8.15266V19.5982H110.039V7.63037C110.039 3.37351 112.529 0.522013 117.108 0.0803411ZM96.4652 0C90.6822 0 86.425 4.41757 86.425 9.99999C86.425 15.5824 90.6822 20 96.4652 20C102.248 20 106.505 15.5822 106.505 9.99999C106.505 4.4178 102.248 0 96.4652 0ZM96.4652 16.4658C92.6902 16.4658 90.1199 13.6946 90.1199 9.99999C90.1199 6.30534 92.6902 3.53424 96.4652 3.53424C100.24 3.53424 102.81 6.30505 102.81 9.99999C102.81 13.6949 100.24 16.4658 96.4652 16.4658ZM69.156 9.99999C69.156 13.6947 71.6863 16.4658 75.381 16.4658C77.9512 16.4658 79.9191 15.261 81.0033 13.2529L83.9351 15.3012C82.2887 18.1122 79.156 20 75.381 20C69.7185 20 65.4613 15.5822 65.4613 9.99997C65.4613 4.41779 69.7185 0 75.381 0C79.156 0 82.2887 1.88749 83.9351 4.69881L81.0033 6.74701C79.9191 4.73899 77.9512 3.53424 75.381 3.53424C71.6863 3.53424 69.156 6.30505 69.156 9.99999ZM61.9271 8.47381V19.5982H58.3128V8.71485C58.3128 5.42171 56.6262 3.53422 53.1321 3.53422C49.6381 3.53422 47.9515 5.42171 47.9515 8.71485V19.5982H44.3369V8.47381C44.3369 3.37352 47.5098 0 53.1321 0C58.7545 0 61.9271 3.37351 61.9271 8.47381ZM40.803 10.0402C40.803 10.4818 40.803 10.9637 40.7628 11.5259H27.55L29.6384 8.23304H36.9074C36.4655 5.34138 34.0961 3.53424 30.9235 3.53424C27.2286 3.53424 24.6583 6.30505 24.6583 9.99999C24.6583 13.6949 27.2286 16.4658 30.9235 16.4658C33.2929 16.4658 35.1804 15.4217 36.345 13.7348L39.1563 15.9438C37.4295 18.3935 34.4976 20 30.9235 20C25.1804 20 20.9637 15.6223 20.9637 9.99999C20.9637 4.41757 25.2205 0 30.9235 0C36.8673 0 40.803 4.25714 40.803 10.0402ZM3.69466 9.99999C3.69466 13.6947 6.22471 16.4658 9.91964 16.4658C12.4899 16.4658 14.4577 15.261 15.542 13.2529L18.4738 15.3012C16.8271 18.1122 13.6946 20 9.91964 20C4.25685 20 0 15.5822 0 9.99999C0 4.41782 4.25685 0 9.91964 0C13.6946 0 16.8271 1.88749 18.4738 4.69881L15.542 6.74701C14.4577 4.73899 12.4899 3.53424 9.91964 3.53424C6.22471 3.53424 3.69466 6.30505 3.69466 9.99999Z"
                  fill="white"
                />
              </g>
            </g>
            <defs>
              <clipPath id="clip0_1409_145408">
                <rect width="140.481" height="20" fill="white" />
              </clipPath>
            </defs>
          </svg>
        </div>
      </div>
      <Footer />
    </div>
  );
};
