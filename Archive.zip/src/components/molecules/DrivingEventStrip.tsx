import type { ReactNode } from "react";
import { CalendarClock, MapPin, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  formatDrivingEventDateRange,
  formatDrivingEventLocation,
  getDrivingEventStatusLabel,
  getDrivingEventStatusPillClassName,
  getDrivingEventStatusTone,
} from "@/lib/drivingEventDisplay";
import type { DrivingEvent } from "@/types/granularityIssue";

export interface DrivingEventStripProps {
  event?: DrivingEvent | null;
  /** Shown when there is no linked event but the issue still has a driving risk label. */
  drivingRisk?: string | null;
  className?: string;
  /** Tighter padding and typography for table cells. */
  compact?: boolean;
}

function MetadataItem({ icon, children, mono = false }: { icon?: ReactNode; children: ReactNode; mono?: boolean }) {
  return (
    <span className={cn("inline-flex min-w-0 max-w-full items-center gap-1", mono && "font-mono")}>
      {icon}
      <span className="truncate">{children}</span>
    </span>
  );
}

function DrivingEventStatusPill({ status }: { status?: string | null }) {
  const tone = getDrivingEventStatusTone(status);
  const isOngoing = tone === "active";

  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-0.5 text-2xs font-semibold",
        getDrivingEventStatusPillClassName(tone)
      )}
    >
      {isOngoing ? (
        <span className="relative flex h-2 w-2" aria-hidden>
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#E22F00] opacity-40" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-[#E22F00]" />
        </span>
      ) : null}
      {getDrivingEventStatusLabel(status)}
    </span>
  );
}

function DrivingRiskFallback({ drivingRisk }: { drivingRisk: string }) {
  return (
    <div
      className="rounded-md border border-ui-border-primary bg-ui-background-secondary px-3 py-2.5"
      data-testid="driving-risk-fallback"
    >
      <div className="flex min-w-0 items-start gap-2">
        <Zap className="mt-0.5 h-4 w-4 shrink-0 text-ui-text-secondary" aria-hidden />
        <div className="min-w-0">
          <p className="text-sm font-semibold text-ui-text-primary">Driving risk: {drivingRisk}</p>
          <p className="text-xs text-ui-text-secondary">No linked supply chain event</p>
        </div>
      </div>
    </div>
  );
}

export function DrivingEventStrip({ event, drivingRisk, className, compact = false }: DrivingEventStripProps) {
  const trimmedRisk = drivingRisk?.trim();
  const showFallback = !event && Boolean(trimmedRisk) && trimmedRisk !== "-";

  if (!event) {
    return showFallback ? <DrivingRiskFallback drivingRisk={trimmedRisk!} /> : null;
  }

  const location = formatDrivingEventLocation(event);
  const dateRange = formatDrivingEventDateRange(event);
  const iconSize = compact ? "h-3.5 w-3.5" : "h-4 w-4";

  return (
    <div
      className={cn(
        "rounded-md border border-ui-border-primary bg-ui-background-secondary",
        compact ? "px-2.5 py-2" : "px-3 py-2.5",
        className
      )}
      data-testid="driving-event-strip"
    >
      <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-start">
        <div className="min-w-0">
          <p
            className={cn("font-semibold text-ui-text-primary", compact ? "text-xs leading-5" : "text-sm", "truncate")}
            title={event.type}
          >
            {event.type}
          </p>
          {event.type_description ? (
            <p
              className={cn("text-ui-text-secondary", compact ? "text-2xs leading-4" : "text-xs", "line-clamp-2")}
              title={event.type_description}
            >
              {event.type_description}
            </p>
          ) : null}
        </div>
        <DrivingEventStatusPill status={event.status} />
      </div>

      {location || dateRange || event.event_id ? (
        <div
          className={cn(
            "mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-ui-text-secondary",
            compact ? "text-2xs" : "text-xs"
          )}
        >
          {location ? (
            <MetadataItem icon={<MapPin className={cn(iconSize, "shrink-0")} aria-hidden />}>{location}</MetadataItem>
          ) : null}
          {dateRange ? (
            <MetadataItem icon={<CalendarClock className={cn(iconSize, "shrink-0")} aria-hidden />}>{dateRange}</MetadataItem>
          ) : null}
          {event.event_id ? <MetadataItem mono>{event.event_id}</MetadataItem> : null}
        </div>
      ) : null}
    </div>
  );
}
