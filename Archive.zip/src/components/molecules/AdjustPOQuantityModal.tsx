import React, { useState } from "react";
import { getGcnLabel } from "@/lib/gcnLabels";

interface PurchaseOrder {
  poNumber: string;
  quantity: number;
  supplier: string;
  placedDate: string;
  placedDaysAgo: string;
  expectedDelivery: string;
  isRecent?: boolean;
}

interface AdjustPOQuantityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm?: (confirmed: boolean) => void;
  materialName?: string;
  gcn?: string;
  ndc?: string;
  totalOpenPOs?: number;
  totalQuantityOrdered?: number;
  nextDelivery?: string;
  purchaseOrders?: PurchaseOrder[];
}

export const AdjustPOQuantityModal: React.FC<AdjustPOQuantityModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  materialName = "Acetaminophen 500mg Tablets",
  gcn = "12345",
  ndc = "00000-0000-00",
  totalOpenPOs = 3,
  totalQuantityOrdered = 10500,
  nextDelivery = "Oct 28",
  purchaseOrders,
}) => {
  const [isConfirmed, setIsConfirmed] = useState(false);

  // Default purchase orders if none provided
  const defaultPurchaseOrders: PurchaseOrder[] = [
    {
      poNumber: "PO-2039-2932",
      quantity: 100,
      supplier: "Supplier Name",
      placedDate: "Oct 27, 2025",
      placedDaysAgo: "2 days ago",
      expectedDelivery: "Nov 10, 2025",
      isRecent: true,
    },
    {
      poNumber: "PO-2039-2932",
      quantity: 100,
      supplier: "Supplier Name",
      placedDate: "Oct 27, 2025",
      placedDaysAgo: "2 days ago",
      expectedDelivery: "Nov 10, 2025",
      isRecent: true,
    },
    {
      poNumber: "PO-2039-2932",
      quantity: 100,
      supplier: "Supplier Name",
      placedDate: "Oct 27, 2025",
      placedDaysAgo: "2 days ago",
      expectedDelivery: "Nov 10, 2025",
      isRecent: true,
    },
    {
      poNumber: "PO-2039-2932",
      quantity: 100,
      supplier: "Supplier Name",
      placedDate: "Oct 27, 2025",
      placedDaysAgo: "2 days ago",
      expectedDelivery: "Nov 10, 2025",
      isRecent: true,
    },
    {
      poNumber: "PO-2039-2932",
      quantity: 100,
      supplier: "Supplier Name",
      placedDate: "Oct 27, 2025",
      placedDaysAgo: "2 days ago",
      expectedDelivery: "Nov 10, 2025",
      isRecent: true,
    },
    {
      poNumber: "PO-2039-2932",
      quantity: 100,
      supplier: "Supplier Name",
      placedDate: "Oct 27, 2025",
      placedDaysAgo: "2 days ago",
      expectedDelivery: "Nov 10, 2025",
      isRecent: true,
    },
  ];

  const orders = purchaseOrders || defaultPurchaseOrders;

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (isConfirmed && onConfirm) {
      onConfirm(true);
    }
    setIsConfirmed(false);
    onClose();
  };

  const handleClose = () => {
    setIsConfirmed(false);
    onClose();
  };

  const formatNumber = (num: number): string => {
    return num.toLocaleString();
  };

  return (
    <div className="fixed inset-0 z-10000 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        style={{
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
        onClick={handleClose}
      />

      {/* Modal Card */}
      <div
        className="relative bg-white rounded-lg shadow-xl max-w-4xl w-[90vw] md:w-full mx-4 max-h-[90vh] overflow-y-auto"
        style={{
          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b" style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}>
          <div className="flex items-center gap-3">
            <div
              className="w-8 h-8 rounded flex items-center justify-center"
              style={{
                backgroundColor: "var(--color-brand-primary-main, #461E96)",
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="white"
                className="w-5 h-5"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.75 7.5h16.5m-16.5 0a1.5 1.5 0 00-1.5 1.5v12a1.5 1.5 0 001.5 1.5h16.5a1.5 1.5 0 001.5-1.5V9a1.5 1.5 0 00-1.5-1.5"
                />
              </svg>
            </div>
            <div>
              <h2
                className="font-bold"
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "20px",
                  fontWeight: "700",
                  lineHeight: "28px",
                }}
              >
                Adjust PO Quantity & Placement
              </h2>
              <p
                className="text-sm mt-1"
                style={{
                  color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "400",
                  lineHeight: "20px",
                }}
              >
                Review open purchase orders for this material
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
            style={{
              fontSize: "24px",
              lineHeight: "1",
            }}
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="px-6 py-6 space-y-6">
          {/* Product Details */}
          <div>
            <h3
              className="font-semibold mb-4"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "600",
                lineHeight: "24px",
              }}
            >
              Product Details
            </h3>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  MATERIAL NAME
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {materialName}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  {getGcnLabel()}
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {gcn}
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  NDC
                </div>
                <div
                  className="font-medium"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  {ndc}
                </div>
              </div>
            </div>

            {/* Summary Boxes */}
            <div className="grid grid-cols-3 gap-4">
              {/* Total Open POs */}
              <div
                className="p-4 rounded-lg"
                style={{
                  backgroundColor: "#E3F2FD",
                  border: "1px solid #BBDEFB",
                }}
              >
                <div
                  className="text-xs mb-2"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  TOTAL OPEN POS
                </div>
                <div
                  className="font-bold"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "24px",
                    fontWeight: "700",
                    lineHeight: "32px",
                  }}
                >
                  {totalOpenPOs}
                </div>
              </div>

              {/* Total Quantity Ordered */}
              <div
                className="p-4 rounded-lg"
                style={{
                  backgroundColor: "#E8F5E9",
                  border: "1px solid #C8E6C9",
                }}
              >
                <div
                  className="text-xs mb-2"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  TOTAL QUANTITY ORDERED
                </div>
                <div
                  className="font-bold"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "24px",
                    fontWeight: "700",
                    lineHeight: "32px",
                  }}
                >
                  {formatNumber(totalQuantityOrdered)}
                </div>
              </div>

              {/* Next Delivery */}
              <div
                className="p-4 rounded-lg"
                style={{
                  backgroundColor: "#F3E8FF",
                  border: "1px solid #E9D5FF",
                }}
              >
                <div
                  className="text-xs mb-2"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "500",
                    lineHeight: "16px",
                    textTransform: "uppercase",
                  }}
                >
                  NEXT DELIVERY
                </div>
                <div
                  className="font-bold"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "24px",
                    fontWeight: "700",
                    lineHeight: "32px",
                  }}
                >
                  {nextDelivery}
                </div>
              </div>
            </div>
          </div>

          {/* Open Purchase Orders Table */}
          <div>
            <h3
              className="font-semibold mb-4"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "16px",
                fontWeight: "600",
                lineHeight: "24px",
              }}
            >
              Open Purchase Orders
            </h3>
            <div className="overflow-x-auto border rounded-lg" style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}>
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ backgroundColor: "var(--cds-color-background-secondary, #F5F5F5)" }}>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      PO Number
                    </th>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      Quantity
                    </th>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      Supplier
                    </th>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      Placed
                    </th>
                    <th
                      className="px-4 py-3 text-left font-semibold"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "14px",
                        fontWeight: "600",
                        lineHeight: "20px",
                      }}
                    >
                      Expected Delivery
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order, index) => (
                    <tr
                      key={index}
                      className="border-t"
                      style={{
                        borderColor: "var(--cds-color-border-primary, #E0E0E0)",
                        backgroundColor: order.isRecent ? "#E8F5E9" : "#FFFFFF",
                      }}
                    >
                      <td className="px-4 py-3">
                        <div
                          className="font-medium"
                          style={{
                            color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                            fontFamily: "Cencora-Gilroy",
                            fontSize: "14px",
                            fontWeight: "500",
                            lineHeight: "20px",
                          }}
                        >
                          {order.poNumber}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div
                          className="font-medium"
                          style={{
                            color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                            fontFamily: "Cencora-Gilroy",
                            fontSize: "14px",
                            fontWeight: "500",
                            lineHeight: "20px",
                          }}
                        >
                          {formatNumber(order.quantity)}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth={2}
                            stroke="currentColor"
                            className="w-4 h-4"
                            style={{
                              color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                            }}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M6.75 21v-3.375c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21M3 3h12m-.75 4.5H21m-3.75 3.75h.008v.008h-.008v-.008zm0 3h.008v.008h-.008v-.008zm0 3h.008v.008h-.008v-.008z"
                            />
                          </svg>
                          <div
                            className="font-medium"
                            style={{
                              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                              fontFamily: "Cencora-Gilroy",
                              fontSize: "14px",
                              fontWeight: "500",
                              lineHeight: "20px",
                            }}
                          >
                            {order.supplier}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div>
                          <div
                            className="font-medium"
                            style={{
                              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                              fontFamily: "Cencora-Gilroy",
                              fontSize: "14px",
                              fontWeight: "500",
                              lineHeight: "20px",
                            }}
                          >
                            {order.placedDate}
                          </div>
                          <div
                            className="text-sm"
                            style={{
                              color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                              fontFamily: "Cencora-Gilroy",
                              fontSize: "12px",
                              fontWeight: "400",
                              lineHeight: "16px",
                            }}
                          >
                            {order.placedDaysAgo}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth={2}
                            stroke="currentColor"
                            className="w-4 h-4"
                            style={{
                              color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                            }}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"
                            />
                          </svg>
                          <div
                            className="font-medium"
                            style={{
                              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                              fontFamily: "Cencora-Gilroy",
                              fontSize: "14px",
                              fontWeight: "500",
                              lineHeight: "20px",
                            }}
                          >
                            {order.expectedDelivery}
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Recommendation Tip */}
          <div
            className="p-4 rounded-lg flex items-start gap-3"
            style={{
              backgroundColor: "#E3F2FD",
              border: "1px solid #BBDEFB",
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={2}
              stroke="currentColor"
              className="w-5 h-5 shrink-0 mt-0.5"
              style={{
                color: "var(--color-brand-primary-main, #461E96)",
              }}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m4.5 0a12.06 12.06 0 00-4.5 0m0 0a6.01 6.01 0 01-1.5-.189M15.75 12.75a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189M12 3.75a6.01 6.01 0 011.5-.189M12 3.75a6.01 6.01 0 00-1.5-.189M12 3.75v.75m0 0a6.01 6.01 0 011.5.189M12 4.5a6.01 6.01 0 00-1.5.189"
              />
            </svg>
            <div>
              <div
                className="font-semibold mb-1"
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "600",
                  lineHeight: "20px",
                }}
              >
                Tip:
              </div>
              <p
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "400",
                  lineHeight: "20px",
                }}
              >
                Recently placed POs (shown in green) are typically easier to modify. Consider increasing quantity on PO-2025-10234 placed 2 days ago, or expedite existing orders if needed.
              </p>
            </div>
          </div>

          {/* Action Confirmation */}
          <div>
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={isConfirmed}
                onChange={(e) => setIsConfirmed(e.target.checked)}
                className="mt-1"
                style={{
                  accentColor: "var(--color-brand-primary-main, #461E96)",
                  width: "20px",
                  height: "20px",
                }}
              />
              <div>
                <div
                  className="font-medium mb-1"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "14px",
                    fontWeight: "500",
                    lineHeight: "20px",
                  }}
                >
                  I will adjust PO Quantity & Placement for this material
                </div>
                <div
                  className="text-sm"
                  style={{
                    color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "12px",
                    fontWeight: "400",
                    lineHeight: "16px",
                  }}
                >
                  Check this box to confirm you'll take action on this recommendation
                </div>
              </div>
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 px-6 pb-6 border-t pt-4" style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}>
          <button
            onClick={handleClose}
            className="px-6 py-2 border rounded-md font-semibold transition-colors hover:bg-gray-50"
            style={{
              borderColor: "var(--cds-color-border-primary, #E0E0E0)",
              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "600",
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={!isConfirmed}
            className="px-6 py-2 rounded-md font-semibold text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              backgroundColor: isConfirmed
                ? "var(--color-brand-primary-main, #461E96)"
                : "var(--Cencora-neutral-expanded-500, #6E6E6E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "600",
            }}
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};
