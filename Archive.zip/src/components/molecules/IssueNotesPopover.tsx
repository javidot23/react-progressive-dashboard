import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { isAxiosError } from "axios";
import { MessageSquare, NotepadText, Pencil, Save, Trash2, X } from "lucide-react";
import { Button } from "@/components/atoms/Button";
import {
  useCreateIssueNoteMutation,
  useUpdateIssueNoteMutation,
  useDeleteIssueNoteMutation,
  useIssueNotesQuery,
  ISSUE_NOTES_DEFAULT_LIMIT,
} from "@/hooks/queries";
import useProfile from "@/hooks/useProfile";
import { issueNoteAuthorLabel } from "@/lib/issueNoteAuthorLabel";
import { issueNoteShowsEditedLabel } from "@/lib/issueNoteEdited";
import { formatRelativeTimeShort } from "@/lib/relativeTime";
import type { IssueNote } from "@/services/issueNotesService";

const POPOVER_MAX_WIDTH_PX = 480;
const ANCHOR_POPOVER_GAP_PX = 14;
const SCROLL_NEAR_BOTTOM_PX = 80;

const FOCUSABLE_SELECTOR =
  'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])';

export interface IssueNotesPopoverProps {
  onClose: () => void;
  anchorRef: React.RefObject<HTMLElement | null>;
  issueBackendId: string | undefined;
  matNbr: string;
  ndc: string;
  isResolved: boolean;
  panelId: string;
  titleId: string;
}

function noteKey(note: IssueNote): string {
  return String(note.id);
}

function resolveErrorMessage(err: unknown, fallback: string): string {
  if (isAxiosError(err)) {
    const data = err.response?.data as { message?: string; detail?: string } | undefined;
    if (data && typeof data === "object") {
      if (typeof data.detail === "string") return data.detail;
      if (typeof data.message === "string") return data.message;
    }
    if (err.message) return err.message;
  }
  if (err instanceof Error && err.message) return err.message;
  return fallback;
}

function getScrollRoots(anchor: HTMLElement): EventTarget[] {
  const roots = new Set<EventTarget>();
  let node: HTMLElement | null = anchor;
  while (node) {
    const style = window.getComputedStyle(node);
    const y = /(auto|scroll|overlay)/.test(style.overflowY);
    const x = /(auto|scroll|overlay)/.test(style.overflowX);
    if (y || x) roots.add(node);
    node = node.parentElement;
  }
  roots.add(window);
  return [...roots];
}

function IssueNotesPopoverEmpty() {
  return (
    <div className="flex flex-col items-center gap-2 py-0 text-center pt-5">
      <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-ui-background-secondary">
        <MessageSquare className="h-8 w-8 text-ui-text-muted" aria-hidden />
      </div>
      <h3 className="text-lg font-semibold text-ui-text-primary">No notes yet</h3>
      <p className="max-w-sm text-sm text-ui-text-secondary">
        Add a note to capture context, follow-ups, or decisions for this issue.
      </p>
    </div>
  );
}

function ActionStatusInline({ isResolved }: { isResolved: boolean }) {
  if (isResolved) {
    return (
      <span className="inline-flex items-center gap-2 shrink-0">
        <span className="inline-flex items-center justify-center p-1 rounded-full border border-[#06C07A] bg-[#D8FEE7] shrink-0">
          <span className="w-2 h-2 rounded-full bg-[#119D63]" />
        </span>
        <span className="font-semibold text-[#1E1E2D]">Reviewed</span>
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-2 shrink-0">
      <span className="inline-flex items-center justify-center p-1 rounded-full border border-[#E22F008A] bg-[#FEEFEB] shrink-0">
        <span className="w-2 h-2 rounded-full bg-[#E22F00]" />
      </span>
      <span className="font-semibold text-[#1E1E2D]">Not Reviewed</span>
    </span>
  );
}

function PopoverAnchorArrow({ placement }: { placement: "bottom" | "top" }) {
  if (placement === "bottom") {
    return (
      <svg
        aria-hidden
        className="pointer-events-none absolute right-2 z-2 h-[10px] w-[18px]"
        style={{
          top: 0,
          transform: "translateY(calc(-100% + 1px))",
        }}
        viewBox="0 0 18 10"
      >
        <path d="M9 0.5 L17.35 9.5 H0.65 Z" fill="#ffffff" />
        <path
          d="M9 0.5 L17.35 9.5 M9 0.5 L0.65 9.5"
          fill="none"
          stroke="#E5E5EA"
          strokeWidth="1"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    );
  }
  return (
    <svg
      aria-hidden
      className="pointer-events-none absolute right-2 z-2 h-[10px] w-[18px]"
      style={{
        bottom: 0,
        transform: "translateY(calc(100% - 1px))",
      }}
      viewBox="0 0 18 10"
    >
      <path d="M0.65 0.5 H17.35 L9 9.5 Z" fill="#ffffff" />
      <path
        d="M0.65 0.5 L9 9.5 M17.35 0.5 L9 9.5"
        fill="none"
        stroke="#E5E5EA"
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function IssueNotesPopover({
  onClose,
  anchorRef,
  issueBackendId,
  matNbr,
  ndc,
  isResolved,
  panelId,
  titleId,
}: IssueNotesPopoverProps) {
  const notesQuery = useIssueNotesQuery({
    issueId: issueBackendId,
    limit: ISSUE_NOTES_DEFAULT_LIMIT,
  });

  const messages = useMemo(() => {
    const pages = notesQuery.data?.pages;
    if (!pages?.length) return [];
    const flat = pages.flatMap(p => p.results);
    return [...flat].reverse();
  }, [notesQuery.data]);

  const notesQueryRef = useRef(notesQuery);
  notesQueryRef.current = notesQuery;

  const popoverRef = useRef<HTMLDivElement>(null);
  const messagesListRef = useRef<HTMLDivElement>(null);
  const topLoadSentinelRef = useRef<HTMLDivElement>(null);
  const issueIdForScrollRef = useRef(issueBackendId);
  const hasInitialScrolledRef = useRef(false);
  const pendingScrollAfterCreateRef = useRef(false);
  const pendingPrependAnchorRef = useRef<{ prevScrollHeight: number; prevScrollTop: number } | null>(null);
  const isAtBottomRef = useRef(true);
  const isMountedRef = useRef(true);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  const [coords, setCoords] = useState({
    top: 0,
    left: 0,
    width: POPOVER_MAX_WIDTH_PX,
    placement: "bottom" as "bottom" | "top",
  });

  const [newContent, setNewContent] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [formError, setFormError] = useState("");

  const { profile } = useProfile();

  const optimisticAuthor = useMemo(
    () =>
      profile
        ? {
            id: profile.id,
            user_data: {
              first_name: profile.givenName,
              last_name: profile.surname,
              email: profile.mail ?? profile.userPrincipalName,
            },
          }
        : undefined,
    [profile]
  );

  const createMutation = useCreateIssueNoteMutation(issueBackendId, optimisticAuthor, { silent: true });
  const updateMutation = useUpdateIssueNoteMutation(issueBackendId, { silent: true });
  const deleteMutation = useDeleteIssueNoteMutation(issueBackendId, { silent: true });

  const updatePosition = useCallback(() => {
    const anchor = anchorRef.current;
    const floating = popoverRef.current;
    if (!anchor || !floating) return;

    const rect = anchor.getBoundingClientRect();
    const width = Math.min(POPOVER_MAX_WIDTH_PX, window.innerWidth * 0.95);
    let left = rect.right - width;
    const minLeft = 8;
    const maxLeft = window.innerWidth - width - 8;
    left = Math.max(minLeft, Math.min(left, maxLeft));

    const gap = ANCHOR_POPOVER_GAP_PX;
    const margin = 8;
    const vh = window.innerHeight;
    const popH = floating.getBoundingClientRect().height;
    const spaceBelow = vh - rect.bottom - gap - margin;
    const spaceAbove = rect.top - gap - margin;

    let placement: "bottom" | "top" = "bottom";
    let top = rect.bottom + gap;

    if (popH > spaceBelow) {
      if (popH <= spaceAbove) {
        placement = "top";
        top = rect.top - popH - gap;
      } else if (spaceAbove >= spaceBelow) {
        placement = "top";
        top = margin;
      }
    }

    top = Math.max(margin, Math.min(top, vh - popH - margin));

    setCoords(prev => {
      if (prev.top === top && prev.left === left && prev.width === width && prev.placement === placement) {
        return prev;
      }
      return { top, left, width, placement };
    });
  }, [anchorRef]);

  useLayoutEffect(() => {
    updatePosition();
    window.addEventListener("resize", updatePosition);
    return () => window.removeEventListener("resize", updatePosition);
  }, [updatePosition]);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    const el = popoverRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => {
      updatePosition();
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [updatePosition]);

  useLayoutEffect(() => {
    closeButtonRef.current?.focus();
  }, []);

  useEffect(() => {
    const root = messagesListRef.current;
    if (!root) return;
    let rafId = 0;
    const updateNearBottom = () => {
      const distance = root.scrollHeight - root.scrollTop - root.clientHeight;
      isAtBottomRef.current = distance <= SCROLL_NEAR_BOTTOM_PX;
    };
    const onScroll = () => {
      if (rafId) cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        rafId = 0;
        updateNearBottom();
      });
    };
    updateNearBottom();
    root.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      root.removeEventListener("scroll", onScroll);
    };
  }, [issueBackendId, messages.length]);

  useLayoutEffect(() => {
    if (issueIdForScrollRef.current !== issueBackendId) {
      issueIdForScrollRef.current = issueBackendId;
      hasInitialScrolledRef.current = false;
      pendingScrollAfterCreateRef.current = false;
      pendingPrependAnchorRef.current = null;
      isAtBottomRef.current = true;
    }

    if (!issueBackendId) return;
    const messagesEl = messagesListRef.current;
    if (!messagesEl || !notesQuery.isSuccess) return;

    if (pendingPrependAnchorRef.current) {
      const anchor = pendingPrependAnchorRef.current;
      messagesEl.scrollTop = messagesEl.scrollHeight - anchor.prevScrollHeight + anchor.prevScrollTop;
      pendingPrependAnchorRef.current = null;
      return;
    }

    if (messages.length === 0) {
      hasInitialScrolledRef.current = false;
      return;
    }

    if (pendingScrollAfterCreateRef.current) {
      messagesEl.scrollTop = messagesEl.scrollHeight;
      pendingScrollAfterCreateRef.current = false;
      hasInitialScrolledRef.current = true;
      isAtBottomRef.current = true;
      return;
    }

    if (!hasInitialScrolledRef.current) {
      messagesEl.scrollTop = messagesEl.scrollHeight;
      hasInitialScrolledRef.current = true;
      isAtBottomRef.current = true;
      return;
    }

    if (isAtBottomRef.current) {
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }
  }, [issueBackendId, messages, notesQuery.isSuccess]);

  const handleLoadOlder = useCallback(() => {
    const q = notesQueryRef.current;
    if (!q.hasNextPage || q.isFetchingNextPage || !issueBackendId) return;
    const el = messagesListRef.current;
    if (el) {
      pendingPrependAnchorRef.current = {
        prevScrollHeight: el.scrollHeight,
        prevScrollTop: el.scrollTop,
      };
    }
    void q.fetchNextPage().catch(() => {
      pendingPrependAnchorRef.current = null;
    });
  }, [issueBackendId]);

  useEffect(() => {
    const root = messagesListRef.current;
    const target = topLoadSentinelRef.current;
    if (!root || !target || !issueBackendId) return;

    const observer = new IntersectionObserver(
      entries => {
        const entry = entries[0];
        if (!entry?.isIntersecting) return;
        handleLoadOlder();
      },
      { root, rootMargin: "80px 0px 0px 0px", threshold: 0 }
    );
    observer.observe(target);
    return () => observer.disconnect();
  }, [issueBackendId, handleLoadOlder, notesQuery.isSuccess, messages.length]);

  useEffect(() => {
    const root = popoverRef.current;
    if (!root) return;
    const getFocusable = () =>
      Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(el => {
        if (el.getAttribute("aria-hidden") === "true") return false;
        const style = window.getComputedStyle(el);
        if (style.visibility === "hidden" || style.display === "none") return false;
        return el.getClientRects().length > 0;
      });

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      const nodes = getFocusable();
      if (nodes.length === 0) return;
      const first = nodes[0]!;
      const last = nodes[nodes.length - 1]!;
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };

    root.addEventListener("keydown", onKeyDown);
    return () => root.removeEventListener("keydown", onKeyDown);
  }, []);

  useEffect(() => {
    const anchor = anchorRef.current;
    if (!anchor) return;
    const roots = getScrollRoots(anchor);
    const onScroll = (e: Event) => {
      const t = e.target;
      if (t instanceof Node && popoverRef.current?.contains(t)) return;
      onCloseRef.current();
    };
    roots.forEach(target => target.addEventListener("scroll", onScroll, { passive: true }));
    return () => {
      roots.forEach(target => target.removeEventListener("scroll", onScroll));
    };
  }, [anchorRef]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCloseRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    const onPointerDown = (e: MouseEvent | PointerEvent) => {
      const t = e.target as Node;
      if (popoverRef.current?.contains(t)) return;
      if (anchorRef.current?.contains(t)) return;
      onCloseRef.current();
    };
    document.addEventListener("mousedown", onPointerDown);
    return () => document.removeEventListener("mousedown", onPointerDown);
  }, [anchorRef]);

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isMountedRef.current) return;
    setFormError("");
    const trimmed = newContent.trim();
    if (!trimmed) {
      setFormError("Note cannot be empty.");
      return;
    }
    if (!issueBackendId) return;
    try {
      pendingScrollAfterCreateRef.current = true;
      await createMutation.mutateAsync({ content: trimmed });
      if (!isMountedRef.current) return;
      setNewContent("");
    } catch (err) {
      pendingScrollAfterCreateRef.current = false;
      if (!isMountedRef.current) return;
      setFormError(resolveErrorMessage(err, "Failed to add note."));
    }
  };

  const startEdit = (note: IssueNote) => {
    setDeleteConfirmId(null);
    setEditingId(noteKey(note));
    setEditContent(note.content);
    setFormError("");
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditContent("");
    setFormError("");
  };

  const saveEdit = async () => {
    if (!editingId) return;
    const trimmed = editContent.trim();
    if (!trimmed) {
      setFormError("Note cannot be empty.");
      return;
    }
    try {
      await updateMutation.mutateAsync({ noteId: editingId, body: { content: trimmed } });
      if (!isMountedRef.current) return;
      cancelEdit();
    } catch (err) {
      if (!isMountedRef.current) return;
      setFormError(resolveErrorMessage(err, "Failed to update note."));
    }
  };

  const confirmDelete = async (noteId: string) => {
    setFormError("");
    try {
      await deleteMutation.mutateAsync(noteId);
      if (!isMountedRef.current) return;
      setDeleteConfirmId(null);
    } catch (err) {
      if (!isMountedRef.current) return;
      setFormError(resolveErrorMessage(err, "Failed to delete note."));
    }
  };

  const avatarSrc = profile?.photoDataUrl;
  const initials =
    profile?.givenName?.[0] || profile?.surname?.[0] ? `${profile?.givenName?.[0] ?? ""}${profile?.surname?.[0] ?? ""}` : "?";

  if (typeof document === "undefined") return null;

  return createPortal(
    <div
      id={panelId}
      ref={popoverRef}
      className="fixed z-10002 flex max-h-[min(85vh,696px)] flex-col overflow-visible"
      style={{
        top: coords.top,
        left: coords.left,
        width: coords.width,
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby={titleId}
    >
      <div className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden rounded-xl border border-[#E5E5EA] bg-white shadow-lg">
        <header className="shrink-0 border-b border-[#E5E5EA] px-4 pt-4 pb-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex min-w-0 items-center gap-2">
              <NotepadText className="h-5 w-5 shrink-0 text-[#6E6E6E]" aria-hidden />
              <h2 id={titleId} className="text-base font-semibold text-[#6E6E6E]">
                Notes
              </h2>
            </div>
            <button
              ref={closeButtonRef}
              type="button"
              onClick={onClose}
              className="shrink-0 rounded-md p-1 text-[#888888] transition-colors hover:bg-[#F5F5F5] hover:text-[#1E1E2D]"
              aria-label="Close notes"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-x-1.5 gap-y-1 text-sm text-[#888888]">
            <span className="text-[#888888]">Mat</span> <span className="font-semibold text-[#1E1E2D]">{matNbr}</span>
            <span className="text-[#C5C5CC]">·</span>
            <span className="text-[#888888]">NDC</span> <span className="font-semibold text-[#1E1E2D]">{ndc || "—"}</span>
            <span className="text-[#C5C5CC]">·</span>
            <ActionStatusInline isResolved={isResolved} />
          </div>
        </header>
        <div ref={messagesListRef} className="max-h-[344px] min-h-0 overflow-y-auto overscroll-y-contain px-4 pt-3 pb-4">
          {!issueBackendId && <p className="text-sm text-status-error-main">This issue cannot load notes (missing issue id).</p>}

          {issueBackendId && notesQuery.isPending && !notesQuery.data && !notesQuery.isError && (
            <div className="flex flex-col items-center justify-center gap-3 py-10">
              <div className="h-8 w-8 animate-spin rounded-full border-[3px] border-ui-border-primary border-t-brand-primary-main" />
              <p className="text-sm font-medium text-ui-text-primary">Loading notes…</p>
            </div>
          )}

          {issueBackendId && notesQuery.isError && (
            <div className="rounded-md border border-status-error-main/30 bg-status-error-light px-3 py-3">
              <p className="text-sm font-medium text-status-error-main">Could not load notes.</p>
              <p className="mt-1 text-xs text-ui-text-secondary">
                {notesQuery.error instanceof Error ? notesQuery.error.message : "Something went wrong."}
              </p>
              <Button type="button" variant="outline" size="sm" className="mt-3" onClick={() => notesQuery.refetch()}>
                Retry
              </Button>
            </div>
          )}

          {issueBackendId && notesQuery.isSuccess && messages.length === 0 && <IssueNotesPopoverEmpty />}

          {issueBackendId && notesQuery.isSuccess && messages.length > 0 && (
            <>
              {notesQuery.isFetchingNextPage ? (
                <div className="flex justify-center pb-2" aria-live="polite">
                  <span className="text-xs text-[#888888]">Loading older notes…</span>
                </div>
              ) : null}
              <div ref={topLoadSentinelRef} className="h-px w-full shrink-0" aria-hidden />
            </>
          )}

          {issueBackendId &&
            notesQuery.isSuccess &&
            messages.length > 0 &&
            messages.map(note => {
              const edited = issueNoteShowsEditedLabel(note.created_at, note.updated_at);
              const isPendingOptimistic = note.id.startsWith("temp-");
              return (
                <article
                  key={noteKey(note)}
                  className={`mb-4${isPendingOptimistic ? " opacity-70" : ""}`}
                  aria-busy={isPendingOptimistic}
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-semibold text-[#1E1E2D]">{issueNoteAuthorLabel(note)}</span>
                    {note.is_my_note ? (
                      <span className="rounded-md bg-[#5B2E91] px-2 py-0.5 text-2xs font-semibold uppercase tracking-wide text-white">
                        YOU
                      </span>
                    ) : null}
                    {note.user_data?.role ? (
                      <span className="rounded-md bg-[#F0F0F2] px-2 py-0.5 text-2xs font-medium uppercase tracking-wide text-[#888888]">
                        {note.user_data.role.trim()}
                      </span>
                    ) : null}
                    <time className="text-xs text-[#888888]" dateTime={note.created_at}>
                      {formatRelativeTimeShort(note.created_at)}
                    </time>
                    {edited ? <span className="text-2xs text-[#888888]">(edited)</span> : null}
                  </div>
                  {editingId === noteKey(note) && note.is_my_note ? (
                    <div className="mt-2 rounded-tl-none rounded-tr-lg rounded-br-lg rounded-bl-lg border border-[#D8C8EB] bg-[#FAF7FD] p-3">
                      <textarea
                        value={editContent}
                        onChange={e => setEditContent(e.target.value)}
                        rows={3}
                        className="w-full resize-none rounded-md border border-input bg-background px-3 py-2 text-sm text-ui-text-primary placeholder:text-muted-foreground focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                      />
                      <div className="mt-3 flex flex-wrap justify-end gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={cancelEdit}
                          className="border-[#D8C8EB] bg-white text-[#1E1E2D] not-disabled:hover:bg-white not-disabled:hover:border-[#888888]"
                        >
                          Cancel
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => void saveEdit()}
                          isLoading={updateMutation.isPending}
                          disabled={!editContent.trim()}
                        >
                          Save
                        </Button>
                      </div>
                    </div>
                  ) : note.is_my_note ? (
                    <div className="mt-2 rounded-tl-none rounded-tr-lg rounded-br-lg rounded-bl-lg border border-[#D8C8EB] bg-[#FAF7FD] p-3">
                      <div className="text-sm wrap-break-word whitespace-pre-wrap text-[#1E1E2D]">{note.content}</div>
                      <div className="mt-2 flex flex-wrap items-center gap-x-6 gap-y-2">
                        {deleteConfirmId === noteKey(note) ? (
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                            <span className="text-[#888888]">Delete this note?</span>
                            <button
                              type="button"
                              disabled={deleteMutation.isPending}
                              className="inline-flex items-center gap-1.5 font-medium text-status-error-main hover:text-status-error-dark disabled:opacity-50"
                              onClick={() => void confirmDelete(noteKey(note))}
                            >
                              <Trash2 className="h-3.5 w-3.5 shrink-0" aria-hidden />
                              {deleteMutation.isPending ? "Deleting…" : "Delete"}
                            </button>
                            <button
                              type="button"
                              className="font-medium text-[#888888] hover:text-[#555555]"
                              onClick={() => setDeleteConfirmId(null)}
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <>
                            <button
                              type="button"
                              className="inline-flex items-center gap-1.5 text-sm font-medium text-[#888888] transition-colors hover:text-[#555555]"
                              onClick={() => startEdit(note)}
                            >
                              <Pencil className="h-3.5 w-3.5 shrink-0" strokeWidth={2} aria-hidden />
                              Edit
                            </button>
                            <button
                              type="button"
                              className="inline-flex items-center gap-1.5 text-sm font-medium text-[#888888] transition-colors hover:text-[#555555]"
                              onClick={() => {
                                setEditingId(null);
                                setDeleteConfirmId(noteKey(note));
                                setFormError("");
                              }}
                            >
                              <Trash2 className="h-3.5 w-3.5 shrink-0" strokeWidth={2} aria-hidden />
                              Delete
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="mt-2 w-full rounded-tl-none rounded-tr-lg rounded-br-lg rounded-bl-lg border border-[#E5E5EA] bg-[#F7F7F8] px-3 py-2 text-sm text-[#1E1E2D]">
                      <div className="wrap-break-word whitespace-pre-wrap">{note.content}</div>
                    </div>
                  )}
                </article>
              );
            })}
        </div>
        <footer className="shrink-0 border-t border-[#E5E5EA] bg-white px-4 pt-4 pb-3">
          {formError ? <p className="mb-2 text-xs text-status-error-main">{formError}</p> : null}
          <form onSubmit={e => void handleCreateSubmit(e)} className="overflow-hidden rounded-xl border border-[#E5E5EA]">
            <div className="flex items-center gap-3 bg-[#F5F5F5] px-2 py-1.5">
              {avatarSrc ? (
                <img src={avatarSrc} alt="" className="h-11 w-11 shrink-0 rounded-full object-cover" />
              ) : (
                <div
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#D8C8EB] text-sm font-semibold text-[#461E96]"
                  aria-hidden
                >
                  {initials}
                </div>
              )}
              <textarea
                value={newContent}
                onChange={e => setNewContent(e.target.value)}
                rows={2}
                placeholder="Write a note..."
                disabled={!issueBackendId}
                className="min-h-13 w-full resize-none border-0 bg-[#F5F5F5] py-1 text-sm leading-5 text-[#1E1E2D] placeholder:text-[#888888] focus-visible:outline-hidden focus-visible:ring-0 disabled:opacity-50"
              />
            </div>
            <div className="flex items-center justify-between gap-2 bg-white px-3 py-2">
              <p className="text-xs text-[#888888]">Saved to this material — visible to the team</p>
              <button
                type="submit"
                disabled={!issueBackendId || !newContent.trim() || createMutation.isPending}
                className="inline-flex shrink-0 items-center gap-2 rounded-md bg-[#461E96] px-3 py-1.5 text-sm font-medium text-white transition-opacity disabled:opacity-50"
              >
                {createMutation.isPending ? (
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                ) : (
                  <Save className="h-4 w-4" aria-hidden />
                )}
                Save Note
              </button>
            </div>
          </form>
        </footer>
      </div>
      <PopoverAnchorArrow placement={coords.placement} />
    </div>,
    document.body
  );
}
