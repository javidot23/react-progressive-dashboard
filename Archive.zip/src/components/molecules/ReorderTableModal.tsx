import React, { useState, useEffect } from "react";

import type { IssueFeedTableScope } from "@/lib/issueTableConfig";

export interface TableColumn {
  id: string;
  label: string;
  visible: boolean;
  locked?: boolean; // Columns that cannot be reordered (Material Name, Material ID)
}

interface ReorderTableModalProps {
  isOpen: boolean;
  onClose: () => void;
  columns: TableColumn[];
  onApply: (columns: TableColumn[]) => void;
  onReset?: () => void;
  viewScope?: "material" | "gcn" | "product" | IssueFeedTableScope;
}

export const ReorderTableModal: React.FC<ReorderTableModalProps> = ({
  isOpen,
  onClose,
  columns: initialColumns,
  onApply,
  onReset,
  // viewScope = "material",
}) => {
  const [columns, setColumns] = useState<TableColumn[]>(initialColumns);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  useEffect(() => {
    setColumns(initialColumns);
  }, [initialColumns, isOpen]);

  const handleDragStart = (index: number) => {
    if (columns[index].locked) return;
    setDraggedIndex(index);
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIndex === null || columns[index].locked) return;
    setDragOverIndex(index);
  };

  const handleDrop = (e: React.DragEvent, dropIndex: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === dropIndex || columns[dropIndex].locked) return;

    const newColumns = [...columns];
    const draggedItem = newColumns[draggedIndex];

    // Remove dragged item
    newColumns.splice(draggedIndex, 1);
    // Insert at new position
    newColumns.splice(dropIndex, 0, draggedItem);

    setColumns(newColumns);
    setDraggedIndex(null);
    setDragOverIndex(null);
  };

  const handleDragEnd = () => {
    setDraggedIndex(null);
    setDragOverIndex(null);
  };

  const toggleVisibility = (index: number) => {
    if (columns[index].locked) return; // Don't allow hiding locked columns
    const newColumns = [...columns];
    newColumns[index].visible = !newColumns[index].visible;
    setColumns(newColumns);
  };

  const handleReset = () => {
    if (onReset) {
      onReset();
      setColumns(initialColumns);
    } else {
      setColumns(initialColumns);
    }
  };

  const handleApply = () => {
    onApply(columns);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-10000 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        style={{
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
        onClick={onClose}
      />

      {/* Modal Card */}
      <div
        className="relative bg-white rounded-lg shadow-xl max-w-2xl w-[90vw] md:w-full mx-4 max-h-[90vh] flex flex-col"
        style={{
          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-6 pt-6 pb-4 border-b"
          style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}
        >
          <div className="flex-1">
            <h2
              className="font-bold mb-2"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "20px",
                fontWeight: "700",
                lineHeight: "28px",
              }}
            >
              Table Configuration
            </h2>
            <p
              className="text-sm"
              style={{
                color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "400",
                lineHeight: "20px",
              }}
            >
              Customize your table by dragging columns to reorder them. Material Name and Material ID will stay in place to help
              you keep track of key information.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 px-6 pt-4">
          <button
            onClick={handleReset}
            className="px-4 py-2 border rounded-md font-semibold transition-colors hover:bg-gray-50"
            style={{
              borderColor: "var(--cds-color-border-primary, #E0E0E0)",
              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "600",
            }}
          >
            Reset
          </button>
          <button
            onClick={handleApply}
            className="px-4 py-2 rounded-md font-semibold text-white transition-colors"
            style={{
              backgroundColor: "var(--color-brand-primary-main, #461E96)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "600",
            }}
          >
            Apply
          </button>
        </div>

        {/* Content - Scrollable Column List */}
        <div className="flex-1 overflow-y-auto px-6 pb-6">
          <div className="space-y-2">
            {columns.map((column, index) => {
              const isDragging = draggedIndex === index;
              const isDragOver = dragOverIndex === index;
              const isSelected = false; // You can add selection logic if needed

              return (
                <div
                  key={column.id}
                  draggable={!column.locked}
                  onDragStart={() => handleDragStart(index)}
                  onDragOver={e => handleDragOver(e, index)}
                  onDrop={e => handleDrop(e, index)}
                  onDragEnd={handleDragEnd}
                  className={`flex items-center p-4 border rounded-lg cursor-move transition-all ${
                    isDragging
                      ? "opacity-50"
                      : isDragOver
                        ? "border-brand-primary-main bg-brand-primary-50"
                        : isSelected
                          ? "border-brand-primary-main bg-brand-primary-50"
                          : "border-gray-200 hover:border-gray-300"
                  } ${column.locked ? "cursor-default" : ""}`}
                  style={{
                    backgroundColor: isSelected ? "var(--color-brand-primary-50, #DDDBF7)" : "#FFFFFF",
                    borderColor: isSelected
                      ? "var(--color-brand-primary-main, #461E96)"
                      : "var(--cds-color-border-primary, #E0E0E0)",
                  }}
                >
                  {/* Drag Handle */}
                  {!column.locked && (
                    <div
                      className="mr-3 cursor-grab active:cursor-grabbing"
                      style={{
                        color: isSelected
                          ? "var(--color-brand-primary-main, #461E96)"
                          : "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                      }}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={2}
                        stroke="currentColor"
                        className="w-5 h-5"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                      </svg>
                    </div>
                  )}

                  {/* Visibility Toggle */}
                  <button
                    onClick={() => toggleVisibility(index)}
                    disabled={column.locked}
                    className="mr-3"
                    style={{
                      color: column.visible
                        ? "var(--color-brand-primary-main, #461E96)"
                        : "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                      opacity: column.locked ? 0.5 : 1,
                      cursor: column.locked ? "not-allowed" : "pointer",
                    }}
                  >
                    {column.visible ? (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={2}
                        stroke="currentColor"
                        className="w-5 h-5"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"
                        />
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                      </svg>
                    ) : (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={2}
                        stroke="currentColor"
                        className="w-5 h-5"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88"
                        />
                      </svg>
                    )}
                  </button>

                  {/* Column Name */}
                  <div
                    className="flex-1 font-semibold"
                    style={{
                      color: isSelected ? "var(--color-brand-primary-main, #461E96)" : "var(--cencora-neutral-900-dark, #1E1E1E)",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "14px",
                      fontWeight: "600",
                      lineHeight: "20px",
                    }}
                  >
                    {column.label}
                  </div>

                  {/* Badge */}
                  <button
                    className="px-3 py-1 rounded-md border text-xs font-medium"
                    style={{
                      borderColor: isSelected
                        ? "var(--color-brand-primary-main, #461E96)"
                        : "var(--cds-color-border-primary, #E0E0E0)",
                      color: isSelected
                        ? "var(--color-brand-primary-main, #461E96)"
                        : "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                      backgroundColor: isSelected ? "var(--color-brand-primary-50, #DDDBF7)" : "transparent",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "12px",
                      fontWeight: "500",
                    }}
                  >
                    Badge
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
