import { useCallback, useMemo, useRef, useState } from "react";
import { isAxiosError } from "axios";
import {
  useCreateIssueNoteMutation,
  useUpdateIssueNoteMutation,
  useDeleteIssueNoteMutation,
  useIssueNotesQuery,
  ISSUE_NOTES_DEFAULT_LIMIT,
} from "@/hooks/queries";
import useProfile from "@/hooks/useProfile";
import type { IssueNote } from "@/services/issueNotesService";

export function noteKey(note: IssueNote): string {
  return String(note.id);
}

export function resolveIssueNoteErrorMessage(err: unknown, fallback: string): string {
  if (isAxiosError(err)) {
    const data = err.response?.data as { message?: string; detail?: string } | undefined;
    if (data && typeof data === "object") {
      if (typeof data.detail === "string") return data.detail;
      if (typeof data.message === "string") return data.message;
    }
    if (err.message) return err.message;
  }
  if (err instanceof Error && err.message) return err.message;
  return fallback;
}

export function useIssueNotesPanel(issueBackendId: string | undefined) {
  const notesQuery = useIssueNotesQuery({
    issueId: issueBackendId,
    limit: ISSUE_NOTES_DEFAULT_LIMIT,
  });

  const messagesNewestFirst = useMemo(() => {
    const pages = notesQuery.data?.pages;
    if (!pages?.length) return [];
    return pages.flatMap(p => p.results);
  }, [notesQuery.data]);

  const messagesOldestFirst = useMemo(() => [...messagesNewestFirst].reverse(), [messagesNewestFirst]);

  const [newContent, setNewContent] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [formError, setFormError] = useState("");

  const isMountedRef = useRef(true);
  isMountedRef.current = true;

  const { profile } = useProfile();

  const optimisticAuthor = useMemo(
    () =>
      profile
        ? {
            id: profile.id,
            user_data: {
              first_name: profile.givenName,
              last_name: profile.surname,
              email: profile.mail ?? profile.userPrincipalName,
            },
          }
        : undefined,
    [profile]
  );

  const createMutation = useCreateIssueNoteMutation(issueBackendId, optimisticAuthor, { silent: true });
  const updateMutation = useUpdateIssueNoteMutation(issueBackendId, { silent: true });
  const deleteMutation = useDeleteIssueNoteMutation(issueBackendId, { silent: true });

  const avatarSrc = profile?.photoDataUrl;
  const initials =
    profile?.givenName?.[0] || profile?.surname?.[0]
      ? `${profile?.givenName?.[0] ?? ""}${profile?.surname?.[0] ?? ""}`
      : "?";

  const handleCreateSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      setFormError("");
      const trimmed = newContent.trim();
      if (!trimmed) {
        setFormError("Note cannot be empty.");
        return;
      }
      if (!issueBackendId) return;
      try {
        await createMutation.mutateAsync({ content: trimmed });
        setNewContent("");
      } catch (err) {
        setFormError(resolveIssueNoteErrorMessage(err, "Failed to add note."));
      }
    },
    [newContent, issueBackendId, createMutation]
  );

  const startEdit = useCallback((note: IssueNote) => {
    setDeleteConfirmId(null);
    setEditingId(noteKey(note));
    setEditContent(note.content);
    setFormError("");
  }, []);

  const cancelEdit = useCallback(() => {
    setEditingId(null);
    setEditContent("");
    setFormError("");
  }, []);

  const saveEdit = useCallback(async () => {
    if (!editingId) return;
    const trimmed = editContent.trim();
    if (!trimmed) {
      setFormError("Note cannot be empty.");
      return;
    }
    try {
      await updateMutation.mutateAsync({ noteId: editingId, body: { content: trimmed } });
      cancelEdit();
    } catch (err) {
      setFormError(resolveIssueNoteErrorMessage(err, "Failed to update note."));
    }
  }, [editingId, editContent, updateMutation, cancelEdit]);

  const confirmDelete = useCallback(
    async (noteId: string) => {
      setFormError("");
      try {
        await deleteMutation.mutateAsync(noteId);
        setDeleteConfirmId(null);
      } catch (err) {
        setFormError(resolveIssueNoteErrorMessage(err, "Failed to delete note."));
      }
    },
    [deleteMutation]
  );

  const handleLoadOlder = useCallback(() => {
    if (!notesQuery.hasNextPage || notesQuery.isFetchingNextPage || !issueBackendId) return;
    void notesQuery.fetchNextPage();
  }, [notesQuery, issueBackendId]);

  return {
    notesQuery,
    messagesNewestFirst,
    messagesOldestFirst,
    newContent,
    setNewContent,
    editingId,
    editContent,
    setEditContent,
    deleteConfirmId,
    setDeleteConfirmId,
    formError,
    createMutation,
    updateMutation,
    deleteMutation,
    avatarSrc,
    initials,
    handleCreateSubmit,
    startEdit,
    cancelEdit,
    saveEdit,
    confirmDelete,
    handleLoadOlder,
  };
}
