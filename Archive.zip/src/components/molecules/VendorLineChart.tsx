import { formatApiDate } from "@/lib/dateUtils";
import SparkAreaLineChart from "@/components/molecules/SparkAreaLineChart";

interface ServiceLevel {
  date: string;
  avg_fill_rate: number;
  material__vendor_id?: string;
  total_order_qty?: number;
  total_received_qty?: number;
}
interface Vendor {
  id: number;
  name?: string;
  service_levels_90_days?: ServiceLevel[];
}
interface Props {
  vendor: Vendor;
}

export default function VendorLineChart({ vendor }: Props) {
  const data = vendor.service_levels_90_days ?? [];
  const sorted = [...data].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const series = sorted.map(s => {
    const orderQty = s.total_order_qty ?? 0;
    const receivedQty = s.total_received_qty ?? 0;
    return orderQty > 0 ? +((receivedQty / orderQty) * 100).toFixed(2) : 0;
  });
  const xLabels = sorted.map(s => s.date.slice(5));

  return (
    <SparkAreaLineChart
      data={series}
      xLabels={xLabels}
      height={50}
      color="rgba(70, 30, 150, 0.62)"
      strokeColor="#461E96"
      valueFormatter={value => `${value}%`}
      anchorTooltipToBucket
      computeYDomain={(minValue, maxValue) => [
        Math.min(minValue - 5, 0),
        maxValue + 5,
      ]}
      renderTooltip={({ tooltip, containerRef, valueFormatter: fmt }) => {
        const el = containerRef.current;
        if (!el || tooltip.anchorX == null) return null;

        const dataPoint = sorted[tooltip.index];
        if (!dataPoint) return null;

        const containerRect = el.getBoundingClientRect();
        const tooltipWidth = 168;
        const edgeMargin = 5;

        let tooltipLeft = tooltip.anchorX - tooltipWidth / 2;
        tooltipLeft = Math.min(
          Math.max(edgeMargin, tooltipLeft),
          Math.max(edgeMargin, containerRect.width - tooltipWidth - edgeMargin)
        );

        const formatDate = (dateStr: string) =>
          formatApiDate(dateStr, { month: "short", day: "numeric", year: "numeric" });

        return (
          <div
            className="absolute z-50 pointer-events-none"
            style={{
              left: `${tooltipLeft}px`,
              bottom: "calc(100% + 6px)",
              top: "auto",
            }}
          >
            <div className="pointer-events-none bg-[#211359] text-white text-xs rounded-md shadow-lg w-[168px] px-2.5 py-2 font-normal z-30">
              <div className="flex flex-col gap-2">
                <div className="flex flex-nowrap items-center justify-between gap-2">
                  <span className="shrink-0 whitespace-nowrap text-xs">Date:</span>
                  <span className="shrink-0 whitespace-nowrap text-right text-xs tabular-nums">
                    {formatDate(dataPoint.date)}
                  </span>
                </div>
                <div className="flex flex-nowrap items-center justify-between gap-2">
                  <span className="shrink-0 whitespace-nowrap text-xs">Inbound Fill Rate:</span>
                  <span className="shrink-0 whitespace-nowrap text-right text-xs tabular-nums">
                    {fmt(tooltip.value)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      }}
    />
  );
}
