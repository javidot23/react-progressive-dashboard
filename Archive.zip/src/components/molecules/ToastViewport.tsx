import { useCallback } from "react";
import { createPortal } from "react-dom";
import { useShallow } from "zustand/react/shallow";
import { useToastStore } from "@/stores/toastStore";
import { Toast } from "@/components/molecules/Toast";

export function ToastViewport() {
  const toasts = useToastStore(useShallow(s => s.toasts));
  const dismiss = useCallback((id: string) => {
    useToastStore.getState().dismiss(id);
  }, []);

  if (typeof document === "undefined") {
    return null;
  }

  return createPortal(
    <div
      role="region"
      aria-label="Notifications"
      className="pointer-events-none fixed inset-x-4 bottom-4 z-10050 flex flex-col gap-3 sm:left-auto sm:right-6 sm:bottom-6 sm:items-end sm:inset-x-auto"
    >
      {toasts.map(t => (
        <Toast key={t.id} toast={t} onDismiss={dismiss} />
      ))}
    </div>,
    document.body
  );
}
