import React from "react";
import { LegendItem } from "@/components/atoms/LegendItem";

interface LegendData {
  color: string;
  label: string;
  value?: string | number;
}

interface ChartLegendProps {
  items: LegendData[];
  className?: string;
}

export const ChartLegend: React.FC<ChartLegendProps> = ({ items, className = "" }) => {
  return (
    <div className={`flex flex-wrap gap-6 ${className}`}>
      {items.map((item, index) => (
        <LegendItem key={index} color={item.color} label={item.label} value={item.value} />
      ))}
    </div>
  );
};
