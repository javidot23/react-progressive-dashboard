import { Card, CardContent, CardHeader } from "@/components/atoms/Card";
import { cn } from "@/lib/utils";

interface GraphCardSkeletonProps {
  height?: string;
  className?: string;
}

export const GraphCardSkeleton = ({ height = "560px", className }: GraphCardSkeletonProps) => {
  return (
    <Card className={cn("flex flex-col rounded-[10px] border-[#E2E8F0]", className)} style={{ height }}>
      <CardHeader className="shrink-0">
        <div className="flex items-center gap-2 mb-2">
          <div
            className="bg-gray-200 rounded animate-pulse"
            style={{
              width: "280px",
              height: "28.8px",
            }}
          />
          <div className="h-4 w-4 bg-gray-200 rounded-full animate-pulse shrink-0" />
        </div>
        <div className="mb-4">
          <div className="bg-gray-200 rounded animate-pulse h-[20px] w-full max-w-[500px]" />
        </div>
        <div className="flex items-center gap-4 flex-wrap">
          {[1, 2, 3, 4, 5].map(item => (
            <div key={item} className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 bg-gray-200 rounded-sm animate-pulse" />
              <div className="bg-gray-200 rounded animate-pulse h-[20px] w-24" />
            </div>
          ))}
        </div>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col space-y-4 overflow-hidden pb-[25px]">
        <div className="w-full flex-1 min-h-[350px] relative">
          <div className="absolute inset-0 bg-gray-200 rounded animate-pulse" />
        </div>
        <div className="flex justify-end shrink-0 w-full">
          <div className="bg-gray-200 rounded animate-pulse h-[16px] w-24 mt-4" />
        </div>
      </CardContent>
    </Card>
  );
};
