import React from "react";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/atoms/Table";
import { useDataUpdateHistory } from "@/hooks/useDataUpdateHistory";

const formatDate = (dateString: string): string => {
  try {
    const date = new Date(dateString);
    return date.toLocaleString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    });
  } catch (error) {
    return dateString;
  }
};

const formatTableName = (tableName: string): string => {
  return tableName
    .split("_")
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

export const DataFreshnessTable: React.FC = () => {
  const { data, isLoading, error } = useDataUpdateHistory();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-ui-text-secondary">Loading data freshness information...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-red-600">Error loading data freshness: {error.message}</div>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-ui-text-secondary">No data freshness information available</div>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto border border-ui-border-primary rounded-md">
      <Table>
        <TableHeader className="bg-ui-background-secondary">
          <TableRow>
            <TableHead className="px-4 py-3 text-xs font-medium text-ui-text-secondary uppercase tracking-wider">
              Table Name
            </TableHead>
            <TableHead className="px-4 py-3 text-xs font-medium text-ui-text-secondary uppercase tracking-wider">
              Last Updated
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((item, index) => (
            <TableRow key={index} className="border-t hover:bg-ui-background-muted">
              <TableCell className="px-4 py-3 text-sm text-ui-text-primary font-medium">
                {formatTableName(item.table_name)}
              </TableCell>
              <TableCell className="px-4 py-3 text-sm text-ui-text-primary">{formatDate(item.last_updated)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};
