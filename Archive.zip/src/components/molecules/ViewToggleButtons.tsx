"use client";

import type React from "react";

import { Button } from "@/components/atoms/Button";

interface ViewToggleButtonsProps {
  currentView: string;
  onViewChange: (view: string) => void;
  views: { id: string; label: string; icon: React.ElementType }[];
}

export function ViewToggleButtons({ currentView, onViewChange, views }: ViewToggleButtonsProps) {
  return (
    <div className="flex items-center space-x-2">
      {views.map(view => (
        <Button
          key={view.id}
          action={currentView === view.id ? "secondary" : "primary"}
          variant={currentView === view.id ? "fill" : "outline"}
          onClick={() => onViewChange(view.id)}
        >
          <view.icon className="h-4 w-4 mr-2 text-slate-500" /> {view.label}
        </Button>
      ))}
    </div>
  );
}
