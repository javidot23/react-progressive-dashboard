import { useCallback, useEffect, useId, useRef, useState } from "react";
import { ArrowDownLeft, NotepadText } from "lucide-react";
import { IssueNotesPagePanel } from "@/components/molecules/IssueNotesPagePanel";
import { IssueNotesPopover } from "@/components/molecules/IssueNotesPopover";
import { issueNoteAuthorLabel } from "@/lib/issueNoteAuthorLabel";
import { formatRelativeTimeShort } from "@/lib/relativeTime";
import type { IssueNote } from "@/services/issueNotesService";

export type IssueNotesCardView = "card" | "page";

export interface IssueNotesCardProps {
  view?: IssueNotesCardView;
  issueBackendId: string | undefined;
  matNbr: string;
  ndc: string;
  hasActions: boolean;
  lastNote?: IssueNote | null;
  notesCount?: number;
  defaultOpen?: boolean;
}

export function IssueNotesCard({
  view = "card",
  issueBackendId,
  matNbr,
  ndc,
  hasActions,
  lastNote,
  notesCount,
  defaultOpen = false,
}: IssueNotesCardProps) {
  const anchorRef = useRef<HTMLButtonElement>(null);
  const panelId = useId();
  const titleId = useId();
  const [isOpen, setIsOpen] = useState(defaultOpen);

  useEffect(() => {
    if (defaultOpen) {
      setIsOpen(true);
    }
  }, [defaultOpen]);

  const closePopover = useCallback(() => {
    setIsOpen(false);
    requestAnimationFrame(() => {
      anchorRef.current?.focus();
    });
  }, []);

  const toggle = useCallback(() => {
    setIsOpen(v => !v);
  }, []);

  const stopDrillThroughNavigation = useCallback((e: React.SyntheticEvent) => {
    e.stopPropagation();
  }, []);

  if (view === "page") {
    return (
      <IssueNotesPagePanel
        issueBackendId={issueBackendId}
        matNbr={matNbr}
        ndc={ndc}
        isResolved={hasActions}
      />
    );
  }

  return (
    <>
      <button
        ref={anchorRef}
        type="button"
        onClick={e => {
          stopDrillThroughNavigation(e);
          toggle();
        }}
        onKeyDown={e => {
          stopDrillThroughNavigation(e);
        }}
        onMouseDown={stopDrillThroughNavigation}
        className="flex h-full w-full cursor-pointer flex-col rounded-md border border-[#735CCC] px-2 py-3 text-left"
        style={{ backgroundColor: "#EEEDFEE3" }}
        aria-expanded={isOpen}
        aria-haspopup="dialog"
        aria-controls={isOpen ? panelId : undefined}
        aria-label={`Notes, ${notesCount} total`}
      >
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="flex min-w-0 items-center gap-1.5">
            <NotepadText className="h-4 w-4 shrink-0 text-[#6E6E6E]" aria-hidden />
            <span className="text-sm font-semibold text-[#6E6E6E]">Notes</span>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <span
              className="inline-flex h-7 min-w-[28px] items-center justify-center rounded-full bg-[#461E96] px-2 text-xs font-semibold tabular-nums text-white"
              aria-hidden
            >
              {notesCount}
            </span>
            <span
              className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-md"
              style={{ backgroundColor: "#5B2E910F" }}
              aria-hidden
            >
              <ArrowDownLeft className="h-4 w-4 text-[#461E96]" strokeWidth={2.25} aria-hidden />
            </span>
          </div>
        </div>

        {lastNote ? (
          <div className="flex min-h-10 flex-1 gap-2">
            <div className="w-0.5 shrink-0 self-stretch rounded-full bg-[#461E96]" aria-hidden />
            <div className="min-w-0 flex-1">
              <p className="text-sm">
                <span className="font-semibold text-[#1E1E2D]">{issueNoteAuthorLabel(lastNote)}</span>
                <span className="text-[#888888]"> · </span>
                <time className="text-[#888888]" dateTime={lastNote.created_at}>
                  {formatRelativeTimeShort(lastNote.created_at)}
                </time>
                <span className="text-[#888888]"> · </span>
                <span className="text-[#5B2E91]">Last reply</span>
              </p>
              <p className="min-w-0 truncate text-xs text-[#555555]" title={lastNote.content}>
                {lastNote.content}
              </p>
            </div>
          </div>
        ) : (
          <div className="flex min-h-10 flex-1 items-start">
            <p className="text-xs text-[#888888]">No notes yet - click to add one</p>
          </div>
        )}
      </button>
      {isOpen && issueBackendId ? (
        <IssueNotesPopover
          onClose={closePopover}
          anchorRef={anchorRef}
          issueBackendId={issueBackendId}
          matNbr={matNbr}
          ndc={ndc}
          isResolved={hasActions}
          panelId={panelId}
          titleId={titleId}
        />
      ) : null}
    </>
  );
}
