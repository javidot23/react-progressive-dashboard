import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import { MessageSquarePlus, Camera, X, Trash2 } from 'lucide-react';
import { Button } from '@/components/atoms/Button';
import { useCreateFeedbackMutation } from '@/hooks/queries/useFeedbackMutations';
import { useAuth } from '@/contexts/AuthContext';

function parseRouteMetadata(pathname: string): { module: string; page: string; subtab: string } {
  const segments = pathname.replace(/^\//, '').split('/').filter(Boolean);

  if (segments.length === 0) return { module: '', page: '', subtab: '' };

  if (segments[0] === 'manage') {
    return {
      module: segments[1] ?? '',
      page: segments[2] ?? '',
      subtab: segments[3] ?? '',
    };
  }

  if (segments[0] === 'react') {
    return { module: 'react', page: segments[1] ?? '', subtab: '' };
  }

  if (segments[0] === 'plan') {
    return { module: 'plan', page: segments[1] ?? '', subtab: '' };
  }

  return { module: segments[0], page: '', subtab: '' };
}

interface HighlightRect {
  top: number;
  left: number;
  width: number;
  height: number;
}

export function FeedbackFAB() {
  const { isAuthenticated } = useAuth();
  const location = useLocation();
  const mutation = useCreateFeedbackMutation({ silent: true });

  const [isOpen, setIsOpen] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const [isPicking, setIsPicking] = useState(false);
  const [highlightRect, setHighlightRect] = useState<HighlightRect | null>(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const overlayRef = useRef<HTMLDivElement>(null);
  const hoveredElementRef = useRef<Element | null>(null);
  const pickTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const captureDelayTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const submitCloseTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
      if (pickTimeoutRef.current !== null) {
        clearTimeout(pickTimeoutRef.current);
        pickTimeoutRef.current = null;
      }
      if (captureDelayTimeoutRef.current !== null) {
        clearTimeout(captureDelayTimeoutRef.current);
        captureDelayTimeoutRef.current = null;
      }
      if (submitCloseTimeoutRef.current !== null) {
        clearTimeout(submitCloseTimeoutRef.current);
        submitCloseTimeoutRef.current = null;
      }
    };
  }, []);

  const handleOpen = () => {
    setFeedbackText('');
    setScreenshot(null);
    setSuccessMessage('');
    setErrorMessage('');
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  const exitPickMode = useCallback(() => {
    setIsPicking(false);
    setHighlightRect(null);
    hoveredElementRef.current = null;
    setIsOpen(true);
  }, []);

  // Escape key exits pick mode
  useEffect(() => {
    if (!isPicking) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') exitPickMode();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isPicking, exitPickMode]);

  const handleOverlayMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const overlay = overlayRef.current;
    if (!overlay) return;

    // Briefly disable pointer-events so elementFromPoint sees through the overlay
    overlay.style.pointerEvents = 'none';
    const el = document.elementFromPoint(e.clientX, e.clientY);
    overlay.style.pointerEvents = 'auto';

    if (!el || el === document.body || el === document.documentElement) {
      setHighlightRect(null);
      hoveredElementRef.current = null;
      return;
    }

    hoveredElementRef.current = el;
    const rect = el.getBoundingClientRect();
    setHighlightRect({ top: rect.top, left: rect.left, width: rect.width, height: rect.height });
  };

  const handleOverlayClick = async (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    const el = hoveredElementRef.current as HTMLElement | null;
    if (!el) return;

    setIsPicking(false);
    setHighlightRect(null);
    setIsCapturing(true);

    await new Promise<void>((resolve) => {
      if (captureDelayTimeoutRef.current !== null) {
        clearTimeout(captureDelayTimeoutRef.current);
      }
      captureDelayTimeoutRef.current = setTimeout(() => {
        captureDelayTimeoutRef.current = null;
        resolve();
      }, 50);
    });

    if (!isMountedRef.current) return;

    try {
      const html2canvas = (await import('html2canvas-pro')).default;
      const canvas = await html2canvas(el, {
        useCORS: true,
        logging: false,
      });
      if (!isMountedRef.current) return;
      setScreenshot(canvas.toDataURL('image/jpeg', 0.6));
    } catch (err) {
      console.error('Screenshot capture failed:', err);
      setErrorMessage('Screenshot capture failed. You can still submit feedback without one.');
    } finally {
      if (!isMountedRef.current) return;
      setIsCapturing(false);
      setIsOpen(true);
    }
  };

  const handleStartPicking = () => {
    setIsOpen(false);
    if (pickTimeoutRef.current !== null) {
      clearTimeout(pickTimeoutRef.current);
    }
    pickTimeoutRef.current = setTimeout(() => {
      pickTimeoutRef.current = null;
      if (isMountedRef.current) {
        setIsPicking(true);
      }
    }, 150);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    const { module, page, subtab } = parseRouteMetadata(location.pathname);

    try {
      await mutation.mutateAsync({ feedback: feedbackText, module, page, subtab, screenshot });
      setSuccessMessage('Feedback submitted. Thank you!');
      setFeedbackText('');
      setScreenshot(null);
      if (submitCloseTimeoutRef.current !== null) {
        clearTimeout(submitCloseTimeoutRef.current);
      }
      submitCloseTimeoutRef.current = setTimeout(() => {
        submitCloseTimeoutRef.current = null;
        if (!isMountedRef.current) return;
        setIsOpen(false);
        setSuccessMessage('');
      }, 1500);
    } catch {
      setErrorMessage('Failed to submit feedback. Please try again.');
    }
  };

  if (!isAuthenticated) return null;

  return (
    <>
      {/* FAB */}
      <div className="fixed bottom-6 right-6 z-10000 group">
        <button
          onClick={handleOpen}
          aria-label="Submit feedback"
          className="flex items-center justify-center w-12 h-12 bg-brand-primary-main text-white rounded-full shadow-lg hover:bg-brand-primary-dark transition-colors focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-2"
        >
          <MessageSquarePlus className="h-5 w-5" />
        </button>
        <div className="absolute bottom-14 right-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-150">
          <span className="whitespace-nowrap bg-gray-900 text-white text-xs font-medium px-2.5 py-1.5 rounded-md shadow-sm">
            Submit feedback
          </span>
        </div>
      </div>

      {/* Capture loading overlay — fixed position, outside any captured element's subtree */}
      {isCapturing && (
        <div className="fixed inset-0 z-10003 flex flex-col items-center justify-center bg-black/40">
          <div className="bg-white rounded-lg px-8 py-6 flex flex-col items-center gap-3 shadow-xl">
            <div className="h-8 w-8 animate-spin rounded-full border-[3px] border-ui-border-primary border-t-brand-primary-main" />
            <p className="text-sm font-medium text-ui-text-primary">Capturing element…</p>
          </div>
        </div>
      )}

      {/* Element picker overlay */}
      {isPicking && (
        <div
          ref={overlayRef}
          className="fixed inset-0 z-10002 cursor-crosshair"
          style={{ background: 'rgba(0,0,0,0.25)' }}
          onMouseMove={handleOverlayMouseMove}
          onClick={handleOverlayClick}
        >
          {/* Instruction banner */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs font-medium px-4 py-2 rounded-full shadow-lg pointer-events-none select-none">
            Click an element to capture it &nbsp;·&nbsp; Esc to cancel
          </div>

          {/* Highlight box */}
          {highlightRect && (
            <div
              className="absolute pointer-events-none"
              style={{
                top: highlightRect.top,
                left: highlightRect.left,
                width: highlightRect.width,
                height: highlightRect.height,
                outline: '2px solid #2563eb',
                background: 'rgba(37,99,235,0.08)',
              }}
            />
          )}
        </div>
      )}

      {/* Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-10001 flex items-end sm:items-center justify-center sm:justify-end sm:pr-6 sm:pb-20">
          <div className="absolute inset-0 bg-black/40" onClick={handleClose} />

          <div className="relative bg-white rounded-lg shadow-2xl w-full max-w-sm mx-4 sm:mx-0">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200">
              <h2 className="text-base font-semibold text-ui-text-primary">Submit Feedback</h2>
              <button
                onClick={handleClose}
                className="p-1 rounded-md text-ui-text-secondary hover:bg-ui-background-muted transition-colors"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="px-5 py-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-ui-text-secondary mb-1">
                  Feedback <span className="text-status-error-main">*</span>
                </label>
                <textarea
                  value={feedbackText}
                  onChange={e => setFeedbackText(e.target.value)}
                  required
                  rows={4}
                  placeholder="Describe your feedback..."
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-ui-text-secondary mb-1">Screenshot</label>
                {screenshot ? (
                  <div className="relative">
                    <img
                      src={screenshot}
                      alt="Screenshot preview"
                      className="w-full h-28 object-cover rounded-md border border-ui-border-primary"
                    />
                    <button
                      type="button"
                      onClick={() => setScreenshot(null)}
                      className="absolute top-1.5 right-1.5 bg-white rounded-full p-0.5 shadow-sm text-ui-text-secondary hover:text-status-error-main transition-colors"
                      aria-label="Remove screenshot"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ) : (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleStartPicking}
                    isLoading={isCapturing}
                    className="w-full text-xs gap-1.5"
                  >
                    <Camera className="h-3.5 w-3.5" />
                    Pick element to capture
                  </Button>
                )}
              </div>

              {successMessage && (
                <p className="text-xs text-status-success-main font-medium">{successMessage}</p>
              )}
              {errorMessage && (
                <p className="text-xs text-status-error-main">{errorMessage}</p>
              )}

              <div className="flex justify-end gap-2 pt-1">
                <Button type="button" variant="secondary" size="sm" onClick={handleClose}>
                  Cancel
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  isLoading={mutation.isPending}
                  disabled={!feedbackText.trim()}
                >
                  Submit
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
