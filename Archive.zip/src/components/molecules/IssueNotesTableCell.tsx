import { useCallback, useId, useRef, useState } from "react";
import { NotepadText } from "lucide-react";
import { IssueNotesPopover } from "@/components/molecules/IssueNotesPopover";
import { issueNoteAuthorLabel } from "@/lib/issueNoteAuthorLabel";
import { formatRelativeTimeShort } from "@/lib/relativeTime";
import type { IssueNote } from "@/services/issueNotesService";

export interface IssueNotesTableCellProps {
  issueBackendId: string | undefined;
  matNbr: string;
  ndc: string;
  hasActions: boolean;
  lastNote?: IssueNote | null;
  notesCount?: number;
}

function previewLabel(lastNote: IssueNote | null | undefined): string {
  if (!lastNote) return "Add a note";
  return `${issueNoteAuthorLabel(lastNote)} · ${formatRelativeTimeShort(lastNote.created_at)}`;
}

export function IssueNotesTableCell({ issueBackendId, matNbr, ndc, hasActions, lastNote, notesCount }: IssueNotesTableCellProps) {
  const anchorRef = useRef<HTMLButtonElement>(null);
  const panelId = useId();
  const titleId = useId();
  const [isOpen, setIsOpen] = useState(false);

  const count = notesCount ?? (lastNote ? 1 : 0);

  const closePopover = useCallback(() => {
    setIsOpen(false);
    requestAnimationFrame(() => {
      anchorRef.current?.focus();
    });
  }, []);

  const toggle = useCallback(() => {
    setIsOpen(v => !v);
  }, []);

  const tip = previewLabel(lastNote ?? null);
  const aria = `Notes, ${count} total. ${tip}`;

  return (
    <>
      <button
        ref={anchorRef}
        type="button"
        onClick={e => {
          e.stopPropagation();
          toggle();
        }}
        onKeyDown={e => {
          if (e.key === "Enter" || e.key === " ") {
            e.stopPropagation();
          }
        }}
        title={tip}
        className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border border-[#735CCC] px-2 py-1.5 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-[#461E96] focus-visible:ring-offset-2"
        style={{ backgroundColor: "#EEEDFEE3" }}
        aria-expanded={isOpen}
        aria-haspopup="dialog"
        aria-controls={isOpen ? panelId : undefined}
        aria-label={aria}
      >
        <NotepadText className="h-4 w-4 shrink-0 text-[#6E6E6E]" aria-hidden />
        {lastNote?.content ? (
          <span className="min-w-0 max-w-[220px] truncate text-xs text-[#555555]">{lastNote.content}</span>
        ) : null}
        <span
          className="inline-flex h-7 min-w-[28px] items-center justify-center rounded-full bg-[#461E96] px-2 text-xs font-semibold tabular-nums text-white"
          aria-hidden
        >
          {count}
        </span>
      </button>
      {isOpen && issueBackendId ? (
        <IssueNotesPopover
          onClose={closePopover}
          anchorRef={anchorRef}
          issueBackendId={issueBackendId}
          matNbr={matNbr}
          ndc={ndc}
          isResolved={hasActions}
          panelId={panelId}
          titleId={titleId}
        />
      ) : null}
    </>
  );
}
