import { Download } from "lucide-react";
import { Button } from "@/components/atoms/Button";
import { Typography } from "@/components/atoms/Typography";
import { cn } from "@/lib/utils";

export type DownloadCsvButtonProps = {
  onDownload: () => void;
  disabled?: boolean;
  className?: string;
};

/**
 * Shared "Download CSV" control for chart (and similar) headers.
 */
export function DownloadCsvButton({ onDownload, disabled = false, className }: DownloadCsvButtonProps) {
  return (
    <Button
      type="button"
      variant="text"
      size="sm"
      disabled={disabled}
      aria-label="Download chart data as CSV"
      onClick={onDownload}
      className={cn(className)}
    >
      <Download className="h-4 w-4" aria-hidden />
      <Typography as="span" variant="body2" color="accent" className="font-bold">
        Download CSV
      </Typography>
    </Button>
  );
}
