import { Download } from "lucide-react";
import { Button } from "@/components/atoms/Button";
import { Typography } from "@/components/atoms/Typography";
import { cn } from "@/lib/utils";

export type DownloadCsvButtonProps = {
  onDownload: () => void;
  disabled?: boolean;
  className?: string;
};

/**
 * Shared "Download CSV" control for chart (and similar) headers.
 */
export function DownloadCsvButton({
  onDownload,
  disabled = false,
  className,
}: DownloadCsvButtonProps) {
  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      disabled={disabled}
      aria-label="Download chart data as CSV"
      onClick={onDownload}
      className={cn(
        "h-9 gap-2 rounded-md border-2 border-brand-primary-main px-3 text-sm font-bold text-brand-primary-main transition-colors hover:bg-brand-primary-50 focus-visible:ring-brand-primary-main focus-visible:ring-offset-1 disabled:pointer-events-auto disabled:cursor-not-allowed disabled:opacity-50 shrink-0",
        className
      )}
    >
      <Download className="h-4 w-4" aria-hidden />
      <Typography as="span" variant="body2" color="accent" className="font-bold">
        Download CSV
      </Typography>
    </Button>
  );
}
