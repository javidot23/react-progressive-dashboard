import {TableRow, TableCell} from "@/components/atoms/Table";
import {Checkbox} from "@/components/atoms/Checkbox";
import {Badge} from "@/components/atoms/Badge";
import {RiskLevelIndicator} from "@/components/atoms/RiskLevelIndicator";
import {AIRecommendationSnippet} from "@/components/molecules/AiRecommendationSnippet";
import type {IssueItem} from "@/lib/types";
import {cn} from "@/lib/utils";

const actionStatusColors: Record<IssueItem["actionStatus"], string> = {
  "ACTION REQUIRED":
    "bg-status-error-light text-status-error-main border-status-error-main",
  "ACTION REVIEWED":
    "bg-status-success-light text-status-success-main border-status-success-main",
  "UNDER REVIEW":
    "bg-status-warning-light text-status-warning-main border-status-warning-main",
  RESOLVED: "bg-slate-100 text-slate-600 border-slate-300",
};

interface IssueTableRowProps {
  issue: IssueItem;
  onSelectRow: (id: string, checked: boolean) => void;
}

export function IssueTableRow({issue, onSelectRow}: IssueTableRowProps) {
  return (
    <TableRow key={issue.id} data-state={issue.selected ? "selected" : ""}>
      <TableCell>
        <Checkbox
          checked={issue.selected}
          onCheckedChange={checked => onSelectRow(issue.id, !!checked)}
          aria-labelledby={`select-issue-${issue.id}`}
        />
        <span id={`select-issue-${issue.id}`} className="sr-only">
          Select issue {issue.productName}
        </span>
      </TableCell>
      <TableCell className="font-medium text-slate-700 text-sm">
        {issue.vendor}
      </TableCell>
      <TableCell>
        <div className="text-status-info-main font-medium text-sm">
          {issue.productName}
        </div>
        <div className="text-xs text-slate-500">{issue.productDetails}</div>
      </TableCell>
      <TableCell>
        <RiskLevelIndicator level={issue.riskLevel} />
      </TableCell>
      <TableCell className="text-sm">
        <div>{issue.riskExposureValue}</div>
        <div className="text-xs text-slate-500">{issue.riskExposureBase}</div>
      </TableCell>
      <TableCell className="text-sm text-slate-600">
        {issue.primaryRiskDriver}
      </TableCell>
      <TableCell>
        <Badge
          variant="outline"
          className={cn(
            "font-semibold text-xs px-2 py-0.5",
            actionStatusColors[issue.actionStatus]
          )}
        >
          {issue.actionStatus}
        </Badge>
      </TableCell>
      <TableCell>
        <AIRecommendationSnippet recommendation={issue.aiRecommendation} />
      </TableCell>
    </TableRow>
  );
}
