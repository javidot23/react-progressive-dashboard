import { forwardRef, useImperativeHandle, useMemo, useState } from "react";
import { Line, XAxis, YAxis, ResponsiveContainer, Area, AreaChart } from "recharts";
import { createPortal } from "react-dom";
import { formatPercentageDisplay } from "@/lib/utils";

interface HistoricalDataPoint {
  year: number;
  month: number;
  percentage: number;
}

export interface HistoricalDataTooltipProps {
  title: string;
  data: HistoricalDataPoint[];
  isVisible: boolean;
  position: { x: number; y: number };
  average?: number;
}

export type HistoricalDataTooltipManagedState = {
  isVisible: boolean;
  title: string;
  data: HistoricalDataPoint[];
  position: { x: number; y: number };
  average?: number;
};

export type HistoricalDataTooltipHandle = {
  show: (payload: Omit<HistoricalDataTooltipManagedState, "isVisible"> & { average?: number }) => void;
  setPosition: (position: { x: number; y: number }) => void;
  hide: () => void;
};

type ManagedState = HistoricalDataTooltipManagedState | null;

const HistoricalDataTooltip = forwardRef<HistoricalDataTooltipHandle | null, HistoricalDataTooltipProps>(
  function HistoricalDataTooltip({ title, data, isVisible, position, average: averageProp }, ref) {
    const [managed, setManaged] = useState<ManagedState>(null);

    useImperativeHandle(
      ref,
      () => ({
        show: payload => {
          setManaged({
            isVisible: true,
            title: payload.title,
            data: payload.data,
            position: payload.position,
            average: payload.average,
          });
        },
        setPosition: nextPosition => {
          setManaged(m => (m?.isVisible ? { ...m, position: nextPosition } : m));
        },
        hide: () => setManaged(null),
      }),
      []
    );

    const effectiveTitle = managed !== null ? managed.title : title;
    const effectiveData = managed !== null ? managed.data : data;
    const effectiveVisible = managed !== null ? managed.isVisible : isVisible;
    const effectivePosition = managed !== null ? managed.position : position;
    const effectiveAverage = managed !== null ? managed.average : averageProp;

    const tooltipContent = useMemo(() => {
      if (!effectiveVisible || !effectiveData || effectiveData.length === 0) {
        return null;
      }

      const gradientId = `areaGradient-${effectiveTitle.replace(/\s+/g, "-").toLowerCase()}`;

      const sortedData = [...effectiveData].sort((a, b) => {
        if (a.year !== b.year) return a.year - b.year;
        return a.month - b.month;
      });

      const chartData = sortedData.map(point => {
        const date = new Date(point.year, point.month - 1);
        const monthName = date.toLocaleDateString("en-US", { month: "short" });

        return {
          month: monthName,
          year: point.year,
          percentage: point.percentage,
          fullDate: date,
          sortKey: point.year * 12 + point.month,
        };
      });

      const percentages = effectiveData.map(point => point.percentage).filter(p => !Number.isNaN(p) && Number.isFinite(p));

      if (percentages.length === 0) {
        return null;
      }

      const minPercentage = Math.min(...percentages);
      const maxPercentage = Math.max(...percentages);

      const range = maxPercentage - minPercentage;

      let padding: number;
      if (range < 5) {
        padding = Math.max(2, (5 - range) / 2);
      } else {
        padding = range * 0.1;
      }

      const yAxisDomain = [Math.max(0, minPercentage - padding), Math.min(100, maxPercentage + padding)];

      const calculatedAverage = effectiveAverage ?? percentages.reduce((sum, p) => sum + p, 0) / percentages.length;

      return (
        <div
          className="fixed z-9999 bg-white border border-gray-200 rounded-[4px] shadow-xl p-2 pointer-events-none"
          style={{
            left: `${effectivePosition.x}px`,
            top: `${effectivePosition.y}px`,
            minWidth: "320px",
            maxWidth: "400px",
          }}
        >
          <h3 className="text-sm font-bold text-gray-900 mb-3">{effectiveTitle}</h3>

          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="128%">
              <AreaChart data={chartData} margin={{ top: 5, right: 20, left: 5, bottom: 60 }}>
                <defs>
                  <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="rgba(70, 30, 150, 0.3)" />
                    <stop offset="100%" stopColor="rgba(70, 30, 150, 0.05)" />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="month"
                  axisLine={false}
                  tickLine={false}
                  interval={0}
                  height={60}
                  tick={props => {
                    const { x, y, payload, index } = props;
                    const dataPoint = chartData[index];
                    const prevDataPoint = index > 0 ? chartData[index - 1] : null;
                    const showYear = !prevDataPoint || prevDataPoint.year !== dataPoint.year;

                    return (
                      <g transform={`translate(${x},${y})`}>
                        <text x={0} y={0} dy={16} textAnchor="end" fill="#666" fontSize="10" transform="rotate(-45)">
                          {payload.value}
                        </text>
                        {showYear && (
                          <text x={0} y={0} dy={40} textAnchor="middle" fill="#999" fontSize="9">
                            {dataPoint.year}
                          </text>
                        )}
                      </g>
                    );
                  }}
                />
                <YAxis
                  domain={yAxisDomain}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 9, fill: "#666" }}
                  tickFormatter={value => formatPercentageDisplay(Number(value), 2)}
                  allowDataOverflow={false}
                  allowDecimals
                  width={40}
                />
                <Area type="monotone" dataKey="percentage" stroke="#461E96" fill={`url(#${gradientId})`} strokeWidth={2} />
                <Line
                  type="monotone"
                  dataKey={() => calculatedAverage}
                  stroke="#461E96"
                  strokeDasharray="5 5"
                  strokeWidth={1}
                  dot={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-2 text-xs text-gray-600 font-medium">
            Average of months shown: {formatPercentageDisplay(calculatedAverage, 2)}
          </div>
        </div>
      );
    }, [effectiveAverage, effectiveData, effectivePosition.x, effectivePosition.y, effectiveTitle, effectiveVisible]);

    const portalTarget = typeof document !== "undefined" ? document.body : null;

    if (!portalTarget || !tooltipContent) {
      return null;
    }

    return createPortal(tooltipContent, portalTarget);
  }
);

export default HistoricalDataTooltip;
