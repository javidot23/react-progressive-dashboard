import { useState, useRef, useEffect, useCallback, type CSSProperties } from "react";
import { useNavigate } from "react-router-dom";
import { useIsMobile } from "@/hooks/useMobile";

export interface DropdownItem {
  label: string;
  path: string;
  tenant?: import("@/tenant").TenantId | readonly import("@/tenant").TenantId[];
  [key: string]: unknown;
}

interface NavigationDropdownProps {
  label: string;
  items: DropdownItem[];
  activePath: string;
  onLabelClick?: () => void;
}

export default function NavigationDropdown({ label, items, activePath, onLabelClick }: NavigationDropdownProps) {
  const [open, setOpen] = useState(false);
  const [dropdownPos, setDropdownPos] = useState({ top: 147, left: 0 });
  const navigate = useNavigate();
  const dropdownRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();

  const isActive = () => {
    if (label === "Supply") {
      return activePath.startsWith("/manage/supply") && !activePath.startsWith("/manage/supply-management");
    }

    const activeMap: Record<string, string[]> = {
      Demand: ["/manage/demand"],
      Orders: ["/manage/orders"],
      Sales: ["/manage/sales"],
      Inventory: ["/manage/inventory"],
      FTS: ["/manage/fts"],
      Chargebacks: ["/manage/chargebacks"],
      "Formulary Change Tracking": ["/manage/formulary-change-tracking"],
      "Secure Supply Chain": ["/manage/secure-supply-chain"],
    };

    const pathsToCheck = activeMap[label] || [`/manage/${label.toLowerCase()}`];
    return pathsToCheck.some(path => activePath.startsWith(path));
  };

  const updateDropdownPosition = useCallback(() => {
    if (!triggerRef.current) return;
    const rect = triggerRef.current.getBoundingClientRect();
    setDropdownPos({ top: rect.bottom, left: rect.left });
  }, []);

  useEffect(() => {
    if (!open) return;
    updateDropdownPosition();
    window.addEventListener("resize", updateDropdownPosition);

    const handleScroll = () => {
      if (isMobile) {
        setOpen(false);
        return;
      }
      updateDropdownPosition();
    };

    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      window.removeEventListener("resize", updateDropdownPosition);
      window.removeEventListener("scroll", handleScroll);
    };
  }, [open, isMobile, updateDropdownPosition]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const getDropdownStyle = (): CSSProperties => {
    if (isMobile) {
      return {
        position: "fixed",
        top: `${dropdownPos.top}px`,
        left: "16px",
        right: "16px",
        zIndex: 9999,
        transform: "translate3d(0, 0, 0)",
        WebkitTransform: "translate3d(0, 0, 0)",
      };
    }

    return {
      position: "fixed",
      top: `${dropdownPos.top}px`,
      left: `${dropdownPos.left}px`,
      zIndex: 9999,
      transform: "translate3d(0, 0, 0)",
      WebkitTransform: "translate3d(0, 0, 0)",
    };
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <div
        ref={triggerRef}
        className={`relative flex items-center gap-1 px-3 sm:px-4 md:px-3 lg:px-4 py-4 text-sm transition-colors whitespace-nowrap cursor-pointer rounded-t-[16px] ${
          isMobile ? "touch-manipulation" : ""
        } ${isActive() ? "text-[#1E1E1E] font-black" : "text-ui-text-heading-primary hover:text-ui-text-heading font-medium"}`}
        style={
          isActive()
            ? {
                background: "linear-gradient(to bottom, #461E9600 0%, #461E96 300%)",
              }
            : undefined
        }
      >
        <span
          onClick={() => {
            const getDropdownRoute = (label: string) => {
              const routeMap: Record<string, string> = {
                Supply: "/manage/supply/overview",
                Demand: "/manage/demand/overview",
                Orders: "/manage/orders/overview",
                Sales: "/manage/sales/overview",
                Inventory: "/manage/inventory/overview",
                FTS: "/manage/fts/mitigation",
                Chargebacks: "/manage/chargebacks/overview",
                "Formulary Change Tracking": "/manage/formulary-change-tracking",
                "Secure Supply Chain": "/manage/secure-supply-chain/inbound-scans",
              };
              return routeMap[label] || `/manage/${label.toLowerCase().replace(/ /g, "-")}`;
            };

            navigate(getDropdownRoute(label));
            onLabelClick?.();
            setOpen(false);
          }}
        >
          {label}
        </span>

        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={1.5}
          stroke="currentColor"
          className={`size-5 cursor-pointer ${isMobile ? "touch-manipulation" : ""}`}
          onClick={e => {
            e.stopPropagation();
            if (open) {
              setOpen(false);
            } else {
              updateDropdownPosition();
              setOpen(true);
            }
          }}
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
        </svg>

        {isActive() && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-ui-interactive-primary" />}
      </div>
      {open && (
        <div
          className={`bg-white border border-gray-200 rounded-md shadow-lg ${!isMobile ? "w-auto min-w-50" : ""}`}
          style={getDropdownStyle()}
        >
          {items.map(item => {
            const isItemActive = activePath === item.path;
            return (
              <button
                key={item.path}
                onClick={() => {
                  navigate(item.path);
                  setOpen(false);
                }}
                className={`w-full flex items-center px-4 py-3 text-sm text-left transition-colors whitespace-nowrap ${
                  isMobile ? "touch-manipulation" : ""
                } ${
                  isItemActive ? "bg-ui-interactive-primary-lightest font-bold text-black" : "text-gray-700 hover:bg-primary-50"
                }`}
              >
                <span className="w-4 shrink-0 mr-2 flex items-center justify-center ">
                  {isItemActive && (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth={2}
                      className="w-4 h-4 text-ui-interactive-primary"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                    </svg>
                  )}
                </span>
                <span className="text-sm whitespace-nowrap">{item.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
