import React, { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Pagination, RiskBadge } from "@/components/atoms";
import { getRiskBadge } from "@/lib/vendorUtils";
import { IssueNotesTableCell } from "@/components/molecules/IssueNotesTableCell";
import { DrivingEventStrip } from "@/components/molecules/DrivingEventStrip";
import { TableColumn } from "@/components/molecules/ReorderTableModal";
import {
  getDefaultIssueFeedColumns,
  getIssueCtaLabel,
  getIssueDisplayTitle,
  normalizeIssueTableScope,
  openIssueDrillThrough,
  type IssueFeedTableScope,
} from "@/lib/issueTableConfig";
import type { GranularityIssueView } from "@/types/granularityIssue";

type IssueData = GranularityIssueView & {
  gcnNumber?: string;
  gcnDescription?: string;
  materialInGcn?: string;
  category?: string;
  manufacturerId?: string;
};

type IssueTableViewScope = "material" | "gcn" | "product" | IssueFeedTableScope;

interface IssueTableViewProps {
  data: IssueData[];
  currentPage: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  viewScope?: IssueTableViewScope;
  columns?: TableColumn[];
  vendorId?: number;
}

export const IssueTableView: React.FC<IssueTableViewProps> = ({
  data,
  currentPage,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  viewScope = "material",
  columns = [],
}) => {
  const navigate = useNavigate();
  const feedScope = normalizeIssueTableScope(viewScope);
  const statusPillClass =
    "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FCD9D1] text-sm font-semibold text-[#E22F00]";
  const createdDateClass =
    "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-transparent text-sm font-medium text-ui-text-primary";

  const visibleColumns = useMemo(() => {
    if (columns.length > 0) {
      return columns.filter(col => col.visible);
    }
    return getDefaultIssueFeedColumns(feedScope);
  }, [columns, feedScope]);

  const renderHeader = (column: TableColumn) => {
    const headerLabels: Record<string, string> = {
      issue_name: feedScope === "material" ? "Material Name" : "Issue",
      material_name: "Material Name",
      // granularity_level: "Level",
      granularity_value: "Identifier",
      group: "Group",
      issue_status: "Issue Status",
      driving_event: "Driving Event",
      materials_impacted: "Materials Impacted",
      material_id: "Material ID",
      material_status: "Material Status",
      vendor_name: "Vendor",
      vendor_nbr: "Vendor Id",
      manufacturer_id: "Manufacturer ID",
      ndc: "NDC",
      risk_score: "Risk Score",
      primary_risk: "Driving Risk",
      risk_adjusted_value: "Risk Adjusted Value / Value at Risk",
      created_date: "Identified",
      action_status: "Action Status",
      notes: "Notes",
      persona: "Persona",
      recommended_actions: "Recommended Actions",
      gcn_number: column.label,
      gcn_description: column.label,
      material_in_gcn: column.label,
      category: "Category",
    };

    const label = headerLabels[column.id] ?? column.label;
    const className =
      column.id === "issue_name" || column.id === "material_name"
        ? "px-4 py-2 min-w-[180px]"
        : column.id === "driving_event" || column.id === "risk_adjusted_value"
          ? "px-4 py-2 min-w-[220px]"
          : "px-4 py-2 min-w-[140px]";

    return (
      <th key={column.id} className={className}>
        {label}
      </th>
    );
  };

  const renderCell = (column: TableColumn, issue: IssueData) => {
    const riskLevel = issue.riskLevel / 100;
    const hasActions = issue.hasActions;
    const status = hasActions ? "reviewed" : "not_reviewed";
    const isNewIssue = issue.isNewIssue;
    const actionStatusText = status === "reviewed" ? "Reviewed" : "Not Reviewed";
    const ctaLabel = getIssueCtaLabel(issue);

    const cellConfig: Record<string, { className: string; content: React.ReactNode; isRowHeader?: boolean }> = {
      issue_name: {
        className: "px-4 py-2 min-w-[180px]",
        isRowHeader: true,
        content: (
          <div className="flex flex-row items-center gap-2">
            {isNewIssue ? <div className="h-2 w-2 rounded-full bg-[#E22F00]" /> : null}
            <div className="font-semibold text-ui-text-primary">{getIssueDisplayTitle(issue)}</div>
          </div>
        ),
      },
      material_name: {
        className: "px-4 py-2 min-w-[180px]",
        isRowHeader: true,
        content: (
          <div className="flex flex-row items-center gap-2">
            {isNewIssue ? <div className="h-2 w-2 rounded-full bg-[#E22F00]" /> : null}
            <div className="font-normal">{issue.productName}</div>
          </div>
        ),
      },
      // granularity_level: {
      //   className: "px-4 py-2 min-w-[140px]",
      //   content: issue.granularityLabel ?? "Issue",
      // },
      granularity_value: {
        className: "px-4 py-2 min-w-[140px]",
        content: <span className="font-mono">{issue.granularityValue || "-"}</span>,
      },
      group: {
        className: "px-4 py-2 min-w-[160px]",
        content: issue.group ? `${issue.group}` : "-",
      },
      issue_status: {
        className: "px-4 py-2 min-w-[140px]",
        content: isNewIssue ? <span className={statusPillClass}>New Issue</span> : "-",
      },
      driving_event: {
        className: "px-4 py-2 min-w-[220px]",
        content: <DrivingEventStrip compact event={issue.drivingEvent} drivingRisk={issue.drivingRisk} />,
      },
      materials_impacted: {
        className: "px-4 py-2 min-w-[140px]",
        content: String(issue.impactedMaterialCount ?? (issue.isSingleMaterial ? 1 : "-")),
      },
      material_id: {
        className: "px-4 py-2 min-w-[120px]",
        content: issue.mat_nbr || "-",
      },
      vendor_name: {
        className: "px-4 py-2 min-w-[160px]",
        content: issue.vendorName || "-",
      },
      vendor_nbr: {
        className: "px-4 py-2 min-w-[120px]",
        content: issue.vendorNbr || "-",
      },
      manufacturer_id: {
        className: "px-4 py-2 min-w-[120px]",
        content: issue.manufacturerId || "-",
      },
      ndc: {
        className: "px-4 py-2 min-w-[120px]",
        content: issue.ndc || "-",
      },
      material_status: {
        className: "px-4 py-2 min-w-[150px]",
        content: issue.xplantMatStatDesc || "-",
      },
      risk_score: {
        className: "px-4 py-2 min-w-[200px]",
        content: (() => {
          const riskBadge = getRiskBadge(riskLevel);
          return (
            <div className="flex flex-row items-center gap-2">
              <div className="h-1 w-[100px] rounded-full bg-gray-200">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: "100%",
                    backgroundColor: riskBadge.hexColor,
                  }}
                />
              </div>
              <RiskBadge riskRating={riskLevel} showIcon size="sm" />
            </div>
          );
        })(),
      },
      primary_risk: {
        className: "px-4 py-2 min-w-[150px]",
        content: issue.drivingRisk || "-",
      },
      risk_adjusted_value: {
        className: "px-4 py-2 min-w-[220px]",
        content: issue.riskExposure || "- / -",
      },
      created_date: {
        className: "px-4 py-2 min-w-[160px]",
        content: <span className={createdDateClass}>{issue.createdAt || "-"}</span>,
      },
      action_status: {
        className: "px-4 py-2 min-w-[160px]",
        content: (
          <div className="flex items-center">
            {status === "reviewed" ? (
              <div className="mr-2 inline-flex items-center justify-center rounded-full border border-[#06C07A] bg-[#D8FEE7] p-1">
                <div className="h-2 w-2 rounded-full bg-[#119D63]" />
              </div>
            ) : (
              <div className="mr-2 inline-flex items-center justify-center rounded-full border border-[#E22F008A] bg-[#FEEFEB] p-1">
                <div className="h-2 w-2 rounded-full bg-[#E22F00]" />
              </div>
            )}
            {actionStatusText}
          </div>
        ),
      },
      notes: {
        className: "px-4 py-2 min-w-[120px]",
        content: (
          <IssueNotesTableCell
            issueBackendId={String(issue.id)}
            matNbr={issue.mat_nbr}
            ndc={issue.ndc}
            hasActions={hasActions}
            lastNote={issue.lastNote}
            notesCount={issue.notesCount}
          />
        ),
      },
      persona: {
        className: "px-4 py-2 min-w-[140px]",
        content: issue.persona || "-",
      },
      recommended_actions: {
        className: "px-4 py-2 min-w-[220px]",
        content: (
          <button
            type="button"
            onClick={e => {
              e.stopPropagation();
              openIssueDrillThrough(navigate, issue);
            }}
            className="rounded px-3 py-1 text-sm font-semibold whitespace-nowrap text-white"
            style={{ backgroundColor: "#461E96", borderRadius: "4px" }}
          >
            {ctaLabel}
          </button>
        ),
      },
      gcn_number: {
        className: "px-4 py-2 min-w-[140px]",
        content: issue.gcnNumber || issue.granularityValue || "-",
      },
      gcn_description: {
        className: "px-4 py-2 min-w-[180px]",
        content: issue.gcnDescription || "-",
      },
      material_in_gcn: {
        className: "px-4 py-2 min-w-[160px]",
        content: issue.materialInGcn || "-",
      },
      category: {
        className: "px-4 py-2 min-w-[140px]",
        content: issue.category || "-",
      },
    };

    const config = cellConfig[column.id];
    if (!config) return null;

    const CellTag = config.isRowHeader ? "th" : "td";
    const stopRowClick = ["notes", "recommended_actions"].includes(column.id);

    return (
      <CellTag key={column.id} className={config.className} onClick={stopRowClick ? e => e.stopPropagation() : undefined}>
        {config.content}
      </CellTag>
    );
  };

  return (
    <div className="flex w-full flex-col">
      <div className="overflow-x-auto overflow-y-auto" style={{ height: "505px" }}>
        <table className="min-w-max w-full text-left text-sm">
          <thead className="sticky top-0 z-10 bg-white font-bold text-ui-text-primary shadow-xs">
            <tr>{visibleColumns.map(column => renderHeader(column))}</tr>
          </thead>
          <tbody>
            {data.map(issue => (
              <tr
                key={issue.id}
                className="cursor-pointer border-t hover:bg-brand-primary-50"
                onClick={() => openIssueDrillThrough(navigate, issue)}
              >
                {visibleColumns.map(column => renderCell(column, issue))}
              </tr>
            ))}
            {data.length === 0 ? (
              <tr>
                <td colSpan={visibleColumns.length} className="px-4 py-6 text-center text-ui-text-secondary">
                  No data
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>

      <Pagination
        currentPage={currentPage}
        pageSize={pageSize}
        total={total}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        itemName="Issues"
      />
    </div>
  );
};

export default IssueTableView;
