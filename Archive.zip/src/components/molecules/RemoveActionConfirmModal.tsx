import React from "react";
import { formatMaterialActionActorLabel } from "@/lib/materialActionDisplay";
import { MaterialAction } from "@/lib/types";
import { ModalShell } from "@/components/atoms/ModalShell";

interface RemoveActionConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  actionDetails: MaterialAction | null;
  isSubmitting?: boolean;
  /** When set, confirms removal of a logical issue-level action (all material rows). */
  issueLevel?: boolean;
  actionLabelOverride?: string;
}

export const RemoveActionConfirmModal: React.FC<RemoveActionConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  actionDetails,
  isSubmitting = false,
  issueLevel = false,
  actionLabelOverride,
}) => {
  const actionLabel =
    actionLabelOverride ??
    (actionDetails?.action === "no_action"
      ? "No Action Required"
      : actionDetails?.potential_action?.recommendation?.trim() ||
        actionDetails?.action ||
        "this action");
  const materialName = actionDetails?.material_name ?? "this material";
  let userLabel = "N/A";
  if (actionDetails?.user != null) {
    const name = formatMaterialActionActorLabel(actionDetails);
    userLabel = name === "Unknown user" ? "N/A" : name;
  }

  return (
    <ModalShell
      isOpen={isOpen}
      onClose={onClose}
      ariaLabelledBy="remove-action-modal-title"
      overlayClassName="fixed inset-0 flex items-center justify-center"
      zIndex={9999}
      className="bg-white rounded-md shadow-lg mx-4 overflow-hidden w-[512px]"
      usePortal
    >
      <div className="flex justify-between items-center px-6 h-[56px] border-b border-gray-300 bg-white">
        <h2 id="remove-action-modal-title" className="text-lg font-semibold text-ui-text-primary">
          Delete Action
        </h2>
        <button
          type="button"
          onClick={onClose}
          className="text-ui-text-muted hover:text-ui-text-secondary text-2xl font-light"
          aria-label="Close delete action dialog"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={1.5}
            stroke="currentColor"
            className="size-6"
            aria-hidden
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M6 18 18 6M6 6l12 12"
            />
          </svg>
        </button>
      </div>

      <div className="px-6 flex items-center min-h-[92px] py-4 border-b border-gray-300 bg-white">
        <p className="text-body-sm-font-family font-medium text-sm text-ui-text-primary">
          {issueLevel ? (
            <>
              Are you sure you want to remove <strong>{actionLabel}</strong> for this issue? This will
              delete the action for all affected materials where it was recorded and cannot be undone.
            </>
          ) : (
            <>
              Are you sure you want to remove <strong>{actionLabel}</strong> for{" "}
              <strong>{materialName}</strong>? This action was applied by {userLabel} and cannot be
              undone.
            </>
          )}
        </p>
      </div>

      <div className="flex justify-end items-center px-6 h-[56px] bg-background-secondary">
        <button
          type="button"
          onClick={onConfirm}
          disabled={isSubmitting}
          className="px-4 py-2 bg-interactive-primary text-white rounded-md hover:bg-brand-main-800 font-medium transition-colors focus:outline-hidden focus:ring-2 focus:ring-brand-primary-main focus:ring-offset-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Delete
        </button>
      </div>
    </ModalShell>
  );
};
