import { InfoIcon } from "@/components/atoms";
import { Link } from "react-router-dom";

export type MetricLink = {
  to: string;
  label: string;
};

export default function Metric({
  label,
  tooltip,
  value,
  size = "lg",
  metricLink,
  change,
  loading,
}: {
  label: string;
  tooltip: string;
  value: string;
  loading: boolean;
  change?: string | null;
  size?: "sm" | "lg";
  metricLink?: MetricLink;
}) {
  const isSmall = size === "sm";
  return (
    <div className="min-w-47.5 border-l border-ui-border-primary pl-5 first:border-l-0 first:pl-0">
      <div
        className={`flex items-center gap-1 text-[${isSmall ? "10px" : "12px"}] font-medium uppercase tracking-wide text-ui-text-secondary`}
      >
        <span>{label}</span>
        <InfoIcon size={14} position="top" tooltip={tooltip} />
      </div>
      {loading ? (
        <div className="mt-1 h-6 w-32 animate-pulse rounded bg-ui-background-secondary" aria-label={`Loading ${label}`} />
      ) : (
        <div className="mt-0.5 flex flex-wrap items-baseline space-x-1.5 gap-y-0.5">
          <span className={`${isSmall ? "text-heading-lg" : "text-heading-xl"} font-semibold text-ui-text-primary`}>{value}</span>
          {change ? <span className={`${isSmall ? "text-xs" : "text-sm"} text-ui-text-secondary`}>{change}</span> : null}
          {metricLink ? (
            <Link
              to={metricLink.to}
              className="text-sm text-ui-text-secondary underline decoration-[10%] decoration-wavy focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-primary-main"
            >
              {metricLink.label}
            </Link>
          ) : null}
        </div>
      )}
    </div>
  );
}
