import React, { useState } from "react";

interface CreateCustomFilterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate?: (filterData: { name: string; description: string; visibility: "private" | "organization-wide" }) => void;
}

export const CreateCustomFilterModal: React.FC<CreateCustomFilterModalProps> = ({ isOpen, onClose, onCreate }) => {
  const [filterName, setFilterName] = useState("");
  const [description, setDescription] = useState("");
  const [visibility, setVisibility] = useState<"private" | "organization-wide">("private");

  if (!isOpen) return null;

  const handleCreate = () => {
    if (filterName.trim()) {
      onCreate?.({
        name: filterName,
        description: description,
        visibility: visibility,
      });
      // Reset form
      setFilterName("");
      setDescription("");
      setVisibility("private");
      onClose();
    }
  };

  const handleClose = () => {
    // Reset form on close
    setFilterName("");
    setDescription("");
    setVisibility("private");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-10000 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        style={{
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
        onClick={handleClose}
      />

      {/* Modal Card */}
      <div
        className="relative bg-white rounded-lg shadow-xl max-w-lg w-[90vw] md:w-full mx-4"
        style={{
          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-4">
          <h2
            className="font-bold"
            style={{
              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "20px",
              fontWeight: "700",
              lineHeight: "28px",
            }}
          >
            Create Custom Filter
          </h2>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
            style={{
              fontSize: "24px",
              lineHeight: "1",
            }}
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="px-6 pb-6 space-y-4">
          {/* Filter Name */}
          <div>
            <label
              className="block mb-2"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "500",
                lineHeight: "20px",
              }}
            >
              Filter Name
            </label>
            <input
              type="text"
              value={filterName}
              onChange={e => setFilterName(e.target.value)}
              placeholder="e.g., Filter Name"
              className="w-full px-3 py-2 border rounded-md focus:outline-hidden focus:ring-2 focus:ring-brand-primary-main"
              style={{
                borderColor: "var(--cds-color-border-primary, #E0E0E0)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
              }}
            />
          </div>

          {/* Description */}
          <div>
            <label
              className="block mb-2"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "500",
                lineHeight: "20px",
              }}
            >
              Description
            </label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="What is this filter for?"
              rows={3}
              className="w-full px-3 py-2 border rounded-md focus:outline-hidden focus:ring-2 focus:ring-brand-primary-main resize-none"
              style={{
                borderColor: "var(--cds-color-border-primary, #E0E0E0)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
              }}
            />
          </div>

          {/* Visibility */}
          <div>
            <label
              className="block mb-3"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "500",
                lineHeight: "20px",
              }}
            >
              Visibility <span style={{ color: "#DC2626" }}>*</span>
            </label>
            <div className="space-y-3">
              {/* Private Option */}
              <label
                className={`flex items-start p-4 border rounded-lg cursor-pointer transition-colors ${
                  visibility === "private"
                    ? "border-brand-primary-main bg-brand-primary-50"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <div className="flex items-center flex-1">
                  <input
                    type="radio"
                    name="visibility"
                    value="private"
                    checked={visibility === "private"}
                    onChange={e => setVisibility(e.target.value as "private" | "organization-wide")}
                    className="mr-3"
                    style={{
                      accentColor: "var(--color-brand-primary-main, #461E96)",
                    }}
                  />
                  <div className="flex items-center flex-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={2}
                      stroke="currentColor"
                      className="w-5 h-5 mr-2"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                      }}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z"
                      />
                    </svg>
                    <div className="flex-1">
                      <div
                        className="font-bold mb-1"
                        style={{
                          color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                          fontFamily: "Cencora-Gilroy",
                          fontSize: "14px",
                          fontWeight: "700",
                          lineHeight: "20px",
                        }}
                      >
                        Private
                      </div>
                      <div
                        className="text-sm"
                        style={{
                          color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                          fontFamily: "Cencora-Gilroy",
                          fontSize: "12px",
                          fontWeight: "400",
                          lineHeight: "16px",
                        }}
                      >
                        Only you can see and use this list
                      </div>
                    </div>
                  </div>
                </div>
              </label>

              {/* Organization-Wide Option */}
              <label
                className={`flex items-start p-4 border rounded-lg cursor-pointer transition-colors ${
                  visibility === "organization-wide"
                    ? "border-brand-primary-main bg-brand-primary-50"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <div className="flex items-center flex-1">
                  <input
                    type="radio"
                    name="visibility"
                    value="organization-wide"
                    checked={visibility === "organization-wide"}
                    onChange={e => setVisibility(e.target.value as "private" | "organization-wide")}
                    className="mr-3"
                    style={{
                      accentColor: "var(--color-brand-primary-main, #461E96)",
                    }}
                  />
                  <div className="flex items-center flex-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={2}
                      stroke="currentColor"
                      className="w-5 h-5 mr-2"
                      style={{
                        color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                      }}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M13.19 8.688a4.5 4.5 0 0 1 1.242 7.244l-4.5 4.5a4.5 4.5 0 0 1-6.364-6.364l1.757-1.757m13.35-.622 1.757-1.757a4.5 4.5 0 0 0-6.364-6.364l-4.5 4.5a4.5 4.5 0 0 0 1.242 7.244"
                      />
                    </svg>
                    <div className="flex-1">
                      <div
                        className="font-bold mb-1"
                        style={{
                          color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                          fontFamily: "Cencora-Gilroy",
                          fontSize: "14px",
                          fontWeight: "700",
                          lineHeight: "20px",
                        }}
                      >
                        Organization-Wide
                      </div>
                      <div
                        className="text-sm"
                        style={{
                          color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                          fontFamily: "Cencora-Gilroy",
                          fontSize: "12px",
                          fontWeight: "400",
                          lineHeight: "16px",
                        }}
                      >
                        Available to all Stratium users
                      </div>
                    </div>
                  </div>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Footer with Create Button */}
        <div className="flex justify-end px-6 pb-6">
          <button
            onClick={handleCreate}
            disabled={!filterName.trim()}
            className="px-6 py-2 rounded-md font-semibold text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              backgroundColor: filterName.trim()
                ? "var(--color-brand-primary-main, #461E96)"
                : "var(--Cencora-neutral-expanded-500, #6E6E6E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "600",
              lineHeight: "20px",
            }}
          >
            Create
          </button>
        </div>
      </div>
    </div>
  );
};
