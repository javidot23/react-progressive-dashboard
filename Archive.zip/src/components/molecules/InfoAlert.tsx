import {Info, AlertTriangle} from "lucide-react";
import {JSX} from "react";

type InfoAlertVariant = "info" | "critical";

interface InfoAlertProps {
  variant?: InfoAlertVariant;
  tooltip?: string;
  title: string;
  description: string;
  buttonLabel?: string;
  onClick?: () => void;
}

const VARIANT_STYLES: Record<
  InfoAlertVariant,
  {
    icon: JSX.Element;
    bgClass: string;
    iconColor: string;
    tooltipBg: string;
    buttonTextColor: string;
    buttonBorder: string;
  }
> = {
  info: {
    icon: <Info className="w-5 h-5 text-status-info-main" />,
    bgClass: "bg-status-info-light",
    iconColor: "text-status-info-main",
    tooltipBg: "bg-status-error-main",
    buttonTextColor: "text-brand-primary-main",
    buttonBorder: "border-brand-primary-main",
  },
  critical: {
    icon: <AlertTriangle className="w-5 h-5 text-status-error-main" />,
    bgClass: "bg-status-error-light",
    iconColor: "text-status-error-main",
    tooltipBg: "bg-status-error-main",
    buttonTextColor: "text-status-error-main",
    buttonBorder: "border-status-error-main",
  },
};

const InfoAlert: React.FC<InfoAlertProps> = ({
  variant = "info",
  tooltip = "We don't have data or a way to map data for this value.",
  title,
  description,
  buttonLabel = "View Details",
  onClick,
}) => {
  const styles = VARIANT_STYLES[variant];

  return (
    <div className="relative group">
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 -translate-y-full z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <div
          className={`${styles.tooltipBg} text-white text-xs rounded px-3 py-2 shadow-lg text-center`}
        >
          {tooltip}
        </div>
      </div>

      <div
        className={`${styles.bgClass} border border-ui-border-primary rounded-md`}
      >
        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 items-center justify-between p-4 w-full">
          <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 items-center space-x-3">
            {styles.icon}
            <div>
              <h3 className="font-medium text-ui-text-primary">{title}</h3>
              <p className="text-md font-normal">{description}</p>
            </div>
          </div>
          <button
            onClick={onClick}
            className={`px-4 py-2 whitespace-nowrap ${styles.bgClass} hover:bg-ui-background-muted ${styles.buttonTextColor} border-2 ${styles.buttonBorder} font-bold rounded cursor-pointer`}
          >
            {buttonLabel}
          </button>
        </div>
      </div>
    </div>
  );
};

export default InfoAlert;
