import { MessageSquare, Pencil, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/atoms/Button";
import { issueNoteAuthorLabel } from "@/lib/issueNoteAuthorLabel";
import { issueNoteShowsEditedLabel } from "@/lib/issueNoteEdited";
import { formatRelativeTimeShort } from "@/lib/relativeTime";
import type { IssueNote } from "@/services/issueNotesService";
import { noteKey, useIssueNotesPanel } from "@/components/molecules/useIssueNotesPanel";

export interface IssueNotesPagePanelProps {
  issueBackendId: string | undefined;
  matNbr: string;
  ndc: string;
  isResolved: boolean;
}

function ActionStatusBadge({ isResolved }: { isResolved: boolean }) {
  if (isResolved) {
    return (
      <span className="inline-flex items-center gap-2 shrink-0">
        <span className="inline-flex items-center justify-center p-1 rounded-full border border-[#06C07A] bg-[#D8FEE7] shrink-0">
          <span className="w-2 h-2 rounded-full bg-[#119D63]" />
        </span>
        <span className="font-semibold text-[#1E1E2D]">Reviewed</span>
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-2 shrink-0">
      <span className="inline-flex items-center justify-center p-1 rounded-full border border-[#E22F008A] bg-[#FEEFEB] shrink-0">
        <span className="w-2 h-2 rounded-full bg-[#E22F00]" />
      </span>
      <span className="font-semibold text-[#1E1E2D]">Not Reviewed</span>
    </span>
  );
}

function PageNoteCard({
  note,
  editingId,
  editContent,
  setEditContent,
  deleteConfirmId,
  setDeleteConfirmId,
  startEdit,
  cancelEdit,
  saveEdit,
  confirmDelete,
  updateMutation,
  deleteMutation,
}: {
  note: IssueNote;
  editingId: string | null;
  editContent: string;
  setEditContent: (v: string) => void;
  deleteConfirmId: string | null;
  setDeleteConfirmId: (v: string | null) => void;
  startEdit: (note: IssueNote) => void;
  cancelEdit: () => void;
  saveEdit: () => Promise<void>;
  confirmDelete: (noteId: string) => Promise<void>;
  updateMutation: { isPending: boolean };
  deleteMutation: { isPending: boolean };
}) {
  const edited = issueNoteShowsEditedLabel(note.created_at, note.updated_at);
  const isPendingOptimistic = note.id.startsWith("temp-");
  const key = noteKey(note);

  return (
    <article
      className={`rounded-lg border border-[#E5E5EA] bg-[#F7F7F8] p-4${isPendingOptimistic ? " opacity-70" : ""}`}
      aria-busy={isPendingOptimistic}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-semibold text-[#1E1E2D]">{issueNoteAuthorLabel(note)}</span>
        {note.is_my_note ? (
          <span className="rounded-md bg-[#5B2E91] px-2 py-0.5 text-2xs font-semibold uppercase tracking-wide text-white">
            YOU
          </span>
        ) : null}
        <span className="text-xs text-[#888888]">
          <span aria-hidden>· </span>
          <time dateTime={note.created_at}>{formatRelativeTimeShort(note.created_at)}</time>
          {edited ? <span> (edited)</span> : null}
        </span>
      </div>

      {editingId === key && note.is_my_note ? (
        <div className="mt-3">
          <textarea
            value={editContent}
            onChange={e => setEditContent(e.target.value)}
            rows={3}
            className="w-full resize-none rounded-md border border-input bg-background px-3 py-2 text-sm text-ui-text-primary placeholder:text-muted-foreground focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          />
          <div className="mt-3 flex flex-wrap justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={cancelEdit}
              className="border-[#D8C8EB] bg-white text-[#1E1E2D] hover:bg-white hover:border-[#888888]"
            >
              Cancel
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={() => void saveEdit()}
              isLoading={updateMutation.isPending}
              disabled={!editContent.trim()}
            >
              Save
            </Button>
          </div>
        </div>
      ) : (
        <>
          <p className="mt-2 text-sm wrap-break-word whitespace-pre-wrap text-[#1E1E2D]">{note.content}</p>
          {note.is_my_note ? (
            <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-2">
              {deleteConfirmId === key ? (
                <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                  <span className="text-[#888888]">Delete this note?</span>
                  <button
                    type="button"
                    disabled={deleteMutation.isPending}
                    className="inline-flex items-center gap-1.5 font-medium text-status-error-main hover:text-status-error-dark disabled:opacity-50"
                    onClick={() => void confirmDelete(key)}
                  >
                    <Trash2 className="h-3.5 w-3.5 shrink-0" aria-hidden />
                    {deleteMutation.isPending ? "Deleting…" : "Delete"}
                  </button>
                  <button
                    type="button"
                    className="font-medium text-[#888888] hover:text-[#555555]"
                    onClick={() => setDeleteConfirmId(null)}
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <>
                  <button
                    type="button"
                    className="inline-flex items-center gap-1.5 text-sm font-medium text-[#888888] transition-colors hover:text-[#555555]"
                    onClick={() => startEdit(note)}
                  >
                    <Pencil className="h-3.5 w-3.5 shrink-0" strokeWidth={2} aria-hidden />
                    Edit
                  </button>
                  <button
                    type="button"
                    className="inline-flex items-center gap-1.5 text-sm font-medium text-[#888888] transition-colors hover:text-[#555555]"
                    onClick={() => {
                      setDeleteConfirmId(key);
                    }}
                  >
                    <Trash2 className="h-3.5 w-3.5 shrink-0" strokeWidth={2} aria-hidden />
                    Delete
                  </button>
                </>
              )}
            </div>
          ) : null}
        </>
      )}
    </article>
  );
}

export function IssueNotesPagePanel({ issueBackendId, matNbr, ndc, isResolved }: IssueNotesPagePanelProps) {
  const panel = useIssueNotesPanel(issueBackendId);
  const {
    notesQuery,
    messagesNewestFirst,
    newContent,
    setNewContent,
    editingId,
    editContent,
    setEditContent,
    deleteConfirmId,
    setDeleteConfirmId,
    formError,
    createMutation,
    updateMutation,
    deleteMutation,
    avatarSrc,
    initials,
    handleCreateSubmit,
    startEdit,
    cancelEdit,
    saveEdit,
    confirmDelete,
    handleLoadOlder,
  } = panel;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-[#1E1E2D]">Notes</h1>
        <div className="mt-2 flex flex-wrap items-center gap-x-1.5 gap-y-1 text-sm text-[#888888]">
          <span className="text-[#888888]">Mat</span>{" "}
          <span className="font-semibold text-[#1E1E2D]">{matNbr || "—"}</span>
          <span className="text-[#C5C5CC]">·</span>
          <span className="text-[#888888]">NDC</span>{" "}
          <span className="font-semibold text-[#1E1E2D]">{ndc || "—"}</span>
          <span className="text-[#C5C5CC]">·</span>
          <ActionStatusBadge isResolved={isResolved} />
        </div>
      </header>

      <section>
        {formError ? <p className="mb-2 text-xs text-status-error-main">{formError}</p> : null}
        <form
          onSubmit={e => void handleCreateSubmit(e)}
          className="overflow-hidden rounded-xl border border-[#E5E5EA] bg-white"
        >
          <div className="flex items-start gap-3 p-4">
            {avatarSrc ? (
              <img src={avatarSrc} alt="" className="h-11 w-11 shrink-0 rounded-full object-cover" />
            ) : (
              <div
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#D8C8EB] text-sm font-semibold text-[#461E96]"
                aria-hidden
              >
                {initials}
              </div>
            )}
            <textarea
              value={newContent}
              onChange={e => setNewContent(e.target.value)}
              rows={3}
              placeholder="Write a note..."
              disabled={!issueBackendId}
              className="min-h-18 w-full resize-none rounded-md border border-[#D8C8EB] bg-white px-3 py-2 text-sm leading-5 text-[#1E1E2D] placeholder:text-[#888888] focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-[#461E96]/30 disabled:opacity-50"
            />
          </div>
          <div className="flex items-center justify-between gap-2 border-t border-[#E5E5EA] px-4 py-3">
            <p className="text-xs text-[#888888]">Saved to this material — visible to the team</p>
            <button
              type="submit"
              disabled={!issueBackendId || !newContent.trim() || createMutation.isPending}
              className="inline-flex shrink-0 items-center gap-2 rounded-md bg-[#461E96] px-4 py-2 text-sm font-medium text-white transition-opacity disabled:opacity-50"
            >
              {createMutation.isPending ? (
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
              ) : (
                <Save className="h-4 w-4" aria-hidden />
              )}
              Save Note
            </button>
          </div>
        </form>
      </section>

      <section>
        <h2 className="mb-4 text-base font-semibold text-[#1E1E2D]">Recent Notes</h2>

        {!issueBackendId && (
          <p className="text-sm text-status-error-main">This issue cannot load notes (missing issue id).</p>
        )}

        {issueBackendId && notesQuery.isPending && !notesQuery.data && !notesQuery.isError && (
          <div className="flex flex-col items-center justify-center gap-3 py-10">
            <div className="h-8 w-8 animate-spin rounded-full border-[3px] border-ui-border-primary border-t-brand-primary-main" />
            <p className="text-sm font-medium text-ui-text-primary">Loading notes…</p>
          </div>
        )}

        {issueBackendId && notesQuery.isError && (
          <div className="rounded-md border border-status-error-main/30 bg-status-error-light px-3 py-3">
            <p className="text-sm font-medium text-status-error-main">Could not load notes.</p>
            <p className="mt-1 text-xs text-ui-text-secondary">
              {notesQuery.error instanceof Error ? notesQuery.error.message : "Something went wrong."}
            </p>
            <Button type="button" variant="outline" size="sm" className="mt-3" onClick={() => notesQuery.refetch()}>
              Retry
            </Button>
          </div>
        )}

        {issueBackendId && notesQuery.isSuccess && messagesNewestFirst.length === 0 && (
          <div className="flex flex-col items-center gap-2 py-8 text-center">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-ui-background-secondary">
              <MessageSquare className="h-8 w-8 text-ui-text-muted" aria-hidden />
            </div>
            <h3 className="text-lg font-semibold text-ui-text-primary">No notes yet</h3>
            <p className="max-w-sm text-sm text-ui-text-secondary">
              Add a note to capture context, follow-ups, or decisions for this issue.
            </p>
          </div>
        )}

        {issueBackendId && notesQuery.isSuccess && messagesNewestFirst.length > 0 && (
          <div className="space-y-3">
            {messagesNewestFirst.map(note => (
              <PageNoteCard
                key={noteKey(note)}
                note={note}
                editingId={editingId}
                editContent={editContent}
                setEditContent={setEditContent}
                deleteConfirmId={deleteConfirmId}
                setDeleteConfirmId={setDeleteConfirmId}
                startEdit={startEdit}
                cancelEdit={cancelEdit}
                saveEdit={saveEdit}
                confirmDelete={confirmDelete}
                updateMutation={updateMutation}
                deleteMutation={deleteMutation}
              />
            ))}
            {notesQuery.hasNextPage ? (
              <div className="flex justify-center pt-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleLoadOlder}
                  isLoading={notesQuery.isFetchingNextPage}
                >
                  Load older notes
                </Button>
              </div>
            ) : null}
          </div>
        )}
      </section>
    </div>
  );
}
