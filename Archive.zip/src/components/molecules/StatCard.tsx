import { useState } from "react";
import { ArrowUp, ArrowDown } from "lucide-react";
import { cn } from "@/lib/utils";
import type { StatCardData, KPITrendPoint } from "@/lib/types";
import { Card, CardContent, CardHeader } from "@/components/atoms/Card";
import { AccessibleChart } from "@/components/atoms/AccessibleChart";
import KPILineChart from "./KPILineChart";
import InfoIcon from "@/components/atoms/InfoIcon";

// Positive = green, negative = red, neutral = gray
const TREND_COLORS = {
  positive: "#007F50",
  negative: "#EF4444",
  neutral: "#6B7280",
} as const;

type TrendSentiment = keyof typeof TREND_COLORS;

// Mini sparkline component for KPI trends
const MiniSparkline = ({
  points,
  trendSentiment,
  title,
  valueFormatter,
}: {
  points: KPITrendPoint[];
  trendSentiment?: TrendSentiment;
  title: string;
  value?: string;
  valueFormatter?: (value: number | null) => string;
}) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!points || points.length < 2) return null;

  // Sort points chronologically by period_start to ensure correct order
  const sortedPoints = [...points].sort((a, b) => new Date(a.period_start).getTime() - new Date(b.period_start).getTime());

  const values = sortedPoints.map(p => p.value);
  const dataMin = Math.min(...values);
  const dataMax = Math.max(...values);
  const dataRange = dataMax - dataMin;
  const midpoint = (dataMax + dataMin) / 2;

  // Ensure the visual range is at least 10% of the midpoint so near-flat
  // data (e.g. 69.6%–70.3%) doesn't get amplified into dramatic spikes.
  const minVisualRange = Math.abs(midpoint) * 0.1;
  const range = Math.max(dataRange, minVisualRange) || 1;
  const minVal = midpoint - range / 2;

  const width = 80;
  const height = 24;
  const padding = 2;

  // Calculate points for the path (using sorted points)
  const pathPoints = values.map((val, idx) => {
    const x = padding + (idx / (values.length - 1)) * (width - padding * 2);
    const y = height - padding - ((val - minVal) / range) * (height - padding * 2);
    return `${x},${y}`;
  });

  const strokeColor = TREND_COLORS[trendSentiment ?? "neutral"];

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  const formatValue = (val: number) => {
    if (valueFormatter) return valueFormatter(val);
    if (val >= 1_000_000) return `$${(val / 1_000_000).toFixed(2)}M`;
    if (val >= 1_000) return `$${(val / 1_000).toFixed(2)}K`;
    if (val < 1 && val > 0) return `${(val * 100).toFixed(2)}%`;
    return val.toLocaleString();
  };

  // Calculate coordinates for each point (for dots)
  const pointCoordinates = values.map((val, idx) => ({
    x: padding + (idx / (values.length - 1)) * (width - padding * 2),
    y: height - padding - ((val - minVal) / range) * (height - padding * 2),
    value: val,
    point: sortedPoints[idx],
  }));

  const hoveredPoint = hoveredIndex !== null ? pointCoordinates[hoveredIndex] : null;

  return (
    <AccessibleChart ariaLabel={`${title} trend sparkline`} className="relative ml-auto">
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="cursor-pointer" aria-hidden>
        <polyline
          fill="none"
          stroke={strokeColor}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={pathPoints.join(" ")}
        />
        {/* Dots for every week/data point */}
        {pointCoordinates.map((coord, idx) => (
          <circle
            key={idx}
            cx={coord.x}
            cy={coord.y}
            r={hoveredIndex === idx ? 3.5 : idx === pointCoordinates.length - 1 ? 2.5 : 1.5}
            fill={strokeColor}
            opacity={hoveredIndex === idx ? 1 : idx === pointCoordinates.length - 1 ? 1 : 0.6}
            onMouseEnter={() => setHoveredIndex(idx)}
            onMouseLeave={() => setHoveredIndex(null)}
            style={{ cursor: "pointer" }}
          />
        ))}
        {/* Invisible larger hit areas for easier hovering */}
        {pointCoordinates.map((coord, idx) => (
          <circle
            key={`hit-${idx}`}
            cx={coord.x}
            cy={coord.y}
            r={6}
            fill="transparent"
            onMouseEnter={() => setHoveredIndex(idx)}
            onMouseLeave={() => setHoveredIndex(null)}
            style={{ cursor: "pointer" }}
          />
        ))}
      </svg>
      {hoveredPoint && (
        <div
          className="absolute z-50 pointer-events-none"
          style={{
            bottom: "100%",
            left: `${hoveredPoint.x}px`,
            transform: "translateX(-50%)",
            paddingBottom: "8px",
          }}
        >
          <div className="bg-white rounded-md shadow-lg px-2 py-1.5 text-xs whitespace-nowrap min-w-[90px] border border-gray-100">
            <div className="flex justify-between gap-2 text-gray-500">
              <span>Week:</span>
              <span className="text-gray-700">{formatDate(hoveredPoint.point.period_start)}</span>
            </div>
            <div className="flex justify-between gap-2 text-gray-500">
              <span>Value:</span>
              <span className="font-medium" style={{ color: strokeColor }}>
                {formatValue(hoveredPoint.value)}
              </span>
            </div>
          </div>
        </div>
      )}
    </AccessibleChart>
  );
};

interface StatCardProps {
  data: StatCardData;
  tooltipPosition?: "top" | "bottom" | "left" | "right";
}

// Higher-is-better: increase = green, decrease = red. Lower-is-better: decrease = green, increase = red.
const HIGHER_IS_BETTER_TITLES = ["Service Level", "Inbound On-Time In-Full", "Perfect Line Rate"];

// Value at Risk and Current Risk Score: lower is better, so decrease = green, increase = red.
const LOWER_IS_BETTER_TITLES = ["Value at Risk", "Current Risk Score"];

function getTrendSentiment(title: string, changeType?: "increase" | "decrease" | "neutral"): TrendSentiment {
  if (!changeType || changeType === "neutral") return "neutral";
  if (HIGHER_IS_BETTER_TITLES.includes(title)) {
    return changeType === "increase" ? "positive" : "negative";
  }
  if (LOWER_IS_BETTER_TITLES.includes(title)) {
    return changeType === "decrease" ? "positive" : "negative";
  }
  // Default (e.g. Open Issues): treat decrease as positive
  return changeType === "decrease" ? "positive" : "negative";
}

export function StatCard({ data, tooltipPosition }: StatCardProps) {
  const { title, value, change, changeType, icon: Icon, iconBgColor, customIconPath, trend } = data;

  const trendSentiment = getTrendSentiment(title, changeType);
  const changeColor = TREND_COLORS[trendSentiment];

  // Handle custom styling for special backgrounds
  const getIconContainerStyle = () => {
    if (iconBgColor === "custom-warning") {
      return {
        borderRadius: "4px",
        background: "#E8E8E8",
      };
    }
    if (iconBgColor === "custom-highlight") {
      return {
        borderRadius: "4px",
        background: "#E8E8E8",
      };
    }
    if (iconBgColor === "custom-success") {
      return {
        borderRadius: "4px",
        background: "#E8E8E8",
      };
    }
    if (iconBgColor === "custom-error") {
      return {
        borderRadius: "4px",
        background: "#E8E8E8",
      };
    }
    return {};
  };

  const getIconContainerClasses = () => {
    if (
      iconBgColor === "custom-warning" ||
      iconBgColor === "custom-highlight" ||
      iconBgColor === "custom-success" ||
      iconBgColor === "custom-error"
    ) {
      return "flex items-center justify-center h-[35px] w-[35px] text-white p-2";
    }
    return cn(
      "flex items-center justify-center h-10 w-10 rounded-lg text-white p-2",
      iconBgColor // This will use the color from dummy data, e.g., bg-red-500
    );
  };

  return (
    <Card className="shadow-xs rounded-md" style={{ minHeight: "165px" }}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 pt-4 px-4" style={{ paddingTop: "24px" }}>
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className={cn(getIconContainerClasses(), "shrink-0")} style={getIconContainerStyle()}>
            {customIconPath ? (
              <img
                src={customIconPath}
                alt={title}
                className={title === "Value at Risk" ? "h-8 w-8" : "h-6 w-6"}
                style={{
                  objectFit: "contain",
                  ...(title === "Value at Risk" ? { width: "32px", height: "32px" } : {}),
                }}
                onError={e => {
                  e.currentTarget.style.display = "none";
                }}
                onLoad={() => {}}
              />
            ) : Icon ? (
              typeof Icon === "function" ? (
                <Icon className="h-6 w-6 text-white" />
              ) : (
                Icon
              )
            ) : null}
          </div>
          <div
            className="font-medium text-2xl leading-7"
            style={{
              color: "var(--Cencora-text-heading, var(--color-text-heading, #1E1E1E))",
              fontFamily: "var(--text-heading-2xl-font-family, Cencora-Gilroy)",
              fontSize: "var(--text-heading-2xl-font-size, 24px)",
              fontWeight: "500",
              lineHeight: "var(--text-heading-2xl-line-height, 28px)",
              letterSpacing: "var(--text-heading-2xl-letter-spacing, 0)",
            }}
          >
            {value}
          </div>
        </div>
        {data.chartData && data.chartData.length > 0 && (
          <div className="shrink ml-4 min-w-0" style={{ maxWidth: "120px", height: "50px" }}>
            <KPILineChart
              data={data.chartData}
              xLabels={data.chartXLabels}
              color={data.chartColor || "#461E96"}
              valueFormatter={data.chartValueFormatter}
              height={50}
              ariaLabel={`${title} trend chart`}
            />
          </div>
        )}
        {data.tooltip && <InfoIcon tooltip={data.tooltip} position={tooltipPosition || "top"} size={26} color="#461E96" />}
      </CardHeader>
      <CardContent className="flex flex-col gap-3 pt-2 pb-4 px-4">
        <div className="flex items-end justify-between">
          <p className="text-sm text-ui-text-secondary">{title}</p>
          {trend?.points && trend.points.length >= 2 && (
            <MiniSparkline
              points={trend.points}
              trendSentiment={trendSentiment}
              title={title}
              value={value}
              valueFormatter={data.sparklineValueFormatter}
            />
          )}
        </div>
        {change && (
          <div className="text-xs flex items-center" style={{ color: changeColor }}>
            {title !== "Open Issues" && changeType === "increase" && (
              <ArrowUp className="h-3 w-3 mr-1" style={{ color: changeColor }} />
            )}
            {title !== "Open Issues" && changeType === "decrease" && (
              <ArrowDown className="h-3 w-3 mr-1" style={{ color: changeColor }} />
            )}
            {change}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
