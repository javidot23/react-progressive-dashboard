import { Card } from "@/components/atoms/Card";
import { Button } from "@/components/atoms/Button";
import { Bot } from "lucide-react";
import type { IssueItem } from "@/lib/types";
import { cn } from "@/lib/utils";

interface AIRecommendationSnippetProps {
  recommendation: IssueItem["aiRecommendation"];
}

export function AIRecommendationSnippet({ recommendation }: AIRecommendationSnippetProps) {
  return (
    <Card className="bg-sky-50 border-sky-200 p-3 w-full max-w-[220px]">
      {" "}
      {/* Constrained width */}
      <div className="flex items-start space-x-2">
        <Bot className="h-5 w-5 text-sky-700 mt-0.5 shrink-0" />
        <div>
          <p className="text-xs font-semibold text-sky-800">{recommendation.title}</p>
          <p className="text-xs text-sky-700 leading-snug">{recommendation.suggestion}</p>
          {recommendation.details?.map(detail => (
            <p key={detail} className="text-xs text-sky-600 leading-snug">
              {detail}
            </p>
          ))}
          <div className="mt-2 flex flex-col space-y-1">
            {recommendation.buttons.map(btn => (
              <Button
                key={btn.text}
                size="sm"
                variant={btn.variant === "default" ? "fill" : "outline"}
                className={cn(
                  btn.variant === "default"
                    ? "bg-status-info-main not-disabled:hover:bg-status-info-dark text-white"
                    : "bg-white text-status-info-main border-status-info-main not-disabled:hover:bg-sky-100",
                  "w-full text-xs py-1 px-2 h-auto" // Adjusted padding for smaller button
                )}
              >
                {btn.text}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}
