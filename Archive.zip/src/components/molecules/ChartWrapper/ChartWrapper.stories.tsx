import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { expect, fn, userEvent, within } from "@storybook/test";
import { Bar, BarChart, LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from "recharts";
import { Button } from "@/components/atoms/Button";
import type { LegendItem } from "@/components/atoms/Legend";
import { Typography } from "@/components/atoms/Typography";
import { chartColorSystem, chartPalettes, getSeriesColors, mapSeriesColors } from "@/lib/chartColors";
import { ChartWrapper } from "./ChartWrapper";

type PlayArgs = { canvasElement: HTMLElement };

const sampleData = [
  { name: "Mon", fillRate: 92, projected: 90, orders: 120 },
  { name: "Tue", fillRate: 94, projected: 91, orders: 132 },
  { name: "Wed", fillRate: 91, projected: 92, orders: 128 },
  { name: "Thu", fillRate: 96, projected: 93, orders: 140 },
  { name: "Fri", fillRate: 95, projected: 94, orders: 136 },
  { name: "Sat", fillRate: 93, projected: 94, orders: 110 },
  { name: "Sun", fillRate: 97, projected: 95, orders: 118 },
];

const seriesColors = mapSeriesColors(["fillRate", "projected", "orders"], {
  palette: "categorical",
});

const defaultLegendItems: LegendItem[] = [
  {
    id: "fill-rate",
    label: "Fill Rate",
    color: seriesColors.fillRate!,
    shape: "line",
  },
  {
    id: "projected",
    label: "Projected Fill Rate",
    color: seriesColors.projected!,
    shape: "line",
  },
  {
    id: "orders",
    label: "Order Quantity",
    color: seriesColors.orders!,
    shape: "square",
  },
];

function DemoLineChart({ colors = seriesColors }: { colors?: Record<string, string> }) {
  return (
    <ResponsiveContainer width="100%" height="100%" minHeight={260}>
      <LineChart data={sampleData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke={chartColorSystem.neutral.grid} />
        <XAxis
          dataKey="name"
          tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
          axisLine={{ stroke: chartColorSystem.neutral.grid }}
        />
        <YAxis tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }} axisLine={{ stroke: chartColorSystem.neutral.grid }} />
        <Tooltip />
        <Line type="monotone" dataKey="fillRate" stroke={colors.fillRate} strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="projected" stroke={colors.projected} strokeWidth={2} strokeDasharray="4 4" dot={false} />
        <Line type="monotone" dataKey="orders" stroke={colors.orders} strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

function PaletteSwatches({ palette }: { palette: readonly string[] }) {
  return (
    <div className="flex h-full min-h-[200px] flex-wrap items-center gap-3 p-4">
      {palette.map((color, index) => (
        <div key={`${color}-${index}`} className="flex flex-col items-center gap-1">
          <span className="h-10 w-10 rounded-md border border-ui-border-primary" style={{ background: color }} />
          <Typography as="span" variant="caption" color="muted">
            S{index + 1}
          </Typography>
        </div>
      ))}
    </div>
  );
}

const outboundLegendItems: LegendItem[] = [
  {
    id: "allowed",
    label: "Allowed",
    color: "var(--color-data-categorical-1)",
    shape: "square",
  },
  {
    id: "none",
    label: "None",
    color: "var(--cds-color-neutral-200)",
    shape: "square",
  },
  {
    id: "excess",
    label: "Excess",
    color: "var(--cds-color-danger-500)",
    shape: "square",
  },
];

const outboundOverviewData = [{ name: "Products", allowed: 65, none: 4, excess: 31 }];
const outboundTrendData = [{ name: "Products", allowed: 58, none: 7, excess: 35 }];

function OutboundUnfilledChartExample() {
  const [view, setView] = useState<"overview" | "trend">("overview");
  const data = view === "overview" ? outboundOverviewData : outboundTrendData;

  return (
    <div className="flex w-full max-w-6xl flex-col gap-5 lg:flex-row lg:items-center">
      <div className="flex shrink-0 flex-col gap-2">
        <Typography as="h3" variant="h4" className="text-xl font-bold leading-none tracking-tight text-heading font-brand">
          Unfilled Products
        </Typography>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="border-brand-primary-main text-brand-primary-main"
          onClick={fn()}
        >
          See Unfilled Products
        </Button>
      </div>

      <ChartWrapper
        title="Products with Outbound Unfilled Qty"
        infoTooltip="Distribution of products by outbound unfilled quantity allowance."
        actions={
          <div
            className="inline-flex overflow-hidden rounded-lg border border-ui-border-primary bg-ui-background-primary"
            role="group"
            aria-label="Chart view"
          >
            <Button
              type="button"
              size="sm"
              variant="text"
              aria-pressed={view === "overview"}
              className={
                view === "overview"
                  ? "rounded-none bg-ui-background-primary px-5 font-semibold text-brand-primary-main not-disabled:hover:bg-ui-background-primary"
                  : "rounded-none px-5 text-ui-text-secondary"
              }
              onClick={() => setView("overview")}
            >
              Overview
            </Button>
            <Button
              type="button"
              size="sm"
              variant="text"
              aria-pressed={view === "trend"}
              className={
                view === "trend"
                  ? "rounded-none bg-ui-background-primary px-5 font-semibold text-brand-primary-main not-disabled:hover:bg-ui-background-primary"
                  : "rounded-none px-5 text-ui-text-secondary"
              }
              onClick={() => setView("trend")}
            >
              Trend
            </Button>
          </div>
        }
        legendItems={outboundLegendItems}
        legendPosition="top"
        variant="transparent"
        showDivider={false}
        minHeight={48}
        height={48}
        className="min-w-0 flex-1"
        contentClassName="gap-3 px-5 pb-0 pt-2"
        footer={
          <Typography as="p" variant="body2" color="secondary">
            Total Products with Excess Outbound Unfilled Qty in the last 90 days{" "}
            <Typography as="span" variant="body2" className="font-semibold">
              39/158
            </Typography>
          </Typography>
        }
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
            <XAxis type="number" domain={[0, 100]} hide />
            <YAxis type="category" dataKey="name" hide />
            <Bar dataKey="allowed" stackId="outbound" fill="var(--color-data-categorical-1)" isAnimationActive={false} />
            <Bar dataKey="none" stackId="outbound" fill="var(--cds-color-neutral-200)" isAnimationActive={false} />
            <Bar dataKey="excess" stackId="outbound" fill="var(--cds-color-danger-500)" isAnimationActive={false} />
          </BarChart>
        </ResponsiveContainer>
      </ChartWrapper>
    </div>
  );
}

const meta: Meta<typeof ChartWrapper> = {
  title: "Molecules/ChartWrapper",
  component: ChartWrapper,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
    docs: {
      description: {
        component:
          "Reusable chart container that standardizes title, info, actions, legends, labels, spacing, and loading/empty/error states. Chart library content is passed as `children`. Use `@/lib/chartColors` (or `useChartColors`) for shared series palettes.",
      },
    },
  },
  args: {
    title: "Inbound Fill Rate Trend",
    description: "Daily trend of inbound fill rates alongside quantities ordered for the last 7 days.",
    className: "w-full max-w-4xl",
    minHeight: 280,
  },
  argTypes: {
    legendPosition: {
      control: "inline-radio",
      options: ["top", "bottom", "none"],
    },
    variant: {
      control: "inline-radio",
      options: ["default", "elevated", "flat", "outlined", "transparent"],
    },
    titleInfoGap: {
      control: "inline-radio",
      options: ["sm", "md", "lg"],
    },
    children: { control: false },
    actions: { control: false },
    info: { control: false },
    legendItems: { control: false },
    labels: { control: false },
    header: { control: false },
    footer: { control: false },
    legend: { control: false },
    renderLegend: { control: false },
    loadingContent: { control: false },
    emptyContent: { control: false },
    errorContent: { control: false },
  },
};

export default meta;
type Story = StoryObj<typeof ChartWrapper>;

export const Default: Story = {
  args: {
    variant: "default",
    infoTooltip: "Purple and blue series show order volume and fill-rate performance. Use Export to download the current view.",
    legendItems: defaultLegendItems,
    actions: (
      <Button variant="outline" size="sm" onClick={fn()}>
        Export
      </Button>
    ),
    children: <DemoLineChart />,
  },
  play: async ({ canvasElement }: PlayArgs) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByRole("heading", { name: "Inbound Fill Rate Trend" })).toBeInTheDocument();
    await expect(canvas.getByText("Fill Rate")).toBeInTheDocument();
  },
};

export const SolidCardSurface: Story = {
  name: "Surface — white + border",
  args: {
    variant: "default",
    title: "Solid card surface",
    description: "White background, border, and rounded corners (default).",
    legendItems: defaultLegendItems,
    children: <DemoLineChart />,
  },
};

export const TransparentSurface: Story = {
  name: "Surface — transparent",
  render: () => (
    <div className="w-full max-w-4xl rounded-[10px] bg-ui-background-secondary p-4">
      <ChartWrapper
        title="Transparent surface"
        description="No fill or border — embeds flush on tinted page backgrounds."
        variant="transparent"
        showDivider={false}
        legendItems={defaultLegendItems}
        minHeight={280}
        className="w-full"
      >
        <DemoLineChart />
      </ChartWrapper>
    </div>
  ),
};

export const TitleOnly: Story = {
  args: {
    description: undefined,
    legendPosition: "none",
    children: <DemoLineChart />,
  },
};

export const TitleWithInfo: Story = {
  args: {
    infoTooltip: "Additional context about this chart metric.",
    legendPosition: "none",
    children: <DemoLineChart />,
  },
};

export const TitleWithAction: Story = {
  args: {
    legendPosition: "none",
    actions: (
      <Button variant="outline" size="sm" onClick={fn()}>
        Refresh
      </Button>
    ),
    children: <DemoLineChart />,
  },
};

export const TitleInfoAndAction: Story = {
  name: "Title + Info + Action",
  args: {
    infoTooltip: "Configure the service-level goal from the action on the right.",
    legendItems: defaultLegendItems,
    actions: (
      <Button variant="outline" size="sm" onClick={fn()}>
        Modify Goal
      </Button>
    ),
    children: <DemoLineChart />,
  },
};

export const SideActionAndViewSwitch: Story = {
  name: "Variant — side CTA + view switch",
  render: () => <OutboundUnfilledChartExample />,
  parameters: {
    docs: {
      description: {
        story:
          "Responsive composition with a leading CTA, title and info control, right-aligned segmented view switch, legend, stacked chart, and summary.",
      },
    },
  },
  play: async ({ canvasElement }: PlayArgs) => {
    const canvas = within(canvasElement);
    const overview = canvas.getByRole("button", { name: "Overview" });
    const trend = canvas.getByRole("button", { name: "Trend" });

    await expect(overview).toHaveAttribute("aria-pressed", "true");
    await userEvent.click(trend);
    await expect(trend).toHaveAttribute("aria-pressed", "true");
  },
};

export const LegendsAbove: Story = {
  args: {
    legendPosition: "top",
    legendItems: defaultLegendItems,
    children: <DemoLineChart />,
  },
};

export const LegendsBelow: Story = {
  args: {
    legendPosition: "bottom",
    legendItems: defaultLegendItems,
    children: <DemoLineChart />,
  },
};

export const NoLegends: Story = {
  args: {
    legendPosition: "none",
    children: <DemoLineChart />,
  },
};

export const MultipleLegendItems: Story = {
  args: {
    legendPosition: "top",
    legendOrientation: "horizontal",
    legendItems: getSeriesColors(6).map((color, index) => ({
      id: `series-${index}`,
      label: `Series ${index + 1}`,
      color,
      shape: index % 2 === 0 ? "square" : "line",
    })),
    children: <PaletteSwatches palette={chartPalettes.categorical.slice(0, 6)} />,
  },
};

export const CustomLegendRenderer: Story = {
  args: {
    legendPosition: "top",
    renderLegend: () => (
      <div className="flex flex-wrap gap-3">
        <Typography as="span" variant="body2" color="secondary" className="inline-flex items-center gap-2">
          <span className="h-2 w-2 rounded-full" style={{ background: chartColorSystem.semantic.success }} />
          On track
        </Typography>
        <Typography as="span" variant="body2" color="secondary" className="inline-flex items-center gap-2">
          <span className="h-2 w-2 rounded-full" style={{ background: chartColorSystem.semantic.warning }} />
          Watch
        </Typography>
        <Typography as="span" variant="body2" color="secondary" className="inline-flex items-center gap-2">
          <span className="h-2 w-2 rounded-full" style={{ background: chartColorSystem.semantic.danger }} />
          At risk
        </Typography>
      </div>
    ),
    children: <DemoLineChart />,
  },
};

export const VerticalLegend: Story = {
  args: {
    legendPosition: "bottom",
    legendOrientation: "vertical",
    legendItems: defaultLegendItems,
    children: <DemoLineChart />,
  },
};

export const CategoricalPalette: Story = {
  name: "Color palette — categorical",
  args: {
    title: "Categorical palette",
    description: "Default multi-series palette from `@/lib/chartColors`.",
    legendPosition: "none",
    children: <PaletteSwatches palette={chartPalettes.categorical} />,
  },
};

export const SemanticPalette: Story = {
  name: "Color palette — semantic",
  args: {
    title: "Semantic palette",
    description: "Success, info, warning, and danger series colors.",
    legendPosition: "none",
    children: <PaletteSwatches palette={chartPalettes.semantic} />,
  },
};

export const RiskPalette: Story = {
  name: "Color palette — risk",
  args: {
    title: "Risk palette",
    description: "Critical → low risk series colors.",
    legendPosition: "none",
    children: <PaletteSwatches palette={chartPalettes.risk} />,
  },
};

export const SeriesColorOverrides: Story = {
  name: "Series color overrides",
  args: {
    title: "Custom series colors",
    description: "Shared palette with per-series overrides.",
    legendItems: [
      {
        id: "fill-rate",
        label: "Fill Rate",
        color: chartColorSystem.semantic.info,
        shape: "line",
      },
      {
        id: "projected",
        label: "Projected",
        color: chartColorSystem.semantic.warning,
        shape: "line",
      },
      {
        id: "orders",
        label: "Orders",
        color: chartColorSystem.primary.light,
        shape: "square",
      },
    ],
    children: (
      <DemoLineChart
        colors={{
          fillRate: chartColorSystem.semantic.info,
          projected: chartColorSystem.semantic.warning,
          orders: chartColorSystem.primary.light,
        }}
      />
    ),
  },
};

export const Loading: Story = {
  args: {
    isLoading: true,
    legendItems: defaultLegendItems,
  },
  play: async ({ canvasElement }: PlayArgs) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByRole("heading", { name: /Inbound Fill Rate/i })).toBeInTheDocument();
  },
};

export const Empty: Story = {
  args: {
    isEmpty: true,
    legendItems: defaultLegendItems,
  },
  play: async ({ canvasElement }: PlayArgs) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByText("No Data Available")).toBeInTheDocument();
  },
};

export const EmptyCustom: Story = {
  args: {
    isEmpty: true,
    emptyContent: (
      <Typography as="div" variant="body2" color="secondary" className="flex min-h-[200px] items-center justify-center">
        No vendors match the current filters
      </Typography>
    ),
  },
};

export const ErrorState: Story = {
  name: "Error",
  args: {
    error: "Failed to fetch service level trend",
    legendItems: defaultLegendItems,
  },
  play: async ({ canvasElement }: PlayArgs) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByText("Unable to load chart")).toBeInTheDocument();
  },
};

export const PaddingAndMargin: Story = {
  name: "Padding / margin configurations",
  args: {
    legendPosition: "none",
    chartPadding: 24,
    chartMargin: 8,
    chartBackground: "var(--color-ui-background-secondary)",
    chartBorderRadius: 8,
    minHeight: 240,
    children: <DemoLineChart />,
  },
};

export const LongTitle: Story = {
  args: {
    title: "Inbound Fill Rate Trend Across All Active Distribution Centers and Vendor Partners",
    infoTooltip: "Long titles should wrap without colliding with actions.",
    actions: (
      <Button variant="outline" size="sm" onClick={fn()}>
        Export
      </Button>
    ),
    legendItems: defaultLegendItems,
    children: <DemoLineChart />,
  },
};

export const WithAxisLabels: Story = {
  name: "Labels — left / right / bottom",
  args: {
    legendPosition: "top",
    legendItems: defaultLegendItems,
    labels: {
      left: (
        <Typography
          as="span"
          variant="body2"
          color="secondary"
          className="write-vertical-left rotate-180 whitespace-nowrap [writing-mode:vertical-rl]"
        >
          Fill rate (%)
        </Typography>
      ),
      right: (
        <Typography
          as="span"
          variant="body2"
          color="secondary"
          className="write-vertical-left rotate-180 whitespace-nowrap [writing-mode:vertical-rl]"
        >
          Orders
        </Typography>
      ),
      bottom: (
        <Typography as="span" variant="body2" color="secondary">
          Day of week
        </Typography>
      ),
    },
    children: <DemoLineChart />,
  },
};

export const ResponsiveBehavior: Story = {
  name: "Responsive behavior",
  render: () => (
    <div className="flex w-full max-w-4xl flex-col gap-4">
      <Typography as="p" variant="body2" color="secondary">
        Resize the Storybook viewport — the chart surface uses full width with a stable min-height.
      </Typography>
      <div className="grid gap-4 md:grid-cols-2">
        <ChartWrapper title="Compact" legendPosition="none" minHeight={180} className="w-full">
          <DemoLineChart />
        </ChartWrapper>
        <ChartWrapper
          title="Wide panel"
          infoTooltip="Shares the same responsive chart surface."
          legendItems={defaultLegendItems}
          minHeight={180}
          className="w-full"
        >
          <DemoLineChart />
        </ChartWrapper>
      </div>
    </div>
  ),
};

export const WithFooter: Story = {
  args: {
    legendItems: defaultLegendItems,
    children: <DemoLineChart />,
    footer: (
      <div className="flex justify-end">
        <Button type="button" variant="text" onClick={fn()}>
          View More →
        </Button>
      </div>
    ),
  },
  play: async ({ canvasElement }: PlayArgs) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole("button", { name: /View More/i }));
  },
};

export const TitleInfoGapLarge: Story = {
  name: "Title / info spacing",
  args: {
    titleInfoGap: "lg",
    infoTooltip: "Larger gap between title and info icon.",
    legendPosition: "none",
    children: <DemoLineChart />,
  },
};
