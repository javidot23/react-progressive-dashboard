import {
  forwardRef,
  type CSSProperties,
  type HTMLAttributes,
  type ReactNode,
} from "react";
import { Card, CardContent, CardHeader } from "@/components/atoms/Card";
import InfoIcon from "@/components/atoms/InfoIcon";
import Legend, { type LegendItem, type LegendProps } from "@/components/atoms/Legend";
import { Typography } from "@/components/atoms/Typography";
import { EmptyState } from "@/components/molecules/EmptyState";
import { cn } from "@/lib/utils";

export type ChartLegendPosition = "top" | "bottom" | "none";
/**
 * Shell appearance:
 * - `default` / `outlined` — white background, border, rounded corners
 * - `elevated` — white background, border, shadow, rounded corners
 * - `transparent` — no fill / no border (for embedding on tinted page backgrounds)
 */
export type ChartWrapperVariant = "default" | "elevated" | "outlined" | "transparent";
export type ChartTitleInfoGap = "sm" | "md" | "lg";

export type ChartWrapperLabels = {
  left?: ReactNode;
  right?: ReactNode;
  bottom?: ReactNode;
};

export type ChartWrapperProps = Omit<HTMLAttributes<HTMLDivElement>, "title"> & {
  /** Chart title — string or custom node. */
  title?: ReactNode;
  /** Optional description under the title row. */
  description?: ReactNode;
  /**
   * Info control next to the title.
   * Pass a string to render the standard `InfoIcon` tooltip, or a custom node.
   */
  info?: ReactNode;
  /** Convenience alias for `info` when using a tooltip string. */
  infoTooltip?: string;
  /** Spacing between title and info control. */
  titleInfoGap?: ChartTitleInfoGap | string;
  /** Right-aligned header action(s). */
  actions?: ReactNode;
  /** Replace the entire header region with a custom node. */
  header?: ReactNode;

  /** Where to render the built-in legend. Use `none` to hide. */
  legendPosition?: ChartLegendPosition;
  /** Items for the built-in `Legend` atom. */
  legendItems?: LegendItem[];
  legendOrientation?: LegendProps["orientation"];
  legendSpacing?: LegendProps["spacing"];
  legendClassName?: string;
  /** Custom legend renderer (receives position). Overrides `legendItems`. */
  renderLegend?: (position: Exclude<ChartLegendPosition, "none">) => ReactNode;
  /** Fully custom legend node (same content used for top/bottom based on `legendPosition`). */
  legend?: ReactNode;

  /** Chart visualization — library-agnostic. */
  children?: ReactNode;
  /** Padding applied to the chart surface. */
  chartPadding?: CSSProperties["padding"];
  /** Margin applied to the chart surface. */
  chartMargin?: CSSProperties["margin"];
  /** Minimum height of the chart surface. */
  minHeight?: CSSProperties["minHeight"];
  /** Explicit height of the chart surface. */
  height?: CSSProperties["height"];
  /** Chart surface background. */
  chartBackground?: CSSProperties["background"];
  /** Chart surface border radius. */
  chartBorderRadius?: CSSProperties["borderRadius"];
  /** Extra classes on the chart surface. */
  chartClassName?: string;
  /** Inline styles merged onto the chart surface. */
  chartStyle?: CSSProperties;
  /**
   * When true (default), the chart surface grows with the container
   * (`w-full min-w-0`). Set false for fixed/intrinsic sizing.
   */
  responsive?: boolean;

  /**
   * Axis / annotation labels around the chart.
   * Positioning is layout-only — the wrapper does not assume a chart library.
   */
  labels?: ChartWrapperLabels;

  /** Loading state for the chart area. */
  isLoading?: boolean;
  /** Custom loading content (defaults to a pulse placeholder). */
  loadingContent?: ReactNode;

  /** Empty state for the chart area. */
  isEmpty?: boolean;
  emptyContent?: ReactNode;
  emptyTitle?: string;
  emptyDescription?: string;

  /** Error state for the chart area. */
  error?: ReactNode | string | null;
  errorContent?: ReactNode;

  /**
   * Shell surface. Use `default` for white + border + rounded; use `transparent`
   * when the chart should sit flush on the page background.
   */
  variant?: ChartWrapperVariant;
  /** Show a divider between header/legend and chart body. */
  showDivider?: boolean;
  /** Optional footer below the chart (and bottom legend). */
  footer?: ReactNode;
  /** Classes for the content region wrapping legend + chart. */
  contentClassName?: string;
  /** Accessible name for the chart surface when no visible title is enough. */
  ariaLabel?: string;
};

const TITLE_INFO_GAP: Record<ChartTitleInfoGap, string> = {
  sm: "gap-1",
  md: "gap-2",
  lg: "gap-3",
};

function toCssSize(value: string | number | undefined): string | undefined {
  if (value == null) return undefined;
  return typeof value === "number" ? `${value}px` : value;
}

function ChartAreaSkeleton({ minHeight }: { minHeight?: CSSProperties["minHeight"] }) {
  return (
    <div
      className="w-full animate-pulse rounded bg-ui-background-secondary"
      style={{ minHeight: minHeight ?? 280 }}
      aria-hidden
    />
  );
}

function ChartErrorState({ message }: { message: ReactNode }) {
  return (
    <div className="flex min-h-[200px] w-full flex-col items-center justify-center gap-1 px-4 text-center">
      <Typography as="p" variant="body2" color="destructive" className="font-medium">
        Unable to load chart
      </Typography>
      {typeof message === "string" ? (
        <Typography as="p" variant="body2" color="muted">
          {message}
        </Typography>
      ) : (
        message
      )}
    </div>
  );
}

function renderLegendSlot(
  position: Exclude<ChartLegendPosition, "none">,
  {
    legend,
    legendItems,
    legendOrientation,
    legendSpacing,
    legendClassName,
    renderLegend,
  }: Pick<
    ChartWrapperProps,
    | "legend"
    | "legendItems"
    | "legendOrientation"
    | "legendSpacing"
    | "legendClassName"
    | "renderLegend"
  >
): ReactNode {
  if (renderLegend) return renderLegend(position);
  if (legend != null) return legend;
  if (legendItems?.length) {
    return (
      <Legend
        items={legendItems}
        orientation={legendOrientation}
        spacing={legendSpacing}
        className={legendClassName}
      />
    );
  }
  return null;
}

/**
 * Standard container for analytics charts.
 *
 * Provides header (title / info / actions), configurable legends, label slots,
 * and loading / empty / error states. Chart library content is passed as children.
 */
export const ChartWrapper = forwardRef<HTMLDivElement, ChartWrapperProps>(
  (
    {
      title,
      description,
      info,
      infoTooltip,
      titleInfoGap = "md",
      actions,
      header,
      legendPosition = "top",
      legendItems,
      legendOrientation = "horizontal",
      legendSpacing = "md",
      legendClassName,
      renderLegend,
      legend,
      children,
      chartPadding,
      chartMargin,
      minHeight = 320,
      height,
      chartBackground,
      chartBorderRadius,
      chartClassName,
      chartStyle,
      responsive = true,
      labels,
      isLoading = false,
      loadingContent,
      isEmpty = false,
      emptyContent,
      emptyTitle = "No Data Available",
      emptyDescription = "No data found for the selected filters. Try adjusting your filter criteria to see results.",
      error = null,
      errorContent,
      variant = "default",
      showDivider = true,
      footer,
      contentClassName,
      ariaLabel,
      className,
      style,
      ...rest
    },
    ref
  ) => {
    const infoNode =
      info ?? (infoTooltip ? <InfoIcon tooltip={infoTooltip} /> : null);

    const titleInfoGapClass =
      titleInfoGap in TITLE_INFO_GAP
        ? TITLE_INFO_GAP[titleInfoGap as ChartTitleInfoGap]
        : undefined;

    const hasBuiltinHeader = title != null || infoNode != null || actions != null;
    const showHeader = header != null || hasBuiltinHeader || description != null;

    const legendProps = {
      legend,
      legendItems,
      legendOrientation,
      legendSpacing,
      legendClassName,
      renderLegend,
    };

    const topLegend =
      legendPosition === "top"
        ? renderLegendSlot("top", legendProps)
        : null;
    const bottomLegend =
      legendPosition === "bottom"
        ? renderLegendSlot("bottom", legendProps)
        : null;

    const hasError = error != null && error !== false && error !== "";
    const showChartChildren = !isLoading && !isEmpty && !hasError;

    const chartSurfaceStyle: CSSProperties = {
      padding: chartPadding,
      margin: chartMargin,
      minHeight: toCssSize(minHeight as string | number | undefined) ?? minHeight,
      height: toCssSize(height as string | number | undefined) ?? height,
      background: chartBackground,
      borderRadius: toCssSize(chartBorderRadius as string | number | undefined) ?? chartBorderRadius,
      ...chartStyle,
    };

    const accessibleName =
      ariaLabel ?? (typeof title === "string" ? title : undefined);

    let chartBody: ReactNode;
    if (isLoading) {
      chartBody = loadingContent ?? <ChartAreaSkeleton minHeight={minHeight} />;
    } else if (hasError) {
      chartBody = errorContent ?? <ChartErrorState message={error} />;
    } else if (isEmpty) {
      chartBody =
        emptyContent ?? (
          <EmptyState title={emptyTitle} description={emptyDescription} />
        );
    } else {
      chartBody = children;
    }

    const chartSurface = (
      <div
        className={cn(
          "relative flex min-h-0 flex-1 flex-col",
          responsive && "w-full min-w-0",
          chartClassName
        )}
        style={chartSurfaceStyle}
        {...(accessibleName && showChartChildren
          ? { role: "img", "aria-label": accessibleName }
          : {})}
        aria-busy={isLoading || undefined}
      >
        {chartBody}
      </div>
    );

    const labeledChart = (
      <div className="flex w-full min-w-0 flex-col gap-2">
        <div className="flex w-full min-w-0 items-stretch gap-2">
          {labels?.left != null && (
            <Typography
              as="div"
              variant="body2"
              color="secondary"
              className="flex shrink-0 items-center self-stretch"
            >
              {labels.left}
            </Typography>
          )}
          <div className="flex min-w-0 flex-1 flex-col">{chartSurface}</div>
          {labels?.right != null && (
            <Typography
              as="div"
              variant="body2"
              color="secondary"
              className="flex shrink-0 items-center self-stretch"
            >
              {labels.right}
            </Typography>
          )}
        </div>
        {labels?.bottom != null && (
          <Typography
            as="div"
            variant="body2"
            color="secondary"
            className="w-full text-center"
          >
            {labels.bottom}
          </Typography>
        )}
      </div>
    );

    const isTransparent = variant === "transparent";
    const cardVariant = isTransparent ? "default" : variant;

    return (
      <Card
        ref={ref}
        variant={cardVariant}
        className={cn(
          "flex flex-col",
          isTransparent && "border-transparent bg-transparent shadow-none",
          className
        )}
        style={style}
        {...rest}
      >
        {showHeader && (
          <CardHeader className="shrink-0 space-y-4">
            {header != null ? (
              header
            ) : (
              <>
                {hasBuiltinHeader && (
                  <div className="flex items-center justify-between gap-2">
                    <div
                      className={cn("flex min-w-0 items-center", titleInfoGapClass)}
                      style={
                        titleInfoGapClass
                          ? undefined
                          : { gap: titleInfoGap }
                      }
                    >
                      {title != null &&
                        (typeof title === "string" ? (
                          <Typography
                            as="h3"
                            variant="h4"
                            className="text-xl font-bold leading-none tracking-tight text-heading font-brand"
                          >
                            {title}
                          </Typography>
                        ) : (
                          title
                        ))}
                      {infoNode}
                    </div>
                    {actions != null && (
                      <div className="relative shrink-0">{actions}</div>
                    )}
                  </div>
                )}
                {description != null && (
                  <Typography as="div" variant="body2" color="secondary">
                    {description}
                  </Typography>
                )}
              </>
            )}
            {showDivider && (showHeader || topLegend) && (
              <hr className="border-ui-border-primary" />
            )}
            {topLegend != null && <div className="pb-1">{topLegend}</div>}
          </CardHeader>
        )}

        {!showHeader && topLegend != null && (
          <div className="shrink-0 space-y-4 px-5 pt-6">
            {topLegend}
            {showDivider && <hr className="border-ui-border-primary" />}
          </div>
        )}

        <CardContent
          className={cn("flex flex-1 flex-col gap-5 pt-5", contentClassName)}
        >
          {labeledChart}
          {bottomLegend != null && (
            <div className="shrink-0 pt-1">{bottomLegend}</div>
          )}
        </CardContent>

        {footer != null && <div className="shrink-0 px-6 pb-6">{footer}</div>}
      </Card>
    );
  }
);

ChartWrapper.displayName = "ChartWrapper";

export default ChartWrapper;
