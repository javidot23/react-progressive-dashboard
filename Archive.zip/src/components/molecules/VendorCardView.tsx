import { VendorRawData, formatSalesRevenueAndQuantity, formatTwoDecimal, getRiskBadge, roundToTwoDecimals } from "@/lib/vendorUtils";
import { Link } from "react-router-dom";
import VendorBarChartCard from "@/components/molecules/VendorBarChartCard";
import VendorLineChart from "@/components/molecules/VendorLineChart";
import { useRiskModelDescriptions } from "@/hooks";
import { isFullFeatureSet } from "@/tenant";

interface VendorCardViewProps {
  vendor: VendorRawData;
}

// Helper function to calculate metrics
const getVendorMetrics = (vendor: VendorRawData) => {
  const serviceLevels = vendor.service_levels_90_days;
  const avgFillRate =
    serviceLevels && serviceLevels.length > 0
      ? (serviceLevels.reduce((sum: number, s: any) => {
        const orderQty = s.total_order_qty ?? 0;
        const receivedQty = s.total_received_qty ?? 0;
        return sum + (orderQty > 0 ? (receivedQty / orderQty) * 100 : 0);
      }, 0) / serviceLevels.length).toFixed(2)
      : "93.40";

  const riskPercentage = (vendor.risk_rating * 100).toFixed(2);
  const riskBadge = getRiskBadge(vendor.risk_rating);

  return {
    avgFillRate,
    riskPercentage,
    riskBadge,
  };
};

// Individual card components
const FillRateCard = ({ vendor, avgFillRate }: { vendor: VendorRawData; avgFillRate: string }) => (
  <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md pt-1 px-2 pb-0 h-[79px]">
    {renderCardHeader(`Fill Rate Trend 90 Days`)}
    <div className="text-2xs absolute text-[#6B7280]">AVG {avgFillRate}%</div>
    <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px] mt-1"></div>
    <div className="">
      <VendorLineChart vendor={vendor} />
    </div>
  </div>
);

const RiskScoreCard = ({
  vendor,
  riskPercentage,
  riskBadge,
}: {
  vendor: VendorRawData;
  riskPercentage: string;
  riskBadge: ReturnType<typeof getRiskBadge>;
}) => {
  const showExactScore = isFullFeatureSet();
  return (
    <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 h-[79px]">
      {renderCardHeaderWithBadge(
        "Risk Score",
        `flex items-center ${riskBadge.bgColor} ${riskBadge.textColor} border border-1 ${riskBadge.borderColor} px-1 py-0.5 rounded text-2xs font-semibold text-nowrap`,
        riskBadge.text
      )}
      {showExactScore ? (
        <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px] mt-1">{riskPercentage} / 100</div>
      ) : (<div className="py-2"></div>)}
      <div>
        <VendorBarChartCard vendor={vendor} color={riskBadge.hexColor} fullWidth={!showExactScore} />
      </div>
    </div>
  );
};

const PrimaryRiskCard = ({ value }: { value?: string | null }) => {
  const displayValue = (value ?? "").trim() || "-";
  return (
  <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 h-[79px]">
    {renderCardHeader("Driving Risk")}
    <div className={`font-bold text-neutral-900 leading-tight ${displayValue.length > 30 ? "text-sm" : "mt-1"}`}>{displayValue}</div>
  </div>
  );
};

const RiskAdjustedValueCard = ({ vendor, riskPercentage }: { vendor: VendorRawData; riskPercentage: string }) => {
  const percentage = Number(riskPercentage);
  const riskAdjustedValue = vendor.risk_adjusted_value || 0;
  const calculated = (percentage / 100) * riskAdjustedValue;
  const roundedValue = roundToTwoDecimals(calculated);

  const value = vendor.risk_adjusted_value
    ? `${formatTwoDecimal(roundedValue, "currency")} / ${formatTwoDecimal(vendor.risk_adjusted_value, "currency")}`
    : "- / -";

  return (
    <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 h-[79px]">
      {renderCardHeader("Risk Adjusted Value")}
      <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px] mt-1">{value}</div>
    </div>
  );
};

const SalesVolumeCard = ({ vendor }: { vendor: VendorRawData }) => {
  const value = formatSalesRevenueAndQuantity(vendor.sales_amount, vendor.sales_volume);

  return (
    <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 h-[79px]">
      {renderCardHeader("Sales Amount")}
      <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px] mt-1">{value}</div>
    </div>
  );
};

const MaterialsAtRiskCard = ({ vendor }: { vendor: VendorRawData }) => {
  const value = (vendor.total_materials ?? 0) > 0 ? `${vendor.materials_at_risk ?? 0} / ${vendor.total_materials ?? 0}` : "- / -";

  return (
    <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 h-[79px]">
      {renderCardHeader("Materials at Risk")}
      <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px] mt-1">{value}</div>
    </div>
  );
};

// Helper function to render warning icon
const renderWarningIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.5}
    stroke="currentColor"
    className="w-4 h-4"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
    />
  </svg>
);

// Helper function to render card header
const renderCardHeader = (title: string) => (
  <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">{title}</div>
);

// Helper function to render card header with badge
const renderCardHeaderWithBadge = (title: string, badgeClassName: string, badgeText: string) => (
  <div className="flex justify-between items-center space-x-2 mb-1">
    <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">{title}</div>
    <div className={badgeClassName}>
      {renderWarningIcon()}
      {badgeText}
    </div>
  </div>
);

// Helper function to render vendor header info
const renderVendorHeader = (vendor: VendorRawData) => (
  <div className="mb-4">
    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
      <h3 className="font-semibold text-base sm:text-lg text-ui-text-primary py-2 wrap-break-word">{vendor.name} • {vendor.vendor_nbr}</h3>
      <div className="flex items-center space-x-2 text-sm text-ui-text-secondary shrink-0">
        <span>•</span>
        <span className="truncate">{vendor.city}</span>
      </div>
    </div>
  </div>
);

export default function VendorCardView({ vendor }: VendorCardViewProps) {
  const { getEnrichedMetadata } = useRiskModelDescriptions();
  const { avgFillRate, riskPercentage, riskBadge } = getVendorMetrics(vendor);
  const drivingRiskLabel =
    getEnrichedMetadata(vendor.driving_risk).display_name ||
    vendor.driving_risk ||
    "-";

  return (
    <Link to={`/plan/vendor/${vendor.id}`} key={vendor.id} state={{ vendor }}>
      <div className="border border-ui-border-primary rounded-md my-3 p-4">
        {renderVendorHeader(vendor)}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
          <FillRateCard vendor={vendor} avgFillRate={avgFillRate} />
          <RiskScoreCard vendor={vendor} riskPercentage={riskPercentage} riskBadge={riskBadge} />
          <PrimaryRiskCard value={drivingRiskLabel} />
          <RiskAdjustedValueCard vendor={vendor} riskPercentage={riskPercentage} />
          <SalesVolumeCard vendor={vendor} />
          <MaterialsAtRiskCard vendor={vendor} />
        </div>
        <div className="flex flex-row items-center justify-end mt-3">
          <span className="text-[#461E96] font-bold text-md">View Supplier Portfolio</span>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
          </svg>
        </div>
      </div>
    </Link>
  );
}
