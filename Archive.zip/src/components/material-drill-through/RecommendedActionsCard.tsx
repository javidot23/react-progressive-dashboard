import CardLayout from "@/components/templates/CardLayout";
import ActionButtonGroup from "@/components/molecules/ActionButtonGroup";
import type { MaterialWithIssues } from "@/lib/types";
// import lightbulbIcon from "@/assets/icons/lightbulb.svg";

interface RecommendedActionsCardProps {
  material: MaterialWithIssues | null | undefined;
  vendorId?: number;
  isLoading?: boolean;
}

export function RecommendedActionsCard({
  material,
  vendorId,
  isLoading,
}: RecommendedActionsCardProps) {
  const openIssue = material?.open_issues?.[0];
  const hasOpenIssue = Boolean(openIssue?.issue_nbr);

  return (
    <CardLayout title="Recommended Actions" className="h-full min-h-[450px] flex flex-col">
      {/* <div className="flex items-center gap-2 mb-4">
        <img src={lightbulbIcon} alt="" className="w-4 h-4" aria-hidden />
        <p className="text-[#525252] text-sm whitespace-nowrap">Recommended Actions</p>
        <hr className="flex-1 border-t border-[#E0E0E0]" />
      </div> */}

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-10 bg-gray-100 rounded animate-pulse" />
          ))}
        </div>
      ) : hasOpenIssue ? (
        <ActionButtonGroup
          material={material!}
          size="md"
          layout="column"
          groupByActionCategory
          issueId={openIssue!.id}
          potentialActions={openIssue!.potential_actions ?? []}
          issueNbr={openIssue!.issue_nbr}
          vendorId={vendorId}
        />
      ) : null}
    </CardLayout>
  );
}
