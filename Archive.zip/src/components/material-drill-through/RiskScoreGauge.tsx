import { useId } from "react";
import { getRiskBadge } from "@/lib/vendorUtils";

interface RiskScoreGaugeProps {
  score: number;
  showScoreLabel?: boolean;
  /** Hides the numeric overlay (variant portal supplier profile — no actual risk values). */
  hideNumericScore?: boolean;
}

/** Semicircle arc geometry — math angle θ measured from +x CCW; SVG y grows down. */
const CX = 100;
const CY = 96;
const R_ARC = 78;
/** Needle stops slightly inside the stroke so it reads clearly */
const R_NEEDLE = 70;

export function RiskScoreGauge({
  score,
  showScoreLabel = true,
  hideNumericScore = false,
}: RiskScoreGaugeProps) {
  const gradientId = useId().replace(/:/g, "");
  const normalized = Math.min(100, Math.max(0, Math.round(score)));
  const fraction = normalized / 100;
  const riskBadge = getRiskBadge(fraction);

  // θ from π (left / low risk) → 0 (right / high risk) across the upper semicircle
  const theta = Math.PI * (1 - fraction);
  const tipX = CX + R_NEEDLE * Math.cos(theta);
  const tipY = CY - R_NEEDLE * Math.sin(theta);

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: 200, height: 108 }}>
        <svg viewBox="0 0 200 108" className="w-[200px] h-[108px]" aria-hidden>
          <defs>
            <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#16a34a" />
              <stop offset="45%" stopColor="#FFA400" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
          </defs>
          {/* Explicit 180° arc: diameter left→right, upper semicircle (bulge toward smaller y) */}
          <path
            d={`M ${CX - R_ARC} ${CY} A ${R_ARC} ${R_ARC} 0 0 1 ${CX + R_ARC} ${CY}`}
            fill="none"
            stroke={`url(#${gradientId})`}
            strokeWidth="12"
            strokeLinecap="round"
          />
          <line
            x1={CX}
            y1={CY}
            x2={tipX}
            y2={tipY}
            stroke="#1E1E1E"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <circle cx={CX} cy={CY} r={4.5} fill="#1E1E1E" />
        </svg>
        {!hideNumericScore && (
          <div className="pointer-events-none absolute inset-0 flex items-end justify-center pb-5">
            <span className="text-[2rem] font-bold leading-none text-[#1E1E1E] tabular-nums">
              {normalized}
              {showScoreLabel && (
                <span className="text-base font-semibold text-[#6E6E6E]"> / 100</span>
              )}
            </span>
          </div>
        )}
      </div>
      <span
        className={[
          "mt-1 inline-flex items-center rounded-full border px-3 py-0.5 text-xs font-semibold",
          riskBadge.bgColor,
          riskBadge.textColor,
          riskBadge.borderColor,
        ].join(" ")}
      >
        {riskBadge.text}
      </span>
    </div>
  );
}
