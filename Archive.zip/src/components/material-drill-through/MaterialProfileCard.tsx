import { Card } from "@/components/atoms/Card";
import {
  formatOrNA,
  isPresent,
  PROFILE_NA,
  ProfileKVList,
  ProfileSection,
  ProfileSkeletonLines,
} from "@/components/material-drill-through/profileCardShared";
import {
  shouldShowCostPerUnit,
  shouldShowDqsaChip,
  shouldShowFeeForService,
  shouldShowFormularySection,
  shouldShowInventoryQuantityRows,
  shouldShowManufacturerAvailability,
  shouldShowMarketShareInProfile,
  shouldShowMaterialExposureFields,
} from "@/components/material-drill-through/materialDrillVisibility";
import { formatCurrency, formatCurrencyCompact, getMaterialStatusDescription } from "@/lib/utils";
import type {
  MaterialFormularyEntry,
  MaterialSubstitutionDetailsResponse,
} from "@/lib/apiServices";

type MaterialDetail = MaterialSubstitutionDetailsResponse["data"]["material"];

interface MaterialProfileCardProps {
  material?: MaterialDetail | null;
  materialFormularies?: MaterialFormularyEntry[];
  availablePlantsCount?: number | null;
  riskAdjustedValue?: number | string | null;
  isLoading?: boolean;
}

function toTitleCase(value: string): string {
  return value
    .toLowerCase()
    .split(/(\s+|[·/,-])/)
    .map(part => (part.match(/^[a-z]/) ? part.charAt(0).toUpperCase() + part.slice(1) : part))
    .join("");
}

function sentenceCase(value: string): string {
  const trimmed = value.trim();
  if (!trimmed) return trimmed;
  return trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase();
}

function isFlagOn(value: unknown): boolean {
  if (value === true) return true;
  if (value === 1) return true;
  if (typeof value === "string") {
    const v = value.trim().toUpperCase();
    return v === "Y" || v === "YES" || v === "TRUE" || v === "1";
  }
  return false;
}

function formatPercent(value: number | null | undefined, digits = 0): string {
  if (!isPresent(value)) return PROFILE_NA;
  const num = value as number;
  const pct = num <= 1 ? num * 100 : num;
  return `${pct.toFixed(digits)}%`;
}

function WarningTriangleIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      width={18}
      height={18}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M12 9v3.75m-9.3 3.38c-.87 1.5.22 3.37 1.95 3.37h14.7c1.73 0 2.82-1.87 1.95-3.37L13.95 3.38c-.87-1.5-3.03-1.5-3.9 0L2.7 16.13ZM12 15.75h.01v.01H12v-.01Z" />
    </svg>
  );
}

function AvailabilityNote({ note }: { note: string }) {
  return (
    <div className="mt-3.5 flex items-center gap-2.5 rounded-lg border border-warning-200 bg-warning-50 p-3">
      <WarningTriangleIcon className="shrink-0 text-warning-600" />
      <div className="min-w-0">
        <p className="text-[13px] font-bold leading-tight text-warning-800">
          Manufacturer availability
        </p>
        <p className="mt-0.5 text-[12px] font-medium text-neutral-500">{sentenceCase(note)}</p>
      </div>
    </div>
  );
}

function Chip({ on, children }: { on: boolean; children: React.ReactNode }) {
  return (
    <span
      className={[
        "inline-flex items-center rounded-md px-2.5 py-1 text-[12px] font-semibold",
        on ? "bg-brand-primary-100 text-brand-primary-main" : "bg-neutral-100 text-neutral-700",
      ].join(" ")}
    >
      {children}
    </span>
  );
}

function MaterialProfileSkeleton() {
  return (
    <Card variant="default" className="p-5">
      <div className="mb-2 h-5 w-44 animate-pulse rounded bg-neutral-200" />
      <div className="mb-5 h-3 w-60 animate-pulse rounded bg-neutral-200" />
      <div className="space-y-5">
        <ProfileSkeletonLines rows={5} />
        <ProfileSkeletonLines rows={4} />
        <ProfileSkeletonLines rows={4} />
      </div>
    </Card>
  );
}

export function MaterialProfileCard({
  material,
  materialFormularies = [],
  availablePlantsCount,
  riskAdjustedValue,
  isLoading,
}: MaterialProfileCardProps) {
  if (isLoading) {
    return <MaterialProfileSkeleton />;
  }

  const matNbr = material?.mat_nbr ?? "";
  const ndc = material?.ndc;
  const api = material?.api;
  const formRoute =
    material &&
    (isPresent(material.form_cd) || isPresent(material.route_cd_interpretation))
      ? `${material.form_cd ?? "—"} · ${material.route_cd_interpretation ?? "—"}`
      : null;
  const strength =
    material &&
    (isPresent(material.unit_strength_qty) || isPresent(material.unit_strength_type_cd))
      ? `${material.unit_strength_qty ?? ""} ${material.unit_strength_type_cd ?? ""}`.trim()
      : null;
  const materialGroup = material?.scrm_mat_grp ?? material?.material_group ?? null;
  const status =
    material && isPresent(material.xplant_mat_stat)
      ? getMaterialStatusDescription(material.xplant_mat_stat)
      : null;
  const therapyClass = material?.hic3_therapy_class;

  const daysOnHandDisplay = (() => {
    if (!material || !isPresent(material.days_on_hand)) return PROFILE_NA;
    const raw = material.days_on_hand;
    if (typeof raw === "number") return `${raw} days`;
    const asNum = Number(raw);
    return Number.isFinite(asNum) ? `${asNum} days` : String(raw);
  })();

  const marketShareDisplay = formatOrNA(material?.market_share, v =>
    formatPercent(v as number, 0)
  );
  const costPerUnitDisplay = formatOrNA(material?.cost_per_unit, v => formatCurrency(v));
  const darThisWeek = formatOrNA(material?.dollars_at_risk_this_week, v =>
    formatCurrencyCompact(v as number)
  );
  const darPrevWeek = formatOrNA(material?.dollars_at_risk_prev_week, v =>
    formatCurrencyCompact(v as number)
  );
  const radDisplay = (() => {
    if (typeof riskAdjustedValue === "string" && riskAdjustedValue) return riskAdjustedValue;
    if (typeof riskAdjustedValue === "number") return formatCurrencyCompact(riskAdjustedValue);
    return PROFILE_NA;
  })();

  const formularies =
    materialFormularies.length > 0
      ? materialFormularies
      : (material?.material_formularies as MaterialFormularyEntry[] | null | undefined) ?? [];

  return (
    <Card variant="default" className="p-5">
      <header className="mb-4">
        <h2 className="text-[18px] font-bold leading-tight text-neutral-900">Material Profile</h2>
        <p className="mt-1 text-[13px] font-medium text-neutral-500">
          Full attribute detail for {matNbr || PROFILE_NA}
        </p>
      </header>

      <ProfileSection title="Identity & Classification">
        <ProfileKVList
          rows={[
            { label: "Material #", value: formatOrNA(matNbr || null) },
            { label: "NDC", value: formatOrNA(ndc) },
            { label: "API", value: formatOrNA(api, v => toTitleCase(v)) },
            { label: "Form · Route", value: formRoute ?? PROFILE_NA },
            { label: "Strength", value: strength ?? PROFILE_NA },
            { label: "Material group", value: formatOrNA(materialGroup) },
            { label: "Status", value: status ?? PROFILE_NA },
            {
              label: "Therapy class",
              value: formatOrNA(therapyClass, v => toTitleCase(v)),
            },
          ]}
        />
      </ProfileSection>

      <ProfileSection title="Inventory & Demand">
        <ProfileKVList
          rows={[
            ...(shouldShowInventoryQuantityRows()
              ? [
                  {
                    label: "Saleable on-hand",
                    value: isPresent(material?.saleable_qty_on_hand)
                      ? `${Number(material!.saleable_qty_on_hand).toLocaleString()} units`
                      : PROFILE_NA,
                  },
                  {
                    label: "Unrestricted on-hand",
                    value: isPresent(material?.unrestricted_qty_on_hand)
                      ? `${Number(material!.unrestricted_qty_on_hand).toLocaleString()} units`
                      : PROFILE_NA,
                  },
                  {
                    label: "7-day forecast",
                    value: isPresent(material?.forecast_qty_7day)
                      ? `${Number(material!.forecast_qty_7day).toLocaleString()} units`
                      : PROFILE_NA,
                  },
                ]
              : []),
            { label: "Days on hand", value: daysOnHandDisplay },
            {
              label: "Stocked Plants",
              value: isPresent(availablePlantsCount) ? String(availablePlantsCount) : PROFILE_NA,
            },
          ]}
        />
        {shouldShowManufacturerAvailability() &&
          material &&
          isPresent(material.mnftr_avail_note_desc) && (
            <AvailabilityNote note={material.mnftr_avail_note_desc as string} />
          )}
      </ProfileSection>

      <ProfileSection title="Commercial & Exposure">
        <ProfileKVList
          rows={[
            ...(shouldShowCostPerUnit()
              ? [{ label: "Cost / unit", value: costPerUnitDisplay }]
              : []),
            ...(shouldShowMarketShareInProfile()
              ? [{ label: "Market share", value: marketShareDisplay }]
              : []),
            ...(shouldShowMaterialExposureFields()
              ? [
                  {
                    label: "Avg shortage duration",
                    value: formatOrNA(material?.avg_shortage_duration, v => `${v} days`),
                  },
                ]
              : []),
            { label: "$ at risk (this week)", value: darThisWeek },
            { label: "$ at risk (prev week)", value: darPrevWeek },
            { label: "Risk-adjusted value", value: radDisplay },
          ]}
        />
      </ProfileSection>

      <ProfileSection title="Attributes">
        <div className="flex flex-wrap gap-2">
          <Chip on={isFlagOn(material?.inj_flg)}>Injectable</Chip>
          <Chip on={isFlagOn(material?.who_essential_flg)}>
            {isFlagOn(material?.who_essential_flg) ? "WHO Essential" : "Not WHO Essential"}
          </Chip>
          {shouldShowDqsaChip() && (
            <Chip on={false}>
              DQSA: {isFlagOn(material?.dqsa_exempt_flg) ? "Exempt" : "Not exempt"}
            </Chip>
          )}
          {shouldShowFeeForService() && (
            <Chip on={isFlagOn(material?.fee_for_service_flg)}>
              {isFlagOn(material?.fee_for_service_flg)
                ? "Fee for Service"
                : "Not Fee for Service"}
            </Chip>
          )}
        </div>
      </ProfileSection>

      {shouldShowFormularySection() && (
      <ProfileSection title="Formulary">
        {formularies.length === 0 ? (
          <p className="text-[13px] font-medium text-neutral-500">No formulary records</p>
        ) : (
          <div className="w-full min-w-0 text-[13px]" role="table">
            <div
              role="row"
              className="grid w-full grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)] gap-x-4 border-b border-neutral-200 pb-2"
            >
              <div
                role="columnheader"
                className="text-left text-[11px] font-bold uppercase tracking-[0.03em] text-neutral-400"
              >
                Program
              </div>
              <div
                role="columnheader"
                className="text-left text-[11px] font-bold uppercase tracking-[0.03em] text-neutral-400"
              >
                Program Description
              </div>
            </div>
            {formularies.map((f, i) => (
              <div
                key={f.id ?? i}
                role="row"
                className="grid w-full grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)] gap-x-4 border-b border-neutral-100 py-[9px] last:border-b-0"
              >
                <div role="cell" className="min-w-0 font-medium text-neutral-900">
                  {formatOrNA(f.program ?? f.name)}
                </div>
                <div role="cell" className="min-w-0 font-medium text-neutral-900">
                  {formatOrNA(f.program_description)}
                </div>
              </div>
            ))}
          </div>
        )}
      </ProfileSection>
      )}
    </Card>
  );
}
