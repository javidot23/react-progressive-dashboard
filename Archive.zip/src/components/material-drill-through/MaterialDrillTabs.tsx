import type { SVGProps } from "react";
import { useSearchParams } from "react-router-dom";

export type MaterialDrillTab =
  | "risk-events"
  | "profile"
  | "inventory"
  | "demand"
  | "actions"
  | "notes";

export const MATERIAL_DRILL_TAB_QUERY_KEY = "tab";

const VALID_TABS: MaterialDrillTab[] = [
  "risk-events",
  "profile",
  "inventory",
  "demand",
  "actions",
  "notes",
];

export function parseMaterialDrillTab(value: string | null): MaterialDrillTab {
  if (value && VALID_TABS.includes(value as MaterialDrillTab)) {
    return value as MaterialDrillTab;
  }
  return "risk-events";
}

interface MaterialDrillTabsProps {
  onTabChange?: (tab: MaterialDrillTab) => void;
  /**
   * Optional subset/relabel of the tabs to show (in order). Defaults to the full
   * issue-material tab set. Ids must exist in the built-in tab definitions.
   */
  tabs?: { id: MaterialDrillTab; label: string }[];
}

type TabDef = {
  id: MaterialDrillTab;
  label: string;
  disabled?: boolean;
  Icon: (p: SVGProps<SVGSVGElement> & { active?: boolean }) => React.ReactElement;
};

function IconRiskEvents({
  active,
  className,
  ...rest
}: SVGProps<SVGSVGElement> & { active?: boolean }) {
  const stroke = "currentColor";

  return (
    <svg
      className={className}
      width={20}
      height={20}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden
      {...rest}
    >
      <path
        d="M4.5 6.75A2.25 2.25 0 0 1 6.75 4.5h5.25"
        stroke={stroke}
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M4.5 6.75v6A2.25 2.25 0 0 0 6.75 15h7.5"
        stroke={stroke}
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8.25 18h4.5"
        stroke={stroke}
        strokeWidth={1.8}
        strokeLinecap="round"
      />
      <path
        d="M10.5 15v3"
        stroke={stroke}
        strokeWidth={1.8}
        strokeLinecap="round"
      />
      <path
        d="M14.8 4.9c.5-.87 1.76-.87 2.26 0l4.08 7.1c.5.87-.13 1.95-1.13 1.95h-8.16c-1 0-1.63-1.08-1.13-1.95l4.08-7.1Z"
        stroke={stroke}
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.93 8.25v2.25"
        stroke={stroke}
        strokeWidth={1.8}
        strokeLinecap="round"
      />
      <circle cx="15.93" cy="12" r="0.6" fill="currentColor" />
    </svg>
  );
}

function IconProfile({ className, ...rest }: SVGProps<SVGSVGElement>) {
  return (
    <svg
      className={className}
      width={20}
      height={20}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      {...rest}
    >
      <rect x="3.5" y="4.5" width="17" height="15" rx="2.25" />
      <path d="M3.5 9h17" />
      <path d="M7 13h4" />
      <path d="M7 16.25h6.5" />
      <circle cx="16.5" cy="14.25" r="2" />
      <path d="M14 17.75c.4-.95 1.4-1.5 2.5-1.5s2.1.55 2.5 1.5" />
    </svg>
  );
}

function IconActionsHistory({ className, ...rest }: SVGProps<SVGSVGElement>) {
  return (
    <svg className={className} width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} aria-hidden {...rest}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5a2.25 2.25 0 002.25-2.25m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5a2.25 2.25 0 012.25 2.25v7.5" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 12.75h.008v.008H12v-.008z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75h.008v.008h-.008v-.008z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 15.75h.008v.008h-.008v-.008z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 15.75h.008v.008h-.008v-.008z" />
      <circle cx="18" cy="18" r="4.5" fill="none" stroke="currentColor" strokeWidth={1.25} />
      <path strokeLinecap="round" strokeLinejoin="round" d="M18 16.5v2.25l1.125.562" />
    </svg>
  );
}

function IconNotes({ className, ...rest }: SVGProps<SVGSVGElement>) {
  return (
    <svg className={className} width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} aria-hidden {...rest}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
    </svg>
  );
}

const TABS: TabDef[] = [
  { id: "risk-events", label: "Driving Risk & Contributors ", Icon: IconRiskEvents },
  { id: "profile", label: "Material & Supplier Profile", Icon: IconProfile },
  { id: "actions", label: "Actions & History", Icon: IconActionsHistory },
  { id: "notes", label: "Notes", Icon: IconNotes },
];

export function MaterialDrillTabs({ onTabChange, tabs }: MaterialDrillTabsProps) {
  const [searchParams, setSearchParams] = useSearchParams();

  const visibleTabs: TabDef[] = tabs
    ? (tabs
        .map(t => {
          const base = TABS.find(b => b.id === t.id);
          return base ? { ...base, label: t.label } : null;
        })
        .filter(Boolean) as TabDef[])
    : TABS;

  const parsed = parseMaterialDrillTab(searchParams.get(MATERIAL_DRILL_TAB_QUERY_KEY));
  const activeTab = visibleTabs.some(t => t.id === parsed) ? parsed : visibleTabs[0]?.id ?? "risk-events";

  const handleTabChange = (tab: MaterialDrillTab) => {
    const next = new URLSearchParams(searchParams);
    next.set(MATERIAL_DRILL_TAB_QUERY_KEY, tab);
    setSearchParams(next, { replace: true });
    onTabChange?.(tab);
  };

  return (
    <div className="pb-0">
      <nav
        className="flex flex-nowrap gap-1 rounded-xl border-[#00000014]"
        aria-label="Material drill-through tabs"
      >
        <div className="bg-[#F5F5F5] p-1.5 rounded-xl">
          {visibleTabs.map(tab => {
            const isActive = activeTab === tab.id;
            const disabled = Boolean(tab.disabled);
            return (
              <button
                key={tab.id}
                type="button"
                disabled={disabled}
                onClick={() => !disabled && handleTabChange(tab.id)}
                className={[
                  "inline-flex min-w-0 flex-1 basis-0 items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium transition-all sm:flex-none sm:basis-auto",
                  isActive
                    ? "bg-white font-semibold text-brand-primary-main shadow-xs"
                    : "bg-transparent text-[#5C5F66]",
                  disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer hover:text-[#1E1E1E]",
                ].join(" ")}
              >
                <tab.Icon
                  className={[
                    "h-5 w-5 shrink-0",
                    isActive ? "text-brand-primary-main" : "text-[#5C5F66]",
                  ].join(" ")}
                  active={isActive}
                />
                <span className="truncate">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
