import CardLayout from "@/components/templates/CardLayout";
import type { DetailedSupplyChainEvent } from "@/lib/apiServices";
import { formatDrillThroughDate } from "@/lib/materialDrillThroughUtils";
import { EmptyState } from "@/components/molecules";

interface DrivingEventPanelProps {
  event: DetailedSupplyChainEvent | null;
  isLoading?: boolean;
  isFetching?: boolean;
}

function formatEventLocation(event: DetailedSupplyChainEvent): string | null {
  const parts: string[] = [];
  if (event.city?.trim()) parts.push(event.city.trim());
  if (event.state?.trim()) parts.push(event.state.trim());
  if (event.country?.trim()) parts.push(event.country.trim());
  return parts.length > 0 ? parts.join(", ") : null;
}

function DrivingEventCard({ event }: { event: DetailedSupplyChainEvent }) {
  const location = formatEventLocation(event);

  return (
    <div
      className={[
        "rounded-md border border-[#E2E8F0] bg-[#FAFAFA] p-3 transition-colors",
        "hover:border-brand-primary-100",
      ].join(" ")}
    >
      <div className="mb-1 flex items-start justify-between gap-2">
        <span className="text-sm font-semibold text-[#1E1E1E]">{event.type}</span>
        <span className="rounded-full bg-[#E8E8E8] px-2 py-0.5 text-xs font-medium text-[#3B3B3B]">
          {event.status}
        </span>
      </div>
      {event.event_id ? (
        <p className="mb-1 text-xs text-[#6E6E6E]">
          <span className="font-medium text-[#525252]">Event ID: </span>
          {event.event_id}
        </p>
      ) : null}
      {event.type_description ? (
        <p className="mb-2 text-sm text-[#6E6E6E]">{event.type_description}</p>
      ) : null}
      {location ? (
        <p className="mb-2 text-xs text-[#6E6E6E]">
          <span className="font-medium text-[#525252]">Location: </span>
          {location}
        </p>
      ) : null}
      <p className="text-xs text-[#6E6E6E]">
        <span className="font-medium text-[#525252]">Start Date: </span>
        {formatDrillThroughDate(event.start_date)}
        {event.end_date ? (
          <>
            {" "}
            <span className="font-medium text-[#525252]">End Date: </span>
            {formatDrillThroughDate(event.end_date)}
          </>
        ) : null}
      </p>
    </div>
  );
}

export function DrivingEventPanel({ event, isLoading, isFetching }: DrivingEventPanelProps) {
  return (
    <CardLayout title="Driving Event" className="flex h-full flex-col">
      <div className="min-h-[120px] flex-1 overflow-y-auto max-h-[420px]">
        {isLoading ? (
          <div className="h-24 animate-pulse rounded-md bg-gray-100" />
        ) : !event ? (
          <EmptyState
            title="No driving event"
            description="This issue is not linked to a supply chain event."
          />
        ) : (
          <div className={isFetching ? "opacity-70 transition-opacity" : undefined}>
            <DrivingEventCard event={event} />
          </div>
        )}
      </div>
    </CardLayout>
  );
}
