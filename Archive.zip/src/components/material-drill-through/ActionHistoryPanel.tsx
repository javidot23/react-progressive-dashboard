import CardLayout from "@/components/templates/CardLayout";
import { Pagination } from "@/components/atoms";
import Tooltip from "@/components/atoms/Tooltip";
import { EmptyState } from "@/components/molecules";
import type { UserAction } from "@/lib/apiServices";
import { cn } from "@/lib/utils";
import {
  ACTION_HISTORY_DOT_STYLES,
  actionHistoryHasHoverDetails,
  formatActionHistoryActor,
  formatActionHistoryDate,
  getActionHistoryDotTone,
  getActionHistoryHoverDetails,
  getActionHistoryLabel,
} from "@/lib/actionHistoryUtils";

interface ActionHistoryPanelProps {
  actions: UserAction[];
  total: number;
  currentPage: number;
  pageSize: number;
  isLoading?: boolean;
  isFetching?: boolean;
  onPageChange: (page: number) => void;
}

function ActionHistoryTooltipContent({ action }: { action: UserAction }) {
  const { materialAtRiskValue, riskScore, decisionRationale } = getActionHistoryHoverDetails(action);

  return (
    <div className="flex flex-col gap-2 text-left">
      <p>
        <span className="font-semibold text-[#3B3B3B]">Material at risk value: </span>
        {materialAtRiskValue}
      </p>
      <p>
        <span className="font-semibold text-[#3B3B3B]">Risk score: </span>
        {riskScore}
      </p>
      <p>
        <span className="font-semibold text-[#3B3B3B]">Decision rationale: </span>
        {decisionRationale}
      </p>
    </div>
  );
}

function ActionHistoryDot({ tone }: { tone: ReturnType<typeof getActionHistoryDotTone> }) {
  const styles = ACTION_HISTORY_DOT_STYLES[tone];
  return (
    <span
      className={cn("relative z-10 inline-flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full", styles.ring)}
      aria-hidden
    >
      <span className={cn("h-2 w-2 shrink-0 rounded-full", styles.inner)} />
    </span>
  );
}

export function ActionHistoryPanel({
  actions,
  total,
  currentPage,
  pageSize,
  isLoading,
  isFetching,
  onPageChange,
}: ActionHistoryPanelProps) {
  return (
    <CardLayout title="Action History" className="h-full flex flex-col">
      <div className="flex-1 overflow-y-auto max-h-[500px] pr-1 min-h-[120px]">
        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-14 bg-gray-100 rounded animate-pulse" />
            ))}
          </div>
        ) : actions.length === 0 ? (
          <EmptyState title="No action history" description="No actions were recorded for this material." />
        ) : (
          <div className="relative">
            <div
              className="pointer-events-none absolute bottom-2 top-2 w-px bg-[#E2E8F0]"
              style={{ left: "calc(5.5rem + 0.75rem + 10px)" }}
              aria-hidden
            />
            <ol className="relative space-y-8">
              {actions.map(action => {
                const label = getActionHistoryLabel(action);
                const tone = getActionHistoryDotTone(label);
                return (
                  <li key={action.id} className="grid grid-cols-[5.5rem_20px_1fr] items-start gap-x-3">
                    <time className="pt-0.5 text-right text-xs font-medium text-[#6B7280]" dateTime={action.created_at}>
                      {formatActionHistoryDate(action.created_at)}
                    </time>
                    <div className="flex justify-center pt-0.5">
                      <ActionHistoryDot tone={tone} />
                    </div>
                    <div className="min-w-0">
                      {actionHistoryHasHoverDetails(action) ? (
                        <Tooltip
                          content={<ActionHistoryTooltipContent action={action} />}
                          position="top"
                          contentMaxHeight={200}
                          className="block w-full"
                        >
                          <div>
                            <p className="text-sm font-semibold leading-snug text-[#1E1E1E]">{label}</p>
                            <p className="mt-1 text-xs text-[#6B7280]">{formatActionHistoryActor(action.user)}</p>
                          </div>
                        </Tooltip>
                      ) : (
                        <>
                          <p className="text-sm font-semibold leading-snug text-[#1E1E1E]">{label}</p>
                          <p className="mt-1 text-xs text-[#6B7280]">{formatActionHistoryActor(action.user)}</p>
                        </>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
          </div>
        )}
      </div>

      {total > 0 && (
        <Pagination
          currentPage={currentPage}
          pageSize={pageSize}
          total={total}
          onPageChange={onPageChange}
          onPageSizeChange={() => {}}
          itemName="actions"
          showPageSizeSelect={false}
          isLoading={isFetching}
          className="border-t border-[#E2E8F0] mt-2 pt-0"
        />
      )}
    </CardLayout>
  );
}
