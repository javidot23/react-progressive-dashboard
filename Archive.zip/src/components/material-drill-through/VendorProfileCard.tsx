import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/atoms/Card";
import { RiskScoreGauge } from "@/components/material-drill-through/RiskScoreGauge";
import {
  damagesRateTextClass,
  formatOrNA,
  formatVendorLocation,
  isPresent,
  normalizeScoreFraction,
  PROFILE_NA,
  filterProfileContactNames,
  ProfileKVCarouselRow,
  ProfileKVList,
  ProfileSection,
  ProfileSkeletonLines,
  resolveVendorBuyerNames,
  resolveVendorRiskScore,
  scoreBarFillClass,
} from "@/components/material-drill-through/profileCardShared";
import {
  shouldHideSupplierRiskScoreValue,
  shouldShowAsnMetrics,
  shouldShowContactsSection,
  shouldShowOverallScore,
  shouldShowOtifMetrics,
  shouldShowPerformanceScorecardSection,
  shouldShowProductDamagesRate,
} from "@/components/material-drill-through/materialDrillVisibility";
import { selectTenantPortalFlags, useTenantContextQuery } from "@/tenant";
import type { MaterialVendorDetail } from "@/lib/apiServices";

interface VendorProfileCardProps {
  vendor?: MaterialVendorDetail | null;
  isLoading?: boolean;
}

function ScoreBar({ label, value }: { label: string; value: number | null | undefined }) {
  if (!isPresent(value)) {
    return (
      <div className="mb-[13px]">
        <div className="mb-[5px] flex items-center justify-between text-[13px]">
          <span className="font-medium text-neutral-700">{label}</span>
          <span className="font-bold text-neutral-900">{PROFILE_NA}</span>
        </div>
        <div className="h-[7px] rounded bg-neutral-100" />
      </div>
    );
  }
  const clamped = normalizeScoreFraction(value as number);
  return (
    <div className="mb-[13px]">
      <div className="mb-[5px] flex items-center justify-between text-[13px]">
        <span className="font-medium text-neutral-700">{label}</span>
        <span className="font-bold text-neutral-900">{Math.round(clamped * 100)}%</span>
      </div>
      <div className="h-[7px] overflow-hidden rounded bg-neutral-100">
        <div className={`h-full rounded ${scoreBarFillClass(clamped)}`} style={{ width: `${clamped * 100}%` }} />
      </div>
    </div>
  );
}

function VendorProfileSkeleton() {
  return (
    <Card variant="default" className="p-5">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="mb-2 h-5 w-40 animate-pulse rounded bg-neutral-200" />
          <div className="h-3 w-52 animate-pulse rounded bg-neutral-200" />
        </div>
        <div className="h-[108px] w-[200px] animate-pulse rounded bg-neutral-100" />
      </div>
      <div className="mt-6 space-y-5">
        <ProfileSkeletonLines rows={5} />
        <ProfileSkeletonLines rows={6} />
        <ProfileSkeletonLines rows={2} />
      </div>
    </Card>
  );
}

export function VendorProfileCard({ vendor, isLoading }: VendorProfileCardProps) {
  const { data: flags } = useTenantContextQuery(selectTenantPortalFlags);
  const tenantType = flags?.tenantType;
  const buyerNames = useMemo(() => resolveVendorBuyerNames(vendor), [vendor]);
  const catMgrNames = useMemo(() => filterProfileContactNames(vendor?.cat_mgr_list), [vendor?.cat_mgr_list]);
  const [buyerIndex, setBuyerIndex] = useState(0);
  const [catMgrIndex, setCatMgrIndex] = useState(0);

  useEffect(() => {
    setBuyerIndex(0);
    setCatMgrIndex(0);
  }, [vendor?.id, buyerNames.join("\u0000"), catMgrNames.join("\u0000")]);

  if (isLoading) {
    return <VendorProfileSkeleton />;
  }

  const location = vendor ? formatVendorLocation(vendor) : PROFILE_NA;
  const riskScore = resolveVendorRiskScore(vendor?.risk_rating);

  const damagesDisplay = (() => {
    if (!isPresent(vendor?.product_damages_rate)) return PROFILE_NA;
    const num = vendor!.product_damages_rate as number;
    const pct = num <= 1 ? num * 100 : num;
    return `${pct.toFixed(1)}%`;
  })();

  const damagesClass =
    isPresent(vendor?.product_damages_rate) && vendor
      ? damagesRateTextClass(vendor.product_damages_rate as number)
      : "text-neutral-900";

  const subtitleName = vendor?.name ?? PROFILE_NA;
  const subtitleParent = isPresent(vendor?.vendor_parent_name) ? ` · ${vendor!.vendor_parent_name}` : "";

  return (
    <Card variant="default" className="p-5">
      <header className="mb-4 flex items-start justify-between gap-4">
        <div className="min-w-0 flex-1">
          <h2 className="text-[18px] font-bold leading-tight text-neutral-900">Supplier Profile</h2>
          <p className="mt-1 text-[13px] font-medium text-neutral-500">
            {subtitleName}
            {subtitleParent}
          </p>
        </div>
        <div className="shrink-0">
          <RiskScoreGauge
            score={riskScore}
            showScoreLabel={false}
            hideNumericScore={shouldHideSupplierRiskScoreValue(tenantType)}
          />
        </div>
      </header>

      <ProfileSection title="Identity">
        <ProfileKVList
          rows={[
            { label: "Supplier #", value: formatOrNA(vendor?.vendor_nbr) },
            { label: "Parent", value: formatOrNA(vendor?.vendor_parent_name) },
            { label: "Location", value: location },
            { label: "Supplier group", value: formatOrNA(vendor?.vendor_group) },
            { label: "DEA #", value: formatOrNA(vendor?.dea_number) },
            {
              label: "Status",
              value: vendor?.is_active === true ? "Active" : vendor?.is_active === false ? "Inactive" : PROFILE_NA,
            },
          ]}
        />
      </ProfileSection>

      {shouldShowPerformanceScorecardSection(tenantType) && (
        <ProfileSection title="Performance Scorecard">
          {shouldShowOverallScore(tenantType) && <ScoreBar label="Overall Score" value={vendor?.overall_score} />}
          {shouldShowOtifMetrics(tenantType) && (
            <>
              <ScoreBar label="OTIF" value={vendor?.otif_percentage} />
              <ScoreBar label="Inbound Fill Rate" value={vendor?.inbound_fill_rate} />
              <ScoreBar label="Outbound Fill Rate" value={vendor?.outbound_fill_rate} />
            </>
          )}
          {shouldShowAsnMetrics(tenantType) && (
            <>
              <ScoreBar label="ASN Timeliness" value={vendor?.asn_timeliness} />
              <ScoreBar label="ASN Essential" value={vendor?.asn_essential} />
            </>
          )}
          {shouldShowProductDamagesRate(tenantType) && (
            <div className="mt-1 flex items-center justify-between text-[13px]">
              <span className="font-medium text-neutral-700">Product damages rate</span>
              <span className={`font-bold ${damagesClass}`}>{damagesDisplay}</span>
            </div>
          )}
        </ProfileSection>
      )}

      {shouldShowContactsSection(tenantType) && (
        <ProfileSection title="Contacts">
          <div className="flex w-full min-w-0 flex-col gap-y-[9px]">
            <ProfileKVCarouselRow
              label="Buyer"
              names={buyerNames}
              index={buyerIndex}
              setIndex={setBuyerIndex}
              prevAriaLabel="Previous buyer"
              nextAriaLabel="Next buyer"
            />
            <ProfileKVCarouselRow
              label="Category managers"
              names={catMgrNames}
              index={catMgrIndex}
              setIndex={setCatMgrIndex}
              prevAriaLabel="Previous category manager"
              nextAriaLabel="Next category manager"
            />
          </div>
        </ProfileSection>
      )}
    </Card>
  );
}
