import AlertTriangleIcon from "@/assets/icons/alert-triangle-primary.svg";
import DocumentIcon from "@/assets/icons/accounting-document.svg";
import PinIcon from "@/assets/icons/pin.svg";
import CartIcon from "@/assets/icons/shopping-cart-empty.svg";
import WarehouseIcon from "@/assets/icons/warehouse-packages.svg";
import type { RiskCategorySummary } from "@/lib/riskCategoryUtils";

const MODEL_TYPE_TO_ICON: Record<string, string> = {
  base_model_operational: AlertTriangleIcon,
  base_model_market: CartIcon,
  base_model_sales: WarehouseIcon,
  base_model_regulatory: DocumentIcon,
  base_model_location: PinIcon,
};

interface RiskCategoryStripProps {
  categories: RiskCategorySummary[];
  isLoading?: boolean;
}

export function RiskCategoryStrip({ categories, isLoading }: RiskCategoryStripProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
        {[1, 2, 3, 4, 5].map(i => (
          <div key={i} className="h-14 rounded-lg border border-[#E8E8E8] bg-gray-100 animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div>
      <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-[#6E6E6E]">Risk categories</h3>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
        {categories.map(category => {
          const icon = category.icon || MODEL_TYPE_TO_ICON[category.type];
          return (
            <div key={category.type} className="flex flex-col gap-1 rounded-lg border border-[#E0E0E0] bg-white p-2.5">
              <div className="flex min-w-0 items-center gap-1.5">
                {icon ? (
                  <div className="shrink-0 rounded bg-primary-50 p-1">
                    <img src={icon} alt="" className="h-4 w-4" />
                  </div>
                ) : null}
                <p className="min-w-0 truncate text-xs font-semibold text-[#525252]" title={category.title}>
                  {category.title}
                </p>
              </div>
              <p className="text-sm font-bold tabular-nums text-[#1E1E1E]">
                {category.score}
                <span className="text-xs font-semibold text-brand-primary-700">/100</span>
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
