import type { ReactNode } from "react";
import pillIcon from "@/assets/icons/plan/pill.svg";
import type { NextPoDelivery } from "@/lib/apiServices";
import { formatApiDate } from "@/lib/dateUtils";
import { formatCurrencyCompact, formatPercentageDisplay } from "@/lib/utils";
import {
  shouldHideSupplierRiskScoreValue,
  shouldShowBuyerNotes,
  shouldShowMarketShareInHeader,
  shouldShowPoDeliveryBlock,
  shouldShowVariantDrivingRiskLabel,
} from "@/components/material-drill-through/materialDrillVisibility";
import { selectTenantPortalFlags, useTenantContextQuery } from "@/tenant";
import { RiskScoreGauge } from "./RiskScoreGauge";

interface MaterialSummaryHeaderProps {
  name: string;
  ndc?: string;
  productFamily?: string;
  category?: string;
  marketShare?: number | null;
  buyerCommentNotes?: string | null;
  nextPoDelivery?: NextPoDelivery | null;
  vendor?: string;
  vendorNbr?: string;
  riskScore: number;
  riskAdjustedValue: number;
  drivingRiskLabel?: string;
  isNewIssue?: boolean;
  actionResolved?: boolean;
  isLoading?: boolean;
  /**
   * Material-centric mode: hides the issue-framed columns (Issue Status, Action
   * Status) and uses neutral (non-alert) framing. Used by the inspect-only
   * material detail page reached from impacted materials.
   */
  hideIssueMeta?: boolean;
}

export function formatMarketShareDisplay(marketShare?: number | null): string {
  if (marketShare == null || !Number.isFinite(marketShare)) {
    return "N/A";
  }
  // API stores market_share as a 0–1 fraction; values > 1 are already whole percents.
  const percent = marketShare <= 1 ? marketShare * 100 : marketShare;
  return formatPercentageDisplay(percent, 0);
}

export function formatBuyerCommentNotes(value?: string | null): string {
  const trimmed = value?.trim();
  return trimmed ? trimmed : "N/A";
}

const PO_DELIVERY_DATE_FORMAT: Intl.DateTimeFormatOptions = {
  month: "short",
  day: "numeric",
  year: "numeric",
};

function formatPlantSegment(plant?: NextPoDelivery["plant"] | null): string | null {
  if (!plant) return null;
  const nbr = plant.plant_nbr?.trim();
  const name = plant.name?.trim();
  if (nbr && name) return `Plant ${nbr} (${name})`;
  if (nbr) return `Plant ${nbr}`;
  if (name) return name;
  return null;
}

export function formatPoDeliveryDate(date?: string | null): string {
  const trimmed = date?.trim();
  if (!trimmed) return "N/A";

  const dateDisplay = formatApiDate(trimmed, PO_DELIVERY_DATE_FORMAT);
  return dateDisplay || "N/A";
}

export function getPoDeliveryHeaderLines(nextPoDelivery?: NextPoDelivery | null): {
  plant: string | null;
  cencoraPredicted: string;
  sapAnticipated: string;
} {
  const plant = nextPoDelivery ? formatPlantSegment(nextPoDelivery.plant) : null;

  return {
    plant,
    cencoraPredicted: formatPoDeliveryDate(nextPoDelivery?.predicted_delv_date),
    sapAnticipated: formatPoDeliveryDate(nextPoDelivery?.anticipated_date),
  };
}

function MetricColumn({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs font-medium text-[#6E6E6E] whitespace-nowrap">{label}</span>
      <div className=" text-xs flex items-center ">{children}</div>
    </div>
  );
}

function ActionStatusIndicator({ resolved }: { resolved: boolean }) {
  if (resolved) {
    return (
      <div className="flex items-center gap-2">
        <div
          className="inline-flex items-center justify-center rounded-full border border-[#06C07A] bg-[#D8FEE7] p-1"
          aria-hidden
        >
          <div className="h-2 w-2 rounded-full bg-[#119D63]" />
        </div>
        <span className="text-sm font-medium text-[#119D63] whitespace-nowrap">Resolved</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <div
        className="inline-flex items-center justify-center rounded-full border border-[#E22F0054] bg-[#FEEFEB] p-1"
        aria-hidden
      >
        <div className="h-2 w-2 rounded-full bg-[#E22F00]" />
      </div>
      <span className="text-sm font-medium text-[#6E6E6E] whitespace-nowrap">Not Resolved</span>
    </div>
  );
}

function DetailSegment({ label, value }: { label: string; value: string }) {
  return (
    <span className="text-sm text-[#6E6E6E]">
      <span>{label}: </span>
      <span className="font-medium text-[#525252]">{value}</span>
    </span>
  );
}

function PoDeliverySummaryBlock({ lines }: { lines: ReturnType<typeof getPoDeliveryHeaderLines> }) {
  return (
    <div
      className="mt-2 max-w-xl rounded-lg border border-[#E2E8F0] bg-white/80 p-3 shadow-xs"
      role="group"
      aria-labelledby="po-delivery-heading"
    >
      <p id="po-delivery-heading" className="text-xs font-bold uppercase tracking-[0.04em] text-[#6E6E6E]">
        Next PO delivery
      </p>
      {lines.plant ? <p className="mt-1 text-sm font-semibold text-[#525252]">{lines.plant}</p> : null}
      <dl className={lines.plant ? "mt-2 space-y-2 border-t border-[#F0F0F0] pt-2" : "mt-1.5 space-y-2"}>
        <div className="flex flex-col gap-0.5 sm:flex-row sm:items-baseline sm:justify-between sm:gap-3">
          <dt className="text-sm text-[#6E6E6E]">Cencora Predicted PO Delivery Date</dt>
          <dd className="shrink-0 text-sm font-semibold tabular-nums text-[#525252]">{lines.cencoraPredicted}</dd>
        </div>
        <div className="flex flex-col gap-0.5 sm:flex-row sm:items-baseline sm:justify-between sm:gap-3">
          <dt className="text-sm text-[#6E6E6E]">SAP Anticipated Date</dt>
          <dd className="shrink-0 text-sm font-semibold tabular-nums text-[#525252]">{lines.sapAnticipated}</dd>
        </div>
      </dl>
    </div>
  );
}

export function MaterialSummaryHeader({
  name,
  ndc,
  productFamily,
  category,
  marketShare,
  buyerCommentNotes,
  nextPoDelivery,
  vendor,
  vendorNbr,
  riskScore,
  riskAdjustedValue,
  drivingRiskLabel,
  isNewIssue,
  actionResolved,
  isLoading,
  hideIssueMeta = false,
}: MaterialSummaryHeaderProps) {
  const { data: flags } = useTenantContextQuery(selectTenantPortalFlags);
  const tenantType = flags?.tenantType;
  const framingClass = hideIssueMeta ? "border-t-[#461E96] bg-white" : "border-t-[#E22F00] bg-[#FEEFEB7A]";

  if (isLoading) {
    return (
      <div className={`overflow-hidden rounded-[10px] border border-[#E2E8F0] border-t-[3px] p-6 animate-pulse ${framingClass}`}>
        <div className="h-28 rounded bg-[#E8E8E8]" />
      </div>
    );
  }

  const showBuyerNotes = shouldShowBuyerNotes(tenantType);
  const showPoDelivery = shouldShowPoDeliveryBlock(tenantType);
  const showDrivingRisk = shouldShowVariantDrivingRiskLabel(tenantType) && Boolean(drivingRiskLabel?.trim());
  const buyerNotesDisplay = formatBuyerCommentNotes(buyerCommentNotes);
  const buyerNotesTitle = buyerNotesDisplay !== "N/A" ? buyerNotesDisplay : undefined;
  const poDeliveryLines = getPoDeliveryHeaderLines(nextPoDelivery);

  const primaryDetailSegments = [
    ndc ? { label: "NDC", value: ndc } : null,
    productFamily ? { label: "Product Family", value: productFamily } : null,
    category ? { label: "Category", value: category } : null,
    shouldShowMarketShareInHeader(tenantType) ? { label: "Market Share", value: formatMarketShareDisplay(marketShare) } : null,
  ].filter((segment): segment is { label: string; value: string } => segment != null);

  return (
    <div className={`overflow-hidden border border-[#E2E8F0] border-t-[3px] shadow-xs ${framingClass}`}>
      <div className="flex flex-col gap-6 p-6 lg:flex-row lg:items-start lg:justify-between">
        <div className="flex min-w-0 flex-1 items-start gap-4">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-[#461E96]">
            <img src={pillIcon} alt="" className="h-7 w-7 brightness-0 invert" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="text-xl font-bold leading-tight text-[#1E1E1E] md:text-2xl">{name}</h1>
            {primaryDetailSegments.length > 0 && (
              <p className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
                {primaryDetailSegments.map((segment, index) => (
                  <span key={segment.label} className="inline-flex items-center gap-2">
                    {index > 0 && (
                      <span className="text-[#6E6E6E]" aria-hidden>
                        •
                      </span>
                    )}
                    <DetailSegment label={segment.label} value={segment.value} />
                  </span>
                ))}
              </p>
            )}
            {(vendor || vendorNbr) && (
              <p className="mt-1 text-sm text-[#6E6E6E]">
                <span>Supplier: </span>
                <span className="font-medium text-[#525252]">{vendor ?? "—"}</span>
                {vendorNbr ? <span className="font-medium text-[#525252]"> (Supplier Id: {vendorNbr})</span> : null}
              </p>
            )}
            {showDrivingRisk && (
              <p className="mt-1 text-sm text-[#6E6E6E]">
                <span>Driving Risk: </span>
                <span className="font-medium text-[#525252]">{drivingRiskLabel}</span>
              </p>
            )}
            {showBuyerNotes && (
              <p className="mt-1 min-w-0 text-sm text-[#6E6E6E]">
                <span>Buyer Notes: </span>
                <span className="font-medium wrap-break-word text-[#525252]" title={buyerNotesTitle}>
                  {buyerNotesDisplay}
                </span>
              </p>
            )}
            {showPoDelivery && <PoDeliverySummaryBlock lines={poDeliveryLines} />}
          </div>
        </div>

        <div className="flex shrink-0 justify-center lg:px-4">
          <RiskScoreGauge score={riskScore} showScoreLabel={false} hideNumericScore={shouldHideSupplierRiskScoreValue()} />
        </div>

        <div className="flex flex-col shrink-0 flex-wrap items-start gap-2">
          <MetricColumn label="Risk Adjusted Value">
            <span className="text-lg font-bold text-[#DC2626] tabular-nums">{formatCurrencyCompact(riskAdjustedValue)}</span>
          </MetricColumn>

          {!hideIssueMeta && (
            <>
              <MetricColumn label="Issue Status">
                {isNewIssue ? (
                  <span className="inline-flex items-center rounded-full border border-[#E22F0054] bg-[#FCD9D1] px-2 text-2xs font-semibold text-[#E22F00]">
                    New Issue
                  </span>
                ) : (
                  <span className="inline-flex items-center rounded-full border border-[#06C07A] bg-[#D8FEE7] px-2 text-2xs text-xs font-semibold text-[#119D63]">
                    Existing Issue
                  </span>
                )}
              </MetricColumn>

              <MetricColumn label="Action Status">
                <ActionStatusIndicator resolved={Boolean(actionResolved)} />
              </MetricColumn>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
