import type { Dispatch, ReactNode, SetStateAction } from "react";

export const PROFILE_NA = "N/A";

export function isPresent(value: unknown): boolean {
  if (value === null || value === undefined) return false;
  if (typeof value === "string" && value.trim() === "") return false;
  return true;
}

export function formatOrNA<T>(value: T | null | undefined, formatter?: (v: T) => string): string {
  if (!isPresent(value)) return PROFILE_NA;
  return formatter ? formatter(value as T) : String(value);
}

export interface ProfileKVRow {
  label: string;
  value: ReactNode;
}

/** Drops blank and "unassigned" contact names (buyers, category managers). */
export function filterProfileContactNames(list: string[] | null | undefined): string[] {
  return (list ?? []).filter(entry => {
    const trimmed = String(entry).trim();
    if (!trimmed) return false;
    if (trimmed.toLowerCase() === "unassigned") return false;
    return true;
  });
}

export function profileCarouselSafeIndex(index: number, length: number): number {
  if (length === 0) return 0;
  return index >= length ? 0 : Math.min(Math.max(0, index), length - 1);
}

function ProfileCarouselChevron({ direction }: { direction: "prev" | "next" }) {
  return (
    <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden>
      {direction === "prev" ? (
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
      ) : (
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
      )}
    </svg>
  );
}

export function ProfileKVCarouselRow({
  label,
  names,
  index,
  setIndex,
  prevAriaLabel,
  nextAriaLabel,
}: {
  label: string;
  names: string[];
  index: number;
  setIndex: Dispatch<SetStateAction<number>>;
  prevAriaLabel: string;
  nextAriaLabel: string;
}) {
  const len = names.length;
  const safeIndex = profileCarouselSafeIndex(index, len);
  const resolveStepIndex = (prev: number) => profileCarouselSafeIndex(prev, len);

  const valueContent =
    len > 1 ? (
      <div className="inline-flex max-w-full items-center justify-end gap-1.5">
        <button
          type="button"
          onClick={() => {
            setIndex(prev => {
              const i = resolveStepIndex(prev);
              return i === 0 ? len - 1 : i - 1;
            });
          }}
          className="shrink-0 rounded p-0.5 text-neutral-700 hover:bg-neutral-100"
          aria-label={prevAriaLabel}
        >
          <ProfileCarouselChevron direction="prev" />
        </button>
        <span className="min-w-0 wrap-break-word text-right">{names[safeIndex]}</span>
        <button
          type="button"
          onClick={() => {
            setIndex(prev => {
              const i = resolveStepIndex(prev);
              return i === len - 1 ? 0 : i + 1;
            });
          }}
          className="shrink-0 rounded p-0.5 text-neutral-700 hover:bg-neutral-100"
          aria-label={nextAriaLabel}
        >
          <ProfileCarouselChevron direction="next" />
        </button>
      </div>
    ) : len === 1 ? (
      <span className="wrap-break-word">{names[0]}</span>
    ) : (
      <span>{PROFILE_NA}</span>
    );

  return (
    <div className="flex w-full min-w-0 items-start gap-x-4">
      <div className="w-[42%] shrink-0 text-[13px] font-medium leading-snug text-neutral-500">{label}</div>
      <div className="min-w-0 flex-1 text-right text-[13px] font-semibold leading-snug text-neutral-900">{valueContent}</div>
    </div>
  );
}

export function resolveVendorBuyerNames(
  vendor:
    | {
        buyer_list?: string[] | null;
        buyer_name?: string | null;
      }
    | null
    | undefined
): string[] {
  const fromList = filterProfileContactNames(vendor?.buyer_list);
  if (fromList.length > 0) return fromList;
  if (isPresent(vendor?.buyer_name)) return [String(vendor!.buyer_name).trim()];
  return [];
}

export function ProfileKVList({ rows }: { rows: ProfileKVRow[] }) {
  return (
    <div className="flex w-full min-w-0 flex-col gap-y-[9px]">
      {rows.map((row, i) => (
        <div key={i} className="flex w-full min-w-0 items-start gap-x-4">
          <div className="w-[42%] shrink-0 text-[13px] font-medium leading-snug text-neutral-500">{row.label}</div>
          <div className="min-w-0 flex-1 text-right text-[13px] font-semibold leading-snug text-neutral-900 wrap-break-word">
            {row.value}
          </div>
        </div>
      ))}
    </div>
  );
}

export function ProfileSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mb-[18px] last:mb-0">
      <p className="mb-3 text-[11px] font-bold uppercase tracking-wider text-neutral-400">{title}</p>
      {children}
    </section>
  );
}

export function ProfileSkeletonLines({ rows }: { rows: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-3 w-full animate-pulse rounded bg-neutral-200" />
      ))}
    </div>
  );
}

/** Performance bar fill: higher is better (vendor scorecard). */
export function scoreBarFillClass(fraction: number): string {
  if (fraction >= 0.85) return "bg-success-500";
  if (fraction >= 0.7) return "bg-warning-500";
  return "bg-danger-500";
}

export function normalizeScoreFraction(value: number): number {
  const fraction = value > 1 ? value / 100 : value;
  return Math.max(0, Math.min(1, fraction));
}

/** Product damages: lower is better — green at ~0%, amber mid, red high. */
export function damagesRateTextClass(rate: number): string {
  const fraction = normalizeScoreFraction(rate);
  if (fraction <= 0.01) return "text-success-500";
  if (fraction <= 0.05) return "text-warning-500";
  return "text-danger-500";
}

export function resolveVendorRiskScore(riskRating: number | null | undefined): number {
  if (!isPresent(riskRating)) return 0;
  return Math.round((riskRating as number) * 100);
}

export function formatVendorLocation(vendor: { city?: string | null; state?: string | null; country?: string | null }): string {
  const city = isPresent(vendor.city) ? String(vendor.city).trim() : "";
  const state = isPresent(vendor.state) ? String(vendor.state).trim() : "";
  const country = isPresent(vendor.country) ? String(vendor.country).trim() : "";

  let locality = "";
  if (city && state && !city.includes(state)) {
    locality = `${city}, ${state}`;
  } else if (city) {
    locality = city;
  } else if (state) {
    locality = state;
  }

  if (locality && country) return `${locality} · ${country}`;
  if (locality) return locality;
  if (country) return country;
  return PROFILE_NA;
}
