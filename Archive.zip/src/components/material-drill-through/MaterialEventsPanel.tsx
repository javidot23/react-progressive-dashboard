import CardLayout from "@/components/templates/CardLayout";
import { EmptyState } from "@/components/molecules";
import { formatDrillThroughDate } from "@/lib/materialDrillThroughUtils";
import type { SupplyChainEvent } from "@/lib/apiServices";

interface MaterialEventsPanelProps {
  events: SupplyChainEvent[];
  isLoading?: boolean;
  isFetching?: boolean;
}

function formatEventLocation(event: SupplyChainEvent): string | null {
  const parts = [event.city, event.state, event.country].map(p => p?.trim()).filter(Boolean) as string[];
  return parts.length > 0 ? parts.join(", ") : null;
}

function EventRow({ event }: { event: SupplyChainEvent }) {
  const location = formatEventLocation(event);
  return (
    <div className="rounded-md border border-[#E2E8F0] bg-[#FAFAFA] p-3 transition-colors hover:border-brand-primary-100">
      <div className="mb-1 flex items-start justify-between gap-2">
        <span className="text-sm font-semibold text-[#1E1E1E]">{event.type}</span>
        <span className="rounded-full bg-[#E8E8E8] px-2 py-0.5 text-xs font-medium text-[#3B3B3B]">{event.status}</span>
      </div>
      {event.event_id ? (
        <p className="mb-1 text-xs text-[#6E6E6E]">
          <span className="font-medium text-[#525252]">Event ID: </span>
          {event.event_id}
        </p>
      ) : null}
      {event.type_description ? <p className="mb-2 text-sm text-[#6E6E6E]">{event.type_description}</p> : null}
      {location ? (
        <p className="mb-2 text-xs text-[#6E6E6E]">
          <span className="font-medium text-[#525252]">Location: </span>
          {location}
        </p>
      ) : null}
      {event.start_date ? (
        <p className="text-xs text-[#6E6E6E]">
          <span className="font-medium text-[#525252]">Start Date: </span>
          {formatDrillThroughDate(event.start_date)}
          {event.end_date ? (
            <>
              {" "}
              <span className="font-medium text-[#525252]">End Date: </span>
              {formatDrillThroughDate(event.end_date)}
            </>
          ) : (event.status ?? "").toUpperCase() !== "CLOSED" ? (
            <> · Ongoing</>
          ) : null}
        </p>
      ) : null}
    </div>
  );
}

/** Lists a material's own supply-chain events (material-scoped), for the material detail Risk tab. */
export function MaterialEventsPanel({ events, isLoading, isFetching }: MaterialEventsPanelProps) {
  return (
    <CardLayout title="Supply Chain Events" className="flex h-full flex-col">
      <div className="min-h-[120px] flex-1 space-y-3 overflow-y-auto max-h-[420px]">
        {isLoading ? (
          <div className="h-24 animate-pulse rounded-md bg-gray-100" />
        ) : events.length === 0 ? (
          <EmptyState
            title="No supply chain events"
            description="This material is not linked to any open supply chain events."
          />
        ) : (
          <div className={isFetching ? "space-y-3 opacity-70 transition-opacity" : "space-y-3"}>
            {events.map(event => (
              <EventRow key={event.id} event={event} />
            ))}
          </div>
        )}
      </div>
    </CardLayout>
  );
}

export default MaterialEventsPanel;
