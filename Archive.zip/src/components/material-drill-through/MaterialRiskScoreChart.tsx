import { useMemo } from "react";
import { Area, AreaChart, CartesianGrid, Label, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import CardLayout from "@/components/templates/CardLayout";
import type { MaterialRiskWeeklyAveragesResponse } from "@/lib/apiServices";
import { formatChartDate } from "@/lib/materialDrillThroughUtils";
import { EmptyState } from "@/components/molecules";

const CHART_MARGIN = { top: 20, right: 110, left: 10, bottom: 20 };
const HIGH_THRESHOLD = 81;
const LIKELY_THRESHOLD = 61;

interface MaterialRiskScoreChartProps {
  weeklyData: MaterialRiskWeeklyAveragesResponse["data"] | null;
  isLoading?: boolean;
}

interface ChartPoint {
  label: string;
  score: number;
}

function buildChartPoints(weeklyData: MaterialRiskWeeklyAveragesResponse["data"] | null): ChartPoint[] {
  const trendPoints = weeklyData?.trend?.points;
  if (trendPoints && trendPoints.length > 0) {
    return trendPoints.map(point => {
      const raw = point.metrics?.avg_risk_score ?? point.metrics?.risk_score ?? point.value;
      const score = typeof raw === "number" ? Math.round(raw * (raw <= 1 ? 100 : 1)) : 0;
      return {
        label: formatChartDate(point.period_start ?? point.period_end),
        score,
      };
    });
  }

  if (weeklyData) {
    const thisWeek = weeklyData.kpi_value ?? weeklyData.average_risk_score_this_week ?? 0;
    const lastWeek = weeklyData.kpi_previous_value ?? weeklyData.average_risk_score_last_week ?? 0;
    const toScore = (v: number) => Math.round(v * (v <= 1 ? 100 : 1));
    return [
      { label: "Last week", score: toScore(lastWeek) },
      { label: "This week", score: toScore(thisWeek) },
    ];
  }

  return [];
}

export function MaterialRiskScoreChart({ weeklyData, isLoading }: MaterialRiskScoreChartProps) {
  const chartData = useMemo(() => buildChartPoints(weeklyData), [weeklyData]);

  return (
    <CardLayout title="Risk Score - Last 90 Days">
      {isLoading ? (
        <div className="h-[320px] bg-gray-100 rounded animate-pulse" />
      ) : chartData.length === 0 ? (
        <EmptyState title="No trend data" description="Weekly risk score history is not available for this material." />
      ) : (
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={chartData} margin={CHART_MARGIN}>
            <defs>
              <linearGradient id="riskScoreGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#dc2626" stopOpacity={0.25} />
                <stop offset="100%" stopColor="#dc2626" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
            <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: "#6E6E6E", fontSize: 12 }} />
            <YAxis
              domain={[0, 100]}
              ticks={[0, 20, 40, 60, 80, 100]}
              axisLine={false}
              tickLine={false}
              tick={{ fill: "#6E6E6E", fontSize: 12 }}
            />
            <Tooltip
              formatter={(value: number) => [`${value}`, "Risk Score"]}
              contentStyle={{ borderRadius: 8, border: "1px solid #E2E8F0" }}
            />
            <ReferenceLine y={HIGH_THRESHOLD} stroke="#dc2626" strokeDasharray="6 4" strokeWidth={1.5}>
              <Label value={`${HIGH_THRESHOLD} - Highly Likely`} position="right" fill="#dc2626" fontSize={11} />
            </ReferenceLine>
            <ReferenceLine y={LIKELY_THRESHOLD} stroke="#FFA400" strokeDasharray="6 4" strokeWidth={1.5}>
              <Label value={`${LIKELY_THRESHOLD} - Likely`} position="right" fill="#FFA400" fontSize={11} />
            </ReferenceLine>
            <Area
              type="monotone"
              dataKey="score"
              stroke="#dc2626"
              strokeWidth={2.5}
              fill="url(#riskScoreGradient)"
              dot={{ r: 4, fill: "#dc2626", strokeWidth: 0 }}
              activeDot={{ r: 6 }}
              label={{ position: "top", fill: "#1E1E1E", fontSize: 11, fontWeight: 600 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      )}
    </CardLayout>
  );
}
