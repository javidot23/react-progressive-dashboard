import {
  isFullFeatureSet,
  isCustomerPortal,
  isCustomerVendorPortal,
  isVariantFamily,
  isVendorPortal,
} from "@/tenant";

/** Placeholder for fields hidden from downstream variant portal users. */
export const MASKED_VALUE = "—";

export function isMaterialDrillVariantUpstream(): boolean {
  return isVendorPortal() || isCustomerVendorPortal();
}

export function isMaterialDrillVariantDownstream(): boolean {
  return isCustomerPortal();
}

/** Stratium and variant upstream only; hidden entirely for variant portal customer (downstream). */
export function shouldShowPoDeliveryBlock(): boolean {
  return isFullFeatureSet() || isMaterialDrillVariantUpstream();
}

export function shouldHideSupplierRiskScoreValue(): boolean {
  return isVariantFamily();
}

export function shouldShowScrmHeaderAttributes(): boolean {
  return isFullFeatureSet();
}

export function shouldShowVariantDrivingRiskLabel(): boolean {
  return isVariantFamily();
}

export function shouldShowMarketShareInHeader(): boolean {
  return isFullFeatureSet();
}

export function shouldShowBuyerNotes(): boolean {
  return isFullFeatureSet();
}

export function shouldShowInventoryQuantityRows(): boolean {
  return !isMaterialDrillVariantDownstream();
}

export function shouldShowMarketShareInProfile(): boolean {
  return !isVariantFamily();
}

export function shouldShowCostPerUnit(): boolean {
  return !isMaterialDrillVariantDownstream();
}

export function shouldShowMaterialExposureFields(): boolean {
  return !isMaterialDrillVariantDownstream();
}

export function shouldShowFeeForService(): boolean {
  return isFullFeatureSet();
}

export function shouldShowDqsaChip(): boolean {
  return !isMaterialDrillVariantDownstream();
}

export function shouldShowFormularySection(): boolean {
  return !isMaterialDrillVariantDownstream();
}

export function shouldShowManufacturerAvailability(): boolean {
  return !isMaterialDrillVariantDownstream();
}

export function shouldShowPerformanceScorecardSection(): boolean {
  return isFullFeatureSet() || isMaterialDrillVariantUpstream();
}

export function shouldShowOverallScore(): boolean {
  return false;
}

export function shouldShowOtifMetrics(): boolean {
  return isFullFeatureSet();
}

export function shouldShowAsnMetrics(): boolean {
  return isFullFeatureSet() || isMaterialDrillVariantUpstream();
}

export function shouldShowProductDamagesRate(): boolean {
  return isFullFeatureSet() || isMaterialDrillVariantUpstream();
}

export function shouldShowContactsSection(): boolean {
  return isFullFeatureSet() || isMaterialDrillVariantUpstream();
}
