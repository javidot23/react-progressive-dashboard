import { type TenantType } from "@/tenant";

/** Placeholder for fields hidden from downstream portal users. */
export const MASKED_VALUE = "—";

export function isMaterialDrillVariantUpstream(type?: TenantType): boolean {
  return type === "vendor" || type === "customer_vendor";
}

export function isMaterialDrillVariantDownstream(type?: TenantType): boolean {
  return type === "customer";
}

export function shouldShowPoDeliveryBlock(type?: TenantType): boolean {
  return isMaterialDrillVariantUpstream(type);
}

export function shouldHideSupplierRiskScoreValue(_type?: TenantType): boolean {
  return true;
}

export function shouldShowScrmHeaderAttributes(_type?: TenantType): boolean {
  return false;
}

export function shouldShowVariantDrivingRiskLabel(_type?: TenantType): boolean {
  return true;
}

export function shouldShowMarketShareInHeader(_type?: TenantType): boolean {
  return false;
}

export function shouldShowBuyerNotes(_type?: TenantType): boolean {
  return false;
}

export function shouldShowInventoryQuantityRows(type?: TenantType): boolean {
  return !isMaterialDrillVariantDownstream(type);
}

export function shouldShowMarketShareInProfile(_type?: TenantType): boolean {
  return false;
}

export function shouldShowCostPerUnit(type?: TenantType): boolean {
  return !isMaterialDrillVariantDownstream(type);
}

export function shouldShowMaterialExposureFields(type?: TenantType): boolean {
  return !isMaterialDrillVariantDownstream(type);
}

export function shouldShowFeeForService(_type?: TenantType): boolean {
  return false;
}

export function shouldShowDqsaChip(type?: TenantType): boolean {
  return !isMaterialDrillVariantDownstream(type);
}

export function shouldShowFormularySection(type?: TenantType): boolean {
  return !isMaterialDrillVariantDownstream(type);
}

export function shouldShowManufacturerAvailability(type?: TenantType): boolean {
  return !isMaterialDrillVariantDownstream(type);
}

export function shouldShowPerformanceScorecardSection(type?: TenantType): boolean {
  return isMaterialDrillVariantUpstream(type);
}

export function shouldShowOverallScore(_type?: TenantType): boolean {
  return false;
}

export function shouldShowOtifMetrics(_type?: TenantType): boolean {
  return false;
}

export function shouldShowAsnMetrics(type?: TenantType): boolean {
  return isMaterialDrillVariantUpstream(type);
}

export function shouldShowProductDamagesRate(type?: TenantType): boolean {
  return isMaterialDrillVariantUpstream(type);
}

export function shouldShowContactsSection(type?: TenantType): boolean {
  return isMaterialDrillVariantUpstream(type);
}
