import { useMemo } from "react";
import CardLayout from "@/components/templates/CardLayout";
import { EmptyState } from "@/components/molecules";
import { RiskBadge } from "@/components/atoms/RiskBadge";
import { cn, getRiskRatingColors } from "@/lib/utils";
import { type DrivingRiskTimelineItem } from "@/lib/materialDrillThroughUtils";
import {
  buildContributorTimeline,
  buildRiskCategorySummaries,
  type EnrichedMaterialRiskRow,
} from "@/lib/riskCategoryUtils";
import { useRiskModelDescriptions } from "@/hooks";
import { RiskCategoryStrip } from "./RiskCategoryStrip";
import AlertTriangleIcon from "@/assets/icons/alert-triangle-primary.svg";

interface DrivingRiskEventsTimelineProps {
  riskData: EnrichedMaterialRiskRow[];
  isLoading?: boolean;
}

/** Matches RiskBadge / Overview: Highly Likely band */
function isHighlyLikelyRisk(riskRating: number): boolean {
  return riskRating >= 0.81 && riskRating <= 1.0;
}

function TimelineDot({ riskRating }: { riskRating: number }) {
  const { verticalLineClass, labelBackgroundClass } = getRiskRatingColors(riskRating);
  return (
    <span
      className={cn(
        "relative z-10 inline-flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full",
        labelBackgroundClass
      )}
      aria-hidden
    >
      <span className={cn("h-2 w-2 shrink-0 rounded-full", verticalLineClass)} />
    </span>
  );
}

function ContributorTimelineList({ items }: { items: DrivingRiskTimelineItem[] }) {
  if (items.length === 0) {
    return (
      <EmptyState
        title="No contributing factors"
        description="No individual risk models are driving this material beyond the category scores above."
      />
    );
  }

  return (
    <div className="relative">
      <div
        className="pointer-events-none absolute bottom-2 top-2 left-[10px] w-px bg-[#E2E8F0]"
        aria-hidden
      />
      <ol className="relative space-y-8">
        {items.map(item => (
          <li
            key={`${item.id}-${item.statusDate ?? ""}`}
            className="grid grid-cols-[20px_1fr] items-start gap-x-3 gap-y-0"
          >
            <div className="flex justify-center pt-1.5">
              <TimelineDot riskRating={item.riskRating} />
            </div>

            <div
              className={cn(
                "flex flex-col gap-2 rounded-[8px] border p-4",
                isHighlyLikelyRisk(item.riskRating)
                  ? "border-[#FECACA] bg-[#FEF2F2]"
                  : "border-[#E8E8E8] bg-[#F5F5F540]"
              )}
            >
              <h4 className="text-sm font-semibold leading-snug text-[#1E1E1E]">{item.riskTypeLabel}</h4>
              {item.description ? (
                <p className="text-xs leading-snug text-[#6E6E6E]">{item.description}</p>
              ) : null}
              <div className="flex shrink-0 pt-0.5">
                <RiskBadge riskRating={item.riskRating} showIcon size="xs" />
              </div>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}

export function DrivingRiskEventsTimeline({ riskData, isLoading }: DrivingRiskEventsTimelineProps) {
  const { riskCategoryTypes } = useRiskModelDescriptions();

  const categories = useMemo(
    () =>
      buildRiskCategorySummaries(riskData, riskCategoryTypes, {
        defaultIcon: AlertTriangleIcon,
      }),
    [riskData, riskCategoryTypes]
  );

  const contributorItems = useMemo(() => buildContributorTimeline(riskData), [riskData]);

  const showEmpty = !isLoading && riskData.length === 0;

  return (
    <CardLayout title="Driving Risks" className="h-full">
      <div className="max-h-[500px] space-y-5 overflow-y-auto pr-1">
        {isLoading ? (
          <div className="space-y-5">
            <RiskCategoryStrip categories={[]} isLoading />
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-24 rounded-[10px] bg-gray-100 animate-pulse" />
              ))}
            </div>
          </div>
        ) : showEmpty ? (
          <EmptyState title="No risk events" description="No driving risk data is available for this material." />
        ) : (
          <>
            <RiskCategoryStrip categories={categories} />
            <div>
              <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-[#6E6E6E]">
                Contributing factors
              </h3>
              <ContributorTimelineList items={contributorItems} />
            </div>
          </>
        )}
      </div>
    </CardLayout>
  );
}
