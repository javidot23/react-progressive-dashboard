import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import { ActionHistoryPanel } from "@/components/material-drill-through/ActionHistoryPanel";
import type { UserAction } from "@/lib/apiServices";

jest.mock("@/components/templates/CardLayout", () => ({
  __esModule: true,
  default: ({ title, children }: { title?: string; children: React.ReactNode }) => (
    <div>
      <h2>{title}</h2>
      {children}
    </div>
  ),
}));

jest.mock("@/components/atoms", () => ({
  Pagination: () => null,
}));

jest.mock("@/components/molecules", () => ({
  EmptyState: ({ title }: { title: string }) => <div>{title}</div>,
}));

jest.mock("@/components/atoms/Tooltip", () => ({
  __esModule: true,
  default: ({ children, content }: { children: React.ReactNode; content: React.ReactNode }) => (
    <div>
      <div data-testid="tooltip-content">{content}</div>
      {children}
    </div>
  ),
}));

const actionWithDetails: UserAction = {
  id: 9,
  issue_nbr: "ISS-9",
  user_id: "u1",
  user: { id: "u1", first_name: "Jane", last_name: "Doe" },
  created_at: "2026-05-19T09:00:00Z",
  updated_at: "2026-05-19T09:00:00Z",
  potential_action: null,
  action: "no_action",
  substituted_material: null,
  material_number: "MAT-9",
  material_name: "Example",
  vendor_name: "Vendor",
  material_context: {
    material_dollars_at_risk: 50000,
    material_risk_rating: 0.8,
  },
  decision_feedback: {
    decision_rationale: "Monitoring supplier performance.",
  },
};

describe("ActionHistoryPanel", () => {
  it("shows action details in hover tooltip content", () => {
    render(<ActionHistoryPanel actions={[actionWithDetails]} total={1} currentPage={1} pageSize={10} onPageChange={jest.fn()} />);

    const tooltip = screen.getByTestId("tooltip-content");
    expect(tooltip).toHaveTextContent("Material at risk value:");
    expect(tooltip).toHaveTextContent("Risk score:");
    expect(tooltip).toHaveTextContent("80 / 100");
    expect(tooltip).toHaveTextContent("Decision rationale:");
    expect(tooltip).toHaveTextContent("Monitoring supplier performance.");
  });
});
