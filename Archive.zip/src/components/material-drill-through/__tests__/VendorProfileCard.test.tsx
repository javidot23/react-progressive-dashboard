import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { VendorProfileCard } from "@/components/material-drill-through/VendorProfileCard";

jest.mock("@/components/material-drill-through/RiskScoreGauge", () => ({
  RiskScoreGauge: ({
    score,
    hideNumericScore,
  }: {
    score: number;
    hideNumericScore?: boolean;
  }) => (
    <div data-testid="risk-score-gauge" data-hide-numeric={hideNumericScore ? "true" : "false"}>
      {hideNumericScore ? null : score}
    </div>
  ),
}));

type GlobalWithTenant = typeof globalThis & { __TENANT__: string };

function setTenant(tenant: string) {
  (global as GlobalWithTenant).__TENANT__ = tenant;
}

const baseVendor = {
  id: 1,
  vendor_nbr: "50003854",
  name: "Cipla USA, Inc.",
  vendor_parent_name: "Cipla Limited",
  city: "Warren",
  state: "NJ",
  country: "USA",
  risk_rating: 0.46,
  overall_score: 0.9076,
  product_damages_rate: 0,
  cat_mgr_list: ["Cindy Dorzinski", "Unassigned"],
  is_active: true,
};

describe("VendorProfileCard", () => {
  afterEach(() => {
    setTenant("stratium");
  });

  it("shows skeleton while loading", () => {
    const { container } = render(<VendorProfileCard isLoading />);
    expect(container.querySelector(".animate-pulse")).toBeInTheDocument();
    expect(screen.queryByText("Supplier Profile")).not.toBeInTheDocument();
  });

  it("renders profile with gauge and location when vendor is present", () => {
    render(<VendorProfileCard vendor={baseVendor} />);

    expect(screen.getByText("Supplier Profile")).toBeInTheDocument();
    expect(screen.getByText("Warren, NJ · USA")).toBeInTheDocument();
    expect(screen.getByTestId("risk-score-gauge")).toHaveTextContent("46");
    expect(screen.getByText("Cindy Dorzinski")).toBeInTheDocument();
    expect(screen.queryByText("Unassigned")).not.toBeInTheDocument();
  });

  it("renders N/A rows and zero risk gauge when vendor is missing after load", () => {
    render(<VendorProfileCard vendor={null} isLoading={false} />);

    expect(screen.getByText("Supplier Profile")).toBeInTheDocument();
    expect(screen.getByTestId("risk-score-gauge")).toHaveTextContent("0");
    expect(screen.getAllByText("N/A").length).toBeGreaterThan(0);
    expect(document.querySelector(".animate-pulse")).not.toBeInTheDocument();
  });

  it("shows risk gauge when risk_rating is null", () => {
    render(
      <VendorProfileCard
        vendor={{ ...baseVendor, risk_rating: null, name: "Acme" }}
      />
    );
    expect(screen.getByTestId("risk-score-gauge")).toHaveTextContent("0");
  });

  it("cycles buyers with prev/next when buyer_list has multiple entries", async () => {
    const user = userEvent.setup();
    render(
      <VendorProfileCard
        vendor={{
          ...baseVendor,
          buyer_list: ["Alice Buyer", "Bob Buyer"],
          buyer_name: "Legacy Name",
        }}
      />
    );

    expect(screen.getByText("Alice Buyer")).toBeInTheDocument();
    expect(screen.queryByText("Bob Buyer")).not.toBeInTheDocument();

    await user.click(screen.getByRole("button", { name: "Next buyer" }));
    expect(screen.getByText("Bob Buyer")).toBeInTheDocument();

    await user.click(screen.getByRole("button", { name: "Previous buyer" }));
    expect(screen.getByText("Alice Buyer")).toBeInTheDocument();
  });

  it("cycles category managers with prev/next when multiple are present", async () => {
    const user = userEvent.setup();
    render(
      <VendorProfileCard
        vendor={{
          ...baseVendor,
          cat_mgr_list: ["Cindy Dorzinski", "Dan Manager"],
        }}
      />
    );

    expect(screen.getByText("Cindy Dorzinski")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Next category manager" })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Next buyer" })).not.toBeInTheDocument();

    await user.click(screen.getByRole("button", { name: "Next category manager" }));
    expect(screen.getByText("Dan Manager")).toBeInTheDocument();
  });

  it("hides category manager carousel controls when only one manager", () => {
    render(
      <VendorProfileCard vendor={{ ...baseVendor, cat_mgr_list: ["Solo Manager"] }} />
    );
    expect(screen.getByText("Solo Manager")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Next category manager" })).not.toBeInTheDocument();
  });

  it("falls back to buyer_name when buyer_list is empty", () => {
    render(
      <VendorProfileCard
        vendor={{ ...baseVendor, buyer_list: [], buyer_name: "Connie Lambert" }}
      />
    );
    expect(screen.getByText("Connie Lambert")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Next buyer" })).not.toBeInTheDocument();
  });

  it("hides numeric score on gauge for variant portal", () => {
    setTenant("stratium.vendor");
    render(<VendorProfileCard vendor={baseVendor} />);

    expect(screen.getByTestId("risk-score-gauge")).toHaveAttribute("data-hide-numeric", "true");
    expect(screen.getByTestId("risk-score-gauge")).toHaveTextContent("");
  });

  it("customer portal hides performance scorecard and contacts", () => {
    setTenant("stratium.customer");
    render(<VendorProfileCard vendor={baseVendor} />);

    expect(screen.queryByText("Performance Scorecard")).not.toBeInTheDocument();
    expect(screen.queryByText("OTIF")).not.toBeInTheDocument();
    expect(screen.queryByText("Inbound Fill Rate")).not.toBeInTheDocument();
    expect(screen.queryByText("ASN Timeliness")).not.toBeInTheDocument();
    expect(screen.queryByText("Product damages rate")).not.toBeInTheDocument();
    expect(screen.queryByText("Contacts")).not.toBeInTheDocument();
  });

  it("variant upstream shows ASN and product damages, hides OTIF", () => {
    setTenant("stratium.vendor");
    render(<VendorProfileCard vendor={baseVendor} />);

    expect(screen.getByText("ASN Timeliness")).toBeInTheDocument();
    expect(screen.getByText("Product damages rate")).toBeInTheDocument();
    expect(screen.queryByText("OTIF")).not.toBeInTheDocument();
    expect(screen.getByText("Contacts")).toBeInTheDocument();
  });
});
