import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import { DrivingRiskEventsTimeline } from "@/components/material-drill-through/DrivingRiskEventsTimeline";
import type { EnrichedMaterialRiskRow } from "@/lib/riskCategoryUtils";

jest.mock("@/components/templates/CardLayout", () => ({
  __esModule: true,
  default: ({ title, children }: { title?: string; children: React.ReactNode }) => (
    <div>
      <h2>{title}</h2>
      {children}
    </div>
  ),
}));

jest.mock("@/components/molecules", () => ({
  EmptyState: ({ title }: { title: string }) => <div>{title}</div>,
}));

jest.mock("@/components/atoms/RiskBadge", () => ({
  RiskBadge: () => <span data-testid="risk-badge" />,
}));

jest.mock("@/hooks", () => ({
  useRiskModelDescriptions: () => ({
    riskCategoryTypes: [
      { type: "base_model_operational", title: "Operational Risk" },
      { type: "base_model_market", title: "Market Risk" },
      { type: "base_model_sales", title: "Sales Risk" },
      { type: "base_model_regulatory", title: "Regulatory Risk" },
      { type: "base_model_location", title: "Location Risk" },
    ],
  }),
}));

function contributorRow(overrides: Partial<EnrichedMaterialRiskRow> = {}): EnrichedMaterialRiskRow {
  return {
    id: 1,
    risk_type: "base_model_operational",
    original_risk_type: "forecast_error_model",
    risk_rating: 0.85,
    time_horizon: 30,
    created_at: "2026-01-10",
    updated_at: "2026-01-10",
    material: 1,
    risk_description: "Elevated lead time risk",
    display_name: "Supply disruption",
    status_date: "2026-01-10",
    ...overrides,
  };
}

describe("DrivingRiskEventsTimeline", () => {
  it("uses Driving Risks as the card title", () => {
    render(<DrivingRiskEventsTimeline riskData={[contributorRow()]} />);
    expect(screen.getByRole("heading", { name: "Driving Risks" })).toBeInTheDocument();
  });

  it("renders risk categories and contributing factors sections", () => {
    render(
      <DrivingRiskEventsTimeline
        riskData={[
          contributorRow(),
          contributorRow({
            id: 2,
            original_risk_type: "category_risk_operational",
            risk_type: "category_risk_group",
            display_name: "Operational Risk",
            risk_rating: 0.7,
          }),
        ]}
      />
    );

    expect(screen.getByText("Risk categories")).toBeInTheDocument();
    expect(screen.getByText("Contributing factors")).toBeInTheDocument();
    expect(screen.getByText("Supply disruption")).toBeInTheDocument();
    expect(screen.getAllByText("Operational Risk").length).toBe(1);
  });

  it("does not render time horizon", () => {
    render(<DrivingRiskEventsTimeline riskData={[contributorRow()]} />);
    expect(screen.queryByText(/Time horizon/i)).not.toBeInTheDocument();
  });
});
