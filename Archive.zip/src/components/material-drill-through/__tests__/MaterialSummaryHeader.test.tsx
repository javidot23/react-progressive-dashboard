import "@testing-library/jest-dom";
import { render, screen, within } from "@testing-library/react";
import {
  MaterialSummaryHeader,
  formatBuyerCommentNotes,
  formatMarketShareDisplay,
  formatPoDeliveryDate,
  getPoDeliveryHeaderLines,
} from "@/components/material-drill-through/MaterialSummaryHeader";
import { getTenantPortalFlags } from "@/tenant";
const vendorPortalFlags = getTenantPortalFlags("vendor");

// MaterialSummaryHeader reads tenantType from useTenantContextQuery(selectTenantPortalFlags);
// mock it so the component doesn't need an AuthProvider/QueryClientProvider in this unit test.
jest.mock("@/tenant", () => ({
  ...jest.requireActual("@/tenant"),
  useTenantContextQuery: jest.fn(),
}));
const { useTenantContextQuery } = jest.requireMock("@/tenant");
(useTenantContextQuery as jest.Mock).mockReturnValue({ data: vendorPortalFlags });

jest.mock("@/components/material-drill-through/RiskScoreGauge", () => ({
  RiskScoreGauge: ({ hideNumericScore }: { hideNumericScore?: boolean }) => (
    <div data-testid="risk-score-gauge" data-hide-numeric={hideNumericScore ? "true" : "false"} />
  ),
}));

const defaultProps = {
  name: "Four Cream",
  riskScore: 100,
  riskAdjustedValue: 99926,
};

describe("formatMarketShareDisplay", () => {
  it("formats whole-number market share as a percentage", () => {
    expect(formatMarketShareDisplay(73.4)).toBe("73%");
  });

  it("scales 0–1 fractional market share to a percentage", () => {
    expect(formatMarketShareDisplay(0.734)).toBe("73%");
    expect(formatMarketShareDisplay(0.15)).toBe("15%");
  });

  it("returns N/A for null or non-finite market share", () => {
    expect(formatMarketShareDisplay(null)).toBe("N/A");
    expect(formatMarketShareDisplay(undefined)).toBe("N/A");
  });
});

describe("formatBuyerCommentNotes", () => {
  it("returns trimmed note text when present", () => {
    expect(formatBuyerCommentNotes("Short note")).toBe("Short note");
  });

  it("returns N/A for null, empty, or whitespace-only values", () => {
    expect(formatBuyerCommentNotes(null)).toBe("N/A");
    expect(formatBuyerCommentNotes(undefined)).toBe("N/A");
    expect(formatBuyerCommentNotes("")).toBe("N/A");
    expect(formatBuyerCommentNotes("   ")).toBe("N/A");
  });
});

describe("formatPoDeliveryDate", () => {
  it("formats YYYY-MM-DD API dates", () => {
    expect(formatPoDeliveryDate("2026-06-09")).toBe("Jun 9, 2026");
    expect(formatPoDeliveryDate("2026-07-01")).toBe("Jul 1, 2026");
  });

  it("returns N/A for null, empty, or invalid dates", () => {
    expect(formatPoDeliveryDate(null)).toBe("N/A");
    expect(formatPoDeliveryDate(undefined)).toBe("N/A");
    expect(formatPoDeliveryDate("")).toBe("N/A");
    expect(formatPoDeliveryDate("   ")).toBe("N/A");
    expect(formatPoDeliveryDate("not-a-date")).toBe("N/A");
  });
});

describe("getPoDeliveryHeaderLines", () => {
  it("returns plant and both dates when all fields are present", () => {
    expect(
      getPoDeliveryHeaderLines({
        predicted_delv_date: "2026-06-09",
        anticipated_date: "2026-06-12",
        plant: { plant_nbr: "341", name: "Plant-UVQHI" },
      })
    ).toEqual({
      plant: "Plant 341 (Plant-UVQHI)",
      cencoraPredicted: "Jun 9, 2026",
      sapAnticipated: "Jun 12, 2026",
    });
  });

  it("returns N/A for missing date fields independently", () => {
    expect(
      getPoDeliveryHeaderLines({
        predicted_delv_date: "2026-07-01",
        plant: { plant_nbr: "862", name: "Plant-3TZ9P" },
      })
    ).toEqual({
      plant: "Plant 862 (Plant-3TZ9P)",
      cencoraPredicted: "Jul 1, 2026",
      sapAnticipated: "N/A",
    });

    expect(
      getPoDeliveryHeaderLines({
        anticipated_date: "2026-07-15",
        plant: { plant_nbr: "862", name: "Plant-3TZ9P" },
      })
    ).toEqual({
      plant: "Plant 862 (Plant-3TZ9P)",
      cencoraPredicted: "N/A",
      sapAnticipated: "Jul 15, 2026",
    });
  });

  it("omits plant when plant segment is empty", () => {
    expect(
      getPoDeliveryHeaderLines({
        predicted_delv_date: "2026-07-01",
        anticipated_date: "2026-07-15",
        plant: { plant_nbr: "", name: "" },
      })
    ).toEqual({
      plant: null,
      cencoraPredicted: "Jul 1, 2026",
      sapAnticipated: "Jul 15, 2026",
    });
  });

  it("returns N/A dates and no plant when payload is null", () => {
    expect(getPoDeliveryHeaderLines(null)).toEqual({
      plant: null,
      cencoraPredicted: "N/A",
      sapAnticipated: "N/A",
    });
    expect(getPoDeliveryHeaderLines(undefined)).toEqual({
      plant: null,
      cencoraPredicted: "N/A",
      sapAnticipated: "N/A",
    });
  });
});

describe("MaterialSummaryHeader", () => {
  it("never shows market share in the detail bullets (Stratium-only, forced off)", () => {
    render(<MaterialSummaryHeader {...defaultProps} marketShare={73.4} />);

    expect(screen.queryByText(/Market Share:/)).not.toBeInTheDocument();
  });

  it("shows the issue-framed columns by default", () => {
    render(<MaterialSummaryHeader {...defaultProps} isNewIssue={false} />);
    expect(screen.getByText("Issue Status")).toBeInTheDocument();
    expect(screen.getByText("Action Status")).toBeInTheDocument();
  });

  it("hides the issue-framed columns in material-centric mode", () => {
    render(<MaterialSummaryHeader {...defaultProps} hideIssueMeta />);
    expect(screen.queryByText("Issue Status")).not.toBeInTheDocument();
    expect(screen.queryByText("Action Status")).not.toBeInTheDocument();
    expect(screen.queryByText("Existing Issue")).not.toBeInTheDocument();
    // Material-relevant metric stays.
    expect(screen.getByText("Risk Adjusted Value")).toBeInTheDocument();
  });

  it("still exposes fractional market share (0–1) formatting via the helper", () => {
    expect(formatMarketShareDisplay(0.734)).toBe("73%");
    expect(formatMarketShareDisplay(0)).toBe("0%");
  });

  it("never shows market share regardless of value (Stratium-only, forced off)", () => {
    render(<MaterialSummaryHeader {...defaultProps} marketShare={null} />);
    expect(screen.queryByText(/Market Share:/)).not.toBeInTheDocument();
  });

  it("never shows buyer notes (Stratium-only, forced off)", () => {
    render(<MaterialSummaryHeader {...defaultProps} buyerCommentNotes="Short note" />);

    expect(screen.queryByText(/Buyer Notes:/)).not.toBeInTheDocument();
    expect(screen.queryByText("Short note")).not.toBeInTheDocument();
  });

  it("shows Cencora and SAP PO delivery dates with plant when provided", () => {
    render(
      <MaterialSummaryHeader
        {...defaultProps}
        nextPoDelivery={{
          predicted_delv_date: "2026-06-09",
          anticipated_date: "2026-06-12",
          plant: { plant_nbr: "341", name: "Plant-UVQHI" },
        }}
      />
    );

    expect(screen.getByRole("group", { name: "Next PO delivery" })).toBeInTheDocument();
    expect(screen.getByText("Plant 341 (Plant-UVQHI)")).toBeInTheDocument();
    expect(screen.getByText("Cencora Predicted PO Delivery Date")).toBeInTheDocument();
    expect(screen.getByText("SAP Anticipated Date")).toBeInTheDocument();
    expect(screen.getByText("Jun 9, 2026")).toBeInTheDocument();
    expect(screen.getByText("Jun 12, 2026")).toBeInTheDocument();
  });

  it("shows N/A for both dates when next_po_delivery is missing", () => {
    render(<MaterialSummaryHeader {...defaultProps} nextPoDelivery={null} />);

    const poBlock = screen.getByRole("group", { name: "Next PO delivery" });
    expect(poBlock).toHaveTextContent("Cencora Predicted PO Delivery Date");
    expect(poBlock).toHaveTextContent("SAP Anticipated Date");
    expect(within(poBlock).getAllByText("N/A")).toHaveLength(2);

    expect(screen.queryByText(/^Plant /)).not.toBeInTheDocument();
  });

  it("shows supplier row but never a buyer notes row (Stratium-only, forced off)", () => {
    render(<MaterialSummaryHeader {...defaultProps} vendor="Reyes Group" vendorNbr="7803933680" buyerCommentNotes={null} />);

    expect(screen.getByText(/Supplier:/)).toBeInTheDocument();
    expect(screen.queryByText(/Buyer Notes:/)).not.toBeInTheDocument();
  });

  it("hides the numeric score on the material risk gauge (Stratium-only, forced off)", () => {
    render(<MaterialSummaryHeader {...defaultProps} riskScore={87} />);

    expect(screen.getByTestId("risk-score-gauge")).toHaveAttribute("data-hide-numeric", "true");
  });
});
