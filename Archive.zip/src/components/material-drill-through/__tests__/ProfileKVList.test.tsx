import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import { ProfileKVList } from "@/components/material-drill-through/profileCardShared";

describe("ProfileKVList", () => {
  it("aligns all rows label left and value right on the same row", () => {
    const { container } = render(
      <ProfileKVList
        rows={[
          { label: "Buyer", value: "Connie Lambert" },
          {
            label: "Category managers",
            value: "Alice Smith, Bob Jones",
          },
          {
            label: "Therapy class",
            value: "Antihyperglycemic · Incretin Mimetic",
          },
        ]}
      />
    );

    const rows = container.querySelectorAll(".flex.w-full.min-w-0.items-start");
    expect(rows).toHaveLength(3);

    const buyerValue = screen.getByText("Connie Lambert");
    expect(buyerValue).toHaveClass("text-right");
    expect(buyerValue).toHaveClass("flex-1");
    expect(buyerValue).not.toHaveClass("text-left");

    const managersValue = screen.getByText("Alice Smith, Bob Jones");
    expect(managersValue).toHaveClass("text-right");
    expect(managersValue).toHaveClass("wrap-break-word");
    expect(managersValue).toHaveClass("flex-1");

    const therapyValue = screen.getByText("Antihyperglycemic · Incretin Mimetic");
    expect(therapyValue).toHaveClass("text-right");
    expect(therapyValue).toHaveClass("wrap-break-word");
    expect(therapyValue).toHaveClass("flex-1");

    const buyerLabel = screen.getByText("Buyer");
    const buyerRow = buyerLabel.parentElement;
    expect(buyerRow?.children[0]).toBe(buyerLabel);
    expect(buyerRow?.children[1]).toBe(buyerValue);
  });

  it("keeps label and value on the same row for long values", () => {
    render(
      <ProfileKVList
        rows={[
          { label: "Buyer", value: "Connie Lambert" },
          {
            label: "Category managers",
            value: "Alice Smith, Bob Jones, Carol White, Dan Green",
          },
        ]}
      />
    );

    const managersLabel = screen.getByText("Category managers");
    const managersValue = screen.getByText(/Alice Smith/);
    expect(managersLabel.getBoundingClientRect().top).toBeCloseTo(
      managersValue.getBoundingClientRect().top,
      0
    );
  });
});
