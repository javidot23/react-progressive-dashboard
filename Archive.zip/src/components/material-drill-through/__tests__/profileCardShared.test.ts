import {
  damagesRateTextClass,
  filterProfileContactNames,
  formatOrNA,
  formatVendorLocation,
  isPresent,
  normalizeScoreFraction,
  resolveVendorBuyerNames,
  resolveVendorRiskScore,
  scoreBarFillClass,
} from "@/components/material-drill-through/profileCardShared";

describe("profileCardShared", () => {
  describe("formatOrNA", () => {
    it("returns N/A for nullish or empty values", () => {
      expect(formatOrNA(null)).toBe("N/A");
      expect(formatOrNA(undefined)).toBe("N/A");
      expect(formatOrNA("")).toBe("N/A");
      expect(formatOrNA("   ")).toBe("N/A");
    });

    it("formats present values", () => {
      expect(formatOrNA(42, v => `$${v}`)).toBe("$42");
    });
  });

  describe("formatVendorLocation", () => {
    it("joins city, state, and country as Warren, NJ · USA", () => {
      expect(
        formatVendorLocation({ city: "Warren", state: "NJ", country: "USA" })
      ).toBe("Warren, NJ · USA");
    });

    it("avoids duplicating state when already in city", () => {
      expect(
        formatVendorLocation({ city: "Warren, NJ", state: "NJ", country: "USA" })
      ).toBe("Warren, NJ · USA");
    });

    it("returns N/A when all location fields are missing", () => {
      expect(formatVendorLocation({})).toBe("N/A");
    });
  });

  describe("resolveVendorRiskScore", () => {
    it("returns 0 when risk_rating is missing", () => {
      expect(resolveVendorRiskScore(null)).toBe(0);
      expect(resolveVendorRiskScore(undefined)).toBe(0);
    });

    it("converts fractional risk_rating to 0–100", () => {
      expect(resolveVendorRiskScore(0.46)).toBe(46);
    });
  });

  describe("scoreBarFillClass", () => {
    it("maps performance tiers to CDS semantic colors", () => {
      expect(scoreBarFillClass(0.9)).toBe("bg-success-500");
      expect(scoreBarFillClass(0.75)).toBe("bg-warning-500");
      expect(scoreBarFillClass(0.5)).toBe("bg-danger-500");
    });
  });

  describe("damagesRateTextClass", () => {
    it("uses success for near-zero damages", () => {
      expect(damagesRateTextClass(0)).toBe("text-success-500");
    });

    it("uses danger for high damages", () => {
      expect(damagesRateTextClass(0.12)).toBe("text-danger-500");
    });
  });

  describe("normalizeScoreFraction", () => {
    it("clamps percentage inputs to 0–1", () => {
      expect(normalizeScoreFraction(85)).toBe(0.85);
      expect(normalizeScoreFraction(120)).toBe(1);
      expect(normalizeScoreFraction(1)).toBe(1);
    });
  });

  describe("isPresent", () => {
    it("treats zero as present", () => {
      expect(isPresent(0)).toBe(true);
    });
  });

  describe("filterProfileContactNames", () => {
    it("removes blank and unassigned entries", () => {
      expect(filterProfileContactNames(["Alice", " ", "unassigned", "Unassigned"])).toEqual([
        "Alice",
      ]);
    });
  });

  describe("resolveVendorBuyerNames", () => {
    it("prefers buyer_list over buyer_name", () => {
      expect(
        resolveVendorBuyerNames({
          buyer_list: ["A", "B"],
          buyer_name: "Legacy",
        })
      ).toEqual(["A", "B"]);
    });

    it("falls back to buyer_name when list is empty", () => {
      expect(resolveVendorBuyerNames({ buyer_list: [], buyer_name: "Connie" })).toEqual([
        "Connie",
      ]);
    });
  });
});
