import {
  isMaterialDrillVariantDownstream,
  isMaterialDrillVariantUpstream,
  shouldHideSupplierRiskScoreValue,
  shouldShowAsnMetrics,
  shouldShowContactsSection,
  shouldShowCostPerUnit,
  shouldShowFeeForService,
  shouldShowFormularySection,
  shouldShowInventoryQuantityRows,
  shouldShowMarketShareInHeader,
  shouldShowMaterialExposureFields,
  shouldShowOtifMetrics,
  shouldShowPerformanceScorecardSection,
  shouldShowPoDeliveryBlock,
} from "@/components/material-drill-through/materialDrillVisibility";

type GlobalWithTenant = typeof globalThis & { __TENANT__: string };

function setTenant(tenant: string) {
  (global as GlobalWithTenant).__TENANT__ = tenant;
}

describe("materialDrillVisibility", () => {
  afterEach(() => {
    setTenant("stratium");
  });

  describe("stratium", () => {
    beforeEach(() => setTenant("stratium"));

    it("treats tenant as neither upstream nor downstream variant portal drill", () => {
      expect(isMaterialDrillVariantUpstream()).toBe(false);
      expect(isMaterialDrillVariantDownstream()).toBe(false);
    });

    it("shows Stratium header and profile defaults", () => {
      expect(shouldShowMarketShareInHeader()).toBe(true);
      expect(shouldShowPoDeliveryBlock()).toBe(true);
      expect(shouldShowInventoryQuantityRows()).toBe(true);
      expect(shouldShowCostPerUnit()).toBe(true);
      expect(shouldShowMaterialExposureFields()).toBe(true);
      expect(shouldShowFeeForService()).toBe(true);
      expect(shouldShowFormularySection()).toBe(true);
      expect(shouldHideSupplierRiskScoreValue()).toBe(false);
      expect(shouldShowPerformanceScorecardSection()).toBe(true);
      expect(shouldShowOtifMetrics()).toBe(true);
      expect(shouldShowAsnMetrics()).toBe(true);
      expect(shouldShowContactsSection()).toBe(true);
    });
  });

  describe("stratium.vendor (upstream)", () => {
    beforeEach(() => setTenant("stratium.vendor"));

    it("identifies upstream", () => {
      expect(isMaterialDrillVariantUpstream()).toBe(true);
      expect(isMaterialDrillVariantDownstream()).toBe(false);
    });

    it("hides market share and shows unmasked PO delivery", () => {
      expect(shouldShowMarketShareInHeader()).toBe(false);
      expect(shouldShowPoDeliveryBlock()).toBe(true);
    });

    it("shows upstream vendor scorecard fields", () => {
      expect(shouldHideSupplierRiskScoreValue()).toBe(true);
      expect(shouldShowPerformanceScorecardSection()).toBe(true);
      expect(shouldShowOtifMetrics()).toBe(false);
      expect(shouldShowAsnMetrics()).toBe(true);
      expect(shouldShowContactsSection()).toBe(true);
      expect(shouldShowFeeForService()).toBe(false);
    });
  });

  describe("stratium.customer (downstream)", () => {
    beforeEach(() => setTenant("stratium.customer"));

    it("identifies downstream", () => {
      expect(isMaterialDrillVariantUpstream()).toBe(false);
      expect(isMaterialDrillVariantDownstream()).toBe(true);
    });

    it("hides PO delivery and limits inventory", () => {
      expect(shouldShowPoDeliveryBlock()).toBe(false);
      expect(shouldShowInventoryQuantityRows()).toBe(false);
      expect(shouldShowCostPerUnit()).toBe(false);
      expect(shouldShowMaterialExposureFields()).toBe(false);
      expect(shouldShowFeeForService()).toBe(false);
      expect(shouldShowFormularySection()).toBe(false);
    });

    it("hides performance scorecard and contacts", () => {
      expect(shouldShowPerformanceScorecardSection()).toBe(false);
      expect(shouldShowOtifMetrics()).toBe(false);
      expect(shouldShowAsnMetrics()).toBe(false);
      expect(shouldShowContactsSection()).toBe(false);
    });
  });

  describe("stratium.customer.vendor (upstream)", () => {
    beforeEach(() => setTenant("stratium.customer.vendor"));

    it("identifies upstream", () => {
      expect(isMaterialDrillVariantUpstream()).toBe(true);
      expect(isMaterialDrillVariantDownstream()).toBe(false);
    });
  });
});
