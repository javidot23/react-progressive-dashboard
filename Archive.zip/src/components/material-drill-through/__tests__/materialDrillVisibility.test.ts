import {
  isMaterialDrillVariantDownstream,
  isMaterialDrillVariantUpstream,
  shouldHideSupplierRiskScoreValue,
  shouldShowAsnMetrics,
  shouldShowContactsSection,
  shouldShowCostPerUnit,
  shouldShowDqsaChip,
  shouldShowFeeForService,
  shouldShowFormularySection,
  shouldShowInventoryQuantityRows,
  shouldShowManufacturerAvailability,
  shouldShowMarketShareInHeader,
  shouldShowMarketShareInProfile,
  shouldShowMaterialExposureFields,
  shouldShowOtifMetrics,
  shouldShowOverallScore,
  shouldShowPerformanceScorecardSection,
  shouldShowPoDeliveryBlock,
  shouldShowProductDamagesRate,
  shouldShowScrmHeaderAttributes,
  shouldShowVariantDrivingRiskLabel,
} from "@/components/material-drill-through/materialDrillVisibility";

describe("materialDrillVisibility", () => {
  it("treats undefined tenant type as neither upstream nor downstream", () => {
    expect(isMaterialDrillVariantUpstream(undefined)).toBe(false);
    expect(isMaterialDrillVariantDownstream(undefined)).toBe(false);
  });

  it("classifies customer as downstream", () => {
    expect(isMaterialDrillVariantUpstream("customer")).toBe(false);
    expect(isMaterialDrillVariantDownstream("customer")).toBe(true);
  });

  it("classifies vendor and customer_vendor as upstream", () => {
    expect(isMaterialDrillVariantUpstream("vendor")).toBe(true);
    expect(isMaterialDrillVariantDownstream("vendor")).toBe(false);
    expect(isMaterialDrillVariantUpstream("customer_vendor")).toBe(true);
    expect(isMaterialDrillVariantDownstream("customer_vendor")).toBe(false);
  });

  it("hides downstream-only fields for customer, shows them for vendor/customer_vendor", () => {
    for (const type of ["vendor", "customer_vendor"] as const) {
      expect(shouldShowPoDeliveryBlock(type)).toBe(true);
      expect(shouldShowInventoryQuantityRows(type)).toBe(true);
      expect(shouldShowCostPerUnit(type)).toBe(true);
      expect(shouldShowMaterialExposureFields(type)).toBe(true);
      expect(shouldShowFormularySection(type)).toBe(true);
      expect(shouldShowDqsaChip(type)).toBe(true);
      expect(shouldShowManufacturerAvailability(type)).toBe(true);
    }

    expect(shouldShowPoDeliveryBlock("customer")).toBe(false);
    expect(shouldShowInventoryQuantityRows("customer")).toBe(false);
    expect(shouldShowCostPerUnit("customer")).toBe(false);
    expect(shouldShowMaterialExposureFields("customer")).toBe(false);
    expect(shouldShowFormularySection("customer")).toBe(false);
    expect(shouldShowDqsaChip("customer")).toBe(false);
    expect(shouldShowManufacturerAvailability("customer")).toBe(false);
  });

  it("shows upstream-only performance/scorecard sections only for vendor/customer_vendor", () => {
    expect(shouldShowPerformanceScorecardSection("vendor")).toBe(true);
    expect(shouldShowPerformanceScorecardSection("customer_vendor")).toBe(true);
    expect(shouldShowPerformanceScorecardSection("customer")).toBe(false);

    expect(shouldShowAsnMetrics("vendor")).toBe(true);
    expect(shouldShowAsnMetrics("customer")).toBe(false);

    expect(shouldShowProductDamagesRate("vendor")).toBe(true);
    expect(shouldShowProductDamagesRate("customer")).toBe(false);

    expect(shouldShowContactsSection("vendor")).toBe(true);
    expect(shouldShowContactsSection("customer")).toBe(false);
  });

  it("forces Stratium-only fields off for every tenant type", () => {
    for (const type of ["customer", "vendor", "customer_vendor", undefined] as const) {
      expect(shouldShowFeeForService(type)).toBe(false);
      expect(shouldShowMarketShareInHeader(type)).toBe(false);
      expect(shouldShowMarketShareInProfile(type)).toBe(false);
      expect(shouldShowScrmHeaderAttributes(type)).toBe(false);
      expect(shouldShowOverallScore(type)).toBe(false);
      expect(shouldShowOtifMetrics(type)).toBe(false);
      expect(shouldHideSupplierRiskScoreValue(type)).toBe(true);
      expect(shouldShowVariantDrivingRiskLabel(type)).toBe(true);
    }
  });
});
