import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import { MaterialProfileCard } from "@/components/material-drill-through/MaterialProfileCard";
import type { MaterialSubstitutionDetailsResponse } from "@/lib/apiServices";
import { getTenantPortalFlags } from "@/tenant";
const vendorPortalFlags = getTenantPortalFlags("vendor");

// MaterialProfileCard reads tenantType from useTenantContextQuery(selectTenantPortalFlags);
// mock it so the component doesn't need an AuthProvider/QueryClientProvider in this unit test.
jest.mock("@/tenant", () => ({
  ...jest.requireActual("@/tenant"),
  useTenantContextQuery: jest.fn(),
}));
const { useTenantContextQuery } = jest.requireMock("@/tenant");
(useTenantContextQuery as jest.Mock).mockReturnValue({ data: vendorPortalFlags });

type MaterialDetail = MaterialSubstitutionDetailsResponse["data"]["material"];

const baseMaterial: MaterialDetail = {
  id: 1,
  mat_nbr: "10308115",
  name: "Liraglutide",
  risk_rating: 1,
  driving_risk: "Regulatory",
  dollars_at_risk: 1000,
  saleable_qty_on_hand: 1922,
  forecast_qty_7day: 715,
  cost_per_unit: 1165.54,
  market_share: null,
  ndc: "69097091055",
  days_on_hand: null,
  mnftr_avail_note_desc: "Supplier shipping intermittent when available",
  inj_flg: "Y",
  who_essential_flg: "N",
  dqsa_exempt_flg: "N",
};

describe("MaterialProfileCard", () => {
  it("shows skeleton while loading", () => {
    const { container } = render(<MaterialProfileCard isLoading />);
    expect(container.querySelector(".animate-pulse")).toBeInTheDocument();
    expect(screen.queryByText("Material Profile")).not.toBeInTheDocument();
  });

  it("renders N/A for null days on hand and shows availability note", () => {
    render(<MaterialProfileCard material={baseMaterial} />);

    expect(screen.getByText("Material Profile")).toBeInTheDocument();
    expect(screen.getByText("Days on hand")).toBeInTheDocument();
    const daysOnHandLabel = screen.getByText("Days on hand");
    const daysOnHandRow = daysOnHandLabel.parentElement;
    expect(daysOnHandRow?.children[1]).toHaveTextContent("N/A");
    expect(screen.getByText("Manufacturer availability")).toBeInTheDocument();
    expect(screen.getByText(/supplier shipping intermittent when available/i)).toBeInTheDocument();
  });

  it("shows empty formulary message when no records", () => {
    render(<MaterialProfileCard material={baseMaterial} materialFormularies={[]} />);
    expect(screen.getByText("No formulary records")).toBeInTheDocument();
  });

  it("shows program and type columns for formulary records", () => {
    render(
      <MaterialProfileCard
        material={baseMaterial}
        materialFormularies={[
          {
            id: 208,
            program: "GOVT",
            program_description: "Government formulary",
          },
        ]}
      />
    );

    expect(screen.getByText("Program")).toBeInTheDocument();
    expect(screen.getByText("Program Description")).toBeInTheDocument();
    expect(screen.getByText("GOVT")).toBeInTheDocument();
    expect(screen.getByText("Government formulary")).toBeInTheDocument();
    expect(screen.queryByText("Contract #")).not.toBeInTheDocument();
    expect(screen.queryByText("Sales group")).not.toBeInTheDocument();
  });

  it("renders profile with N/A when material is missing after load", () => {
    render(<MaterialProfileCard material={null} isLoading={false} />);
    expect(screen.getByText("Material Profile")).toBeInTheDocument();
    expect(screen.getAllByText("N/A").length).toBeGreaterThan(0);
  });

  it("renders all upstream inventory and commercial fields (excluding Stratium-only fields)", () => {
    render(<MaterialProfileCard material={baseMaterial} availablePlantsCount={3} />);

    expect(screen.getByText("Days on hand")).toBeInTheDocument();
    expect(screen.getByText("Saleable on-hand")).toBeInTheDocument();
    expect(screen.getByText("Unrestricted on-hand")).toBeInTheDocument();
    expect(screen.getByText("7-day forecast")).toBeInTheDocument();
    expect(screen.getByText("Manufacturer availability")).toBeInTheDocument();
    expect(screen.getByText("Formulary")).toBeInTheDocument();
    expect(screen.getByText("Cost / unit")).toBeInTheDocument();
    expect(screen.getByText(/DQSA:/)).toBeInTheDocument();
    expect(screen.getByText("Avg shortage duration")).toBeInTheDocument();
    // Stratium-only fields are forced off for every tenant type.
    expect(screen.queryByText("Market share")).not.toBeInTheDocument();
    expect(screen.queryByText(/Fee for Service/)).not.toBeInTheDocument();
  });

  it("never shows the Fee for Service chip (Stratium-only, forced off)", () => {
    render(<MaterialProfileCard material={{ ...baseMaterial, fee_for_service_flg: 1 }} />);
    expect(screen.queryByText(/Fee for Service/)).not.toBeInTheDocument();
  });

  it("shows avg shortage duration in commercial section", () => {
    render(<MaterialProfileCard material={{ ...baseMaterial, avg_shortage_duration: 14 }} />);
    expect(screen.getByText("Avg shortage duration")).toBeInTheDocument();
    expect(screen.getByText("14 days")).toBeInTheDocument();
  });
});
