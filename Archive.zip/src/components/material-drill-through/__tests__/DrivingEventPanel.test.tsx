import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import { DrivingEventPanel } from "@/components/material-drill-through/DrivingEventPanel";
import type { DetailedSupplyChainEvent } from "@/lib/apiServices";

jest.mock("@/components/templates/CardLayout", () => ({
  __esModule: true,
  default: ({ title, children }: { title?: string; children: React.ReactNode }) => (
    <div>
      <h2>{title}</h2>
      {children}
    </div>
  ),
}));

jest.mock("@/components/molecules", () => ({
  EmptyState: ({ title }: { title: string }) => <div>{title}</div>,
}));

const baseEvent: DetailedSupplyChainEvent = {
  id: 8,
  event_id: "SCE-20729081",
  type: "Cencora Defined Drug Shortage",
  type_description: "Test description",
  status: "CLOSED",
  start_date: "2026-03-10T12:44:59.541365Z",
  end_date: "2026-04-03T12:44:59.541365Z",
  latitude: -12.45,
  longitude: -96.45,
  city: "Sandraland",
  state: "CT",
  country: "Malaysia",
  mat_nbr: {
    id: 46,
    vendor: "Vendor Co",
    mat_nbr: "0603363730",
    name: "Test Material",
    created_at: "",
    updated_at: "",
    risk_rating: 0.53,
    driving_risk: "Compliance",
    dollars_at_risk: 1000,
    ndc: "72114312250",
    saleable_qty_on_hand: 100,
    unrestricted_qty_on_hand: 100,
    forecast_qty_7day: 10,
    cost_per_unit: 10,
    market_share: 10,
    material_group: "GRX",
    cat_mgr_name: "Manager",
    cat_mgr_nbr: "1",
    buyer_name: "Buyer",
    buyer_cd: "1",
    product_family: "family",
    otif_percentage: 0.5,
    delivery_deviation: 0,
    outbound_fill_rate: 0.5,
    fdb_gcn_seq_nbr: "1",
    hic3_therapy_class: "Class",
    dollars_at_risk_this_week: 0,
    dollars_at_risk_prev_week: 0,
    xplant_mat_stat: "UM",
    scrm_mat_grp: "GRX",
  },
  metadata: "",
  created_at: "",
  updated_at: "",
};

describe("DrivingEventPanel", () => {
  it("renders Driving Event title", () => {
    render(<DrivingEventPanel event={baseEvent} />);
    expect(screen.getByRole("heading", { name: "Driving Event" })).toBeInTheDocument();
  });

  it("shows event details when event is present", () => {
    render(<DrivingEventPanel event={baseEvent} />);

    expect(screen.getByText("Cencora Defined Drug Shortage")).toBeInTheDocument();
    expect(screen.getByText("CLOSED")).toBeInTheDocument();
    expect(screen.getByText("SCE-20729081")).toBeInTheDocument();
    expect(screen.getByText("Test description")).toBeInTheDocument();
    expect(screen.getByText(/Location:/)).toBeInTheDocument();
    expect(screen.getByText(/Sandraland/)).toBeInTheDocument();
    expect(screen.getByText(/Start Date:/)).toBeInTheDocument();
    expect(screen.getByText(/End Date:/)).toBeInTheDocument();
  });

  it("shows empty state when event is null", () => {
    render(<DrivingEventPanel event={null} />);
    expect(screen.getByText("No driving event")).toBeInTheDocument();
  });

  it("shows loading skeleton while loading", () => {
    const { container } = render(<DrivingEventPanel event={null} isLoading />);
    expect(container.querySelector(".animate-pulse")).toBeInTheDocument();
    expect(screen.queryByText("No driving event")).not.toBeInTheDocument();
  });
});
