"use client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/atoms/Card";
import { Button } from "@/components/atoms/Button";
import InfoIcon from "@/components/atoms/InfoIcon";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, CartesianGrid, Tooltip, Cell } from "recharts";
import { INCOMPLETE_WEEK_BAR_OPACITY } from "@/lib/incompleteWeek";
import { useState, useRef, useEffect } from "react";
import { ModifyGoalModal, ModifyGoalData } from "@/components/organisms/ModifyGoalModal";
import { getMySettings, patchMySettings } from "@/services/userSettingsService";
import { GraphCardSkeleton, EmptyState } from "@/components/molecules";
import Legend, { LegendItem } from "@/components/atoms/Legend";
import { getErrorMessage } from "@/lib/getErrorMessage";
import { toast } from "@/lib/toast";
import { useWeeklyOutboundUnfilledTrendQuery } from "@/hooks/queries/useWeeklyOutboundUnfilledTrendQuery";
import { AccessibleChart } from "@/components/atoms/AccessibleChart";

const CARD_MIN_HEIGHT = "480px";
const MIN_CHART_HEIGHT = "320px";
const CHART_MARGIN = { top: 20, right: 20, left: 20, bottom: 20 };
const MAX_BAR_SIZE = 100;
const ORDERS_COLOR = "#461E96"; // Purple

const CARD_TITLE = "Outbound Unfilled Quantity";
const CARD_DESCRIPTION = "Weekly unfilled quantity and fulfillment percentage for the last 90 days.";
const INFO_TOOLTIP =
  "This visual provides the unfilled percentage trends over time, showing the percentage of omits with inflation patterns by customer. The purple bars indicate the average omit percentage trending above normal baseline.";

const LEGEND_ITEMS: LegendItem[] = [
  { id: "orders", color: ORDERS_COLOR, label: "Orders", shape: "square" },
];

const formatPercentage = (value: number) => {
  return `${value}%`;
};

interface TooltipPayload {
  payload: {
    unfilledPercentage?: number;
    week?: string;
    isIncompleteWeek?: boolean;
  };
}

interface UnfilledPercentageTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}

const UnfilledPercentageTooltip = ({ active, payload, label }: UnfilledPercentageTooltipProps) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const unfilledPercentage = data.unfilledPercentage || 0;
    const week = data.week || label;
    const incompleteWeek = Boolean(data.isIncompleteWeek);

    return (
      <div className="bg-[#211359] text-white text-xs rounded-md shadow-lg w-[200px] p-3 font-normal z-30">
        <div className="flex flex-col gap-2">
          <div className="flex justify-between">
            <span className="text-white">Week:</span>
            <span className="font-medium">{week}</span>
          </div>
          {incompleteWeek && (
            <p className="text-xs font-medium text-white/80 border-b border-white/20 pb-2">
              Incomplete week
            </p>
          )}
          <div className="flex justify-between">
            <span className="text-white">Unfilled Percentage:</span>
            <span className="font-medium">{unfilledPercentage}%</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

interface UnfilledPercentageCardHeaderProps {
  goalTarget: number;
  onModifyGoal: () => void;
  modifyButtonRef: React.RefObject<HTMLButtonElement | null>;
  isModalOpen: boolean;
  onModalClose: () => void;
  onSaveGoal: (data: ModifyGoalData) => Promise<void>;
}

const UnfilledPercentageCardHeader = ({
  goalTarget,
  onModifyGoal,
  modifyButtonRef,
  isModalOpen,
  onModalClose,
  onSaveGoal,
}: UnfilledPercentageCardHeaderProps) => (
  <CardHeader className="shrink-0">
    <div className="flex items-center justify-between gap-2">
      <div className="flex items-center gap-2">
        <CardTitle
          className="text-xl font-bold leading-[28.8px] text-heading font-brand"
          style={{
            fontSize: "20px",
            fontWeight: "700",
            lineHeight: "28.8px",
          }}
        >
          {CARD_TITLE}
        </CardTitle>
        <InfoIcon tooltip={INFO_TOOLTIP} />
      </div>
      <div className="relative">
        <Button
          ref={modifyButtonRef}
          variant="outline"
          size="sm"
          onClick={onModifyGoal}
          className="border-2 border-brand-primary-main text-brand-primary-main font-bold rounded hover:bg-transparent text-sm px-4 py-1"
        >
          Modify Goal
        </Button>
        {isModalOpen && (
          <ModifyGoalModal
            isOpen={isModalOpen}
            onClose={onModalClose}
            onSave={onSaveGoal}
            triggerRef={modifyButtonRef}
            initialData={{
              serviceLevelTarget: goalTarget,
              riskScoreThreshold: "100%",
              alertFrequency: "daily",
            }}
          />
        )}
      </div>
    </div>

    <p className="text-sm text-ui-text-secondary mb-4">{CARD_DESCRIPTION}</p>

    <Legend items={LEGEND_ITEMS} orientation="horizontal" spacing="md" />
  </CardHeader>
);


export function UnfilledPercentageTrendCard() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [goalTarget, setGoalTarget] = useState(10);
  const modifyButtonRef = useRef<HTMLButtonElement>(null);
  const {
    chartData,
    isLoading: loading,
    error: trendError,
  } = useWeeklyOutboundUnfilledTrendQuery();

  const error = trendError;
  const hasEverFetched = !loading || chartData.length > 0 || !!error;
  const hasData = chartData.length > 0;

  const handleModifyGoal = () => {
    setIsModalOpen(true);
  };

  const handleSaveGoal = async (data: ModifyGoalData) => {
    try {
      const nextVal = data.serviceLevelTarget == null ? 10 : data.serviceLevelTarget;
      setGoalTarget(nextVal);
      await patchMySettings({
        unfilled_percentage_target: data.serviceLevelTarget,
      });
      toast.success({ title: "Threshold updated" });
    } catch (e) {
      console.warn("Failed to save unfilled_percentage_target", e);
      toast.error({
        title: "Couldn't update threshold",
        description: getErrorMessage(e),
      });
    }
  };

  useEffect(() => {
    (async () => {
      try {
        const settings = await getMySettings();
        const target = Math.min(100, Math.max(0, Math.round(parseFloat(String(settings.unfilled_percentage_target ?? 10)))));
        setGoalTarget(target || 10);
      } catch (error) {
        console.warn("Failed to fetch user settings", error);
      }
    })();
  }, []);

  // Show skeleton only when loading AND no data, OR when never fetched
  if ((loading && !hasData) || (!hasEverFetched && !error)) {
    return (
      <div className="relative h-full">
        <GraphCardSkeleton height={CARD_MIN_HEIGHT} />
      </div>
    );
  }

  if (hasEverFetched && !loading && !error && !hasData) {
    return (
      <div className="relative h-full">
        <Card
          className="flex flex-col h-full border border-[#E2E8F0] rounded-[4px]"
          style={{ height: CARD_MIN_HEIGHT, boxSizing: "border-box" }}
        >
          <UnfilledPercentageCardHeader
            goalTarget={goalTarget}
            onModifyGoal={handleModifyGoal}
            modifyButtonRef={modifyButtonRef}
            isModalOpen={isModalOpen}
            onModalClose={() => setIsModalOpen(false)}
            onSaveGoal={handleSaveGoal}
          />
          <CardContent className="flex-1 flex items-center justify-center min-h-0">
            <EmptyState
              title="Trend data unavailable"
              description="No weekly outbound unfilled trend data is available for the selected period. Goal thresholds can still be updated."
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="relative h-full">
      <Card className="flex flex-col h-full border border-[#E2E8F0] rounded-[4px]" style={{ height: CARD_MIN_HEIGHT, boxSizing: 'border-box' }}>
        <UnfilledPercentageCardHeader
          goalTarget={goalTarget}
          onModifyGoal={handleModifyGoal}
          modifyButtonRef={modifyButtonRef}
          isModalOpen={isModalOpen}
          onModalClose={() => setIsModalOpen(false)}
          onSaveGoal={handleSaveGoal}
        />
        <CardContent className="flex-1 flex flex-col px-4 pt-4 pb-0 min-h-0">
          <div
            className="w-full overflow-x-auto overflow-y-visible relative shrink-0"
            style={{ height: MIN_CHART_HEIGHT }}
          >
            {error && !loading && (
              <div className="absolute inset-0 flex items-center justify-center text-status-error-main z-10">
                <div className="text-center">
                  <p className="text-sm font-medium">Failed to load data</p>
                  <p className="text-xs text-ui-text-muted mt-1">{error}</p>
                </div>
              </div>
            )}
            <AccessibleChart ariaLabel={CARD_TITLE} className="h-full w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={CHART_MARGIN}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-ui-border-primary)" vertical={false} />

                <XAxis
                  dataKey="week"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                  label={{
                    value: "Average Omit % trending above normal baseline",
                    position: "insideBottom",
                    offset: -5,
                    style: {
                      textAnchor: "middle",
                      fill: "var(--color-ui-text-muted)",
                      fontSize: "12px",
                    },
                  }}
                />

                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                  domain={[0, 20]}
                  tickFormatter={formatPercentage}
                  label={{
                    value: "% received %",
                    angle: -90,
                    position: "insideLeft",
                    style: {
                      textAnchor: "middle",
                      fill: "var(--color-ui-text-muted)",
                      fontSize: "12px",
                    },
                  }}
                />

                <Tooltip
                  content={<UnfilledPercentageTooltip />}
                  cursor={{ fill: "rgba(59, 41, 112, 0.1)" }}
                  allowEscapeViewBox={{ x: false, y: false }}
                  offset={10}
                />

                <Bar
                  dataKey="unfilledPercentage"
                  fill={ORDERS_COLOR}
                  stroke={ORDERS_COLOR}
                  strokeWidth={1}
                  radius={[0, 0, 0, 0]}
                  maxBarSize={MAX_BAR_SIZE}
                >
                  {chartData.map((entry, index) => (
                    <Cell
                      key={`unfilled-${index}`}
                      fillOpacity={entry.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            </AccessibleChart>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
