"use client"
import { useState } from "react"
import { Table, TableBody, TableHead, TableHeader, TableRow } from "@/components/atoms/Table"
import { Checkbox } from "@/components/atoms/Checkbox"
import {Pagination} from "@/components/atoms"
import { Info, ChevronDown, MapPin, BarChart3 } from "lucide-react"
import Filters from "@/components/atoms/Filters"
import AppliedFilters from "@/components/atoms/AppliedFilters"
import { issueFiltersConfig, issueAppliedFiltersConfig } from "@/lib/filterConfigs"
import { useFilterRangesQuery } from "@/hooks/queries"
import { ViewToggleButtons } from "@/components/molecules/ViewToggleButtons"
import { IssueTableRow } from "@/components/molecules/IssueTableRow"
import type { IssueItem } from "@/lib/types"

interface IssuesTableProps {
  issues: IssueItem[]
  currentPage?: number
  pageSize?: number
  total?: number
  onPageChange?: (page: number) => void
  onPageSizeChange?: (pageSize: number) => void
}

export function IssuesTable({
  issues: initialIssues,
  currentPage = 1,
  pageSize = 20,
  total = 0,
  onPageChange,
  onPageSizeChange
}: IssuesTableProps) {
  const [issues, setIssues] = useState(initialIssues.map((issue) => ({ ...issue, selected: issue.selected || false })))
  const [viewMode, setViewMode] = useState<"table" | "cards">("table")
  const [filters, setFilters] = useState({
    ordering: "-material__risk_rating",
    risk_rating_min: null,
    risk_rating_max: null,
    driving_risk: null,
    has_no_actions: undefined,
    risk_adjusted_value_min: null,
    risk_adjusted_value_max: null,
  })

  const { maxes: issueRangeMaxes } = useFilterRangesQuery({
    module: "issue",
    keys: ["risk_adjusted_value"],
  })

  const handleSelectAll = (checked: boolean | "indeterminate") => {
    setIssues(issues.map((issue) => ({ ...issue, selected: !!checked })))
  }

  const handleSelectRow = (id: string, checked: boolean) => {
    setIssues(issues.map((issue) => (issue.id === id ? { ...issue, selected: checked } : issue)))
  }

  const allSelected = issues.every((issue) => issue.selected)
  const someSelected = issues.some((issue) => issue.selected) && !allSelected

  const tableViews = [
    { id: "table", label: "Table View", icon: MapPin },
    { id: "cards", label: "Cards View", icon: BarChart3 },
  ]

  return (
    <div className="bg-ui-background-primary p-4 sm:p-6 rounded-lg shadow-sm">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
        <div>
          <h3 className="text-xl font-semibold text-ui-text-primary flex items-center">
                            Open Issues by Risk Adjusted Value <Info className="w-3 h-3 ml-2 text-brand-primary-main" />
          </h3>
          <p className="text-sm text-ui-text-secondary">19 issues requiring response - 2 new since yesterday</p>
        </div>
        <ViewToggleButtons currentView={viewMode} onViewChange={(view) => setViewMode(view as "table" | "cards")} views={tableViews} />
      </div>

      <div className="flex flex-col space-y-3 mb-4">
        <Filters
          filters={filters}
          setFilters={setFilters}
          config={issueFiltersConfig}
          dynamicMaxValues={issueRangeMaxes}
        />
        <AppliedFilters
          filters={filters}
          setFilters={setFilters}
          config={issueAppliedFiltersConfig}
        />
      </div>

      {viewMode === "table" && (
        <div className="overflow-x-auto border border-ui-border-primary rounded-md">
          <Table>
            <TableHeader className="bg-ui-background-secondary">
              <TableRow>
                <TableHead className="w-[50px] px-4 py-3">
                  <Checkbox
                    checked={allSelected || someSelected}
                    onCheckedChange={handleSelectAll}
                    aria-label="Select all issues"
                  />
                </TableHead>
                {[
                  "Vendor",
                  "Product",
                  "Risk Level",
                  "Risk Exposure",
                  "Driving Risk Driver",
                  "Action Status",
                  "AI Recommendation",
                ].map((header, idx) => (
                  <TableHead
                    key={header}
                    className="px-4 py-3 text-xs font-medium text-ui-text-secondary uppercase tracking-wider"
                  >
                    {header}
                    {(idx < 2 || (idx > 2 && idx < 6)) && <Info className="h-3 w-3 inline-block ml-1 text-ui-text-muted" />}
                    {idx === 0 && <ChevronDown className="h-4 w-4 inline-block ml-1 text-ui-text-muted" />}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {issues.map((issue) => (
                <IssueTableRow key={issue.id} issue={issue} onSelectRow={handleSelectRow} />
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      {/* TODO: Implement Cards View if viewMode === 'cards' */}
      {viewMode === "cards" && (
        <div className="border border-ui-border-primary rounded-md p-4 text-center text-ui-text-secondary">
          Cards View for issues would be displayed here.
        </div>
      )}

      {onPageChange && onPageSizeChange && (
        <Pagination
          currentPage={currentPage}
          pageSize={pageSize}
          total={total}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
          itemName="Issues"
          className="mt-6"
        />
      )}
    </div>
  );
}
