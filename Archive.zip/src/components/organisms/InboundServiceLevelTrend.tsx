import React, { useEffect, useState, useMemo } from "react";
import { createRoot } from "react-dom/client";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { MapContainer, useMap } from "react-leaflet";
import { useServiceLevelData } from "@/hooks/useServiceLevelData";
import { formatApiDate } from "@/lib/dateUtils";
import InfoIcon from "@/components/atoms/InfoIcon";
import { Spinner } from "@/components/atoms/Spinner";
import { generateAllZipCoordinatesInstantly } from "@/lib/geocodingService";
import usStatesData from "@/public/data/us-states.json";
import usaFlag from "@/assets/icons/usa-icon-flag.svg";
interface ChartPointTooltipProps {
  date: string;
  fillRate: string;
  shippedQty: string;
  orderQty: string;
}

const ChartPointTooltip: React.FC<ChartPointTooltipProps> = ({ date, fillRate, shippedQty, orderQty }) => (
  <div
    style={{
      background: "var(--cds-color-background-brand-secondary)",
      color: "white",
      padding: "8px 12px",
      borderRadius: "6px",
      fontSize: "11px",
      lineHeight: 1.4,
      minWidth: "120px",
      position: "relative",
      zIndex: 999999,
    }}
  >
    <div style={{ fontWeight: 600, marginBottom: "4px" }}>Date: {date}</div>
    <div>Fill Rate: {fillRate}%</div>
    <div>Shipped Qty: {shippedQty}</div>
    <div>Orders Placed: {orderQty}</div>
  </div>
);

interface InboundServiceLevelTrendProps {
  className?: string;
}

// Utility functions
// Impact is inverse of service level: High Impact = Low Service Level
const getImpactLevel = (serviceLevel: number): "high" | "medium" | "low" => {
  if (serviceLevel < 0.41) return "high"; // < 41% = High impact
  if (serviceLevel <= 0.8) return "medium"; // 41% - 80% = Medium impact
  return "low"; // ≥ 81% = Low impact
};

const getImpactColor = (impact: "high" | "medium" | "low"): string => {
  switch (impact) {
    case "high":
      return "#461E96";
    case "medium":
      return "#EC4899";
    case "low":
      return "#06B6D4";
    default:
      return "#06B6D4";
  }
};

const clearNonTileLayers = (map: L.Map) => {
  map.eachLayer(layer => {
    if (!(layer instanceof L.TileLayer)) {
      map.removeLayer(layer);
    }
  });
};

type DomListener = {
  element: Element;
  type: string;
  handler: EventListener;
};

type PlantMarkerPopupState = {
  tooltipRoot: ReturnType<typeof createRoot> | null;
  setupHoverTimeouts: ReturnType<typeof setTimeout>[];
  chartListeners: DomListener[];
  tooltipContainerListeners: DomListener[];
};

function cleanupPopupDom(plantMarker: L.CircleMarker, popupState: PlantMarkerPopupState) {
  popupState.setupHoverTimeouts.forEach(timeoutId => clearTimeout(timeoutId));
  popupState.setupHoverTimeouts.length = 0;

  if (popupState.tooltipRoot) {
    popupState.tooltipRoot.unmount();
    popupState.tooltipRoot = null;
  }

  popupState.chartListeners.forEach(({ element, type, handler }) => {
    element.removeEventListener(type, handler);
  });
  popupState.chartListeners.length = 0;

  popupState.tooltipContainerListeners.forEach(({ element, type, handler }) => {
    element.removeEventListener(type, handler);
  });
  popupState.tooltipContainerListeners.length = 0;

  const popup = plantMarker.getPopup();
  const popupEl = popup?.getElement();
  if (popupEl) {
    const old = (popupEl as { _popupHover?: { enter: EventListener; leave: EventListener } })._popupHover;
    if (old) {
      popupEl.removeEventListener("mouseenter", old.enter);
      popupEl.removeEventListener("mouseleave", old.leave);
      delete (popupEl as { _popupHover?: unknown })._popupHover;
    }
  }
}

const createInteractivePlantMarkers = (
  map: L.Map,
  plant: any,
  plantColor: string,
  geocodedZipCodes: Map<string, any>,
  serviceLevels: any[] = []
): (() => void) | undefined => {
  if (!plant.coverage_zip_codes || plant.coverage_zip_codes.length === 0) {
    return undefined;
  }

  try {
    // Create plant marker (static, no animation)
    const plantMarker = L.circleMarker([plant.latitude, plant.longitude], {
      radius: 6,
      fillColor: plantColor,
      color: "var(--color-accent-50, #FFF0F6)",
      weight: 3,
      opacity: 1,
      fillOpacity: 1,
      interactive: true, // Ensure it's clickable
      className: "plant-marker",
    });

    const popupState: PlantMarkerPopupState = {
      tooltipRoot: null,
      setupHoverTimeouts: [],
      chartListeners: [],
      tooltipContainerListeners: [],
    };

    // Calculate average fill rate from service levels
    const calculateAverageFillRate = (levels: any[]): number => {
      if (!levels || levels.length === 0) return 0;
      let totalFillRate = 0;
      let count = 0;
      levels.forEach(level => {
        if (level.total_order_qty && level.total_order_qty > 0) {
          const fillRate = (level.total_received_qty || 0) / level.total_order_qty;
          totalFillRate += fillRate;
          count++;
        }
      });
      return count > 0 ? (totalFillRate / count) * 100 : 0;
    };

    // Generate chart data points from service levels
    const generateChartData = (levels: any[]): { x: number; y: number; data: any }[] => {
      if (!levels || levels.length === 0) return [];
      const sortedLevels = [...levels].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      const chartWidth = 200;
      const chartHeight = 25;
      const topMargin = 5;
      const bottomMargin = 5;
      const usableHeight = chartHeight - topMargin - bottomMargin;
      const pointSpacing = sortedLevels.length > 1 ? chartWidth / (sortedLevels.length - 1) : 0;

      // Find min and max fill rates for normalization
      const fillRates = sortedLevels.map(level => {
        if (level.total_order_qty && level.total_order_qty > 0) {
          return ((level.total_received_qty || 0) / level.total_order_qty) * 100;
        }
        return 0;
      });
      const minRate = Math.min(...fillRates);
      const maxRate = Math.max(...fillRates);
      const range = maxRate - minRate || 100; // Avoid division by zero

      return sortedLevels.map((level, index) => {
        const fillRate =
          level.total_order_qty && level.total_order_qty > 0
            ? ((level.total_received_qty || 0) / level.total_order_qty) * 100
            : 0;
        // Normalize fill rate to chart height (min maps to bottom, max maps to top)
        const normalizedRate = range > 0 ? (fillRate - minRate) / range : 0.5;
        const normalizedY = topMargin + usableHeight - normalizedRate * usableHeight;
        return {
          x: index * pointSpacing,
          y: normalizedY,
          data: level,
        };
      });
    };

    const avgFillRate = calculateAverageFillRate(serviceLevels);
    const chartData = generateChartData(serviceLevels);

    // Generate polyline points string
    const polylinePoints = chartData.map(p => `${p.x},${p.y}`).join(" ");
    const bottomY = 30; // Bottom of chart area (35px height - 5px margin)
    const polygonPoints =
      chartData.length > 0
        ? `${polylinePoints} ${chartData[chartData.length - 1].x},${bottomY} ${chartData[0].x},${bottomY}`
        : "";

    const hoverCircles = chartData
      .map((point, index) => {
        const dateStr = formatApiDate(point.data.date);
        const fillRatePct =
          point.data.total_order_qty && point.data.total_order_qty > 0
            ? (((point.data.total_received_qty || 0) / point.data.total_order_qty) * 100).toFixed(2)
            : "0.00";
        const shippedQty = (point.data.total_received_qty || 0).toLocaleString();
        const orderQty = (point.data.total_order_qty || 0).toLocaleString();

        return `
        <circle
          cx="${point.x}"
          cy="${point.y}"
          r="4"
          fill="#6B46C1"
          stroke="white"
          stroke-width="2"
          class="chart-hover-point"
          style="opacity: 0; cursor: pointer;"
          data-index="${index}"
          data-date="${dateStr}"
          data-fill-rate="${fillRatePct}"
          data-shipped-qty="${shippedQty}"
          data-order-qty="${orderQty}"
          data-x="${Math.max(0, point.x - 60)}"
          data-plant-id="${plant.id}"
        />`;
      })
      .join("");

    // Add plant tooltip matching the image style exactly
    const plantTooltipContent = `
        <div style="
          font-family: system-ui, -apple-system, sans-serif;
          background: white;
          border-radius: 12px;
          padding: 16px;
          min-width: 280px;
          box-shadow: 0 10px 25px rgba(0,0,0,0.15);
          border: 1px solid #e5e7eb;
          position: relative;
        ">
          <!-- Header with Info Icon -->
          <div style="display: flex; align-items: center; margin-bottom: 16px;">
            <div style="display: flex; align-items: center;">
              <svg width="16" height="16" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="#9CA3AF" stroke-width="1.5" style="margin-right: 8px;">
                <g fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M14.25 16.5H13.5A1.5 1.5 0 0 1 12 15V11.25a.75.75 0 0 0 -.75-.75H10.5"/>
                  <path d="M11.625 6.75A.375.375 0 1 0 12 7.125a.375.375 0 0 0 -.375-.375h0"/>
                  <path d="M.75 12A11.25 11.25 0 1 0 23.25 12 11.25 11.25 0 1 0 .75 12Z"/>
                </g>
              </svg>
              <span style="
                color: var(--Cencora-text-heading, var(--color-text-heading, #1E1E1E));
                font-family: var(--text-body-sm-font-family, Cencora-Gilroy);
                font-size: var(--text-body-sm-font-size, 14px);
                font-style: normal;
                font-weight: 700;
                line-height: var(--text-body-sm-line-height, 20px);
              ">
                Inbound Service Level
              </span>
            </div>
          </div>

          <!-- DC Name -->
          <div style="
            color: var(--Cencora-text-heading, var(--color-text-heading, #1E1E1E));
            font-family: var(--text-body-sm-font-family, Cencora-Gilroy);
            font-size: var(--text-body-2xs-font-size, 12px);
            font-style: normal;
            font-weight: 700;
            line-height: var(--text-body-sm-line-height, 20px);
            margin-bottom: 6px;
          ">
            DC Name: <span style="
              color: var(--Cencora-text-heading, var(--color-text-heading, #1E1E1E));
              font-family: var(--text-body-sm-font-family, Cencora-Gilroy);
              font-size: var(--text-body-2xs-font-size, 12px);
              font-style: normal;
              font-weight: 500;
              line-height: var(--text-body-sm-line-height, 20px);
            ">${plant.name}</span>
          </div>

          <!-- City -->
          <div style="
            color: var(--Cencora-text-heading, var(--color-text-heading, #1E1E1E));
            font-family: var(--text-body-sm-font-family, Cencora-Gilroy);
            font-size: var(--text-body-2xs-font-size, 12px);
            font-style: normal;
            font-weight: 700;
            line-height: var(--text-body-sm-line-height, 20px);
            margin-bottom: 16px;
          ">
            City: <span style="
              color: var(--Cencora-text-heading, var(--color-text-heading, #1E1E1E));
              font-family: var(--text-body-sm-font-family, Cencora-Gilroy);
              font-size: var(--text-body-2xs-font-size, 12px);
              font-style: normal;
              font-weight: 500;
              line-height: var(--text-body-sm-line-height, 20px);
            ">${plant.city}</span>
          </div>

          <!-- Mini Chart Section -->
          <div style="
            background: var(--color-neutral-50, #F5F5F5);
            border-radius: 4px;
            border: var(--stroke-weight-1, 1px) solid var(--color-neutral-200, #CACACA);
            padding: 12px;
            margin-bottom: 8px;
            height: 93px;
          ">
            <div style="
              font-size: 11px;
              font-weight: 500;
              color: #6b7280;
              text-transform: uppercase;
              letter-spacing: 0.5px;
              margin-bottom: 6px;
            ">
              FILL RATE TREND 30 DAYS
            </div>
            <div style="
              color: var(--Pale-Sky, var(--color-grey-46, #6B7280));
              font-family: system-ui, -apple-system, sans-serif;
              font-size: 10px;
              font-style: normal;
              font-weight: var(--font-weight-400, 400);
              line-height: var(--line-height-19_2, 19.2px);
              margin-bottom: 10px;
            ">
              AVG ${avgFillRate.toFixed(2)}%
            </div>

            <!-- Mini SVG Chart with Hover Points -->
            <div style="position: relative; overflow: visible; height: 35px;">
              <svg width="200" height="35" style="width: 100%; height: 35px; max-width: 100%;" id="chart-${plant.id}">
                <defs>
                  <linearGradient id="miniGradient-${plant.id}" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#6B46C1" stop-opacity="0.3"/>
                    <stop offset="100%" stop-color="#6B46C1" stop-opacity="0.05"/>
                  </linearGradient>
                </defs>
                ${
                  chartData.length > 0
                    ? `
                <polyline
                  points="${polylinePoints}"
                  fill="none"
                  stroke="#6B46C1"
                  stroke-width="2"
                  style="filter: drop-shadow(0 1px 2px rgba(0,0,0,0.1));"
                />
                <polygon
                  points="${polygonPoints}"
                  fill="url(#miniGradient-${plant.id})"
                />
                ${hoverCircles}
                `
                    : '<text x="100" y="17" text-anchor="middle" fill="#6b7280" font-size="10px">No data available</text>'
                }
              </svg>

              <!-- Tooltip Container -->
              <div id="tooltip-${plant.id}" class="chart-tooltip-container" style="
                position: absolute;
                display: none;
                pointer-events: auto;
                z-index: 999999;
                filter: drop-shadow(0 4px 6px rgba(0,0,0,0.1));
              "></div>
            </div>
          </div>
        </div>
      `;

    // Use popup instead of tooltip for better hover control
    plantMarker.bindPopup(plantTooltipContent, {
      closeButton: false,
      autoClose: false,
      closeOnClick: false,
      autoPan: false,
      className: "custom-tooltip-popup",
      maxWidth: 320,
      offset: [0, -15],
    });

    // Store ZIP markers and lines for this plant (initially hidden)
    const zipMarkers: L.CircleMarker[] = [];
    const connectionLines: L.Polyline[] = [];
    let isExpanded = false;

    // Create ZIP code markers and connection lines (but don't add to map yet)
    for (const zipCode of plant.coverage_zip_codes) {
      const cleanZip = zipCode.replace(/[^0-9]/g, "").substring(0, 5);
      const coords = geocodedZipCodes.get(cleanZip);

      if (coords) {
        // Create ZIP code marker (smaller bullet point)
        const zipMarker = L.circleMarker([coords.latitude, coords.longitude], {
          radius: 4,
          fillColor: plantColor,
          color: "#ffffff",
          weight: 1,
          opacity: 1,
          fillOpacity: 1,
        });

        zipMarkers.push(zipMarker);

        // Create connection line from plant to ZIP code
        const connectionLine = L.polyline(
          [
            [plant.latitude, plant.longitude],
            [coords.latitude, coords.longitude],
          ],
          {
            color: plantColor,
            weight: 2,
            opacity: 0.6,
            dashArray: "5,5",
          }
        );

        connectionLines.push(connectionLine);
      }
    }

    // Add click handler to show/hide ZIP codes
    plantMarker.on("click", function () {
      if (!isExpanded) {
        // Show ZIP codes and lines first
        connectionLines.forEach(line => map.addLayer(line));
        zipMarkers.forEach(marker => map.addLayer(marker));

        // Bring plant marker to front so it's above all lines and ZIP markers
        plantMarker.bringToFront();

        isExpanded = true;

        // Keep marker at normal size but ensure it's visible above lines
        plantMarker.setStyle({
          radius: 6,
          weight: 3,
          fillOpacity: 1,
          opacity: 1,
        });
      } else {
        // Hide ZIP codes and lines
        zipMarkers.forEach(marker => map.removeLayer(marker));
        connectionLines.forEach(line => map.removeLayer(line));
        isExpanded = false;

        // Reset marker size
        plantMarker.setStyle({
          radius: 6,
          weight: 3,
          fillOpacity: 1,
          opacity: 1,
        });
      }
    });

    // Popup hover management - much more reliable than tooltip
    let closeTimeout: NodeJS.Timeout | null = null;
    let isOverPopup = false;
    let isOverMarker = false;

    // Function to close popup
    const closePopup = () => {
      if (!isOverPopup && !isOverMarker) {
        plantMarker.closePopup();
      }
    };

    // Marker hover handlers
    plantMarker.on({
      mouseover: function (e) {
        const layer = e.target;
        isOverMarker = true;

        layer.bringToFront();
        layer.setStyle({
          radius: 8,
          weight: 3,
        });

        // Cancel any pending close
        if (closeTimeout) {
          clearTimeout(closeTimeout);
          closeTimeout = null;
        }

        const popup = plantMarker.getPopup();
        if (popup) {
          const markerLatLng = plantMarker.getLatLng();
          const containerPoint = map.latLngToContainerPoint(markerLatLng);
          const mapHeight = map.getSize().y;

          if (containerPoint.y < mapHeight * 0.55) {
            popup.options.offset = L.point(0, 260);
          } else {
            popup.options.offset = L.point(0, -15);
          }
        }

        layer.openPopup();
      },
      mouseout: function (e) {
        const layer = e.target;
        isOverMarker = false;

        layer.setStyle({
          radius: 6,
          weight: 3,
        });

        // Close immediately
        closePopup();
      },
    });

    plantMarker.on("popupopen", function () {
      cleanupPopupDom(plantMarker, popupState);

      const setupHover = () => {
        const popup = plantMarker.getPopup();
        if (!popup) return;

        const popupEl = popup.getElement();
        if (!popupEl) return;

        const handleEnter = () => {
          isOverPopup = true;
          if (closeTimeout) {
            clearTimeout(closeTimeout);
            closeTimeout = null;
          }
        };

        const handleLeave = () => {
          isOverPopup = false;
          closePopup();
        };

        const old = (popupEl as { _popupHover?: { enter: EventListener; leave: EventListener } })._popupHover;
        if (old) {
          popupEl.removeEventListener("mouseenter", old.enter);
          popupEl.removeEventListener("mouseleave", old.leave);
        }

        popupEl.addEventListener("mouseenter", handleEnter);
        popupEl.addEventListener("mouseleave", handleLeave);

        (popupEl as { _popupHover?: { enter: EventListener; leave: EventListener } })._popupHover = {
          enter: handleEnter,
          leave: handleLeave,
        };

        const chartPoints = popupEl.querySelectorAll(".chart-hover-point");
        const tooltipContainer = popupEl.querySelector(`#tooltip-${plant.id}`) as HTMLElement | null;

        chartPoints.forEach(circle => {
          const onChartEnter = (e: Event) => {
            const target = e.target as SVGCircleElement;
            target.style.opacity = "1";

            if (tooltipContainer) {
              const date = target.getAttribute("data-date") || "";
              const fillRate = target.getAttribute("data-fill-rate") || "0";
              const shippedQty = target.getAttribute("data-shipped-qty") || "0";
              const orderQty = target.getAttribute("data-order-qty") || "0";
              const xPos = target.getAttribute("data-x") || "0";

              tooltipContainer.style.display = "block";
              tooltipContainer.style.left = `${xPos}px`;
              tooltipContainer.style.top = "-80px";

              if (!popupState.tooltipRoot) {
                popupState.tooltipRoot = createRoot(tooltipContainer);
              }
              popupState.tooltipRoot.render(
                <ChartPointTooltip date={date} fillRate={fillRate} shippedQty={shippedQty} orderQty={orderQty} />
              );
            }
          };

          const onChartLeave = (e: Event) => {
            const target = e.target as SVGCircleElement;
            target.style.opacity = "0";

            if (tooltipContainer && !tooltipContainer.matches(":hover")) {
              tooltipContainer.style.display = "none";
            }
          };

          circle.addEventListener("mouseenter", onChartEnter);
          circle.addEventListener("mouseleave", onChartLeave);
          popupState.chartListeners.push(
            { element: circle, type: "mouseenter", handler: onChartEnter },
            { element: circle, type: "mouseleave", handler: onChartLeave }
          );
        });

        if (tooltipContainer) {
          const onTooltipEnter = () => {
            tooltipContainer.style.display = "block";
          };
          const onTooltipLeave = () => {
            tooltipContainer.style.display = "none";
          };

          tooltipContainer.addEventListener("mouseenter", onTooltipEnter);
          tooltipContainer.addEventListener("mouseleave", onTooltipLeave);
          popupState.tooltipContainerListeners.push(
            { element: tooltipContainer, type: "mouseenter", handler: onTooltipEnter },
            { element: tooltipContainer, type: "mouseleave", handler: onTooltipLeave }
          );
        }
      };

      popupState.setupHoverTimeouts.push(setTimeout(setupHover, 10));
      popupState.setupHoverTimeouts.push(setTimeout(setupHover, 50));
    });

    plantMarker.on("popupclose", function () {
      isOverPopup = false;
      if (closeTimeout) {
        clearTimeout(closeTimeout);
        closeTimeout = null;
      }
      cleanupPopupDom(plantMarker, popupState);
    });

    // Add hover effects for ZIP markers
    zipMarkers.forEach(zipMarker => {
      zipMarker.on({
        mouseover: function (e) {
          const layer = e.target;
          layer.setStyle({
            radius: 6,
            weight: 2,
          });
          layer.openTooltip();
        },
        mouseout: function (e) {
          const layer = e.target;
          layer.setStyle({
            radius: 4,
            weight: 1,
          });
          layer.closeTooltip();
        },
      });
    });

    plantMarker.addTo(map);

    return () => {
      if (closeTimeout) {
        clearTimeout(closeTimeout);
        closeTimeout = null;
      }

      cleanupPopupDom(plantMarker, popupState);

      if (isExpanded) {
        connectionLines.forEach(line => {
          if (map.hasLayer(line)) {
            map.removeLayer(line);
          }
        });
        zipMarkers.forEach(marker => {
          if (map.hasLayer(marker)) {
            map.removeLayer(marker);
          }
        });
      }

      zipMarkers.forEach(marker => {
        marker.off();
        if (map.hasLayer(marker)) {
          map.removeLayer(marker);
        }
      });

      connectionLines.forEach(line => {
        if (map.hasLayer(line)) {
          map.removeLayer(line);
        }
      });

      plantMarker.closePopup();
      plantMarker.off();
      if (map.hasLayer(plantMarker)) {
        map.removeLayer(plantMarker);
      }
    };
  } catch (error) {
    console.error(`Error creating interactive plant marker for ${plant.name}:`, error);
    return undefined;
  }
};

// Component to handle plant markers and US states background
const PlantMarkersLayer: React.FC<{ data: any[] }> = ({ data }) => {
  const map = useMap();

  useEffect(() => {
    if (!map) return;

    let cancelled = false;
    const markerCleanups: Array<() => void> = [];
    let statesLayer: L.GeoJSON | null = null;

    const runCleanup = () => {
      cancelled = true;
      markerCleanups.forEach(cleanup => cleanup());
      markerCleanups.length = 0;
      if (statesLayer && map.hasLayer(statesLayer)) {
        map.removeLayer(statesLayer);
        statesLayer = null;
      }
      clearNonTileLayers(map);
    };

    if (!data.length) {
      clearNonTileLayers(map);
      return runCleanup;
    }

    clearNonTileLayers(map);

    const geojsonData = usStatesData as GeoJSON.FeatureCollection;

    statesLayer = L.geoJSON(geojsonData, {
      style: {
        fillColor: "var(--color-neutral-200, #CACACA)",
        color: "#ffffff",
        weight: 1,
        opacity: 1,
        fillOpacity: 1,
      },
    }).addTo(map);

    const calculateAverageFillRate = (levels: any[]): number => {
      if (!levels || levels.length === 0) return 0;
      let totalFillRate = 0;
      let count = 0;
      levels.forEach(level => {
        if (level.total_order_qty && level.total_order_qty > 0) {
          const fillRate = (level.total_received_qty || 0) / level.total_order_qty;
          totalFillRate += fillRate;
          count++;
        }
      });
      return count > 0 ? (totalFillRate / count) * 100 : 0;
    };

    const processPlantCoverage = async () => {
      try {
        if (cancelled) return;

        const allZipCoordinates = await generateAllZipCoordinatesInstantly(data);
        if (cancelled) return;

        for (const plantData of data) {
          if (cancelled) return;

          const { plant } = plantData;
          const avgFillRatePercentage = calculateAverageFillRate(plantData.service_levels);
          const avgServiceLevel = avgFillRatePercentage / 100;
          const impact = getImpactLevel(avgServiceLevel);
          const plantColor = getImpactColor(impact);

          const cleanup = createInteractivePlantMarkers(map, plant, plantColor, allZipCoordinates, plantData.service_levels);
          if (cleanup) {
            markerCleanups.push(cleanup);
          }
        }
      } catch (error) {
        console.error("Error processing plant coverage:", error);
      }
    };

    void processPlantCoverage();

    return runCleanup;
  }, [map, data]);

  return null;
};

// Component to add global styles
const MapStyles: React.FC = () => {
  useEffect(() => {
    const styleId = "inbound-service-level-map-styles";

    if (!document.getElementById(styleId)) {
      const styleSheet = document.createElement("style");
      styleSheet.id = styleId;
      styleSheet.textContent = `
      .leaflet-container {
        background: #f8fafc;
        overflow: hidden !important;
      }
      .leaflet-map-pane {
        overflow: visible !important;
      }
      /* Custom popup styling (using popup instead of tooltip for better hover) */
      .leaflet-popup-pane {
        z-index: 999999 !important;
        pointer-events: none !important;
      }
      .leaflet-popup.custom-tooltip-popup {
        pointer-events: auto !important;
        margin-bottom: 20px !important;
        z-index: 999999 !important;
      }
      .chart-tooltip-container {
        z-index: 999999 !important;
      }
      .leaflet-popup.custom-tooltip-popup .leaflet-popup-content-wrapper {
        background: transparent !important;
        border: none !important;
        box-shadow: none !important;
        padding: 0 !important;
        border-radius: 0 !important;
        pointer-events: auto !important;
        overflow: visible !important;
      }
      .leaflet-popup.custom-tooltip-popup .leaflet-popup-content {
        margin: 0 !important;
        padding: 0 !important;
        pointer-events: auto !important;
        overflow: visible !important;

      }
      .leaflet-popup.custom-tooltip-popup .leaflet-popup-tip-container {
        display: none !important;
      }
      .leaflet-popup.custom-tooltip-popup * {
        pointer-events: auto !important;
      }
      .leaflet-interactive:focus {
        outline: none !important;
        box-shadow: none !important;
      }
      .leaflet-interactive:active {
        outline: none !important;
        box-shadow: none !important;
      }
      .leaflet-interactive {
        outline: none !important;
        -webkit-tap-highlight-color: transparent !important;
        -webkit-focus-ring-color: transparent !important;
        user-select: none !important;
        -webkit-user-select: none !important;
        -moz-user-select: none !important;
        -ms-user-select: none !important;
      }
      .leaflet-interactive * {
        outline: none !important;
        box-shadow: none !important;
      }
      .leaflet-interactive:focus-visible {
        outline: none !important;
        box-shadow: none !important;
      }
      .plant-marker {
        filter: drop-shadow(0 2px 2px rgba(0, 0, 0, 0.09)) drop-shadow(0 0 1px rgba(0, 0, 0, 0.45));
      }
    `;
      document.head.appendChild(styleSheet);
    }

    return () => {
      const existingStyle = document.getElementById(styleId);
      existingStyle?.remove();
    };
  }, []);

  return null;
};

export const InboundServiceLevelTrend: React.FC<InboundServiceLevelTrendProps> = ({ className = "" }) => {
  const { data, loading, error } = useServiceLevelData();
  const [selectedImpact, setSelectedImpact] = useState<"high" | "medium" | "low">("high");

  const legendItems = [
    { color: "#461E96", label: "High Impact", description: "< 41%" },
    { color: "var(--Cencora-accent-expanded-400, #EC4899)", label: "Medium Impact", description: "41% - 80%" },
    { color: "var(--Cencora-highlight-300-core, #06B6D4)", label: "Low Impact", description: "≥ 81%" },
  ];

  // Transform plant data to plant-level data for table
  const plantTableData = useMemo(() => {
    return data
      .map(plantData => {
        let avgFillRate = 0;
        if (plantData.service_levels && plantData.service_levels.length > 0) {
          let totalFillRate = 0;
          let count = 0;
          plantData.service_levels.forEach(level => {
            const orderQty = level.total_order_qty ?? 0;
            const receivedQty = level.total_received_qty ?? 0;
            if (orderQty > 0) {
              totalFillRate += receivedQty / orderQty;
              count++;
            }
          });
          avgFillRate = count > 0 ? totalFillRate / count : 0;
        }

        const fillRatePercent = avgFillRate * 100;
        const impact = getImpactLevel(avgFillRate);

        return {
          plantName: plantData.plant.name || "-",
          plantNbr: plantData.plant.plant_nbr || plantData.plant.id?.toString() || "-",
          state: plantData.plant.state || "-",
          city: plantData.plant.city || "-",
          fillRate: fillRatePercent,
          impact,
          // Calculate trend as quantity difference (commented out)
          // const previousServiceLevel = plantData.service_levels.length > 1
          //   ? plantData.service_levels[plantData.service_levels.length - 2]
          //   : null;
          // const currentReceivedQty = latestServiceLevel?.total_received_qty || 0;
          // const previousReceivedQty = previousServiceLevel?.total_received_qty || 0;
          // trend: currentReceivedQty - previousReceivedQty,
        };
      })
      .filter(item => {
        // Filter by selected impact level
        return item.impact === selectedImpact;
      })
      .sort((a, b) => {
        // Sort by plant name
        return a.plantName.localeCompare(b.plantName);
      });
  }, [data, selectedImpact]);

  if (error) {
    return (
      <div className={`bg-ui-background-primary rounded-[10px] border border-[#E2E8F0] p-6 ${className}`}>
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <p className="text-red-600 mb-2">Error loading service level data</p>
            <p className="text-sm text-ui-text-muted">{error}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-ui-background-primary rounded-[10px] border border-[#E2E8F0] ${className}`}>
      <div className="p-6 border-b border-ui-border-primary" style={{ overflow: "visible" }}>
        <div className="flex flex-row items-center space-x-2 mb-2">
          <h2 className="text-ui-text-primary font-[700] text-xl leading-[28.8px]">Inbound Fill Rate by Distribution Center</h2>
          <InfoIcon
            className="text-brand-primary-700"
            tooltip="Shows the average inbound fill rate by distribution center, with impact levels scaled by fill rate. Hover over a distribution center to view its 30-day inbound fill rate trend quantity and coverage area. Each coverage area represents a unique ZIP code that is serviced by the distribution center marked with a circle and a line connecting it to the distribution center."
          />
        </div>
        <p className="text-sm text-ui-text-muted font-normal mb-4">
          Displays the average inbound fill rate by distribution center, with impact levels scaled by fill rate. Hover over a
          distribution center to view its 30-day inbound fill rate trend quantity and coverage area.
        </p>

        <div className="flex items-center space-x-6">
          {legendItems.map(item => (
            <div key={item.label} className="flex items-center space-x-2">
              <div
                style={{
                  borderRadius: "2px",
                  background: item.color,
                  width: "10px",
                  height: "10px",
                  flexShrink: 0,
                }}
              />
              <span className="text-sm text-ui-text-primary font-medium">
                {item.label} <span className="text-xs text-ui-text-muted font-normal">({item.description})</span>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="p-6" style={{ overflow: "hidden" }}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Map Section */}
          <div className="relative" style={{ overflow: "hidden" }}>
            {loading && (
              <div className="absolute inset-0 bg-ui-background-primary/80 flex items-center justify-center z-10 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Spinner size="sm" />
                  <span className="text-sm text-ui-text-muted">Loading distribution centers...</span>
                </div>
              </div>
            )}
            <div className="relative h-[470px] bg-gray-200 rounded-[10px]" style={{ position: "relative", overflow: "hidden" }}>
              <style>
                {`
                  .custom-tooltip {
                    background: transparent !important;
                    border: none !important;
                    box-shadow: none !important;
                    padding: 0 !important;
                    pointer-events: auto !important;
                    overflow: visible !important;
                    z-index: 999999 !important;
                  }
                  .custom-tooltip:hover {
                    z-index: 999999 !important;
                    opacity: 1 !important;
                  }
                  .custom-tooltip .leaflet-tooltip-content {
                    background: transparent !important;
                    margin: 0 !important;
                    padding: 0 !important;
                  }
                  .custom-tooltip .leaflet-tooltip-tip {
                    background: var(--background-brand-secondary) !important;
                    border: none !important;
                  }
                `}
              </style>
              <MapContainer
                center={[39.0, -96.5]}
                zoom={4}
                minZoom={2}
                maxZoom={7}
                zoomControl={true}
                attributionControl={false}
                scrollWheelZoom={true}
                doubleClickZoom={true}
                dragging={true}
                boxZoom={false}
                keyboard={false}
                touchZoom={true}
                maxBoundsViscosity={1.0}
                className="w-full h-full rounded-lg border border-ui-border-primary"
                maxBounds={[
                  [24.0, -125.0],
                  [50.0, -66.0],
                ]}
                style={{ position: "relative", overflow: "hidden" }}
              >
                <MapStyles />
                <PlantMarkersLayer data={data} />
              </MapContainer>
            </div>
          </div>

          {/* Table Section */}
          <div className="flex flex-col rounded-[10px] border-1 border-[#E2E8F0] p-4">
            {/* Impact Filters and Time Period */}
            <div className="flex items-center gap-3 mb-4 flex-wrap ">
              <div className="inline-flex flex-wrap w-fit rounded-[4px] items-center gap-2 border-1 border-[#CBD5E1]">
                {(["high", "medium", "low"] as const).map(impact => (
                  <button
                    key={impact}
                    onClick={() => setSelectedImpact(impact)}
                    className={`px-4 py-2 rounded-md text-sm font-semibold transition-colors ${
                      selectedImpact === impact
                        ? "bg-brand-primary-main text-white"
                        : "bg-ui-background-primary text-ui-text-primary hover:bg-ui-background-muted"
                    }`}
                  >
                    {impact === "high" ? "High Impact" : impact === "medium" ? "Medium Impact" : "Low Impact"}
                  </button>
                ))}
              </div>
            </div>

            {/* Data Table */}
            <div className="h-[380px] overflow-y-auto border border-[#E2E8F0] rounded-[16px]">
              <table className="w-full text-sm">
                <thead className="bg-[#F8FAFC] border-b border-[#E2E8F0]">
                  <tr>
                    <th className="px-4 py-3 text-left font-bold text-ui-text-primary">Plant Name</th>
                    <th className="px-4 py-3 text-left font-bold text-ui-text-primary">Plant NBR</th>
                    <th className="px-4 py-3 text-left font-bold text-ui-text-primary">State</th>
                    <th className="px-4 py-3 text-left font-bold text-ui-text-primary">City</th>
                    <th className="px-4 py-3 text-left font-bold text-ui-text-primary">Inbound Fill Rate</th>
                    {/* <th className="px-4 py-3 text-left font-bold text-ui-text-primary">Trend Analysis</th> */}
                  </tr>
                </thead>
                <tbody>
                  {plantTableData.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-6 text-center text-ui-text-muted">
                        No data available for {selectedImpact} impact
                      </td>
                    </tr>
                  ) : (
                    plantTableData.map((item, index) => {
                      return (
                        <tr key={index} className="border-b border-ui-border-primary hover:bg-ui-background-muted">
                          <td className="px-4 py-3 text-ui-text-primary">{item.plantName}</td>
                          <td className="px-4 py-3 text-ui-text-primary">{item.plantNbr}</td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <img src={usaFlag} alt={item.state} className="w-4 h-4" />
                              <span className="font-medium text-ui-text-primary">{item.state}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-ui-text-primary">{item.city}</td>
                          <td className="px-4 py-3 text-ui-text-primary">{item.fillRate.toFixed(2)}%</td>
                          {/* Trend Analysis column - commented out
                          <td className="px-4 py-3">
                            <span
                              className={`inline-flex items-center gap-1 px-1 rounded-md text-sm font-medium border-1 ${
                                item.trend >= 0
                                  ? "bg-green-50 text-green-700 border-[#8AF6BB]"
                                  : "bg-red-50 text-red-700 border-[#FDAC9A]"
                              }`}
                            >
                              {item.trend >= 0 ? (
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                                </svg>
                              ) : (
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                                </svg>
                              )}
                              {item.trend >= 0 ? `+${Math.abs(item.trend).toLocaleString('en-US')}` : `-${Math.abs(item.trend).toLocaleString('en-US')}`}
                            </span>
                          </td>
                          */}
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InboundServiceLevelTrend;
