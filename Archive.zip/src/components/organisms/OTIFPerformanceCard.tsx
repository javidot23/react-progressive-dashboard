"use client";
import InfoIcon from "@/components/atoms/InfoIcon";
import { ComposedChart, Bar, Line, XAxis, YAxis, ResponsiveContainer, CartesianGrid, Tooltip, DotProps, Cell } from "recharts";
import { useWeeklyOtifLineCountsQuery } from "@/hooks/queries/useMainKpiQueries";
import { useMemo } from "react";
import { GraphCardSkeleton, EmptyState } from "@/components/molecules";
import { AccessibleChart } from "@/components/atoms/AccessibleChart";
import Legend, { LegendItem } from "@/components/atoms/Legend";
import CardLayout from "@/components/templates/CardLayout";
import { Link, useLocation } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { ROUTES } from "@/constants/routes";

const CARD_MIN_HEIGHT = "560px";
const MIN_CHART_HEIGHT = "350px";
const CHART_MARGIN = { top: 20, right: 0, left: 0, bottom: 20 };
const MAX_BAR_SIZE = 30;
const INCOMPLETE_WEEK_BAR_OPACITY = 0.45;
const LINE_STROKE_WIDTH = 3;
const OTIF_LINE_COLOR = "#053E67";

const CARD_TITLE = "OTIF Performance Over Time";
const CARD_DESCRIPTION = "Weekly trend of inbound order quantities delivered on time and in full for the last 90 days.";
const INFO_TOOLTIP_BASE =
  "This visual provides the OTIF line counts trend with bars showing different line count categories (OTIF, OT but not IF, IF but not OT, NOT OT or IF). The blue line indicates the overall OTIF percentage for the last 90 days.";
const INFO_TOOLTIP_CTA = " Click view more to go to the manage module.";

const LEGEND_ITEMS: LegendItem[] = [
  { id: "otif-lines", color: "#735CCC", label: "OTIF Lines", shape: "square" },
  { id: "ot-not-if", color: "#00B4E6", label: "On time not in full", shape: "square" },
  { id: "if-not-ot", color: "#B7E8FE", label: "In full not on time", shape: "square" },
  { id: "not-ot-or-if", color: "#FCA2C9", label: "Not on time or in full", shape: "square" },
  { id: "otif-percentage", color: OTIF_LINE_COLOR, label: "OTIF %", shape: "line" },
];

const formatQuantity = (value: number) => {
  if (value >= 1000) {
    return `${(value / 1000).toFixed(0)}K`;
  }
  return value.toString();
};

const formatOTIFPercentage = (value: number) => {
  return `${value}%`;
};

const getWeekDates = (year: number, week: number): { weekStart: Date; weekEnd: Date } => {
  const jan4 = new Date(year, 0, 4);
  const jan4Day = jan4.getDay() || 7;
  const daysToMonday = jan4Day - 1;

  const week1Monday = new Date(year, 0, 4 - daysToMonday);

  const targetWeekMonday = new Date(week1Monday);
  targetWeekMonday.setDate(week1Monday.getDate() + (week - 1) * 7);

  const weekEnd = new Date(targetWeekMonday);
  weekEnd.setDate(targetWeekMonday.getDate() + 6);

  return {
    weekStart: targetWeekMonday,
    weekEnd: weekEnd,
  };
};

const formatDate = (date: Date): string => {
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
};

const startOfLocalDay = (d: Date): Date => {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
};

/** Week is still in progress when today falls within [weekStart, weekEnd] (inclusive, local dates). */
const isIncompleteWeek = (weekStart: Date, weekEnd: Date, now: Date = new Date()): boolean => {
  const today = startOfLocalDay(now);
  const start = startOfLocalDay(weekStart);
  const end = startOfLocalDay(weekEnd);
  return today >= start && today <= end;
};

interface TooltipPayload {
  payload: {
    otif?: number;
    otifCount?: number;
    otButNotIfCount?: number;
    ifButNotOtCount?: number;
    notOtOrIfCount?: number;
    totalLines?: number;
    weekRange?: string;
    isIncompleteWeek?: boolean;
  };
}

interface OTIFTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}

const OTIFTooltip = ({ active, payload, label }: OTIFTooltipProps) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const otifPercentage = data.otif || 0;
    const otifCount = data.otifCount || 0;
    const otButNotIfCount = data.otButNotIfCount || 0;
    const ifButNotOtCount = data.ifButNotOtCount || 0;
    const notOtOrIfCount = data.notOtOrIfCount || 0;
    const totalLines = data.totalLines || 0;
    const weekRange = data.weekRange || label;
    const incompleteWeek = Boolean(data.isIncompleteWeek);

    // Color mapping for the categories
    const categoryColors = {
      "OTIF Lines": "#735CCC",
      "On time not in full": "#00B4E6",
      "In full not on time": "#B7E8FE",
      "Not on time or in full": "#FCA2C9",
      "OTIF %": "#053E67",
    };

    return (
      <div className="bg-white border border-gray-200 text-gray-900 text-xs rounded-md shadow-lg w-[250px] p-3 font-normal z-30">
        <div className="flex flex-col gap-2">
          <div className="flex items-center space-x-1">
            <span className="text-gray-600">Week:</span>
            <span className="text-gray-900 font-medium">{weekRange}</span>
          </div>
          {incompleteWeek && (
            <p className="text-xs font-medium text-ui-text-secondary border-b border-gray-100 pb-2">Incomplete week</p>
          )}
          {otifCount > 0 && (
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: categoryColors["OTIF Lines"] }}></div>
              <div className="flex items-center space-x-1">
                <span className="text-gray-600">OTIF Lines:</span>
                <span className="text-gray-900 font-medium">{otifCount.toLocaleString()}</span>
              </div>
            </div>
          )}
          {otButNotIfCount > 0 && (
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: categoryColors["On time not in full"] }}></div>
              <div className="flex items-center space-x-1">
                <span className="text-gray-600">On time not in full:</span>
                <span className="text-gray-900 font-medium">{otButNotIfCount.toLocaleString()}</span>
              </div>
            </div>
          )}
          {ifButNotOtCount > 0 && (
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: categoryColors["In full not on time"] }}></div>
              <div className="flex items-center space-x-1">
                <span className="text-gray-600">In full not on time:</span>
                <span className="text-gray-900 font-medium">{ifButNotOtCount.toLocaleString()}</span>
              </div>
            </div>
          )}
          {notOtOrIfCount > 0 && (
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: categoryColors["Not on time or in full"] }}></div>
              <div className="flex items-center space-x-1">
                <span className="text-gray-600">Not on time or in full:</span>
                <span className="text-gray-900 font-medium">{notOtOrIfCount.toLocaleString()}</span>
              </div>
            </div>
          )}
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: categoryColors["OTIF %"] }}></div>
            <div className="flex items-center space-x-1">
              <span className="text-gray-600">OTIF Performance:</span>
              <span className="text-gray-900 font-medium">{otifPercentage.toFixed(2)}%</span>
            </div>
          </div>
          <div className="flex items-center space-x-1 border-t border-gray-200 pt-2 mt-1">
            <span className="text-gray-600 font-medium">Total Lines:</span>
            <span className="text-gray-900 font-medium">{totalLines.toLocaleString()}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

// Custom dot component with white center
const CustomDot = (props: DotProps & { fill?: string }) => {
  const { cx, cy, fill } = props;
  if (cx === undefined || cy === undefined) return null;
  return (
    <g>
      <circle cx={cx} cy={cy} r={5} fill={fill} />
      <circle cx={cx} cy={cy} r={2} fill="white" />
    </g>
  );
};

// Custom active dot component with white center
const CustomActiveDot = (props: DotProps & { fill?: string }) => {
  const { cx, cy, fill } = props;
  if (cx === undefined || cy === undefined) return null;
  return (
    <g>
      <circle cx={cx} cy={cy} r={7} fill={fill} />
      <circle cx={cx} cy={cy} r={3} fill="white" />
    </g>
  );
};

function normalizePathname(pathname: string): string {
  if (pathname.length > 1 && pathname.endsWith("/")) {
    return pathname.slice(0, -1);
  }
  return pathname;
}

export function OTIFPerformanceCard() {
  const location = useLocation();
  const showViewMoreLink = normalizePathname(location.pathname) !== ROUTES.MANAGE_OVERVIEW;
  const infoTooltipText = showViewMoreLink ? INFO_TOOLTIP_BASE + INFO_TOOLTIP_CTA : INFO_TOOLTIP_BASE;

  const { weeklyOtifLineCounts, isLoading: loading, isFetched, error } = useWeeklyOtifLineCountsQuery();

  const { chartData, maxValue } = useMemo(() => {
    if (!weeklyOtifLineCounts || weeklyOtifLineCounts.length === 0) return { chartData: [], maxValue: 1000 };

    let maxVal = 0;

    const data = weeklyOtifLineCounts.map(item => {
      const { weekStart, weekEnd } = getWeekDates(item.year, item.week);
      const weekStartFormatted = formatDate(weekStart);
      const weekEndFormatted = formatDate(weekEnd);
      const weekRange = `${weekStartFormatted} - ${weekEndFormatted}`;
      const incompleteWeek = isIncompleteWeek(weekStart, weekEnd);

      const otifPercentage = item.otif_percentage || 0;

      const weekMax = Math.max(item.otif_count, item.ot_but_not_if_count, item.if_but_not_ot_count, item.not_ot_or_if_count);
      maxVal = Math.max(maxVal, weekMax);

      return {
        week: weekStartFormatted,
        weekRange: weekRange,
        otifCount: item.otif_count,
        otButNotIfCount: item.ot_but_not_if_count,
        ifButNotOtCount: item.if_but_not_ot_count,
        notOtOrIfCount: item.not_ot_or_if_count,
        otif: otifPercentage,
        totalLines: item.total_lines,
        isIncompleteWeek: incompleteWeek,
      };
    });

    let calculatedMax;
    if (maxVal <= 100) {
      calculatedMax = Math.ceil(maxVal / 10) * 10;
    } else if (maxVal <= 500) {
      calculatedMax = Math.ceil(maxVal / 50) * 50;
    } else if (maxVal <= 1000) {
      calculatedMax = Math.ceil(maxVal / 100) * 100;
    } else {
      calculatedMax = Math.ceil(maxVal / 500) * 500;
    }

    const finalMax = Math.max(calculatedMax, 100);

    return { chartData: data, maxValue: finalMax };
  }, [weeklyOtifLineCounts]);

  const hasData = weeklyOtifLineCounts && weeklyOtifLineCounts.length > 0;
  const hasEverFetched = isFetched;

  // Show skeleton only when loading AND no data, OR when never fetched
  if ((loading && !hasData) || (!hasEverFetched && !error)) {
    return (
      <div className="relative h-full">
        <GraphCardSkeleton height={CARD_MIN_HEIGHT} />
      </div>
    );
  }

  if (hasEverFetched && !loading && !error && !hasData) {
    return (
      <div className="relative h-full">
        <CardLayout
          className="flex flex-col h-full"
          style={{ height: CARD_MIN_HEIGHT }}
          title={
            <span className="text-xl font-bold leading-[28.8px] text-heading font-brand max-sm:text-base max-sm:leading-[20.8px] max-sm:font-semibold">
              {CARD_TITLE}
            </span>
          }
          icon={<InfoIcon tooltip={infoTooltipText} />}
          subtitle={
            <>
              <p className="text-sm text-ui-text-secondary">{CARD_DESCRIPTION}</p>
              <hr className="my-2" />
              <Legend items={LEGEND_ITEMS} orientation="horizontal" spacing="md" />
            </>
          }
        >
          <div className="flex-1 flex flex-col px-4 pt-4 pb-0 min-h-0">
            <div className="flex-1 flex items-center justify-center">
              <EmptyState
                title="No Data Available"
                description="No OTIF performance data found for the selected filters. Try adjusting your filter criteria to see results."
              />
            </div>
          </div>
          {showViewMoreLink && (
            <div className="shrink-0 px-6 pb-6">
              <div className="flex justify-end">
                <Link
                  to={ROUTES.MANAGE_OVERVIEW}
                  state={{ scrollTo: "manage-navigation" }}
                  className="font-semibold text-brand-primary-main text-[14px] flex items-center gap-1"
                >
                  View More
                  <ChevronRight className="h-6 w-6 text-brand-primary-main" aria-hidden />
                </Link>
              </div>
            </div>
          )}
        </CardLayout>
      </div>
    );
  }

  return (
    <div className="relative h-full">
      <CardLayout
        className="flex flex-col h-full"
        style={{ height: CARD_MIN_HEIGHT, boxSizing: "border-box", marginBottom: "0" }}
        title={
          <span className="text-xl font-bold leading-[28.8px] text-heading font-brand max-sm:text-base max-sm:leading-[20.8px] max-sm:font-semibold">
            {CARD_TITLE}
          </span>
        }
        icon={<InfoIcon tooltip={infoTooltipText} />}
        subtitle={
          <>
            <p className="text-sm text-ui-text-secondary">{CARD_DESCRIPTION}</p>
            <hr className="my-2" />
            <Legend items={LEGEND_ITEMS} orientation="horizontal" spacing="md" />
          </>
        }
      >
        <div style={{ height: MIN_CHART_HEIGHT }}>
          {error && !loading && (
            <div className="absolute inset-0 flex items-center justify-center text-status-error-main z-10">
              <div className="text-center">
                <p className="text-sm font-medium">Failed to load data</p>
                <p className="text-xs text-ui-text-muted mt-1">{error}</p>
              </div>
            </div>
          )}
          <AccessibleChart ariaLabel={CARD_TITLE} className="h-full w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData} margin={CHART_MARGIN}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-ui-border-primary)" />

                <XAxis
                  dataKey="week"
                  axisLine={false}
                  tickLine={false}
                  interval={0}
                  tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                  angle={-70}
                  dx={-5}
                  dy={17}
                />

                <YAxis
                  yAxisId="quantity"
                  orientation="left"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                  domain={[0, maxValue]}
                  tickFormatter={formatQuantity}
                  label={{
                    value: "Lines",
                    angle: -90,
                    position: "insideLeft",
                    style: {
                      textAnchor: "middle",
                      fill: "var(--color-ui-text-muted)",
                      fontSize: "12px",
                    },
                  }}
                />

                <YAxis
                  yAxisId="otifPercentage"
                  orientation="right"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                  domain={[0, 100]}
                  tickFormatter={formatOTIFPercentage}
                  label={{
                    value: "Percentage",
                    angle: -90,
                    position: "insideRight",
                    style: {
                      textAnchor: "middle",
                      fill: "var(--color-ui-text-muted)",
                      fontSize: "12px",
                    },
                  }}
                />

                <Bar
                  yAxisId="quantity"
                  dataKey="otifCount"
                  stackId="quantity"
                  fill="#735CCC"
                  stroke="#735CCC"
                  strokeWidth={1}
                  radius={[0, 0, 0, 0]}
                  maxBarSize={MAX_BAR_SIZE}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`otifCount-${index}`} fillOpacity={entry.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1} />
                  ))}
                </Bar>

                <Bar
                  yAxisId="quantity"
                  dataKey="otButNotIfCount"
                  stackId="quantity"
                  fill="#00B4E6"
                  stroke="#00B4E6"
                  strokeWidth={1}
                  radius={[0, 0, 0, 0]}
                  maxBarSize={MAX_BAR_SIZE}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`otButNotIf-${index}`} fillOpacity={entry.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1} />
                  ))}
                </Bar>

                <Bar
                  yAxisId="quantity"
                  dataKey="ifButNotOtCount"
                  stackId="quantity"
                  fill="#B7E8FE"
                  stroke="#B7E8FE"
                  strokeWidth={1}
                  radius={[0, 0, 0, 0]}
                  maxBarSize={30}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`ifButNotOt-${index}`} fillOpacity={entry.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1} />
                  ))}
                </Bar>

                <Bar
                  yAxisId="quantity"
                  dataKey="notOtOrIfCount"
                  stackId="quantity"
                  fill="#FCA2C9"
                  stroke="#FCA2C9"
                  strokeWidth={1}
                  radius={[2, 2, 0, 0]}
                  maxBarSize={MAX_BAR_SIZE}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`notOtOrIf-${index}`} fillOpacity={entry.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1} />
                  ))}
                </Bar>

                <Tooltip
                  content={<OTIFTooltip />}
                  cursor={{ fill: "rgba(59, 41, 112, 0.1)" }}
                  allowEscapeViewBox={{ x: false, y: false }}
                  offset={10}
                />

                <Line
                  yAxisId="otifPercentage"
                  type="linear"
                  dataKey="otif"
                  stroke={OTIF_LINE_COLOR}
                  strokeWidth={LINE_STROKE_WIDTH}
                  dot={<CustomDot fill={OTIF_LINE_COLOR} />}
                  activeDot={<CustomActiveDot fill={OTIF_LINE_COLOR} />}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </AccessibleChart>
        </div>

        {showViewMoreLink && (
          <div className="shrink-0 mt-auto">
            <div className="flex justify-end">
              <Link
                to={ROUTES.MANAGE_OVERVIEW}
                state={{ scrollTo: "manage-navigation" }}
                className="font-semibold text-brand-primary-main text-[14px] flex items-center gap-1"
              >
                View More
                <ChevronRight className="h-6 w-6 text-brand-primary-main" aria-hidden />
              </Link>
            </div>
          </div>
        )}
      </CardLayout>
    </div>
  );
}
