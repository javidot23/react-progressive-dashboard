import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/atoms/Card";
import {Button} from "@/components/atoms/Button";
import {Info} from "lucide-react";
import { useLatestSupplyChainEventsQuery } from "@/hooks/queries/useSupplyChainEventsWithLocationQuery";

export function SmartInsightsCard() {
  const { supplyChainEvents, isLoading: loading, error } = useLatestSupplyChainEventsQuery(10);

  const latestEvents = supplyChainEvents.slice(0, 2);
  return (
    <Card className="h-[413px]">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-2 mb-1">
          <div
            className="flex items-center justify-center"
            style={{
              borderRadius: "8px",
              background: "var(--gradient-primary)",
              width: "36px",
              height: "36px",
            }}
          >
            <img
              src="/src/public/icons/alarm-bell.svg"
              alt="Supply Chain Events"
              className="w-5 h-5"
            />
          </div>
          <CardTitle className="text-lg font-semibold text-ui-text-primary">
            Smart Insights
          </CardTitle>
          <Info className="w-3 h-3 text-brand-primary-main" />
        </div>
        <CardDescription className="text-sm text-ui-text-secondary">
          AI-powered recommendations and alerts
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {loading && (
          <div className="text-center py-8 text-ui-text-muted">
            Loading insights...
          </div>
        )}
        {error && (
          <div className="text-center py-8 text-ui-text-muted">
            Error loading insights
          </div>
        )}
        {!loading && !error && latestEvents.length === 0 && (
          <div className="text-center py-8 text-ui-text-muted">
            No insights available
          </div>
        )}
        {!loading && !error && latestEvents.length > 0 && (
          <div className="space-y-4">
            {latestEvents.map(event => (
              <div
                key={event.id}
                className="p-4 border border-ui-border-primary rounded-lg"
              >
                <h4 className="font-semibold text-ui-text-primary mb-2">
                  {event.type}
                </h4>
                <p
                  className="text-ui-text-secondary mb-3"
                  style={{fontSize: "13px"}}
                >
                  {event.typeDescription}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="font-semibold text-brand-primary-main"
                  style={{
                    border: "2px solid var(--color-ui-border-secondary)",
                    borderRadius: "4px",
                  }}
                >
                  View Details
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
