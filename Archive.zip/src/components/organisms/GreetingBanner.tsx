import { useProfile } from "@/hooks/useProfile";
import { ReactNode } from "react";
import { Banner } from "@/components/organisms/Banner";

const getGreeting = (): string => {
  const hour = new Date().getHours();
  if (hour < 12) return "Good Morning";
  if (hour < 17) return "Good Afternoon";
  return "Good Evening";
};

const getUserDisplayName = (profile: ReturnType<typeof useProfile>["profile"]): string => {
  if (!profile) return "User";
  const name = profile.displayName || profile.givenName || profile.mail?.split("@")[0] || "User";
  return name.split(" ")[0];
};

interface GreetingBannerProps {
  rightSideContent?: ReactNode;
  description?: string;
}

export const GreetingBanner = ({ rightSideContent, description }: GreetingBannerProps) => {
  const { profile } = useProfile();
  const greeting = getGreeting();
  const displayName = getUserDisplayName(profile);

  return (
    <Banner
      backgroundClassName="bg-[url('/src/assets/images/greeting-banner.svg')]"
      title={`${greeting}, ${displayName}!`}
      titleClassName="text-xl lg:text-3xl xl:text-5xl"
      description={description || "Here's what's happening with your supply chain today"}
      rightSideContent={rightSideContent}
    />
  );
};
