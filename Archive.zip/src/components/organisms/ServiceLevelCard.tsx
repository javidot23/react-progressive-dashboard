"use client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/atoms/Card";
import { Button } from "@/components/atoms/Button";
import { ChevronRight } from "lucide-react";
import InfoIcon from "@/components/atoms/InfoIcon";
import { ComposedChart, Bar, Line, XAxis, YAxis, ResponsiveContainer, ReferenceLine, Tooltip } from "recharts";

import { useServiceLevelTrendQuery } from "@/hooks/queries/useServiceLevelQueries";
import { ModifyGoalModal, ModifyGoalData } from "@/components/organisms/ModifyGoalModal";
import { AccessibleChart } from "@/components/atoms/AccessibleChart";
import { useState, useRef, useEffect, useMemo, type ReactNode } from "react";
import type { ServiceLevelTrendDisplay } from "@/stores/slices/types";
import { getMySettings, patchMySettings } from "@/services/userSettingsService";
import { Link } from "react-router-dom";
import { GraphCardSkeleton, EmptyState } from "@/components/molecules";
import Legend, { LegendItem } from "@/components/atoms/Legend";
import { isVendorPortal } from "@/tenant";
import { getErrorMessage } from "@/lib/getErrorMessage";
import { toast } from "@/lib/toast";

const CARD_MIN_HEIGHT = "560px";
const MIN_CHART_HEIGHT = "370px";
const CHART_MARGIN = { top: 40, right: 20, left: 20, bottom: 20 };
const MAX_BAR_SIZE = 30;
const LINE_STROKE_WIDTH = 3;
const GOAL_LINE_COLOR = "#8F8F8F";
const ACTUAL_FILL_RATE_COLOR = "#00B4E6";
const PROJECTED_FILL_RATE_COLOR = "#DD7005";
const ORDER_QUANTITY_COLOR = "#C1BBEE";
const RECEIVED_QUANTITY_COLOR = "#8267CD";
const RECEIVED_QUANTITY_GRADIENT = "linear-gradient(180deg, #383874 0%, #5D50A0 18.27%, #8267CD 100%)";

const CHART_CATEGORY_COLORS = {
  "Order Quantity": ORDER_QUANTITY_COLOR,
  "Received Quantity": RECEIVED_QUANTITY_COLOR,
  "Fill Rate": ACTUAL_FILL_RATE_COLOR,
  "Projected Fill Rate": PROJECTED_FILL_RATE_COLOR,
  Goal: GOAL_LINE_COLOR,
} as const;

const TREND_DAYS = isVendorPortal() ? 90 : 30;
const CARD_TITLE = "Inbound Fill Rate Trend";
const CARD_DESCRIPTION_BASE = `Daily trend of inbound fill rates alongside quantities ordered and received for the last ${TREND_DAYS} days.`;
const INFO_TOOLTIP = `This visual provides the Inbound Service Level trend with the purple bars indicating the received quantity and the light purple column displaying order quantity. The light blue line indicates actual fill rate for the last ${TREND_DAYS} days. The dashed orange line indicates projected fill rate for the most recent 7 days based on maturity-weighted historical fill-rate patterns. The gray dotted line indicates the user-set service level goal which can be configured by clicking the modify goal button. Click view more to go to the manage tab.`;

const TOOLTIP_SWATCH_CLASS = "w-3 h-3 rounded-sm block shrink-0";

const LEGEND_ITEMS: LegendItem[] = [
  { id: "order-quantity", color: CHART_CATEGORY_COLORS["Order Quantity"], label: "Order Quantity", shape: "square" },
  {
    id: "received-quantity",
    color: CHART_CATEGORY_COLORS["Received Quantity"],
    label: "Received Quantity",
    shape: "gradient",
    gradient: RECEIVED_QUANTITY_GRADIENT,
  },
  { id: "fill-rate", color: CHART_CATEGORY_COLORS["Fill Rate"], label: "Fill Rate", shape: "line" },
  { id: "projected-fill-rate", color: CHART_CATEGORY_COLORS["Projected Fill Rate"], label: "Projected Fill Rate", shape: "line" },
  { id: "goal", color: CHART_CATEGORY_COLORS.Goal, label: "Goal", shape: "line" },
];

interface TooltipMetricRowProps {
  swatch: ReactNode;
  label: string;
  value: string;
}

const TooltipMetricRow = ({ swatch, label, value }: TooltipMetricRowProps) => (
  <div className="flex items-center justify-between gap-2">
    <div className="flex items-center gap-2">
      {swatch}
      <span className="text-gray-600">{label}:</span>
    </div>
    <span className="text-gray-900 font-medium">{value}</span>
  </div>
);

const getTooltipData = (payload?: TooltipPayload[]) => {
  if (!payload?.length) return null;
  return payload.find(entry => entry.payload?.date != null)?.payload ?? payload[0]?.payload ?? null;
};

interface ChartDataPoint extends ServiceLevelTrendDisplay {
  fillRateActual: number | null;
  fillRateProjected: number | null;
}

const buildChartData = (trend: ServiceLevelTrendDisplay[]): ChartDataPoint[] => {
  const firstProjectedIndex = trend.findIndex(d => d.dataType === "projected");

  return trend.map((item, index) => {
    const fillRateActual = item.dataType === "actual" ? item.serviceLevel : null;
    let fillRateProjected = item.dataType === "projected" ? item.serviceLevel : null;

    if (firstProjectedIndex > 0 && index === firstProjectedIndex - 1) {
      fillRateProjected = item.serviceLevel;
    }

    return {
      ...item,
      fillRateActual,
      fillRateProjected,
    };
  });
};

const formatQuantity = (value: number) => {
  if (value >= 1000000) {
    return `${(value / 1000000).toFixed(2)}M`;
  }
  if (value >= 1000) {
    return `${(value / 1000).toFixed(0)}K`;
  }
  return value.toString();
};

const formatServiceLevel = (value: number) => {
  return `${value}%`;
};

const SingleBarShape = (props: unknown) => {
  const {
    x = 0,
    y = 0,
    width = 0,
    height = 0,
    payload,
  } = props as {
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    payload?: {
      mediumImpact?: number;
      highImpact?: number;
    };
  };
  const orderQuantity = payload?.mediumImpact || 0;
  const receivedQuantity = payload?.highImpact || 0;

  const receivedHeight = orderQuantity > 0 ? (receivedQuantity / orderQuantity) * height : 0;

  const receivedY = y + (height - receivedHeight);
  const isFullHeight = receivedHeight >= height - 0.1;

  const innerBarWidth = width * 0.55;
  const innerBarX = x + (width - innerBarWidth) / 2;

  return (
    <g>
      <rect
        x={x}
        y={y}
        width={width}
        height={height}
        fill="var(--cds-color-brand-100)"
        stroke="var(--cds-color-brand-500)"
        strokeWidth={1}
        rx={2}
        ry={2}
      />
      {receivedHeight > 0 && (
        <rect
          x={innerBarX}
          y={receivedY}
          width={innerBarWidth}
          height={receivedHeight}
          fill="url(#serviceLevelPurpleGradient)"
          stroke="#8267CD"
          strokeWidth={1}
          rx={isFullHeight ? 2 : 0}
          ry={isFullHeight ? 2 : 0}
        />
      )}
    </g>
  );
};

interface TooltipPayload {
  payload: {
    serviceLevel?: number;
    dataType?: "actual" | "projected";
    highImpact?: number;
    mediumImpact?: number;
    date?: string;
  };
}

interface ServiceLevelTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
  serviceLevelTarget: number;
}

const formatDisplayDate = (rawDate: string): string => {
  const parts = rawDate.split("-").map(Number);
  if (parts.length !== 3) return rawDate;
  const [y, m, d] = parts;
  return new Date(y, m - 1, d).toLocaleDateString("en-US", { month: "short", day: "numeric" });
};

const ServiceLevelTooltip = ({ active, payload, label, serviceLevelTarget }: ServiceLevelTooltipProps) => {
  const data = getTooltipData(payload);

  if (active && data) {
    const goal = serviceLevelTarget || 95;
    const receivedQuantity = data.highImpact ?? 0;
    const orderQuantity = data.mediumImpact ?? 0;
    const fillRate = Number(data.serviceLevel ?? 0);
    const displayDate = data.date ? formatDisplayDate(data.date) : (label ?? "");
    const isProjected = data.dataType === "projected";
    const fillRateLabel = isProjected ? "Projected Fill Rate" : "Fill Rate";
    const fillRateColor = isProjected ? CHART_CATEGORY_COLORS["Projected Fill Rate"] : CHART_CATEGORY_COLORS["Fill Rate"];

    return (
      <div className="bg-white border border-gray-200 text-gray-900 text-xs rounded-md shadow-lg w-[250px] p-3 font-normal z-30">
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-gray-600">Date:</span>
            <span className="text-gray-900 font-medium">{displayDate}</span>
          </div>
          <TooltipMetricRow
            swatch={
              <span className={TOOLTIP_SWATCH_CLASS} style={{ backgroundColor: CHART_CATEGORY_COLORS["Order Quantity"] }} />
            }
            label="Order Quantity"
            value={orderQuantity.toLocaleString()}
          />
          <TooltipMetricRow
            swatch={<span className={TOOLTIP_SWATCH_CLASS} style={{ background: RECEIVED_QUANTITY_GRADIENT }} />}
            label="Received Quantity"
            value={receivedQuantity.toLocaleString()}
          />
          <TooltipMetricRow
            swatch={
              isProjected ? (
                <span className="block h-0 w-4 shrink-0 border-t-2 border-dashed" style={{ borderColor: fillRateColor }} />
              ) : (
                <span className="block h-[2px] w-4 shrink-0" style={{ backgroundColor: fillRateColor }} />
              )
            }
            label={fillRateLabel}
            value={`${fillRate.toFixed(2)}%`}
          />
          <TooltipMetricRow
            swatch={
              <span
                className="block h-0 w-4 shrink-0 border-t-2 border-dashed"
                style={{ borderColor: CHART_CATEGORY_COLORS.Goal }}
              />
            }
            label="Goal"
            value={`${goal}%`}
          />
        </div>
      </div>
    );
  }
  return null;
};

interface ServiceLevelCardHeaderProps {
  serviceLevelTarget: number;
  onModifyGoal: () => void;
  modifyButtonRef: React.RefObject<HTMLButtonElement | null>;
  isModalOpen: boolean;
  onModalClose: () => void;
  onSaveGoal: (data: ModifyGoalData) => Promise<void>;
}

const ServiceLevelCardHeader = ({
  serviceLevelTarget,
  onModifyGoal,
  modifyButtonRef,
  isModalOpen,
  onModalClose,
  onSaveGoal,
}: ServiceLevelCardHeaderProps) => (
  <CardHeader className="shrink-0">
    <div className="flex items-center justify-between gap-2">
      <div className="flex items-center gap-2">
        <CardTitle className="text-xl font-bold text-heading font-brand">{CARD_TITLE}</CardTitle>
        <InfoIcon tooltip={INFO_TOOLTIP} />
      </div>
      <div className="relative">
        <Button
          ref={modifyButtonRef}
          variant="outline"
          size="sm"
          onClick={onModifyGoal}
          className="border-2 border-brand-primary-main text-brand-primary-main font-bold rounded hover:bg-transparent text-sm px-4 py-1"
        >
          Modify Goal
        </Button>
        {isModalOpen && (
          <ModifyGoalModal
            isOpen={isModalOpen}
            onClose={onModalClose}
            onSave={onSaveGoal}
            triggerRef={modifyButtonRef}
            initialData={{
              serviceLevelTarget: serviceLevelTarget,
              riskScoreThreshold: "100%",
              alertFrequency: "daily",
            }}
          />
        )}
      </div>
    </div>

    <p className="text-sm text-ui-text-secondary">{CARD_DESCRIPTION_BASE}</p>
    <hr className="mb-2"/>
    <Legend items={LEGEND_ITEMS} orientation="horizontal" spacing="md" />
  </CardHeader>
);

const CardFooter = () => (
  <div className="shrink-0 px-6 pb-6">
    <div className="flex justify-end">
      <Link
        to="/manage/overview"
        state={{ scrollTo: "manage-navigation" }}
        className="font-semibold text-brand-primary-main text-[14px] flex items-center gap-1"
      >
        View More
        <ChevronRight className="h-6 w-6 text-brand-primary-main" aria-hidden />
      </Link>
    </div>
  </div>
);

export function ServiceLevelCard() {
  const {
    data: serviceLevelTrend = [],
    isPending: loading,
    isError,
    error: queryError,
    dataUpdatedAt,
  } = useServiceLevelTrendQuery();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [serviceLevelTarget, setServiceLevelTarget] = useState(95);
  const modifyButtonRef = useRef<HTMLButtonElement>(null);

  const chartData = useMemo(() => (serviceLevelTrend.length > 0 ? buildChartData(serviceLevelTrend) : []), [serviceLevelTrend]);
  const error = isError ? (queryError instanceof Error ? queryError.message : "Failed to fetch service level trend") : null;
  const hasData = serviceLevelTrend.length > 0 && chartData.length > 0;
  const hasEverFetched = dataUpdatedAt > 0;

  const maxQuantity = chartData.length > 0 ? Math.max(...chartData.map(d => d.mediumImpact || 0)) : 10000;

  const quantityDomain = maxQuantity > 0 ? [0, Math.ceil(maxQuantity * 1.1)] : [0, 10000];

  const handleModifyGoal = () => {
    setIsModalOpen(true);
  };

  const handleSaveGoal = async (data: ModifyGoalData) => {
    try {
      const nextVal = data.serviceLevelTarget == null ? 0 : data.serviceLevelTarget;
      setServiceLevelTarget(nextVal);
      await patchMySettings({
        inbound_service_level_target: data.serviceLevelTarget,
      });
      toast.success({ title: "Threshold updated" });
    } catch (e) {
      console.warn("Failed to save inbound_service_level_target", e);
      toast.error({
        title: "Couldn't update threshold",
        description: getErrorMessage(e),
      });
    }
  };

  useEffect(() => {
    (async () => {
      try {
        const settings = await getMySettings();
        const inbound = Math.min(100, Math.max(0, Math.round(parseFloat(String(settings.inbound_service_level_target ?? 95)))));
        setServiceLevelTarget(inbound || 95);
      } catch (error) {
        console.warn("Failed to fetch user settings", error);
      }
    })();
  }, []);

  // Show skeleton only when loading AND no data, OR when never fetched
  if ((loading && !hasData) || (!hasEverFetched && !error)) {
    return (
      <div className="relative h-full">
        <GraphCardSkeleton height={CARD_MIN_HEIGHT} />
      </div>
    );
  }

  if (hasEverFetched && !loading && !error && !hasData) {
    return (
      <div className="relative h-full">
        <Card className="flex flex-col h-full" style={{ height: CARD_MIN_HEIGHT, boxSizing: "border-box" }}>
          <ServiceLevelCardHeader
            serviceLevelTarget={serviceLevelTarget}
            onModifyGoal={handleModifyGoal}
            modifyButtonRef={modifyButtonRef}
            isModalOpen={isModalOpen}
            onModalClose={() => setIsModalOpen(false)}
            onSaveGoal={handleSaveGoal}
          />
          <CardContent className="flex-1 flex items-center justify-center min-h-0">
            <EmptyState
              title="No Data Available"
              description="No service level data found for the selected filters. Try adjusting your filter criteria to see results."
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="relative h-full">
      <Card className="flex flex-col h-full" style={{ height: CARD_MIN_HEIGHT, boxSizing: "border-box" }}>
        <ServiceLevelCardHeader
          serviceLevelTarget={serviceLevelTarget}
          onModifyGoal={handleModifyGoal}
          modifyButtonRef={modifyButtonRef}
          isModalOpen={isModalOpen}
          onModalClose={() => setIsModalOpen(false)}
          onSaveGoal={handleSaveGoal}
        />
        <CardContent className="flex-1 flex flex-col px-4 pt-4 pb-0 min-h-0" style={{ padding: "0" }}>
          <div className="w-full overflow-x-auto overflow-y-visible relative shrink-0" style={{ height: MIN_CHART_HEIGHT }}>
            {error && !loading && (
              <div className="absolute inset-0 flex items-center justify-center text-status-error-main z-10">
                <div className="text-center">
                  <p className="text-sm font-medium">Failed to load data</p>
                  <p className="text-xs text-ui-text-muted mt-1">{error}</p>
                </div>
              </div>
            )}
            <AccessibleChart ariaLabel={CARD_TITLE} className="h-full w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={chartData} margin={CHART_MARGIN}>
                  <defs>
                    <linearGradient id="serviceLevelPurpleGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#383874" />
                      <stop offset="18.27%" stopColor="#5D50A0" />
                      <stop offset="100%" stopColor="#8267CD" />
                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="day"
                    axisLine={false}
                    tickLine={false}
                    interval={0}
                    tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                    angle={-70}
                    dx={-5}
                    dy={17}
                  />
                  <YAxis
                    yAxisId="quantity"
                    orientation="left"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                    domain={quantityDomain}
                    tickFormatter={formatQuantity}
                    label={{
                      value: "Quantity Orders",
                      angle: -90,
                      position: "insideLeft",
                      style: {
                        textAnchor: "middle",
                        fill: "var(--color-ui-text-muted)",
                        fontSize: "12px",
                      },
                    }}
                  />
                  <YAxis
                    yAxisId="serviceLevel"
                    orientation="right"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                    domain={[0, 100]}
                    tickFormatter={formatServiceLevel}
                    label={{
                      value: "Fill Rate",
                      angle: 90,
                      position: "insideRight",
                      style: {
                        textAnchor: "middle",
                        fill: "var(--color-ui-text-muted)",
                        fontSize: "12px",
                      },
                    }}
                  />
                  <Bar yAxisId="quantity" dataKey="mediumImpact" shape={SingleBarShape} maxBarSize={MAX_BAR_SIZE} />
                  <Tooltip
                    content={<ServiceLevelTooltip serviceLevelTarget={serviceLevelTarget} />}
                    cursor={{ fill: "rgba(59, 41, 112, 0.1)" }}
                    allowEscapeViewBox={{ x: false, y: false }}
                    offset={10}
                    shared
                  />
                  <Line
                    yAxisId="serviceLevel"
                    type="monotone"
                    dataKey="fillRateActual"
                    stroke={ACTUAL_FILL_RATE_COLOR}
                    strokeWidth={LINE_STROKE_WIDTH}
                    dot={false}
                    connectNulls={false}
                    activeDot={{ r: 4, fill: ACTUAL_FILL_RATE_COLOR }}
                  />
                  <Line
                    yAxisId="serviceLevel"
                    type="monotone"
                    dataKey="fillRateProjected"
                    stroke={PROJECTED_FILL_RATE_COLOR}
                    strokeWidth={LINE_STROKE_WIDTH}
                    strokeDasharray="6 4"
                    dot={false}
                    connectNulls={false}
                    activeDot={{ r: 4, fill: PROJECTED_FILL_RATE_COLOR }}
                  />
                  <ReferenceLine
                    yAxisId="serviceLevel"
                    y={serviceLevelTarget}
                    stroke={GOAL_LINE_COLOR}
                    strokeDasharray="5 5"
                    strokeWidth={2}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </AccessibleChart>
          </div>
        </CardContent>
        <CardFooter />
      </Card>
    </div>
  );
}
