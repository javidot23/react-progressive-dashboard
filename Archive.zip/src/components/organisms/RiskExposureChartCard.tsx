"use client"
// This component is very similar to ServiceLevelCard from the overview page.
import { useState } from "react"

// For brevity, I'm adapting it. Ideally, make a more generic chart card.
import { Card, CardContent, CardHeader, CardDescription } from "@/components/atoms/Card"
import { Button } from "@/components/atoms/Button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/molecules/DropdownMenu"
import { ChevronDown, ArrowRight, ArrowUp, MapPin, BarChartIcon as ChartIcon } from "lucide-react" // Renamed BarChart3 to ChartIcon
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts"
import type { ServiceLevelData } from "@/lib/types" // Using existing type for chart data structure

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-800 text-white p-3 rounded-lg shadow-lg">
        <p className="text-sm font-bold mb-1">{label}</p> {/* Assuming label is day like 'M', 'T' */}
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 rounded-full bg-purple-500" />
          <p className="text-xs">{`Risk Exposure: ${payload[0].value}`}</p>
        </div>
      </div>
    )
  }
  return null
}

export function RiskExposureChartCard({ chartData }: { chartData: ServiceLevelData[] }) {
  const [viewMode, setViewMode] = useState<"map" | "chart">("chart")

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="text-3xl font-bold text-slate-800">
            10% <ArrowUp className="inline-block h-5 w-5 text-status-success-main mb-1" />
          </div>
          <div className="flex items-center space-x-1">
            <Button
              variant={viewMode === "map" ? "secondary" : "ghost"}
              size="sm"
              onClick={() => setViewMode("map")}
              className="text-xs"
            >
              <MapPin className="h-3 w-3 mr-1" /> Map View
            </Button>
            <Button
              variant={viewMode === "chart" ? "secondary" : "ghost"}
              size="sm"
              onClick={() => setViewMode("chart")}
              className="text-xs"
            >
              <ChartIcon className="h-3 w-3 mr-1" /> Chart View
            </Button>
          </div>
        </div>
        <CardDescription className="text-sm text-slate-500">Risk Exposure</CardDescription>
      </CardHeader>
      <CardContent>
        {viewMode === "chart" && (
          <div className="h-[150px] w-full">
            {" "}
            {/* Adjusted height */}
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 5, right: 0, left: -30, bottom: 5 }}>
                <XAxis dataKey="name" tickLine={false} axisLine={false} tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }} />
                <YAxis tickLine={false} axisLine={false} tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(238, 242, 255, 0.5)" }} />
                <Bar dataKey="highImpact" stackId="a" fill="var(--color-brand-primary-light)" radius={[3, 3, 0, 0]} barSize={15}>
                  {chartData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={"var(--color-brand-primary-main)"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
        {viewMode === "map" && (
          <div className="h-[150px] w-full flex items-center justify-center text-slate-400 text-sm">
            Map View Placeholder
          </div>
        )}
        <div className="flex items-center justify-between mt-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-slate-500 text-xs px-2">
                Last 7 days <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem>Last 30 days</DropdownMenuItem>
              <DropdownMenuItem>Last 90 days</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="ghost" className="text-purple-600 font-semibold text-xs px-2">
            VIEW AI REPORT <ArrowRight className="h-3 w-3 ml-1" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
