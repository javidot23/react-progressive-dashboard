import { MaterialWithIssues } from "@/lib/types";
import { InfoIcon, Pagination, RiskBadge } from "@/components/atoms";
import React, { useState, memo } from "react";
import { MaterialRiskDriverModal } from "@/components/molecules/MaterialRiskDriverModal";
import ActionButtonGroup from "@/components/molecules/ActionButtonGroup";
import { useRiskModelDescriptions } from "@/hooks";
import { formatCurrencyCompact, getMaterialStatusDescription } from "@/lib/utils";
import { isFullFeatureSet } from "@/tenant";
import { getRiskBadge } from "@/lib/vendorUtils";

interface MaterialRiskTableProps {
  materials: MaterialWithIssues[];
  isComparisonMode?: boolean;
  // Pagination props
  currentPage?: number;
  pageSize?: number;
  total?: number;
  onPageChange?: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  vendorId?: number;
}

const MaterialRiskTable: React.FC<MaterialRiskTableProps> = ({
  materials,
  currentPage = 1,
  pageSize = 10,
  total = 0,
  onPageChange,
  onPageSizeChange,
  vendorId,
}) => {
  const [showMaterialRiskDriverModal, setShowMaterialRiskDriverModal] = useState<boolean>(false);
  const [selectedMaterialForModal, setSelectedMaterialForModal] = useState<MaterialWithIssues | null>(null);
  const { getEnrichedMetadata } = useRiskModelDescriptions();

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex-1 overflow-auto">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left min-w-max">
            <thead className="font-bold text-ui-text-primary">
              <tr>
                <th className="px-4 py-2 min-w-[150px] flex flex-row items-center gap-2">
                  Name
                  <InfoIcon size={20} position="right" tooltip="The name is the name of the material." />
                </th>
                <th className="px-4 py-2 min-w-[100px]">Material Number</th>
                <th className="px-4 py-2 min-w-[160px]">Vendor</th>
                <th className="px-4 py-2 min-w-[120px]">Vendor Id</th>
                <th className="px-4 py-2 min-w-[150px]">Material Status</th>
                <th className="px-4 py-2 min-w-[120px]">NDC</th>
                <th className="px-4 py-2 min-w-[200px]">Risk Score</th>
                <th className="px-4 py-2 min-w-[150px]">Driving Risk</th>
                <th className="px-4 py-2 min-w-[180px]">Risk Adjusted Value</th>
                <th className="px-4 py-2 min-w-[160px]">Created Date</th>
                <th className="px-4 py-2 min-w-[160px]">Action Status</th>
                <th className="px-4 py-2 min-w-[200px]">Recommended Actions</th>
              </tr>
            </thead>
            <tbody>
              {materials.map(material => {
                const riskPercentage = (material.risk_score || 93.7).toFixed(2);
                const riskLevel = (material.risk_score || 93.7) / 100;

                const hasActions = material.open_issues?.some(issue => issue.actions && issue.actions.length > 0) ?? false;

                const hasOpenIssues = material.open_issues && material.open_issues.length > 0;

                const status = hasActions ? "reviewed" : "not_reviewed";

                const hasOpenIssuesToday =
                  material.open_issues?.some(issue => {
                    if (!issue.created_at) return false;
                    const issueDate = new Date(issue.created_at);
                    const today = new Date();
                    return issueDate.toDateString() === today.toDateString();
                  }) || false;

                return (
                  <tr key={material.id} className="border-t hover:bg-brand-primary-50 cursor-pointer">
                    <th className="px-4 py-2 min-w-[150px]">
                      <div className="flex flex-row items-center space-x-1">
                        {hasOpenIssuesToday && <div className="w-2 h-2 bg-[#E22F00] rounded-full"></div>}
                        <div>
                          <div className="font-normal">{material.name || `Material ${material.id}`}</div>
                        </div>
                      </div>
                    </th>

                    <td className="px-4 py-2 min-w-[100px]">{material.mat_nbr}</td>
                    <td className="px-4 py-2 min-w-[160px]">{material.vendor?.name || "-"}</td>
                    <td className="px-4 py-2 min-w-[120px]">{material.vendor?.vendor_nbr || "-"}</td>
                    <td className="px-4 py-2 min-w-[150px]">{getMaterialStatusDescription(material.xplant_mat_stat)}</td>
                    <td className="px-4 py-2 min-w-[120px]">{material.ndc || "-"}</td>
                    <td className="px-4 py-2 min-w-[200px]">
                      {(() => {
                        const showExactScore = isFullFeatureSet();
                        const riskBadge = getRiskBadge(riskLevel);
                        return (
                          <div className="flex flex-row items-center gap-2">
                            <div className="w-[100px] bg-gray-200 rounded-full h-1">
                              <div
                                className="h-full rounded-full"
                                style={{
                                  width: showExactScore ? `${Math.min(riskLevel * 100, 100)}%` : '100%',
                                  backgroundColor: riskBadge.hexColor,
                                }}
                              />
                            </div>
                            {showExactScore ? (
                              <>
                                <div className="">
                                  <span>{riskPercentage} / 100</span>
                                </div>
                                <RiskBadge riskRating={riskLevel} showIcon={true} size="sm" />
                              </>
                            ) : (
                              <span
                                className={`${riskBadge.bgColor} ${riskBadge.textColor} border ${riskBadge.borderColor} px-1 py-0.5 rounded text-xs font-semibold text-nowrap`}
                              >
                                {riskBadge.text}
                              </span>
                            )}
                          </div>
                        );
                      })()}
                    </td>

                    <td className="px-4 py-2 min-w-[150px]">
                      <button
                        className="flex flex-row items-center justify-between w-full"
                        onClick={() => {
                          setSelectedMaterialForModal(material);
                          setShowMaterialRiskDriverModal(true);
                        }}
                      >
                        {getEnrichedMetadata(material.driving_risk).display_name || material.driving_risk || "Operational"}

                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                          strokeWidth={1.5}
                          stroke="#6E6E6E"
                          className="w-5 h-5 text-brand-primary-main hover:text-brand-primary-dark transition-colors"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                        </svg>
                      </button>
                    </td>
                    <td className="px-4 py-2 min-w-[180px]">
                      {material.risk_score && material.dollars_at_risk
                        ? `${formatCurrencyCompact(
                          Math.round((material.risk_score / 100) * material.dollars_at_risk)
                        )} / ${formatCurrencyCompact(material.dollars_at_risk, true)}`
                        : "- / -"}
                    </td>

                    <td className="px-4 py-2 min-w-[160px]">
                      {hasOpenIssues && material.open_issues[0]?.created_at ? (
                        <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-transparent text-sm font-medium text-ui-text-primary">
                          {new Date(material.open_issues[0].created_at).toLocaleDateString("en-US", {
                            day: "2-digit",
                            month: "short",
                            year: "numeric",
                          })}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-transparent text-sm font-medium text-ui-text-primary">
                          -
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-2 min-w-[160px]">
                      {hasOpenIssues && (
                        <>
                          {status === "reviewed" ? (
                            <div className="inline-flex items-center justify-center p-1 rounded-full border border-[#06C07A] bg-[#D8FEE7] mr-2">
                              <div className="w-2 h-2 rounded-full bg-[#119D63]" />
                            </div>
                          ) : (
                            <div className="inline-flex items-center justify-center p-1 rounded-full border border-[#E22F008A] bg-[#FEEFEB] mr-2">
                              <div className="w-2 h-2 rounded-full bg-[#E22F00]" />
                            </div>
                          )}
                          {status === "reviewed" ? "Reviewed" : "Not Reviewed"}
                        </>
                      )}
                    </td>

                    <td className="px-4 py-2 min-w-[200px]">
                      {hasOpenIssues && (
                        <ActionButtonGroup
                          material={material}
                          size="sm"
                          issueId={material.open_issues[0]?.id}
                          potentialActions={material.open_issues[0]?.potential_actions || []}
                          issueNbr={material.open_issues[0]?.issue_nbr}
                          vendorId={vendorId}
                        />
                      )}
                    </td>
                  </tr>
                );
              })}
              {materials.length === 0 && (
                <tr>
                  <td colSpan={12} className="px-4 py-6 text-center text-ui-text-secondary">
                    No data
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {onPageChange && onPageSizeChange && (
        <Pagination
          currentPage={currentPage}
          pageSize={pageSize}
          total={total}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
          itemName="Materials"
        />
      )}

      {showMaterialRiskDriverModal && <MaterialRiskDriverModal
        isOpen={showMaterialRiskDriverModal}
        onClose={() => {
          setShowMaterialRiskDriverModal(false);
          setSelectedMaterialForModal(null);
        }}
        materialName={selectedMaterialForModal?.name || `Material ${selectedMaterialForModal?.id}`}
        vendorName={selectedMaterialForModal?.vendor?.name}
        overallRiskScore={selectedMaterialForModal?.risk_score || 93.7}
        dollarsAtRisk={selectedMaterialForModal?.dollars_at_risk || 0}
        materialId={selectedMaterialForModal?.id || 0}
        materialNbr={selectedMaterialForModal?.mat_nbr}
        riskLevel={selectedMaterialForModal?.risk_score || 93.7}
        drivingRisk={selectedMaterialForModal?.driving_risk}
        ndc={selectedMaterialForModal?.ndc || selectedMaterialForModal?.ean_n4_nbr_11}
      />}
    </div>
  );
};

export default memo(MaterialRiskTable);
