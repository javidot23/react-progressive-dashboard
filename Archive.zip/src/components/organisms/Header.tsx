import { NavLink, Link, useLocation } from "react-router-dom";
import { Menu, X, Bell, ListChecks, Settings, FileText, BookOpen } from "lucide-react";
import { useState, useRef, useCallback, useEffect } from "react";
import { UserMenuDropdown } from "@/components/molecules/UserMenuDropdown";
import { ProfilePictureDropdown } from "@/components/molecules/ProfilePictureDropdown";
import { useIsMobile } from "@/hooks/useMobile";
import { ROUTES } from "@/constants/routes";
import WhiteLogo from "@/assets/icons/white-logo.svg";
import PrimaryLogo from "@/assets/icons/primary-logo.svg";
import AlertNotificationIcon from "@/assets/icons/alert-notification-white.svg";
const HEADER_HEIGHT_MOBILE = 64;
const HEADER_HEIGHT_DESKTOP = 83;
const NAV_OFFSET_DESKTOP = 36;
const ACTIVE_INDICATOR_OFFSET = -22;

const NAV_ITEMS = [
  { name: "Overview", href: ROUTES.OVERVIEW, matchPath: ROUTES.OVERVIEW },
  { name: "React", href: ROUTES.REACT, matchPath: ROUTES.REACT },
  { name: "Manage", href: ROUTES.MANAGE_OVERVIEW, matchPath: ROUTES.MANAGE },
  { name: "Plan", href: ROUTES.PLAN, matchPath: ROUTES.PLAN },
] as const;

export interface HeaderProps {
  className?: string;
}

export const Header = ({ className }: HeaderProps) => {
  const location = useLocation();
  const isDisruptionsMap = location.pathname === ROUTES.DISRUPTIONS_MAP;
  const isPlanProductPage = location.pathname.startsWith("/plan/vendor/");
  const isWhiteNavbar = isDisruptionsMap || isPlanProductPage;
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const desktopDropdownTriggerRef = useRef<HTMLButtonElement>(null);
  const mobileDropdownTriggerRef = useRef<HTMLButtonElement>(null);
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();

  const toggleDropdown = useCallback(() => setIsDropdownOpen(prev => !prev), []);
  const closeDropdown = useCallback(() => setIsDropdownOpen(false), []);
  const toggleMobileMenu = useCallback(() => setIsMobileMenuOpen(prev => !prev), []);
  const closeMobileMenu = useCallback(() => setIsMobileMenuOpen(false), []);

  useEffect(() => {
    if (isMobileMenuOpen && mobileMenuRef.current) {
      const firstLink = mobileMenuRef.current.querySelector("a");
      firstLink?.focus();
    }
  }, [isMobileMenuOpen]);

  const handleMobileMenuKeyDown = useCallback(
    (event: React.KeyboardEvent) => {
      if (event.key === "Escape") {
        closeMobileMenu();
      }
    },
    [closeMobileMenu]
  );

  useEffect(() => {
    if (isMobileMenuOpen) {
      const originalOverflow = window.document.body.style.overflow;
      window.document.body.style.overflow = "hidden";
      return () => {
        window.document.body.style.overflow = originalOverflow;
      };
    }
  }, [isMobileMenuOpen]);

  return (
    <header
      className={`${isWhiteNavbar ? "bg-white border-b border-[#E2E8F0]" : "bg-[#461E96]"} h-[75px] md:h-[83px] sticky top-0 z-9999 ${className}`}
    >
      <div className="w-full max-w-(--breakpoint-2xl) mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className="flex items-center justify-between gap-2 md:gap-3 lg:gap-4"
          style={{ height: isMobile ? `${HEADER_HEIGHT_MOBILE}px` : `${HEADER_HEIGHT_DESKTOP}px` }}
        >
          <div className="flex flex-row items-center shrink-0 min-w-0">
            <Link
              to={ROUTES.OVERVIEW}
              className={`inline-flex shrink-0 rounded-sm focus:outline-hidden focus-visible:ring-2 focus-visible:ring-offset-2 ${
                isWhiteNavbar
                  ? "focus-visible:ring-[#461E96] focus-visible:ring-offset-white"
                  : "focus-visible:ring-white focus-visible:ring-offset-[#461E96]"
              }`}
              aria-label="Cencora, go to Overview"
            >
              {isWhiteNavbar ? (
                <img src={PrimaryLogo} alt="Stratium home" className="h-9 md:h-10 ml-[-5px] w-auto shrink-0" />
              ) : (
                <img src={WhiteLogo} alt="" className="h-5 md:h-5 w-auto shrink-0" />
              )}
            </Link>
            <nav
              className="hidden md:flex items-center"
              style={{ marginLeft: isMobile ? 0 : `${NAV_OFFSET_DESKTOP}px` }}
              aria-label="Main navigation"
            >
              {NAV_ITEMS.map(item => {
                const getNavItemWidth = (name: string) => {
                  const widths: Record<string, string> = {
                    Overview: "90px",
                    React: "65px",
                    Manage: "75px",
                    Plan: "55px",
                  };
                  return widths[name] || "70px";
                };

                return (
                  <NavLink
                    key={item.name}
                    to={item.href}
                    end={item.href === item.matchPath}
                    className={({ isActive }) => {
                      const isParentActive = location.pathname.startsWith(item.matchPath);
                      const active = isActive || isParentActive;

                      return `
                      relative flex min-w-0 px-2 md:px-3 lg:px-4 py-2 justify-center items-center gap-2
                      transition-colors duration-200 text-center text-xs md:text-sm font-brand no-underline whitespace-nowrap
                      ${
                        isWhiteNavbar
                          ? active
                            ? "text-[#461E96] font-bold"
                            : "text-[#525252] font-medium hover:text-[#461E96]"
                          : active
                            ? "text-white font-bold"
                            : "text-white font-medium hover:opacity-80"
                      }
                    `;
                    }}
                    style={{
                      fontFamily: 'var(--text-body-sm-font-family, "Cencora-Gilroy")',
                      fontSize: "var(--text-body-sm-font-size, 14px)",
                      lineHeight: "var(--text-body-sm-line-height, 20px)",
                      width: getNavItemWidth(item.name),
                      minWidth: getNavItemWidth(item.name),
                    }}
                  >
                    {({ isActive }) => {
                      const isParentActive = location.pathname.startsWith(item.matchPath);
                      const active = isActive || isParentActive;

                      return (
                        <>
                          {item.name}
                          {active && (
                            <div
                              className={`absolute left-0 right-0 h-[3px] ${isWhiteNavbar ? "bg-[#461E96]" : "bg-white"}`}
                              style={{ bottom: `${ACTIVE_INDICATOR_OFFSET}px` }}
                              aria-hidden="true"
                            />
                          )}
                        </>
                      );
                    }}
                  </NavLink>
                );
              })}
            </nav>
          </div>

          <div className="hidden md:flex items-center justify-center flex-1 min-w-0 px-2 lg:px-3 xl:px-4">
            <div className="relative w-full"></div>
          </div>

          <div className="flex items-center relative shrink-0">
            <button
              onClick={toggleMobileMenu}
              className={`md:hidden p-2 ${isWhiteNavbar ? "text-[#525252] hover:text-[#461E96]" : "text-white hover:opacity-80"} transition-colors duration-200 mr-2 touch-manipulation`}
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
              aria-expanded={isMobileMenuOpen}
              aria-controls="mobile-navigation"
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <div className="hidden md:flex items-center gap-3 lg:gap-5 xl:gap-8">
              <div className="flex flex-col items-center justify-center gap-1"></div>
              <div className="flex flex-col items-center justify-center gap-1">
                <NavLink
                  to={ROUTES.GLOSSARY}
                  state={{ from: location.pathname }}
                  className={`transition-colors duration-200 ${isWhiteNavbar ? "text-[#525252] hover:text-[#461E96]" : "text-white hover:opacity-80"} flex items-center justify-center p-1`}
                  aria-label="Glossary"
                >
                  <FileText className="h-5 w-5" />
                </NavLink>
                <span
                  className={`text-xs font-bold ${isWhiteNavbar ? "text-[#525252]" : "text-white"} leading-tight hidden xl:inline`}
                >
                  Glossary
                </span>
              </div>
              <div className="flex flex-col items-center justify-center gap-1">
                <button
                  ref={desktopDropdownTriggerRef}
                  onClick={toggleDropdown}
                  className={`transition-colors duration-200 ${isWhiteNavbar ? "text-[#525252] hover:text-[#461E96]" : "text-white hover:opacity-80"} flex items-center justify-center p-1`}
                  aria-label="Action Log"
                  aria-expanded={isDropdownOpen}
                  aria-haspopup="true"
                >
                  <ListChecks className="h-5 w-5" aria-hidden />
                </button>
                <span
                  className={`text-xs font-bold ${isWhiteNavbar ? "text-[#525252]" : "text-white"} leading-tight hidden xl:inline`}
                >
                  Action Log
                </span>
              </div>
              <div className="flex flex-col items-center justify-center gap-1">
                <NavLink
                  to={ROUTES.PROFILE}
                  className={`transition-colors duration-200 ${isWhiteNavbar ? "text-[#525252] hover:text-[#461E96]" : "text-white hover:opacity-80"} flex items-center justify-center p-1`}
                  aria-label="Settings"
                >
                  <Settings className="h-5 w-5" />
                </NavLink>
                <span
                  className={`text-xs font-bold ${isWhiteNavbar ? "text-[#525252]" : "text-white"} leading-tight hidden xl:inline`}
                >
                  Settings
                </span>
              </div>
              <ProfilePictureDropdown />
            </div>
            <UserMenuDropdown
              isOpen={isDropdownOpen}
              onClose={closeDropdown}
              triggerRef={isMobile ? mobileDropdownTriggerRef : desktopDropdownTriggerRef}
            />
          </div>
        </div>
        {isMobileMenuOpen && (
          <>
            <div className="md:hidden fixed inset-0 bg-black/50 z-9998 top-[64px]" onClick={closeMobileMenu} aria-hidden="true" />
            <div
              className={`md:hidden fixed top-[64px] left-0 right-0 bottom-0 ${isWhiteNavbar ? "bg-white" : "bg-[#461E96]"} z-9999 overflow-y-auto transition-all duration-300 ease-in-out`}
              id="mobile-navigation"
              ref={mobileMenuRef}
              onKeyDown={handleMobileMenuKeyDown}
              tabIndex={-1}
            >
              <nav className="px-4 py-4 space-y-4" aria-label="Mobile navigation">
                <div className="mb-2"></div>

                <div className="space-y-1">
                  <div
                    className={`px-2 py-1.5 text-xs font-semibold ${isWhiteNavbar ? "text-[#525252]" : "text-white/70"} uppercase tracking-wider`}
                  >
                    Navigation
                  </div>
                  {NAV_ITEMS.map(item => (
                    <NavLink
                      key={item.name}
                      to={item.href}
                      end={item.href === item.matchPath}
                      onClick={closeMobileMenu}
                      className={({ isActive }) => {
                        const isParentActive = location.pathname.startsWith(item.matchPath);
                        const active = isActive || isParentActive;

                        return `
                          w-full flex items-center px-4 py-3.5 text-left transition-all duration-200
                          text-base font-brand rounded-lg touch-manipulation no-underline
                          ${
                            isWhiteNavbar
                              ? active
                                ? "text-[#461E96] font-bold bg-[#461E96]/10 shadow-xs"
                                : "text-[#525252] font-medium hover:bg-gray-100 active:bg-gray-200"
                              : active
                                ? "text-white font-bold bg-white/15 shadow-xs"
                                : "text-white font-medium hover:bg-white/10 active:bg-white/15"
                          }
                        `;
                      }}
                      style={{
                        fontSize: "var(--text-body-sm-font-size, 14px)",
                        lineHeight: "var(--text-body-sm-line-height, 20px)",
                      }}
                    >
                      {item.name}
                    </NavLink>
                  ))}
                </div>

                <div className={`border-t ${isWhiteNavbar ? "border-gray-200" : "border-white/20"} my-4`} />

                <div className="space-y-1">
                  <div
                    className={`px-2 py-1.5 text-xs font-semibold ${isWhiteNavbar ? "text-[#525252]" : "text-white/70"} uppercase tracking-wider`}
                  >
                    Actions
                  </div>
                  <button
                    className={`w-full flex items-center gap-3 px-4 py-3.5 text-left transition-all duration-200 text-base font-medium ${isWhiteNavbar ? "text-[#525252] hover:bg-gray-100 active:bg-gray-200" : "text-white hover:bg-white/10 active:bg-white/15"} rounded-lg touch-manipulation`}
                  >
                    {isWhiteNavbar ? (
                      <Bell className="h-5 w-5 shrink-0" />
                    ) : (
                      <img src={AlertNotificationIcon} alt="" className="h-5 w-5 shrink-0" aria-hidden />
                    )}
                    <span>Alerts</span>
                  </button>
                  <NavLink
                    to={ROUTES.GLOSSARY}
                    state={{ from: location.pathname }}
                    onClick={closeMobileMenu}
                    className={`w-full flex items-center gap-3 px-4 py-3.5 text-left transition-all duration-200 text-base font-medium ${isWhiteNavbar ? "text-[#525252] hover:bg-gray-100 active:bg-gray-200" : "text-white hover:bg-white/10 active:bg-white/15"} rounded-lg touch-manipulation no-underline`}
                  >
                    <BookOpen className="h-5 w-5 shrink-0" />
                    <span>Glossary</span>
                  </NavLink>
                  <button
                    onClick={() => {
                      setIsDropdownOpen(true);
                      closeMobileMenu();
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3.5 text-left transition-all duration-200 text-base font-medium ${isWhiteNavbar ? "text-[#525252] hover:bg-gray-100 active:bg-gray-200" : "text-white hover:bg-white/10 active:bg-white/15"} rounded-lg touch-manipulation`}
                  >
                    <ListChecks className="h-5 w-5 shrink-0" aria-hidden />
                    <span>Action Log</span>
                  </button>
                  <NavLink
                    to={ROUTES.PROFILE}
                    onClick={closeMobileMenu}
                    className={`w-full flex items-center gap-3 px-4 py-3.5 text-left transition-all duration-200 text-base font-medium ${isWhiteNavbar ? "text-[#525252] hover:bg-gray-100 active:bg-gray-200" : "text-white hover:bg-white/10 active:bg-white/15"} rounded-lg touch-manipulation no-underline`}
                  >
                    <Settings className="h-5 w-5 shrink-0" />
                    <span>Settings</span>
                  </NavLink>
                </div>
              </nav>
            </div>
          </>
        )}
      </div>
    </header>
  );
};
