import { Card, CardContent, CardHeader, CardTitle } from "@/components/atoms/Card"
import { Badge } from "@/components/atoms/Badge"
import { Info } from "lucide-react"
import type { RiskAlternative } from "@/lib/types"
import { cn } from "@/lib/utils"

export function RiskAlternativesListCard({ alternatives }: { alternatives: RiskAlternative[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
                          Risk-Adjusted Alternatives <Info className="w-3 h-3 ml-2 text-brand-primary-main" />
        </CardTitle>
        {/* <CardDescription>For selected high-risk products</CardDescription> */}
      </CardHeader>
      <CardContent className="space-y-3">
        {alternatives.map((alt) => (
          <div
            key={alt.name}
            className="flex items-center justify-between p-4 rounded-lg bg-ui-background-secondary border border-ui-border-primary"
          >
            <div>
              <p className="font-semibold text-sm text-slate-800">{alt.name}</p>
              <p className="text-xs text-slate-500">{alt.description}</p>
            </div>
            <Badge
              className={cn(
                "font-semibold text-xs px-2.5 py-1",
                alt.costChangeType === "saving"
                          ? "bg-status-success-light text-status-success-main"
        : "bg-status-error-light text-status-error-main",
              )}
            >
              {alt.costChange}
            </Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
