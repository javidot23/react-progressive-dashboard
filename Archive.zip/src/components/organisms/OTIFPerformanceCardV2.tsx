"use client";

import { useMemo } from "react";
import {
  Bar,
  CartesianGrid,
  Cell,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  type DotProps,
} from "recharts";
import { Link, useLocation } from "react-router-dom";
import type { LegendItem } from "@/components/atoms/Legend";
import { AccessibleChart } from "@/components/atoms/AccessibleChart";
import { ChartWrapper } from "@/components/molecules/ChartWrapper";
import { useWeeklyOtifLineCountsQuery } from "@/hooks/queries/useMainKpiQueries";
import { ROUTES } from "@/constants/routes";

const CARD_MIN_HEIGHT = 560;
const MIN_CHART_HEIGHT = 350;
const CHART_MARGIN = { top: 20, right: 0, left: 0, bottom: 20 };
const MAX_BAR_SIZE = 30;
const INCOMPLETE_WEEK_BAR_OPACITY = 0.45;
const LINE_STROKE_WIDTH = 3;

const COLOR_OTIF_LINES = "var(--color-brand-900)";
const COLOR_OT_NOT_IF = "var(--color-data-alert-danger-light)";
const COLOR_IF_NOT_OT = "var(--color-data-alert-danger-median)";
const COLOR_NOT_OT_OR_IF = "var(--color-data-alert-danger-dark)";
const COLOR_OTIF_PERCENT = "#053E67";

const CARD_TITLE = "OTIF Performance";
const CARD_DESCRIPTION = "Weekly trend of inbound quantities delivered on time and in full for the last 90 days";
const INFO_TOOLTIP_BASE =
  "This visual provides the OTIF line counts trend with bars showing different line count categories (OTIF, OT but not IF, IF but not OT, NOT OT or IF). The blue line indicates the overall OTIF percentage for the last 90 days.";
const INFO_TOOLTIP_CTA = " Click see OTIF exceptions to view exception details.";
const ACTION_LABEL = "See OTIF Exceptions";

const LEGEND_ITEMS: LegendItem[] = [
  { id: "otif-lines", color: COLOR_OTIF_LINES, label: "OTIF Lines", shape: "square" },
  { id: "ot-not-if", color: COLOR_OT_NOT_IF, label: "On time not in full", shape: "square" },
  { id: "if-not-ot", color: COLOR_IF_NOT_OT, label: "In full not on time", shape: "square" },
  { id: "not-ot-or-if", color: COLOR_NOT_OT_OR_IF, label: "Not on time or In Full", shape: "square" },
  { id: "otif-percentage", color: COLOR_OTIF_PERCENT, label: "OTIF %", shape: "line" },
];

const CATEGORY_COLORS = {
  "OTIF Lines": COLOR_OTIF_LINES,
  "On time not in full": COLOR_OT_NOT_IF,
  "In full not on time": COLOR_IF_NOT_OT,
  "Not on time or In Full": COLOR_NOT_OT_OR_IF,
  "OTIF %": COLOR_OTIF_PERCENT,
} as const;

const formatQuantity = (value: number) => {
  if (value >= 1000) {
    return `${(value / 1000).toFixed(0)}K`;
  }
  return value.toString();
};

const formatOTIFPercentage = (value: number) => `${value}%`;

const getWeekDates = (year: number, week: number): { weekStart: Date; weekEnd: Date } => {
  const jan4 = new Date(year, 0, 4);
  const jan4Day = jan4.getDay() || 7;
  const daysToMonday = jan4Day - 1;
  const week1Monday = new Date(year, 0, 4 - daysToMonday);
  const targetWeekMonday = new Date(week1Monday);
  targetWeekMonday.setDate(week1Monday.getDate() + (week - 1) * 7);
  const weekEnd = new Date(targetWeekMonday);
  weekEnd.setDate(targetWeekMonday.getDate() + 6);

  return {
    weekStart: targetWeekMonday,
    weekEnd,
  };
};

const formatDate = (date: Date): string =>
  date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });

const startOfLocalDay = (d: Date): Date => new Date(d.getFullYear(), d.getMonth(), d.getDate());

/** Week is still in progress when today falls within [weekStart, weekEnd] (inclusive, local dates). */
const isIncompleteWeek = (weekStart: Date, weekEnd: Date, now: Date = new Date()): boolean => {
  const today = startOfLocalDay(now);
  const start = startOfLocalDay(weekStart);
  const end = startOfLocalDay(weekEnd);
  return today >= start && today <= end;
};

function normalizePathname(pathname: string): string {
  if (pathname.length > 1 && pathname.endsWith("/")) {
    return pathname.slice(0, -1);
  }
  return pathname;
}

interface TooltipPayload {
  payload: {
    otif?: number;
    otifCount?: number;
    otButNotIfCount?: number;
    ifButNotOtCount?: number;
    notOtOrIfCount?: number;
    totalLines?: number;
    weekRange?: string;
    isIncompleteWeek?: boolean;
  };
}

interface OTIFTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}

const OTIFTooltip = ({ active, payload, label }: OTIFTooltipProps) => {
  if (!active || !payload?.length) return null;

  const data = payload[0].payload;
  const otifPercentage = data.otif || 0;
  const otifCount = data.otifCount || 0;
  const otButNotIfCount = data.otButNotIfCount || 0;
  const ifButNotOtCount = data.ifButNotOtCount || 0;
  const notOtOrIfCount = data.notOtOrIfCount || 0;
  const totalLines = data.totalLines || 0;
  const weekRange = data.weekRange || label;
  const incompleteWeek = Boolean(data.isIncompleteWeek);

  return (
    <div className="z-30 w-[250px] rounded-md border border-gray-200 bg-white p-3 text-xs font-normal text-gray-900 shadow-lg">
      <div className="flex flex-col gap-2">
        <div className="flex items-center space-x-1">
          <span className="text-gray-600">Week:</span>
          <span className="font-medium text-gray-900">{weekRange}</span>
        </div>
        {incompleteWeek && (
          <p className="border-b border-gray-100 pb-2 text-xs font-medium text-ui-text-secondary">Incomplete week</p>
        )}
        {otifCount > 0 && (
          <div className="flex items-center space-x-2">
            <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: CATEGORY_COLORS["OTIF Lines"] }} />
            <div className="flex items-center space-x-1">
              <span className="text-gray-600">OTIF Lines:</span>
              <span className="font-medium text-gray-900">{otifCount.toLocaleString()}</span>
            </div>
          </div>
        )}
        {otButNotIfCount > 0 && (
          <div className="flex items-center space-x-2">
            <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: CATEGORY_COLORS["On time not in full"] }} />
            <div className="flex items-center space-x-1">
              <span className="text-gray-600">On time not in full:</span>
              <span className="font-medium text-gray-900">{otButNotIfCount.toLocaleString()}</span>
            </div>
          </div>
        )}
        {ifButNotOtCount > 0 && (
          <div className="flex items-center space-x-2">
            <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: CATEGORY_COLORS["In full not on time"] }} />
            <div className="flex items-center space-x-1">
              <span className="text-gray-600">In full not on time:</span>
              <span className="font-medium text-gray-900">{ifButNotOtCount.toLocaleString()}</span>
            </div>
          </div>
        )}
        {notOtOrIfCount > 0 && (
          <div className="flex items-center space-x-2">
            <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: CATEGORY_COLORS["Not on time or In Full"] }} />
            <div className="flex items-center space-x-1">
              <span className="text-gray-600">Not on time or In Full:</span>
              <span className="font-medium text-gray-900">{notOtOrIfCount.toLocaleString()}</span>
            </div>
          </div>
        )}
        <div className="flex items-center space-x-2">
          <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: CATEGORY_COLORS["OTIF %"] }} />
          <div className="flex items-center space-x-1">
            <span className="text-gray-600">OTIF Performance:</span>
            <span className="font-medium text-gray-900">{otifPercentage.toFixed(2)}%</span>
          </div>
        </div>
        <div className="mt-1 flex items-center space-x-1 border-t border-gray-200 pt-2">
          <span className="font-medium text-gray-600">Total Lines:</span>
          <span className="font-medium text-gray-900">{totalLines.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
};

const CustomDot = (props: DotProps & { fill?: string }) => {
  const { cx, cy, fill } = props;
  if (cx === undefined || cy === undefined) return null;
  return (
    <g>
      <circle cx={cx} cy={cy} r={5} fill={fill} />
      <circle cx={cx} cy={cy} r={2} fill="white" />
    </g>
  );
};

const CustomActiveDot = (props: DotProps & { fill?: string }) => {
  const { cx, cy, fill } = props;
  if (cx === undefined || cy === undefined) return null;
  return (
    <g>
      <circle cx={cx} cy={cy} r={7} fill={fill} />
      <circle cx={cx} cy={cy} r={3} fill="white" />
    </g>
  );
};

export function OTIFPerformanceCardV2() {
  const location = useLocation();
  const showExceptionsAction = normalizePathname(location.pathname) !== ROUTES.MANAGE_OTIF_EXCEPTIONS;
  const infoTooltipText = showExceptionsAction ? INFO_TOOLTIP_BASE + INFO_TOOLTIP_CTA : INFO_TOOLTIP_BASE;

  const { weeklyOtifLineCounts, isLoading: loading, isFetched, error } = useWeeklyOtifLineCountsQuery();

  const { chartData, maxValue } = useMemo(() => {
    if (!weeklyOtifLineCounts || weeklyOtifLineCounts.length === 0) {
      return { chartData: [], maxValue: 1000 };
    }

    let maxVal = 0;

    const data = weeklyOtifLineCounts.map(item => {
      const { weekStart, weekEnd } = getWeekDates(item.year, item.week);
      const weekStartFormatted = formatDate(weekStart);
      const weekEndFormatted = formatDate(weekEnd);
      const weekRange = `${weekStartFormatted} - ${weekEndFormatted}`;
      const incompleteWeek = isIncompleteWeek(weekStart, weekEnd);
      const otifPercentage = item.otif_percentage || 0;
      const weekMax = Math.max(item.otif_count, item.ot_but_not_if_count, item.if_but_not_ot_count, item.not_ot_or_if_count);
      maxVal = Math.max(maxVal, weekMax);

      return {
        week: weekStartFormatted,
        weekRange,
        otifCount: item.otif_count,
        otButNotIfCount: item.ot_but_not_if_count,
        ifButNotOtCount: item.if_but_not_ot_count,
        notOtOrIfCount: item.not_ot_or_if_count,
        otif: otifPercentage,
        totalLines: item.total_lines,
        isIncompleteWeek: incompleteWeek,
      };
    });

    let calculatedMax;
    if (maxVal <= 100) {
      calculatedMax = Math.ceil(maxVal / 10) * 10;
    } else if (maxVal <= 500) {
      calculatedMax = Math.ceil(maxVal / 50) * 50;
    } else if (maxVal <= 1000) {
      calculatedMax = Math.ceil(maxVal / 100) * 100;
    } else {
      calculatedMax = Math.ceil(maxVal / 500) * 500;
    }

    return { chartData: data, maxValue: Math.max(calculatedMax, 100) };
  }, [weeklyOtifLineCounts]);

  const hasData = weeklyOtifLineCounts && weeklyOtifLineCounts.length > 0;
  const hasEverFetched = isFetched;
  const isLoading = (loading && !hasData) || (!hasEverFetched && !error);
  const isEmpty = hasEverFetched && !loading && !error && !hasData;
  const chartError = error && !loading ? error : null;

  return (
    <ChartWrapper
      className="w-full min-w-0 bg-transparent border-none"
      style={{ minHeight: CARD_MIN_HEIGHT }}
      title={CARD_TITLE}
      chartBackground="transparent"
      description={CARD_DESCRIPTION}
      infoTooltip={infoTooltipText}
      actions={
        showExceptionsAction ? (
          <Link
            to={ROUTES.MANAGE_OTIF_EXCEPTIONS}
            className="inline-flex h-8 items-center justify-center rounded-md border border-2 border-brand-primary-main px-3 text-xs font-semibold text-brand-primary-main transition-colors hover:bg-brand-primary-main/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ui-border-focus"
          >
            {ACTION_LABEL}
          </Link>
        ) : undefined
      }
      legendItems={LEGEND_ITEMS}
      legendPosition="top"
      legendOrientation="horizontal"
      legendSpacing="md"
      isLoading={isLoading}
      isEmpty={isEmpty}
      emptyTitle="No Data Available"
      emptyDescription="No OTIF performance data found for the selected filters. Try adjusting your filter criteria to see results."
      error={chartError}
      minHeight={MIN_CHART_HEIGHT}
      height={MIN_CHART_HEIGHT}
      ariaLabel={CARD_TITLE}
      responsive
    >
      <AccessibleChart ariaLabel={CARD_TITLE} className="h-full w-full">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData} margin={CHART_MARGIN}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-ui-border-primary)" />

            <XAxis
              dataKey="week"
              axisLine={false}
              tickLine={false}
              interval={0}
              tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
              angle={-70}
              dx={-5}
              dy={17}
            />

            <YAxis
              yAxisId="quantity"
              orientation="left"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
              domain={[0, maxValue]}
              tickFormatter={formatQuantity}
              label={{
                value: "Lines",
                angle: -90,
                position: "insideLeft",
                style: {
                  textAnchor: "middle",
                  fill: "var(--color-ui-text-muted)",
                  fontSize: "12px",
                },
              }}
            />

            <YAxis
              yAxisId="otifPercentage"
              orientation="right"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
              domain={[0, 100]}
              tickFormatter={formatOTIFPercentage}
              label={{
                value: "Percentage",
                angle: -90,
                position: "insideRight",
                style: {
                  textAnchor: "middle",
                  fill: "var(--color-ui-text-muted)",
                  fontSize: "12px",
                },
              }}
            />

            <Bar
              yAxisId="quantity"
              dataKey="otifCount"
              stackId="quantity"
              fill={COLOR_OTIF_LINES}
              stroke={COLOR_OTIF_LINES}
              strokeWidth={1}
              radius={[0, 0, 0, 0]}
              maxBarSize={MAX_BAR_SIZE}
            >
              {chartData.map((entry, index) => (
                <Cell key={`otifCount-${index}`} fillOpacity={entry.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1} />
              ))}
            </Bar>

            <Bar
              yAxisId="quantity"
              dataKey="otButNotIfCount"
              stackId="quantity"
              fill={COLOR_OT_NOT_IF}
              stroke={COLOR_OT_NOT_IF}
              strokeWidth={1}
              radius={[0, 0, 0, 0]}
              maxBarSize={MAX_BAR_SIZE}
            >
              {chartData.map((entry, index) => (
                <Cell key={`otButNotIf-${index}`} fillOpacity={entry.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1} />
              ))}
            </Bar>

            <Bar
              yAxisId="quantity"
              dataKey="ifButNotOtCount"
              stackId="quantity"
              fill={COLOR_IF_NOT_OT}
              stroke={COLOR_IF_NOT_OT}
              strokeWidth={1}
              radius={[0, 0, 0, 0]}
              maxBarSize={MAX_BAR_SIZE}
            >
              {chartData.map((entry, index) => (
                <Cell key={`ifButNotOt-${index}`} fillOpacity={entry.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1} />
              ))}
            </Bar>

            <Bar
              yAxisId="quantity"
              dataKey="notOtOrIfCount"
              stackId="quantity"
              fill={COLOR_NOT_OT_OR_IF}
              stroke={COLOR_NOT_OT_OR_IF}
              strokeWidth={1}
              radius={[2, 2, 0, 0]}
              maxBarSize={MAX_BAR_SIZE}
            >
              {chartData.map((entry, index) => (
                <Cell key={`notOtOrIf-${index}`} fillOpacity={entry.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1} />
              ))}
            </Bar>

            <Tooltip
              content={<OTIFTooltip />}
              cursor={{ fill: "rgba(59, 41, 112, 0.1)" }}
              allowEscapeViewBox={{ x: false, y: false }}
              offset={10}
            />

            <Line
              yAxisId="otifPercentage"
              type="linear"
              dataKey="otif"
              stroke={COLOR_OTIF_PERCENT}
              strokeWidth={LINE_STROKE_WIDTH}
              dot={<CustomDot fill={COLOR_OTIF_PERCENT} />}
              activeDot={<CustomActiveDot fill={COLOR_OTIF_PERCENT} />}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </AccessibleChart>
    </ChartWrapper>
  );
}
