export function CriticalAlert() {
  return (
    <div className="relative group mb-6">
      {/* Tooltip appears on hover */}
      <div className="absolute -top-5 left-1/2 -translate-x-1/2 -translate-y-full z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <div className="bg-status-error-main text-white text-xs rounded px-3 py-2 shadow-lg text-center w-72">
          We don't have data or a way to map data for this value.
        </div>
      </div>

      {/* Alert box */}
      <div className="rounded-lg p-4 bg-status-alert-main border border-status-alert-main">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {/* Alert icon */}
            <div className="shrink-0">
              <img src="/src/public/icons/alert-icon.svg" alt="Alert" className="w-6 h-6" />
            </div>

            {/* Text content */}
            <div>
              <h3 className="text-sm font-semibold text-ui-text-primary mb-1">Critical Supply Chain Alert</h3>
              <p className="text-sm text-ui-text-secondary">
                2 high-impact disruptions detected in Human Health segment – Review required within 48 hours
              </p>
            </div>
          </div>

          {/* View Details button */}
          <button
            className="shrink-0 px-4 py-2 text-sm font-medium rounded-md text-brand-primary-main border-2 border-brand-primary-main"
            style={{ borderRadius: "4px" }}
          >
            View Details
          </button>
        </div>
      </div>
    </div>
  );
}
