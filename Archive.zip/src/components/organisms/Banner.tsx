import { type ReactNode } from "react";

/** Main content pull-up over the banner. Keep in sync with `BANNER_CONTENT_RESERVE_CLASS`. */
export const BANNER_CONTENT_OVERLAP_CLASS = "-mt-32";

/** Bottom padding below banner filters so overlap does not cover tags. */
export const BANNER_CONTENT_RESERVE_CLASS = "pb-32";

export interface BannerProps {
  backgroundClassName: string;
  title: ReactNode;
  titleClassName?: string;
  description?: string;
  rightSideContent?: ReactNode;
}

/**
 * Hero banner with a decorative background layer and foreground content in normal
 * document flow. When `rightSideContent` (e.g. global filters) is present, bottom
 * padding reserves space for main content overlap (`BANNER_CONTENT_OVERLAP_CLASS`).
 */
export function Banner({ backgroundClassName, title, titleClassName, description, rightSideContent }: BannerProps) {
  return (
    <section className="relative isolate min-h-[320px]">
      <div
        className={`absolute inset-0 -z-10 bg-cover bg-center bg-no-repeat ${backgroundClassName}`}
        aria-hidden="true"
      />
      <div
        className={`relative w-full max-w-(--breakpoint-2xl) mx-auto px-4 sm:px-6 lg:px-8 pt-8 md:pt-12 ${
          rightSideContent ? `${BANNER_CONTENT_RESERVE_CLASS} xl:pb-12` : "pb-8 md:pb-12"
        }`}
      >
        <div className="flex w-full min-w-0 flex-col items-stretch gap-4 xl:flex-row xl:items-start">
          <div className="flex min-w-0 flex-1 items-center gap-4 md:gap-6 xl:mt-0">
            <div className="min-w-0 flex-1">
              <h1 className={`mb-2 font-bold text-white ${titleClassName ?? "text-3xl md:text-4xl lg:text-5xl"}`}>
                {title}
              </h1>
              {description && (
                <p className="relative block w-full max-w-none text-sm font-light text-[#A1A1A1] md:text-lg">
                  {description}
                </p>
              )}
            </div>
          </div>
          {rightSideContent && (
            <div className="mb-4 flex w-full min-w-0 shrink-0 flex-col items-stretch gap-2 xl:max-w-[min(100%,40rem)] xl:items-end">
              {rightSideContent}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
