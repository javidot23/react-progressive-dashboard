import { useState, useEffect } from "react";
import { ModalShell } from "@/components/atoms/ModalShell";
import { X, MapPin } from "lucide-react";
import { supplyChainEventsService, type DetailedSupplyChainEvent } from "@/lib/apiServices";
import { RiskBadge } from "@/components/atoms/RiskBadge";
import { MapContainer, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import usStatesData from "@/public/data/us-states.json";

export interface EventDetails {
  magnitude?: number;
  depth?: string;
  epicenter?: string;
  affectedRadius?: string;
}

export interface InsightAlertModalData {
  id: string;
  title: string;
  description: string;
  impactLevel?: "High Impact" | "Medium Impact" | "Low Impact";
  likelihood?: "Highly Likely" | "Likely" | "Possible";
  eventDetails?: EventDetails;
  eventLocation?: {
    coordinates?: string;
    state?: string;
    stateCode?: string;
  };
  affectedMaterials?: string[];
  recommendation?: string;
  knowledgeGraphLink?: string;
  onViewKnowledgeGraph?: () => void;
}

interface InsightAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  alert: InsightAlertModalData;
  triggerRef?: React.RefObject<HTMLElement | null>;
}
const createEventIcon = (color: string) => {
  return L.divIcon({
    className: "custom-event-marker",
    html: `
            <div style="
                width: 24px;
                height: 24px;
                background-color: ${color};
                border: 3px solid white;
                border-radius: 50% 50% 50% 0;
                transform: rotate(-45deg);
                box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            ">
                <div style="
                    width: 8px;
                    height: 8px;
                    background-color: white;
                    border-radius: 50%;
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%) rotate(45deg);
                "></div>
            </div>
        `,
    iconSize: [24, 24],
    iconAnchor: [12, 24],
    popupAnchor: [0, -24],
  });
};

// Component to add map styles (background color)
const MapStyles: React.FC = () => {
  useEffect(() => {
    const styleId = "insight-alert-modal-map-styles";

    if (!document.getElementById(styleId)) {
      const styleSheet = document.createElement("style");
      styleSheet.id = styleId;
      styleSheet.textContent = `
                .insight-alert-map .leaflet-container {
                    background: #f8fafc;
                    overflow: hidden !important;
                }
                .insight-alert-map .leaflet-map-pane {
                    overflow: visible !important;
                }
            `;
      document.head.appendChild(styleSheet);
    }

    return () => {
      const existingStyle = document.getElementById(styleId);
      existingStyle?.remove();
    };
  }, []);

  return null;
};

// Component to add US states GeoJSON background
const MapBackgroundLayer: React.FC = () => {
  const map = useMap();

  useEffect(() => {
    // Add US states GeoJSON background
    const geojsonData = usStatesData as any;
    const geoJsonLayer = L.geoJSON(geojsonData, {
      style: {
        fillColor: "#CACACA",
        color: "#ffffff", // White borders
        weight: 1,
        opacity: 1,
        fillOpacity: 1,
      },
    });
    geoJsonLayer.addTo(map);

    return () => {
      // Cleanup: remove GeoJSON layer
      map.removeLayer(geoJsonLayer);
    };
  }, [map]);

  return null;
};

// Component to handle map markers and circles
const EventMapMarkers: React.FC<{ eventData: DetailedSupplyChainEvent }> = ({ eventData }) => {
  const map = useMap();

  useEffect(() => {
    if (!eventData.latitude || !eventData.longitude) return;

    const mainEventLat = eventData.latitude;
    const mainEventLng = eventData.longitude;

    // Clear any existing markers and circles (but keep GeoJSON background)
    map.eachLayer(layer => {
      if (layer instanceof L.Marker || layer instanceof L.Circle) {
        map.removeLayer(layer);
      }
    });

    // Create main event marker (purple)
    const mainMarker = L.marker([mainEventLat, mainEventLng], {
      icon: createEventIcon("#9333EA"), // Purple color
    });
    mainMarker.addTo(map);

    // Add concentric circles around main event (orange)
    const circleRadii = [50000, 100000, 150000]; // 50km, 100km, 150km in meters
    circleRadii.forEach((radius, index) => {
      const circle = L.circle([mainEventLat, mainEventLng], {
        radius: radius,
        color: "#F97316", // Orange color
        fillColor: "#F97316",
        fillOpacity: 0.1 - index * 0.02, // Decreasing opacity
        weight: 1,
      });
      circle.addTo(map);
    });

    // Add markers for related events with coordinates (blue)
    if (eventData.related_events) {
      eventData.related_events.forEach(relatedEvent => {
        if (relatedEvent.latitude !== null && relatedEvent.longitude !== null) {
          const relatedMarker = L.marker([relatedEvent.latitude, relatedEvent.longitude], {
            icon: createEventIcon("#3B82F6"), // Blue color
          });
          relatedMarker.addTo(map);
        }
      });
    }

    // Fit map to show all markers and circles
    const bounds = L.latLngBounds([[mainEventLat, mainEventLng]]);
    if (eventData.related_events) {
      eventData.related_events.forEach(relatedEvent => {
        if (relatedEvent.latitude !== null && relatedEvent.longitude !== null) {
          bounds.extend([relatedEvent.latitude, relatedEvent.longitude]);
        }
      });
    }
    // Expand bounds to include circles
    bounds.extend([mainEventLat + 1, mainEventLng + 1]);
    bounds.extend([mainEventLat - 1, mainEventLng - 1]);
    map.fitBounds(bounds, { padding: [20, 20] });

    return () => {
      // Cleanup: remove only markers and circles (keep GeoJSON background)
      map.eachLayer(layer => {
        if (layer instanceof L.Marker || layer instanceof L.Circle) {
          map.removeLayer(layer);
        }
      });
    };
  }, [map, eventData]);

  return null;
};

export function InsightAlertModal({ isOpen, onClose, alert, triggerRef }: InsightAlertModalProps) {
  const [eventData, setEventData] = useState<DetailedSupplyChainEvent | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && alert.id) {
      fetchEventDetails();
    } else {
      setEventData(null);
      setError(null);
    }
  }, [isOpen, alert.id]);

  const fetchEventDetails = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await supplyChainEventsService.getSupplyChainEvent(alert.id);
      setEventData(response.data.data);
    } catch (err) {
      console.error("Failed to fetch event details:", err);
      setError("Failed to load event details");
    } finally {
      setLoading(false);
    }
  };

  const getRiskRating = (): number => {
    if (!eventData?.mat_nbr) return 0;
    return eventData.mat_nbr.risk_rating || 0;
  };

  const formatCoordinates = () => {
    if (!eventData) return null;
    if (eventData.latitude !== null && eventData.longitude !== null) {
      const lat =
        eventData.latitude >= 0 ? `${eventData.latitude.toFixed(4)}° N` : `${Math.abs(eventData.latitude).toFixed(4)}° S`;
      const lng =
        eventData.longitude >= 0 ? `${eventData.longitude.toFixed(4)}° E` : `${Math.abs(eventData.longitude).toFixed(4)}° W`;
      return `${lat}, ${lng}`;
    }
    return null;
  };

  // Get affected materials from event data or fallback to alert data
  const affectedMaterials = eventData?.mat_nbr
    ? (() => {
        let main = `${eventData.mat_nbr.name} • ${eventData.mat_nbr.mat_nbr || ""}`;
        if (eventData.mat_nbr.scrm_mat_grp) main += ` • ${eventData.mat_nbr.scrm_mat_grp}`;
        return [main];
      })()
    : alert.affectedMaterials || [];

  // Add related events materials
  if (eventData?.related_events) {
    eventData.related_events.forEach(relatedEvent => {
      if (relatedEvent.mat_nbr) {
        let materialDisplay = `${relatedEvent.mat_nbr.name} • ${relatedEvent.mat_nbr.mat_nbr || ""}`;
        if (relatedEvent.mat_nbr.scrm_mat_grp) materialDisplay += ` • ${relatedEvent.mat_nbr.scrm_mat_grp}`;
        if (!affectedMaterials.includes(materialDisplay)) {
          affectedMaterials.push(materialDisplay);
        }
      }
    });
  }

  const displayTitle = eventData?.type || alert.title;
  const displayDescription = eventData?.type_description || eventData?.metadata || alert.description;
  const coordinates = formatCoordinates();
  const riskRating = getRiskRating();

  return (
    <ModalShell
      isOpen={isOpen}
      onClose={onClose}
      ariaLabelledBy="insight-alert-modal-title"
      usePortal
      zIndex={999999}
      triggerRef={triggerRef}
      className="bg-white rounded-[8px] shadow-xl max-w-2xl w-full mx-4 max-h-[min(90dvh,100%)] min-h-140 flex flex-col overflow-hidden"
      lockScroll={false}
    >
      {/* Header */}
      <div className="flex shrink-0 items-start justify-between px-6 pt-4">
        {loading ? (
          <div className="flex-1">
            <div className="flex flex-col items-start gap-2">
              <div className="h-7 w-64 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-6 w-24 bg-gray-200 rounded animate-pulse"></div>
            </div>
          </div>
        ) : (
          <div className="flex-1">
            <div className="flex flex-col items-start gap-2">
              <h2 id="insight-alert-modal-title" className="text-xl font-bold text-gray-900">
                {displayTitle}
              </h2>
              <div className="flex items-center gap-2 flex-wrap">
                <RiskBadge riskRating={riskRating} showIcon={true} size="sm" />
              </div>
            </div>
          </div>
        )}
        <button
          type="button"
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600 transition-colors p-1"
          aria-label="Close alert details dialog"
        >
          <X className="h-5 w-5" aria-hidden />
        </button>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain">
      {loading && (
        <div className="px-6 py-4 space-y-4 flex-1 min-h-115">
          {/* Description Skeleton */}
          <div className="space-y-2">
            <div className="h-5 w-24 bg-gray-200 rounded animate-pulse"></div>
            <div className="space-y-2">
              <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
              <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
              <div className="h-4 w-3/4 bg-gray-200 rounded animate-pulse"></div>
            </div>
          </div>

          {/* Event Location Skeleton */}
          <div className="space-y-2">
            <div className="h-5 w-32 bg-gray-200 rounded animate-pulse"></div>
            <div className="bg-gray-100 rounded-lg p-4 min-h-50 flex items-center justify-center">
              <div className="w-full h-full bg-gray-200 rounded-lg animate-pulse"></div>
            </div>
            <div className="h-4 w-64 bg-gray-200 rounded animate-pulse"></div>
          </div>

          {/* Affected Materials Skeleton */}
          <div className="space-y-2">
            <div className="h-5 w-40 bg-gray-200 rounded animate-pulse"></div>
            <div className="flex flex-wrap gap-2">
              <div className="h-6 w-32 bg-gray-200 rounded-full animate-pulse"></div>
              <div className="h-6 w-28 bg-gray-200 rounded-full animate-pulse"></div>
              <div className="h-6 w-36 bg-gray-200 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="px-6 py-8 text-center">
          <div className="text-red-500">{error}</div>
        </div>
      )}

      {!loading && !error && (
        <div className="px-6 py-4 space-y-3 flex-1 min-h-115">
          {/* Description */}
          <div className="flex flex-col">
            <h2 className="text-base font-bold text-gray-900 mb-2">Description</h2>
            <p className="text-gray-700 text-sm leading-relaxed whitespace-pre-line">{displayDescription}</p>
          </div>

          {/* Event Location: map only when coordinates exist; otherwise "no location" placeholder */}
          {eventData && (
            <div className="space-y-2 rounded-[4px] border p-4">
              <h3 className="text-sm font-semibold text-gray-900 flex items-center gap-2">
                <MapPin className="h-4 w-4" color="#593AB1" />
                Event Location
              </h3>
              {eventData.latitude != null && eventData.longitude != null ? (
                <>
                  <div className="bg-gray-100 rounded-lg min-h-50 relative overflow-hidden">
                    <MapContainer
                      center={[eventData.latitude, eventData.longitude]}
                      zoom={4}
                      minZoom={3}
                      maxZoom={10}
                      zoomControl={true}
                      attributionControl={false}
                      scrollWheelZoom={true}
                      doubleClickZoom={true}
                      dragging={true}
                      touchZoom={true}
                      className="w-full h-50 rounded-[4px] z-0 insight-alert-map"
                      style={{ position: "relative" }}
                    >
                      <MapStyles />
                      <MapBackgroundLayer />
                      <EventMapMarkers eventData={eventData} />
                    </MapContainer>
                  </div>
                  {(coordinates || eventData.city || eventData.state) && (
                    <div className="flex flex-row items-center justify-center text-sm bg-[#F5F5F5] rounded-[4px] p-2 text-[#6B7280]">
                      <div className="flex flex-row items-center justify-center space-x-2">
                        {coordinates && <span>{coordinates}</span>}
                        {coordinates && eventData.city && eventData.state && <span className="mx-1">•</span>}
                        {eventData.city && eventData.state && (
                          <span>
                            {eventData.city}, {eventData.state}
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="bg-gray-100 rounded-lg min-h-50 flex items-center justify-center">
                  <p className="text-gray-500 text-sm font-medium text-center px-4">No location available for this event</p>
                </div>
              )}
            </div>
          )}

          {/* Affected Materials */}
          {affectedMaterials.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-base font-semibold text-gray-900">Affected Materials</h3>
              <div className="flex flex-wrap gap-2">
                {affectedMaterials.map((material, index) => (
                  <span key={index} className="bg-[#EEEDFE] text-[#461E96] px-2.5 py-1 rounded-full text-xs font-medium">
                    {material}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      </div>
    </ModalShell>
  );
}
