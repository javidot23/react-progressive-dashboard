import { useState, useEffect, useCallback, useRef, useMemo, useLayoutEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { Link, useLocation } from "react-router-dom";
import apiClient from "@/lib/apiClient";
import { customListsService } from "@/lib/apiServices";
import { getCurrentMode } from "@/lib/globalFiltersInterceptor";
import { toWafSafeQueryString } from "@/lib/queryStringUtils";
import { useGlobalFiltersStore, FilterValueType, isMultiFilter } from "@/stores/slices/globalFilters";
import { getFormularyContractTypeLabel, getMaterialStatusDescription, getProductCategoryLabel } from "@/lib/utils";
import { getAllGcnLabel, getGcnLabel, getMaterialSearchPlaceholder } from "@/lib/gcnLabels";
import { isFullFeatureSet, isVariantFamily } from "@/tenant";
import filterIcon from "@/assets/icons/filters-primary-icon.svg";
import removeIcon from "@/assets/icons/x-icon-primary.svg";
import filterIconPrimary from "@/assets/icons/filter-lines-primary.svg";
import { CreateNewListModal } from "@/components/molecules/CreateNewListModal";
import { icons } from "@/components/custom-lists/components/Icons";
import { Checkbox } from "@/components/atoms";
import Tooltip from "@/components/atoms/Tooltip";

function formatFormularyFilterValue(value: FilterValueType): string {
  if (isMultiFilter(value)) {
    return value.ids.map(id => getFormularyContractTypeLabel(String(id))).join(", ");
  }
  return getFormularyContractTypeLabel(value.id);
}

function formatProductCategoryFilterValue(value: FilterValueType): string {
  if (isMultiFilter(value)) {
    return value.ids.map(id => getProductCategoryLabel(String(id))).join(", ");
  }
  return getProductCategoryLabel(String(value.id));
}

const FILTER_NAME_MAP: Record<string, string> = {
  gf_supplier: "Supplier",
  gf_supplier_parent: "Supplier Parent",
  gf_product_category: "Product Category",
  gf_therapeutic_class: "Therapeutic Class",
  gf_buyer: "Buyer",
  gf_category_manager: "Category Manager",
  gf_material: "Material",
  gf_gcn: getGcnLabel(),
  gf_formulary: "Formulary",
  gf_formulary_program: "Formulary Program",
  gf_material_status: "Material Status",
  gf_customer: "Customer",
  gf_custom_list: "Custom Lists",
  gf_injectable: "Injectable",
  gf_who_essential: "WHO Essential",
  gf_fee_for_service: "Fee for Service",
};
interface DropdownItem {
  id: string | number;
  name: string;
  icon?: string;
}
interface SupplierItem extends DropdownItem {
  vendor_nbr: string | number;
}
interface MaterialItem extends DropdownItem {
  mat_nbr: string | number;
}

interface CustomerItem extends DropdownItem {
  cust_corp_chain_nbr: string | number;
}
interface ApiResponse {
  data?: {
    results?: unknown[];
    [key: string]: unknown;
  };
  results?: unknown[];
  [key: string]: unknown;
}

type FilterId =
  | "custom_list"
  | "supplier"
  | "supplier_parent"
  | "product_category"
  | "therapeutic_class"
  | "buyer"
  | "category_manager"
  | "material"
  | "gcn"
  | "formulary"
  | "formulary_program"
  | "material_status"
  | "customer"
  | "injectable"
  | "who_essential"
  | "fee_for_service";

const VARIANT_HIDDEN_FILTER_IDS = new Set<FilterId>([
  "therapeutic_class",
  "buyer",
  "category_manager",
  "customer",
  "supplier_parent",
  "formulary_program",
]);

const FILTER_CATEGORIES_ALL = [
  { id: "supplier" as FilterId, label: "Supplier", defaultValue: "All Suppliers", endpoint: "/vendor/", searchParam: "search" },
  {
    id: "supplier_parent" as FilterId,
    label: "Supplier Parent",
    defaultValue: "All Supplier Parents",
    endpoint: "/vendor/parents/",
    searchParam: "search",
  },
  {
    id: "product_category" as FilterId,
    label: "Product Category",
    defaultValue: "All Categories",
    endpoint: "/material/group/",
    searchParam: "material_group",
  },
  {
    id: "therapeutic_class" as FilterId,
    label: "Therapeutic Class",
    defaultValue: "All Therapeutic Classes",
    endpoint: "/material/therapy-class/",
    searchParam: "hic3_therapy_class",
  },
  {
    id: "buyer" as FilterId,
    label: "Buyer",
    defaultValue: "All Buyers",
    endpoint: "/material/buyer/",
    searchParam: "buyer_name",
  },
  {
    id: "category_manager" as FilterId,
    label: "Category Manager",
    defaultValue: "All Managers",
    endpoint: "/material/category-manager/",
    searchParam: "cat_mgr_name",
  },
  { id: "material" as FilterId, label: "Material", defaultValue: "All Materials", endpoint: "/material/", searchParam: "search" },
  {
    id: "gcn" as FilterId,
    label: getGcnLabel(),
    defaultValue: getAllGcnLabel(),
    endpoint: "/material/gcn/",
    searchParam: "fdb_gcn_seq_nbr",
  },
  {
    id: "formulary" as FilterId,
    label: "Formulary (Contract Type)",
    defaultValue: "All Contract Types",
    endpoint: "/material-formulary/unique/",
    searchParam: "name",
  },
  {
    id: "formulary_program" as FilterId,
    label: "Formulary Program",
    defaultValue: "All Programs",
    endpoint: "/material-formulary/unique-program-descriptions/",
    searchParam: "name",
  },
  {
    id: "material_status" as FilterId,
    label: "Material Status",
    defaultValue: "All Statuses",
    endpoint: "/material/xplant-mat-stat/",
    searchParam: "xplant_mat_stat",
  },
  {
    id: "customer" as FilterId,
    label: "Customer",
    defaultValue: "All Customers",
    endpoint: "/customer-corp-chain/",
    searchParam: "search",
  },
];

const FILTER_CATEGORIES = isVariantFamily()
  ? FILTER_CATEGORIES_ALL.filter(c => !VARIANT_HIDDEN_FILTER_IDS.has(c.id))
  : FILTER_CATEGORIES_ALL;

const BOOLEAN_FILTER_CATEGORIES_ALL: { id: FilterId; label: string; defaultValue: string }[] = [
  { id: "injectable", label: "Injectable", defaultValue: "All" },
  { id: "who_essential", label: "WHO Essential", defaultValue: "All" },
  { id: "fee_for_service", label: "Fee for Service", defaultValue: "All" },
];

const VARIANT_HIDDEN_BOOLEAN_FILTER_IDS = new Set<FilterId>(["injectable"]);
const STRATIUM_ONLY_BOOLEAN_FILTER_IDS = new Set<FilterId>(["fee_for_service"]);

const BOOLEAN_FILTER_CATEGORIES = BOOLEAN_FILTER_CATEGORIES_ALL.filter(c => {
  if (STRATIUM_ONLY_BOOLEAN_FILTER_IDS.has(c.id)) return isFullFeatureSet();
  if (isVariantFamily() && VARIANT_HIDDEN_BOOLEAN_FILTER_IDS.has(c.id)) return false;
  return true;
});

interface GlobalFiltersProps {
  isBannerMode?: boolean;
  variant?: "banner" | "default";
}

/** Dropdown row: tooltip only when the label span is visually truncated. */
function OptionItem({
  tooltipContent,
  selected,
  ariaLabel,
  onClick,
  iconSlot,
  displayName,
}: {
  tooltipContent: string;
  selected: boolean;
  ariaLabel: string;
  onClick: () => void;
  iconSlot?: ReactNode;
  displayName: string;
}) {
  const spanRef = useRef<HTMLSpanElement | null>(null);
  const [isTruncated, setIsTruncated] = useState(false);

  useLayoutEffect(() => {
    const el = spanRef.current;
    if (!el) return;
    const measure = () => setIsTruncated(el.scrollWidth > el.clientWidth);
    measure();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(measure) : null;
    ro?.observe(el);
    return () => {
      ro?.disconnect();
    };
  }, [displayName]);

  return (
    <Tooltip content={tooltipContent} position="top" className="block w-full" disabled={!isTruncated}>
      <button
        type="button"
        role="option"
        aria-selected={selected}
        aria-label={ariaLabel}
        onClick={onClick}
        className="flex items-center gap-2 w-full px-3 py-2 text-left text-sm text-ui-text-secondary hover:bg-ui-background-muted transition-colors"
      >
        <Checkbox checked={selected} onCheckedChange={() => {}} className="pointer-events-none flex-shrink-0" />
        {iconSlot}
        <span ref={spanRef} className="truncate">
          {displayName}
        </span>
      </button>
    </Tooltip>
  );
}

export default function GlobalFilters({ isBannerMode = false, variant }: GlobalFiltersProps = {}) {
  // Support both isBannerMode (legacy) and variant prop
  const bannerMode = isBannerMode || variant === "banner";
  const location = useLocation();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCreateListModalOpen, setIsCreateListModalOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [dropdownPosition, setDropdownPosition] = useState<Record<string, "top" | "bottom">>({});
  const [currentMode, setCurrentMode] = useState<"APPLY" | "SHOW_DISABLED" | "IGNORE">(getCurrentMode());
  const { filters: storeFilters, setFilter, removeFilter: removeFromStore, clearFilters: clearStore } = useGlobalFiltersStore();
  const [searches, setSearches] = useState<Record<FilterId, string>>({
    custom_list: "",
    supplier: "",
    supplier_parent: "",
    product_category: "",
    therapeutic_class: "",
    buyer: "",
    category_manager: "",
    material: "",
    gcn: "",
    formulary: "",
    formulary_program: "",
    material_status: "",
    customer: "",
    injectable: "",
    who_essential: "",
    fee_for_service: "",
  });
  const [filterData, setFilterData] = useState<Record<FilterId, DropdownItem[]>>({
    custom_list: [],
    supplier: [],
    supplier_parent: [],
    product_category: [],
    therapeutic_class: [],
    buyer: [],
    category_manager: [],
    material: [],
    gcn: [],
    formulary: [],
    formulary_program: [],
    material_status: [],
    customer: [],
    injectable: [],
    who_essential: [],
    fee_for_service: [],
  });
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const [pendingFilters, setPendingFilters] = useState<Record<string, FilterValueType>>({});
  const pendingFiltersRef = useRef<Record<string, FilterValueType>>({});
  const [pagination, setPagination] = useState<Record<FilterId, { hasMore: boolean; offset: number; limit: number }>>({
    custom_list: { hasMore: true, offset: 0, limit: 10 },
    supplier: { hasMore: true, offset: 0, limit: 10 },
    supplier_parent: { hasMore: true, offset: 0, limit: 10 },
    product_category: { hasMore: true, offset: 0, limit: 10 },
    therapeutic_class: { hasMore: true, offset: 0, limit: 10 },
    buyer: { hasMore: true, offset: 0, limit: 10 },
    category_manager: { hasMore: true, offset: 0, limit: 10 },
    material: { hasMore: true, offset: 0, limit: 10 },
    gcn: { hasMore: true, offset: 0, limit: 10 },
    formulary: { hasMore: true, offset: 0, limit: 10 },
    formulary_program: { hasMore: true, offset: 0, limit: 10 },
    material_status: { hasMore: true, offset: 0, limit: 10 },
    customer: { hasMore: true, offset: 0, limit: 10 },
    injectable: { hasMore: false, offset: 0, limit: 0 },
    who_essential: { hasMore: false, offset: 0, limit: 0 },
    fee_for_service: { hasMore: false, offset: 0, limit: 0 },
  });
  const paginationRef = useRef(pagination);
  const searchesRef = useRef(searches);
  const fetchingRef = useRef<Record<string, boolean>>({});
  const debounceTimers = useRef<Record<string, NodeJS.Timeout>>({});
  const abortControllers = useRef<Record<string, AbortController>>({});
  const latestSearchTerms = useRef<Record<string, string>>({});
  const previousSearches = useRef<Record<FilterId, string>>(searches);
  const searchInputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const dropdownButtonRefs = useRef<Record<string, HTMLButtonElement | null>>({});

  const appliedFilters = useMemo(() => {
    const filters: Record<string, FilterValueType> = {};
    Object.entries(storeFilters).forEach(([key, value]) => {
      if (key.startsWith("gf_")) {
        const cleanKey = key.replace("gf_", "");
        filters[cleanKey] = value;
      }
    });
    return filters;
  }, [storeFilters]);

  const appliedFiltersFetchedRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    const filtersToFetch = ["custom_list", "supplier"] as const;

    filtersToFetch.forEach(filterId => {
      const hasAppliedFilter = appliedFilters[filterId];
      const dataNotLoaded = filterData[filterId].length === 0;
      const notYetFetched = !appliedFiltersFetchedRef.current.has(filterId);

      if (hasAppliedFilter && dataNotLoaded && notYetFetched) {
        appliedFiltersFetchedRef.current.add(filterId);
        if (filterId === "custom_list") {
          const fetchCustomListsData = async () => {
            try {
              const response = await customListsService.getCustomLists({ limit: 50, offset: 0 });
              const results = response.data.data.results ?? [];
              const items: DropdownItem[] = results
                .filter((item: { id?: string; name: string }) => item.id)
                .map((item: { id?: string; name: string; icon?: string }) => ({
                  id: item.id as string,
                  name: item.name,
                  icon: item.icon,
                }));
              setFilterData(prev => ({ ...prev, custom_list: items }));
            } catch (e) {
              console.error("Failed to fetch custom lists for tooltip:", e);
            }
          };
          fetchCustomListsData();
        } else if (filterId === "supplier") {
          const fetchSuppliersData = async () => {
            try {
              const response = await apiClient.get("/vendor/?limit=50&offset=0");
              const results = response.data?.data?.results ?? response.data?.results ?? [];
              const items: DropdownItem[] = results.map(
                (item: { vendor_nbr?: number; id?: string; vendor_name?: string; name?: string }) =>
                  ({
                    id: item.vendor_nbr?.toString() || item.id || "",
                    name: item.vendor_name || item.name || "",
                    vendor_nbr: item.vendor_nbr,
                  }) as DropdownItem
              );
              setFilterData(prev => ({ ...prev, supplier: items }));
            } catch (e) {
              console.error("Failed to fetch suppliers for tooltip:", e);
            }
          };
          fetchSuppliersData();
        }
      }
    });
  }, [appliedFilters, filterData]);

  useEffect(() => {
    paginationRef.current = pagination;
  }, [pagination]);

  useEffect(() => {
    searchesRef.current = searches;
  }, [searches]);

  useEffect(() => {
    pendingFiltersRef.current = pendingFilters;
  }, [pendingFilters]);

  useEffect(() => {
    setCurrentMode(getCurrentMode());
  }, [location.pathname]);

  useEffect(() => {
    const controllers = abortControllers.current;
    return () => {
      Object.values(controllers).forEach(controller => {
        controller.abort();
      });
    };
  }, []);

  useEffect(() => {
    if (openDropdown && searchInputRefs.current[openDropdown]) {
      const rafId = requestAnimationFrame(() => {
        searchInputRefs.current[openDropdown]?.focus();
      });

      return () => {
        cancelAnimationFrame(rafId);
      };
    }
  }, [openDropdown]);

  // Initialize pending filters when modal opens (normalize legacy FilterValue to MultiFilterValue)
  useEffect(() => {
    if (isModalOpen) {
      const pending: Record<string, FilterValueType> = {};
      Object.entries(storeFilters).forEach(([key, value]) => {
        if (!key.startsWith("gf_")) return;
        const cleanKey = key.replace("gf_", "");

        if (cleanKey === "injectable" || cleanKey === "who_essential" || cleanKey === "fee_for_service") {
          pending[cleanKey] = isMultiFilter(value) ? { id: value.ids[0], label: value.labels[0] } : value;
          return;
        }

        if (cleanKey === "custom_list") {
          const ids = isMultiFilter(value) ? value.ids : [value.id];
          const labels = ids.map(id => {
            const item = filterData.custom_list.find(i => String(i.id) === String(id));
            if (item) return item.name;
            if (isMultiFilter(value)) {
              const idx = value.ids.indexOf(id);
              return idx >= 0 ? value.labels[idx] : id;
            }
            return value.label;
          });
          pending[cleanKey] = { ids, labels };
          return;
        }

        if (isMultiFilter(value)) {
          pending[cleanKey] = value;
        } else {
          pending[cleanKey] = { ids: [value.id], labels: [value.label] };
        }
      });
      setPendingFilters(pending);
    }
  }, [isModalOpen, storeFilters, filterData.custom_list]);

  const fetchData = useCallback(
    async (filterId: FilterId, endpoint: string, searchParam: string, searchTerm: string, reset: boolean) => {
      if (abortControllers.current[filterId]) {
        abortControllers.current[filterId].abort();
      }

      const abortController = new AbortController();
      abortControllers.current[filterId] = abortController;

      latestSearchTerms.current[filterId] = searchTerm;

      try {
        fetchingRef.current[filterId] = true;
        setLoading(prev => ({ ...prev, [filterId]: true }));

        const currentPagination = paginationRef.current[filterId];
        const offset = reset ? 0 : currentPagination.offset;
        const limit = currentPagination.limit;

        const params = new URLSearchParams({
          limit: limit.toString(),
          offset: offset.toString(),
          ...(searchTerm && { [searchParam]: searchTerm }),
        });

        if (filterId === "material") {
          const currentPendingFilters = pendingFiltersRef.current;
          const supplierFilter = currentPendingFilters.supplier || appliedFilters.supplier;
          if (supplierFilter) {
            const supplierIds = isMultiFilter(supplierFilter) ? supplierFilter.ids.join(",") : supplierFilter.id;
            params.set("supplier", supplierIds);
          }
        }

        const apiUrl = `${endpoint}?${toWafSafeQueryString(params)}`;
        const response = await apiClient.get(apiUrl, {
          signal: abortController.signal,
        });

        if (latestSearchTerms.current[filterId] !== searchTerm) {
          return;
        }

        const data = response.data as ApiResponse;
        const results = data.data?.results || data.results || data.data || data || [];
        const rawItems: unknown[] = Array.isArray(results) ? results : [];

        const newItems = rawItems.map((item: unknown) => {
          const itemRecord = item as Record<string, unknown>;
          switch (filterId) {
            case "product_category": {
              const code = String(itemRecord.material_group ?? "").trim();
              return {
                id: code,
                name: getProductCategoryLabel(code),
                ...itemRecord,
              };
            }
            case "therapeutic_class":
              return {
                id: itemRecord.hic3_therapy_class as string,
                name: itemRecord.hic3_therapy_class as string,
                ...itemRecord,
              };
            case "buyer":
              return {
                id: itemRecord.buyer_name as string | number,
                name: itemRecord.buyer_name as string,
                ...itemRecord,
              };
            case "category_manager":
              return {
                id: itemRecord.cat_mgr_name as string | number,
                name: itemRecord.cat_mgr_name as string,
                ...itemRecord,
              };
            case "gcn":
              return {
                id: itemRecord.fdb_gcn_seq_nbr as string | number,
                name: itemRecord.fdb_gcn_seq_nbr as string,
                ...itemRecord,
              };
            case "material_status":
              return {
                id: itemRecord.xplant_mat_stat as string,
                name: getMaterialStatusDescription(itemRecord.xplant_mat_stat as string),
                ...itemRecord,
              };
            case "customer":
              return {
                id: itemRecord.cust_corp_chain_nbr as string,
                name: itemRecord.name as string,
                ...itemRecord,
              };
            case "formulary": {
              const code = String(itemRecord.name ?? itemRecord.id ?? "").trim();
              return {
                id: code,
                name: getFormularyContractTypeLabel(code),
                ...itemRecord,
              };
            }
            case "formulary_program": {
              const name = String(itemRecord.name ?? "").trim();
              return { id: name, name, ...itemRecord };
            }
            case "supplier_parent":
              return {
                id: itemRecord.vendor_parent_id as string,
                name: itemRecord.vendor_parent_name
                  ? `(${itemRecord.vendor_parent_id}) ${itemRecord.vendor_parent_name}`
                  : (itemRecord.vendor_parent_id as string),
                ...itemRecord,
              };
            default:
              return {
                id: (itemRecord.id as string | number) || "",
                name: (itemRecord.name as string) || "",
                ...itemRecord,
              } as DropdownItem;
          }
        });

        setFilterData(prev => ({
          ...prev,
          [filterId]: reset ? newItems : [...prev[filterId], ...newItems],
        }));

        const hasMore = newItems.length === limit;
        setPagination(prev => ({
          ...prev,
          [filterId]: {
            ...prev[filterId],
            hasMore,
            offset: offset + newItems.length,
          },
        }));
      } catch (error) {
        if (error instanceof Error && (error.name === "AbortError" || error.name === "CanceledError")) {
          return;
        }
        console.error(`Error fetching ${filterId}:`, error);
      } finally {
        if (latestSearchTerms.current[filterId] === searchTerm) {
          fetchingRef.current[filterId] = false;
          setLoading(prev => ({ ...prev, [filterId]: false }));
        }
      }
    },
    []
  );

  const fetchFilterData = useCallback(
    (filterId: FilterId, searchTerm = "", reset = false) => {
      const category = FILTER_CATEGORIES.find(c => c.id === filterId);
      if (!category) return;

      fetchData(filterId, category.endpoint, category.searchParam, searchTerm, reset);
    },
    [fetchData]
  );

  const fetchCustomLists = useCallback(async (searchTerm = "", reset = false) => {
    const filterId = "custom_list" as FilterId;

    try {
      fetchingRef.current[filterId] = true;
      setLoading(prev => ({ ...prev, [filterId]: true }));

      const currentPagination = paginationRef.current[filterId];
      const offset = reset ? 0 : currentPagination.offset;
      const limit = currentPagination.limit;

      const response = await customListsService.getCustomLists({
        limit,
        offset,
        ...(searchTerm && { search: searchTerm }),
      });

      const data = response.data.data;
      const results = data.results ?? [];

      const newItems: DropdownItem[] = results
        .filter((item: { id?: string; name: string; icon?: string }) => item.id)
        .map((item: { id?: string; name: string; icon?: string }) => ({
          id: item.id as string,
          name: item.name,
          icon: item.icon,
        }));

      setFilterData(prev => ({
        ...prev,
        [filterId]: reset ? newItems : [...prev[filterId], ...newItems],
      }));

      const hasMore = data.next !== null;
      setPagination(prev => ({
        ...prev,
        [filterId]: {
          ...prev[filterId],
          hasMore,
          offset: offset + newItems.length,
        },
      }));
    } catch (error) {
      console.error("Error fetching custom lists:", error);
    } finally {
      fetchingRef.current[filterId] = false;
      setLoading(prev => ({ ...prev, [filterId]: false }));
    }
  }, []);

  useEffect(() => {
    if (openDropdown === "custom_list") {
      const searchTerm = searches.custom_list;
      const previousValue = previousSearches.current.custom_list;

      if (filterData.custom_list.length === 0 || previousValue !== searchTerm) {
        if (debounceTimers.current.custom_list) {
          clearTimeout(debounceTimers.current.custom_list);
        }

        debounceTimers.current.custom_list = setTimeout(() => {
          setPagination(prev => ({
            ...prev,
            custom_list: { ...prev.custom_list, offset: 0, hasMore: true },
          }));
          fetchCustomLists(searchTerm, true);
        }, 300);
      }
    }
  }, [openDropdown, searches.custom_list, fetchCustomLists, filterData.custom_list.length]);

  useEffect(() => {
    Object.entries(searches).forEach(([filterId, searchValue]) => {
      // Skip custom_list as it has its own handler
      if (filterId === "custom_list") return;
      const previousValue = previousSearches.current[filterId as FilterId];

      if (previousValue !== searchValue) {
        if (debounceTimers.current[filterId]) {
          clearTimeout(debounceTimers.current[filterId]);
        }

        debounceTimers.current[filterId] = setTimeout(() => {
          setPagination(prev => ({
            ...prev,
            [filterId]: { ...prev[filterId as FilterId], offset: 0, hasMore: true },
          }));
          fetchFilterData(filterId as FilterId, searchValue, true);
        }, 300);
      }
    });

    previousSearches.current = searches;

    const currentTimers = debounceTimers.current;
    return () => {
      Object.values(currentTimers).forEach(timer => {
        if (timer) clearTimeout(timer);
      });
    };
  }, [searches, fetchFilterData]);

  const handleScroll = useCallback(
    (e: React.UIEvent<HTMLDivElement>, filterId: string) => {
      const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
      const SCROLL_THRESHOLD = 10;
      const isNearBottom = scrollTop + clientHeight >= scrollHeight - SCROLL_THRESHOLD;

      if (!isNearBottom) return;

      const pag = paginationRef.current[filterId as FilterId];
      const isLoading = fetchingRef.current[filterId];

      if (!pag.hasMore || isLoading) return;

      const currentSearch = searchesRef.current[filterId as FilterId];

      if (filterId === "custom_list") {
        fetchCustomLists(currentSearch, false);
      } else {
        fetchFilterData(filterId as FilterId, currentSearch, false);
      }
    },
    [fetchFilterData, fetchCustomLists]
  );

  const calculateDropdownPosition = useCallback((id: string) => {
    const button = dropdownButtonRefs.current[id];
    if (!button) return "bottom";

    const rect = button.getBoundingClientRect();
    const viewportHeight = window.innerHeight;
    const spaceBelow = viewportHeight - rect.bottom;
    const spaceAbove = rect.top;
    const dropdownHeight = 320; // max-h-80 = 320px

    // If not enough space below but enough space above, position upward
    if (spaceBelow < dropdownHeight && spaceAbove > spaceBelow) {
      return "top";
    }
    return "bottom";
  }, []);

  // Recalculate dropdown position when it opens
  useEffect(() => {
    if (openDropdown) {
      const position = calculateDropdownPosition(openDropdown);
      setDropdownPosition((prev: Record<string, "top" | "bottom">) => ({ ...prev, [openDropdown]: position }));
    }
  }, [openDropdown, calculateDropdownPosition]);

  const toggleDropdown = useCallback(
    (id: string) => {
      const newOpenDropdown = openDropdown === id ? null : id;
      setOpenDropdown(newOpenDropdown);

      if (newOpenDropdown) {
        const filterId = id as FilterId;
        if (filterData[filterId].length === 0) {
          fetchFilterData(filterId, "", true);
        }
        // Calculate position after a brief delay to ensure DOM is updated
        setTimeout(() => {
          const position = calculateDropdownPosition(id);
          setDropdownPosition((prev: Record<string, "top" | "bottom">) => ({ ...prev, [id]: position }));
        }, 0);
      }
    },
    [openDropdown, filterData, fetchFilterData, calculateDropdownPosition]
  );

  const clearSearchForFilter = useCallback((filterId: string) => {
    setSearches(prev => ({ ...prev, [filterId]: "" }));
  }, []);

  const clearPendingFilter = useCallback(
    (id: string) => {
      setPendingFilters(prev => {
        const updated = { ...prev };
        delete updated[id];
        return updated;
      });
      clearSearchForFilter(id);
      setOpenDropdown(null);
    },
    [clearSearchForFilter]
  );

  const isSupplierItem = (obj: DropdownItem): obj is SupplierItem => "vendor_nbr" in obj;
  const isMaterialItem = (obj: DropdownItem): obj is MaterialItem => "mat_nbr" in obj;
  const isCustomerItem = (obj: DropdownItem): obj is CustomerItem => "cust_corp_chain_nbr" in obj;

  const getItemId = useCallback((id: string, item: DropdownItem): string => {
    if (id === "supplier" && isSupplierItem(item)) return item.vendor_nbr.toString();
    if (id === "material" && isMaterialItem(item)) return item.mat_nbr.toString();
    if (id === "customer" && isCustomerItem(item)) return item.cust_corp_chain_nbr.toString();
    return item.id?.toString() || item.name;
  }, []);

  const getItemLabel = useCallback(
    (id: string, item: DropdownItem): string => {
      if (id === "formulary") {
        const code = getItemId(id, item);
        return getFormularyContractTypeLabel(code);
      }
      if (id === "product_category") {
        const code = getItemId(id, item);
        return getProductCategoryLabel(code);
      }
      if (id === "material" && (item as MaterialItem).mat_nbr) {
        return `(${(item as MaterialItem).mat_nbr}) ${item.name}`;
      }
      if (id === "supplier" && isSupplierItem(item)) {
        return `(${item.vendor_nbr}) ${item.name}`;
      }
      if (id === "customer" && isCustomerItem(item)) {
        return `(${item.cust_corp_chain_nbr}) ${item.name}`;
      }
      return item.name;
    },
    [getItemId]
  );

  const isItemSelected = useCallback(
    (id: string, item: DropdownItem): boolean => {
      const current = pendingFilters[id];
      if (!current) return false;
      const itemId = getItemId(id, item);
      if (isMultiFilter(current)) return current.ids.includes(itemId);
      return current.id === itemId;
    },
    [pendingFilters, getItemId]
  );

  const toggleFilterSelection = useCallback(
    (id: string, item: DropdownItem) => {
      const itemId = getItemId(id, item);
      const itemLabel = getItemLabel(id, item);

      setPendingFilters(prev => {
        const current = prev[id];
        const multi = current && isMultiFilter(current) ? current : null;

        if (!multi) {
          return { ...prev, [id]: { ids: [itemId], labels: [itemLabel] } };
        }

        const idx = multi.ids.indexOf(itemId);
        if (idx >= 0) {
          const newIds = multi.ids.filter((_, i) => i !== idx);
          const newLabels = multi.labels.filter((_, i) => i !== idx);
          if (newIds.length === 0) {
            const updated = { ...prev };
            delete updated[id];
            return updated;
          }
          return { ...prev, [id]: { ids: newIds, labels: newLabels } };
        }
        return {
          ...prev,
          [id]: {
            ids: [...multi.ids, itemId],
            labels: [...multi.labels, itemLabel],
          },
        };
      });

      if (id === "supplier") {
        setFilterData(prev => ({ ...prev, material: [] }));
        setPagination(prev => ({
          ...prev,
          material: { hasMore: true, offset: 0, limit: 10 },
        }));
      }
    },
    [getItemId, getItemLabel]
  );

  const removeFilter = useCallback(
    (id: string) => {
      removeFromStore(`gf_${id}`);
    },
    [removeFromStore]
  );

  const clearAllFilters = useCallback(() => {
    clearStore();
    setPendingFilters({});
  }, [clearStore]);

  const applyFilters = useCallback(() => {
    clearStore();
    Object.entries(pendingFilters).forEach(([id, filterValue]) => {
      setFilter(`gf_${id}`, filterValue);
    });
    setIsModalOpen(false);
  }, [pendingFilters, clearStore, setFilter]);

  const getFilterLabel = useCallback((filterValue: FilterValueType): string => {
    if (isMultiFilter(filterValue)) {
      return filterValue.labels.join(", ");
    }
    return filterValue.label;
  }, []);

  // Tooltip-specific label formatting
  const getTooltipLabel = useCallback(
    (filterId: string, filterValue: FilterValueType): string => {
      if (filterId === "custom_list") {
        // Custom list: look up names from filterData (don't show GUIDs)
        const ids = isMultiFilter(filterValue) ? filterValue.ids : [filterValue.id];
        return ids
          .map(id => {
            const item = filterData.custom_list.find(i => String(i.id) === String(id));
            return (
              item?.name || (isMultiFilter(filterValue) ? filterValue.labels[filterValue.ids.indexOf(id)] : filterValue.label)
            );
          })
          .join(", ");
      }

      if (filterId === "supplier") {
        // Supplier: look up names from filterData, format as "(ID) Name"
        const ids = isMultiFilter(filterValue) ? filterValue.ids : [filterValue.id];
        return ids
          .map((id, idx) => {
            const item = filterData.supplier.find(
              i => String(i.id) === String(id) || String((i as SupplierItem).vendor_nbr) === String(id)
            );
            const name = item?.name || (isMultiFilter(filterValue) ? filterValue.labels[idx] : filterValue.label);
            // If name already has "(ID)" format, use as-is
            if (name.includes(`(${id})`)) return name;
            return `(${id}) ${name}`;
          })
          .join(", ");
      }

      if (filterId === "formulary") {
        return formatFormularyFilterValue(filterValue);
      }

      if (filterId === "product_category") {
        return formatProductCategoryFilterValue(filterValue);
      }

      // Default: use standard label
      return getFilterLabel(filterValue);
    },
    [getFilterLabel, filterData.custom_list, filterData.supplier]
  );

  const getFilterValue = useCallback(
    (id: string, defaultValue: string) => {
      const pendingValue = pendingFilters[id];
      if (pendingValue) {
        if (id === "formulary") {
          if (isMultiFilter(pendingValue)) {
            if (pendingValue.ids.length === 0) return defaultValue;
            if (pendingValue.ids.length === 1) return formatFormularyFilterValue(pendingValue);
            return `${pendingValue.ids.length} selected`;
          }
          return formatFormularyFilterValue(pendingValue);
        }
        if (id === "product_category") {
          if (isMultiFilter(pendingValue)) {
            if (pendingValue.ids.length === 0) return defaultValue;
            if (pendingValue.ids.length === 1) return formatProductCategoryFilterValue(pendingValue);
            return `${pendingValue.ids.length} selected`;
          }
          return formatProductCategoryFilterValue(pendingValue);
        }
        if (isMultiFilter(pendingValue)) {
          if (pendingValue.ids.length === 0) return defaultValue;
          if (pendingValue.ids.length === 1) return pendingValue.labels[0];
          return `${pendingValue.ids.length} selected`;
        }
        return pendingValue.label;
      }
      const filterValue = appliedFilters[id];
      if (filterValue) {
        if (id === "formulary") {
          if (isMultiFilter(filterValue)) {
            if (filterValue.ids.length === 1) return formatFormularyFilterValue(filterValue);
            return `${filterValue.ids.length} selected`;
          }
          return formatFormularyFilterValue(filterValue);
        }
        if (id === "product_category") {
          if (isMultiFilter(filterValue)) {
            if (filterValue.ids.length === 1) return formatProductCategoryFilterValue(filterValue);
            return `${filterValue.ids.length} selected`;
          }
          return formatProductCategoryFilterValue(filterValue);
        }
        if (isMultiFilter(filterValue)) {
          if (filterValue.ids.length === 1) return filterValue.labels[0];
          return `${filterValue.ids.length} selected`;
        }
        return filterValue.label;
      }
      return defaultValue;
    },
    [appliedFilters, pendingFilters]
  );

  const getDataForFilter = useCallback(
    (filterId: string): DropdownItem[] => {
      return filterData[filterId as FilterId] || [];
    },
    [filterData]
  );

  const getSearchValueForFilter = useCallback(
    (filterId: string): string => {
      return searches[filterId as FilterId] || "";
    },
    [searches]
  );

  const setSearchValueForFilter = useCallback((filterId: string, value: string) => {
    const MAX_LENGTH = 1000;
    const sanitizedValue = value.slice(0, MAX_LENGTH);

    setSearches(prev => ({ ...prev, [filterId as FilterId]: sanitizedValue }));
  }, []);

  const isDisabled = useMemo(() => currentMode === "SHOW_DISABLED", [currentMode]);

  const hasAppliedFilters = useMemo(() => Object.keys(appliedFilters).length > 0, [appliedFilters]);

  if (currentMode === "IGNORE") {
    return null;
  }

  return (
    <>
      <div data-testid="global-filters" className={bannerMode ? "w-full" : ""}>
        {/* Filter Button and Clear All Filters */}
        <div className={`flex items-center gap-2 ${bannerMode ? "justify-end mb-1 xl:-mt-7.5" : ""}`}>
          <button
            onClick={() => setIsModalOpen(true)}
            className={`flex items-center gap-2 font-medium focus:outline-none bg-[#E8E8E8] hover:bg-[#D1D1D1] transition-colors px-3 py-1.5 rounded-md ${bannerMode ? "text-white" : "text-ui-text-secondary"}`}
            disabled={isDisabled}
          >
            <img src={filterIcon} alt="Filters" className="w-5 h-5" />
            <span className="text-sm font-bold text-[#461E96]">Filters</span>
          </button>
          {hasAppliedFilters && (
            <button
              onClick={clearAllFilters}
              disabled={isDisabled}
              className={`bg-transparent text-white border-2 border-white text-sm px-3 py-1 rounded-md font-bold hover:opacity-80 transition-opacity shrink-0 ${isDisabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
              aria-label="Clear all filters"
            >
              Clear all filters
            </button>
          )}
        </div>

        {/* Applied Filters Tags - Displayed outside modal */}
        {hasAppliedFilters && (
          <div
            className={` ${bannerMode ? "grid grid-cols-2 md:grid-cols-4 gap-2 w-full [direction:rtl]" : "lg:flex gap-2 flex-wrap mt-2 justify-end"}`}
          >
            {Object.entries(appliedFilters).map(([id, filterValue]) => {
              const filterName = FILTER_NAME_MAP[`gf_${id}`] || id;
              const tooltipContent = isDisabled ? (
                <>
                  Visible here but not applied to API on this page - <strong>{filterName}:</strong>{" "}
                  {getTooltipLabel(id, filterValue)}
                </>
              ) : (
                <>
                  <strong>{filterName}:</strong> {getTooltipLabel(id, filterValue)}
                </>
              );

              return (
                <Tooltip key={id} content={tooltipContent} disabled={false} contentMaxHeight={80}>
                  <div
                    className={`relative group ${bannerMode ? "bg-[#EEEDFE] text-ui-text-primary [direction:ltr]" : "bg-white text-ui-text-primary"} border-2 border-[#C1BBEE] text-sm pl-1 pr-0 py-1 rounded-[4px] flex items-center gap-2 ${isDisabled ? "opacity-50" : ""} ${bannerMode ? "min-w-0" : ""}`}
                  >
                    <span className={`font-bold text-sm flex-1 min-w-0 ${bannerMode ? "truncate" : ""}`}>
                      {filterName}:{" "}
                      {id === "formulary"
                        ? formatFormularyFilterValue(filterValue)
                        : id === "product_category"
                          ? formatProductCategoryFilterValue(filterValue)
                          : getFilterLabel(filterValue)}
                    </span>
                    {!isDisabled && (
                      <button
                        onClick={() => removeFilter(id)}
                        aria-label={`Remove ${filterName} filter`}
                        className="shrink-0 flex items-center justify-center"
                      >
                        <img src={removeIcon} alt="Remove" className="w-10 h-5" />
                      </button>
                    )}
                  </div>
                </Tooltip>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal Overlay */}
      {isModalOpen &&
        createPortal(
          <div className="fixed inset-0 z-999999" style={{ isolation: "isolate" }}>
            {/* Backdrop */}
            <div className="fixed inset-0 bg-black/50 bg-opacity-50" onClick={() => setIsModalOpen(false)} />
            {/* Modal */}
            <div className="fixed top-0 bottom-0 right-0 z-999999">
              <div
                className="bg-white h-full w-full md:w-99.25 max-w-200 shadow-2xl overflow-y-auto"
                onClick={e => e.stopPropagation()}
              >
                {/* Modal Header */}
                <div className="sticky top-0 bg-white px-6 py-4 flex items-center justify-between z-10">
                  <div className="flex items-center gap-2">
                    <img src={filterIconPrimary} alt="Filters" className="w-5 h-5" />
                    <h2 className="text-lg font-bold text-ui-text-primary">Global Filters</h2>
                    {isDisabled && <span className="text-sm text-ui-text-secondary">(Disabled)</span>}
                  </div>

                  {/* <button
                onClick={() => setIsModalOpen(false)}
                className="text-ui-text-secondary hover:text-ui-text-primary transition-colors"
                aria-label="Close filters"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button> */}
                </div>
                <hr className="mx-4 my-2" />
                {/* Modal Content */}
                <div className="px-8 py-3">
                  <div className="grid md:grid-cols-1 gap-4">
                    {/* Custom Lists Filter - At the top */}
                    <div className="relative">
                      <div className="flex items-center justify-between">
                        <label className="text-md font-bold text-[#4A5568] block">Custom Lists</label>
                        <button
                          type="button"
                          className="text-sm font-medium text-brand-primary-main hover:text-brand-primary-dark transition-colors bg-transparent border-none cursor-pointer flex items-center gap-1"
                          onClick={() => {
                            setIsModalOpen(false);
                            setIsCreateListModalOpen(true);
                          }}
                        >
                          <span className="text-lg leading-none">+</span> Create New List
                        </button>
                      </div>
                      <button
                        ref={el => {
                          dropdownButtonRefs.current["custom_list"] = el;
                        }}
                        onClick={() => toggleDropdown("custom_list")}
                        disabled={isDisabled}
                        aria-expanded={openDropdown === "custom_list"}
                        aria-haspopup="listbox"
                        aria-label="Filter by Custom Lists"
                        className={`flex items-center justify-between w-full px-3 py-2 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-none ${isDisabled ? "opacity-50 cursor-not-allowed" : ""}`}
                      >
                        <span className="text-[#4A5568] text-sm">{getFilterValue("custom_list", "All Custom Lists")}</span>
                        <svg
                          className={`w-4 h-4 text-ui-text-muted transition-transform duration-200 ${
                            openDropdown === "custom_list" ? "rotate-180" : ""
                          }`}
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>
                      <div className="border-b border-b-[#E8E8E8]">
                        <Link
                          to="/custom-lists"
                          className="w-fit pb-2 mt-2 text-sm font-bold text-brand-primary-main cursor-pointer flex items-center"
                        >
                          View All Custom Lists
                          <svg className="w-6 h-6 -rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 9l-7 7-7-7" />
                          </svg>
                        </Link>
                      </div>

                      {openDropdown === "custom_list" && !isDisabled && (
                        <div
                          role="listbox"
                          aria-label="Custom Lists options"
                          className={`absolute left-0 w-full bg-white border border-gray-300 rounded-md shadow-lg z-50 max-h-80 flex flex-col ${
                            dropdownPosition["custom_list"] === "top" ? "bottom-full mb-0 flex-col-reverse" : "top-full mt-1"
                          }`}
                        >
                          <div
                            className={`p-2 ${dropdownPosition["custom_list"] === "top" ? "border-t border-gray-200" : "border-b border-gray-200"}`}
                          >
                            <input
                              ref={el => {
                                searchInputRefs.current["custom_list"] = el;
                              }}
                              type="search"
                              role="searchbox"
                              aria-label="Search Custom Lists"
                              placeholder="Search Custom Lists..."
                              value={getSearchValueForFilter("custom_list")}
                              onChange={e => setSearchValueForFilter("custom_list", e.target.value)}
                              onKeyDown={e => {
                                if (e.key === "Escape") {
                                  setOpenDropdown(null);
                                }
                              }}
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary-main text-sm"
                              onClick={e => e.stopPropagation()}
                            />
                          </div>
                          <div className="overflow-y-auto flex-1" onScroll={e => handleScroll(e, "custom_list")}>
                            {/* Default "All" option to clear filter */}
                            <button
                              type="button"
                              role="option"
                              aria-label="Select All Custom Lists"
                              onClick={() => clearPendingFilter("custom_list")}
                              className="block w-full px-3 py-2 text-left text-sm font-bold text-ui-text-secondary hover:bg-ui-background-muted transition-colors border-b border-gray-200"
                            >
                              All Custom Lists
                            </button>
                            {loading["custom_list"] && filterData.custom_list.length === 0 ? (
                              <div className="px-3 py-4 text-sm text-gray-500 text-center">
                                <div className="animate-spin w-5 h-5 border-2 border-gray-300 border-t-brand-primary-main rounded-full mx-auto"></div>
                              </div>
                            ) : filterData.custom_list.length === 0 ? (
                              <div className="px-3 py-2 text-sm text-gray-500">No results found</div>
                            ) : (
                              <>
                                {filterData.custom_list.map(item => {
                                  const selected = isItemSelected("custom_list", item);
                                  return (
                                    <OptionItem
                                      key={item.id}
                                      tooltipContent={getItemLabel("custom_list", item)}
                                      selected={selected}
                                      ariaLabel={`${selected ? "Deselect" : "Select"} ${item.name}`}
                                      onClick={() => toggleFilterSelection("custom_list", item)}
                                      displayName={item.name}
                                      iconSlot={
                                        <span className="shrink-0 w-7 h-7 flex items-center justify-center rounded bg-[#DDDBF7]">
                                          {item.icon && icons[item.icon as keyof typeof icons]}
                                        </span>
                                      }
                                    />
                                  );
                                })}
                                {loading["custom_list"] && (
                                  <div className="px-3 py-2 text-sm text-gray-500 text-center">
                                    <div className="animate-spin w-4 h-4 border-2 border-gray-300 border-t-brand-primary-main rounded-full mx-auto"></div>
                                  </div>
                                )}
                              </>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                    {FILTER_CATEGORIES.map(category => (
                      <div key={category.id} className="relative">
                        <label className="text-md font-bold text-[#4A5568] block">{category.label}</label>
                        <button
                          ref={el => {
                            dropdownButtonRefs.current[category.id] = el;
                          }}
                          onClick={() => toggleDropdown(category.id)}
                          disabled={isDisabled}
                          aria-expanded={openDropdown === category.id}
                          aria-haspopup="listbox"
                          aria-label={`Filter by ${category.label}`}
                          className={`flex items-center justify-between w-full px-3 py-2 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-none ${isDisabled ? "opacity-50 cursor-not-allowed" : ""}`}
                        >
                          <span className="text-[#4A5568] text-sm">{getFilterValue(category.id, category.defaultValue)}</span>
                          <svg
                            className={`w-4 h-4 text-ui-text-muted transition-transform duration-200 ${
                              openDropdown === category.id ? "rotate-180" : ""
                            }`}
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                          </svg>
                        </button>
                        {openDropdown === category.id && !isDisabled && (
                          <div
                            role="listbox"
                            aria-label={`${category.label} options`}
                            className={`absolute left-0 w-full bg-white border border-gray-300 rounded-md shadow-lg z-50 max-h-80 flex flex-col ${
                              dropdownPosition[category.id] === "top" ? "bottom-full mb-0 flex-col-reverse" : "top-full mt-1"
                            }`}
                          >
                            <div
                              className={`p-2 ${dropdownPosition[category.id] === "top" ? "border-t border-gray-200" : "border-b border-gray-200"}`}
                            >
                              <input
                                ref={el => {
                                  searchInputRefs.current[category.id] = el;
                                }}
                                type="search"
                                role="searchbox"
                                aria-label={`Search ${category.label}`}
                                placeholder={
                                  category.id === "material"
                                    ? getMaterialSearchPlaceholder()
                                    : category.id === "supplier"
                                      ? "Search by name or nbr"
                                      : category.id === "supplier_parent"
                                        ? "Search by parent name or ID"
                                        : category.id === "customer"
                                          ? "Search by name or nbr"
                                          : `Search ${category.label}...`
                                }
                                value={getSearchValueForFilter(category.id)}
                                onChange={e => setSearchValueForFilter(category.id, e.target.value)}
                                onKeyDown={e => {
                                  if (e.key === "Escape") {
                                    setOpenDropdown(null);
                                  }
                                }}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary-main text-sm"
                                onClick={e => e.stopPropagation()}
                              />
                            </div>
                            <div className="overflow-y-auto flex-1" onScroll={e => handleScroll(e, category.id)}>
                              {/* Default "All" option to clear filter */}
                              <button
                                type="button"
                                role="option"
                                aria-label={`Select ${category.defaultValue}`}
                                onClick={() => clearPendingFilter(category.id)}
                                className="block w-full px-3 py-2 text-left text-sm font-bold text-ui-text-secondary hover:bg-ui-background-muted transition-colors border-b border-gray-200"
                              >
                                {category.defaultValue}
                              </button>
                              {loading[category.id] && getDataForFilter(category.id).length === 0 ? (
                                <div className="px-3 py-2 text-sm text-gray-500 text-center">Loading...</div>
                              ) : getDataForFilter(category.id).length === 0 ? (
                                <div className="px-3 py-2 text-sm text-gray-500">No results found</div>
                              ) : (
                                <>
                                  {getDataForFilter(category.id).map(item => {
                                    const selected = isItemSelected(category.id, item);
                                    const displayName =
                                      category.id === "formulary"
                                        ? getFormularyContractTypeLabel(String(item.id ?? item.name))
                                        : category.id === "product_category"
                                          ? getProductCategoryLabel(String(item.id ?? item.name))
                                          : category.id === "material" && (item as MaterialItem).mat_nbr
                                            ? `(${(item as MaterialItem).mat_nbr}) ${item.name}`
                                            : category.id === "supplier" && (item as SupplierItem).vendor_nbr
                                              ? `(${(item as SupplierItem).vendor_nbr}) ${item.name}`
                                              : category.id === "customer" && (item as CustomerItem).cust_corp_chain_nbr
                                                ? `(${(item as CustomerItem).cust_corp_chain_nbr}) ${item.name}`
                                                : item.name;
                                    return (
                                      <OptionItem
                                        key={String(item.id ?? item.name)}
                                        tooltipContent={getItemLabel(category.id, item)}
                                        selected={selected}
                                        ariaLabel={`${selected ? "Deselect" : "Select"} ${displayName}`}
                                        onClick={() => toggleFilterSelection(category.id, item)}
                                        displayName={displayName}
                                      />
                                    );
                                  })}
                                  {loading[category.id] && (
                                    <div className="px-3 py-2 text-sm text-gray-500 text-center">Loading more...</div>
                                  )}
                                </>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                    {/* Boolean Filters (Injectable, WHO Essential) */}
                    {BOOLEAN_FILTER_CATEGORIES.map(bf => {
                      const pending = pendingFilters[bf.id];
                      const currentValue = pending && !isMultiFilter(pending) ? pending.id : null;
                      const displayText = currentValue === "1" ? "Yes" : currentValue === "0" ? "No" : bf.defaultValue;

                      return (
                        <div key={bf.id} className="relative">
                          <label className="text-md font-bold text-[#4A5568] block">{bf.label}</label>
                          <button
                            ref={el => {
                              dropdownButtonRefs.current[bf.id] = el;
                            }}
                            onClick={() => toggleDropdown(bf.id)}
                            disabled={isDisabled}
                            aria-expanded={openDropdown === bf.id}
                            aria-haspopup="listbox"
                            aria-label={`Filter by ${bf.label}`}
                            className={`flex items-center justify-between w-full px-3 py-2 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-none ${isDisabled ? "opacity-50 cursor-not-allowed" : ""}`}
                          >
                            <span className="text-[#4A5568] text-sm">{displayText}</span>
                            <svg
                              className={`w-4 h-4 text-ui-text-muted transition-transform duration-200 ${openDropdown === bf.id ? "rotate-180" : ""}`}
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                            </svg>
                          </button>
                          {openDropdown === bf.id && !isDisabled && (
                            <div
                              role="listbox"
                              aria-label={`${bf.label} options`}
                              className={`absolute left-0 w-full bg-white border border-gray-300 rounded-md shadow-lg z-50 flex flex-col ${
                                dropdownPosition[bf.id] === "top" ? "bottom-full mb-0" : "top-full mt-1"
                              }`}
                            >
                              {[
                                { value: null, label: bf.defaultValue },
                                { value: "1", label: "Yes" },
                                { value: "0", label: "No" },
                              ].map(option => {
                                const selected = currentValue === option.value;
                                return (
                                  <Tooltip key={option.label} content={option.label} position="top" className="block w-full">
                                    <button
                                      role="option"
                                      aria-selected={selected}
                                      aria-label={`${selected ? "Deselect" : "Select"} ${option.label}`}
                                      onClick={() => {
                                        if (option.value === null) {
                                          setPendingFilters(prev => {
                                            const updated = { ...prev };
                                            delete updated[bf.id];
                                            return updated;
                                          });
                                        } else {
                                          setPendingFilters(prev => ({
                                            ...prev,
                                            [bf.id]: { id: option.value, label: option.label },
                                          }));
                                        }
                                        setOpenDropdown(null);
                                      }}
                                      className={`flex items-center gap-2 w-full px-3 py-2 text-left text-sm hover:bg-ui-background-muted transition-colors ${
                                        selected
                                          ? "font-bold text-ui-text-primary bg-ui-background-muted"
                                          : "text-ui-text-secondary"
                                      }`}
                                    >
                                      {option.label}
                                    </button>
                                  </Tooltip>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex flex-row w-full justify-between pt-4 border-t border-[#E2E8F0] gap-3">
                    <button
                      onClick={() => setPendingFilters({})}
                      disabled={isDisabled || Object.keys(pendingFilters).length === 0}
                      className={`px-4 py-2 hover:bg-purple-50 text-brand-primary-main border-2 border-brand-primary-main font-bold text-sm rounded-md w-full ${isDisabled || Object.keys(pendingFilters).length === 0 ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                    >
                      Clear all Filters
                    </button>
                    <button
                      onClick={applyFilters}
                      disabled={isDisabled}
                      className={`px-4 py-2 bg-[#461E96] text-white border-2 border-brand-primary-main font-bold text-sm rounded-md w-full ${isDisabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                    >
                      Apply Filters
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>,
          document.body
        )}
      {openDropdown && <div className="fixed inset-0 z-40" onClick={() => setOpenDropdown(null)} />}
      {isCreateListModalOpen && (
        <CreateNewListModal isOpen={isCreateListModalOpen} onClose={() => setIsCreateListModalOpen(false)} />
      )}
    </>
  );
}
