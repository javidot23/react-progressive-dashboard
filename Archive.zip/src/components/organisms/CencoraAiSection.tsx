import {Card} from "@/components/atoms/Card";

export function CencoraAISection() {
  return (
    <Card className="bg-brand-primary-surface p-6 rounded-md h-64">
      <div className="text-center text-white/80 text-sm">
        Operations recommendations will appear here when available.
      </div>
    </Card>
  );
}
