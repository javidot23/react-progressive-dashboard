import React from "react";
import { StatCard } from "@/components/molecules/StatCard";
import { StatCardSkeleton } from "@/components/molecules/StatCardSkeleton";
import {
  useOtifDataQuery,
  useTwoWeekSummaryQuery,
  useWeeklyOtifLineCountsQuery,
  useAggregateRiskKpiQuery,
} from "@/hooks/queries/useMainKpiQueries";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/atoms/Button";
import type { StatCardData } from "@/lib/types";
import AlertTrianglePrimaryBrandPrimary from "@/assets/icons/alert-triangle-primary-brand-primary.svg";
import DeliveryTruckPrimaryBrandPrimary from "@/assets/icons/delivery-truck-primary-brand-primary.svg";
import DiscountDollarDashBrandPrimary from "@/assets/icons/discount-dollar-dash-brand-primary.svg";
import MonitorGraphBrandPrimary from "@/assets/icons/monitor-graph-brand-primary.svg";

interface MainKPIsProps {
  className?: string;
}

type ChangeType = "increase" | "decrease" | "neutral";

interface CardState {
  title: string;
  loading: boolean;
  error: string | null;
  data: StatCardData | null;
  retry: () => void;
}

interface TrendData {
  kpi?: string;
  unit?: string;
  points: Array<{ period_start: string; period_end: string; value: number; metrics?: Record<string, number> }>;
}

const TOOLTIP_POSITIONS = ["top", "top", "top", "top"] as const;

const getTooltipText = (cardTitle: string) => {
  switch (cardTitle) {
    case "Inbound On-Time In-Full":
      return "Displays the last rolling 30 days On-Time In-Full (OTIF) percentage compared to the previous 30 days.";
    case "Open Issues":
      return "Displays today's snapshot of opened issues from total issues. This shows the current count of open issues out of the total issues for today.";
    case "Value at Risk":
      return "Displays the estimated total dollar value at risk, with an indicator showing the dollar change since last week.";
    case "Current Risk Score":
      return "Displays the aggregate risk score for materials out of 100 with an indicator showing the recent percentage change";
    default:
      return "This tooltip content is for demonstration purposes only.";
  }
};

const calculatePercentageChange = (current: number, previous: number): number => {
  if (previous === 0) return current > 0 ? 100 : 0;
  return ((current - previous) / previous) * 100;
};

const formatChange = (
  difference: number,
  suffix: string = "since last week",
  includePercent: boolean = false
): { text: string; type: ChangeType } => {
  const rounded = Math.round(difference);
  const percentSymbol = includePercent ? "%" : "";

  if (rounded > 0) {
    return { text: `+${rounded}${percentSymbol} ${suffix}`, type: "increase" };
  }

  if (rounded < 0) {
    return { text: `${rounded}${percentSymbol} ${suffix}`, type: "decrease" };
  }

  return {
    text: suffix.includes("last") || suffix.includes("previous") ? `No change ${suffix}` : suffix,
    type: "neutral",
  };
};

const transformOtifData = (
  otifData: {
    last30DaysOtif?: number;
    previous30DaysOtif?: number;
    thisWeekOtif?: number;
    lastWeekOtif?: number;
    kpiValue?: number;
    kpiPreviousValue?: number;
    trend?: TrendData;
  } | null,
  weeklyOtifLineCounts?: Array<{ otif_percentage: number; year: number; week: number }>
): StatCardData | null => {
  if (!otifData) return null;

  const currentOtif = otifData.kpiValue ?? otifData.last30DaysOtif ?? otifData.thisWeekOtif;
  const previousOtif = otifData.kpiPreviousValue ?? otifData.previous30DaysOtif ?? otifData.lastWeekOtif;

  if (currentOtif === undefined || previousOtif === undefined) return null;

  const value = `${Math.round(currentOtif * 100)}%`;
  const percentageDiff = calculatePercentageChange(currentOtif, previousOtif);
  const change = formatChange(percentageDiff, "from previous 30 days", true);

  // Generate chart data from weekly OTIF line counts (last 7 weeks) as fallback
  let chartData: number[] | undefined;
  let chartXLabels: string[] | undefined;

  if (!otifData.trend && weeklyOtifLineCounts && weeklyOtifLineCounts.length > 0) {
    const sortedData = [...weeklyOtifLineCounts]
      .sort((a, b) => {
        if (a.year !== b.year) return a.year - b.year;
        return a.week - b.week;
      })
      .slice(-7);

    chartData = sortedData.map(item => item.otif_percentage);
    chartXLabels = sortedData.map(item => `W${item.week}`);
    if (chartData.length < 7) {
      while (chartData.length < 7) {
        chartData.unshift(currentOtif);
        chartXLabels?.unshift('');
      }
    }
  } else if (!otifData.trend) {
    chartData = [previousOtif, currentOtif];
    chartXLabels = ['Prev', 'Now'];
  }

  return {
    title: "Inbound On-Time In-Full",
    value,
    change: change.text,
    changeType: change.type,
    customIconPath: DeliveryTruckPrimaryBrandPrimary,
    iconBgColor: "custom-error",
    trend: otifData.trend,
    chartData,
    chartXLabels,
    chartColor: "#461E96",
    chartValueFormatter: (value: number | null) => value ? `${Math.round(value * 100)}%` : "0%",
    tooltip: getTooltipText("Inbound On-Time In-Full"),
  };
};

const transformIssuesData = (
  todaySnapshot: {
    open_issues?: number;
    total_issues?: number;
    snapshot_date?: string;
    current_total_issues?: number;
    current_opened_issues?: number;
    previous_total_issues?: number;
    previous_opened_issues?: number;
    kpiValue?: number;
    kpiTotal?: number;
    trend?: TrendData;
  } | null
): StatCardData | null => {
  if (!todaySnapshot) return null;

  const openIssues = todaySnapshot.kpiValue ?? todaySnapshot.open_issues ?? todaySnapshot.current_opened_issues;
  const totalIssues = todaySnapshot.kpiTotal ?? todaySnapshot.total_issues ?? todaySnapshot.current_total_issues;

  if (openIssues === undefined || totalIssues === undefined) return null;

  const value = `${openIssues.toLocaleString("en-US")}/${totalIssues.toLocaleString("en-US")}`;

  // Generate chart data from previous and current opened issues as fallback
  let chartData: number[] | undefined;
  let chartXLabels: string[] | undefined;

  if (!todaySnapshot.trend) {
    const previousOpened = todaySnapshot.previous_opened_issues ?? openIssues;
    chartData = [previousOpened, openIssues];
    chartXLabels = ['Prev', 'Now'];
  }

  const issuesValueFormatter = (v: number | null) => (v != null ? v.toLocaleString("en-US") : "0");

  return {
    title: "Open Issues",
    value,
    change: `Opened issues from total issues`,
    changeType: "neutral",
    customIconPath: AlertTrianglePrimaryBrandPrimary,
    iconBgColor: "custom-error",
    trend: todaySnapshot.trend,
    chartData,
    chartXLabels,
    chartColor: "#461E96",
    chartValueFormatter: issuesValueFormatter,
    sparklineValueFormatter: issuesValueFormatter,
    tooltip: getTooltipText("Open Issues"),
  };
};

const transformValueAtRiskData = (valueAtRiskTrend: {
  kpiValue: number;
  kpiPreviousValue: number;
  trend: TrendData;
} | null): StatCardData | null => {
  if (!valueAtRiskTrend) return null;

  const thisWeek = valueAtRiskTrend.kpiValue || 0;
  const lastWeek = valueAtRiskTrend.kpiPreviousValue || 0;

  const valueInMillions = thisWeek / 1_000_000;
  const formattedValue = `$${valueInMillions.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}M`;

  const difference = thisWeek - lastWeek;
  let changeText: string;
  let changeType: ChangeType;

  if (difference === 0) {
    changeText = "No change from last week";
    changeType = "neutral";
  } else {
    const absDifference = Math.abs(difference);
    let formattedDiff: string;

    if (absDifference >= 1_000_000) {
      formattedDiff = `$${(absDifference / 1_000_000).toFixed(2)}M`;
    } else if (absDifference >= 1_000) {
      formattedDiff = `$${(absDifference / 1_000).toFixed(2)}K`;
    } else {
      formattedDiff = `$${absDifference.toFixed(0)}`;
    }

    changeText = difference > 0
      ? `${formattedDiff} more than last week`
      : `${formattedDiff} less than last week`;
    changeType = difference > 0 ? "increase" : "decrease";
  }

  // Generate simple trend chart data as fallback
  let chartData: number[] | undefined;
  let chartXLabels: string[] | undefined;

  if (!valueAtRiskTrend.trend) {
    chartData = [lastWeek / 1_000_000, thisWeek / 1_000_000];
    chartXLabels = ['Last', 'Now'];
  }

  return {
    title: "Value at Risk",
    value: formattedValue,
    change: changeText,
    changeType,
    customIconPath: DiscountDollarDashBrandPrimary,
    iconBgColor: "custom-error",
    trend: valueAtRiskTrend.trend,
    chartData,
    chartXLabels,
    chartColor: "#461E96",
    chartValueFormatter: (value: number | null) => value ? `$${value.toFixed(2)}M` : "$0M",
    tooltip: getTooltipText("Value at Risk"),
  };
};

const transformRiskScoreData = (weeklyRiskAnalysis: {
  averageRiskScoreThisWeek: number;
  averageRiskScoreLastWeek: number;
  kpiValue?: number;
  kpiPreviousValue?: number;
  trend?: TrendData;
} | null): StatCardData | null => {
  if (!weeklyRiskAnalysis) return null;

  const thisWeek = (weeklyRiskAnalysis.kpiValue ?? weeklyRiskAnalysis.averageRiskScoreThisWeek) || 0;
  const lastWeek = (weeklyRiskAnalysis.kpiPreviousValue ?? weeklyRiskAnalysis.averageRiskScoreLastWeek) || 0;

  // API averages are in 0–1 scale; normalize to 0–100 for display
  const riskPercent = Math.round(thisWeek * 100);
  const value = `${riskPercent}/100`;

  const percentageDiff = calculatePercentageChange(thisWeek, lastWeek);
  const change = formatChange(percentageDiff, "since last week", true);

  // Generate simple trend chart data as fallback
  let chartData: number[] | undefined;
  let chartXLabels: string[] | undefined;

  if (!weeklyRiskAnalysis.trend) {
    chartData = [lastWeek, thisWeek];
    chartXLabels = ['Last', 'Now'];
  }

  return {
    title: "Current Risk Score",
    value,
    change: change.text,
    changeType: change.type,
    customIconPath: MonitorGraphBrandPrimary,
    iconBgColor: "custom-error",
    trend: weeklyRiskAnalysis.trend,
    chartData,
    chartXLabels,
    chartColor: "#461E96",
    chartValueFormatter: (value: number | null) => value ? `${Math.round(value * 100)}` : "0",
    tooltip: getTooltipText("Current Risk Score"),
  };
};

const useKPIData = () => {
  const { otifData, isLoading: otifLoading, error: otifError, refetch: refetchOtif } = useOtifDataQuery();
  const {
    twoWeekSummary,
    isLoading: twoWeekLoading,
    error: twoWeekError,
    refetch: refetchTwoWeek,
  } = useTwoWeekSummaryQuery();
  const { weeklyOtifLineCounts } = useWeeklyOtifLineCountsQuery();
  const {
    weeklyRiskAnalysis,
    valueAtRiskTrend,
    isLoading: riskLoading,
    error: riskError,
    refetch: refetchRisk,
  } = useAggregateRiskKpiQuery();

  const cards: CardState[] = [
    {
      title: "Open Issues",
      loading: twoWeekLoading,
      error: twoWeekError,
      data: transformIssuesData(twoWeekSummary),
      retry: () => void refetchTwoWeek(),
    },
    {
      title: "Inbound On-Time In-Full",
      loading: otifLoading,
      error: otifError,
      data: transformOtifData(otifData, weeklyOtifLineCounts),
      retry: () => void refetchOtif(),
    },
    {
      title: "Value at Risk",
      loading: riskLoading,
      error: riskError,
      data: transformValueAtRiskData(valueAtRiskTrend),
      retry: () => void refetchRisk(),
    },
    {
      title: "Current Risk Score",
      loading: riskLoading,
      error: riskError,
      data: transformRiskScoreData(weeklyRiskAnalysis),
      retry: () => void refetchRisk(),
    },
  ];

  return cards;
};

interface ErrorCardProps extends React.PropsWithChildren {
  title: string;
  onRetry: () => void;
}

const ErrorCard: React.FC<ErrorCardProps> = ({ title, onRetry, children = "Failed to load data" }) => (
  <div className="bg-status-error-light border border-status-error-main rounded-lg p-4">
    <div className="flex items-start space-x-2">
      <AlertTriangle className="w-5 h-5 text-status-error-main shrink-0 mt-0.5" />
      <div>
        <h4 className="text-sm font-semibold text-status-error-dark">{title}</h4>
        <p className="text-xs text-status-error-text mt-1">{children}</p>
        <Button onClick={onRetry} variant="outline" size="sm" className="mt-2 text-xs">
          Retry
        </Button>
      </div>
    </div>
  </div>
);

export const MainKPIs: React.FC<MainKPIsProps> = ({ className = "" }) => {
  const cards = useKPIData();

  return (
    <div className={className}>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {cards.map((card, index) => (
          <div key={card.title} className="w-full" style={{ minHeight: '165px' }}>
            {card.loading ? (
              <StatCardSkeleton />
            ) : card.error ? (
              <ErrorCard title={card.title} onRetry={card.retry} />
            ) : !card.data ? (
              <StatCardSkeleton />
            ) : (
              <StatCard data={card.data} tooltipPosition={TOOLTIP_POSITIONS[index]} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default MainKPIs;
