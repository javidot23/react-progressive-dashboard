import React, {useState} from "react";

interface ModifyGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: ModifyGoalData) => void;
  initialData?: ModifyGoalData;
  triggerRef?: React.RefObject<HTMLElement | null>;
}

export interface ModifyGoalData {
  serviceLevelTarget: number | null;
  riskScoreThreshold: string;
  alertFrequency: "daily" | "weekly";
}

export function ModifyGoalModal({
  onClose,
  onSave,
  initialData = {
    serviceLevelTarget: 100,
    riskScoreThreshold: "100%",
    alertFrequency: "daily",
  },
}: ModifyGoalModalProps) {
  const [serviceLevelTargetValue, setServiceLevelTargetValue] = useState<string>(
    initialData?.serviceLevelTarget == null ? "" : String(initialData.serviceLevelTarget)
  );

  const handleSave = () => {
    const parsed = serviceLevelTargetValue === ""
      ? null
      : Math.max(0, Math.min(100, parseInt(serviceLevelTargetValue, 10) || 0));
    onSave({
      serviceLevelTarget: parsed,
      riskScoreThreshold: initialData.riskScoreThreshold,
      alertFrequency: initialData.alertFrequency,
    });
    onClose();
  };

  return (
    <>
      <div
        className="fixed inset-0 z-100 "
        onClick={onClose}
        style={{backgroundColor: "transparent"}}
      />

      <div
        className="bg-white rounded-md shadow-2xl border border-gray-300 overflow-hidden mt-2
                   max-sm:fixed max-sm:inset-x-4 max-sm:top-1/2 max-sm:-translate-y-1/2 max-sm:mt-0
                   sm:absolute sm:right-0 sm:top-full"
        style={{
          width: "calc(100vw - 32px)",
          maxWidth: "522px",
          minHeight: "230px",
          zIndex: 101,
        }}
      >
        <div className="flex items-center justify-between px-4 sm:px-6 py-3 sm:py-4">
          <h2 className="text-sm sm:text-base font-lg text-[#1E1E1E] font-brand font-semibold">
            Modify Goal
          </h2>
          <button onClick={onClose} className="">
            <svg
              className="h-5 w-5 text-gray-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="#6E6E6E"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>
        <hr />

        <div className="px-4 sm:px-6 py-3 sm:py-4 flex flex-col flex-1">
          <div className="mb-4">
            <label className="block text-xs font-medium text-[#1E1E1E] mb-2 sm:mb-3">
              Service Level Target
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                max="100"
                step="1"
                value={serviceLevelTargetValue}
                onChange={e => {
                  const raw = e.target.value.replace(/[^0-9]/g, '');
                  if (raw === '') { setServiceLevelTargetValue(''); return; }
                  let n = parseInt(raw, 10);
                  if (Number.isNaN(n)) { n = 0; }
                  n = Math.max(0, Math.min(100, n));
                  setServiceLevelTargetValue(String(n));
                }}
                className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 pr-8 text-sm focus:ring-2 focus:ring-brand-700 focus:border-brand-700"
                placeholder="Enter service level target (0-100)"
              />
              <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">
                %
              </span>
            </div>
          </div>
        </div>

        <div className="flex justify-end items-center h-12 sm:h-14 bg-background-secondary px-4 sm:px-6 rounded-b-lg">
          <button
            onClick={handleSave}
            className="bg-interactive-primary hover:bg-interactive-primary-hover text-white px-4 sm:px-6 py-2 text-sm font-semibold rounded-md transition-colors focus:outline-hidden focus:ring-2 focus:ring-interactive-primary focus:ring-offset-2 shadow-xs"
            style={{
              minWidth: "80px",
              height: "36px",
              fontSize: "14px",
              fontWeight: "500",
            }}
          >
            Modify
          </button>
        </div>
      </div>
    </>
  );
}
