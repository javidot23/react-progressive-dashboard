"use client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/atoms/Card";
import InfoIcon from "@/components/atoms/InfoIcon";
import {
  Line,
  XAxis,
  YAxis,
  ResponsiveContainer,
  CartesianGrid,
  Tooltip,
  Area,
  ComposedChart,
  type DotProps,
} from "recharts";
import { useState, useRef, useEffect, useMemo } from "react";
import { GraphCardSkeleton, EmptyState } from "@/components/molecules";
import Legend, { LegendItem } from "@/components/atoms/Legend";
import { issuesService } from "@/lib/apiServices";
import { formatCurrencyCompact } from "@/lib/utils";
import { computeIsIncompleteWeekFromApiWeekStart, INCOMPLETE_WEEK_BAR_OPACITY } from "@/lib/incompleteWeek";
import { formatApiDate } from "@/lib/dateUtils";
import { rechartsNullDot } from "@/lib/rechartsNullDot";

type LineDotCallbackProps = DotProps & { index?: number };

const CARD_MIN_HEIGHT = "480px";
const MIN_CHART_HEIGHT = "320px";
const CHART_MARGIN = { top: 20, right: 20, left: 12, bottom: 20 };
const LINE_STROKE_WIDTH = 3;
const VALUE_MITIGATED_COLOR = "#593AB1"; // Purple
const VALUE_AT_RISK_COLOR = "#0391D7"; // Blue

const CARD_TITLE = "Value at Risk Trend";
const CARD_DESCRIPTION_BASE = "Track weekly value at risk from newly opened issues versus value mitigated through actions taken over the last 90 days.";
const INFO_TOOLTIP =
  "Displays the weekly trend of value at risk and value mitigated over a 90-day period. Value at Risk represents the dollar amount at risk from issues that opened in each week, calculated using the material's dollars at risk value. Value Mitigated represents the dollar amount addressed through actions taken in each week.";

const LEGEND_ITEMS: LegendItem[] = [
  { id: "value-mitigated", color: VALUE_MITIGATED_COLOR, label: "Value Mitigated", shape: "square" },
  { id: "value-at-risk", color: VALUE_AT_RISK_COLOR, label: "Value at Risk", shape: "square" },
];

// Transform API data to chart format (weekly data)
const transformApiDataToChartFormat = (apiData: Array<{
  week: number;
  date: string;
  value_at_risk: number;
  value_mitigated: number;
}>) => {
  return apiData.map(item => ({
    date: item.date,
    week: item.week,
    valueMitigated: item.value_mitigated || 0,
    valueAtRisk: item.value_at_risk || 0,
    valueMitigatedDollars: item.value_mitigated || 0,
    valueAtRiskDollars: item.value_at_risk || 0,
    isIncompleteWeek: computeIsIncompleteWeekFromApiWeekStart(item.date),
  }));
};

interface TooltipPayload {
  payload: {
    valueMitigated?: number;
    valueAtRisk?: number;
    valueMitigatedDollars?: number;
    valueAtRiskDollars?: number;
    isIncompleteWeek?: boolean;
  };
}

type ValueAtRiskChartRow = {
  date: string;
  week: number;
  valueMitigated: number;
  valueAtRisk: number;
  valueMitigatedDollars: number;
  valueAtRiskDollars: number;
  isIncompleteWeek?: boolean;
};

interface ValueAtRiskTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
  chartData: ValueAtRiskChartRow[];
}

const ValueAtRiskTooltip = ({ active, payload, label, chartData }: ValueAtRiskTooltipProps) => {
  if (active && payload && payload.length) {
    const activeData = chartData.find(item => item.date === label);
    const valueMitigatedDollars = activeData?.valueMitigatedDollars || 0;
    const valueAtRiskDollars = activeData?.valueAtRiskDollars || 0;

    const formattedDate = (label ? formatApiDate(label, { month: "short", day: "numeric", year: "numeric" }) : "") || label || "";

    const incompleteWeek = Boolean(activeData?.isIncompleteWeek);

    return (
      <div className="bg-white border border-gray-200 text-gray-900 text-xs rounded-md shadow-lg w-[240px] p-3 font-normal z-30">
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Date:</span>
            <span className="text-gray-900 font-medium">{formattedDate}</span>
          </div>
          {incompleteWeek && (
            <p className="text-xs font-medium text-ui-text-secondary border-b border-gray-100 pb-2">
              Incomplete week
            </p>
          )}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Value Mitigated:</span>
              <span className="text-gray-900 font-medium">{formatCurrencyCompact(valueMitigatedDollars)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Value at Risk:</span>
              <span className="text-gray-900 font-medium">{formatCurrencyCompact(valueAtRiskDollars)}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

const isValidDotCoord = (cx: unknown, cy: unknown): cx is number =>
  typeof cx === "number" && typeof cy === "number" && Number.isFinite(cx) && Number.isFinite(cy);

// Custom dot component with white center
const CustomDot = (props: DotProps & { fill?: string; payload?: { isIncompleteWeek?: boolean } }) => {
  const { cx, cy, fill, payload } = props;
  if (!isValidDotCoord(cx, cy)) return rechartsNullDot(cx, cy);
  const opacity = payload?.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1;
  return (
    <g opacity={opacity}>
      <circle cx={cx} cy={cy} r={5} fill={fill} />
      <circle cx={cx} cy={cy} r={2} fill="white" />
    </g>
  );
};

// Custom active dot component with white center
const CustomActiveDot = (props: DotProps & { fill?: string; payload?: { isIncompleteWeek?: boolean } }) => {
  const { cx, cy, fill, payload } = props;
  if (!isValidDotCoord(cx, cy)) return rechartsNullDot(cx, cy);
  const opacity = payload?.isIncompleteWeek ? INCOMPLETE_WEEK_BAR_OPACITY : 1;
  return (
    <g opacity={opacity}>
      <circle cx={cx} cy={cy} r={7} fill={fill} />
      <circle cx={cx} cy={cy} r={3} fill="white" />
    </g>
  );
};

/** Dots on the dimmed tail segment (stroke already uses INCOMPLETE_WEEK_BAR_OPACITY). */
const CustomDotDimTail = (props: DotProps & { fill?: string }) => {
  const { cx, cy, fill } = props;
  if (!isValidDotCoord(cx, cy)) return rechartsNullDot(cx, cy);
  return (
    <g>
      <circle cx={cx} cy={cy} r={5} fill={fill} />
      <circle cx={cx} cy={cy} r={2} fill="white" />
    </g>
  );
};

const CustomActiveDotDimTail = (props: DotProps & { fill?: string }) => {
  const { cx, cy, fill } = props;
  if (!isValidDotCoord(cx, cy)) return rechartsNullDot(cx, cy);
  return (
    <g>
      <circle cx={cx} cy={cy} r={7} fill={fill} />
      <circle cx={cx} cy={cy} r={3} fill="white" />
    </g>
  );
};

const ValueAtRiskCardHeader = () => (
  <CardHeader className="shrink-0">
    <div className="flex items-center gap-2">
      <CardTitle
        className="text-xl font-bold leading-[28.8px] text-heading font-brand"
        style={{
          fontSize: "20px",
          fontWeight: "700",
          lineHeight: "28.8px",
        }}
      >
        {CARD_TITLE}
      </CardTitle>
      <InfoIcon tooltip={INFO_TOOLTIP} />
    </div>

    <p className="text-sm text-ui-text-secondary">
      {CARD_DESCRIPTION_BASE}
    </p>
    <Legend items={LEGEND_ITEMS} orientation="horizontal" spacing="md" />
  </CardHeader>
);


export function ValueAtRiskTrendCard() {
  const [chartData, setChartData] = useState<ValueAtRiskChartRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasEverFetched, setHasEverFetched] = useState(false);
  const isFetchingRef = useRef(false);

  const hasData = chartData.length > 0;

  /** Split last segment when the final week is incomplete so stroke matches OTIF-style dimming. */
  const chartDataForStroke = useMemo(() => {
    const n = chartData.length;
    if (n === 0) return [];
    const lastIncomplete = Boolean(chartData[n - 1]?.isIncompleteWeek);
    const splitTail = n >= 2 && lastIncomplete;
    return chartData.map((d, i) => {
      if (splitTail) {
        return {
          ...d,
          valueMitigatedSolid: i === n - 1 ? null : d.valueMitigated,
          valueMitigatedDim: i >= n - 2 ? d.valueMitigated : null,
          valueAtRiskSolid: i === n - 1 ? null : d.valueAtRisk,
          valueAtRiskDim: i >= n - 2 ? d.valueAtRisk : null,
        };
      }
      if (n === 1 && lastIncomplete) {
        return {
          ...d,
          valueMitigatedSolid: null,
          valueMitigatedDim: d.valueMitigated,
          valueAtRiskSolid: null,
          valueAtRiskDim: d.valueAtRisk,
        };
      }
      return {
        ...d,
        valueMitigatedSolid: d.valueMitigated,
        valueMitigatedDim: null,
        valueAtRiskSolid: d.valueAtRisk,
        valueAtRiskDim: null,
      };
    });
  }, [chartData]);

  // Fetch value at risk trend data
  useEffect(() => {
    // Prevent duplicate fetches (e.g., from React StrictMode or concurrent renders)
    if (isFetchingRef.current || hasEverFetched) {
      return;
    }

    let isMounted = true;

    const fetchData = async () => {
      isFetchingRef.current = true;
      try {
        setLoading(true);
        setError(null);
        const response = await issuesService.getValueAtRiskTrend();

        // Only update state if component is still mounted
        if (isMounted) {
          if (response.data.success && response.data.data) {
            const transformedData = transformApiDataToChartFormat(response.data.data);
            setChartData(transformedData);
            setHasEverFetched(true);
          } else {
            throw new Error('Invalid response format');
          }
        }
      } catch (err) {
        // Only update state if component is still mounted
        if (isMounted) {
          setError(err instanceof Error ? err.message : 'Failed to fetch value at risk trend data');
          setHasEverFetched(true);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
        isFetchingRef.current = false;
      }
    };

    fetchData();

    // Cleanup function to prevent state updates after unmount
    return () => {
      isMounted = false;
      isFetchingRef.current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Show skeleton only when loading AND no data, OR when never fetched
  if ((loading && !hasData) || (!hasEverFetched && !error)) {
    return (
      <div className="relative h-full">
        <GraphCardSkeleton height={CARD_MIN_HEIGHT} />
      </div>
    );
  }

  if (hasEverFetched && !loading && !error && !hasData) {
    return (
      <div className="relative h-full">
        <Card className="flex flex-col h-full" style={{ height: CARD_MIN_HEIGHT, boxSizing: 'border-box' }}>
          <ValueAtRiskCardHeader />
          <CardContent className="flex-1 flex items-center justify-center min-h-0">
            <EmptyState
              title="No Data Available"
              description="No value at risk data found for the selected filters. Try adjusting your filter criteria to see results."
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="relative h-full">
      <Card className="flex flex-col h-full" style={{ height: CARD_MIN_HEIGHT, boxSizing: 'border-box' }}>
        <ValueAtRiskCardHeader />
        <CardContent className="flex-1 flex flex-col px-4 pt-4 pb-0 min-h-0">
          <div
            className="w-full overflow-x-auto overflow-y-visible relative shrink-0"
            style={{ height: MIN_CHART_HEIGHT }}
          >
            {error && !loading && (
              <div className="absolute inset-0 flex items-center justify-center text-status-error-main z-10">
                <div className="text-center">
                  <p className="text-sm font-medium">Failed to load data</p>
                  <p className="text-xs text-ui-text-muted mt-1">{error}</p>
                </div>
              </div>
            )}
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartDataForStroke} margin={CHART_MARGIN}>
                <defs>
                  <linearGradient id="valueMitigatedGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#593AB1" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#593AB1" stopOpacity={0.05} />
                  </linearGradient>
                  <linearGradient id="valueAtRiskGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0391D7" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#0391D7" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-ui-border-primary)" vertical={false} />

                <XAxis
                  dataKey="date"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                  tickFormatter={(value) => formatApiDate(value) || value}
                />

                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--color-ui-text-muted)", fontSize: 12 }}
                  domain={[0, "auto"]}
                  tickFormatter={(v: number) => formatCurrencyCompact(v)}
                  label={{
                    value: "Amount",
                    angle: -90,
                    position: "insideLeft",
                    style: {
                      textAnchor: "middle",
                      fill: "var(--color-ui-text-muted)",
                      fontSize: "12px",
                    },
                  }}
                />

                <Tooltip
                  content={<ValueAtRiskTooltip chartData={chartData} />}
                  cursor={{ fill: "rgba(59, 41, 112, 0.1)" }}
                  allowEscapeViewBox={{ x: false, y: false }}
                  offset={10}
                />

                <Area
                  type="monotone"
                  dataKey="valueMitigated"
                  stroke="none"
                  fill="url(#valueMitigatedGradient)"
                  fillOpacity={1}
                  strokeWidth={0}
                />
                <Area
                  type="monotone"
                  dataKey="valueAtRisk"
                  stroke="none"
                  fill="url(#valueAtRiskGradient)"
                  fillOpacity={1}
                  strokeWidth={0}
                />

                <Line
                  type="monotone"
                  dataKey="valueMitigatedSolid"
                  stroke={VALUE_MITIGATED_COLOR}
                  strokeWidth={LINE_STROKE_WIDTH}
                  connectNulls={false}
                  dot={<CustomDot fill={VALUE_MITIGATED_COLOR} />}
                  activeDot={<CustomActiveDot fill={VALUE_MITIGATED_COLOR} />}
                />
                <Line
                  type="monotone"
                  dataKey="valueMitigatedDim"
                  stroke={VALUE_MITIGATED_COLOR}
                  strokeWidth={LINE_STROKE_WIDTH}
                  strokeOpacity={INCOMPLETE_WEEK_BAR_OPACITY}
                  connectNulls={false}
                  dot={(props: LineDotCallbackProps) => {
                    const n = chartDataForStroke.length;
                    if (props.index !== n - 1) return rechartsNullDot(props.cx, props.cy);
                    return <CustomDotDimTail {...props} fill={VALUE_MITIGATED_COLOR} />;
                  }}
                  activeDot={(props: LineDotCallbackProps) => {
                    const n = chartDataForStroke.length;
                    if (props.index !== n - 1) return rechartsNullDot(props.cx, props.cy);
                    return <CustomActiveDotDimTail {...props} fill={VALUE_MITIGATED_COLOR} />;
                  }}
                />

                <Line
                  type="monotone"
                  dataKey="valueAtRiskSolid"
                  stroke={VALUE_AT_RISK_COLOR}
                  strokeWidth={LINE_STROKE_WIDTH}
                  connectNulls={false}
                  dot={<CustomDot fill={VALUE_AT_RISK_COLOR} />}
                  activeDot={<CustomActiveDot fill={VALUE_AT_RISK_COLOR} />}
                />
                <Line
                  type="monotone"
                  dataKey="valueAtRiskDim"
                  stroke={VALUE_AT_RISK_COLOR}
                  strokeWidth={LINE_STROKE_WIDTH}
                  strokeOpacity={INCOMPLETE_WEEK_BAR_OPACITY}
                  connectNulls={false}
                  dot={(props: LineDotCallbackProps) => {
                    const n = chartDataForStroke.length;
                    if (props.index !== n - 1) return rechartsNullDot(props.cx, props.cy);
                    return <CustomDotDimTail {...props} fill={VALUE_AT_RISK_COLOR} />;
                  }}
                  activeDot={(props: LineDotCallbackProps) => {
                    const n = chartDataForStroke.length;
                    if (props.index !== n - 1) return rechartsNullDot(props.cx, props.cy);
                    return <CustomActiveDotDimTail {...props} fill={VALUE_AT_RISK_COLOR} />;
                  }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
