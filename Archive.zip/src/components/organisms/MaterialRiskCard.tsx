import { Badge } from "@/components/atoms/Badge";
import { MaterialRiskDriverModal } from "@/components/molecules/MaterialRiskDriverModal";
import { MaterialWithIssues } from "@/lib/types";
import ActionButtonGroup from "@/components/molecules/ActionButtonGroup";
import { getRiskBadge } from "@/lib/vendorUtils";
import React, { useState } from "react";
import { useRiskModelDescriptions } from "@/hooks";
import { formatCurrencyCompact, getMaterialStatusDescription } from "@/lib/utils";
import lightbulbIcon from "@/assets/icons/lightbulb.svg";
import { isFullFeatureSet } from "@/tenant";

interface MaterialRiskCardProps {
  material: MaterialWithIssues;
  isComparisonMode?: boolean;
  vendorId?: number;
}

const MaterialRiskCard: React.FC<MaterialRiskCardProps> = ({ material, isComparisonMode = false, vendorId }) => {
  const [showMaterialRiskDriverModal, setShowMaterialRiskDriverModal] = useState<boolean>(false);
  const { getEnrichedMetadata } = useRiskModelDescriptions();
  const drivingRiskLabel = getEnrichedMetadata(material.driving_risk).display_name || material.driving_risk || "Operational";

  const xplantMatStatDesc = getMaterialStatusDescription(material.xplant_mat_stat);
  const vendorName = material.vendor?.name;
  const vendorNbr = material.vendor?.vendor_nbr;
  const createdAtDisplay =
    material.open_issues.length > 0
      ? new Date(material.open_issues[0].created_at).toLocaleDateString("en-US", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        })
      : new Date(material.created_at).toLocaleDateString("en-US", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        });
  const isNewIssue =
    material.open_issues.length > 0 &&
    (() => {
      const createdAt = new Date(material.open_issues[0].created_at);
      const today = new Date();
      return (
        createdAt.getDate() === today.getDate() &&
        createdAt.getMonth() === today.getMonth() &&
        createdAt.getFullYear() === today.getFullYear()
      );
    })();

  return (
    <div className="border border-ui-border-primary rounded-md my-3 p-4">
      {/* Header aligned with IssueCard (React open issues / supply management) */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 gap-2">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between w-full gap-2">
          <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 gap-1 sm:gap-0">
            <h3 className="font-semibold text-lg text-ui-text-primary">
              {material.name || `Material ${material.id}`}
            </h3>
            <div className="flex items-center flex-wrap gap-x-2 text-sm text-ui-text-secondary">
              <span>Material Id : {material.mat_nbr}</span>
              <span className="hidden sm:inline">•</span>
              <span className="sm:hidden">•</span>
              <span>Material Status : {xplantMatStatDesc || "-"}</span>
              <span className="sm:hidden">•</span>
              <span className="hidden sm:inline">•</span>
              <span>Vendor : {vendorName || "-"}</span>
              <span className="hidden sm:inline">•</span>
              <span>Vendor Id : {vendorNbr || "-"}</span>
              <span className="hidden sm:inline">•</span>
              <span className="sm:hidden">•</span>
              <span>NDC : {material.ndc || material.ean_n4_nbr_11 || "-"}</span>
              <span className="hidden sm:inline">•</span>
              <span className="sm:hidden">•</span>
              <span>Date : {createdAtDisplay}</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {isNewIssue && (
              <Badge className="bg-status-info-light text-status-info-dark border-status-info-main text-sm font-semibold px-3 py-1 text-nowrap">
                New Issue
              </Badge>
            )}
          </div>
        </div>
      </div>
      <div
        className={`grid gap-3 ${isComparisonMode ? "grid-cols-1" : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6"}`}
      >
        {(() => {
          const showExactScore = isFullFeatureSet();
          const riskRating = (material.risk_score || 93.7) / 100;
          const riskBadge = getRiskBadge(riskRating);

          return (
            <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-2 px-2 h-[79px] flex flex-col">
              <div className="flex justify-between items-center space-x-2 mb-1">
                <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">Risk Score</div>
                <div
                  className={`flex items-center ${riskBadge.bgColor} ${riskBadge.textColor} border ${riskBadge.borderColor} px-1 py-0.5 rounded text-2xs font-semibold text-nowrap`}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-3 h-3 sm:w-4 sm:h-4"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
                    />
                  </svg>
                  {riskBadge.text}
                </div>
              </div>
              {showExactScore && (
                <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px] mt-1">
                  {(material.risk_score || 93.7).toFixed(2)} / 100
                </div>
              )}
              <div className="mt-auto">
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: showExactScore ? `${material.risk_score || 93.7}%` : '100%',
                      backgroundColor: riskBadge.hexColor,
                    }}
                  />
                </div>
              </div>
            </div>
          );
        })()}

        <div
          onClick={() => setShowMaterialRiskDriverModal(true)}
          className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 h-[79px] cursor-pointer"
        >
          <div className="w-full text-left" title="View Risk Driver Details">
            <div className="flex items-center justify-between">
              <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">Driving Risk</div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="#6E6E6E"
                className="w-4 h-4 sm:w-5 sm:h-5 text-brand-primary-main hover:text-brand-primary-dark transition-colors"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
              </svg>
            </div>
            <div className={`font-bold text-neutral-900 leading-tight ${drivingRiskLabel.length > 30 ? "text-sm" : "mt-1"}`}>
              {drivingRiskLabel}
            </div>
          </div>
        </div>
        <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 h-[79px]">
          <div className="flex flex-col items-left">
            <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">Risk Adjusted Value</div>
          </div>
          <div className="font-bold text-neutral-900 text-sm sm:text-lg mt-1">
            {material.risk_score && material.dollars_at_risk
              ? `${formatCurrencyCompact(
                Math.round((material.risk_score / 100) * material.dollars_at_risk)
              )} / ${formatCurrencyCompact(material.dollars_at_risk, true)}`
              : "- / -"}
          </div>
        </div>

        {/* Action Status Card - matches IssueCard design */}
        {(() => {
          const hasActions =
            material.open_issues?.some(
              issue => issue.actions && issue.actions.length > 0
            ) || false;
          const status = hasActions ? "reviewed" : "not_reviewed";
          const actionStatusText = status === "reviewed" ? "Reviewed" : "Not Reviewed";

          return (
            <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 h-[79px]">
              <div className="flex flex-col items-left">
                <div className="text-xs sm:text-sm text-[#6E6E6E] font-normal text-nowrap">
                  Action Status
                </div>
              </div>
              <div className="flex items-center gap-2 mt-1">
                {status === "reviewed" ? (
                  <div className="inline-flex items-center justify-center p-1 rounded-full border border-[#06C07A] bg-[#D8FEE7]">
                    <div className="w-2 h-2 rounded-full bg-[#119D63]" />
                  </div>
                ) : (
                  <div className="inline-flex items-center justify-center p-1 rounded-full border border-[#E22F008A] bg-[#FEEFEB]">
                    <div className="w-2 h-2 rounded-full bg-[#E22F00]" />
                  </div>
                )}
                <div className="font-bold text-neutral-900 text-sm sm:text-[17.44px]">
                  {actionStatusText}
                </div>
              </div>
            </div>
          );
        })()}
      </div>

      {/* Recommended Actions Section - matches IssueCard design */}
      {!isComparisonMode && material.open_issues && material.open_issues.length > 0 && (
        <>
          <div className="flex items-center gap-2 my-3">
            <img
              src={lightbulbIcon}
              alt="Lightbulb Icon"
              className="w-4 h-4"
            />
            <p className="text-[#525252] text-sm whitespace-nowrap">
              Recommended Actions
            </p>
            <hr className="flex-1 border-t border-[#E0E0E0]" />
          </div>
        </>
      )}
      <hr className="my-3" />
      {!isComparisonMode && material.open_issues && material.open_issues.length > 0 && (
        <ActionButtonGroup
          material={material}
          size="md"
          issueId={material.open_issues[0]?.id}
          potentialActions={material.open_issues[0]?.potential_actions || []}
          issueNbr={material.open_issues[0]?.issue_nbr}
          vendorId={vendorId}
        />
      )}
      {showMaterialRiskDriverModal && <MaterialRiskDriverModal
        isOpen={showMaterialRiskDriverModal}
        onClose={() => setShowMaterialRiskDriverModal(false)}
        materialName={material.name || `Material ${material.id}`}
        vendorName={material.vendor?.name}
        overallRiskScore={material.risk_score || 93.7}
        dollarsAtRisk={material.dollars_at_risk || 0}
        materialId={material.id}
        materialNbr={material.mat_nbr}
        riskLevel={material.risk_score}
        drivingRisk={material.driving_risk}
        ndc={material.ndc || material.ean_n4_nbr_11}
      />}
    </div>
  );
};

export default MaterialRiskCard;
