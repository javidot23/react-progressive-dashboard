import { MaterialRiskData, materialRiskService } from "@/lib/apiServices";
import React, { useEffect, useRef, useState } from "react";
import { ModalShell } from "@/components/atoms/ModalShell";
import { RiskBadge } from "@/components/atoms/RiskBadge";
import { useRiskModelDescriptions } from "@/hooks";
import { formatCurrencyCompact } from "@/lib/utils";
import DocumentIcon from "@/assets/icons/accounting-document.svg";
import AlertTriangleIcon from "@/assets/icons/alert-triangle-primary.svg";
import DollarIcon from "@/assets/icons/discount-dollar-dash-primary.svg";
import MessagesIcon from "@/assets/icons/messages-bubble-square-star.svg";
import UsersIcon from "@/assets/icons/multiple-users-primary.svg";
import PinIcon from "@/assets/icons/pin-primary.svg";
import CartIcon from "@/assets/icons/shopping-cart-empty.svg";
import WarehouseIcon from "@/assets/icons/warehouse-packages.svg";

interface RiskDriverModalProps {
  isOpen: boolean;
  onClose: () => void;
  productName: string;
  overallRiskScore: number;
  dollarsAtRisk: number;
  materialId?: number;
  riskLevel?: number;
  ndc?: string;
  materialIdString?: string;
  supplierName?: string;
  drivingRisk?: string;
}

interface RiskCategoryData {
  title: string;
  icon: string;
  score: number;
  subtitle?: string;
}

interface ContributingRiskDriver {
  title: string;
  level: "Low" | "Medium" | "High";
  score: number;
  metrics: string[];
}

export const RiskDriverModal: React.FC<RiskDriverModalProps> = ({
  isOpen,
  onClose,
  productName,
  overallRiskScore,
  dollarsAtRisk,
  materialId,
  riskLevel,
  ndc,
  materialIdString,
  supplierName,
  drivingRisk,
}) => {
  const { mapRiskTypeToModelType, getEnrichedMetadata } = useRiskModelDescriptions();
  const [riskData, setRiskData] = useState<MaterialRiskData[]>([]);
  const [error, setError] = useState<string | null>(null);
  const isFetching = useRef(false);

  const fetchRiskData = async (materialId: number) => {
    if (isFetching.current) return;

    isFetching.current = true;
    setError(null);

    try {
      const response = await materialRiskService.getMaterialRisk(materialId);
      const responseData = response.data;

      if (responseData.success && Array.isArray(responseData.data)) {
        const mapped = responseData.data.map((item: any) => ({
          ...item,
          risk_type: mapRiskTypeToModelType(item.risk_type),
        }));
        setRiskData(mapped);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to fetch risk data";
      console.error("Error fetching risk data:", err);
      setError(errorMessage);
    } finally {
      isFetching.current = false;
    }
  };

  useEffect(() => {
    if (isOpen && materialId && !isFetching.current) {
      fetchRiskData(materialId);
    }
  }, [isOpen, materialId]);

  if (!isOpen) return null;

  const getRiskCategories = (): RiskCategoryData[] => {
    const baseCategories = [
      {
        type: "base_model_operational",
        title: "Operational Risk",
        icon: AlertTriangleIcon,
        subtitle: supplierName ? `${supplierName}` : "N/A",
      },
      {
        type: "financial",
        title: "Financial Risk",
        icon: DollarIcon,
      },
      {
        type: "base_model_market",
        title: "Market Risk",
        icon: CartIcon,
      },
      {
        type: "patient",
        title: "Patient Risk",
        icon: UsersIcon,
      },
      {
        type: "base_model_sales",
        title: "Sales Risk",
        icon: WarehouseIcon,
      },
      {
        type: "base_model_regulatory",
        title: "Regulatory Risk",
        icon: DocumentIcon,
      },
      {
        type: "base_model_location",
        title: "Location Risk",
        icon: PinIcon,
      },
      {
        type: "reputational",
        title: "Reputational Risk",
        icon: MessagesIcon,
      },
    ];

    return baseCategories.map(category => {
      const apiData = riskData.find(risk => risk.risk_type === category.type);
      return {
        title: category.title,
        icon: category.icon,
        score: apiData ? Math.round(apiData.risk_rating * 100) : 0,
        subtitle: category.subtitle,
      };
    });
  };

  const riskCategories = getRiskCategories();

  // Get primary risk category (highest score)
  const primaryRiskCategory = riskCategories.reduce(
    (max, category) => (category.score > max.score ? category : max),
    riskCategories[0] || { title: "Operational", score: 0 }
  );

  // Get primary risk driver label
  const primaryRiskDriverLabel = drivingRisk
    ? getEnrichedMetadata(drivingRisk).display_name || drivingRisk
    : "Cascading Product Shortage";

  // Mock contributing risk drivers (in real app, this would come from API)
  const contributingRiskDrivers: ContributingRiskDriver[] = [
    {
      title: "Forecast Variance",
      level: "Medium",
      score: 64,
      metrics: ["Variance from Forecast +34%", "Affected DCs 8 locations", "Timeframe Last 30 days"],
    },
    {
      title: "Distribution Disruption",
      level: "Medium",
      score: 58,
      metrics: ["Processing Delays +2.3 days avg", "Late Deliveries 18% of orders", "Affected DCs 5 locations"],
    },
    {
      title: "Supplier Performance",
      level: "Low",
      score: 42,
      metrics: ["OTIF Performance 89%", "vs Target (95%) -6%", "Open Issues 2 active"],
    },
  ];

  const getRiskColor = (score: number): string => {
    const normalizedScore = score / 100;

    if (normalizedScore >= 0.0 && normalizedScore <= 0.2) {
      return "var(--Cencora-success-500-dark, #059669)";
    } else if (normalizedScore >= 0.21 && normalizedScore <= 0.4) {
      return "var(--Cencora-success-500-dark, #059669)";
    } else if (normalizedScore >= 0.41 && normalizedScore <= 0.6) {
      return "var(--Cencora-warning-600-dark, #D97706)";
    } else if (normalizedScore >= 0.61 && normalizedScore <= 0.8) {
      return "var(--Cencora-warning-600-dark, #D97706)";
    } else if (normalizedScore >= 0.81 && normalizedScore <= 1.0) {
      return "var(--Cencora-danger-500-core, #DC2626)";
    }

    return "var(--Cencora-success-500-dark, #059669)";
  };

  const getLevelColor = (level: "Low" | "Medium" | "High"): string => {
    switch (level) {
      case "Low":
        return "bg-green-100 text-green-700 border-green-700";
      case "Medium":
        return "bg-yellow-100 text-yellow-700 border-yellow-700";
      case "High":
        return "bg-red-100 text-red-700 border-red-700";
      default:
        return "bg-gray-100 text-gray-700 border-gray-700";
    }
  };

  const primaryRiskScore = Math.round(primaryRiskCategory.score * 0.87); // Approximate 87/100 from image
  const riskAdjustedValue = Math.round((overallRiskScore / 100) * dollarsAtRisk);

  return (
    <ModalShell
      isOpen={isOpen}
      onClose={onClose}
      ariaLabelledBy="risk-driver-modal-title"
      usePortal
      zIndex={9999}
      overlayClassName="fixed inset-0 flex items-center justify-center p-4"
      className="relative overflow-y-auto max-h-[95vh] w-[95vw] max-w-211 md:w-211 mx-4 md:mx-0 rounded-lg bg-white shadow-xl"
      lockScroll={false}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-6 pt-6 pb-3">
        <div className="flex-1">
          <h2
            id="risk-driver-modal-title"
            className="font-bold mb-2"
            style={{
              color: "var(--cds-color-brand-700)",
              fontFamily: "var(--cds-text-font-family-brand)",
              fontSize: "24px",
              fontWeight: "700",
              lineHeight: "32px",
            }}
          >
            {productName}
          </h2>
          <div
            className="text-sm"
            style={{
              color: "var(--cds-color-text-secondary, #525252)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "14px",
              fontWeight: "400",
              lineHeight: "20px",
            }}
          >
            {ndc && `NDC: ${ndc}`}
            {ndc && materialIdString && " • "}
            {materialIdString && `Material ID: ${materialIdString}`}
            {(ndc || materialIdString) && supplierName && " • "}
            {supplierName && `Supplier: ${supplierName}`}
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="font-bold hover:opacity-70 transition-opacity ml-4"
          aria-label="Close risk drivers dialog"
          style={{
            color: "var(--cds-color-text-secondary)",
            fontFamily: "var(--cds-text-font-family-brand)",
            fontSize: "24px",
            lineHeight: "1",
          }}
        >
          ×
        </button>
      </div>

      <div className="px-6 pb-6">
        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
            <p className="text-sm text-red-600">Error loading risk data: {error}</p>
          </div>
        )}

        {/* Risk Summary Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {/* Risk Score Card */}
          <div
            className="flex flex-col p-4"
            style={{
              borderRadius: "8px",
              border: "1px solid var(--color-neutral-200, #E0E0E0)",
              background: "var(--cds-color-background-secondary, #F5F5F5)",
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <div
                className="text-sm font-medium"
                style={{
                  color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "500",
                }}
              >
                Risk Score
              </div>
              {riskLevel !== undefined && <RiskBadge riskRating={riskLevel / 100} size="xs" />}
            </div>
            <div
              className="font-bold mb-2"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "28px",
                fontWeight: "700",
                lineHeight: "36px",
              }}
            >
              {overallRiskScore.toFixed(2)}%
            </div>
            <div className="w-full">
              <div className="bg-gray-200 rounded-full overflow-hidden" style={{ height: "8px" }}>
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${overallRiskScore}%`,
                    backgroundColor: getRiskColor(overallRiskScore),
                  }}
                />
              </div>
            </div>
          </div>

          {/* Risk-Adjusted Value Card */}
          <div
            className="flex flex-col p-4"
            style={{
              borderRadius: "8px",
              border: "1px solid var(--color-neutral-200, #E0E0E0)",
              background: "var(--cds-color-background-secondary, #F5F5F5)",
            }}
          >
            <div
              className="text-sm font-medium mb-2"
              style={{
                color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "500",
              }}
            >
              Risk-Adjusted Value
            </div>
            <div
              className="font-bold"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "28px",
                fontWeight: "700",
                lineHeight: "36px",
              }}
            >
              {formatCurrencyCompact(riskAdjustedValue)}
            </div>
          </div>

          {/* Driving Risk Category Card */}
          <div
            className="flex flex-col p-4"
            style={{
              borderRadius: "8px",
              border: "1px solid var(--color-neutral-200, #E0E0E0)",
              background: "var(--cds-color-background-secondary, #F5F5F5)",
            }}
          >
            <div
              className="text-sm font-medium mb-2"
              style={{
                color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "500",
              }}
            >
              Driving Risk Category
            </div>
            <div
              className="font-bold mb-1"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "28px",
                fontWeight: "700",
                lineHeight: "36px",
              }}
            >
              {primaryRiskCategory.title.replace(" Risk", "")}
            </div>
            <div
              className="text-sm"
              style={{
                color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "400",
              }}
            >
              Cascading Shortage
            </div>
          </div>
        </div>

        {/* Driving Risk Driver Section */}
        <div className="mb-6 p-4 border rounded-lg" style={{ borderColor: "var(--cds-color-border-primary, #E0E0E0)" }}>
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <div className="mb-2">
                <span
                  className="inline-block px-2 py-1 rounded text-xs font-semibold border"
                  style={{
                    backgroundColor: "#FEE2E2",
                    color: "#DC2626",
                    borderColor: "#DC2626",
                  }}
                >
                  Driving Risk Driver
                </span>
              </div>
              <h3
                className="font-bold mb-2"
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "20px",
                  fontWeight: "700",
                  lineHeight: "28px",
                }}
              >
                {primaryRiskDriverLabel}
              </h3>
              <p
                className="mb-4"
                style={{
                  color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "14px",
                  fontWeight: "400",
                  lineHeight: "20px",
                }}
              >
                A single shortage at the primary manufacturing facility is cascading through the supply chain, affecting multiple
                downstream products and creating a ripple effect across 14 distribution centers.
              </p>
              <div className="flex flex-wrap gap-4">
                <div>
                  <span style={{ color: "var(--Cencora-neutral-expanded-500, #6E6E6E)" }}>Affects </span>
                  <strong style={{ color: "var(--cencora-neutral-900-dark, #1E1E1E)" }}>23 products</strong>
                </div>
                <div>
                  <span style={{ color: "var(--Cencora-neutral-expanded-500, #6E6E6E)" }}>Financial impact: </span>
                  <strong style={{ color: "var(--cencora-neutral-900-dark, #1E1E1E)" }}>{formatCurrencyCompact(1800000)}</strong>
                </div>
                <div>
                  <span style={{ color: "var(--Cencora-neutral-expanded-500, #6E6E6E)" }}>Status: </span>
                  <strong style={{ color: "var(--cencora-neutral-900-dark, #1E1E1E)" }}>Immediate action required</strong>
                </div>
              </div>
            </div>
            <div className="ml-4 text-right">
              <div
                className="text-xs mb-1"
                style={{
                  color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "12px",
                  fontWeight: "400",
                }}
              >
                Score
              </div>
              <div
                className="font-bold"
                style={{
                  color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                  fontFamily: "Cencora-Gilroy",
                  fontSize: "32px",
                  fontWeight: "700",
                  lineHeight: "40px",
                }}
              >
                {primaryRiskScore} /100
              </div>
            </div>
          </div>
        </div>

        {/* Contributing Risk Drivers Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3
              className="font-semibold"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "18px",
                fontWeight: "600",
                lineHeight: "24px",
              }}
            >
              Contributing Risk Drivers
            </h3>
            <span
              className="text-sm"
              style={{
                color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "400",
              }}
            >
              3 additional factors
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {contributingRiskDrivers.map((driver, index) => (
              <div
                key={index}
                className="p-4 border rounded-lg"
                style={{
                  borderColor: "var(--cds-color-border-primary, #E0E0E0)",
                  backgroundColor: "#FFFFFF",
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4
                    className="font-semibold"
                    style={{
                      color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "16px",
                      fontWeight: "600",
                      lineHeight: "24px",
                    }}
                  >
                    {driver.title}
                  </h4>
                  <span className={`px-2 py-1 rounded text-xs font-semibold border ${getLevelColor(driver.level)}`}>
                    {driver.level}
                  </span>
                </div>
                <div
                  className="font-bold mb-3"
                  style={{
                    color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                    fontFamily: "Cencora-Gilroy",
                    fontSize: "24px",
                    fontWeight: "700",
                    lineHeight: "32px",
                  }}
                >
                  {driver.score} /100
                </div>
                <div className="space-y-1">
                  {driver.metrics.map((metric, idx) => (
                    <div
                      key={idx}
                      className="text-sm"
                      style={{
                        color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                        fontFamily: "Cencora-Gilroy",
                        fontSize: "12px",
                        fontWeight: "400",
                        lineHeight: "16px",
                      }}
                    >
                      {metric}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Risk Category Breakdown Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3
              className="font-semibold"
              style={{
                color: "var(--cencora-neutral-900-dark, #1E1E1E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "18px",
                fontWeight: "600",
                lineHeight: "24px",
              }}
            >
              Risk Category Breakdown
            </h3>
            <span
              className="text-sm"
              style={{
                color: "var(--Cencora-neutral-expanded-500, #6E6E6E)",
                fontFamily: "Cencora-Gilroy",
                fontSize: "14px",
                fontWeight: "400",
              }}
            >
              8 categories
            </span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {riskCategories.map((category, index) => (
              <div
                key={index}
                className="flex flex-col p-3 border rounded-lg"
                style={{
                  borderColor: "var(--cds-color-border-primary, #E0E0E0)",
                  backgroundColor: "#FFFFFF",
                }}
              >
                <div className="flex items-center space-x-1 mb-1">
                  <img
                    src={category.icon}
                    alt={`${category.title} icon`}
                    style={{
                      width: "16px",
                      height: "16px",
                      flexShrink: 0,
                    }}
                  />
                  <h4
                    className="font-semibold"
                    style={{
                      color: "var(--cencora-brand-700-core, #461E96)",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "12px",
                      fontWeight: "600",
                      lineHeight: "16px",
                    }}
                  >
                    {category.title}
                  </h4>
                </div>
                {category.subtitle && (
                  <p
                    className="mb-1 text-xs"
                    style={{
                      color: "var(--cds-color-text-secondary, #525252)",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "10px",
                      fontWeight: "400",
                      lineHeight: "12px",
                    }}
                  >
                    {category.subtitle}
                  </p>
                )}
                <div className="flex items-baseline mb-2">
                  <span
                    className="font-bold"
                    style={{
                      color: "var(--cencora-brand-700-core, #461E96)",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "16px",
                      fontWeight: "700",
                      lineHeight: "20px",
                    }}
                  >
                    {category.score}
                  </span>
                  <span
                    className="ml-1 text-xs"
                    style={{
                      color: "var(--cds-color-text-secondary, #525252)",
                      fontFamily: "Cencora-Gilroy",
                      fontSize: "10px",
                      fontWeight: "400",
                      lineHeight: "12px",
                    }}
                  >
                    /100
                  </span>
                </div>
                <div
                  className="w-full rounded-full overflow-hidden"
                  style={{
                    backgroundColor: "var(--cds-color-border-primary, #E0E0E0)",
                    height: "6px",
                    borderRadius: "3px",
                  }}
                >
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${category.score}%`,
                      backgroundColor: getRiskColor(category.score),
                      borderRadius: "3px",
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Issue Impact Chain Section */}
        <div>
          <h3
            className="font-semibold mb-4"
            style={{
              color: "var(--cencora-neutral-900-dark, #1E1E1E)",
              fontFamily: "Cencora-Gilroy",
              fontSize: "18px",
              fontWeight: "600",
              lineHeight: "24px",
            }}
          >
            Issue Impact Chain
          </h3>
          <div className="flex flex-wrap items-center gap-2">
            {/* ROOT CAUSE */}
            <div
              className="px-4 py-3 rounded-lg"
              style={{
                backgroundColor: "#461E96",
                color: "#FFFFFF",
                fontFamily: "Cencora-Gilroy",
                fontSize: "12px",
                fontWeight: "600",
                minWidth: "140px",
              }}
            >
              <div className="text-xs mb-1 opacity-80">ROOT CAUSE</div>
              <div>Manufacturing Delay</div>
            </div>
            <div className="text-2xl text-gray-400">→</div>

            {/* PRIMARY IMPACT */}
            <div
              className="px-4 py-3 rounded-lg border"
              style={{
                backgroundColor: "#F5F5F5",
                borderColor: "#E0E0E0",
                color: "#1E1E1E",
                fontFamily: "Cencora-Gilroy",
                fontSize: "12px",
                fontWeight: "600",
                minWidth: "140px",
              }}
            >
              <div className="text-xs mb-1 opacity-70">PRIMARY IMPACT</div>
              <div>Raw Material Shortage</div>
            </div>
            <div className="text-2xl text-gray-400">→</div>

            {/* SECONDARY IMPACT */}
            <div
              className="px-4 py-3 rounded-lg border"
              style={{
                backgroundColor: "#F5F5F5",
                borderColor: "#E0E0E0",
                color: "#1E1E1E",
                fontFamily: "Cencora-Gilroy",
                fontSize: "12px",
                fontWeight: "600",
                minWidth: "140px",
              }}
            >
              <div className="text-xs mb-1 opacity-70">SECONDARY IMPACT</div>
              <div>Production Issue</div>
            </div>
            <div className="text-2xl text-gray-400">→</div>

            {/* DOWNSTREAM EFFECT */}
            <div
              className="px-4 py-3 rounded-lg border"
              style={{
                backgroundColor: "#F5F5F5",
                borderColor: "#E0E0E0",
                color: "#1E1E1E",
                fontFamily: "Cencora-Gilroy",
                fontSize: "12px",
                fontWeight: "600",
                minWidth: "140px",
              }}
            >
              <div className="text-xs mb-1 opacity-70">DOWNSTREAM EFFECT</div>
              <div>23 Materials Affected</div>
            </div>
          </div>
        </div>
      </div>
    </ModalShell>
  );
};
