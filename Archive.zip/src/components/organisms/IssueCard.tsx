import React, { memo } from "react";
import { useNavigate } from "react-router-dom";
import { navigateToMaterialDrillThrough } from "@/lib/materialDrillThroughUtils";
import { navigateToIssueDrillThrough } from "@/lib/issueDrillThroughUtils";
import { Badge } from "@/components/atoms/Badge";
import { getRiskBadge } from "@/lib/vendorUtils";
import { IssueNotesCard } from "@/components/molecules/IssueNotesCard";
import { DrivingEventStrip } from "@/components/molecules/DrivingEventStrip";
import { isFullFeatureSet } from "@/tenant";
import type { GranularityIssueView } from "@/types/granularityIssue";

interface IssueCardProps {
  issue: GranularityIssueView;
  vendorId?: number;
}

const HIGH_RISK = 80;
const MID_RISK = 40;

/** Left rail color by risk score (0–100). */
function riskRailColor(riskLevel: number): string {
  if (riskLevel > HIGH_RISK) return "#dc2626";
  if (riskLevel > MID_RISK) return "#FFA400";
  return "#16a34a";
}

const TagGlyph = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-3.5 h-3.5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.568 3H5.25A2.25 2.25 0 0 0 3 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 0 0 5.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 0 0 9.568 3Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 6h.008v.008H6V6Z" />
  </svg>
);

export const IssueCard: React.FC<IssueCardProps> = memo(({ issue }) => {
  const navigate = useNavigate();

  const isSingleMaterial = issue.isSingleMaterial ?? true;
  const impactedCount = issue.impactedMaterialCount ?? 1;
  const riskLevel = issue.riskLevel;
  const riskBadge = getRiskBadge(riskLevel / 100);
  const showExactScore = isFullFeatureSet();
  const railColor = riskRailColor(riskLevel);
  const hasActions = issue.hasActions;

  // Material grain shows the material name; other grains read by their granularity (chip + title).
  const title = isSingleMaterial
    ? issue.productName
    : `${issue.granularityLabel ?? "Issue"} ${issue.granularityValue ?? ""}`.trim();

  const openDrillThrough = () => {
    if (isSingleMaterial) {
      navigateToMaterialDrillThrough(navigate, issue);
    } else {
      navigateToIssueDrillThrough(navigate, issue);
    }
  };

  const isInteractiveTarget = (target: EventTarget | null) => {
    if (!(target instanceof HTMLElement)) return false;
    return Boolean(
      target.closest('button, a, input, textarea, select, [role="dialog"], [data-prevent-drill-through="true"]')
    );
  };

  const handleCardActivate = (e: React.MouseEvent | React.KeyboardEvent) => {
    if (isInteractiveTarget(e.target)) return;
    if ("key" in e && e.key !== "Enter" && e.key !== " ") return;
    if ("key" in e) e.preventDefault();
    openDrillThrough();
  };

  const ctaLabel = isSingleMaterial ? "View material and take action" : `View ${impactedCount} materials and take action`;

  return (
    <div
      className="relative w-full min-w-0 border border-ui-border-primary rounded-lg my-3 p-4 pl-5 cursor-pointer hover:border-brand-primary-main transition-colors"
      onClick={handleCardActivate}
      onKeyDown={handleCardActivate}
      role="link"
      tabIndex={0}
      title="View issue drill-through"
    >
      {/* Risk rail */}
      <span
        aria-hidden
        className="absolute left-0 top-0 h-full w-[5px] rounded-l-lg"
        style={{ backgroundColor: railColor }}
      />

      {/* Header */}
      <div className="flex flex-col gap-1 min-w-0 mb-3">
        <div className="flex items-center flex-wrap gap-2">
          <span className="inline-flex items-center gap-1.5 rounded bg-brand-primary-100 text-brand-primary-main border border-brand-primary-200 px-2 py-0.5 text-2xs font-semibold">
            <TagGlyph />
            <span>{issue.granularityLabel ?? "Issue"}</span>
            {issue.granularityValue ? <span className="font-mono">{issue.granularityValue}</span> : null}
          </span>
          {issue.group ? <span className="text-xs text-ui-text-secondary">· Group: {issue.group}</span> : null}
          {issue.isNewIssue ? (
            <Badge className="text-xs font-semibold px-2 py-0.1 text-nowrap border border-[#E22F0054] bg-[#FCD9D1] text-[#E22F00]">
              New Issue
            </Badge>
          ) : null}
        </div>
        <h3 className="font-bold text-lg text-ui-text-primary truncate">{title}</h3>
        {/* Identity subtitle — material grain only */}
        {isSingleMaterial ? (
          <div className="flex items-center flex-wrap gap-x-2 gap-y-1.5 text-sm text-ui-text-secondary">
            <span>Material Id : {issue.mat_nbr || "-"}</span>
            <span>•</span>
            <span>Material Status : {issue.xplantMatStatDesc || "-"}</span>
            <span>•</span>
            <span>Vendor : {issue.vendorName || "-"}</span>
            <span>•</span>
            <span>Vendor Id : {issue.vendorNbr || "-"}</span>
            <span>•</span>
            <span>NDC : {issue.ndc || "-"}</span>
          </div>
        ) : null}
      </div>

      <DrivingEventStrip
        className="mb-3"
        event={issue.drivingEvent}
        drivingRisk={issue.drivingRisk}
      />

      {/* Metric row — identical across all granularities */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-[repeat(auto-fit,minmax(12.5rem,1fr))] *:min-w-0 mb-3">
        {/* Materials Impacted */}
        <Metric label="Materials Impacted" value={String(impactedCount)} />

        {/* Risk Score (reused original card visual) */}
        <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 flex flex-col">
          <div className="flex justify-between items-center space-x-2 mb-1">
            <div className="text-sm text-[#6E6E6E] font-normal text-nowrap">Risk Score</div>
            <div
              className={`flex items-center ${riskBadge.bgColor} ${riskBadge.textColor} border-1 ${riskBadge.borderColor} px-1 py-0.5 rounded text-2xs font-semibold text-nowrap`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="w-4 h-4"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
                />
              </svg>
              {riskBadge.text}
            </div>
          </div>
          {showExactScore && <div className="font-bold text-neutral-900 text-[17.44px] mt-1">{riskLevel} / 100</div>}
          <div className="mt-auto">
            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full"
                style={{ width: showExactScore ? `${riskLevel}%` : "100%", backgroundColor: riskBadge.hexColor }}
              />
            </div>
          </div>
        </div>

        {/* Risk Adjusted Value / Value at Risk */}
        <Metric label="Risk Adjusted Value / Value at Risk" value={issue.riskExposure} />

        {/* Action Status */}
        <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 flex flex-col">
          <div className="text-sm text-[#6E6E6E] font-normal text-nowrap">Action Status</div>
          <div className="flex items-center gap-2 mt-1">
            {hasActions ? (
              <div className="inline-flex items-center justify-center p-1 rounded-full border border-[#06C07A] bg-[#D8FEE7]">
                <div className="w-2 h-2 rounded-full bg-[#119D63]" />
              </div>
            ) : (
              <div className="inline-flex items-center justify-center p-1 rounded-full border border-[#E22F008A] bg-[#FEEFEB]">
                <div className="w-2 h-2 rounded-full bg-[#E22F00]" />
              </div>
            )}
            <div className="font-bold text-neutral-900 text-[17.44px]">
              {hasActions ? "Reviewed" : "Not Reviewed"}
            </div>
          </div>
        </div>

        {/* Notes */}
        <div
          className="h-full"
          data-prevent-drill-through="true"
          onClick={e => e.stopPropagation()}
          onKeyDown={e => e.stopPropagation()}
        >
          <IssueNotesCard
            view="card"
            issueBackendId={String(issue.id)}
            matNbr={issue.mat_nbr}
            ndc={issue.ndc}
            hasActions={hasActions}
            lastNote={issue.lastNote}
            notesCount={issue.notesCount}
          />
        </div>
      </div>

      {/* Footer CTA */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#F0F0F0]">
        <span className="text-xs text-ui-text-secondary">
          Identified {issue.createdAt}
          {issue.persona ? ` · ${issue.persona}` : ""}
        </span>
        <div data-prevent-drill-through="true" onClick={e => e.stopPropagation()}>
          <button
            type="button"
            onClick={openDrillThrough}
            className="inline-flex items-center gap-1 text-brand-primary-main text-sm font-bold cursor-pointer"
          >
            {ctaLabel}
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
});

IssueCard.displayName = "IssueCard";

interface MetricProps {
  label: string;
  value: string;
}

const Metric: React.FC<MetricProps> = ({ label, value }) => (
  <div className="bg-[#F5F5F5] border-1 border-[#CACACA] rounded-md py-3 px-2 flex flex-col">
    <div className="text-sm text-[#6E6E6E] font-normal">{label}</div>
    <div className="font-bold text-neutral-900 text-[17.44px] mt-1 break-words">{value}</div>
  </div>
);
