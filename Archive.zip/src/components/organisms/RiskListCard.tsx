"use client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/atoms/Card";
import { ChevronRight, Package } from "lucide-react";
import type { RiskListItem } from "@/lib/types";
import { cn, getRiskRatingColors } from "@/lib/utils";
import { Link } from "react-router-dom";
import { EmptyState } from "@/components/molecules";
import { useMemo, useState } from "react";
import { RiskBadge } from "@/components/atoms/RiskBadge";
import { MaterialRiskDriverModal } from "@/components/molecules/MaterialRiskDriverModal";

const TITLE_STYLES = {
  fontSize: "20px",
  fontWeight: "700",
  lineHeight: "28.8px",
};

const ROUTE_MAP: Record<string, string> = {
  "High-Risk Suppliers": "/plan",
  "High-Risk Materials": "/react",
  "Top At-Risk Suppliers": "/plan",
  "Top At-Risk Materials": "/react",
};

type RiskListCardProps = {
  title: string;
  description: string;
  items: RiskListItem[];
  loading: boolean;
  error: string | null;
  lastFetched?: number | null;
  totalCount?: number;
};

interface RiskItemProps {
  item: RiskListItem;
  title?: string;
  onMetadataClick?: () => void;
}

const RiskItem = ({ item, title, onMetadataClick }: RiskItemProps) => {
  const riskRating = item.riskRating !== undefined ? item.riskRating : 0.5;
  const riskColors = getRiskRatingColors(riskRating);
  const dotColor = riskColors.verticalLineClass;

  // High-Risk Supplier Card: Supplier Name as main, Supplier ID and NDC as metadata
  // High-Risk Material Card: Material Name as main, Material ID, Brand, NDC, Material Status as metadata
  let mainName = item.name;
  let metadataText = "";

  if (title === "High-Risk Suppliers") {
    // Main: Supplier Name (e.g., "Glenmark Generics")
    mainName = item.name;
    // Metadata: Supplier ID • NDC (if available) - single row separated by dots
    const vendorNbr = item.vendorNbr || "";
    const metadataParts: string[] = [];
    if (vendorNbr) {
      metadataParts.push(vendorNbr);
    }
    if (item.ndc) {
      metadataParts.push(item.ndc);
    }
    metadataText = metadataParts.join(" • ");
  } else if (title === "High-Risk Materials") {
    // Main: Material Name
    mainName = item.name;
    // Metadata: Material ID • Brand • NDC • Material Status - single row separated by dots
    const matNbr = item.matNbr || "";
    const materialGroup = item.materialGroup || "N/A";
    const ndc = item.ndc || "N/A";
    const brand = item.productFamily || undefined;

    const metadataParts: string[] = [];
    if (matNbr) {
      metadataParts.push(matNbr);
    }
    if (brand) {
      metadataParts.push(brand);
    }
    if (ndc && ndc !== "N/A") {
      metadataParts.push(ndc);
    }
    if (materialGroup && materialGroup !== "N/A") {
      metadataParts.push(materialGroup);
    }
    metadataText = metadataParts.join(" • ");
  } else {
    // Default behavior for other titles
    const nameParts = item.name.includes(" • ") ? item.name.split(" • ") : [item.name, ""];
    mainName = nameParts[0];
    const metadataParts: string[] = [];
    if (nameParts[1]) {
      metadataParts.push(nameParts[1]);
    }
    if (item.ndc) {
      metadataParts.push(item.ndc);
    }
    metadataText = metadataParts.join(" • ");
  }

  return (
    <div
      className={cn(
        "flex items-center gap-3 rounded-[8px] border border-[#E8E8E8] bg-[#F5F5F540] p-4 mb-3",
        onMetadataClick && "cursor-pointer hover:bg-[#EBEBEB40] transition-colors"
      )}
      onClick={onMetadataClick}
      role={onMetadataClick ? "button" : undefined}
    >
      <div className="grow min-w-0">
        <div className="flex flex-row items-center justify-between mb-2">
          <div className="flex flex-row items-center gap-2">
            <div className={cn("w-2 h-2 rounded-full", dotColor)} />
            <p className="font-bold text-sm text-ui-text-primary">
              {mainName}
            </p>
          </div>
          <RiskBadge
            riskRating={riskRating}
            showIcon={true}
            size="xs"
          />
        </div>
        {metadataText && (
          <div className="text-xs text-ui-text-muted mb-1">
            {metadataText}
          </div>
        )}
        <div className="text-xs text-ui-text-muted">
          {item.description}
        </div>
      </div>
    </div>
  );
};


interface RiskListCardHeaderProps {
  title: string;
  description: string;
  items: RiskListItem[];
  totalCount?: number;
}

const RiskListCardHeader = ({ title, description, items, totalCount: propTotalCount }: RiskListCardHeaderProps) => {
  // Count items by risk level
  const riskCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    items.forEach(item => {
      const riskColors = item.riskRating !== undefined ? getRiskRatingColors(item.riskRating) : getRiskRatingColors(0.5);
      const label = riskColors.label;
      counts[label] = (counts[label] || 0) + 1;
    });
    return counts;
  }, [items]);

  // Use totalCount from prop if provided (even if 0), otherwise fall back to items.length
  // This ensures we show the actual total count, not just the displayed items count
  const totalCount = propTotalCount !== undefined && propTotalCount !== null ? propTotalCount : items.length;

  // Get legend items for risk levels that have items
  // Match the actual risk rating colors from getRiskRatingColors
  const legendItems = useMemo(() => {
    const riskLevelColors: Record<string, { color: string; label: string }> = {
      "Highly Unlikely": { color: "bg-green-600", label: "Highly Unlikely" },
      "Unlikely": { color: "bg-green-600", label: "Unlikely" },
      "Even Chance": { color: "bg-warning-600", label: "Even Chance" },
      "Likely": { color: "bg-warning-600", label: "Likely" },
      "Highly Likely": { color: "bg-red-600", label: "Highly Likely" },
    };

    return Object.entries(riskLevelColors)
      .filter(([label]) => (riskCounts[label] || 0) > 0)
      .map(([label, config]) => ({
        ...config,
        count: riskCounts[label] || 0,
      }));
  }, [riskCounts]);

  const itemType = title.includes("Suppliers") ? "Suppliers" : "Materials";

  const noun = title === "High-Risk Suppliers" ? "Supplier" : title === "High-Risk Materials" ? "Material" : "Issue";

  return (
    <CardHeader className="shrink-0">
      <div className="flex items-center justify-between mb-2">
        <CardTitle className="text-xl font-bold leading-[28.8px] text-heading font-brand" style={TITLE_STYLES} data-testid="card-title">
          {title}
        </CardTitle>
        <div className="px-2.5 bg-[#F5F5F5] rounded-full">
          <span className="text-xs font-medium text-[#475569]">
            {`${totalCount} Total ${noun}${totalCount > 1 ? "s" : ""}`}
          </span>
        </div>
      </div>
      <CardDescription className="mb-3 text-ui-text-secondary text-sm">{description}</CardDescription>
      {(title === "Top At-Risk Suppliers" || title === "Top At-Risk Materials" || title === "High-Risk Suppliers" || title === "High-Risk Materials") && <hr className="mb-3" />}
      <div className="flex items-center gap-6 flex-wrap">
        {legendItems.map((item, index) => (
          <div key={index} className="flex items-center gap-2">
            <div className="flex flex-col">
              <div className="flex flex-row items-center gap-1">
                <div className={cn("w-3 h-1 rounded", item.color)}></div>
                <span className="text-xs text-[#64748B] font-medium">{item.label}</span>
              </div>
              <span className="text-xs text-[#3B3B3B]">{item.count}  {itemType}</span>
            </div>
          </div>
        ))}
      </div>
    </CardHeader>
  );
};

const CardFooter = ({ title }: { title: string }) => {
  const targetPath = ROUTE_MAP[title] || "";

  if (!targetPath) return null;

  return (
    <div className="flex justify-end pb-4">
      <Link to={targetPath} className="font-semibold text-brand-primary-main text-[14px] flex items-center gap-1">
        View More
        <ChevronRight className="h-6 w-6 text-brand-primary-main" aria-hidden />
      </Link>
    </div>
  );
};

const RiskListCardSkeleton = ({
  title,
  description: _description,
  itemCount = 3,
}: {
  title: string;
  description: string;
  itemCount?: number;
}) => (
  <Card className="flex flex-col h-full">
    <CardHeader className="shrink-0">
      <div className="flex items-center justify-between mb-2">
        <CardTitle className="text-xl font-bold leading-[28.8px] text-heading font-brand" style={TITLE_STYLES}>
          {title}
        </CardTitle>
        <div className="px-2 py-1 bg-[#F5F5F5] rounded-[12px] animate-pulse h-6 w-24" />
      </div>
      <div className="mb-3">
        <div className="bg-gray-200 rounded animate-pulse h-4 w-3/4" />
      </div>
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-0.5 bg-gray-200 rounded animate-pulse" />
          <div className="flex flex-col gap-1">
            <div className="bg-gray-200 rounded animate-pulse h-3 w-20" />
            <div className="bg-gray-200 rounded animate-pulse h-3 w-16" />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-0.5 bg-gray-200 rounded animate-pulse" />
          <div className="flex flex-col gap-1">
            <div className="bg-gray-200 rounded animate-pulse h-3 w-16" />
            <div className="bg-gray-200 rounded animate-pulse h-3 w-16" />
          </div>
        </div>
      </div>
    </CardHeader>
    <CardContent className="flex-1 flex flex-col px-4 pt-4 pb-4 gap-4 min-h-0">
      <div className="flex-1 min-h-0 overflow-y-auto">
        {Array.from({ length: itemCount }).map((_, index) => (
          <div
            key={index}
            className="flex items-center gap-3 rounded-lg border border-ui-border-primary bg-ui-background-primary p-4 mb-3"
          >
            <div className="w-2 h-2 bg-gray-200 rounded-full animate-pulse" />
            <div className="grow space-y-2">
              <div className="bg-gray-200 rounded animate-pulse h-[20px] w-3/4" />
              <div className="bg-gray-200 rounded animate-pulse h-[16px] w-1/2" />
              <div className="bg-gray-200 rounded animate-pulse h-[16px] w-2/3" />
            </div>
            <div className="bg-gray-200 rounded-full animate-pulse h-[28px] w-24" />
          </div>
        ))}
      </div>
      <div className="mt-auto shrink-0 flex justify-end pt-4">
        <div className="bg-gray-200 rounded animate-pulse h-[16px] w-24" />
      </div>
    </CardContent>
  </Card>
);

export function RiskListCard({ title, description, loading, error, items, lastFetched = null, totalCount }: RiskListCardProps) {
  const [selectedItem, setSelectedItem] = useState<RiskListItem | null>(null);
  const hasData = items && items.length > 0;
  const hasEverFetched = lastFetched != null;

  const handleMetadataClick = (item: RiskListItem) => {
    setSelectedItem(item);
  };

  const showModal = title?.includes("Materials");

  const handleCloseModal = () => {
    setSelectedItem(null);
  };

  if (loading || (!hasEverFetched && !error)) {
    return (
      <div className="relative h-full">
        <RiskListCardSkeleton title={title} description={description} itemCount={3} />
      </div>
    );
  }

  if (hasEverFetched && !loading && !error && !hasData) {
    return (
      <div className="relative h-full">
        <Card className="flex flex-col h-full">
          <RiskListCardHeader title={title} description={description} items={[]} totalCount={totalCount} />
          <CardContent className="flex-1 flex flex-col px-4 pt-4 pb-4 gap-4 min-h-0" data-testid="card-content">
            <div className="flex-1 flex items-center justify-center">
              <EmptyState
                icon={<Package className="h-12 w-12" />}
                title="No Items Found"
                description="No risk items available for the selected filters."
              />
            </div>
            <div className="mt-auto shrink-0">
              <CardFooter title={title} />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="relative h-full">
      <Card className="flex flex-col h-full">
        <RiskListCardHeader title={title} description={description} items={items} totalCount={totalCount} />
        <CardContent className="flex-1 flex flex-col px-4 pt-4 pb-4 gap-4 relative min-h-0" data-testid="card-content">
          {error && !loading && (
            <div className="absolute inset-0 flex items-center justify-center text-status-error-main z-10 bg-white bg-opacity-90">
              <div className="text-center">
                <p className="text-sm font-medium">Failed to load data</p>
                <p className="text-xs text-ui-text-muted mt-1">{error}</p>
              </div>
            </div>
          )}
          <div className="flex-1 min-h-0 overflow-y-auto">
            {items.map(item => (
              <RiskItem
                key={item.id ?? item.name}
                item={item}
                title={title}
                onMetadataClick={showModal ? () => handleMetadataClick(item) : undefined}
              />
            ))}
          </div>
          <div className="mt-auto shrink-0">
            <CardFooter title={title} />
          </div>
        </CardContent>
      </Card>
      {selectedItem && showModal && (
        <MaterialRiskDriverModal
          isOpen={!!selectedItem}
          onClose={handleCloseModal}
          materialName={selectedItem.name}
          vendorName={selectedItem.vendorName}
          overallRiskScore={(selectedItem.riskRating ?? 0.5) * 100}
          dollarsAtRisk={selectedItem.dollarsAtRisk ?? 0}
          materialId={selectedItem.id}
          materialNbr={selectedItem.matNbr}
          drivingRisk={selectedItem.description}
          ndc={selectedItem.ndc}
        />
      )}
    </div>
  );
}
