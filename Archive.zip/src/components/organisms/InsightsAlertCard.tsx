import { useRef, useState } from "react";
import arrowRightIcon from "@/assets/icons/right-arrow-primary.svg";
import {
  InsightAlertModal,
  type InsightAlertModalData,
} from "./InsightAlertModal";

export interface InsightAlert extends InsightAlertModalData {
  onViewDetails?: () => void;
}

interface InsightsAlertCardProps {
  alert: InsightAlert;
}

export function InsightsAlertCard({ alert }: InsightsAlertCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);

  const handleCardClick = () => {
    setIsModalOpen(true);
    if (alert.onViewDetails) {
      alert.onViewDetails();
    }
  };

  return (
    <>
      <div
        className="bg-[#EEEDFE52] border border-[#E2E8F0] rounded-lg p-3 cursor-pointer hover:shadow-md transition-shadow flex flex-col h-full min-h-[160px]"
        onClick={handleCardClick}
      >
        <h3 className="font-semibold text-ui-text-primary mb-2 text-base shrink-0 line-clamp-2">
          {alert.title}
        </h3>
        <p
          className={`text-sm text-ui-text-secondary flex-1 line-clamp-3 ${alert.affectedMaterials?.length ? "mb-3" : "mb-4"}`}
        >
          {alert.description}
        </p>
        {alert.affectedMaterials && alert.affectedMaterials.length > 0 && (
          <div className="mb-3 overflow-x-auto scrollbar-hover-thin">
            <div className="flex flex-nowrap gap-2">
              {alert.affectedMaterials.map((material, index) => (
                <span
                  key={index}
                  className="bg-[#EEEDFE] text-[#461E96] px-2.5 py-1 rounded-full text-xs font-medium shrink-0 whitespace-nowrap"
                >
                  {material}
                </span>
              ))}
            </div>
          </div>
        )}
        <button
          ref={triggerRef}
          type="button"
          className="border-3 border-[#CACACA] hover:bg-brand-primary-50 rounded-[4px] px-2 py-1 text-sm shrink-0 mt-auto w-fit"
          onClick={(e) => {
            e.stopPropagation();
            handleCardClick();
          }}
        >
          <div className="flex flex-row items-center space-x-1">
            <div className="text-sm font-bold text-brand-primary-main whitespace-nowrap">
              View Details
            </div>
            <img src={arrowRightIcon} alt="Arrow Right" className="w-4 h-4" />
          </div>
        </button>
      </div>

      <InsightAlertModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        alert={alert}
        triggerRef={triggerRef}
      />
    </>
  );
}
