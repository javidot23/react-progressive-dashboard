import React from "react";
import { getRiskBadge } from "@/lib/vendorUtils";
import { formatCurrencyCompact, formatPercentageDisplay } from "@/lib/utils";
import { isFullFeatureSet } from "@/tenant";
import type { IssueImpactedMaterialApiData } from "@/types/granularityIssue";

interface ImpactedMaterialsTableProps {
  materials: IssueImpactedMaterialApiData[];
  selected: Set<string>;
  onToggle: (matNbr: string) => void;
  onRowClick: (material: IssueImpactedMaterialApiData) => void;
}

const FLAG_LABELS: { key: keyof IssueImpactedMaterialApiData; label: string }[] = [
  { key: "who_essential_flg", label: "WHO Essential" },
  { key: "inj_flg", label: "Injectable" },
  { key: "short_date_flg", label: "Short Date" },
  { key: "drop_ship_flg", label: "Drop Ship" },
  { key: "fee_for_service_flg", label: "Fee-for-Service" },
  { key: "dqsa_exempt_flg", label: "DQSA Exempt" },
];

function materialFlags(material: IssueImpactedMaterialApiData): string[] {
  return FLAG_LABELS.filter(f => Boolean(material[f.key])).map(f => f.label);
}

export const ImpactedMaterialsTable: React.FC<ImpactedMaterialsTableProps> = ({
  materials,
  selected,
  onToggle,
  onRowClick,
}) => {
  const showExactScore = isFullFeatureSet();

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-left" style={{ minWidth: 900 }}>
        <thead className="font-bold text-ui-text-primary border-b border-[#E2E8F0]">
          <tr>
            <th className="px-3 py-2 w-10" />
            <th className="px-3 py-2 min-w-[200px]">Material</th>
            <th className="px-3 py-2 min-w-[120px]">NDC</th>
            <th className="px-3 py-2 min-w-[160px]">Supplier</th>
            <th className="px-3 py-2 min-w-[120px]">Risk Score</th>
            <th className="px-3 py-2 min-w-[120px] text-right">$ at Risk</th>
            <th className="px-3 py-2 min-w-[110px] text-right">On-Hand Qty</th>
            <th className="px-3 py-2 min-w-[110px] text-right">Unfilled Qty</th>
            <th className="px-3 py-2 min-w-[90px] text-right">OTIF</th>
            <th className="px-3 py-2 min-w-[160px]">Flags</th>
            <th className="px-3 py-2 w-8" />
          </tr>
        </thead>
        <tbody>
          {materials.map(material => {
            const isChecked = selected.has(material.mat_nbr);
            const riskBadge = getRiskBadge(material.risk_rating ?? 0);
            const flags = materialFlags(material);
            const onHand = material.saleable_qty_on_hand;

            return (
              <tr
                key={material.mat_nbr}
                className={`border-b border-[#F0F0F0] cursor-pointer transition-colors ${
                  isChecked
                    ? "bg-brand-primary-50 hover:bg-brand-primary-100"
                    : "hover:bg-gray-50"
                }`}
                onClick={() => onRowClick(material)}
              >
                <td
                  className="px-3 py-2"
                  onClick={e => {
                    e.stopPropagation();
                    onToggle(material.mat_nbr);
                  }}
                >
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={() => onToggle(material.mat_nbr)}
                    onClick={e => e.stopPropagation()}
                    aria-label={`Include ${material.name} in the action`}
                    className="cursor-pointer"
                  />
                </td>
                <td className="px-3 py-2">
                  <div className="font-semibold text-brand-primary-main">{material.name}</div>
                  <div className="font-mono text-xs text-[#6E6E6E]">
                    {material.mat_nbr}
                    {material.material_group ? ` · ${material.material_group}` : ""}
                  </div>
                </td>
                <td className="px-3 py-2 font-mono text-xs">{material.ndc || "-"}</td>
                <td className="px-3 py-2">
                  <div>{material.vendor || "-"}</div>
                  {material.vendor_nbr ? <div className="text-xs text-[#6E6E6E]">{material.vendor_nbr}</div> : null}
                </td>
                <td className="px-3 py-2">
                  <span
                    className={`inline-flex items-center ${riskBadge.bgColor} ${riskBadge.textColor} border ${riskBadge.borderColor} px-2 py-0.5 rounded text-xs font-semibold text-nowrap`}
                  >
                    {showExactScore ? `${Math.round((material.risk_rating ?? 0) * 100)} / 100` : riskBadge.text}
                  </span>
                </td>
                <td className="px-3 py-2 text-right font-bold">
                  {formatCurrencyCompact(material.dollars_at_risk ?? 0, true)}
                </td>
                <td className="px-3 py-2 text-right">
                  {onHand != null ? onHand.toLocaleString() : "-"}
                </td>
                <td className="px-3 py-2 text-right">
                  {material.unfilled_qty != null ? material.unfilled_qty.toLocaleString() : "-"}
                </td>
                <td className="px-3 py-2 text-right">
                  {material.otif_percentage != null ? formatPercentageDisplay(material.otif_percentage) : "-"}
                </td>
                <td className="px-3 py-2">
                  <div className="flex flex-wrap gap-1">
                    {flags.length > 0
                      ? flags.map(flag => (
                          <span
                            key={flag}
                            className="inline-flex items-center rounded bg-brand-primary-100 text-brand-primary-main px-1.5 py-0.5 text-2xs font-semibold text-nowrap"
                          >
                            {flag}
                          </span>
                        ))
                      : "-"}
                  </div>
                </td>
                <td className="px-3 py-2 text-[#A0A0A0]">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4">
                    <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                  </svg>
                </td>
              </tr>
            );
          })}
          {materials.length === 0 && (
            <tr>
              <td colSpan={11} className="px-4 py-6 text-center text-ui-text-secondary">
                No impacted materials for this issue.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ImpactedMaterialsTable;
