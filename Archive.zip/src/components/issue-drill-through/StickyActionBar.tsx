import React from "react";
import { formatCurrencyCompact } from "@/lib/utils";

interface StickyActionBarProps {
  /** Label of the currently-selected recommended action (null = none chosen). */
  actionLabel: string | null;
  selectedCount: number;
  totalCount: number;
  /** Summed $ at risk across the selected materials. */
  selectedDollars: number;
  /** True when the chosen action is a product substitution (routes off-page, single material only). */
  isSubstitution: boolean;
  onApply: () => void;
  isSubmitting?: boolean;
}

export const StickyActionBar: React.FC<StickyActionBarProps> = ({
  actionLabel,
  selectedCount,
  totalCount,
  selectedDollars,
  isSubstitution,
  onApply,
  isSubmitting = false,
}) => {
  const excludedCount = Math.max(0, totalCount - selectedCount);
  // Substitution can only run against a single material.
  const substitutionBlocked = isSubstitution && selectedCount !== 1;
  const disabled = !actionLabel || selectedCount === 0 || substitutionBlocked || isSubmitting;

  const buttonLabel = isSubstitution
    ? `Review substitutes for ${selectedCount} →`
    : `Apply to ${selectedCount} material${selectedCount === 1 ? "" : "s"}`;

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#E2E8F0]"
      style={{ boxShadow: "0 -4px 20px rgba(0,0,0,0.06)" }}
    >
      <div className="mx-auto max-w-[1400px] px-8 py-3 flex items-center justify-between gap-4">
        <div className="min-w-0">
          <div className="text-sm font-bold text-brand-primary-main truncate">
            {actionLabel ? `Selected action: ${actionLabel}` : "Select a recommended action"}
          </div>
          <div className="text-xs text-ui-text-secondary">
            Applies to {selectedCount} material{selectedCount === 1 ? "" : "s"} ·{" "}
            {formatCurrencyCompact(selectedDollars, true)}
            {excludedCount > 0 ? <span className="text-[#C2551F]"> · {excludedCount} excluded</span> : null}
            {substitutionBlocked ? (
              <span className="text-[#C2551F]"> · select exactly one material to review substitutes</span>
            ) : null}
          </div>
        </div>
        <button
          type="button"
          onClick={onApply}
          disabled={disabled}
          className="px-4 py-2 text-white text-sm font-semibold rounded-md whitespace-nowrap transition-colors"
          style={{ backgroundColor: disabled ? "#C9C2E6" : "#461E96" }}
        >
          {isSubmitting ? "Applying..." : buttonLabel}
        </button>
      </div>
    </div>
  );
};

export default StickyActionBar;
