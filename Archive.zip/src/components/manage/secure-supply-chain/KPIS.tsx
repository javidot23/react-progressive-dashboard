import { useQuery } from "@tanstack/react-query";
import { materialEpcisKpisQueryOptions } from "@/hooks/manage/secure-supply-chain/epcis-coverage";
import { formatUsInteger } from "@/lib/usFormat";
import InfoIcon from "@/components/atoms/InfoIcon";

const TOTAL_MATERIALS_INFO =
  "Displays the count of the supplier's active products subject to DSCSA, excluding discontinued items. Reflects the full catalog and is not limited to the selected time window.";
const TOTAL_WEE_MATERIALS_INFO =
  "Displays the count of products under a DSCSA Waiver, Exception, or Exemption (WEE). A subset of Total Materials.";
const TOTAL_RECEIVED_INFO = "Displays the count of distinct products received within the selected time window.";
const SCOPE_NOTE =
  "Total Materials and Total WEE Materials reflect the full active catalog and are not affected by the date filter. Total Received and coverage metrics are scoped to the selected time window.";

const FileLineIcon = () => (
  <svg width="35" height="35" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="35" height="35" rx="4" fill="#EEEDFE" />
    <path
      d="M8.60167 20.4694H13.2171C13.4373 20.4682 13.6528 20.4062 13.84 20.2903C14.0272 20.1743 14.1788 20.0089 14.2779 19.8123L15.6792 17.0019C15.7335 16.8981 15.817 16.8125 15.9194 16.7555C16.0217 16.6985 16.1385 16.6726 16.2553 16.681C16.3722 16.6894 16.484 16.7317 16.5771 16.8028C16.6703 16.8739 16.7406 16.9706 16.7796 17.0811L18.2442 21.459C18.2823 21.5695 18.3523 21.6663 18.4453 21.7372C18.5382 21.8081 18.6501 21.85 18.7667 21.8576C18.8834 21.8652 18.9997 21.8382 19.1011 21.78C19.2025 21.7217 19.2845 21.6349 19.3367 21.5302L20.7458 18.7198C20.8435 18.5221 20.9947 18.3557 21.1822 18.2395C21.3698 18.1234 21.5861 18.0621 21.8067 18.0627H26.4063M8.59375 13.1465H26.4063M9.78125 9.58398H25.2188C25.8746 9.58398 26.4063 10.1156 26.4063 10.7715V24.2298C26.4063 24.8857 25.8746 25.4173 25.2188 25.4173H9.78125C9.12541 25.4173 8.59375 24.8857 8.59375 24.2298V10.7715C8.59375 10.1156 9.12541 9.58398 9.78125 9.58398Z"
      stroke="#461E96"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const ChecklistIcon = () => (
  <svg width="35" height="35" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="35" height="35" rx="4" fill="#EEEDFE" />
    <path
      d="M12.1563 16.3213H16.3125M12.1563 19.29H14.5313M12.1563 22.2588H14.5313M15.7188 26.415H9.78125C9.46631 26.415 9.16426 26.2899 8.94156 26.0672C8.71886 25.8445 8.59375 25.5425 8.59375 25.2275V12.7588C8.59375 12.4438 8.71886 12.1418 8.94156 11.9191C9.16426 11.6964 9.46631 11.5713 9.78125 11.5713H12.75C12.75 10.7839 13.0628 10.0288 13.6195 9.47207C14.1763 8.91532 14.9314 8.60254 15.7188 8.60254C16.5061 8.60254 17.2612 8.91532 17.818 9.47207C18.3747 10.0288 18.6875 10.7839 18.6875 11.5713H21.6563C21.9712 11.5713 22.2732 11.6964 22.4959 11.9191C22.7186 12.1418 22.8438 12.4438 22.8438 12.7588V14.54M23.7732 20.2836L21.4734 23.3505C21.4222 23.4185 21.3571 23.4748 21.2824 23.5154C21.2076 23.5561 21.125 23.5803 21.0401 23.5863C20.9552 23.5923 20.8701 23.58 20.7903 23.5502C20.7106 23.5205 20.6382 23.474 20.578 23.4138L19.3905 22.2263M15.7227 10.9799C15.6638 10.9799 15.6063 10.9974 15.5574 11.0302C15.5085 11.063 15.4705 11.1095 15.4481 11.1639C15.4258 11.2184 15.4201 11.2782 15.4318 11.3359C15.4435 11.3936 15.4721 11.4465 15.5139 11.4879C15.5558 11.5292 15.6089 11.5573 15.6667 11.5684C15.7245 11.5795 15.7843 11.5731 15.8385 11.5502C15.8927 11.5272 15.9388 11.4887 15.9711 11.4394C16.0033 11.3902 16.0202 11.3325 16.0196 11.2736C16.0197 11.2346 16.0121 11.196 15.9972 11.1599C15.9823 11.1238 15.9604 11.0911 15.9328 11.0635C15.9053 11.0359 15.8725 11.014 15.8364 10.9992C15.8004 10.9843 15.7617 10.9767 15.7227 10.9768M16.9063 21.665C16.9063 22.9248 17.4067 24.133 18.2975 25.0238C19.1883 25.9146 20.3965 26.415 21.6563 26.415C22.916 26.415 24.1242 25.9146 25.015 25.0238C25.9058 24.133 26.4063 22.9248 26.4063 21.665C26.4063 20.4053 25.9058 19.1971 25.015 18.3063C24.1242 17.4155 22.916 16.915 21.6563 16.915C20.3965 16.915 19.1883 17.4155 18.2975 18.3063C17.4067 19.1971 16.9063 20.4053 16.9063 21.665Z"
      stroke="#461E96"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export interface KPISProps {
  days: number;
  filtersVersion: number;
}

const KPI_CARD_COUNT = 3;

const KpiCardSkeleton = () => (
  <div className="flex-1 flex flex-col gap-3 bg-neutral-0 rounded-md border border-ui-border-base p-4 animate-pulse">
    <div className="flex justify-between">
      <div className="flex items-center gap-3">
        <div className="w-[35px] h-[35px] rounded bg-gray-200" />
        <div className="h-4 w-32 rounded bg-gray-200" />
      </div>
    </div>
    <div className="h-9 w-20 rounded bg-gray-200" />
  </div>
);

function KPIS({ days, filtersVersion }: KPISProps) {
  const { data, isPending, isError, error } = useQuery(materialEpcisKpisQueryOptions(filtersVersion, days));

  if (isPending) {
    return (
      <div className="flex flex-wrap gap-4 w-full">
        {Array.from({ length: KPI_CARD_COUNT }, (_, i) => (
          <KpiCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex flex-wrap gap-4 w-full">
        <div className="flex-1 rounded-md border border-status-error-main/30 bg-neutral-0 p-4 text-sm text-status-error-main">
          Failed to load KPIs: {error instanceof Error ? error.message : "Unknown error"}
        </div>
      </div>
    );
  }

  const kpis = [
    {
      icon: <FileLineIcon />,
      title: "Total Materials",
      value: formatUsInteger(data?.total_mat_count ?? 0),
      tooltip: TOTAL_MATERIALS_INFO,
    },
    {
      icon: <FileLineIcon />,
      title: "Total WEE Materials",
      value: formatUsInteger(data?.total_wee_mat_count ?? 0),
      tooltip: TOTAL_WEE_MATERIALS_INFO,
    },
    {
      icon: <ChecklistIcon />,
      title: "Total Received",
      value: formatUsInteger(data?.total_mats_received_count ?? 0),
      tooltip: TOTAL_RECEIVED_INFO,
    },
  ];

  return (
    <div className="w-full">
      <div className="flex flex-wrap gap-4 w-full">
        {kpis.map(kpi => (
          <div
            key={kpi.title}
            className="flex-1 min-w-[10rem] flex flex-col gap-3 bg-neutral-0 rounded-md border border-ui-border-base p-4"
          >
            <div className="flex justify-between gap-2">
              <div className="flex items-center gap-3">
                {kpi.icon}
                <span className="text-text-secondary">{kpi.title}</span>
              </div>
              <InfoIcon tooltip={kpi.tooltip} size={18} />
            </div>
            <span className="text-text-primary text-3xl font-bold">{kpi.value}</span>
          </div>
        ))}
      </div>
      <p className="mt-2 text-xs text-ui-text-muted">{SCOPE_NOTE}</p>
    </div>
  );
}

export default KPIS;
