export interface SalesGroupSale {
  sales_group: string;
  total_sales_qty: number;
}

export interface SalesGroupConfig {
  key: string;
  label: string;
  color: string;
}

export const SALES_GROUP_ORDER: SalesGroupConfig[] = [
  { key: "PRxO", label: "PRxO", color: "#0073BE" },
  { key: "PGEN", label: "Pharmagen", color: "#E6008C" },
  { key: "WAG", label: "WAG", color: "#461E96" },
  { key: "3rd Party", label: "Third Party", color: "#DD7005" },
  { key: "GOVT", label: "Govt", color: "#119D63" },
  { key: "NONE", label: "Non-Contract", color: "#9CA3AF" },
];

const COLOR_BY_KEY: Record<string, string> = Object.fromEntries(SALES_GROUP_ORDER.map(g => [g.key, g.color]));

const LABEL_BY_KEY: Record<string, string> = Object.fromEntries(SALES_GROUP_ORDER.map(g => [g.key, g.label]));

export function getSalesGroupColor(key: string): string {
  return COLOR_BY_KEY[key] ?? "#C4C4C4";
}

export function getSalesGroupLabel(key: string): string {
  return LABEL_BY_KEY[key] ?? key;
}
