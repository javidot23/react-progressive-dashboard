import { memo, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MapContainer, GeoJSON } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import type { ComponentProps } from "react";
import type { Layer, Path } from "leaflet";
import { EmptyState } from "@/components/molecules";
import usStatesData from "@/public/data/us-states.json";
import { stateSalesComparisonQueryOptions } from "@/hooks/manage/sales";
import { computeMapTooltipPlacement } from "@/lib/mapTooltipPlacement";
import type { StateSalesComparisonItem } from "@/lib/apiServices";
import { parseCsSalesMetric } from "@/lib/csSalesValueParse";
import {
  BORDER_COLOR,
  calculateStateSalesFillColor,
  DEFAULT_BORDER_WEIGHT,
  DEFAULT_FILL_OPACITY,
  EMPTY_STATE_COLOR,
  getStateNameFromFeature,
  HOVER_BORDER_WEIGHT,
  HOVER_FILL_OPACITY,
  MAP_CONFIG,
  MAP_HEIGHT,
  repositionRemoteStates,
  STATE_ABBREVIATION_TO_NAME,
  type GeoJSONFeature,
} from "@/lib/csSalesChangeTrackingConstants";

const MapSkeleton = memo(() => (
  <div className="w-full h-full min-h-110 relative bg-white rounded-[10px] border border-[#E2E8F0]">
    <div className="absolute inset-0 bg-gray-200 rounded-lg animate-pulse" />
  </div>
));
MapSkeleton.displayName = "MapSkeleton";

const MapErrorState = memo<{ error: string }>(({ error }) => (
  <div
    className="w-full h-full flex items-center justify-center min-h-110 text-status-error-main bg-white rounded-lg border border-ui-border-primary"
    role="alert"
    aria-live="polite"
  >
    <div className="text-center">
      <p className="text-sm font-medium">Failed to load map data</p>
      <p className="text-xs text-ui-text-muted mt-1">{error}</p>
    </div>
  </div>
));
MapErrorState.displayName = "MapErrorState";

interface StateComparisonLookup {
  currentValue: number;
  previousValue: number;
  percentChange: number;
}

interface TooltipContentState {
  stateName: string;
  currentValue: number;
  previousValue: number;
  percentChange: number;
}

export const CsSalesChangeTrackingWorldMap = memo(function CsSalesChangeTrackingWorldMap({
  filtersVersion,
  activeTab,
  filters,
  isDollars = true,
  enabled = true,
}: {
  filtersVersion: number;
  activeTab: "historical" | "current";
  filters?: { measure?: string; period?: string; state?: string };
  isDollars?: boolean;
  enabled?: boolean;
}) {
  const {
    data,
    dataUpdatedAt,
    isPending: loading,
    error,
  } = useQuery({
    ...stateSalesComparisonQueryOptions(filtersVersion, activeTab, filters),
    enabled,
  });
  const stateSalesData = useMemo(() => data?.data ?? [], [data?.data]);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [tooltipVisible, setTooltipVisible] = useState(false);
  const [tooltipContent, setTooltipContent] = useState<TooltipContentState | null>(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
  const lastStateKeyRef = useRef("");
  const pendingPosRef = useRef({ x: 0, y: 0 });
  const posRafRef = useRef<number | null>(null);

  const scheduleTooltipPosUpdate = useCallback(() => {
    if (posRafRef.current != null) return;
    posRafRef.current = requestAnimationFrame(() => {
      posRafRef.current = null;
      const { x, y } = pendingPosRef.current;
      setTooltipPos(p => (p.x === x && p.y === y ? p : { x, y }));
    });
  }, []);

  useEffect(
    () => () => {
      if (posRafRef.current != null) cancelAnimationFrame(posRafRef.current);
    },
    []
  );

  const mapTooltipRef = useRef<HTMLDivElement>(null);
  const [tooltipPlacement, setTooltipPlacement] = useState({
    left: 0,
    top: 0,
    transform: "translateY(-100%)",
  });

  useLayoutEffect(() => {
    if (!tooltipVisible || !mapContainerRef.current) return;
    const container = mapContainerRef.current;
    const apply = () => {
      const cw = container.clientWidth;
      const ch = container.clientHeight;
      const tw = mapTooltipRef.current?.offsetWidth || 240;
      const th = mapTooltipRef.current?.offsetHeight || 120;
      setTooltipPlacement(computeMapTooltipPlacement(tooltipPos.x, tooltipPos.y, cw, ch, tw, th));
    };
    apply();
    const raf = requestAnimationFrame(apply);
    return () => cancelAnimationFrame(raf);
  }, [tooltipVisible, tooltipPos.x, tooltipPos.y, tooltipContent, isDollars]);

  const transformedGeoJsonData = useMemo(() => repositionRemoteStates(usStatesData), []);

  const comparisonLookup = useMemo(() => {
    const lookup: Record<string, StateComparisonLookup> = {};
    if (!stateSalesData || stateSalesData.length === 0) return lookup;
    stateSalesData.forEach((item: StateSalesComparisonItem) => {
      const current = isDollars
        ? parseCsSalesMetric(item.current_period_sales)
        : parseCsSalesMetric(item.current_period_order_qty);
      const previous = isDollars
        ? parseCsSalesMetric(item.previous_period_sales)
        : parseCsSalesMetric(item.previous_period_order_qty);
      const percentChange = previous > 0 ? ((current - previous) / previous) * 100 : current > 0 ? 100 : 0;
      const fullStateName = STATE_ABBREVIATION_TO_NAME[item.state];
      if (fullStateName) {
        lookup[fullStateName] = { currentValue: current, previousValue: previous, percentChange };
      }
    });
    return lookup;
  }, [stateSalesData, isDollars]);

  const currentPeriodValueRange = useMemo(() => {
    const vals = Object.values(comparisonLookup).map(c => c.currentValue);
    if (vals.length === 0) return { min: 0, max: 0 };
    return { min: Math.min(...vals), max: Math.max(...vals) };
  }, [comparisonLookup]);

  const geoJsonStyle = useCallback(
    (feature?: GeoJSONFeature) => {
      if (!feature) {
        return {
          fillColor: EMPTY_STATE_COLOR,
          weight: DEFAULT_BORDER_WEIGHT,
          opacity: 1,
          color: BORDER_COLOR,
          fillOpacity: DEFAULT_FILL_OPACITY,
        };
      }
      const stateName = getStateNameFromFeature(feature);
      const comp = comparisonLookup[stateName];
      if (comp === undefined) {
        return {
          fillColor: EMPTY_STATE_COLOR,
          weight: DEFAULT_BORDER_WEIGHT,
          opacity: 1,
          color: BORDER_COLOR,
          fillOpacity: DEFAULT_FILL_OPACITY,
        };
      }
      const color = calculateStateSalesFillColor(comp.currentValue, currentPeriodValueRange.min, currentPeriodValueRange.max);
      return {
        fillColor: color,
        weight: DEFAULT_BORDER_WEIGHT,
        opacity: 1,
        color: BORDER_COLOR,
        fillOpacity: DEFAULT_FILL_OPACITY,
      };
    },
    [comparisonLookup, currentPeriodValueRange.min, currentPeriodValueRange.max]
  );

  const onEachFeature = useCallback(
    (feature: GeoJSONFeature, layer: Layer) => {
      const stateName = getStateNameFromFeature(feature);
      if (!stateName) return;
      const comp = comparisonLookup[stateName];
      const pathLayer = layer as Path;
      pathLayer.on({
        mouseover: function (e) {
          const target = e.target as Path;
          target.setStyle({ weight: HOVER_BORDER_WEIGHT, fillOpacity: HOVER_FILL_OPACITY });
          if (target.bringToFront) target.bringToFront();
        },
        mousemove: function (e) {
          if (mapContainerRef.current && comp) {
            const rect = mapContainerRef.current.getBoundingClientRect();
            const x = e.originalEvent.clientX - rect.left;
            const y = e.originalEvent.clientY - rect.top;
            pendingPosRef.current = { x, y };
            scheduleTooltipPosUpdate();
            if (stateName !== lastStateKeyRef.current) {
              lastStateKeyRef.current = stateName;
              setTooltipContent({
                stateName,
                currentValue: comp.currentValue,
                previousValue: comp.previousValue,
                percentChange: comp.percentChange,
              });
            }
            setTooltipVisible(true);
          }
        },
        mouseout: function (e) {
          const target = e.target as Path;
          target.setStyle({ weight: DEFAULT_BORDER_WEIGHT, fillOpacity: DEFAULT_FILL_OPACITY });
          lastStateKeyRef.current = "";
          setTooltipVisible(false);
        },
      });
    },
    [comparisonLookup, scheduleTooltipPosUpdate]
  );

  const geoJsonKey = `cs-map-${filtersVersion}-${activeTab}-${isDollars}-${dataUpdatedAt}`;

  if (loading) return <MapSkeleton />;
  if (error) return <MapErrorState error={error.message} />;
  if (!stateSalesData || stateSalesData.length === 0) {
    return (
      <div className="flex items-center justify-center h-100">
        <EmptyState
          title="No data available"
          description="No data found for the selected filters. Try adjusting your filter criteria to see results."
        />
      </div>
    );
  }

  const geoData = transformedGeoJsonData as ComponentProps<typeof GeoJSON>["data"];

  return (
    <div ref={mapContainerRef} className="relative" style={{ height: `${MAP_HEIGHT}px` }}>
      <MapContainer
        style={{ background: "#ffffff", height: "100%", width: "100%" }}
        center={MAP_CONFIG.center}
        zoom={MAP_CONFIG.zoom}
        minZoom={MAP_CONFIG.minZoom}
        maxZoom={MAP_CONFIG.maxZoom}
        zoomControl={false}
        attributionControl={false}
        scrollWheelZoom={true}
        doubleClickZoom={true}
        dragging={true}
        touchZoom={true}
        maxBounds={MAP_CONFIG.maxBounds}
      >
        <GeoJSON data={geoData} style={geoJsonStyle} onEachFeature={onEachFeature} key={geoJsonKey} />
      </MapContainer>
      {tooltipVisible && tooltipContent && (
        <div
          ref={mapTooltipRef}
          className="absolute pointer-events-none z-1000"
          style={{
            left: tooltipPlacement.left,
            top: tooltipPlacement.top,
            transform: tooltipPlacement.transform,
          }}
        >
          <div className="bg-white border border-gray-200 text-gray-900 text-xs rounded-md shadow-lg w-62.5 p-3 font-normal z-30">
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center gap-4">
                <span className="text-gray-600">State:</span>
                <span className="text-gray-900 font-medium">{tooltipContent.stateName}</span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-gray-600">Current Period:</span>
                <span className="text-gray-900 font-medium">
                  {isDollars ? `$${tooltipContent.currentValue.toLocaleString()}` : tooltipContent.currentValue.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-gray-600">Previous Period:</span>
                <span className="text-gray-900 font-medium">
                  {isDollars
                    ? `$${tooltipContent.previousValue.toLocaleString()}`
                    : tooltipContent.previousValue.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-gray-600">% Change:</span>
                <span className="text-gray-900 font-medium">{tooltipContent.percentChange.toFixed(2)}%</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
});
