import React, { useCallback, useEffect, useId, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import InfoIcon from "@/components/atoms/InfoIcon";
import CardLayout from "@/components/templates/CardLayout";
import { EmptyState } from "@/components/molecules";
import {
  CS_CHANGE_TRACKING_CORPORATE_CHAIN_TABLE_DESCRIPTION,
  CS_CHANGE_TRACKING_MATERIAL_TABLE_DESCRIPTION,
  CS_CHANGE_TRACKING_SALES_GROUP_TABLE_DESCRIPTION,
  getCsSalesComparisonTableSubtitle,
  isCsSalesComparisonTableTitle,
} from "@/lib/csSalesCopy";

export interface ProductSalesData {
  productName: string;
  matNbr?: string;
  salesCurrentPeriod: string;
  salesPreviousPeriod?: string;
  salesCurrentPeriod2?: string;
  maxContractPerMaterial?: string;
  percentChange?: number;
}

export interface ColumnDef {
  key: string;
  label: string;
}

export interface TotalUnitSalesDataTableProps {
  title: string;
  data: ProductSalesData[];
  columns: ColumnDef[];
  showBars?: boolean;
  materialColumnName?: string;
  maxHeight?: string;
  loading?: boolean;
  error?: string | null;
  contractSalesData?: { results?: unknown[] } | null;
  showTooltip?: boolean;
  maxBarWidth?: number;
  showPercentChange?: boolean;
  totalCount?: number;
  pageOffset?: number;
  pageSize?: number;
  onPageChange?: (offset: number) => void;
  onPrefetchNextPage?: () => void;
  comparisonDataContext?: "historical" | "current";
  comparisonMetricLabel?: string;
  preserveServerRowOrder?: boolean;
  paginationAriaScope?: string;
  onScrollEnd?: () => void;
  hasMore?: boolean;
  isFetchingMore?: boolean;
}

/** Distinct colors cycled by stable sort order of `contract_name` values returned from the API. */
const CONTRACT_SEGMENT_COLOR_PALETTE = [
  "#461E96",
  "#DD7005",
  "#0073BE",
  "#E6008C",
  "#119D63",
  "#C45C26",
  "#2E6F95",
  "#B8306A",
  "#3D7A4D",
  "#5C6BC0",
  "#00838F",
  "#8B4A6B",
  "#F9A825",
  "#3949AB",
  "#5B2C83",
  "#6D4C41",
  "#546E7A",
  "#00897B",
  "#7B1FA2",
  "#C62828",
] as const;

function collectContractNamesFromApiResults(results: unknown[] | undefined): string[] {
  const names = new Set<string>();
  for (const row of results ?? []) {
    const cs = (row as { contract_sales?: { contract_name?: unknown }[] }).contract_sales;
    if (!Array.isArray(cs)) continue;
    for (const c of cs) {
      const n = typeof c.contract_name === "string" ? c.contract_name.trim() : "";
      if (n) names.add(n);
    }
  }
  return Array.from(names).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
}

function buildContractColorMapFromResults(results: unknown[] | undefined): {
  names: string[];
  colorByName: Record<string, string>;
} {
  const names = collectContractNamesFromApiResults(results);
  const colorByName: Record<string, string> = {};
  names.forEach((name, i) => {
    colorByName[name] = CONTRACT_SEGMENT_COLOR_PALETTE[i % CONTRACT_SEGMENT_COLOR_PALETTE.length];
  });
  return { names, colorByName };
}

const BAR_REMAINING_COLOR = "#E8E8E8";
const FALLBACK_CONTRACT_COLOR = BAR_REMAINING_COLOR;
const CS_PERCENT_CHANGE_NEGATIVE = "#E22F00";
const CS_PERCENT_CHANGE_POSITIVE = "#027F50";
const CS_PERCENT_CHANGE_TRACK_BG = "#F1F5F9";
const CS_PERCENT_CHANGE_BAR_VISUAL_CAP = 100;
const CS_PERCENT_CHANGE_BAR_WIDTH_FACTOR = 0.82;

const INFO_TOOLTIP_UNIT_SALES_BY_MATERIAL_90D = "Total Unit Sales by Material over the last 90 days.";
const INFO_TOOLTIP_UNIT_SALES_BY_CORPORATE_CHAIN_90D =
  "Total Unit Sales by Corporate Chain over the last 90 days.";

/** CS Sales Change Tracking — material table only: USD in cells/tooltip without double "$". */
function withUsdPrefixIfMissing(value: string): string {
  const t = value.trim();
  if (t === "" || t === "—") return value;
  if (t.startsWith("$")) return value;
  return `$${t}`;
}

function percentChangeBarHalfWidths(percentChange: number): { posHalfPct: number; negHalfPct: number } {
  const pc = Number.isFinite(percentChange) ? percentChange : 0;
  if (pc === 0) return { posHalfPct: 0, negHalfPct: 0 };
  const mag = Math.min(Math.abs(pc), CS_PERCENT_CHANGE_BAR_VISUAL_CAP);
  const widthPct = (mag / CS_PERCENT_CHANGE_BAR_VISUAL_CAP) * 50;
  const visible = Math.max(widthPct, 0.5);
  if (pc > 0) return { posHalfPct: visible, negHalfPct: 0 };
  return { posHalfPct: 0, negHalfPct: visible };
}

const TOOLTIP_OFFSET_PX = 12;
const TOOLTIP_WIDTH_PX = 250;

export interface SalesTableTooltipData {
  materialName?: string;
  contractSales?: Array<{ contract_name: string; total_sales_qty: number }>;
  contractName?: string;
  totalSales?: string;
  comparisonTooltip?: {
    rowLabel: string;
    metricLabel: string;
    currentPeriod: string;
    previousPeriod: string;
    percentChange: number;
  };
}

function applyTooltipPositionToElement(el: HTMLDivElement, data: SalesTableTooltipData, pos: { x: number; y: number }) {
  const ct = data.comparisonTooltip;
  const tooltipWidth = ct ? 300 : TOOLTIP_WIDTH_PX;
  let tooltipLeft = pos.x + TOOLTIP_OFFSET_PX;
  const tooltipBottom = window.innerHeight - pos.y + TOOLTIP_OFFSET_PX;
  const padding = 8;
  tooltipLeft = Math.max(padding, Math.min(tooltipLeft, window.innerWidth - tooltipWidth - padding));
  el.style.left = `${tooltipLeft}px`;
  el.style.bottom = `${tooltipBottom}px`;
  el.style.maxWidth = `${tooltipWidth}px`;
}

type TotalUnitSalesFixedTooltipProps = {
  tooltipData: SalesTableTooltipData;
  title: string;
  tooltipPosRef: React.MutableRefObject<{ x: number; y: number }>;
  tooltipShellRef: React.RefObject<HTMLDivElement | null>;
  applyLayout: () => void;
};

function TotalUnitSalesFixedTooltip({
  tooltipData,
  title,
  tooltipPosRef,
  tooltipShellRef,
  applyLayout,
}: TotalUnitSalesFixedTooltipProps) {
  useLayoutEffect(() => {
    applyLayout();
  }, [tooltipData, applyLayout]);

  const ct = tooltipData.comparisonTooltip;
  const { materialName, contractSales, contractName, totalSales } = tooltipData;
  const isContractTotalSales =
    title === "Total Unit Sales by Contract Name" ||
    title === "Total sale Units by Contract Name" ||
    title === "Total Unit Sales by Contract Type";
  const isCorporateChainTotalSales = title === "Corporate Chain Total Sales" || title === "Total Unit Sales by Corporate Chain";
  const isSalesGroupBreakdownTable =
    title === "Total Unit Sales by Material" || isCorporateChainTotalSales;

  const tooltipWidth = ct ? 300 : TOOLTIP_WIDTH_PX;
  const { x, y } = tooltipPosRef.current;
  let tooltipLeft = x + TOOLTIP_OFFSET_PX;
  const tooltipBottom = window.innerHeight - y + TOOLTIP_OFFSET_PX;
  const padding = 8;
  tooltipLeft = Math.max(padding, Math.min(tooltipLeft, window.innerWidth - tooltipWidth - padding));

  const tooltipContent = (
    <div
      ref={tooltipShellRef}
      className="fixed pointer-events-none shadow-xl"
      style={{
        left: tooltipLeft,
        bottom: tooltipBottom,
        zIndex: 2147483647,
        maxWidth: tooltipWidth,
      }}
    >
      <div className="bg-white border border-gray-200 text-gray-900 text-xs rounded-md shadow-lg p-3 font-normal z-30">
        <div className="flex flex-col gap-2">
          {ct ? (
            <>
              <div className="font-medium text-gray-900 pointer-events-none">{ct.rowLabel}</div>
              <div className="pointer-events-none space-y-2">
                {title === "Total Unit Sales by Material" ? (
                  <>
                    <div className="flex justify-between items-baseline gap-3">
                      <span className="shrink-0 tabular-nums text-gray-600">Current period</span>
                      <span className="text-right font-medium tabular-nums text-gray-900">
                        {ct.metricLabel.toLowerCase().includes("dollar")
                          ? withUsdPrefixIfMissing(ct.currentPeriod)
                          : ct.currentPeriod}
                      </span>
                    </div>
                    <div className="flex justify-between items-baseline gap-3">
                      <span className="shrink-0 tabular-nums text-gray-600">Previous period</span>
                      <span className="text-right font-medium tabular-nums text-gray-900">
                        {ct.previousPeriod === "—"
                          ? "—"
                          : ct.metricLabel.toLowerCase().includes("dollar")
                            ? withUsdPrefixIfMissing(ct.previousPeriod)
                            : ct.previousPeriod}
                      </span>
                    </div>
                    <div className="flex justify-between items-baseline gap-3 pt-1">
                      <span className="shrink-0 font-medium tabular-nums text-white">% Change</span>
                      <span className="text-right font-medium tabular-nums text-white">{ct.percentChange.toFixed(2)}%</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between items-baseline gap-3">
                      <span className="shrink-0 tabular-nums text-gray-600">Current period ({ct.metricLabel})</span>
                      <span className="text-right font-medium tabular-nums text-gray-900">{ct.currentPeriod}</span>
                    </div>
                    <div className="flex justify-between items-baseline gap-3">
                      <span className="shrink-0 tabular-nums text-gray-600">Previous period ({ct.metricLabel})</span>
                      <span className="text-right font-medium tabular-nums text-gray-900">{ct.previousPeriod}</span>
                    </div>
                    <div className="flex justify-between items-baseline gap-3 pt-1">
                      <span className="shrink-0 font-medium tabular-nums text-white">% Change</span>
                      <span className="text-right font-medium tabular-nums text-white">{ct.percentChange.toFixed(2)}%</span>
                    </div>
                  </>
                )}
              </div>
            </>
          ) : isContractTotalSales ? (
            <>
              <div className="flex justify-between items-center space-x-1 pointer-events-none">
                <span className="text-gray-600">Contract name:</span>
                <span className="font-medium text-gray-900">{contractName}</span>
              </div>
              <div className="flex justify-between items-center space-x-1 pointer-events-none">
                <span className="text-gray-600">Total Sales:</span>
                <span className="font-medium text-gray-900">{totalSales}</span>
              </div>
            </>
          ) : (
            <>
              <div className="flex justify-between items-center space-x-1 pointer-events-none">
                <span className="text-gray-600">{isCorporateChainTotalSales ? "Corporate Chain:" : "Material:"}</span>
                <span className="font-medium text-gray-900">{materialName}</span>
              </div>
              {contractSales && contractSales.length > 0 ? (
                <div className="space-y-1 pr-1">
                  {contractSales.map((contract, index) => (
                    <div key={index} className="flex justify-between items-center space-x-1">
                      <span className="text-gray-600">{contract.contract_name}:</span>
                      <span className="font-medium text-gray-900">{contract.total_sales_qty.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-gray-600 pointer-events-none">
                  {isSalesGroupBreakdownTable ? "No sales group data available" : "No contract sales data available"}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );

  return createPortal(tooltipContent, document.body);
}

const TotalUnitSalesDataTable = React.memo(
  ({
    title,
    data,
    columns,
    showBars = false,
    materialColumnName = "Material Name",
    contractSalesData = null,
    showTooltip = false,
    maxBarWidth = 200,
    maxHeight = "600px",
    loading = false,
    error = null,
    showPercentChange = false,
    totalCount,
    pageOffset = 0,
    pageSize = 10,
    onPageChange,
    onPrefetchNextPage,
    comparisonDataContext,
    comparisonMetricLabel = "Sales",
    preserveServerRowOrder = false,
    paginationAriaScope = "rows",
    onScrollEnd,
    hasMore = false,
    isFetchingMore = false,
  }: TotalUnitSalesDataTableProps) => {
    const [tooltipData, setTooltipData] = useState<SalesTableTooltipData | null>(null);
    const hideTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const tooltipLayoutRafRef = useRef<number | null>(null);
    const tooltipPosRef = useRef({ x: 0, y: 0 });
    const tooltipShellRef = useRef<HTMLDivElement | null>(null);
    const tooltipDataRef = useRef<SalesTableTooltipData | null>(null);
    tooltipDataRef.current = tooltipData;
    const colMaterialHeaderId = useId();
    const colSalesHeaderId = useId();
    const colComparisonHeaderId = useId();
    const rowHeaderIdPrefix = useId();
    const pctLabelIdPrefix = useId();

    const applyTooltipLayout = useCallback(() => {
      const el = tooltipShellRef.current;
      const data = tooltipDataRef.current;
      if (!el || !data) return;
      applyTooltipPositionToElement(el, data, tooltipPosRef.current);
    }, []);

    const scheduleTooltipLayout = useCallback(() => {
      if (tooltipLayoutRafRef.current !== null) {
        cancelAnimationFrame(tooltipLayoutRafRef.current);
      }
      tooltipLayoutRafRef.current = requestAnimationFrame(() => {
        tooltipLayoutRafRef.current = null;
        applyTooltipLayout();
      });
    }, [applyTooltipLayout]);

    const handleMouseMove = useCallback(
      (e: React.MouseEvent) => {
        if (!showTooltip) return;
        if (hideTimeoutRef.current) {
          clearTimeout(hideTimeoutRef.current);
          hideTimeoutRef.current = null;
        }
        tooltipPosRef.current = { x: e.clientX, y: e.clientY };
        scheduleTooltipLayout();
      },
      [showTooltip, scheduleTooltipLayout]
    );

    const handlePercentBarMouseMove = useCallback(
      (e: React.MouseEvent) => {
        tooltipPosRef.current = { x: e.clientX, y: e.clientY };
        scheduleTooltipLayout();
      },
      [scheduleTooltipLayout]
    );

    const handleMouseLeave = useCallback(() => {
      hideTimeoutRef.current = setTimeout(() => {
        setTooltipData(null);
        hideTimeoutRef.current = null;
      }, 100);
    }, []);

    useEffect(() => {
      return () => {
        if (tooltipLayoutRafRef.current !== null) cancelAnimationFrame(tooltipLayoutRafRef.current);
        if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);
      };
    }, []);

    const contractSegmentColoring = React.useMemo(
      () => buildContractColorMapFromResults(contractSalesData?.results as unknown[] | undefined),
      [contractSalesData]
    );

    const getColorForContract = useCallback(
      (contractName: string): string => contractSegmentColoring.colorByName[contractName] ?? FALLBACK_CONTRACT_COLOR,
      [contractSegmentColoring]
    );

    const hideMaterialColumnSubLabel =
      title === "Total Unit Sales by Material" ||
      title === "Corporate Chain Total Sales" ||
      title === "Total Unit Sales by Corporate Chain";

    const isContractTypeLegendTable =
      title === "Total Unit Sales by Material" ||
      title === "Total Unit Sales by Contract Name" ||
      title === "Total sale Units by Contract Name" ||
      title === "Total Unit Sales by Contract Type" ||
      title === "Corporate Chain Total Sales" ||
      title === "Total Unit Sales by Corporate Chain";

    const subtitle = React.useMemo(() => {
      if (showBars && showPercentChange && comparisonDataContext && isCsSalesComparisonTableTitle(title)) {
        if (title === "Total Unit Sales by Material") {
          return <p className="text-sm text-ui-text-secondary">{CS_CHANGE_TRACKING_MATERIAL_TABLE_DESCRIPTION}</p>;
        }
        if (title === "Total Unit Sales by Sales Group") {
          return <p className="text-sm text-ui-text-secondary">{CS_CHANGE_TRACKING_SALES_GROUP_TABLE_DESCRIPTION}</p>;
        }
        if (title === "Total Unit Sales by Corporate Chain") {
          return <p className="text-sm text-ui-text-secondary">{CS_CHANGE_TRACKING_CORPORATE_CHAIN_TABLE_DESCRIPTION}</p>;
        }
      }
      if (
        isContractTypeLegendTable &&
        !(
          showPercentChange &&
          comparisonDataContext &&
          (title === "Total Unit Sales by Material" || title === "Total Unit Sales by Corporate Chain")
        )
      ) {
        if (contractSegmentColoring.names.length > 0) {
          return (
            <div className="flex flex-row flex-wrap gap-x-4 gap-y-2 min-w-0">
              {contractSegmentColoring.names.map(label => (
                <div key={label} className="flex flex-row items-center gap-2 shrink-0">
                  <span
                    className="h-2 w-2 shrink-0 block"
                    style={{
                      backgroundColor: contractSegmentColoring.colorByName[label] ?? FALLBACK_CONTRACT_COLOR,
                    }}
                  />
                  <span className="text-[13px] leading-none" style={{ color: "#525252" }}>
                    {label}
                  </span>
                </div>
              ))}
            </div>
          );
        }
      }
      if (showBars && showPercentChange && comparisonDataContext && isCsSalesComparisonTableTitle(title)) {
        return getCsSalesComparisonTableSubtitle(comparisonDataContext, title);
      }
      if (showBars) {
        if (
          title === "Total Unit Sales by Contract Name" ||
          title === "Total sale Units by Contract Name" ||
          title === "Total Unit Sales by Contract Type"
        )
          return "Total Unit Sales by Contract Type over the last 90 days.";
        if (title === "Total Unit Sales by Sales Group") return "Total Unit Sales by Sales Group over the last 90 days.";
        if (title === "Total Unit Sales by Material") return `${INFO_TOOLTIP_UNIT_SALES_BY_MATERIAL_90D}.`;
        if (title === "Corporate Chain Total Sales" || title === "Total Unit Sales by Corporate Chain")
          return `${INFO_TOOLTIP_UNIT_SALES_BY_CORPORATE_CHAIN_90D}.`;
        return `Total Unit Sales by ${title} over the last 90 days.`;
      }
      if (
        title === "Total Unit Sales by Contract Name" ||
        title === "Total sale Units by Contract Name" ||
        title === "Total Unit Sales by Contract Type"
      )
        return "Total Unit Sales by Contract Type for the past 90 days with hover tooltip showing Contract Type.";
      if (title === "Total Unit Sales by Corporate Chain")
        return "Total Unit Sales by Corporate Chain for the past 90 days with hover tooltip showing Contract Type.";
      return `This table shows ${title.toLowerCase()} with sales volume data.`;
    }, [title, showBars, showPercentChange, comparisonDataContext, isContractTypeLegendTable, contractSegmentColoring]);

    const { sortedData, maxValue, parseSalesValue } = React.useMemo(() => {
      const parseSalesValue = (value: string): number => {
        const numStr = value.replace(/[$,Kk]/g, "");
        const num = parseFloat(numStr);
        return /k/i.test(value) ? num * 1000 : num;
      };

      const sorted = preserveServerRowOrder
        ? [...data]
        : [...data].sort((a, b) => {
            const aValue = parseSalesValue(a.salesCurrentPeriod);
            const bValue = parseSalesValue(b.salesCurrentPeriod);
            return bValue - aValue;
          });

      const max = sorted.length > 0 ? Math.max(...sorted.map(row => parseSalesValue(row.salesCurrentPeriod))) : 0;

      return { sortedData: sorted, maxValue: max, parseSalesValue };
    }, [data, preserveServerRowOrder]);

    const useInfiniteScroll = onScrollEnd != null;
    const hasBarTableServerPagination = !useInfiniteScroll && !showPercentChange && totalCount != null && onPageChange != null;

    const displayedBarTableRows = useInfiniteScroll
      ? sortedData
      : showPercentChange
        ? sortedData
        : hasBarTableServerPagination
          ? sortedData.slice(0, pageSize)
          : sortedData.slice(0, 10);

    const showPaginationFooter =
      !useInfiniteScroll && totalCount != null && onPageChange != null && totalCount > pageSize && (showPercentChange || hasBarTableServerPagination);

    const scrollContainerRef = useRef<HTMLDivElement>(null);

    React.useEffect(() => {
      if (!useInfiniteScroll) return;
      const container = scrollContainerRef.current;
      if (!container) return;
      const handleScroll = () => {
        if (isFetchingMore || !hasMore) return;
        const { scrollTop, scrollHeight, clientHeight } = container;
        if (scrollHeight - scrollTop - clientHeight < 100) {
          onScrollEnd?.();
        }
      };
      container.addEventListener("scroll", handleScroll);

      // Auto-load more when content doesn't overflow the container
      if (!isFetchingMore && hasMore && container.scrollHeight <= container.clientHeight) {
        onScrollEnd?.();
      }

      return () => container.removeEventListener("scroll", handleScroll);
    }, [useInfiniteScroll, isFetchingMore, hasMore, onScrollEnd, data.length]);

    if (sortedData.length === 0 && !loading && !error) {
      return (
        <CardLayout title={title} subtitle="Sales data for current period">
          <EmptyState
            title="No data available"
            description="No data found for the selected filters. Try adjusting your filter criteria to see results."
          />
        </CardLayout>
      );
    }

    if (showBars) {
      const comparisonBarWidthPx = Math.max(112, Math.round(maxBarWidth * CS_PERCENT_CHANGE_BAR_WIDTH_FACTOR));

      return (
        <CardLayout
          title={title}
          subtitle={subtitle}
          icon={
            <InfoIcon
              tooltip={
                title === "Total Unit Sales by Material"
                  ? INFO_TOOLTIP_UNIT_SALES_BY_MATERIAL_90D
                  : title === "Total Unit Sales by Sales Group"
                    ? "Total Unit Sales by Sales Group over the last 90 days."
                    : title === "Total Unit Sales by Contract Name" ||
                        title === "Total sale Units by Contract Name" ||
                        title === "Total Unit Sales by Contract Type"
                      ? "Total Unit Sales by Contract Type over the last 90 days."
                      : title === "Corporate Chain Total Sales" || title === "Total Unit Sales by Corporate Chain"
                        ? INFO_TOOLTIP_UNIT_SALES_BY_CORPORATE_CHAIN_90D
                        : `Total Unit Sales by ${title} over the last 90 days.`
              }
            />
          }
          className="overflow-visible"
        >
          <div ref={useInfiniteScroll ? scrollContainerRef : undefined} className={`w-full overflow-x-auto flex flex-col min-h-[350px] relative ${useInfiniteScroll ? "overflow-y-auto" : "overflow-y-visible"}`} style={{ maxHeight }}>
            {loading && (
              <div className="absolute inset-0 bg-white bg-opacity-75 rounded-lg z-10">
                <table className="w-full text-sm text-left">
                  <thead className="font-bold text-ui-text-primary">
                    <tr>
                      <th className="px-4 py-2">
                        <div className="h-4 bg-gray-200 rounded animate-pulse w-32" />
                      </th>
                      <th className="px-4 py-2">
                        <div className="h-4 bg-gray-200 rounded animate-pulse w-24" />
                      </th>
                      <th className="px-4 py-2">
                        <div className="h-4 bg-gray-200 rounded animate-pulse w-24" />
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {[1, 2, 3, 4, 5].map(row => (
                      <tr key={row} className="border-t">
                        <td className="px-4 py-2">
                          <div className="h-4 bg-gray-200 rounded animate-pulse w-40" />
                        </td>
                        <td className="px-4 py-2">
                          <div className="h-2 bg-gray-200 rounded-full animate-pulse w-[200px]" />
                        </td>
                        <td className="px-4 py-2">
                          <div className="h-4 bg-gray-200 rounded animate-pulse w-20" />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {error && !loading && (
              <div className="absolute inset-0 bg-white flex items-center justify-center text-status-error-main z-20">
                <div className="text-center">
                  <p className="text-sm font-medium">Failed to load data</p>
                  <p className="text-xs text-ui-text-muted mt-1">{error}</p>
                </div>
              </div>
            )}
            {!error && (
              <div className="flex-1 overflow-visible">
                <div
                  className="relative w-full overflow-visible"
                  onMouseMove={handleMouseMove}
                  onMouseLeave={showTooltip ? handleMouseLeave : undefined}
                >
                  <table className="w-full text-sm text-left">
                    <thead className="font-bold text-ui-text-primary">
                      <tr>
                        <th
                          scope="col"
                          id={showPercentChange ? colMaterialHeaderId : undefined}
                          className="px-4 py-2 flex items-center gap-2 whitespace-nowrap"
                        >
                          {materialColumnName}
                        </th>
                        {showPercentChange ? (
                          <>
                            <th scope="col" id={colSalesHeaderId} className="px-4 py-2 whitespace-nowrap">
                              Sales Current Period
                            </th>
                            <th
                              scope="col"
                              id={colComparisonHeaderId}
                              className="min-w-[20rem] py-2 pl-2 pr-4 text-center whitespace-nowrap"
                            >
                              Previous vs Current Period
                            </th>
                          </>
                        ) : (
                          <>
                            <th className="px-4 py-2 whitespace-nowrap">{title === "Total Unit Sales by Material" ? "" : ""}</th>
                            <th className="px-4 py-2 whitespace-nowrap">Sales Volume</th>
                          </>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {(showPercentChange ? sortedData : displayedBarTableRows).map((row, rowIndex) => {
                        const currentValue = parseSalesValue(row.salesCurrentPeriod);
                        const valueRatio = maxValue > 0 ? currentValue / maxValue : 0;
                        /** Track width scales with value so the largest row uses full `maxBarWidth`; smaller rows are shorter. */
                        const MIN_SALES_BAR_TRACK_PX = 4;
                        const trackWidthPx =
                          maxValue > 0 && currentValue > 0
                            ? Math.max(Math.round(maxBarWidth * valueRatio), MIN_SALES_BAR_TRACK_PX)
                            : 0;
                        const pc = row.percentChange ?? 0;
                        const { posHalfPct, negHalfPct } = showPercentChange
                          ? percentChangeBarHalfWidths(pc)
                          : { posHalfPct: 0, negHalfPct: 0 };

                        const materialContractSales = (
                          (
                            contractSalesData?.results as Array<{
                              name: string;
                              contract_sales?: Array<{
                                contract_name: string;
                                total_sales_qty?: number;
                                sales_amount?: number;
                              }>;
                            }>
                          )?.find(item => item.name === row.productName)?.contract_sales || []
                        ).map(c => ({
                          contract_name: c.contract_name,
                          total_sales_qty: c.total_sales_qty ?? (c as { sales_amount?: number }).sales_amount ?? 0,
                        }));

                        const isContractTotalSales =
                          title === "Total Unit Sales by Contract Name" ||
                          title === "Total sale Units by Contract Name" ||
                          title === "Total Unit Sales by Contract Type";
                        const contractData = (
                          contractSalesData?.results as Array<{ name: string; total_sales_qty?: number }>
                        )?.find(item => item.name === row.productName);

                        const rowHeaderId = showPercentChange ? `${rowHeaderIdPrefix}-r${rowIndex}` : "";
                        const pctSpanId = showPercentChange ? `${pctLabelIdPrefix}-r${rowIndex}` : "";

                        const comparisonBarEl = showPercentChange ? (
                          <div
                            className="relative shrink-0 cursor-pointer"
                            style={{ width: `${comparisonBarWidthPx}px` }}
                            aria-hidden
                            onMouseEnter={e => {
                              tooltipPosRef.current = { x: e.clientX, y: e.clientY };
                              setTooltipData({
                                comparisonTooltip: {
                                  rowLabel: row.productName,
                                  metricLabel: comparisonMetricLabel,
                                  currentPeriod: row.salesCurrentPeriod,
                                  previousPeriod: row.salesPreviousPeriod ?? "—",
                                  percentChange: row.percentChange ?? 0,
                                },
                              });
                            }}
                            onMouseMove={handlePercentBarMouseMove}
                            onMouseLeave={() => setTooltipData(null)}
                          >
                            <div
                              className="relative h-3 w-full overflow-hidden rounded-full"
                              style={{ backgroundColor: CS_PERCENT_CHANGE_TRACK_BG }}
                            >
                              {negHalfPct > 0 && (
                                <div
                                  className="pointer-events-none absolute top-0 z-0 h-3 rounded-l-full"
                                  style={{
                                    right: "calc(50% + 2px)",
                                    width: `max(0px, calc(${negHalfPct}% - 2px))`,
                                    backgroundColor: CS_PERCENT_CHANGE_NEGATIVE,
                                  }}
                                />
                              )}
                              {posHalfPct > 0 && (
                                <div
                                  className="pointer-events-none absolute top-0 z-0 h-3 rounded-r-full"
                                  style={{
                                    left: "calc(50% + 2px)",
                                    width: `max(0px, calc(${posHalfPct}% - 2px))`,
                                    backgroundColor: CS_PERCENT_CHANGE_POSITIVE,
                                  }}
                                />
                              )}
                            </div>
                            <div
                              className="pointer-events-none absolute left-1/2 top-1/2 z-10 h-5 w-0.5 -translate-x-1/2 -translate-y-1/2 bg-[#A3A3A3]"
                              aria-hidden
                            />
                          </div>
                        ) : null;

                        return (
                          <tr
                            key={
                              hasBarTableServerPagination
                                ? `o${pageOffset}-i${rowIndex}-${row.productName}`
                                : row.matNbr
                                  ? `${row.productName}-${row.matNbr}`
                                  : `${row.productName}-${rowIndex}`
                            }
                            className="border-t hover:bg-brand-primary-50 cursor-pointer"
                            onMouseEnter={
                              showTooltip
                                ? () => {
                                    if (hideTimeoutRef.current) {
                                      clearTimeout(hideTimeoutRef.current);
                                      hideTimeoutRef.current = null;
                                    }
                                    if (isContractTotalSales && contractData) {
                                      setTooltipData({
                                        contractName: contractData.name,
                                        totalSales: contractData.total_sales_qty?.toLocaleString() ?? "0",
                                      });
                                    } else {
                                      setTooltipData({
                                        materialName: row.productName,
                                        contractSales: materialContractSales,
                                      });
                                    }
                                  }
                                : undefined
                            }
                          >
                            {showPercentChange ? (
                              <th
                                scope="row"
                                id={rowHeaderId}
                                className="px-4 py-2 font-medium text-ui-text-primary text-left align-top"
                              >
                                <div className="flex flex-col">
                                  <span>{row.productName}</span>
                                  {!hideMaterialColumnSubLabel && row.matNbr && (
                                    <span className="text-xs text-ui-text-secondary">{row.matNbr}</span>
                                  )}
                                </div>
                              </th>
                            ) : (
                              <td className="px-4 py-2 font-medium text-ui-text-primary">
                                <div className="flex flex-col">
                                  <span>{row.productName}</span>
                                  {!hideMaterialColumnSubLabel && row.matNbr && (
                                    <span className="text-xs text-ui-text-secondary">{row.matNbr}</span>
                                  )}
                                </div>
                              </td>
                            )}
                            {showPercentChange ? (
                              <>
                                <td className="px-4 py-2 whitespace-nowrap" headers={`${rowHeaderId} ${colSalesHeaderId}`}>
                                  <span className="text-ui-text-primary">
                                    {title === "Total Unit Sales by Material" &&
                                    comparisonMetricLabel.toLowerCase().includes("dollar")
                                      ? withUsdPrefixIfMissing(row.salesCurrentPeriod)
                                      : row.salesCurrentPeriod}
                                  </span>
                                </td>
                                <td
                                  className="min-w-[20rem] py-2 pl-2 pr-4 whitespace-nowrap"
                                  headers={`${rowHeaderId} ${colComparisonHeaderId}`}
                                >
                                  <div
                                    role="group"
                                    aria-labelledby={`${colComparisonHeaderId} ${pctSpanId}`}
                                    className="grid w-full items-center gap-x-3 grid-cols-[minmax(0,1fr)_auto_minmax(0,1.25fr)]"
                                  >
                                    <div className="flex min-w-0 justify-end">
                                      {pc < 0 ? (
                                        <span id={pctSpanId} className="shrink-0 tabular-nums text-ui-text-primary">
                                          {(row.percentChange ?? 0).toFixed(2)}%
                                        </span>
                                      ) : null}
                                    </div>
                                    <div className="flex shrink-0 justify-center">{comparisonBarEl}</div>
                                    <div className="flex min-w-0 justify-start">
                                      {pc >= 0 ? (
                                        <span id={pctSpanId} className="shrink-0 tabular-nums text-ui-text-primary">
                                          {(row.percentChange ?? 0).toFixed(2)}%
                                        </span>
                                      ) : null}
                                    </div>
                                  </div>
                                </td>
                              </>
                            ) : (
                              <>
                                <td className="px-4 py-2 whitespace-nowrap">
                                  <div className="flex items-center gap-3 whitespace-nowrap">
                                    <div
                                      className="relative h-2 flex shrink-0 overflow-hidden rounded-full"
                                      style={{
                                        width: trackWidthPx > 0 ? `${trackWidthPx}px` : 0,
                                        backgroundColor: BAR_REMAINING_COLOR,
                                      }}
                                    >
                                      {isContractTypeLegendTable && materialContractSales.length > 0 ? (
                                        (() => {
                                          const rowTotalQty = parseSalesValue(row.salesCurrentPeriod);
                                          let offset = 0;
                                          return (
                                            <>
                                              {materialContractSales.map((contract, idx) => {
                                                const segmentPct =
                                                  rowTotalQty > 0 ? (contract.total_sales_qty ?? 0) / rowTotalQty : 0;
                                                const segmentWidth = Math.max(segmentPct * 100, 0);
                                                const el = (
                                                  <div
                                                    key={`${contract.contract_name}-${idx}`}
                                                    className="absolute top-0 h-full"
                                                    style={{
                                                      left: `${offset}%`,
                                                      width: `${segmentWidth}%`,
                                                      backgroundColor: getColorForContract(contract.contract_name),
                                                    }}
                                                  />
                                                );
                                                offset += segmentWidth;
                                                return el;
                                              })}
                                            </>
                                          );
                                        })()
                                      ) : title === "Total Unit Sales by Contract Type" ? (
                                        <div className="absolute inset-0 rounded-full bg-brand-primary-700" />
                                      ) : isContractTypeLegendTable ? (
                                        <div
                                          className="absolute inset-0 rounded-full"
                                          style={{ backgroundColor: BAR_REMAINING_COLOR }}
                                        />
                                      ) : (
                                        <div className="absolute inset-0 rounded-full bg-brand-primary-700" />
                                      )}
                                    </div>
                                  </div>
                                </td>
                                <td className="px-4 py-2 whitespace-nowrap">
                                  <span className="text-ui-text-primary whitespace-nowrap">{row.salesCurrentPeriod}</span>
                                </td>
                              </>
                            )}
                          </tr>
                        );
                      })}
                      {sortedData.length === 0 && (
                        <tr>
                          <td
                            colSpan={showPercentChange ? 3 : 3}
                            className="px-4 py-6 text-center text-ui-text-secondary whitespace-nowrap"
                          >
                            No data
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                  {showPaginationFooter && (
                    <div className="flex items-center justify-between px-4 py-2 border-t">
                      <span className="text-sm text-ui-text-secondary">
                        Showing {pageOffset + 1}-{Math.min(pageOffset + pageSize, totalCount)} of {totalCount}
                      </span>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          className="px-3 py-1 text-sm border rounded disabled:opacity-50"
                          disabled={pageOffset === 0}
                          aria-label={`Previous page of ${paginationAriaScope}`}
                          aria-disabled={pageOffset === 0}
                          onClick={() => onPageChange(Math.max(0, pageOffset - pageSize))}
                        >
                          Previous
                        </button>
                        <button
                          type="button"
                          className="px-3 py-1 text-sm border rounded disabled:opacity-50"
                          disabled={pageOffset + pageSize >= totalCount}
                          aria-label={`Next page of ${paginationAriaScope}`}
                          aria-disabled={pageOffset + pageSize >= totalCount}
                          onClick={() => onPageChange(pageOffset + pageSize)}
                          onMouseEnter={() => {
                            if (onPrefetchNextPage && pageOffset + pageSize < totalCount) {
                              onPrefetchNextPage();
                            }
                          }}
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  )}
                  {useInfiniteScroll && isFetchingMore && (
                    <div className="flex items-center justify-center px-4 py-3 border-t">
                      <span className="text-sm text-ui-text-secondary">Loading more…</span>
                    </div>
                  )}
                  {useInfiniteScroll && !hasMore && displayedBarTableRows.length > 0 && totalCount != null && totalCount > 0 && (
                    <div className="flex items-center justify-center px-4 py-2 border-t">
                      <span className="text-xs text-ui-text-muted">Showing all {totalCount} results</span>
                    </div>
                  )}
                  {(showTooltip || showPercentChange) && tooltipData && (
                    <TotalUnitSalesFixedTooltip
                      tooltipData={tooltipData}
                      title={title}
                      tooltipPosRef={tooltipPosRef}
                      tooltipShellRef={tooltipShellRef}
                      applyLayout={applyTooltipLayout}
                    />
                  )}
                </div>
              </div>
            )}
          </div>
        </CardLayout>
      );
    }

    return (
      <CardLayout
        title={title}
        subtitle={subtitle}
        icon={
          <InfoIcon
            tooltip={
              title === "Total Unit Sales by Material"
                ? INFO_TOOLTIP_UNIT_SALES_BY_MATERIAL_90D
                : title === "Total Unit Sales by Contract Name" ||
                    title === "Total sale Units by Contract Name" ||
                    title === "Total Unit Sales by Contract Type"
                  ? "Total Unit Sales by Contract Type for the past 90 days with hover tooltip showing Contract Type."
                  : title === "Corporate Chain Total Sales" || title === "Total Unit Sales by Corporate Chain"
                    ? INFO_TOOLTIP_UNIT_SALES_BY_CORPORATE_CHAIN_90D
                    : `This table shows ${title.toLowerCase()} with sales volume data.`
            }
          />
        }
      >
        <div className="w-full h-full flex flex-col relative min-h-[300px]">
          {loading && (
            <div className="absolute inset-0 bg-white bg-opacity-75 rounded-lg z-10">
              <table className="w-full text-sm text-left">
                <thead className="font-bold text-ui-text-primary">
                  <tr>
                    {columns.map(column => (
                      <th key={column.key} className="px-4 py-2">
                        <div className="h-4 bg-gray-200 rounded animate-pulse w-32" />
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[1, 2, 3, 4, 5].map(row => (
                    <tr key={row} className="border-t">
                      {columns.map(column => (
                        <td key={column.key} className="px-4 py-2">
                          <div className="h-4 bg-gray-200 rounded animate-pulse w-24" />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {error && !loading && (
            <div className="absolute inset-0 bg-white flex items-center justify-center text-status-error-main z-20">
              <div className="text-center">
                <p className="text-sm font-medium">Failed to load data</p>
                <p className="text-xs text-ui-text-muted mt-1">{error}</p>
              </div>
            </div>
          )}
          {!error && (
            <div className="flex-1 overflow-auto">
              <table className="w-full text-sm text-left">
                <thead className="font-bold text-ui-text-primary">
                  <tr>
                    {columns.map((column, index) => (
                      <th key={index} className="px-4 py-2 whitespace-nowrap">
                        {column.label}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.map(row => (
                    <tr
                      key={row.matNbr ? `${row.productName}-${row.matNbr}` : row.productName}
                      className="border-t hover:bg-brand-primary-50 cursor-pointer"
                    >
                      {columns.map(column => (
                        <td key={column.key} className="px-4 py-2 text-ui-text-primary">
                          {row[column.key as keyof ProductSalesData]}
                        </td>
                      ))}
                    </tr>
                  ))}
                  {data.length === 0 && (
                    <tr>
                      <td colSpan={columns.length} className="px-4 py-6 text-center text-ui-text-secondary whitespace-nowrap">
                        No data
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </CardLayout>
    );
  }
);
TotalUnitSalesDataTable.displayName = "TotalUnitSalesDataTable";

export default TotalUnitSalesDataTable;
