import { InfoIcon } from "@/components/atoms";
import { Card, CardContent, CardHeader } from "@/components/atoms/Card";
import { useCorporateChainWithSalesGroupSalesInfiniteQuery } from "@/hooks/queries/useCorporateChainWithSalesGroupSalesQuery";
import { useEffect, useRef, useCallback, useState } from "react";
import { EmptyState } from "@/components/molecules";
import {
  SALES_GROUP_ORDER,
  getSalesGroupColor,
  getSalesGroupLabel,
  type SalesGroupSale,
} from "./salesGroupConfig";

const CARD_TITLE = "Corporate Chain Total Sales";
const CARD_DESCRIPTION = "Total Unit Sales by Corporate Chain over the last 90 days.";
const INFO_TOOLTIP = "Total Unit Sales by Corporate Chain over the last 90 days.";
const SalesGroupTooltip = ({
  groups,
  position,
}: {
  groups: SalesGroupSale[];
  position: { x: number; y: number };
}) => (
  <div
    className="fixed z-50 pointer-events-none bg-white border border-gray-200 text-gray-900 text-xs rounded-md shadow-lg w-[250px] p-3 font-normal"
    style={{
      left: `${position.x}px`,
      top: `${position.y}px`,
      transform: "translate(-50%, calc(-100% - 8px))",
    }}
  >
    <div className="flex flex-col gap-2">
      {groups.map((group, index) => (
        <div key={`${group.sales_group}-${index}`} className="flex items-center gap-2 whitespace-nowrap">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div
              className="w-3 h-3 rounded-sm shrink-0"
              style={{ backgroundColor: getSalesGroupColor(group.sales_group) }}
            />
            <span className="text-gray-600 truncate">{getSalesGroupLabel(group.sales_group)}</span>
          </div>
          <span className="font-medium text-gray-900 tabular-nums shrink-0">{group.total_sales_qty.toLocaleString()}</span>
        </div>
      ))}
    </div>
  </div>
);

const StackedSalesBar = ({
  salesGroupSales,
  totalSales,
}: {
  salesGroupSales: SalesGroupSale[];
  totalSales: number;
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState<{ x: number; y: number } | null>(null);

  if (!salesGroupSales || salesGroupSales.length === 0 || totalSales === 0) {
    return <div className="h-2 bg-gray-100 rounded w-full" />;
  }

  const orderedGroups = SALES_GROUP_ORDER
    .map(config => salesGroupSales.find(s => s.sales_group === config.key))
    .filter((s): s is SalesGroupSale => s != null && s.total_sales_qty > 0);

  const handleMouseEnter = (event: React.MouseEvent<HTMLDivElement>) => {
    setIsHovered(true);
    setTooltipPosition({ x: event.clientX, y: event.clientY });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setTooltipPosition(null);
  };

  const handleMouseMove = (event: React.MouseEvent<HTMLDivElement>) => {
    if (isHovered) {
      setTooltipPosition({ x: event.clientX, y: event.clientY });
    }
  };

  let offset = 0;
  return (
    <>
      <div
        className="h-2 bg-gray-100 rounded w-full relative overflow-hidden"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onMouseMove={handleMouseMove}
      >
        {orderedGroups.map((group, idx) => {
          const segmentPct = totalSales > 0 ? (group.total_sales_qty / totalSales) * 100 : 0;
          const el = (
            <div
              key={`${group.sales_group}-${idx}`}
              className="absolute top-0 h-full"
              style={{
                left: `${offset}%`,
                width: `${segmentPct}%`,
                backgroundColor: getSalesGroupColor(group.sales_group),
              }}
            />
          );
          offset += segmentPct;
          return el;
        })}
      </div>
      {isHovered && tooltipPosition && <SalesGroupTooltip groups={orderedGroups} position={tooltipPosition} />}
    </>
  );
};

const SalesGroupLegend = () => (
  <div className="flex flex-wrap gap-x-4 gap-y-1 px-6 pb-3">
    {SALES_GROUP_ORDER.map(config => (
      <div key={config.key} className="flex items-center gap-1.5">
        <div className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: config.color }} />
        <span className="text-xs text-ui-text-secondary">{config.label}</span>
      </div>
    ))}
  </div>
);

const CorporateChainSkeleton = () => (
  <Card className="flex flex-col">
    <CardHeader className="shrink-0">
      <div className="flex items-center gap-2 mb-2">
        <div className="bg-gray-200 rounded animate-pulse" style={{ width: "300px", height: "28.8px" }} />
        <div className="h-4 w-4 bg-gray-200 rounded-full animate-pulse shrink-0" />
      </div>
      <div className="mb-4">
        <div className="bg-gray-200 rounded animate-pulse h-[20px] w-full max-w-[600px]" />
      </div>
    </CardHeader>
    <CardContent className="flex-1 flex flex-col overflow-hidden px-4 pt-4 pb-4">
      <div className="flex gap-2 mb-4">
        {[1, 2, 3, 4, 5, 6].map(i => (
          <div key={i} className="bg-gray-200 rounded animate-pulse h-4 w-20" />
        ))}
      </div>
      <div className="w-full border rounded-2xl border-[#E2E8F0] overflow-hidden">
        <table className="w-full table-fixed">
          <colgroup>
            <col style={{ width: "25%" }} />
            <col />
            <col style={{ width: "120px" }} />
          </colgroup>
          <thead className="bg-[#F8FAFC] border-b border-[#CBD5E1]">
            <tr>
              <th className="text-left text-sm px-4 py-4"><div className="bg-gray-200 rounded animate-pulse h-5 w-40" /></th>
              <th className="px-4 py-4"><div className="bg-gray-200 rounded animate-pulse h-2 w-full" /></th>
              <th className="text-left text-sm px-4 py-4"><div className="bg-gray-200 rounded animate-pulse h-5 w-20" /></th>
            </tr>
          </thead>
          <tbody>
            {[1, 2, 3, 4, 5].map(item => (
              <tr key={item} className="border-b border-gray-200">
                <td className="text-sm px-4 py-3"><div className="bg-gray-200 rounded animate-pulse h-5 w-48" /></td>
                <td className="text-sm px-4 py-3"><div className="bg-gray-200 rounded animate-pulse h-2 w-full" /></td>
                <td className="text-sm px-4 py-3"><div className="bg-gray-200 rounded animate-pulse h-5 w-16" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </CardContent>
  </Card>
);

export const CorporateChainSales = () => {
  const {
    data,
    isLoading: loading,
    error,
    hasMore,
    isFetchingNextPage,
    fetchNextPage,
    hasEverFetched,
  } = useCorporateChainWithSalesGroupSalesInfiniteQuery();
  const tableContainerRef = useRef<HTMLDivElement>(null);

  const handleScroll = useCallback(() => {
    const container = tableContainerRef.current;
    if (!container) return;

    if (isFetchingNextPage || !hasMore) return;

    const { scrollTop, scrollHeight, clientHeight } = container;
    if (scrollHeight - scrollTop - clientHeight < 100) {
      void fetchNextPage();
    }
  }, [fetchNextPage, hasMore, isFetchingNextPage]);

  useEffect(() => {
    const container = tableContainerRef.current;
    if (!container || data.length === 0) return;
    container.addEventListener("scroll", handleScroll);
    return () => container.removeEventListener("scroll", handleScroll);
  }, [handleScroll, data]);

  const hasData = data.length > 0;

  if ((loading && !hasData) || (!hasEverFetched && !error)) {
    return <CorporateChainSkeleton />;
  }

  if (hasEverFetched && !loading && !error && !hasData) {
    return (
      <Card className="flex flex-col">
        <CardHeader className="shrink-0 pb-2">
          <div className="flex items-center gap-2 mb-2">
            <h2 className="text-xl font-bold text-color-heading">{CARD_TITLE}</h2>
            <InfoIcon tooltip={INFO_TOOLTIP} />
          </div>
          <p className="text-sm text-ui-text-secondary pb-1">{CARD_DESCRIPTION}</p>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col overflow-hidden px-4 pt-4 pb-4">
          <div className="flex-1 flex items-center justify-center py-12">
            <EmptyState
              title="No Data Available"
              description="No corporate chain sales data found for the selected filters. Try adjusting your filter criteria to see results."
            />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="flex flex-col">
      <CardHeader className="shrink-0 pb-2">
        <div className="flex items-center gap-2 mb-2">
          <h2 className="text-xl font-bold text-color-heading">{CARD_TITLE}</h2>
          <InfoIcon tooltip={INFO_TOOLTIP} />
        </div>
        <p className="text-sm text-ui-text-secondary pb-1">{CARD_DESCRIPTION}</p>
      </CardHeader>
      <SalesGroupLegend />
      <CardContent className="flex-1 flex flex-col overflow-hidden">
        {error && !loading && (
          <div className="flex items-center justify-center text-status-error-main mb-3">
            <div className="text-center">
              <p className="text-sm font-medium">Failed to load data</p>
              <p className="text-xs text-ui-text-muted mt-1">{error}</p>
            </div>
          </div>
        )}
        <div
          className="w-full border rounded-2xl border-[#E2E8F0] overflow-hidden flex flex-col"
          style={{ maxHeight: "500px" }}
        >
          <div ref={tableContainerRef} className="overflow-y-auto flex-1">
            <table className="w-full table-fixed">
              <colgroup>
                <col style={{ width: "25%" }} />
                <col />
                <col style={{ width: "120px" }} />
              </colgroup>
              <thead className="bg-[#F8FAFC] border-b border-[#CBD5E1] sticky top-0 z-10">
                <tr>
                  <th className="text-left text-sm px-4 py-4 font-bold rounded-tl-2xl">Corporate Chain Name</th>
                  <th></th>
                  <th className="text-left text-sm px-4 py-4 font-bold">Sales Volume</th>
                </tr>
              </thead>
              <tbody>
                {data.map((item, index) => (
                  <tr key={item.corporate_chain_nbr || index}>
                    <td className="text-sm px-4 py-3 wrap-break-word truncate">{item.name || "-"}</td>
                    <td className="text-sm px-4 py-3">
                      <StackedSalesBar
                        salesGroupSales={item.sales_group_sales || []}
                        totalSales={item.total_sales_qty || 0}
                      />
                    </td>
                    <td className="text-sm px-4 py-3 whitespace-nowrap">{(item.total_sales_qty || 0).toLocaleString()}</td>
                  </tr>
                ))}
                {isFetchingNextPage && (
                  <tr>
                    <td colSpan={3} className="text-center py-4 text-sm text-ui-text-muted">
                      Loading more...
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
