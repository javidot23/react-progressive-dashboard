import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { MapContainer, GeoJSON, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import type { Layer, Path } from "leaflet";
import usStatesData from "@/public/data/us-states.json";
import { useStateSalesData } from "@/stores/useDashboardStore";
import { repositionRemoteStates } from "@/lib/csSalesChangeTrackingConstants";

const STATE_ABBREVIATION_TO_NAME: Record<string, string> = {
  AL: "Alabama",
  AK: "Alaska",
  AZ: "Arizona",
  AR: "Arkansas",
  CA: "California",
  CO: "Colorado",
  CT: "Connecticut",
  DE: "Delaware",
  FL: "Florida",
  GA: "Georgia",
  HI: "Hawaii",
  ID: "Idaho",
  IL: "Illinois",
  IN: "Indiana",
  IA: "Iowa",
  KS: "Kansas",
  KY: "Kentucky",
  LA: "Louisiana",
  ME: "Maine",
  MD: "Maryland",
  MA: "Massachusetts",
  MI: "Michigan",
  MN: "Minnesota",
  MS: "Mississippi",
  MO: "Missouri",
  MT: "Montana",
  NE: "Nebraska",
  NV: "Nevada",
  NH: "New Hampshire",
  NJ: "New Jersey",
  NM: "New Mexico",
  NY: "New York",
  NC: "North Carolina",
  ND: "North Dakota",
  OH: "Ohio",
  OK: "Oklahoma",
  OR: "Oregon",
  PA: "Pennsylvania",
  PR: "Puerto Rico",
  RI: "Rhode Island",
  SC: "South Carolina",
  SD: "South Dakota",
  TN: "Tennessee",
  TX: "Texas",
  UT: "Utah",
  VT: "Vermont",
  VA: "Virginia",
  WA: "Washington",
  WV: "West Virginia",
  WI: "Wisconsin",
  WY: "Wyoming",
  DC: "District of Columbia",
  FM: "Federated States of Micronesia",
};

interface StateSalesData {
  name?: string;
  state?: string;
  total_sales_qty?: number;
  sales_amount?: number;
}

interface GeoJSONFeature {
  properties?: {
    NAME?: string;
    name?: string;
    STATE_NAME?: string;
  };
}

interface MapConfig {
  center: [number, number];
  zoom: number;
  minZoom: number;
  maxZoom: number;
  maxBounds: [[number, number], [number, number]];
}

interface ColorRange {
  light: { r: number; g: number; b: number };
  dark: { r: number; g: number; b: number };
  default: string;
}

const MAP_CONFIG: MapConfig = {
  center: [35, -96],
  zoom: 4,
  minZoom: 2,
  maxZoom: 6,
  maxBounds: [
    [0, -180],
    [72, -40],
  ],
};

const COLOR_RANGE: ColorRange = {
  light: { r: 178, g: 173, b: 239 },
  dark: { r: 70, g: 30, b: 150 },
  default: "#8C7ED7",
};

const MAP_HEIGHT = 440;
const BORDER_COLOR = "#CACACA";
const DEFAULT_BORDER_WEIGHT = 0.8;
const HOVER_BORDER_WEIGHT = 1;
const DEFAULT_FILL_OPACITY = 0.8;
const HOVER_FILL_OPACITY = 0.9;
const EMPTY_STATE_COLOR = "#E8E8E8";

const TOOLTIP_MOVE_THRESHOLD_PX = 2;
const TOOLTIP_OFFSET_X = 12;
const TOOLTIP_GAP_ABOVE_CURSOR = 10;
const TOOLTIP_EDGE_MARGIN = 8;

const getStateNameFromFeature = (feature: GeoJSONFeature): string => {
  return feature?.properties?.name || feature?.properties?.NAME || feature?.properties?.STATE_NAME || "";
};

const calculateBrandColor = (sales: number, minSales: number, maxSales: number): string => {
  if (maxSales === minSales) {
    return COLOR_RANGE.default;
  }

  const normalized = (sales - minSales) / (maxSales - minSales);
  const { light, dark } = COLOR_RANGE;

  const r = Math.round(light.r + (dark.r - light.r) * normalized);
  const g = Math.round(light.g + (dark.g - light.g) * normalized);
  const b = Math.round(light.b + (dark.b - light.b) * normalized);

  return `rgb(${r}, ${g}, ${b})`;
};

const MapSkeleton = React.memo(() => (
  <div className="w-full h-full min-h-110 relative bg-white rounded-[10px] border border-[#E2E8F0]">
    <div className="absolute inset-0 bg-gray-200 rounded-lg animate-pulse" />
  </div>
));
MapSkeleton.displayName = "MapSkeleton";

const MapZoomControls = React.memo(() => {
  const map = useMap();
  return (
    <div className="absolute bottom-3 right-3 z-400 flex flex-col overflow-hidden rounded-md border border-[#CBD5E1] bg-white shadow-md">
      <button
        type="button"
        className="flex h-9 w-9 items-center justify-center text-lg font-semibold text-ui-text-primary hover:bg-gray-50"
        aria-label="Zoom in"
        onClick={() => map.zoomIn()}
      >
        +
      </button>
      <button
        type="button"
        className="flex h-9 w-9 items-center justify-center border-t border-[#CBD5E1] text-lg font-semibold text-ui-text-primary hover:bg-gray-50"
        aria-label="Zoom out"
        onClick={() => map.zoomOut()}
      >
        −
      </button>
    </div>
  );
});
MapZoomControls.displayName = "MapZoomControls";

const MapErrorState = React.memo<{ error: string }>(({ error }) => (
  <div
    className="w-full h-full flex items-center justify-center min-h-110 text-status-error-main bg-white rounded-lg border border-ui-border-primary"
    role="alert"
    aria-live="polite"
  >
    <div className="text-center">
      <p className="text-sm font-medium">Failed to load map data</p>
      <p className="text-xs text-ui-text-muted mt-1">{error}</p>
    </div>
  </div>
));
MapErrorState.displayName = "MapErrorState";

interface MapTooltipState {
  visible: boolean;
  stateName: string;
  sales: number;
  x: number;
  y: number;
}

export const WorldMap = React.memo(() => {
  const { stateSalesData, loading, error } = useStateSalesData();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const salesLookupRef = useRef<Record<string, number>>({});
  const tooltipRafRef = useRef<number | null>(null);
  const lastCommittedTooltipRef = useRef<Omit<MapTooltipState, "visible"> | null>(null);

  const [tooltip, setTooltip] = useState<MapTooltipState>({
    visible: false,
    stateName: "",
    sales: 0,
    x: 0,
    y: 0,
  });
  const [tooltipViewport, setTooltipViewport] = useState<{ left: number; top: number } | null>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);

  const { salesLookup, minSales, maxSales } = useMemo(() => {
    if (!stateSalesData || stateSalesData.length === 0) {
      return { salesLookup: {}, minSales: 0, maxSales: 0 };
    }

    const lookup: Record<string, number> = {};
    const salesValues: number[] = [];

    stateSalesData.forEach(state => {
      const stateData = state as StateSalesData;
      const stateAbbr = stateData.name || stateData.state || "";
      const salesQty = stateData.total_sales_qty || stateData.sales_amount || 0;
      const fullStateName = STATE_ABBREVIATION_TO_NAME[stateAbbr];
      if (fullStateName) {
        lookup[fullStateName] = salesQty;
        salesValues.push(salesQty);
      }
    });

    return {
      salesLookup: lookup,
      minSales: salesValues.length > 0 ? Math.min(...salesValues) : 0,
      maxSales: salesValues.length > 0 ? Math.max(...salesValues) : 0,
    };
  }, [stateSalesData]);

  useEffect(() => {
    salesLookupRef.current = salesLookup;
  }, [salesLookup]);

  useEffect(() => {
    return () => {
      if (tooltipRafRef.current != null) {
        cancelAnimationFrame(tooltipRafRef.current);
        tooltipRafRef.current = null;
      }
    };
  }, []);

  useLayoutEffect(() => {
    if (!tooltip.visible) {
      setTooltipViewport(null);
      return;
    }
    const container = mapContainerRef.current;
    const el = tooltipRef.current;
    if (!container || !el) {
      return;
    }

    const cw = container.clientWidth;
    const ch = container.clientHeight;
    const w = el.offsetWidth;
    const h = el.offsetHeight;
    if (w === 0 || h === 0) {
      return;
    }

    const m = TOOLTIP_EDGE_MARGIN;
    let left = tooltip.x + TOOLTIP_OFFSET_X;
    let top = tooltip.y - TOOLTIP_GAP_ABOVE_CURSOR;

    const maxLeft = Math.max(m, cw - w - m);
    left = Math.min(Math.max(left, m), maxLeft);

    const minTop = m + h;
    const maxTop = ch - m;
    top = Math.min(Math.max(top, minTop), maxTop);

    setTooltipViewport(prev => (prev && prev.left === left && prev.top === top ? prev : { left, top }));
  }, [tooltip.visible, tooltip.x, tooltip.y, tooltip.stateName, tooltip.sales]);

  const geoJsonStyle = useCallback(
    (feature?: GeoJSONFeature) => {
      if (!feature) {
        return {
          fillColor: EMPTY_STATE_COLOR,
          weight: DEFAULT_BORDER_WEIGHT,
          opacity: 1,
          color: BORDER_COLOR,
          fillOpacity: DEFAULT_FILL_OPACITY,
        };
      }
      const stateName = getStateNameFromFeature(feature);
      const sales = salesLookup[stateName];

      if (sales === undefined || sales === 0) {
        return {
          fillColor: EMPTY_STATE_COLOR,
          weight: DEFAULT_BORDER_WEIGHT,
          opacity: 1,
          color: BORDER_COLOR,
          fillOpacity: DEFAULT_FILL_OPACITY,
        };
      }

      const color = calculateBrandColor(sales, minSales, maxSales);

      return {
        fillColor: color,
        weight: DEFAULT_BORDER_WEIGHT,
        opacity: 1,
        color: BORDER_COLOR,
        fillOpacity: DEFAULT_FILL_OPACITY,
      };
    },
    [salesLookup, minSales, maxSales]
  );

  const scheduleTooltipUpdate = useCallback((payload: Omit<MapTooltipState, "visible">) => {
    const last = lastCommittedTooltipRef.current;
    if (last) {
      const positionClose =
        Math.abs(payload.x - last.x) < TOOLTIP_MOVE_THRESHOLD_PX &&
        Math.abs(payload.y - last.y) < TOOLTIP_MOVE_THRESHOLD_PX;
      const dataSame = last.stateName === payload.stateName && last.sales === payload.sales;
      if (dataSame && positionClose) {
        return;
      }
    }

    if (tooltipRafRef.current != null) {
      cancelAnimationFrame(tooltipRafRef.current);
    }

    tooltipRafRef.current = requestAnimationFrame(() => {
      tooltipRafRef.current = null;
      lastCommittedTooltipRef.current = { ...payload };
      setTooltip({
        visible: true,
        stateName: payload.stateName,
        sales: payload.sales,
        x: payload.x,
        y: payload.y,
      });
    });
  }, []);

  const onEachFeature = useCallback((feature: GeoJSONFeature, layer: Layer) => {
    const stateName = feature?.properties?.name || feature?.properties?.NAME || feature?.properties?.STATE_NAME || "";

    if (!stateName) {
      return;
    }

    const pathLayer = layer as Path;

    pathLayer.on({
      mouseover(e) {
        const target = e.target as Path;
        target.setStyle({
          weight: HOVER_BORDER_WEIGHT,
          fillOpacity: HOVER_FILL_OPACITY,
        });
        if (target.bringToFront) {
          target.bringToFront();
        }
      },
      mousemove(e) {
        if (!mapContainerRef.current) {
          return;
        }
        const rect = mapContainerRef.current.getBoundingClientRect();
        const x = e.originalEvent.clientX - rect.left;
        const y = e.originalEvent.clientY - rect.top;
        const currentSales = salesLookupRef.current[stateName] ?? 0;
        scheduleTooltipUpdate({ stateName, sales: currentSales, x, y });
      },
      mouseout(e) {
        if (tooltipRafRef.current != null) {
          cancelAnimationFrame(tooltipRafRef.current);
          tooltipRafRef.current = null;
        }
        lastCommittedTooltipRef.current = null;
        const target = e.target as Path;
        target.setStyle({
          weight: DEFAULT_BORDER_WEIGHT,
          fillOpacity: DEFAULT_FILL_OPACITY,
        });
        setTooltip(prev => ({ ...prev, visible: false }));
      },
    });
  }, [scheduleTooltipUpdate]);

  const transformedGeoJsonData = useMemo(() => repositionRemoteStates(usStatesData), []);

  if (loading) {
    return <MapSkeleton />;
  }

  if (error) {
    return <MapErrorState error={error} />;
  }

  if (!stateSalesData || stateSalesData.length === 0) {
    return null;
  }

  return (
    <div ref={mapContainerRef} className="relative" style={{ height: `${MAP_HEIGHT}px` }}>
      <MapContainer
        style={{ background: "#ffffff", height: "100%", width: "100%" }}
        center={MAP_CONFIG.center}
        zoom={MAP_CONFIG.zoom}
        minZoom={MAP_CONFIG.minZoom}
        maxZoom={MAP_CONFIG.maxZoom}
        zoomControl={false}
        attributionControl={false}
        scrollWheelZoom={true}
        doubleClickZoom={true}
        dragging={true}
        touchZoom={true}
        maxBounds={MAP_CONFIG.maxBounds}
      >
        <GeoJSON data={transformedGeoJsonData as any} style={geoJsonStyle} onEachFeature={onEachFeature} />
        <MapZoomControls />
      </MapContainer>

      {tooltip.visible && (
        <div
          ref={tooltipRef}
          className="absolute pointer-events-none z-1000"
          style={{
            left: tooltipViewport?.left ?? tooltip.x + TOOLTIP_OFFSET_X,
            top: tooltipViewport?.top ?? tooltip.y - TOOLTIP_GAP_ABOVE_CURSOR,
            transform: "translateY(-100%)",
          }}
        >
          <div className="bg-white rounded-md border border-gray-200 shadow-xs text-xs p-3">
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center gap-4">
                <span className="text-gray-600">State:</span>
                <span className="text-gray-900 font-medium">{tooltip.stateName}</span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-gray-600">Sales Units:</span>
                <span className="text-gray-900 font-medium">{tooltip.sales.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
});
WorldMap.displayName = "WorldMap";
