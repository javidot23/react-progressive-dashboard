import { memo, useCallback, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ResponsiveContainer,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  Cell,
  ReferenceArea,
} from "recharts";
import InfoIcon from "@/components/atoms/InfoIcon";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/atoms/Card";
import Legend from "@/components/atoms/Legend";
import type { CSalesFilters } from "@/hooks/manage/sales/cs-sales-query-keys";
import { salesTimelineQueryOptions } from "@/hooks/manage/sales";
import {
  getCsSalesAnalysisCardSubtitle,
  getCsSalesAnalysisCardTooltip,
  getCsSalesPercentChangeChartLabels,
} from "@/lib/csSalesCopy";
import { isSalesTimelineWeeklyItem } from "@/lib/apiServices";
import { formatMonthYearChartLabel, formatWeekLabel } from "@/lib/csSalesChangeTrackingConstants";
import {
  computeSalesTimelineHighlightAxisRanges,
  type SalesTimelineHighlightAxisRanges,
} from "@/lib/csSalesTimelineHighlight";
import { parseCsSalesMetric } from "@/lib/csSalesValueParse";
import { formatUsCompactCount, formatUsCurrency, formatUsInteger } from "@/lib/usFormat";

const CS_SALES_CHART_MARGIN = { top: 20, right: 10, left: 0, bottom: 30 };
const CS_ANALYSIS_CHART_MIN_HEIGHT_PX = 192;
const CS_AXIS_TICK = { fill: "var(--color-ui-text-muted)", fontSize: 10 };
const CS_Y_AXIS_LABEL_STYLE = {
  textAnchor: "middle" as const,
  fontSize: "12px",
  fill: "var(--color-ui-text-muted)",
};

const formatDollarAxis = (value: number) => {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(0)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(0)}K`;
  return value.toString();
};

const CP_HIGHLIGHT_FILL = "#6C9FE8";
const PP_HIGHLIGHT_FILL = "#E8A86C";

const HIGHLIGHT_AREA_BASE = { fillOpacity: 0.18, strokeOpacity: 0 } as const;

const TimelineHighlightBands = memo(function TimelineHighlightBands({
  ranges,
  yDomain,
}: {
  ranges: SalesTimelineHighlightAxisRanges;
  yDomain: [number, number];
}) {
  const [y0, y1] = yDomain;
  return (
    <>
      {ranges.ppStartLabel && ranges.ppEndLabel ? (
        <ReferenceArea
          x1={ranges.ppStartLabel}
          x2={ranges.ppEndLabel}
          y1={y0}
          y2={y1}
          fill={PP_HIGHLIGHT_FILL}
          {...HIGHLIGHT_AREA_BASE}
          label={{ value: "PP", position: "insideTopLeft", fontSize: 10, fill: "#B07840" }}
        />
      ) : null}
      {ranges.cpStartLabel && ranges.cpEndLabel ? (
        <ReferenceArea
          x1={ranges.cpStartLabel}
          x2={ranges.cpEndLabel}
          y1={y0}
          y2={y1}
          fill={CP_HIGHLIGHT_FILL}
          {...HIGHLIGHT_AREA_BASE}
          label={{ value: "CP", position: "insideTopLeft", fontSize: 10, fill: "#4070B0" }}
        />
      ) : null}
    </>
  );
});

interface TimelineTooltipPayload {
  periodLabel: string;
  value: number;
}

const SalesTimelineTooltip = memo(function SalesTimelineTooltip({
  active,
  payload,
  isDollars,
}: {
  active?: boolean;
  payload?: ReadonlyArray<{ payload?: TimelineTooltipPayload }>;
  isDollars: boolean;
}) {
  if (active && payload?.[0]) {
    const p = payload[0].payload;
    if (!p) return null;
    return (
      <div className="bg-white border border-gray-200 text-gray-900 text-xs rounded-md shadow-lg w-[250px] p-3 font-normal z-30">
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">Period:</span>
            <span className="text-gray-900 font-medium">{p.periodLabel}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">{isDollars ? "Sales:" : "Order Qty:"}</span>
            <span className="text-gray-900 font-medium">
              {isDollars ? formatUsCurrency(p.value) : formatUsInteger(p.value)}
            </span>
          </div>
        </div>
      </div>
    );
  }
  return null;
});

interface PercentageChangeTooltipPayload {
  periodLabel: string;
  priorPeriodValue: number;
  currentPeriodValue: number;
  percentageChange: number;
}

const PercentageChangeTooltip = memo(function PercentageChangeTooltip({
  active,
  payload,
  activeTab,
  isDollars,
}: {
  active?: boolean;
  payload?: ReadonlyArray<{ payload?: PercentageChangeTooltipPayload }>;
  activeTab: "historical" | "current";
  isDollars: boolean;
}) {
  const labels = getCsSalesPercentChangeChartLabels(activeTab);
  if (active && payload && payload.length && payload[0].payload) {
    const data = payload[0].payload;
    const percentageChange = data.percentageChange || 0;
    const formatVal = (v: number) => (isDollars ? formatUsCurrency(v) : formatUsInteger(v));

    return (
      <div className="bg-white border border-gray-200 text-gray-900 text-xs rounded-md shadow-lg w-[250px] p-3 font-normal z-30">
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">{labels.periodAxis}:</span>
            <span className="text-gray-900 font-medium">{data.periodLabel}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">{labels.priorValue}:</span>
            <span className="text-gray-900 font-medium">{formatVal(data.priorPeriodValue)}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">{labels.currentValue}:</span>
            <span className="text-gray-900 font-medium">{formatVal(data.currentPeriodValue)}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">{labels.chartPercentChangeLabel}:</span>
            <span className="text-gray-900 font-medium">
              {data.currentPeriodValue === 0 ? "N/A (no current period data)" : `${percentageChange.toFixed(2)}%`}
            </span>
          </div>
        </div>
      </div>
    );
  }
  return null;
});

export const DollarSalesChangeTrackingCard = memo(function DollarSalesChangeTrackingCard({
  filtersVersion,
  activeTab,
  filters,
  queryEnabled = true,
}: {
  filtersVersion: number;
  activeTab: "historical" | "current";
  filters?: CSalesFilters;
  queryEnabled?: boolean;
}) {
  const {
    data: timelineRes,
    isPending: loading,
    error,
  } = useQuery(salesTimelineQueryOptions(filtersVersion, activeTab, filters, queryEnabled));
  const timelineData = useMemo(() => timelineRes?.data ?? [], [timelineRes?.data]);
  const isDollars = filters?.measure !== "Quantity";

  const timelineChartData = useMemo(() => {
    return timelineData.map(item => {
      const salesAmount = parseCsSalesMetric(item.sales_amount);
      const orderQty = parseCsSalesMetric(item.total_order_qty);
      const value = isDollars ? salesAmount : orderQty;
      const periodLabel = isSalesTimelineWeeklyItem(item)
        ? formatWeekLabel(item.week_start)
        : formatMonthYearChartLabel(item.year, item.month);
      return {
        periodLabel,
        value,
        sales_amount: salesAmount,
        total_order_qty: orderQty,
      };
    });
  }, [timelineData, isDollars]);

  const highlightRanges = useMemo(() => {
    const period = filters?.period ?? (activeTab === "historical" ? "Last 12 months" : "Month to date");
    return computeSalesTimelineHighlightAxisRanges(activeTab, period, timelineData);
  }, [activeTab, filters?.period, timelineData]);

  const percentChangeLabels = getCsSalesPercentChangeChartLabels(activeTab);

  const percentageChangeData = useMemo(() => {
    if (timelineChartData.length === 0) return [];
    return timelineChartData.map((item, i) => {
      const prev = i > 0 ? timelineChartData[i - 1].value : item.value;
      let percentageChange = 0;
      if (prev > 0) {
        percentageChange = ((item.value - prev) / prev) * 100;
      } else if (item.value > 0) {
        percentageChange = 100;
      }
      return {
        sales: Math.round(percentageChange * 100) / 100,
        periodLabel: item.periodLabel,
        priorPeriodValue: i > 0 ? timelineChartData[i - 1].value : 0,
        currentPeriodValue: item.value,
        percentageChange,
      };
    });
  }, [timelineChartData]);

  const timelineValueYDomain = useMemo((): [number, number] => {
    if (!timelineChartData.length) return [0, 1];
    let min = timelineChartData[0].value;
    let max = timelineChartData[0].value;
    for (const row of timelineChartData) {
      if (row.value < min) min = row.value;
      if (row.value > max) max = row.value;
    }
    const span = Math.max(max - min, Math.abs(max), Math.abs(min), 1);
    const pad = span * 0.08;
    const round2 = (n: number) => Math.round(n * 100) / 100;
    return [round2(min - pad), round2(max + pad)];
  }, [timelineChartData]);

  const percentageChangeYDomain = useMemo((): [number, number] => {
    if (!percentageChangeData.length) return [0, 100];
    let min = 0;
    let max = 0;
    for (const row of percentageChangeData) {
      if (row.sales < min) min = row.sales;
      if (row.sales > max) max = row.sales;
    }
    const span = Math.max(Math.abs(min), Math.abs(max), 1);
    const pad = span * 0.08;
    const round2 = (n: number) => Math.round(n * 100) / 100;
    return [round2(min - pad), round2(max + pad)];
  }, [percentageChangeData]);

  const renderTimelineTooltip = useCallback(
    (props: { active?: boolean; payload?: ReadonlyArray<{ payload?: TimelineTooltipPayload }> }) => (
      <SalesTimelineTooltip active={props.active} payload={props.payload} isDollars={isDollars} />
    ),
    [isDollars]
  );

  const renderPercentChangeTooltip = useCallback(
    (props: { active?: boolean; payload?: ReadonlyArray<{ payload?: PercentageChangeTooltipPayload }> }) => (
      <PercentageChangeTooltip active={props.active} payload={props.payload} activeTab={activeTab} isDollars={isDollars} />
    ),
    [activeTab, isDollars]
  );

  const chartLegendItems = useMemo(
    () => [
      { id: 1, label: isDollars ? "Sales ($)" : "Order Qty", color: "#461E96", shape: "square" as const },
      { id: 2, label: "% change (-)", color: "#E22F00", shape: "square" as const },
      { id: 3, label: "% change (+)", color: "#027F50", shape: "square" as const },
      { id: 4, label: "CP (Current Period)", color: CP_HIGHLIGHT_FILL, shape: "square" as const },
      { id: 5, label: "PP (Previous Period)", color: PP_HIGHLIGHT_FILL, shape: "square" as const },
    ],
    [isDollars]
  );

  return (
    <Card className="flex h-full w-full flex-col overflow-hidden min-h-[clamp(22rem,85dvh,35rem)]">
      <CardHeader className="shrink-0">
        <div className="flex items-center gap-2">
          <CardTitle className="text-xl font-bold leading-tight text-color-heading font-brand">
            Sales Change Analysis
          </CardTitle>
          <InfoIcon tooltip={getCsSalesAnalysisCardTooltip(activeTab)} />
        </div>
        <p className="text-sm text-ui-text-secondary mb-4">{getCsSalesAnalysisCardSubtitle(activeTab)}</p>
        <Legend items={chartLegendItems} orientation="horizontal" spacing="md" />
      </CardHeader>
      <CardContent className="relative flex flex-1 flex-col min-h-0 min-w-0 overflow-hidden p-4 pt-0 pb-0">
        {error && !loading && (
          <div className="absolute inset-0 flex items-center justify-center text-status-error-main z-10 bg-ui-background-primary/90">
            <div className="text-center">
              <p className="text-sm font-medium">Failed to load chart data</p>
              <p className="text-xs text-ui-text-muted mt-1">{error.message}</p>
            </div>
          </div>
        )}
        {loading && !error && (
          <div className="absolute inset-0 z-10 flex items-center justify-center rounded-md bg-white/80">
            <div className="h-64 w-full max-w-2xl mx-4 bg-gray-200 rounded animate-pulse" />
          </div>
        )}
        <div className="relative flex min-h-48 flex-1 basis-0 flex-col w-full">
          {!loading && !error && (
            <ResponsiveContainer width="100%" height="100%" minHeight={CS_ANALYSIS_CHART_MIN_HEIGHT_PX}>
              <BarChart data={timelineChartData} margin={CS_SALES_CHART_MARGIN}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="var(--color-ui-border-primary)" opacity={0.6} />
                <XAxis
                  dataKey="periodLabel"
                  axisLine={false}
                  tickLine={false}
                  interval={0}
                  tick={CS_AXIS_TICK}
                  angle={-70}
                  dx={-8}
                  dy={20}
                />
                <YAxis
                  domain={timelineValueYDomain}
                  axisLine={false}
                  tickLine={false}
                  tick={CS_AXIS_TICK}
                  tickFormatter={isDollars ? formatDollarAxis : formatUsCompactCount}
                  label={{
                    value: isDollars ? "Dollars" : "Quantity",
                    angle: -90,
                    position: "insideLeft",
                    style: CS_Y_AXIS_LABEL_STYLE,
                  }}
                />
                <TimelineHighlightBands ranges={highlightRanges} yDomain={timelineValueYDomain} />
                <Tooltip content={renderTimelineTooltip} cursor={{ fill: "rgba(59, 41, 112, 0.1)" }} />
                <Bar dataKey="value" fill="#461E96" radius={[2, 2, 2, 2]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="relative flex min-h-48 flex-1 basis-0 flex-col w-full">
          {!loading && !error && (
            <ResponsiveContainer width="100%" height="100%" minHeight={CS_ANALYSIS_CHART_MIN_HEIGHT_PX}>
              <BarChart data={percentageChangeData} margin={CS_SALES_CHART_MARGIN}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="var(--color-ui-border-primary)" opacity={0.6} />
                <XAxis
                  dataKey="periodLabel"
                  axisLine={false}
                  tickLine={false}
                  interval={0}
                  tick={CS_AXIS_TICK}
                  angle={-70}
                  dx={-8}
                  dy={20}
                />
                <YAxis
                  domain={percentageChangeYDomain}
                  axisLine={false}
                  tickLine={false}
                  tick={CS_AXIS_TICK}
                  tickFormatter={(value: number) => `${value}%`}
                  label={{
                    value: percentChangeLabels.yAxisLabel,
                    angle: -90,
                    position: "insideLeft",
                    style: CS_Y_AXIS_LABEL_STYLE,
                  }}
                />
                <Tooltip content={renderPercentChangeTooltip} cursor={{ fill: "rgba(59, 41, 112, 0.1)" }} />
                <Bar dataKey="sales" radius={[2, 2, 2, 2]} maxBarSize={20}>
                  {percentageChangeData.map((entry, index: number) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.currentPeriodValue === 0 ? "#9CA3AF" : entry.sales >= 0 ? "#027F50" : "#E22F00"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </CardContent>
    </Card>
  );
});
