import { InfoIcon } from "@/components/atoms";
import { Card, CardContent, CardHeader } from "@/components/atoms/Card";
import { useContractSalesData } from "@/stores/useDashboardStore";
import { useEffect, useMemo, useRef, useCallback } from "react";
import { EmptyState } from "@/components/molecules";

const CARD_MIN_HEIGHT = "560px";
const CARD_TITLE = "Total Unit Sales by Contract Type";
const CARD_DESCRIPTION = "Total Unit Sales by Contract Type over the last 90 days.";
const INFO_TOOLTIP = "Total Unit Sales by Contract Type over the last 90 days.";

interface ContractSalesItem {
  name: string;
  total_sales_qty: number;
}

const SalesByContractSkeleton = () => (
  <Card className="flex flex-col h-full" style={{ minHeight: CARD_MIN_HEIGHT }}>
    <CardHeader className="shrink-0">
      <div className="flex items-center gap-2 mb-2">
        <div
          className="bg-gray-200 rounded animate-pulse"
          style={{
            width: "280px",
            height: "28.8px",
          }}
        />
        <div className="h-4 w-4 bg-gray-200 rounded-full animate-pulse shrink-0" />
      </div>
      <div className="mb-4">
        <div className="bg-gray-200 rounded animate-pulse h-[20px] w-full max-w-[600px]" />
      </div>
    </CardHeader>
    <CardContent className="flex-1 flex flex-col overflow-hidden px-4 pt-4 pb-0">
      <div className="w-full flex-1 overflow-hidden flex flex-col" style={{ maxHeight: "400px" }}>
        <div className="w-full overflow-x-auto overflow-y-auto flex-1">
          <table className="w-full min-w-[500px] border-collapse">
            <thead className="sticky top-0 bg-white z-10">
              <tr className="border-b border-gray-300">
                <th className="text-left text-sm px-4 py-4">
                  <div className="bg-gray-200 rounded animate-pulse h-5 w-32" />
                </th>
                <th className="text-left text-sm px-4 py-4">
                  <div className="bg-gray-200 rounded animate-pulse h-5 w-28" />
                </th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5].map(item => (
                <tr key={item} className="border-b border-gray-200">
                  <td className="text-sm px-4 py-3">
                    <div className="bg-gray-200 rounded animate-pulse h-5 w-40" />
                  </td>
                  <td className="text-sm px-4 py-3">
                    <div className="bg-gray-200 rounded animate-pulse h-5 w-12" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </CardContent>
  </Card>
);

const SalesByContractHeader = () => (
  <CardHeader className="shrink-0 pb-4">
    <div className="flex items-center gap-2 mb-2">
      <h2 className="text-xl font-bold text-color-heading">{CARD_TITLE}</h2>
      <InfoIcon tooltip={INFO_TOOLTIP} />
    </div>
    <p className="text-sm text-ui-text-secondary pb-3">{CARD_DESCRIPTION}</p>
  </CardHeader>
);

export const SalesByContract = () => {
  const { contractSalesData, loading, error, fetchMoreContractSalesData, pagination, lastFetched } = useContractSalesData(20);
  const tableContainerRef = useRef<HTMLDivElement>(null);

  // Infinite scroll handler
  const handleScroll = useCallback(() => {
    const container = tableContainerRef.current;
    if (!container || pagination.isLoadingMore || !pagination.hasMore) {
      return;
    }

    const { scrollTop, scrollHeight, clientHeight } = container;
    // Load more when user is within 100px of the bottom
    if (scrollHeight - scrollTop - clientHeight < 100) {
      fetchMoreContractSalesData();
    }
  }, [pagination.isLoadingMore, pagination.hasMore, fetchMoreContractSalesData]);

  useEffect(() => {
    const container = tableContainerRef.current;
    if (!container) return;

    container.addEventListener("scroll", handleScroll);
    return () => {
      container.removeEventListener("scroll", handleScroll);
    };
  }, [handleScroll]);

  const data = useMemo(() => {
    if (!contractSalesData?.data?.results) return [];
    return contractSalesData.data.results as ContractSalesItem[];
  }, [contractSalesData]);

  const hasData = contractSalesData && data.length > 0;
  const hasEverFetched = lastFetched != null;

  if ((loading && !hasData) || (!hasEverFetched && !error)) {
    return (
      <div className="relative h-full">
        <SalesByContractSkeleton />
      </div>
    );
  }

  if (hasEverFetched && !loading && !error && !hasData) {
    return (
      <Card className="flex flex-col" style={{ minHeight: CARD_MIN_HEIGHT }}>
        <SalesByContractHeader />
        <CardContent className="flex-1 flex flex-col overflow-hidden px-4 pt-4 pb-0">
          <div className="flex-1 flex items-center justify-center">
            <EmptyState
              title="No Data Available"
              description="No contract sales data found for the selected filters. Try adjusting your filter criteria to see results."
            />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="flex flex-col">
      <SalesByContractHeader />
      <CardContent className="flex-1 flex flex-col overflow-hidden">
        <div className="flex flex-col gap-3">
          {error && !loading && (
            <div className="absolute inset-0 flex items-center justify-center text-status-error-main z-10">
              <div className="text-center">
                <p className="text-sm font-medium">Failed to load data</p>
                <p className="text-xs text-ui-text-muted mt-1">{error}</p>
              </div>
            </div>
          )}
          <div
            className="w-full border rounded-2xl border-[#E2E8F0] overflow-hidden flex flex-col"
            style={{ maxHeight: "400px" }}
          >
            <div ref={tableContainerRef} className="overflow-y-auto flex-1">
              <table className="w-full">
                <thead className="bg-[#F8FAFC] border-b border-[#CBD5E1] sticky top-0 z-10">
                  <tr>
                    <th className="text-left text-sm px-4 py-4 font-bold rounded-tl-2xl">
                      <div className="flex items-center gap-4">
                        <span>Contract Name</span>
                      </div>
                    </th>
                    <th className="text-left text-sm px-4 py-4 font-bold">Sales Volume</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map(item => (
                    <tr key={item.name}>
                      <td className="text-sm px-4 py-3 wrap-break-word">{item.name}</td>
                      <td className="text-sm px-4 py-3">{(item.total_sales_qty || 0).toLocaleString()}</td>
                    </tr>
                  ))}
                  {pagination.isLoadingMore && (
                    <tr>
                      <td colSpan={2} className="text-center py-4 text-sm text-ui-text-muted">
                        Loading more...
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
