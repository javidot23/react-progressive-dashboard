import { useMemo, useState, useCallback, useEffect } from "react";
import CardLayout from "@/components/templates/CardLayout";
import { InfoIcon, SkeletonTable } from "@/components/atoms";
import Legend from "@/components/atoms/Legend";
import DCMissedLinesTable, { LEGEND_ITEMS, type DCRow } from "./DCMissedLinesTable";
import FtsPlantsSortBar from "./FtsPlantsSortBar";
// uncomment when testing
// import FtsPlantsRangeFilters from "./FtsPlantsRangeFilters";
import { useQuery } from "@tanstack/react-query";
import { failToSupplyService, type FtsPlantsParams } from "@/lib/apiServices";
import { useGlobalFiltersListener, useGlobalFiltersVersion } from "@/hooks/useGlobalFiltersListener";
import { computeOrderedLinesServiceMetrics } from "@/lib/orderedLinesServiceLevel";
import {
  EMPTY_FTS_PLANTS_RANGE_DRAFT,
  mergeFtsPlantsRangeParams,
  type FtsPlantsRangeFieldKey,
} from "@/utils/ftsMitigation";

const DEFAULT_PAGE = 1;
const DEFAULT_PAGE_SIZE = 10;
const MAX_PLANTS_PAGE_SIZE = 50;

const DC_TOOLTIP =
  "Displays distribution center missed lines and omit quantities. Use sorting and numeric filters to narrow results. Refer to the legend for service level and quantity metrics.";

interface DCMissedLinesCardProps {
  matNbr: string | null;
  fromDate: string;
  toDate: string;
}

export default function DCMissedLinesCard({ matNbr, fromDate, toDate }: DCMissedLinesCardProps) {
  const filtersVersion = useGlobalFiltersVersion();
  const [currentPage, setCurrentPage] = useState(DEFAULT_PAGE);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [ordering, setOrdering] = useState("-total_missed_lines");
  const [appliedRanges, setAppliedRanges] = useState<Record<FtsPlantsRangeFieldKey, string>>(() => ({
    ...EMPTY_FTS_PLANTS_RANGE_DRAFT,
  }));

  const offset = useMemo(() => (currentPage - 1) * pageSize, [currentPage, pageSize]);

  useEffect(() => {
    setCurrentPage(DEFAULT_PAGE);
    setOrdering("-total_missed_lines");
    setAppliedRanges({ ...EMPTY_FTS_PLANTS_RANGE_DRAFT });
  }, [matNbr]);

  useEffect(() => {
    setCurrentPage(DEFAULT_PAGE);
  }, [ordering, fromDate, toDate]);

  const onGlobalFiltersChange = useCallback(() => {
    setCurrentPage(DEFAULT_PAGE);
  }, []);

  useGlobalFiltersListener(onGlobalFiltersChange);

  const handlePageChange = useCallback((page: number) => setCurrentPage(page), []);
  const handlePageSizeChange = useCallback((size: number) => {
    const clamped = Math.min(MAX_PLANTS_PAGE_SIZE, Math.max(1, size));
    setPageSize(clamped);
    setCurrentPage(DEFAULT_PAGE);
  }, []);

  // uncomment when testing (with FtsPlantsRangeFilters onApply)
  // const onRangeApply = useCallback((next: Record<FtsPlantsRangeFieldKey, string>) => {
  //   setAppliedRanges(next);
  //   setCurrentPage(DEFAULT_PAGE);
  // }, []);

  const plantsParams = useMemo((): FtsPlantsParams => {
    const base: Record<string, string | number> = {
      from_date: fromDate,
      to_date: toDate,
      ordering,
      limit: pageSize,
      offset,
    };
    mergeFtsPlantsRangeParams(base, appliedRanges);
    return base as FtsPlantsParams;
  }, [fromDate, toDate, ordering, pageSize, offset, appliedRanges]);

  const plantsQuery = useQuery({
    queryKey: ["fts", "plants", matNbr, plantsParams, filtersVersion],
    enabled: Boolean(matNbr),
    queryFn: async () => {
      if (!matNbr) return null;
      const res = await failToSupplyService.getPlants(matNbr, plantsParams);
      if (!res.data.success) {
        throw new Error(res.data.message || res.data.error || "Failed to load DC Missed Lines");
      }
      return res.data;
    },
  });

  const tableData: DCRow[] = useMemo(() => {
    const rows = plantsQuery.data?.data?.results ?? [];
    return rows.map((r, idx) => {
      const omitQty = r.omit_qty ?? 0;
      const demandQty = r.demand_qty ?? 0;
      const qtyDen = omitQty + demandQty;
      const omitPct = qtyDen > 0 ? (omitQty / qtyDen) * 100 : 0;
      const demandPct = qtyDen > 0 ? (demandQty / qtyDen) * 100 : 0;

      const linesDen = r.ordered_lines ?? 0;
      const linesMetrics = computeOrderedLinesServiceMetrics({
        ordered_lines: linesDen,
        total_missed_lines: r.total_missed_lines,
      });

      const segDemand = Math.max(0, Math.min(100, Math.round(demandPct)));
      const segOmit = Math.max(0, Math.min(100, Math.round(omitPct)));

      return {
        id: `${r.plant_nbr}-${idx}`,
        dcName: r.plant_name,
        dcId: r.plant_nbr,
        prxoMissedLines: r.prxo_missed_lines.toLocaleString(),
        pharmaGenMissedLines: r.pgen_missed_lines.toLocaleString(),
        totalMissedLines: r.total_missed_lines.toLocaleString(),
        totalMissedLinesPct: `${r.total_missed_lines_pct.toFixed(2)}%`,
        outboundFillRate: `${r.outbound_fill_rate.toFixed(2)}%`,
        omitDemandQtyDisplay: Math.round(qtyDen).toLocaleString(),
        omitQty: Math.round(omitQty),
        demandQty: Math.round(demandQty),
        mtdQuantityPct: Math.round(omitPct),
        mtdQuantitySegments: [
          { pct: segDemand, color: "#8A8A8A" },
          { pct: segOmit, color: "#E8E8E8" },
        ],
        totalMissedLinesCount: r.total_missed_lines,
        thresholdMissedLines: linesMetrics.threshold_missed_lines,
        linesServiceStatus: linesMetrics.status,
        orderedLines: linesDen,
      };
    });
  }, [plantsQuery.data]);

  const total = plantsQuery.data?.data?.count ?? 0;
  const isLoading = Boolean(matNbr) && plantsQuery.isPending;
  const disabled = !matNbr;
  const hasNoDcRows =
    Boolean(matNbr) &&
    plantsQuery.isFetched &&
    !plantsQuery.isPending &&
    !plantsQuery.isError &&
    total === 0;

  return (
    <CardLayout
      title="DC Missed Lines"
      subtitle="Showing the missed lines and omit qty per DC. Click to filter the inventory trend chart below to a single DC."
      icon={<InfoIcon position="bottom" tooltip={DC_TOOLTIP} />}
    >
      <div className="flex flex-col space-y-4 w-full">
        {!(matNbr && (hasNoDcRows || plantsQuery.isError)) && (
          <Legend items={LEGEND_ITEMS} orientation="horizontal" spacing="md" />
        )}
        {!matNbr && (
          <div className="text-sm text-ui-text-secondary">
            Click a material in the table above to load distribution center results.
          </div>
        )}
        {matNbr && !hasNoDcRows && !plantsQuery.isError ? (
          <div className="flex flex-col gap-3">
            <FtsPlantsSortBar ordering={ordering} onOrderingChange={setOrdering} disabled={disabled} />
            {/* uncomment when testing
            <FtsPlantsRangeFilters applied={appliedRanges} onApply={onRangeApply} disabled={disabled} />
            */}
          </div>
        ) : null}
        {isLoading ? (
          <SkeletonTable rows={10} columns={8} />
        ) : matNbr && plantsQuery.isError ? (
          <div className="text-sm text-ui-text-secondary py-2">
            Unable to load DC Missed Lines for this material. Try again or pick another material.
          </div>
        ) : hasNoDcRows ? (
          <div className="text-sm text-ui-text-secondary py-2">
            No DC Missed Lines data for the selected material for this date range.
          </div>
        ) : matNbr ? (
          <DCMissedLinesTable
            data={tableData}
            currentPage={currentPage}
            pageSize={pageSize}
            total={total}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            pageSizeOptions={[10, 25, 50]}
          />
        ) : null}
      </div>
    </CardLayout>
  );
}
