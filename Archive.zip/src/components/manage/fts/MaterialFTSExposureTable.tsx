import { memo, useMemo } from "react";
import { ArrowDown } from "lucide-react";
import { getMonthColumns } from "@/lib/ftsMonthUtils";
import type { FTSMaterialExposureItem } from "@/hooks/manage/fts/fts-material-exposure-query";

const PILL_POSITIVE_BG = "#E7F7FF";
const PILL_POSITIVE_TEXT = "#005C98";
const PILL_NEGATIVE_BG = "rgb(254 226 226)";
const PILL_NEGATIVE_TEXT = "rgb(185 28 28)";
const HEADER_BG = "#F5F5F5";
const SELECTED_MONTH_HEADER_BG = "#EEEDFEC9";
const HEADER_TEXT_COLOR = "#461E96";
const PREVIOUS_MONTHS_HEADER_TEXT_COLOR = "#6B7280";
const MONTH_KEY_ROW_BG = "#FFFFFF";
/** Inner grid lines (row tops, column separators) */
const TABLE_BORDER_CLASS = "border-[#F3F4F6]";
const OUTER_TABLE_BORDER_CLASS = "border-[#E5E7EB]";
const MONTH_KEY_HEADER_TH_CLASS = `px-4 py-2 text-nowrap text-center border-t ${TABLE_BORDER_CLASS}`;

interface MonthCellProps {
  pct: number;
  value: number;
}

const MonthCell = memo(function MonthCell({ pct, value }: MonthCellProps) {
  const isPositive = pct >= 0;
  const pillBg = isPositive ? PILL_POSITIVE_BG : PILL_NEGATIVE_BG;
  const pillTextColor = isPositive ? PILL_POSITIVE_TEXT : PILL_NEGATIVE_TEXT;

  return (
    <div className="flex flex-col gap-0.5 py-2 px-2 min-w-0 items-center">
      <span
        className="inline-flex items-center justify-center rounded-full px-2 py-0.5 text-xs font-medium w-fit"
        style={{ backgroundColor: pillBg, color: pillTextColor }}
      >
        {pct}%
      </span>
      <span className="text-sm text-ui-text-primary">{value}</span>
    </div>
  );
});

interface MaterialFTSExposureTableProps {
  data: FTSMaterialExposureItem[];
  currentPage: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  selectedMonth: string;
}

export default function MaterialFTSExposureTable({ data, selectedMonth }: MaterialFTSExposureTableProps) {
  const monthColumns = useMemo(() => getMonthColumns(selectedMonth), [selectedMonth]);

  const allMonthKeys = monthColumns.allMonthKeys;

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex-1 overflow-auto">
        <div className={`rounded-[4px] overflow-hidden border ${OUTER_TABLE_BORDER_CLASS}`}>
          <table className="w-full text-sm border-collapse">
            <thead className="font-bold text-ui-text-primary">
              <tr>
                <th rowSpan={2} className="px-4 py-2 text-nowrap text-center" style={{ backgroundColor: HEADER_BG }}>
                  Material NDC
                </th>
                <th rowSpan={2} className="px-4 py-2 text-nowrap text-center" style={{ backgroundColor: HEADER_BG }}>
                  Material Description
                </th>
                <th rowSpan={2} className="px-4 py-2 text-nowrap text-center" style={{ backgroundColor: HEADER_BG }}>
                  FTS Exposure
                </th>
                <th rowSpan={2} className="px-4 py-2 text-nowrap text-center" style={{ backgroundColor: HEADER_BG }}>
                  FTS Quantity
                </th>
                <th colSpan={7} className="px-4 py-2 text-nowrap text-center font-normal" style={{ backgroundColor: HEADER_BG }}>
                  PRxO - Line Service Level and Net Sales
                </th>
              </tr>
              <tr>
                <th
                  colSpan={1}
                  className="py-2 text-nowrap text-center"
                  style={{ backgroundColor: SELECTED_MONTH_HEADER_BG, color: HEADER_TEXT_COLOR }}
                >
                  <span className="inline-flex items-center justify-center">
                    <ArrowDown className="h-6 w-6 shrink-0 text-ui-text-muted" aria-hidden color={HEADER_TEXT_COLOR} />
                    Selected Month
                  </span>
                </th>
                <th
                  colSpan={6}
                  className="px-4 py-2 text-nowrap text-center font-normal"
                  style={{ color: PREVIOUS_MONTHS_HEADER_TEXT_COLOR }}
                >
                  PREVIOUS 6 MONTHS
                </th>
              </tr>
              <tr>
                <th className={MONTH_KEY_HEADER_TH_CLASS} style={{ backgroundColor: MONTH_KEY_ROW_BG }}>
                  {"\u00a0"}
                </th>
                <th className={MONTH_KEY_HEADER_TH_CLASS} style={{ backgroundColor: MONTH_KEY_ROW_BG }}>
                  {"\u00a0"}
                </th>
                <th className={MONTH_KEY_HEADER_TH_CLASS} style={{ backgroundColor: MONTH_KEY_ROW_BG }}>
                  {"\u00a0"}
                </th>
                <th className={MONTH_KEY_HEADER_TH_CLASS} style={{ backgroundColor: MONTH_KEY_ROW_BG }}>
                  {"\u00a0"}
                </th>
                <th className={MONTH_KEY_HEADER_TH_CLASS} style={{ backgroundColor: MONTH_KEY_ROW_BG }}>
                  {monthColumns.selectedMonth}
                </th>
                {monthColumns.previousMonths.map((label, i) => (
                  <th
                    key={monthColumns.previousMonthKeys[i]}
                    className={MONTH_KEY_HEADER_TH_CLASS}
                    style={{ backgroundColor: MONTH_KEY_ROW_BG }}
                  >
                    {label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map(row => (
                <tr key={row.id} className={`border-t hover:bg-brand-primary-50 ${TABLE_BORDER_CLASS}`}>
                  <td
                    className={`px-4 py-2 font-medium text-ui-text-primary text-nowrap text-center border-r ${TABLE_BORDER_CLASS}`}
                  >
                    {row.material_ndc}
                  </td>
                  <td className={`px-4 py-2 text-ui-text-primary text-nowrap text-center border-r ${TABLE_BORDER_CLASS}`}>
                    {row.material_description}
                  </td>
                  <td className={`px-4 py-2 text-nowrap text-center border-r ${TABLE_BORDER_CLASS}`}>
                    {row.fts_exposure.toLocaleString()}
                  </td>
                  <td className={`px-4 py-2 text-nowrap text-center border-r ${TABLE_BORDER_CLASS}`}>
                    {row.fts_quantity.toLocaleString()}
                  </td>
                  {allMonthKeys.map(monthKey => {
                    const cellData = row.monthly_data[monthKey];
                    if (!cellData) {
                      return (
                        <td key={monthKey} className="px-2 py-2 text-nowrap text-center">
                          —
                        </td>
                      );
                    }
                    return (
                      <td key={monthKey} className="text-nowrap text-center">
                        <MonthCell pct={cellData.pct} value={cellData.value} />
                      </td>
                    );
                  })}
                </tr>
              ))}
              {data.length === 0 && (
                <tr>
                  <td
                    colSpan={4 + allMonthKeys.length}
                    className={`px-4 py-6 text-center text-ui-text-secondary border-t ${TABLE_BORDER_CLASS}`}
                  >
                    No data
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
