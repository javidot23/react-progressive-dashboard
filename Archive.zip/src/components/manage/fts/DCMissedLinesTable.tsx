import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Pagination } from "@/components/atoms";
import type { LegendItem } from "@/components/atoms/Legend";
import type { OrderedLinesServiceStatus } from "@/lib/orderedLinesServiceLevel";
import { cn } from "@/lib/utils";

interface DCRow {
  id: string;
  dcName: string;
  dcId: string;
  prxoMissedLines: string;
  pharmaGenMissedLines: string;
  totalMissedLines: string;
  totalMissedLinesPct: string;
  outboundFillRate: string;
  omitDemandQtyDisplay: string;
  /** Raw quantities for omit / demand bar tooltip */
  omitQty: number;
  demandQty: number;
  mtdQuantityPct: number;
  mtdQuantitySegments?: { pct: number; color: string }[];
  /** Raw missed line count (MTD Lines bar length). */
  totalMissedLinesCount: number;
  thresholdMissedLines: number | null;
  linesServiceStatus: OrderedLinesServiceStatus;
  /** Denominator for 95% line threshold (MTD Lines tooltip). */
  orderedLines: number;
}

interface DCMissedLinesTableProps {
  data: DCRow[];
  currentPage: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  /** FTS plants API: default 10, max 50 */
  pageSizeOptions?: number[];
}

const LEGEND_ITEMS: LegendItem[] = [
  { id: "1", label: "Service Level <95%", color: "#F97316", shape: "square" },
  { id: "2", label: "Service Level >=95%", color: "#461E96", shape: "square" },
  { id: "3", label: "Omit Qty", color: "#E8E8E8", shape: "square" },
  { id: "4", label: "Demand Qty", color: "#8A8A8A", shape: "square" },
  { id: "5", label: "95% line threshold", color: "#1E1E1E", shape: "square" },
];

const SegmentedBar = ({
  segments,
  fallbackPct,
  barClassName = "w-24 h-2",
}: {
  segments?: { pct: number; color: string }[];
  fallbackPct: number;
  barClassName?: string;
}) => {
  const displaySegments = segments ?? [{ pct: fallbackPct, color: "#6B7280" }];
  return (
    <div className={cn("overflow-hidden bg-gray-100 flex rounded-sm", barClassName)}>
      {displaySegments.map((seg, i) => (
        <div
          key={i}
          className="h-full min-w-0 transition-all"
          style={{ width: `${seg.pct}%`, backgroundColor: seg.color }}
        />
      ))}
    </div>
  );
};

/** Portal tooltip: native `title` on a 10px bar is nearly impossible to trigger; scroll parents also clip CSS-only tips. */
function OmitDemandQtyBar({
  omitQty,
  demandQty,
  segments,
  fallbackPct,
}: {
  omitQty: number;
  demandQty: number;
  segments?: { pct: number; color: string }[];
  fallbackPct: number;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [pos, setPos] = useState({ left: 0, top: 0 });

  const syncPos = useCallback(() => {
    const el = wrapRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setPos({ left: r.left + r.width / 2, top: r.top });
  }, []);

  useEffect(() => {
    if (!visible) return;
    syncPos();
    const opts = { capture: true } as const;
    window.addEventListener("scroll", syncPos, opts);
    window.addEventListener("resize", syncPos);
    return () => {
      window.removeEventListener("scroll", syncPos, opts);
      window.removeEventListener("resize", syncPos);
    };
  }, [visible, syncPos]);

  const show = () => {
    syncPos();
    setVisible(true);
  };
  const hide = () => setVisible(false);

  const tooltip =
    visible && typeof document !== "undefined" ? (
      createPortal(
        <div
          className="fixed z-10000 min-w-[148px] -translate-x-1/2 -translate-y-full rounded-md border border-gray-200 bg-[#211359] px-3 py-2 text-xs text-white shadow-lg pointer-events-none tabular-nums"
          style={{ left: pos.left, top: pos.top - 8 }}
          role="tooltip"
        >
          <div className="space-y-0.5 leading-snug">
            <div>Omit: {omitQty.toLocaleString()}</div>
            <div>Demand QTY: {demandQty.toLocaleString()}</div>
          </div>
        </div>,
        document.body
      )
    ) : null;

  return (
    <>
      <div
        ref={wrapRef}
        className="flex flex-1 min-w-[100px] max-w-[200px] cursor-default items-center py-2"
        onMouseEnter={show}
        onMouseLeave={hide}
        role="img"
        aria-label={`Omit ${omitQty.toLocaleString()}, Demand QTY ${demandQty.toLocaleString()}`}
      >
        <SegmentedBar segments={segments} fallbackPct={fallbackPct} barClassName="w-full h-2.5" />
      </div>
      {tooltip}
    </>
  );
}

export function computeMtdLinesAxisMax(rows: DCRow[]): number {
  let max = 1;
  for (const r of rows) {
    max = Math.max(max, r.totalMissedLinesCount);
    if (r.thresholdMissedLines != null) {
      max = Math.max(max, r.thresholdMissedLines);
    }
  }
  return Math.max(1, Math.ceil(max * 1.1));
}

const MtdLinesCountBar = ({
  axisMax,
  totalMissed,
  thresholdMissedLines,
  status,
  className,
}: {
  axisMax: number;
  totalMissed: number;
  thresholdMissedLines: number | null;
  status: OrderedLinesServiceStatus;
  className?: string;
}) => {
  const max = Math.max(axisMax, 1e-9);
  const fillPct = Math.min(100, Math.max(0, (totalMissed / max) * 100));
  const showThreshold = thresholdMissedLines != null && status !== "no_data";
  const thresholdPct = showThreshold
    ? Math.min(100, Math.max(0, (thresholdMissedLines / max) * 100))
    : null;

  const fillColor =
    status === "meets_target" ? "#461E96" : status === "below_target" ? "#F97316" : "#9CA3AF";

  return (
    <div
      className={cn("relative flex-1 min-w-[100px] max-w-[200px] h-2.5 rounded-sm bg-gray-100 overflow-hidden", className)}
    >
      <div
        className="absolute left-0 top-0 bottom-0 rounded-l-sm transition-[width]"
        style={{ width: `${fillPct}%`, backgroundColor: fillColor }}
        aria-hidden
      />
      {thresholdPct != null ? (
        <div
          className="absolute top-0 bottom-0 z-10 w-px bg-[#1E1E1E] pointer-events-none"
          style={{ left: `${thresholdPct}%`, transform: "translateX(-50%)" }}
          aria-hidden
        />
      ) : null}
    </div>
  );
};

function MtdLinesWithTooltip({
  axisMax,
  totalMissed,
  thresholdMissedLines,
  status,
  orderedLines,
}: {
  axisMax: number;
  totalMissed: number;
  thresholdMissedLines: number | null;
  status: OrderedLinesServiceStatus;
  orderedLines: number;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [pos, setPos] = useState({ left: 0, top: 0 });

  const syncPos = useCallback(() => {
    const el = wrapRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setPos({ left: r.left + r.width / 2, top: r.top });
  }, []);

  useEffect(() => {
    if (!visible) return;
    syncPos();
    const opts = { capture: true } as const;
    window.addEventListener("scroll", syncPos, opts);
    window.addEventListener("resize", syncPos);
    return () => {
      window.removeEventListener("scroll", syncPos, opts);
      window.removeEventListener("resize", syncPos);
    };
  }, [visible, syncPos]);

  const show = () => {
    syncPos();
    setVisible(true);
  };
  const hide = () => setVisible(false);

  const thresholdLabel =
    thresholdMissedLines != null ? Math.round(thresholdMissedLines).toLocaleString() : "—";

  const ariaLabel =
    status === "no_data"
      ? `MTD missed lines ${totalMissed.toLocaleString()}, no ordered line data`
      : `MTD missed lines ${totalMissed.toLocaleString()}, 95% line threshold ${thresholdLabel}, ordered lines ${orderedLines.toLocaleString()}, ${status === "meets_target" ? "meets" : "below"} 95% line target`;

  const tooltip =
    visible && typeof document !== "undefined" ? (
      createPortal(
        <div
          className="fixed z-10000 min-w-[180px] -translate-x-1/2 -translate-y-full rounded-md border border-gray-200 bg-[#211359] px-3 py-2 text-xs text-white shadow-lg pointer-events-none tabular-nums"
          style={{ left: pos.left, top: pos.top - 8 }}
          role="tooltip"
        >
          <div className="space-y-0.5 leading-snug">
            <div>MTD missed lines: {totalMissed.toLocaleString()}</div>
            <div>95% line threshold: {thresholdLabel}</div>
            <div>Ordered lines: {orderedLines.toLocaleString()}</div>
          </div>
        </div>,
        document.body
      )
    ) : null;

  return (
    <>
      <div
        ref={wrapRef}
        className="flex min-w-[160px] cursor-default items-center gap-3 py-2"
        onMouseEnter={show}
        onMouseLeave={hide}
        role="img"
        aria-label={ariaLabel}
      >
        <MtdLinesCountBar
          axisMax={axisMax}
          totalMissed={totalMissed}
          thresholdMissedLines={thresholdMissedLines}
          status={status}
        />
        <span className="shrink-0 text-nowrap text-ui-text-primary tabular-nums">{totalMissed.toLocaleString()}</span>
      </div>
      {tooltip}
    </>
  );
}

export default function DCMissedLinesTable({
  data,
  currentPage,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 25, 50],
}: DCMissedLinesTableProps) {
  const mtdAxisMax = computeMtdLinesAxisMax(data);

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm text-left">
          <thead className="font-bold text-ui-text-primary">
            <tr>
              <th className="px-4 py-2 text-nowrap">Distribution Center</th>
              <th className="px-4 py-2 text-nowrap">Distribution Center Id</th>
              <th className="px-4 py-2 text-nowrap">PrXO Missed Lines</th>
              <th className="px-4 py-2 text-nowrap">PharmaGen Missed Lines</th>
              <th className="px-4 py-2 text-nowrap">Total Missed Lines</th>
              <th className="px-4 py-2 text-nowrap">Outbound Fill Rate</th>
              <th className="px-4 py-2 text-nowrap">Omit and Demand Qty</th>
              <th className="px-4 py-2 align-bottom min-w-[160px]">
                <div>MTD Lines</div>
              </th>
            </tr>
          </thead>
          <tbody>
            {data.map(row => (
              <tr key={row.id} className="border-t hover:bg-brand-primary-50">
                <td className="px-4 py-2 font-medium text-ui-text-primary text-nowrap">{row.dcName}</td>
                <td className="px-4 py-2 text-nowrap">{row.dcId}</td>
                <td className="px-4 py-2 text-nowrap">{row.prxoMissedLines}</td>
                <td className="px-4 py-2 text-nowrap">{row.pharmaGenMissedLines}</td>
                <td className="px-4 py-2 text-nowrap">
                  {row.totalMissedLines} ({row.totalMissedLinesPct})
                </td>
                <td className="px-4 py-2 text-nowrap">{row.outboundFillRate}</td>
                <td className="px-4 py-2">
                  <div className="flex items-center gap-3 min-w-[160px]">
                    <OmitDemandQtyBar
                      omitQty={row.omitQty}
                      demandQty={row.demandQty}
                      segments={row.mtdQuantitySegments}
                      fallbackPct={row.mtdQuantityPct}
                    />
                    <span className="text-nowrap text-ui-text-primary tabular-nums shrink-0">
                      {row.omitDemandQtyDisplay}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-2">
                  <MtdLinesWithTooltip
                    axisMax={mtdAxisMax}
                    totalMissed={row.totalMissedLinesCount}
                    thresholdMissedLines={row.thresholdMissedLines}
                    status={row.linesServiceStatus}
                    orderedLines={row.orderedLines}
                  />
                </td>
              </tr>
            ))}
            {data.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-6 text-center text-ui-text-secondary">
                  No data
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Pagination
        currentPage={currentPage}
        pageSize={pageSize}
        total={total}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        pageSizeOptions={pageSizeOptions}
        itemName="Distribution Centers"
      />
    </div>
  );
}

export { LEGEND_ITEMS };
export type { DCRow };
