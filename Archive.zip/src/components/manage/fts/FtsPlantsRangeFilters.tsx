// import { useState, useCallback, useEffect } from "react";
// uncomment when testing (restore component): import EMPTY_FTS_PLANTS_RANGE_DRAFT and type FtsPlantsRangeFieldKey from @/utils/ftsMitigation
// import {
//   EMPTY_FTS_PLANTS_RANGE_DRAFT,
//   type FtsPlantsRangeFieldKey,
// } from "@/utils/ftsMitigation";

// uncomment when testing (restore FtsPlantsRangeFilters component below)
// const GROUPS: Array<{
//   title: string;
//   minKey: FtsPlantsRangeFieldKey;
//   maxKey: FtsPlantsRangeFieldKey;
//   unit?: string;
// }> = [
//   { title: "PRxO missed lines", minKey: "prxo_missed_lines_min", maxKey: "prxo_missed_lines_max" },
//   { title: "PharmaGen missed lines", minKey: "pgen_missed_lines_min", maxKey: "pgen_missed_lines_max" },
//   { title: "Total missed lines", minKey: "total_missed_lines_min", maxKey: "total_missed_lines_max" },
//   { title: "Missed lines %", minKey: "total_missed_lines_pct_min", maxKey: "total_missed_lines_pct_max", unit: "%" },
//   { title: "Outbound fill rate", minKey: "outbound_fill_rate_min", maxKey: "outbound_fill_rate_max", unit: "%" },
//   { title: "Service level", minKey: "service_level_min", maxKey: "service_level_max", unit: "%" },
//   { title: "Omit quantity", minKey: "omit_qty_min", maxKey: "omit_qty_max" },
//   { title: "Demand quantity", minKey: "demand_qty_min", maxKey: "demand_qty_max" },
//   { title: "Ordered lines", minKey: "ordered_lines_min", maxKey: "ordered_lines_max" },
// ];

// Uncomment when testing
// interface FtsPlantsRangeFiltersProps {
//   applied: Record<FtsPlantsRangeFieldKey, string>;
//   onApply: (next: Record<FtsPlantsRangeFieldKey, string>) => void;
//   disabled?: boolean;
// }

// Uncomment when testing
// export default function FtsPlantsRangeFilters({ applied, onApply, disabled = false }: FtsPlantsRangeFiltersProps) {
//   const [draft, setDraft] = useState<Record<FtsPlantsRangeFieldKey, string>>(() => ({ ...applied }));
//   const [expanded, setExpanded] = useState(false);

//   useEffect(() => {
//     if (!expanded) setDraft({ ...applied });
//   }, [applied, expanded]);

//   const syncDraftFromApplied = useCallback(() => {
//     setDraft({ ...applied });
//   }, [applied]);

//   const handleApply = useCallback(() => {
//     onApply({ ...draft });
//   }, [draft, onApply]);

//   const handleClear = useCallback(() => {
//     const empty = { ...EMPTY_FTS_PLANTS_RANGE_DRAFT };
//     setDraft(empty);
//     onApply(empty);
//   }, [onApply]);

//   return (
//     <div className="w-full border border-[#E2E8F0] rounded-md bg-ui-background-primary">
//       WARNING: This is a placeholder:
//       <button
//         type="button"
//         disabled={disabled}
//         onClick={() => {
//           if (!expanded) syncDraftFromApplied();
//           setExpanded(e => !e);
//         }}
//         className="flex w-full items-center justify-between px-3 py-2 text-sm font-medium text-ui-text-primary hover:bg-ui-background-muted rounded-md disabled:opacity-50"
//       >
//         <span>Numeric filters (min / max)</span>
//         <svg
//           className={`w-5 h-5 shrink-0 transition-transform ${expanded ? "rotate-180" : ""}`}
//           fill="none"
//           stroke="currentColor"
//           viewBox="0 0 24 24"
//         >
//           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
//         </svg>
//       </button>
//       {expanded && (
//         <div className="px-3 pb-3 pt-1 border-t border-[#E2E8F0] space-y-3">
//           <p className="text-xs text-ui-text-secondary">
//             Optional bounds for the plants list. Leave blank to ignore. Values are sent as API query parameters per the Fail to Supply spec.
//           </p>
//           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
//             {GROUPS.map(g => (
//               <div key={g.title} className="flex flex-col gap-1 rounded border border-[#E2E8F0] p-2 bg-white">
//                 <div className="text-xs font-semibold text-ui-text-primary">
//                   {g.title}
//                   {g.unit ? ` (${g.unit})` : ""}
//                 </div>
//                 <div className="flex gap-2 items-center">
//                   <input
//                     type="text"
//                     inputMode="decimal"
//                     placeholder="Min"
//                     disabled={disabled}
//                     value={draft[g.minKey]}
//                     onChange={e => setDraft(prev => ({ ...prev, [g.minKey]: e.target.value }))}
//                     className="flex-1 min-w-0 h-8 px-2 text-sm border border-[#E2E8F0] rounded"
//                   />
//                   <span className="text-ui-text-muted text-xs">–</span>
//                   <input
//                     type="text"
//                     inputMode="decimal"
//                     placeholder="Max"
//                     disabled={disabled}
//                     value={draft[g.maxKey]}
//                     onChange={e => setDraft(prev => ({ ...prev, [g.maxKey]: e.target.value }))}
//                     className="flex-1 min-w-0 h-8 px-2 text-sm border border-[#E2E8F0] rounded"
//                   />
//                 </div>
//               </div>
//             ))}
//           </div>
//           <div className="flex flex-wrap gap-2 justify-end">
//             <button
//               type="button"
//               disabled={disabled}
//               onClick={handleClear}
//               className="px-3 py-1.5 text-sm font-semibold border-2 border-[#E2E8F0] rounded-md hover:bg-ui-background-muted text-ui-text-secondary"
//             >
//               Clear
//             </button>
//             <button
//               type="button"
//               disabled={disabled}
//               onClick={handleApply}
//               className="px-3 py-1.5 text-sm font-bold border-2 border-brand-primary-main text-brand-primary-main rounded-md hover:bg-purple-50"
//             >
//               Apply filters
//             </button>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }
