import { useCallback } from "react";
import { CalendarDayPicker } from "@/components/atoms/CalendarDayPicker";
import { dateToISO, getToday } from "@/lib/dateUtils";

interface FtsDateRangeInputsProps {
  fromDate: string;
  toDate: string;
  onFromDateChange: (iso: string) => void;
  onToDateChange: (iso: string) => void;
  disabled?: boolean;
}

export default function FtsDateRangeInputs({
  fromDate,
  toDate,
  onFromDateChange,
  onToDateChange,
  disabled = false,
}: FtsDateRangeInputsProps) {
  const handleFromChange = useCallback(
    (iso: string) => {
      onFromDateChange(iso);
      if (iso > toDate) onToDateChange(iso);
    },
    [onFromDateChange, onToDateChange, toDate]
  );

  const handleToChange = useCallback(
    (iso: string) => {
      onToDateChange(iso);
      if (iso < fromDate) onFromDateChange(iso);
    },
    [onFromDateChange, onToDateChange, fromDate]
  );

  const isFromDayDisabled = useCallback(
    (day: Date) => {
      const iso = dateToISO(day);
      const todayIso = dateToISO(getToday());
      if (iso > todayIso) return true;
      if (iso > toDate) return true;
      return false;
    },
    [toDate]
  );

  const isToDayDisabled = useCallback(
    (day: Date) => {
      const iso = dateToISO(day);
      const todayIso = dateToISO(getToday());
      if (iso > todayIso) return true;
      if (iso < fromDate) return true;
      return false;
    },
    [fromDate]
  );

  const fromPickerKey = `${fromDate}|${toDate}`;
  const toPickerKey = `${fromDate}|${toDate}-to`;

  return (
    <div className="flex flex-col sm:flex-row flex-wrap gap-4 items-start w-full min-w-0">
      <CalendarDayPicker
        key={fromPickerKey}
        title="From date"
        value={fromDate}
        onSelectDay={handleFromChange}
        isDayDisabled={isFromDayDisabled}
        disabled={disabled}
      />
      <CalendarDayPicker
        key={toPickerKey}
        title="To date"
        value={toDate}
        onSelectDay={handleToChange}
        isDayDisabled={isToDayDisabled}
        disabled={disabled}
      />
    </div>
  );
}
