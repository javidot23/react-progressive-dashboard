import { formatApiDate } from "@/lib/dateUtils";
import SparkAreaLineChart from "@/components/molecules/SparkAreaLineChart";
import type { FtsTrendPoint } from "@/lib/apiServices";

interface FtsTrendLineChartProps {
  points: FtsTrendPoint[] | undefined;
  /** Shown in the hover tooltip (e.g. "PRxO Service Level"). */
  metricLabel?: string;
}

export default function FtsTrendLineChart({
  points,
  metricLabel = "Service level",
}: FtsTrendLineChartProps) {
  const sorted = [...(points ?? [])].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  const series = sorted.map(p => (typeof p.value === "number" ? +p.value.toFixed(2) : 0));
  const xLabels = sorted.map(s => s.date.slice(5));

  if (sorted.length === 0) {
    return <div className="h-[50px] w-full rounded bg-[#F5F5F5]" aria-hidden />;
  }

  return (
    <SparkAreaLineChart
      className="relative w-full min-w-0"
      data={series}
      xLabels={xLabels}
      height={50}
      color="rgba(70, 30, 150, 0.62)"
      strokeColor="#461E96"
      valueFormatter={value => `${value}%`}
      computeYDomain={(minValue, maxValue) => [
        Math.min(minValue - 5, 0),
        Math.max(maxValue + 5, 100),
      ]}
      renderTooltip={({ tooltip, tooltipPosition, containerRef }) => {
        const el = containerRef.current;
        if (!el) return null;

        const dataPoint = sorted[tooltip.index];
        if (!dataPoint) return null;

        const containerRect = el.getBoundingClientRect();
        const tooltipWidth = 160;
        const tooltipHeight = 60;
        const cursorX = tooltipPosition.x;
        const cursorY = tooltipPosition.y;
        const offset = 15;
        const edgeMargin = 5;

        let tooltipLeft = cursorX + offset;
        if (tooltipLeft + tooltipWidth + edgeMargin > containerRect.width) {
          tooltipLeft = cursorX - tooltipWidth - offset;
          if (tooltipLeft < edgeMargin) tooltipLeft = edgeMargin;
        }
        if (tooltipLeft < edgeMargin) tooltipLeft = edgeMargin;

        let tooltipTop = cursorY - tooltipHeight / 2;
        if (tooltipTop < edgeMargin) tooltipTop = edgeMargin;
        else if (tooltipTop + tooltipHeight + edgeMargin > containerRect.height) {
          tooltipTop = containerRect.height - tooltipHeight - edgeMargin;
        }

        const formatDate = (dateStr: string) =>
          formatApiDate(dateStr, { month: "short", day: "numeric", year: "numeric" });

        return (
          <div
            className="absolute z-50 pointer-events-none"
            style={{ left: `${tooltipLeft}px`, top: `${tooltipTop}px` }}
          >
            <div className="bg-[#211359] text-white text-xs rounded-md shadow-lg w-[160px] p-2 font-normal z-30">
              <div className="flex flex-col gap-2">
                <div className="flex justify-between gap-2">
                  <span className="text-xs">Date:</span>
                  <span className="text-xs text-right">{formatDate(dataPoint.date)}</span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-xs">{metricLabel}:</span>
                  <span className="text-xs">{tooltip.value}%</span>
                </div>
              </div>
            </div>
          </div>
        );
      }}
    />
  );
}
