import { useCallback, useEffect, useId, useRef, useState } from "react";
import SortIcon from "@/assets/icons/asc-icon.svg";

/** Matches fail_to_supply.md — materials endpoint ordering only. */
const SORT_FIELDS = [
  { label: "Material ID", value: "mat_nbr" },
  { label: "Sales amount", value: "sales_amount" },
  { label: "Omits quantity", value: "omits_qty" },
] as const;

function parseOrdering(ordering: string): { field: string; desc: boolean } {
  const trimmed = ordering.trim();
  if (trimmed.startsWith("-")) {
    return { field: trimmed.slice(1) || "mat_nbr", desc: true };
  }
  return { field: trimmed || "mat_nbr", desc: false };
}

function buildOrdering(field: string, desc: boolean): string {
  return desc ? `-${field}` : field;
}

interface FtsMaterialsSortBarProps {
  ordering: string;
  onOrderingChange: (ordering: string) => void;
}

export default function FtsMaterialsSortBar({ ordering, onOrderingChange }: FtsMaterialsSortBarProps) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const listboxId = useId();

  const { field: currentField, desc: currentDesc } = parseOrdering(ordering);
  const currentOption = SORT_FIELDS.find(o => o.value === currentField) ?? SORT_FIELDS[0];

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, [open]);

  const setFieldAndDirection = useCallback(
    (field: string, desc: boolean) => {
      onOrderingChange(buildOrdering(field, desc));
    },
    [onOrderingChange]
  );

  const selectField = useCallback(
    (field: string) => {
      setFieldAndDirection(field, currentDesc);
      setOpen(false);
    },
    [currentDesc, setFieldAndDirection]
  );

  return (
    <div ref={containerRef} className="flex flex-wrap items-end gap-3 w-full">
      <div className="flex flex-col space-y-1 min-w-[200px] flex-1 sm:flex-none sm:max-w-xs">
        <span id={`${listboxId}-label`} className="text-sm font-medium text-[#495057] text-nowrap">
          Sort
        </span>
        <div className="relative">
          <button
            type="button"
            aria-haspopup="listbox"
            aria-expanded={open}
            aria-labelledby={`${listboxId}-label`}
            onClick={() => setOpen(o => !o)}
            className="flex items-center justify-between w-full h-[36px] px-3 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-hidden text-sm text-ui-text-secondary"
          >
            <span className="truncate">{currentOption.label}</span>
            <svg className={`w-5 h-5 shrink-0 transition-transform ${open ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          {open && (
            <ul
              role="listbox"
              className="absolute z-30 mt-1 w-full border border-gray-300 rounded-md shadow-lg bg-white max-h-60 overflow-y-auto py-1"
            >
              {SORT_FIELDS.map(opt => (
                <li key={opt.value} role="option" aria-selected={opt.value === currentField}>
                  <button
                    type="button"
                    className={`block w-full px-4 py-2 text-left text-sm hover:bg-ui-background-muted ${
                      opt.value === currentField ? "bg-ui-background-muted font-semibold text-ui-text-primary" : "text-ui-text-secondary"
                    }`}
                    onClick={() => selectField(opt.value)}
                  >
                    {opt.label}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
      <div className="flex gap-1 pb-0.5">
        <button
          type="button"
          title="Sort ascending"
          onClick={() => setFieldAndDirection(currentField, false)}
          className={`flex items-center justify-center px-2.5 h-[36px] border rounded-md ${
            !currentDesc ? "bg-violet-50 border-violet-600 text-violet-600" : "bg-white border-[#E2E8F0] text-[#4A5568] hover:border-gray-400"
          }`}
        >
          <img src={SortIcon} alt="" className="w-4 h-4" />
        </button>
        <button
          type="button"
          title="Sort descending"
          onClick={() => setFieldAndDirection(currentField, true)}
          className={`flex items-center justify-center px-2.5 h-[36px] border rounded-md rotate-180 ${
            currentDesc ? "bg-violet-50 border-violet-600 text-violet-600" : "bg-white border-[#E2E8F0] text-[#4A5568] hover:border-gray-400"
          }`}
        >
          <img src={SortIcon} alt="" className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
