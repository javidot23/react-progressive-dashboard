import type { CSSProperties } from "react";
import type { Meta, StoryObj } from "@storybook/react";

const semanticColors = [
  "--color-background-primary",
  "--color-background-secondary",
  "--color-text-primary",
  "--color-text-secondary",
  "--color-border-primary",
  "--color-interactive-primary",
  "--color-status-success-main",
  "--color-status-warning-main",
  "--color-status-error-main",
] as const;

function ColorTokens() {
  return (
    <div className="grid min-w-[40rem] grid-cols-3 gap-4">
      {semanticColors.map(token => (
        <article key={token} className="border border-border-primary p-4">
          <div className="mb-3 h-20 border border-border-secondary" style={{ backgroundColor: `var(${token})` }} />
          <code className="text-sm">{token}</code>
        </article>
      ))}
    </div>
  );
}

function TypographyTokens() {
  return (
    <div className="space-y-6 text-text-primary">
      <h1 className="text-3xl font-bold">Heading specimen</h1>
      <h2 className="text-xl font-semibold">Section heading</h2>
      <p className="text-base">Default body text for application content.</p>
      <p className="text-sm text-text-secondary">Secondary supporting text.</p>
    </div>
  );
}

function RadiusTokens() {
  const radii = ["0", "0.25rem", "0.5rem", "9999px"];

  return (
    <div className="flex gap-5">
      {radii.map(radius => (
        <div key={radius} className="text-center">
          <div className="mb-2 h-20 w-20 bg-interactive-primary" style={{ borderRadius: radius } as CSSProperties} />
          <code>{radius}</code>
        </div>
      ))}
    </div>
  );
}

const meta = {
  title: "Foundations/Design Tokens",
  parameters: {
    layout: "padded",
    docs: {
      description: {
        component: "Semantic design tokens exposed through the application CSS theme.",
      },
    },
  },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const Colors: Story = {
  render: () => <ColorTokens />,
};

export const Typography: Story = {
  render: () => <TypographyTokens />,
};

export const BorderRadii: Story = {
  render: () => <RadiusTokens />,
};
