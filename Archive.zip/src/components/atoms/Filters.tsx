import { useEffect, useMemo, useRef, useState } from "react";
import DualRangeSlider from "@/components/atoms/DualRangeSlider";
import SortIcon from "@/assets/icons/asc-icon.svg";
import { getDrivingRiskLabel } from "@/lib";
import { InfoIcon } from "@/components/atoms";
import { useRiskModelDescriptions } from "@/hooks";
import { CalendarDayPicker } from "@/components/atoms/CalendarDayPicker";
import { dateToISO, getToday } from "@/lib/dateUtils";

export interface SortOption {
  label: string;
  value: string;
}

export interface DropdownConfig {
  key: string;
  label: string;
  options:
    | string[]
    | (() => Promise<string[]>)
    | ((search?: string, offset?: number, limit?: number) => Promise<{ options: string[]; hasMore: boolean }>);
  displayMapping?: (value: string) => Promise<string>; // Function to convert stored value to display value
  storeMapping?: (value: string) => Promise<string>; // Function to convert display value to stored value
  disableSearch?: boolean; // Disable search and infinite scroll for this dropdown
  searchPlaceholder?: string; // Custom placeholder for search input
}

export interface RangeConfig {
  key: string;
  label: string;
  min: number;
  max: number;
  step?: number;
  minKey: string;
  maxKey: string;
  valueTransform?: {
    displayToStore: (value: number) => number;
    storeToDisplay: (value: number) => number;
  };
  children?: RangeConfig[];
}

export interface PresetRangeConfig {
  key: string;
  label: string;
  minKey: string;
  maxKey: string;
  presets: Record<string, { min: number; max: number }>;
}

export interface DateInputConfig {
  key: string;
  label: string;
}

export interface FiltersConfig {
  sortOptions: SortOption[];
  dropdowns?: DropdownConfig[];
  ranges?: RangeConfig[];
  presetRanges?: PresetRangeConfig[];
  dateInputs?: DateInputConfig[];
  customOrder?: string[]; // Custom order for rendering filters
}

interface FiltersProps {
  filters: any;
  setFilters: (filters: any) => void;
  config: FiltersConfig;
  /** Override the outer grid columns (e.g. "grid-cols-1"). */
  gridColsClassName?: string;
  /** Optional className for the Sort filter container (e.g. "lg:col-span-2"). */
  sortItemClassName?: string;
  /**
   * Per-range-key live max from the backend. Overrides ``config.ranges[*].max``
   * (and matching children). Missing keys fall back to the static config.
   */
  dynamicMaxValues?: Record<string, number>;
}

const formatOptionLabel = (
  config: DropdownConfig,
  option: string,
  getRiskDisplayName?: (risk: string) => string
) => {
  if (config.key === "has_no_actions") {
    return option;
  }
  if (config.key === "driving_risk") {
    if (getRiskDisplayName) return getRiskDisplayName(option) || option;
    return getDrivingRiskLabel(option, option);
  }
  return option;
};

const getRangeWarningMessage = (filters: any, rangeConfig: RangeConfig) => {
  const maxValue = filters[rangeConfig.maxKey];
  const minValue = filters[rangeConfig.minKey];

  if (minValue >= maxValue) return "Minimum cannot exceed maximum.";
  return null;
};

export default function Filters({
  filters,
  setFilters,
  config,
  gridColsClassName,
  sortItemClassName,
  dynamicMaxValues,
}: FiltersProps) {
  const { getEnrichedMetadata } = useRiskModelDescriptions();

  // Apply dynamic maxes (including ``0`` — the "no data" contract value) to
  // each range config and its children. Missing keys keep the static fallback.
  const resolvedRanges: RangeConfig[] | undefined = useMemo(() => {
    if (!config.ranges) return config.ranges;
    return config.ranges.map((rangeConfig) => {
      const dynamicMax = dynamicMaxValues?.[rangeConfig.key];
      const resolvedChildren = rangeConfig.children?.map((child) => {
        const childMax = dynamicMaxValues?.[child.key];
        return typeof childMax === "number" ? { ...child, max: childMax } : child;
      });

      if (typeof dynamicMax === "number") {
        return { ...rangeConfig, max: dynamicMax, children: resolvedChildren };
      }
      if (resolvedChildren && resolvedChildren !== rangeConfig.children) {
        return { ...rangeConfig, children: resolvedChildren };
      }
      return rangeConfig;
    });
  }, [config.ranges, dynamicMaxValues]);

  // Value-level signature so the clamp effect re-runs on actual changes, not
  // on a fresh object reference from an unmemoized parent prop.
  const dynamicMaxSignature = useMemo(() => {
    if (!dynamicMaxValues) return "";
    return Object.keys(dynamicMaxValues)
      .sort()
      .map((k) => `${k}:${dynamicMaxValues[k]}`)
      .join("|");
  }, [dynamicMaxValues]);

  // The clamp effect intentionally doesn't depend on ``filters`` (would loop
  // on unmemoized ``dynamicMaxValues``), but still needs the latest snapshot
  // to spread without overwriting concurrent user edits.
  const latestFiltersRef = useRef(filters);
  latestFiltersRef.current = filters;

  // Clamp stored bounds when the dynamic max shrinks below them, so the
  // slider stays in range. Only patches when at least one bound actually
  // exceeds the new max.
  useEffect(() => {
    if (!resolvedRanges || !dynamicMaxValues) return;
    const currentFilters = latestFiltersRef.current;
    const updates: Record<string, number> = {};
    const visit = (range: RangeConfig) => {
      const max = range.max;
      const currentMax = currentFilters[range.maxKey];
      const storedMax =
        typeof currentMax === "number"
          ? range.valueTransform?.storeToDisplay(currentMax) ?? currentMax
          : null;
      if (storedMax !== null && storedMax > max) {
        const clamped = range.valueTransform?.displayToStore(max) ?? max;
        if (clamped !== currentMax) {
          updates[range.maxKey] = clamped;
        }
      }
      const currentMin = currentFilters[range.minKey];
      const storedMin =
        typeof currentMin === "number"
          ? range.valueTransform?.storeToDisplay(currentMin) ?? currentMin
          : null;
      if (storedMin !== null && storedMin > max) {
        const clamped = range.valueTransform?.displayToStore(max) ?? max;
        if (clamped !== currentMin) {
          updates[range.minKey] = clamped;
        }
      }
      range.children?.forEach(visit);
    };
    resolvedRanges.forEach(visit);
    if (Object.keys(updates).length > 0) {
      setFilters({ ...latestFiltersRef.current, ...updates });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dynamicMaxSignature]);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [dropdownOptions, setDropdownOptions] = useState<Record<string, string[]>>({});
  const [loadingOptions, setLoadingOptions] = useState<Record<string, boolean>>({});
  const [searchQueries, setSearchQueries] = useState<Record<string, string>>({});
  const [hasMoreOptions, setHasMoreOptions] = useState<Record<string, boolean>>({});
  const [optionOffsets, setOptionOffsets] = useState<Record<string, number>>({});
  const [searchTimeouts, setSearchTimeouts] = useState<Record<string, NodeJS.Timeout>>({});
  const [displayValues, setDisplayValues] = useState<Record<string, string>>({});
  const loadedDropdownsRef = useRef<Set<string>>(new Set());

  // Load async dropdown options
  useEffect(() => {
    const loadAsyncOptions = async () => {
      if (config.dropdowns) {
        for (const dropdown of config.dropdowns) {
          // Skip if already loaded (prevent duplicate calls in React.StrictMode)
          if (loadedDropdownsRef.current.has(dropdown.key)) {
            continue;
          }

          if (typeof dropdown.options === "function") {
            // Mark as loaded BEFORE making the API call to prevent duplicate calls in Strict Mode
            loadedDropdownsRef.current.add(dropdown.key);

            try {
              setLoadingOptions(prev => ({ ...prev, [dropdown.key]: true }));
              // Check if the function supports search parameters
              const optionsFunction = dropdown.options as (
                search?: string,
                offset?: number,
                limit?: number
              ) => Promise<{ options: string[]; hasMore: boolean }>;
              const result = await optionsFunction(undefined, 0, 10);

              // Check if result has the new structure with options and hasMore
              if (result && typeof result === "object" && "options" in result && "hasMore" in result) {
                const typedResult = result as {
                  options: string[];
                  hasMore: boolean;
                };
                const selectedValue = filters[dropdown.key];
                let optionsToSet = ["All", ...typedResult.options];

                // If there's a selected value and it's not in the options, add it
                if (selectedValue && selectedValue !== "" && !typedResult.options.includes(selectedValue) && dropdown.key !== "vendor_nbr") {
                  optionsToSet = [selectedValue, "All", ...typedResult.options];
                }

                setDropdownOptions(prev => ({
                  ...prev,
                  [dropdown.key]: optionsToSet,
                }));
                setHasMoreOptions(prev => ({
                  ...prev,
                  [dropdown.key]: typedResult.hasMore,
                }));
                setOptionOffsets(prev => ({
                  ...prev,
                  [dropdown.key]: typedResult.options.length,
                }));
              } else {
                // Legacy API structure (array of strings)
                const typedResult = result as string[];
                const selectedValue = filters[dropdown.key];
                let optionsToSet = ["All", ...typedResult];

                // If there's a selected value and it's not in the options, add it
                if (selectedValue && selectedValue !== "" && !typedResult.includes(selectedValue) && dropdown.key !== "vendor_nbr") {
                  optionsToSet = [selectedValue, "All", ...typedResult];
                }

                setDropdownOptions(prev => ({
                  ...prev,
                  [dropdown.key]: optionsToSet,
                }));
                setHasMoreOptions(prev => ({ ...prev, [dropdown.key]: false }));
                setOptionOffsets(prev => ({
                  ...prev,
                  [dropdown.key]: typedResult.length,
                }));
              }
            } catch (error) {
              console.error(`Failed to fetch options for ${dropdown.key}:`, error);
              const selectedValue = filters[dropdown.key];
              let optionsToSet = ["All"];

              // If there's a selected value, add it even if API failed
              if (selectedValue && selectedValue !== "") {
                optionsToSet = [selectedValue, "All"];
              }

              setDropdownOptions(prev => ({
                ...prev,
                [dropdown.key]: optionsToSet,
              }));
              setHasMoreOptions(prev => ({ ...prev, [dropdown.key]: false }));
              setOptionOffsets(prev => ({ ...prev, [dropdown.key]: 0 }));
            } finally {
              setLoadingOptions(prev => ({ ...prev, [dropdown.key]: false }));
            }
          } else {
            // Mark as loaded for static options too
            loadedDropdownsRef.current.add(dropdown.key);

            setDropdownOptions(prev => ({
              ...prev,
              [dropdown.key]: dropdown.options as string[],
            }));
            setHasMoreOptions(prev => ({ ...prev, [dropdown.key]: false }));
            setOptionOffsets(prev => ({
              ...prev,
              [dropdown.key]: (dropdown.options as string[]).length,
            }));
          }
        }
      }
    };

    loadAsyncOptions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Only run once on mount - config shouldn't change after mount

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      Object.values(searchTimeouts).forEach(timeout => {
        if (timeout) clearTimeout(timeout);
      });
    };
  }, [searchTimeouts]);

  // Update display values when filters change
  useEffect(() => {
    const updateDisplayValues = async () => {
      if (config.dropdowns) {
        for (const dropdownConfig of config.dropdowns) {
          if (filters[dropdownConfig.key] && filters[dropdownConfig.key] !== "") {
            const storedValue = filters[dropdownConfig.key];

            // If there's a displayMapping function, use it
            if (dropdownConfig.displayMapping) {
              try {
                const displayValue = await dropdownConfig.displayMapping(storedValue);
                setDisplayValues(prev => ({
                  ...prev,
                  [dropdownConfig.key]: displayValue,
                }));
              } catch (error) {
                console.error(`Error mapping stored value "${storedValue}" to display value:`, error);
                setDisplayValues(prev => ({
                  ...prev,
                  [dropdownConfig.key]: storedValue,
                }));
              }
            } else {
              setDisplayValues(prev => ({
                ...prev,
                [dropdownConfig.key]: storedValue,
              }));
            }
          } else {
            setDisplayValues(prev => ({
              ...prev,
              [dropdownConfig.key]: "All",
            }));
          }
        }
      }
    };

    updateDisplayValues();
  }, [filters, config.dropdowns]);

  const handleSortChange = (field: string, direction: string) => {
    let orderingValue = direction === "desc" ? `-${field}` : field;
    // For vendor filters, when sorting by risk_rating, preserve secondary ordering by risk_adjusted_value
    if (field === "risk_rating" && direction === "desc") {
      orderingValue = `-${field},-risk_adjusted_value`;
    }
    setFilters({ ...filters, ordering: orderingValue });
  };

  const handlePresetRangeFilter = (presetConfig: PresetRangeConfig, value: string) => {
    if (value === "All") {
      setFilters({
        ...filters,
        [presetConfig.minKey]: null,
        [presetConfig.maxKey]: null,
      });
    } else {
      const selectedRange = presetConfig.presets[value];
      if (selectedRange) {
        setFilters({
          ...filters,
          [presetConfig.minKey]: selectedRange.min,
          [presetConfig.maxKey]: selectedRange.max,
        });
      }
    }
    setOpenDropdown(null);
  };

  const handleDropdownFilter = async (key: string, value: string) => {
    // Find the dropdown config to check for mapping functions
    const dropdownConfig = config.dropdowns?.find(d => d.key === key);

    // Special handling for has_no_actions filter
    if (key === "has_no_actions") {
      let newValue;
      if (value === "All") {
        newValue = undefined;
      } else if (value === "Not Reviewed") {
        newValue = true;
      } else if (value === "Reviewed") {
        newValue = false;
      }

      setFilters({ ...filters, [key]: newValue });
    } else {
      let newValue = value === "All" ? "" : value;

      // If there's a storeMapping function, use it to convert display value to stored value
      if (dropdownConfig?.storeMapping && value !== "All") {
        try {
          newValue = await dropdownConfig.storeMapping(value);
        } catch (error) {
          console.error(`Error mapping display value "${value}" to stored value:`, error);
        }
      }

      setFilters({ ...filters, [key]: newValue });
    }
    setOpenDropdown(null);
  };

  // Handle search input for dropdowns with debouncing
  const handleSearchChange = (dropdownKey: string, searchQuery: string) => {
    setSearchQueries(prev => ({ ...prev, [dropdownKey]: searchQuery }));

    // Clear existing timeout
    if (searchTimeouts[dropdownKey]) {
      clearTimeout(searchTimeouts[dropdownKey]);
    }

    // Set new timeout for debounced search
    const timeout = setTimeout(async () => {
      await performSearch(dropdownKey, searchQuery);
    }, 300); // 300ms debounce

    setSearchTimeouts(prev => ({ ...prev, [dropdownKey]: timeout }));
  };

  // Perform the actual search
  const performSearch = async (dropdownKey: string, searchQuery: string) => {
    // Find the dropdown config
    const dropdownConfig = config.dropdowns?.find(d => d.key === dropdownKey);
    if (!dropdownConfig || typeof dropdownConfig.options !== "function") return;

    // Check if the function supports search parameters
    const optionsFunction = dropdownConfig.options as (
      search?: string,
      offset?: number,
      limit?: number
    ) => Promise<{ options: string[]; hasMore: boolean }>;

    setLoadingOptions(prev => ({ ...prev, [dropdownKey]: true }));
    try {
      const result = await optionsFunction(searchQuery, 0, 20);
      if (result && typeof result === "object" && "options" in result && "hasMore" in result) {
        setDropdownOptions(prev => ({
          ...prev,
          [dropdownKey]: ["All", ...result.options],
        }));
        setHasMoreOptions(prev => ({ ...prev, [dropdownKey]: result.hasMore }));
        setOptionOffsets(prev => ({
          ...prev,
          [dropdownKey]: result.options.length,
        }));
      }
    } catch (error) {
      console.error(`Error searching ${dropdownKey}:`, error);
    } finally {
      setLoadingOptions(prev => ({ ...prev, [dropdownKey]: false }));
    }
  };

  // Handle loading more options for infinite scroll
  const handleLoadMore = async (dropdownKey: string) => {
    const dropdownConfig = config.dropdowns?.find(d => d.key === dropdownKey);
    if (!dropdownConfig || typeof dropdownConfig.options !== "function") return;

    // Check if the function supports search parameters
    const optionsFunction = dropdownConfig.options as (
      search?: string,
      offset?: number,
      limit?: number
    ) => Promise<{ options: string[]; hasMore: boolean }>;

    const currentOffset = optionOffsets[dropdownKey] || 0;
    const searchQuery = searchQueries[dropdownKey] || "";

    setLoadingOptions(prev => ({ ...prev, [dropdownKey]: true }));
    try {
      const result = await optionsFunction(searchQuery, currentOffset, 20);
      if (result && typeof result === "object" && "options" in result && "hasMore" in result) {
        setDropdownOptions(prev => ({
          ...prev,
          [dropdownKey]: [...prev[dropdownKey].slice(1), ...result.options], // Remove "All" from current, add new options
        }));
        setHasMoreOptions(prev => ({ ...prev, [dropdownKey]: result.hasMore }));
        setOptionOffsets(prev => ({
          ...prev,
          [dropdownKey]: currentOffset + result.options.length,
        }));
      }
    } catch (error) {
      console.error(`Error loading more ${dropdownKey}:`, error);
    } finally {
      setLoadingOptions(prev => ({ ...prev, [dropdownKey]: false }));
    }
  };

  const getCurrentPresetValue = (presetConfig: PresetRangeConfig) => {
    const minValue = filters[presetConfig.minKey];
    const maxValue = filters[presetConfig.maxKey];

    if (!minValue && !maxValue) return "All";

    for (const [presetName, range] of Object.entries(presetConfig.presets)) {
      if (minValue === range.min && maxValue === range.max) {
        return presetName;
      }
    }

    return "Custom";
  };

  // Handle comma-separated ordering values (e.g., "-risk_rating,-risk_adjusted_value")
  const firstOrdering = filters.ordering?.split(",")[0] || "";
  const currentSort = config.sortOptions.find(opt => firstOrdering === opt.value || firstOrdering === `-${opt.value}`);
  const currentDirection = firstOrdering?.startsWith("-") ? "desc" : "asc";

  // Helper function to get dropdown display value
  const getDropdownDisplayValue = (dropdownConfig: DropdownConfig) => {
    const isLoading = loadingOptions[dropdownConfig.key] || false;

    // Handle special case for has_no_actions
    if (dropdownConfig.key === "has_no_actions") {
      if (filters[dropdownConfig.key] === true) return "Not Reviewed";
      if (filters[dropdownConfig.key] === false) return "Reviewed";
      return "All";
    }

    if (isLoading) return "Loading...";

    // Return the cached display value
    return displayValues[dropdownConfig.key] || "All";
  };

  const shouldRenderRangeWarning = (rangeConfig: RangeConfig) => {
    const minValue = filters[rangeConfig.minKey] ?? rangeConfig.min;
    const maxValue = filters[rangeConfig.maxKey] ?? rangeConfig.max;

    return minValue > maxValue;
  };

  // Helper function to render dropdown options
  const renderDropdownOptions = (dropdownConfig: DropdownConfig) => {
    const options = dropdownOptions[dropdownConfig.key] || [];
    const isLoading = loadingOptions[dropdownConfig.key] || false;
    const hasMore = hasMoreOptions[dropdownConfig.key] || false;
    const searchQuery = searchQueries[dropdownConfig.key] || "";

    // Check if this dropdown supports search (has async function and search is not disabled)
    const supportsSearch = typeof dropdownConfig.options === "function" && !dropdownConfig.disableSearch;

    // Ensure selected option is always included in the options list
    const selectedValue = filters[dropdownConfig.key];
    const formattedDisplayValue = displayValues[dropdownConfig.key];
    let displayOptions = [...options];

    // If there's a selected value and it's not in the current options, add it at the top
    if (selectedValue && selectedValue !== "") {
      const valueToCheck = formattedDisplayValue && formattedDisplayValue !== "All"
        ? formattedDisplayValue
        : selectedValue;

      if (!options.includes(valueToCheck) && !options.includes(selectedValue)) {
        displayOptions = [valueToCheck, ...options];
      }
    }

    // Handle infinite scroll
    const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
      if (!supportsSearch || !hasMore || isLoading) return;

      const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
      const scrollThreshold = 50; // Load more when 50px from bottom

      if (scrollHeight - scrollTop - clientHeight < scrollThreshold) {
        handleLoadMore(dropdownConfig.key);
      }
    };

    return (
      <div className="max-h-60 overflow-hidden">
        {/* Search input for async dropdowns */}
        {supportsSearch && (
          <div className="p-2 border-b border-gray-200">
            <input
              type="text"
              placeholder={dropdownConfig.searchPlaceholder || `Search ${dropdownConfig.label.toLowerCase()}...`}
              value={searchQuery}
              onChange={e => handleSearchChange(dropdownConfig.key, e.target.value)}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              onClick={e => e.stopPropagation()}
            />
          </div>
        )}

        {/* Options list with infinite scroll */}
        <div className="max-h-48 overflow-y-auto" onScroll={handleScroll}>
          {isLoading && displayOptions.length === 0 ? (
            <div className="px-4 py-2 text-sm text-gray-500">Loading...</div>
          ) : displayOptions.length === 0 ? (
            <div className="px-4 py-2 text-sm text-gray-500">No options available</div>
          ) : (
            displayOptions.map(option => {
              // Handle special case for has_no_actions
              let isSelected = false;
              if (dropdownConfig.key === "has_no_actions") {
                if (option === "All" && (filters[dropdownConfig.key] === undefined || filters[dropdownConfig.key] === null)) {
                  isSelected = true;
                } else if (option === "Not Reviewed" && filters[dropdownConfig.key] === true) {
                  isSelected = true;
                } else if (option === "Reviewed" && filters[dropdownConfig.key] === false) {
                  isSelected = true;
                }
              } else {
                if (dropdownConfig.key === "vendor_nbr" && option.includes(")") && option.startsWith("(")) {
                  const match = option.match(/^\((\d+)\)/);
                  if (match) {
                    const vendorNbrFromOption = match[1];
                    isSelected = filters[dropdownConfig.key] === vendorNbrFromOption || filters[dropdownConfig.key] === option;
                  } else {
                    isSelected = filters[dropdownConfig.key] === option;
                  }
                } else {
                  isSelected = filters[dropdownConfig.key] === option;
                }
              }

              return (
                <button
                  key={option}
                  onClick={() => handleDropdownFilter(dropdownConfig.key, option)}
                  className={`block w-full px-4 py-2 text-left text-sm text-ui-text-secondary hover:bg-ui-background-muted ${
                    isSelected ? "bg-ui-background-muted font-semibold text-ui-text-primary" : ""
                  }`}
                >
                  {option}
                </button>
              );
            })
          )}

          {/* Loading indicator for infinite scroll */}
          {supportsSearch && isLoading && displayOptions.length > 1 && (
            <div className="px-4 py-2 text-sm text-gray-500 text-center">Loading...</div>
          )}

          {/* End of results indicator */}
          {supportsSearch && !hasMore && !isLoading && displayOptions.length > 1 && (
            <div className="px-4 py-2 text-sm text-gray-400 text-center">No more results</div>
          )}
        </div>
      </div>
    );
  };

  const gridColsClass = gridColsClassName || "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4";

  return (
    <>
      <div className={`grid ${gridColsClass} gap-4 w-full min-w-0 relative z-20 [&>*]:min-w-0`}>
        {config.sortOptions.length > 0 && (
          <div className={`flex flex-col gap-1 relative ${sortItemClassName || ""}`}>
            <label className="text-sm font-medium text-[#495057]">Sort</label>
            <div className="flex min-w-0 gap-2">
              <div className="relative min-w-0 flex-1">
                <button
                  onClick={() => setOpenDropdown(openDropdown === "sort" ? null : "sort")}
                  className="flex items-center justify-between w-full h-[36px] px-3 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-hidden"
                >
                  <span className="truncate text-sm">{currentSort?.label || config.sortOptions[0]?.label}</span>
                  <svg
                    className={`w-5 h-5 text-ui-text-muted transition-transform duration-200 ${
                      openDropdown === "sort" ? "rotate-180" : ""
                    }`}
                    fill="none"
                    stroke="#000000"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {openDropdown === "sort" && (
                  <div className="absolute mt-1 w-full border border-gray-300 rounded-md shadow-lg z-[60] bg-white max-h-60 overflow-y-auto">
                    {config.sortOptions.map(option => (
                      <button
                        key={option.value}
                        onClick={() => {
                          handleSortChange(option.value, currentDirection);
                          setOpenDropdown(null);
                        }}
                        className={`block w-full px-4 py-2 text-left text-sm text-ui-text-secondary hover:bg-ui-background-muted ${
                          currentSort?.value === option.value ? "bg-ui-background-muted font-semibold text-ui-text-primary" : ""
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="shrink-0 flex space-x-1">
                <button
                  onClick={() => handleSortChange(currentSort?.value || config.sortOptions[0]?.value || "name", "asc")}
                  className={`flex items-center justify-center px-2.5 h-[36px] border rounded-md ${
                    currentDirection === "asc"
                      ? "bg-violet-50 border-violet-600 text-violet-600"
                      : "bg-white border-[#E2E8F0] text-[#4A5568] hover:border-gray-400"
                  }`}
                  title="Sort A → Z"
                >
                  <img src={SortIcon} alt="Sort A → Z" className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleSortChange(currentSort?.value || config.sortOptions[0]?.value || "name", "desc")}
                  className={`flex items-center justify-center px-2.5 h-[36px] border rounded-md rotate-180 ${
                    currentDirection === "desc"
                      ? "bg-violet-50 border-violet-600 text-violet-600"
                      : "bg-white border-[#E2E8F0] text-[#4A5568] hover:border-gray-400"
                  }`}
                  title="Sort Z → A"
                >
                  <img src={SortIcon} alt="Sort A → Z" className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Custom Order Filters */}
        {config.customOrder ? (
          config.customOrder.map(filterKey => {
            // Find the filter config by key
            const presetConfig = config.presetRanges?.find(p => p.key === filterKey);
            const rangeConfig = resolvedRanges?.find(r => r.key === filterKey);
            const dropdownConfig = config.dropdowns?.find(d => d.key === filterKey);

            if (presetConfig) {
              return (
                <div key={presetConfig.key} className="flex flex-col gap-1 relative">
                  <label className="text-sm font-medium text-[#495057] text-nowrap">{presetConfig.label}</label>
                  <button
                    onClick={() => setOpenDropdown(openDropdown === presetConfig.key ? null : presetConfig.key)}
                    className="flex items-center justify-between w-full h-[36px] px-3 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-hidden"
                  >
                    <span className="text-sm">{getCurrentPresetValue(presetConfig)}</span>
                    <svg
                      className={`w-5 h-5 transition-transform duration-200 ${
                        openDropdown === presetConfig.key ? "rotate-180" : ""
                      }`}
                      fill="none"
                      stroke="#000000"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  {openDropdown === presetConfig.key && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg z-[60]">
                      {["All", ...Object.keys(presetConfig.presets)].map(option => (
                        <button
                          key={option}
                          onClick={() => handlePresetRangeFilter(presetConfig, option)}
                          className={`block w-full px-4 py-2 text-left text-sm text-ui-text-secondary hover:bg-ui-background-muted ${
                            getCurrentPresetValue(presetConfig) === option
                              ? "bg-ui-background-muted font-semibold text-ui-text-primary"
                              : ""
                          }`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            }

            if (rangeConfig) {
              return (
                <div key={rangeConfig.key} className="flex flex-col gap-1 relative">
                  <label className="text-sm font-medium text-[#495057] text-nowrap">{rangeConfig.label}</label>
                  <button
                    onClick={() => setOpenDropdown(openDropdown === rangeConfig.key ? null : rangeConfig.key)}
                    className="flex items-center justify-between w-full h-[36px] px-3 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-hidden"
                  >
                    <span className="text-sm">
                      {filters[rangeConfig.minKey] || filters[rangeConfig.maxKey] ? "Custom Range" : "All"}
                    </span>
                    <svg
                      className={`w-5 h-5 transition-transform duration-200 ${
                        openDropdown === rangeConfig.key ? "rotate-180" : ""
                      }`}
                      fill="none"
                      stroke="#000000"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  {openDropdown === rangeConfig.key && (
                    <div className="absolute top-full left-0 z-[60] mt-1 w-full max-w-64 bg-white border border-gray-300 rounded-md shadow-lg p-4 overflow-hidden">
                      <div className="space-y-4 w-full">
                        <div className="w-full max-w-full">
                          <label className="block text-xs font-medium text-gray-600 mb-3">{rangeConfig.label} Range</label>
                          <div className="w-full max-w-full overflow-hidden">
                            <DualRangeSlider
                              min={rangeConfig.min}
                              max={rangeConfig.max}
                              step={rangeConfig.step || 1}
                              minValue={
                                rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.storeToDisplay(filters[rangeConfig.minKey] || rangeConfig.min)
                                  : filters[rangeConfig.minKey] || rangeConfig.min
                              }
                              maxValue={
                                rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.storeToDisplay(filters[rangeConfig.maxKey] || rangeConfig.max)
                                  : filters[rangeConfig.maxKey] || rangeConfig.max
                              }
                              onMinChange={(_value) => {}}
                              onMaxChange={(_value) => {}}
                              onChangeEnd={(minVal, maxVal) => {
                                const newFilters: any = { ...filters };
                                const minStoreValue = rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.displayToStore(minVal)
                                  : minVal;
                                const maxStoreValue = rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.displayToStore(maxVal)
                                  : maxVal;
                                const defaultMinStoreValue = rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.displayToStore(rangeConfig.min)
                                  : rangeConfig.min;
                                const defaultMaxStoreValue = rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.displayToStore(rangeConfig.max)
                                  : rangeConfig.max;

                                if (minStoreValue !== defaultMinStoreValue) {
                                  newFilters[rangeConfig.minKey] = minStoreValue;
                                } else {
                                  delete newFilters[rangeConfig.minKey];
                                }

                                if (maxStoreValue !== defaultMaxStoreValue) {
                                  newFilters[rangeConfig.maxKey] = maxStoreValue;
                                } else {
                                  delete newFilters[rangeConfig.maxKey];
                                }

                                setFilters(newFilters);
                              }}
                              debounceMs={500}
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1">From:</label>
                            <input
                              type="number"
                              min={0}
                              max={filters[rangeConfig.maxKey]}
                              value={
                                rangeConfig.valueTransform
                                  ? filters[rangeConfig.minKey]
                                    ? rangeConfig.valueTransform.storeToDisplay(filters[rangeConfig.minKey])
                                    : ""
                                  : filters[rangeConfig.minKey] || ""
                              }
                              onChange={e => {
                                setFilters({
                                  ...filters,
                                  [rangeConfig.minKey]: e.target.value
                                    ? rangeConfig.valueTransform
                                      ? rangeConfig.valueTransform.displayToStore(Number(e.target.value))
                                      : Number(e.target.value)
                                    : null,
                                });
                              }}
                              className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                              placeholder="Min value"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1">To:</label>
                            <input
                              type="number"
                              min={filters[rangeConfig.minKey] || 0}
                              max={rangeConfig.max}
                              value={
                                rangeConfig.valueTransform
                                  ? filters[rangeConfig.maxKey]
                                    ? rangeConfig.valueTransform.storeToDisplay(filters[rangeConfig.maxKey])
                                    : ""
                                  : filters[rangeConfig.maxKey] || ""
                              }
                              onChange={e =>
                                setFilters({
                                  ...filters,
                                  [rangeConfig.maxKey]: e.target.value
                                    ? rangeConfig.valueTransform
                                      ? rangeConfig.valueTransform.displayToStore(Number(e.target.value))
                                      : Number(e.target.value)
                                    : null,
                                })
                              }
                              className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                              placeholder="Max value"
                            />
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            setFilters({
                              ...filters,
                              [rangeConfig.minKey]: null,
                              [rangeConfig.maxKey]: null,
                            });
                            setOpenDropdown(null);
                          }}
                          className="w-full px-3 py-1 bg-gray-100 text-gray-700 rounded text-sm hover:bg-gray-200"
                        >
                          Clear
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            }

            if (dropdownConfig) {
              return (
                <div key={dropdownConfig.key} className="flex flex-col gap-1 relative">
                  <label className="text-sm font-medium text-[#495057] text-nowrap">{dropdownConfig.label}</label>
                  <button
                    onClick={async () => {
                      const isOpening = openDropdown !== dropdownConfig.key;
                      setOpenDropdown(openDropdown === dropdownConfig.key ? null : dropdownConfig.key);

                      // Skip reload if search is disabled (all data already loaded)
                      if (dropdownConfig.disableSearch) {
                        return;
                      }

                      // If opening the dropdown and the selected value is not in options, reload
                      const selectedValue = filters[dropdownConfig.key];
                      const options = dropdownOptions[dropdownConfig.key] || [];
                      const formattedDisplayValue = displayValues[dropdownConfig.key];
                      const valueToCheck = formattedDisplayValue && formattedDisplayValue !== "All"
                        ? formattedDisplayValue
                        : selectedValue;

                      if (isOpening && selectedValue && selectedValue !== "" && !options.includes(valueToCheck) && !options.includes(selectedValue)) {
                        if (typeof dropdownConfig.options === "function") {
                          try {
                            setLoadingOptions(prev => ({
                              ...prev,
                              [dropdownConfig.key]: true,
                            }));
                            const optionsFunction = dropdownConfig.options as (
                              search?: string,
                              offset?: number,
                              limit?: number
                            ) => Promise<{
                              options: string[];
                              hasMore: boolean;
                            }>;
                            const result = await optionsFunction(undefined, 0, 10);

                            if (result && typeof result === "object" && "options" in result && "hasMore" in result) {
                              const typedResult = result as {
                                options: string[];
                                hasMore: boolean;
                              };
                              let optionsToSet = ["All", ...typedResult.options];

                              if (selectedValue && !typedResult.options.includes(valueToCheck) && !typedResult.options.includes(selectedValue) && dropdownConfig.key !== "vendor_nbr") {
                                optionsToSet = [valueToCheck, "All", ...typedResult.options];
                              }

                              setDropdownOptions(prev => ({
                                ...prev,
                                [dropdownConfig.key]: optionsToSet,
                              }));
                              setHasMoreOptions(prev => ({
                                ...prev,
                                [dropdownConfig.key]: typedResult.hasMore,
                              }));
                              setOptionOffsets(prev => ({
                                ...prev,
                                [dropdownConfig.key]: typedResult.options.length,
                              }));
                            }
                          } catch (error) {
                            console.error(`Error reloading options for ${dropdownConfig.key}:`, error);
                          } finally {
                            setLoadingOptions(prev => ({
                              ...prev,
                              [dropdownConfig.key]: false,
                            }));
                          }
                        }
                      }
                    }}
                    className="flex items-center justify-between w-full h-[36px] px-3 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-hidden"
                  >
                    <span className="text-sm">{getDropdownDisplayValue(dropdownConfig)}</span>
                    <svg
                      className={`w-5 h-5 transition-transform duration-200 ${
                        openDropdown === dropdownConfig.key ? "rotate-180" : ""
                      }`}
                      fill="none"
                      stroke="#000000"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  {openDropdown === dropdownConfig.key && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg z-[60]">
                      {renderDropdownOptions(dropdownConfig)}
                    </div>
                  )}
                </div>
              );
            }

            return null;
          })
        ) : (
          <>
            {/* Default Order: Preset Range Filters */}
            {config.presetRanges?.map(presetConfig => (
              <div key={presetConfig.key} className="flex flex-col gap-1 relative">
                <label className="text-sm font-medium text-[#495057] text-nowrap">{presetConfig.label}</label>
                <button
                  onClick={() => setOpenDropdown(openDropdown === presetConfig.key ? null : presetConfig.key)}
                  className="flex items-center justify-between w-full h-[36px] px-3 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-hidden"
                >
                  <span className="text-sm">{getCurrentPresetValue(presetConfig)}</span>
                  <svg
                    className={`w-5 h-5 transition-transform duration-200 ${
                      openDropdown === presetConfig.key ? "rotate-180" : ""
                    }`}
                    fill="none"
                    stroke="#000000"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {openDropdown === presetConfig.key && (
                  <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg z-[60]">
                    {["All", ...Object.keys(presetConfig.presets)].map(option => (
                      <button
                        key={option}
                        onClick={() => handlePresetRangeFilter(presetConfig, option)}
                        className={`block w-full px-4 py-2 text-left text-sm text-ui-text-secondary hover:bg-ui-background-muted ${
                          getCurrentPresetValue(presetConfig) === option
                            ? "bg-ui-background-muted font-semibold text-ui-text-primary"
                            : ""
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {/* Default Order: Range Filters */}
            {resolvedRanges?.map(rangeConfig => (
              <div key={rangeConfig.key} className="flex flex-col gap-1 relative">
                <label className="text-sm font-medium text-[#495057] text-nowrap">{rangeConfig.label}</label>
                <button
                  onClick={() => setOpenDropdown(openDropdown === rangeConfig.key ? null : rangeConfig.key)}
                  className="flex items-center justify-between w-full h-[36px] px-3 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-hidden"
                >
                  <span className="text-sm">
                    {filters[rangeConfig.minKey] ||
                    filters[rangeConfig.maxKey] ||
                    rangeConfig.children?.some(item => filters[item.minKey] || filters[item.maxKey])
                      ? "Custom Range"
                      : "All"}
                  </span>
                  <svg
                    className={`w-5 h-5 transition-transform duration-200 ${
                      openDropdown === rangeConfig.key ? "rotate-180" : ""
                    }`}
                    fill="none"
                    stroke="#000000"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {openDropdown === rangeConfig.key && (
                  <div className="absolute top-full left-0 z-[60] mt-1 w-full max-w-64 bg-white border border-gray-300 rounded-md shadow-lg p-4 overflow-hidden">
                    {!rangeConfig?.children?.length ? (
                      <div className="space-y-4 w-full">
                        <div className="w-full max-w-full">
                          <label className="block text-xs font-medium text-gray-600 mb-3">{rangeConfig.label} Range</label>
                          <div className="w-full max-w-full overflow-hidden">
                            <DualRangeSlider
                              min={rangeConfig.min}
                              max={rangeConfig.max}
                              step={rangeConfig.step || 1}
                              minValue={
                                rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.storeToDisplay(filters[rangeConfig.minKey] ?? rangeConfig.min)
                                  : (filters[rangeConfig.minKey] ?? rangeConfig.min)
                              }
                              maxValue={
                                rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.storeToDisplay(filters[rangeConfig.maxKey] ?? rangeConfig.max)
                                  : (filters[rangeConfig.maxKey] ?? rangeConfig.max)
                              }
                              onMinChange={(_value) => {}}
                              onMaxChange={(_value) => {}}
                              onChangeEnd={(minVal, maxVal) => {
                                const newFilters: any = { ...filters };
                                const minStoreValue = rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.displayToStore(minVal)
                                  : minVal;
                                const maxStoreValue = rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.displayToStore(maxVal)
                                  : maxVal;
                                const defaultMinStoreValue = rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.displayToStore(rangeConfig.min)
                                  : rangeConfig.min;
                                const defaultMaxStoreValue = rangeConfig.valueTransform
                                  ? rangeConfig.valueTransform.displayToStore(rangeConfig.max)
                                  : rangeConfig.max;

                                if (minStoreValue !== defaultMinStoreValue) {
                                  newFilters[rangeConfig.minKey] = minStoreValue;
                                } else {
                                  delete newFilters[rangeConfig.minKey];
                                }

                                if (maxStoreValue !== defaultMaxStoreValue) {
                                  newFilters[rangeConfig.maxKey] = maxStoreValue;
                                } else {
                                  delete newFilters[rangeConfig.maxKey];
                                }

                                setFilters(newFilters);
                              }}
                              debounceMs={500}
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1">From:</label>
                            <input
                              type="number"
                              min={0}
                              max={filters[rangeConfig.maxKey]}
                              value={
                                rangeConfig.valueTransform
                                  ? filters[rangeConfig.minKey]
                                    ? rangeConfig.valueTransform.storeToDisplay(filters[rangeConfig.minKey])
                                    : ""
                                  : filters[rangeConfig.minKey] || ""
                              }
                              onChange={e => {
                                const value = parseFloat(e.target.value);

                                setFilters({
                                  ...filters,
                                  [rangeConfig.minKey]: e.target.value
                                    ? rangeConfig.valueTransform
                                      ? rangeConfig.valueTransform.displayToStore(value)
                                      : value
                                    : null,
                                });
                              }}
                              className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                              placeholder="Min value"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1">To:</label>
                            <input
                              type="number"
                              min={filters[rangeConfig.minKey] || 0}
                              max={rangeConfig.max}
                              value={
                                rangeConfig.valueTransform
                                  ? filters[rangeConfig.maxKey]
                                    ? rangeConfig.valueTransform.storeToDisplay(filters[rangeConfig.maxKey])
                                    : ""
                                  : filters[rangeConfig.maxKey] || ""
                              }
                              onChange={e => {
                                const value = parseFloat(e.target.value);

                                setFilters({
                                  ...filters,
                                  [rangeConfig.maxKey]: e.target.value
                                    ? rangeConfig.valueTransform
                                      ? rangeConfig.valueTransform.displayToStore(value)
                                      : value
                                    : null,
                                });
                              }}
                              className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                              placeholder="Max value"
                            />
                          </div>
                          {shouldRenderRangeWarning(rangeConfig) && (
                            <div className="flex items-center gap-2 col-span-2">
                              <InfoIcon size={20} showTooltip={false} color="var(--Cencora-warning-400-dark, #D97706)" />
                              <span className="text-xs leading-tight">{getRangeWarningMessage(filters, rangeConfig)}</span>
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => {
                            setFilters({
                              ...filters,
                              [rangeConfig.minKey]: null,
                              [rangeConfig.maxKey]: null,
                            });
                          }}
                          className="w-full px-3 py-1 bg-gray-100 text-gray-700 rounded text-sm hover:bg-gray-200"
                        >
                          Clear
                        </button>
                      </div>
                    ) : (
                      rangeConfig?.children?.map((child, index) => (
                        <div key={child.key} className={`space-y-4 w-full ${index === 0 ? "mb-3" : ""}`}>
                          <div className="w-full max-w-full">
                            <label className="block text-xs font-medium text-gray-600 mb-3">{child.label} Range</label>
                            <div className="w-full max-w-full overflow-hidden">
                              <DualRangeSlider
                                min={child.min}
                                max={child.max}
                                step={child.step || 1}
                                minValue={
                                  child.valueTransform
                                    ? child.valueTransform.storeToDisplay(filters[child.minKey] ?? child.min)
                                    : (filters[child.minKey] ?? child.min)
                                }
                                maxValue={
                                  child.valueTransform
                                    ? child.valueTransform.storeToDisplay(filters[child.maxKey] ?? child.max)
                                    : (filters[child.maxKey] ?? child.max)
                                }
                                onMinChange={(_value) => {}}
                                onMaxChange={(_value) => {}}
                                onChangeEnd={(minVal, maxVal) => {
                                  setFilters({
                                    ...filters,
                                    [child.minKey]: child.valueTransform ? child.valueTransform.displayToStore(minVal) : minVal,
                                    [child.maxKey]: child.valueTransform ? child.valueTransform.displayToStore(maxVal) : maxVal,
                                  });
                                }}
                                debounceMs={500}
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-xs font-medium text-gray-600 mb-1">From:</label>
                              <input
                                type="number"
                                min={0}
                                max={filters[child.maxKey]}
                                value={
                                  child.valueTransform
                                    ? filters[child.minKey]
                                      ? child.valueTransform.storeToDisplay(filters[child.minKey])
                                      : ""
                                    : filters[child.minKey] || ""
                                }
                                onChange={e => {
                                  const value = parseFloat(e.target.value);

                                  setFilters({
                                    ...filters,
                                    [child.minKey]: e.target.value
                                      ? child.valueTransform
                                        ? child.valueTransform.displayToStore(value)
                                        : value
                                      : null,
                                  });
                                }}
                                className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                                placeholder="Min value"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-600 mb-1">To:</label>
                              <input
                                type="number"
                                min={filters[child.minKey] || 0}
                                max={child.max}
                                value={
                                  child.valueTransform
                                    ? filters[child.maxKey]
                                      ? child.valueTransform.storeToDisplay(filters[child.maxKey])
                                      : ""
                                    : filters[child.maxKey] || ""
                                }
                                onChange={e => {
                                  const value = parseFloat(e.target.value);

                                  setFilters({
                                    ...filters,
                                    [child.maxKey]: e.target.value
                                      ? child.valueTransform
                                        ? child.valueTransform.displayToStore(value)
                                        : value
                                      : null,
                                  });
                                }}
                                className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                                placeholder="Max value"
                              />
                            </div>
                            {shouldRenderRangeWarning(child) && (
                              <div className="flex items-center gap-2 col-span-2">
                                <InfoIcon size={20} showTooltip={false} color="var(--Cencora-warning-400-dark, #D97706)" />
                                <span className="text-xs leading-tight">{getRangeWarningMessage(filters, child)}</span>
                              </div>
                            )}
                          </div>
                          <button
                            onClick={() => {
                              setFilters({
                                ...filters,
                                [child.minKey]: null,
                                [child.maxKey]: null,
                              });
                            }}
                            className="w-full px-3 py-1 bg-gray-100 text-gray-700 rounded text-sm hover:bg-gray-200"
                          >
                            Clear
                          </button>
                          {index === 0 && <p className="border border-ui-border-primary"></p>}
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            ))}

            {/* Default Order: Dropdown Filters */}
            {config.dropdowns?.map(dropdownConfig => {
              const options = dropdownOptions[dropdownConfig.key] || [];
              const isLoading = loadingOptions[dropdownConfig.key] || false;

              // Ensure selected option is always included in the options list
              const selectedValue = filters[dropdownConfig.key];
              const formattedDisplayValue = displayValues[dropdownConfig.key];
              let displayOptions = [...options];

              // If there's a selected value and it's not in the current options, add it at the top
              if (selectedValue && selectedValue !== "") {
                const valueToCheck = formattedDisplayValue && formattedDisplayValue !== "All"
                  ? formattedDisplayValue
                  : selectedValue;

                if (!options.includes(valueToCheck) && !options.includes(selectedValue)) {
                  displayOptions = [valueToCheck, ...options];
                }
              }

              // Get display value - handle special case for has_no_actions
              const getDisplayValue = () => {
                if (isLoading) return "Loading...";

                if (dropdownConfig.key === "driving_risk") {
                  const value = filters[dropdownConfig.key];
                  if (value == null || value === "") return "All";
                  const val = getEnrichedMetadata(value).display_name || value;
                  return val.length === 0 ? "All" : val;
                }

                if (dropdownConfig.key === "has_no_actions") {
                  const value = filters[dropdownConfig.key];
                  if (value === true) return "Not Reviewed";
                  if (value === false) return "Reviewed";
                  return "All";
                }

                // If there's a selected value, use formatted display value if available (for vendor_nbr etc.)
                if (selectedValue && selectedValue !== "") {
                  const formattedValue = displayValues[dropdownConfig.key];
                  if (formattedValue && formattedValue !== "All") {
                    return formattedValue;
                  }
                  return selectedValue;
                }

                return "All";
              };

              return (
                <div key={dropdownConfig.key} className="flex flex-col gap-1 relative">
                  <label className="text-sm font-medium text-[#495057] text-nowrap">{dropdownConfig.label}</label>
                  <button
                    onClick={async () => {
                      const isOpening = openDropdown !== dropdownConfig.key;
                      setOpenDropdown(openDropdown === dropdownConfig.key ? null : dropdownConfig.key);

                      // Skip reload if search is disabled (all data already loaded)
                      if (dropdownConfig.disableSearch) {
                        return;
                      }

                      // If opening the dropdown and the selected value is not in options, reload
                      const formattedDisplayValueForReload = displayValues[dropdownConfig.key];
                      const valueToCheckForReload = formattedDisplayValueForReload && formattedDisplayValueForReload !== "All"
                        ? formattedDisplayValueForReload
                        : selectedValue;

                      if (isOpening && selectedValue && selectedValue !== "" && !options.includes(valueToCheckForReload) && !options.includes(selectedValue)) {
                        if (typeof dropdownConfig.options === "function") {
                          try {
                            setLoadingOptions(prev => ({
                              ...prev,
                              [dropdownConfig.key]: true,
                            }));
                            const optionsFunction = dropdownConfig.options as (
                              search?: string,
                              offset?: number,
                              limit?: number
                            ) => Promise<{
                              options: string[];
                              hasMore: boolean;
                            }>;
                            const result = await optionsFunction(undefined, 0, 10);

                            if (result && typeof result === "object" && "options" in result && "hasMore" in result) {
                              const typedResult = result as {
                                options: string[];
                                hasMore: boolean;
                              };
                              let optionsToSet = ["All", ...typedResult.options];

                              if (selectedValue && !typedResult.options.includes(valueToCheckForReload) && !typedResult.options.includes(selectedValue) && dropdownConfig.key !== "vendor_nbr") {
                                optionsToSet = [valueToCheckForReload, "All", ...typedResult.options];
                              }

                              setDropdownOptions(prev => ({
                                ...prev,
                                [dropdownConfig.key]: optionsToSet,
                              }));
                              setHasMoreOptions(prev => ({
                                ...prev,
                                [dropdownConfig.key]: typedResult.hasMore,
                              }));
                              setOptionOffsets(prev => ({
                                ...prev,
                                [dropdownConfig.key]: typedResult.options.length,
                              }));
                            }
                          } catch (error) {
                            console.error(`Error reloading options for ${dropdownConfig.key}:`, error);
                          } finally {
                            setLoadingOptions(prev => ({
                              ...prev,
                              [dropdownConfig.key]: false,
                            }));
                          }
                        }
                      }
                    }}
                    className="flex items-center justify-between w-full h-[36px] px-3 bg-white border-2 border-[#E2E8F0] rounded-md hover:border-gray-400 focus:outline-hidden"
                    disabled={isLoading}
                  >
                    <span className="text-sm text-start line-clamp-1">{getDisplayValue()}</span>
                    <svg
                      className={`w-5 h-5 transition-transform duration-200 ${
                        openDropdown === dropdownConfig.key ? "rotate-180" : ""
                      }`}
                      fill="none"
                      stroke="#000000"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  {openDropdown === dropdownConfig.key && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg z-[60]">
                      {displayOptions.map(option => {
                        // Check if this option is selected - handle special case for has_no_actions
                        let isSelected = false;
                        if (dropdownConfig.key === "has_no_actions") {
                          isSelected = (option === "All" && filters[dropdownConfig.key] === undefined) ||
                            (option === "Not Reviewed" && filters[dropdownConfig.key] === true) ||
                            (option === "Reviewed" && filters[dropdownConfig.key] === false);
                        } else {
                          if (dropdownConfig.key === "vendor_nbr" && option.includes(")") && option.startsWith("(")) {
                            const match = option.match(/^\((\d+)\)/);
                            if (match) {
                              const vendorNbrFromOption = match[1];
                              isSelected = filters[dropdownConfig.key] === vendorNbrFromOption || filters[dropdownConfig.key] === option;
                            } else {
                              isSelected = (filters[dropdownConfig.key] || "All") === option;
                            }
                          } else {
                            isSelected = (filters[dropdownConfig.key] || "All") === option;
                          }
                        }

                        return (
                          <button
                            key={option}
                            onClick={() => handleDropdownFilter(dropdownConfig.key, option)}
                            className={`block w-full px-4 py-2 text-left text-sm text-ui-text-secondary hover:bg-ui-background-muted ${
                              isSelected ? "bg-ui-background-muted font-semibold text-ui-text-primary" : ""
                            }`}
                          >
                            {formatOptionLabel(
                              dropdownConfig,
                              option,
                              dropdownConfig.key === "driving_risk"
                                ? r => getEnrichedMetadata(r).display_name || r
                                : undefined
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}

            {/* Date Input Filters */}
            {config.dateInputs?.map(dateInputConfig => (
              <div key={dateInputConfig.key} className="flex flex-col gap-1">
                <CalendarDayPicker
                  title={dateInputConfig.label}
                  value={filters[dateInputConfig.key] ?? ""}
                  onSelectDay={(iso: string | null) => {
                    setFilters({
                      ...filters,
                      [dateInputConfig.key]: iso || null,
                    });
                  }}
                  isDayDisabled={day => dateToISO(day) > dateToISO(getToday())}
                />
              </div>
            ))}
          </>
        )}
      </div>

      {/* Click-outside overlay */}
      {openDropdown && <div className="fixed inset-0 z-10" onClick={() => setOpenDropdown(null)} />}
    </>
  );
}
