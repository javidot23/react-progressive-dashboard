import {
  createElement,
  forwardRef,
  type ComponentPropsWithRef,
  type ComponentPropsWithoutRef,
  type ElementType,
  type HTMLAttributes,
  type ReactElement,
  type Ref,
} from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/** Temporary raw Figma values — replace with CDS tokens when available. */
const CARD_SHADOW_ELEVATED = "shadow-[0_0_16px_0_#00000014,0_0_6px_0_#0000001F]";

const generalCardVariants = cva(
  [
    "group/card @container/card relative w-full min-w-0 max-w-full",
    "rounded-lg text-ui-text-primary",
    "[--card-padding-y:16px]",
    "[--card-padding-x:20px]",
    "[--card-gap:14px]",
    "gap-(--card-gap) py-(--card-padding-y)",
  ].join(" "),
  {
    variants: {
      variant: {
        outlined: "border border-ui-border-primary bg-white",
        elevated: `border-0 bg-white ${CARD_SHADOW_ELEVATED}`,
        flat: `border-0 bg-white shadow-none has-[>[data-slot=general-card-action-area]]:${CARD_SHADOW_ELEVATED}`,
      },
      orientation: {
        vertical: "flex flex-col",
        horizontal: "grid grid-cols-[repeat(auto-fit,minmax(min(100%,16rem),1fr))] py-0",
      },
    },
    defaultVariants: {
      variant: "flat",
      orientation: "vertical",
    },
  }
);

type AsProp<C extends ElementType> = {
  as?: C;
};

type PropsToOmit<C extends ElementType, P> = keyof (AsProp<C> & P);

type PolymorphicComponentProp<C extends ElementType, Props = object> = Props &
  AsProp<C> &
  Omit<ComponentPropsWithoutRef<C>, PropsToOmit<C, Props>>;

type PolymorphicRef<C extends ElementType> = ComponentPropsWithRef<C>["ref"];

type PolymorphicComponentPropWithRef<C extends ElementType, Props = object> = PolymorphicComponentProp<C, Props> & {
  ref?: PolymorphicRef<C>;
};

type GeneralCardVariantProps = VariantProps<typeof generalCardVariants>;

export type GeneralCardProps<C extends ElementType = "div"> = PolymorphicComponentPropWithRef<C, GeneralCardVariantProps>;

type GeneralCardComponent = <C extends ElementType = "div">(props: GeneralCardProps<C>) => ReactElement | null;

const GeneralCardBase = (
  { className, variant = "flat", orientation = "vertical", as, ...props }: GeneralCardProps & { as?: ElementType },
  ref: Ref<HTMLElement>
) => {
  const Component = (as || "div") as ElementType;

  return createElement(Component, {
    ...props,
    ref,
    "data-slot": "general-card",
    "data-variant": variant ?? "flat",
    "data-orientation": orientation ?? "vertical",
    className: cn(generalCardVariants({ variant, orientation }), className),
  });
};

export const GeneralCard = forwardRef(GeneralCardBase) as unknown as GeneralCardComponent & { displayName?: string };

GeneralCard.displayName = "GeneralCard";

export const GeneralCardHeader = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    {...props}
    data-slot="general-card-header"
    className={cn(
      [
        "group/card-header @container/card-header grid auto-rows-min items-start",
        "gap-1.5 px-(--card-padding-x)",
        "has-data-[slot=general-card-action]:grid-cols-1",
        "has-data-[slot=general-card-action]:@sm/card:grid-cols-[minmax(0,1fr)_auto]",
        "has-data-[slot=general-card-action]:@sm/card:items-start",
        "has-data-[slot=general-card-description]:grid-rows-[auto_auto]",
      ].join(" "),
      className
    )}
  />
));

GeneralCardHeader.displayName = "GeneralCardHeader";

type GeneralCardTitleHeading = "h1" | "h2" | "h3" | "h4" | "h5" | "h6";

export type GeneralCardTitleProps<C extends GeneralCardTitleHeading = "h3"> = PolymorphicComponentPropWithRef<C>;

type GeneralCardTitleComponent = <C extends GeneralCardTitleHeading = "h3">(
  props: GeneralCardTitleProps<C>
) => ReactElement | null;

const GeneralCardTitleBase = (
  { className, as, ...props }: GeneralCardTitleProps & { as?: GeneralCardTitleHeading },
  ref: Ref<HTMLHeadingElement>
) => {
  const Component = (as || "h3") as GeneralCardTitleHeading;

  return createElement(Component, {
    ...props,
    ref,
    "data-slot": "general-card-title",
    className: cn("min-w-0 text-lg font-semibold leading-snug tracking-tight text-ui-text-heading", className),
  });
};

export const GeneralCardTitle = forwardRef(GeneralCardTitleBase) as unknown as GeneralCardTitleComponent & {
  displayName?: string;
};

GeneralCardTitle.displayName = "GeneralCardTitle";

export const GeneralCardDescription = forwardRef<HTMLParagraphElement, HTMLAttributes<HTMLParagraphElement>>(
  ({ className, ...props }, ref) => (
    <p
      ref={ref}
      {...props}
      data-slot="general-card-description"
      className={cn("min-w-0 text-sm text-ui-text-secondary wrap-break-word", className)}
    />
  )
);

GeneralCardDescription.displayName = "GeneralCardDescription";

export const GeneralCardAction = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    {...props}
    data-slot="general-card-action"
    className={cn(
      [
        "flex shrink-0 flex-wrap items-center gap-2",
        "justify-start @sm/card:col-start-2 @sm/card:row-span-2 @sm/card:row-start-1",
        "@sm/card:justify-end @sm/card:self-start",
      ].join(" "),
      className
    )}
  />
));

GeneralCardAction.displayName = "GeneralCardAction";

export const GeneralCardSection = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    {...props}
    data-slot="general-card-section"
    className={cn(
      [
        "min-w-0",
        "group-data-[orientation=horizontal]/card:flex",
        "group-data-[orientation=horizontal]/card:flex-col",
        "group-data-[orientation=horizontal]/card:gap-(--card-gap)",
        "group-data-[orientation=horizontal]/card:py-(--card-padding-y)",
      ].join(" "),
      className
    )}
  />
));

GeneralCardSection.displayName = "GeneralCardSection";

export const GeneralCardMedia = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    {...props}
    data-slot="general-card-media"
    className={cn(
      [
        "relative overflow-hidden",
        // Cancel root padding only at the card edges; keep gap mid-card.
        "group-data-[orientation=vertical]/card:first:-mt-(--card-padding-y)",
        "group-data-[orientation=vertical]/card:first:rounded-t-lg",
        "group-data-[orientation=vertical]/card:last:-mb-(--card-padding-y)",
        "group-data-[orientation=vertical]/card:last:rounded-b-lg",
        "group-data-[orientation=horizontal]/card:rounded-lg",
        "[&>img]:block [&>img]:h-auto [&>img]:w-full [&>img]:object-cover",
        "group-data-[orientation=horizontal]/card:[&>img]:h-full",
      ].join(" "),
      className
    )}
  />
));

GeneralCardMedia.displayName = "GeneralCardMedia";

export const GeneralCardContent = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => (
  <div ref={ref} {...props} data-slot="general-card-content" className={cn("min-w-0 px-(--card-padding-x)", className)} />
));

GeneralCardContent.displayName = "GeneralCardContent";

export const GeneralCardFooter = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    {...props}
    data-slot="general-card-footer"
    className={cn(
      ["mt-auto flex flex-col gap-2 px-(--card-padding-x)", "@sm/card:flex-row @sm/card:flex-wrap @sm/card:items-center"].join(
        " "
      ),
      className
    )}
  />
));

GeneralCardFooter.displayName = "GeneralCardFooter";

export type GeneralCardActionAreaProps<C extends ElementType = "button"> = PolymorphicComponentPropWithRef<C>;

type GeneralCardActionAreaComponent = <C extends ElementType = "button">(
  props: GeneralCardActionAreaProps<C>
) => ReactElement | null;

const GeneralCardActionAreaBase = (
  { className, as, ...props }: GeneralCardActionAreaProps & { as?: ElementType },
  ref: Ref<HTMLElement>
) => {
  const Component = (as || "button") as ElementType;
  const defaultButtonProps = Component === "button" && !("type" in props) ? { type: "button" } : {};

  return createElement(Component, {
    ...defaultButtonProps,
    ...props,
    ref,
    "data-slot": "general-card-action-area",
    className: cn(
      [
        "-my-(--card-padding-y) flex min-w-0 flex-1 cursor-pointer appearance-none",
        "flex-col gap-(--card-gap) rounded-lg border-0 bg-transparent",
        "py-(--card-padding-y) text-start font-inherit text-inherit",
        "focus-visible:outline-2 focus-visible:outline-offset-2",
        "focus-visible:outline-ui-border-focus",
        "disabled:cursor-not-allowed disabled:opacity-50",
      ].join(" "),
      className
    ),
  });
};

export const GeneralCardActionArea = forwardRef(GeneralCardActionAreaBase) as unknown as GeneralCardActionAreaComponent & {
  displayName?: string;
};

GeneralCardActionArea.displayName = "GeneralCardActionArea";

export { generalCardVariants };
