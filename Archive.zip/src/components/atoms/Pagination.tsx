import React, { useMemo, useState, useEffect } from "react";
import { useTableSettings } from "@/components/atoms/TableSettings";

interface PaginationProps {
  currentPage: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  itemName?: string; // e.g., "Suppliers", "Purchase Orders by Material", "Issues"
  showPageSizeSelect?: boolean;
  /** Allowed page-size options to display in the dropdown */
  pageSizeOptions?: number[];
  className?: string;
  isLoading?: boolean; // For pagination controls only, doesn't affect table content
}

export const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  itemName = "items",
  showPageSizeSelect = true,
  pageSizeOptions,
  className = "",
  isLoading = false,
}) => {
  const tableSettings = useTableSettings();
  const updateSettings = tableSettings?.updateSettings;

  // Safe defaults to prevent crashes
  const safeCurrentPage = Math.max(1, currentPage || 1);
  const safePageSize = Math.max(1, pageSize || 10);
  const safeTotal = Math.max(0, total || 0);

  const [goToPageInput, setGoToPageInput] = useState(safeCurrentPage);
  const pageCount = Math.max(1, Math.ceil(safeTotal / safePageSize));

  // Keep goToPageInput in sync with current page
  useEffect(() => {
    setGoToPageInput(safeCurrentPage);
  }, [safeCurrentPage]);

  // Go to page helper
  const goToPage = (page: number) => {
    const clampedPage = Math.min(Math.max(page, 1), pageCount);
    if (onPageChange && clampedPage !== safeCurrentPage) {
      onPageChange(clampedPage);
    }
  };

  // Detect mobile size for conditional rendering
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 640);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // Pages to show (with ellipsis) - responsive window size
  const pagesToShow = useMemo(() => {
    const pages: (number | "...")[] = [];
    const add = (n: number | "...") => {
      if (pages[pages.length - 1] === n) return;
      pages.push(n);
    };

    // Responsive: fewer pages on mobile
    const maxVisiblePages = isMobile ? 3 : 5;
    const windowSize = isMobile ? 0 : 2;

    if (pageCount <= maxVisiblePages) {
      // Show all pages if we have few pages
      for (let i = 1; i <= pageCount; i++) add(i);
    } else {
      const start = Math.max(1, safeCurrentPage - windowSize);
      const end = Math.min(pageCount, safeCurrentPage + windowSize);

      add(1);
      if (start > 2) add("...");
      for (let i = start; i <= end; i++) add(i);
      if (end < pageCount - 1) add("...");
      if (pageCount > 1) add(pageCount);
    }

    return pages;
  }, [safeCurrentPage, pageCount, isMobile]);

  const startIndex = (safeCurrentPage - 1) * safePageSize + 1;
  const endIndex = Math.min(safeCurrentPage * safePageSize, safeTotal);

  return (
    <div className={`flex flex-col gap-4 py-4 px-2 sm:px-0 bg-white ${className}`}>
      {/* Top Row */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-6 pl-6">
        <div className="font-sans font-bold text-[14px] leading-[22.4px] text-[#6E6E6E] min-w-0">
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-gray-300 border-t-brand-primary-main"></div>
              <span>Loading...</span>
            </div>
          ) : (
            `Showing ${startIndex}-${endIndex} of ${safeTotal} ${itemName}`
          )}
        </div>

        {showPageSizeSelect && (
          <div className="flex items-center gap-2 font-sans text-[14px] text-ui-text-secondary">
            <span>Show:</span>
            <select
              className="
                w-10 h-10
                rounded-md border border-gray-300
                bg-white text-ui-text-primary text-center text-[14px]
                focus:outline-hidden focus:ring-2 focus:ring-brand-primary-main focus:border-transparent
              "
              value={safePageSize}
              onChange={e => {
                const val = Number(e.target.value);
                if (!Number.isNaN(val) && val > 0) {
                  updateSettings?.({ pageSize: val });
                  onPageSizeChange(val);
                }
              }}
            >
              {(() => {
                const baseOptions = pageSizeOptions?.length ? pageSizeOptions : [10, 14, 20, 30];
                const options = [...new Set(baseOptions)].sort((a, b) => a - b);

                // Ensure the current page size is always selectable (avoid value not in list).
                if (!options.includes(safePageSize)) options.unshift(safePageSize);
                // If total is less than 10, add it as an option to avoid empty box appearance
                if (safeTotal > 0 && safeTotal < 10 && !options.includes(safeTotal)) {
                  options.unshift(safeTotal);
                }
                return options
                  .filter(opt => opt <= safeTotal || safeTotal === 0)
                  .map(opt => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ));
              })()}
            </select>
            <span>per page</span>
          </div>
        )}
      </div>

      {/* Bottom Row - page controls and go-to stay grouped; wrap on narrow screens */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-3 pl-6">
        <div className="flex flex-wrap items-center gap-2 text-[14px]">
          <button
            type="button"
            onClick={() => goToPage(safeCurrentPage - 1)}
            disabled={safeCurrentPage === 1}
            className={`w-[72px] px-3 py-2 rounded-md border flex items-center justify-center ${
              safeCurrentPage === 1 ? "opacity-50 cursor-not-allowed" : "hover:bg-ui-background-muted"
            }`}
          >
            ← Prev
          </button>

          {isMobile ? (
            <div className="w-10 h-10 rounded-md border flex items-center justify-center bg-brand-primary-main text-white border-brand-primary-main">
              {safeCurrentPage}
            </div>
          ) : (
            pagesToShow.map((p, idx) =>
              p === "..." ? (
                <span key={`e-${idx}`} className="w-10 h-10 flex items-center justify-center">
                  …
                </span>
              ) : (
                <button
                  key={p}
                  type="button"
                  onClick={() => goToPage(p as number)}
                  className={`w-10 h-10 rounded-md border flex items-center justify-center ${
                    p === safeCurrentPage
                      ? "bg-brand-primary-main text-white border-brand-primary-main"
                      : "hover:bg-ui-background-muted"
                  }`}
                  aria-current={p === safeCurrentPage ? "page" : undefined}
                >
                  {p}
                </button>
              )
            )
          )}

          <button
            type="button"
            onClick={() => goToPage(safeCurrentPage + 1)}
            disabled={safeCurrentPage === pageCount}
            className={`w-[72px] px-3 py-2 rounded-md border flex items-center justify-center ${
              safeCurrentPage === pageCount ? "opacity-50 cursor-not-allowed" : "hover:bg-ui-background-muted"
            }`}
          >
            Next →
          </button>
        </div>

        <div className="flex items-center gap-2 text-[14px] text-ui-text-secondary shrink-0">
          <span>Go to:</span>
          <input
            type="number"
            min={1}
            max={pageCount}
            value={goToPageInput}
            onChange={e => {
              const val = Number(e.target.value);
              if (!Number.isNaN(val)) {
                setGoToPageInput(val);
              }
            }}
            onKeyDown={e => {
              if (e.key === "Enter") goToPage(goToPageInput);
            }}
            className="
              h-10 w-20
              border border-gray-300 rounded-md
              text-ui-text-primary text-center text-[14px]
              bg-white
              focus:outline-hidden focus:ring-2 focus:ring-brand-primary-main focus:border-transparent
            "
          />
          <button
            type="button"
            onClick={() => goToPage(goToPageInput)}
            className="w-10 h-10 rounded-md border bg-brand-primary-main text-white border-brand-primary-main hover:opacity-90 text-[14px] flex items-center justify-center"
          >
            Go
          </button>
        </div>
      </div>
    </div>
  );
};

export default Pagination;
