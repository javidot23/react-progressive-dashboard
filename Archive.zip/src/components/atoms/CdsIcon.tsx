import React from "react";

interface CdsIconProps {
  name: string;
  library?: "cds-ui" | "cds-ui-regular" | "cds-ui-semibold" | "cds-expressive";
  size?: "2xs" | "xs" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl" | "4xl" | "5xl" | "6xl" | "7xl";
  className?: string;
  label?: string;
  color?: string;
}

const CdsIcon: React.FC<CdsIconProps> = ({ name, library = "cds-ui", size, className = "", label, color }) => {
  const iconProps: any = {
    name,
    library,
    className,
  };

  if (size) {
    iconProps.size = size;
  }

  if (label) {
    iconProps.label = label;
  }

  if (color) {
    iconProps.style = { color };
  }

  return React.createElement("sl-icon", iconProps);
};

export default CdsIcon;
