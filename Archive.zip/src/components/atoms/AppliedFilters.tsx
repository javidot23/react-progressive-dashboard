import { JSX } from "react";
import SortIcon from "@/assets/icons/asc-icon.svg";
import { formatNumber } from "@/lib/vendorUtils";
import { useRiskModelDescriptions } from "@/hooks";
import { DEFAULT_DC_PLANTS_ORDERING } from "@/lib/inventoryFilterUtils";
import { formatDohZoneAppliedFilterDisplay } from "@/hooks/manage/inventory/top-materials-outside-threshold";

const INVENTORY_DOH_ZONE_FILTER_KEYS = ["active_doh_zone", "doh_days_min", "doh_days_max"] as const;

function isInventoryDohZoneFilterKey(key: string): boolean {
  return (INVENTORY_DOH_ZONE_FILTER_KEYS as readonly string[]).includes(key);
}

function clearInventoryDohZoneFilters(filters: Record<string, unknown>): Record<string, unknown> {
  return {
    ...filters,
    active_doh_zone: null,
    doh_days_min: null,
    doh_days_max: null,
  };
}

export interface FilterLabels {
  [key: string]: string;
}

export interface FieldLabels {
  [key: string]: string;
}

const RiskType = { PRIMARY: "primary_risk", DRIVING: "driving_risk" } as const;

export interface LookupByFilterKeyEntry {
  items: any[];
  idKey: string;
  nameKey: string;
  showIdInLabel?: boolean;
}

export interface AppliedFiltersConfig {
  filterLabels: FilterLabels;
  fieldLabels: FieldLabels;
  defaultFilters: any;
  riskRatingRanges?: Record<string, { min: number; max: number }>;
  lookupItems?: any[];
  lookupKey?: string;
  lookupNameKey?: string;
  lookupByFilterKey?: Record<string, LookupByFilterKeyEntry>;
  dateRangePairs?: Array<{ fromKey: string; toKey: string; label: string }>;
}

export interface AppliedFiltersProps {
  filters: any;
  setFilters: (filters: any) => void;
  config: AppliedFiltersConfig;
  /** When false, the "Clear all Filters" button is hidden regardless of active filters */
  showClearAllButton?: boolean;
}

export default function AppliedFilters({ filters, setFilters, config, showClearAllButton = true }: AppliedFiltersProps) {
  const { getEnrichedMetadata } = useRiskModelDescriptions();

  const usesRiskRatingPresets = (baseKey: string) =>
    Boolean(config.riskRatingRanges && (baseKey === "risk_rating" || baseKey === "effective_risk_rating"));

  const getRiskRatingPresetLabel = (minValue: unknown, maxValue: unknown) => {
    if (!config.riskRatingRanges) return null;
    for (const [rangeName, range] of Object.entries(config.riskRatingRanges)) {
      if (minValue === range.min && maxValue === range.max) {
        return `Risk Score: ${rangeName}`;
      }
    }
    return null;
  };

  const getFilterDisplayName = (key: string, value: any): string | JSX.Element => {
    const label = config.filterLabels[key] || key;

    if (key === "ordering" || key === "dc_plants_ordering") {
      // Handle comma-separated ordering values (e.g., "-risk_rating,-risk_adjusted_value")
      const firstOrdering = value.split(",")[0];
      const isDesc = firstOrdering.startsWith("-");
      const field = isDesc ? firstOrdering.substring(1) : firstOrdering;
      const fieldLabel = config.fieldLabels[field] || field;
      return (
        <span className="inline-flex items-center gap-1">
          {label}: {fieldLabel}
          <img
            src={SortIcon}
            alt={isDesc ? "Descending" : "Ascending"}
            className={`w-3.5 h-3.5 transition-transform duration-200 ${isDesc ? "rotate-180" : ""}`}
          />
        </span>
      );
    }

    if (key === "risk_rating_min" || key === "risk_rating_max") {
      const presetLabel = getRiskRatingPresetLabel(filters.risk_rating_min, filters.risk_rating_max);
      if (presetLabel) return presetLabel;
      return `${label}: ${value}`;
    }

    if (key === "effective_risk_rating_min" || key === "effective_risk_rating_max") {
      const presetLabel = getRiskRatingPresetLabel(
        filters.effective_risk_rating_min,
        filters.effective_risk_rating_max
      );
      if (presetLabel) return presetLabel;
      return `${label}: ${value}`;
    }

    if (key.includes("_min")) {
      // Handle percentage fields (OTIF, Outbound Fill Rate, Inbound Fill Rate, ASN Timeliness, ASN Essential, Product Damage Rate, and Product Families OTIF/Outbound Fill Rate)
      if (
        key.includes("otif") ||
        key.includes("outbound") ||
        key.includes("inbound_fill_rate") ||
        key.includes("asn_timeliness") ||
        key.includes("asn_essential") ||
        key.includes("product_damages_rate") ||
        key.includes("average_otif") ||
        key.includes("average_outbound_fill_rate")
      ) {
        return `${label}: ≥ ${Math.round(Number(value) * 100)}%`;
      }
      // Handle perfect order rate (already in percentage format)
      if (key.includes("perfect_order_rate")) {
        return `${label}: ≥ ${Number(value).toFixed(2)}%`;
      }
      // Handle delivery deviation
      if (key.includes("deviation")) {
        const formatDeviation = (num: number) => {
          return num >= 0 ? `+${num.toFixed(2)}` : num.toFixed(2);
        };
        return `${label}: ≥ ${formatDeviation(Number(value))}`;
      }
      // Handle PO quantity with number formatting
      if (key.includes("po_quantity")) {
        const formatNumber = (num: number) => {
          if (num >= 1000000) {
            const millions = num / 1000000;
            return millions % 1 === 0 ? millions + "M" : millions.toFixed(2) + "M";
          } else if (num >= 1000) {
            const thousands = num / 1000;
            return thousands % 1 === 0 ? thousands + "k" : thousands.toFixed(2) + "k";
          }
          return num.toString();
        };
        return `${label}: ≥ ${formatNumber(Number(value))}`;
      }
      return `${label}: ≥ ${formatNumber(value)}`;
    }

    if (key.includes("_max")) {
      // Handle percentage fields (OTIF, Outbound Fill Rate, Inbound Fill Rate, ASN Timeliness, ASN Essential, Product Damage Rate, and Product Families OTIF/Outbound Fill Rate)
      if (
        key.includes("otif") ||
        key.includes("outbound") ||
        key.includes("inbound_fill_rate") ||
        key.includes("asn_timeliness") ||
        key.includes("asn_essential") ||
        key.includes("product_damages_rate") ||
        key.includes("average_otif") ||
        key.includes("average_outbound_fill_rate")
      ) {
        return `${label}: ≤ ${Math.round(Number(value) * 100)}%`;
      }
      // Handle perfect order rate (already in percentage format)
      if (key.includes("perfect_order_rate")) {
        return `${label}: ≤ ${Number(value).toFixed(2)}%`;
      }
      // Handle delivery deviation
      if (key.includes("deviation")) {
        const formatDeviation = (num: number) => {
          return num >= 0 ? `+${num.toFixed(2)}` : num.toFixed(2);
        };
        return `${label}: ≤ ${formatDeviation(Number(value))}`;
      }
      // Handle PO quantity with number formatting
      if (key.includes("po_quantity")) {
        const formatNumber = (num: number) => {
          if (num >= 1000000) {
            const millions = num / 1000000;
            return millions % 1 === 0 ? millions + "M" : millions.toFixed(2) + "M";
          } else if (num >= 1000) {
            const thousands = num / 1000;
            return thousands % 1 === 0 ? thousands + "k" : thousands.toFixed(2) + "k";
          }
          return num.toString();
        };
        return `${label}: ≤ ${formatNumber(Number(value))}`;
      }
      return `${label}: ≤ ${formatNumber(value)}`;
    }

    if (key === RiskType.PRIMARY || key === RiskType.DRIVING) {
      return `${label}: ${getEnrichedMetadata(value).display_name || value}`;
    }

    if (key === "has_no_actions") {
      return `${label}: ${value === true ? "Not Reviewed" : "Reviewed"}`;
    }

    if (key === "active_doh_zone") {
      return `${label}: ${formatDohZoneAppliedFilterDisplay(value, filters.doh_days_min, filters.doh_days_max)}`;
    }

    // Handle per-filter-key lookups (e.g. mat_nbr, vendor_nbr, plant_nbr, cust_corp_chain_nbr)
    const lookupEntry = config.lookupByFilterKey?.[key];
    if (lookupEntry) {
      const item = lookupEntry.items.find((item: any) => item[lookupEntry.idKey] === value);
      if (item) {
        const name = item[lookupEntry.nameKey] ?? value;
        const display = lookupEntry.showIdInLabel ? `(${value}) ${name}` : name;
        return `${label}: ${display}`;
      }
      return `${label}: ${value}`;
    }

    // Handle legacy single lookup (materials, vendors, plants, customers, etc.)
    if (config.lookupItems && config.lookupKey && config.lookupNameKey && key === config.lookupKey) {
      const item = config.lookupItems.find((item: any) => item[config.lookupKey!] === value);
      if (item) {
        // For materials (mat_nbr), include mat_nbr before name like global filters
        if (key === "mat_nbr" && item.mat_nbr) {
          return `${label}: (${item.mat_nbr}) ${item[config.lookupNameKey!] || value}`;
        }
        return `${label}: ${item[config.lookupNameKey!] || value}`;
      }
      return `${label}: ${value}`;
    }

    return `${label}: ${value}`;
  };

  const removeFilter = (key: string) => {
    const newFilters = { ...filters };

    if (key.endsWith("_min") || key.endsWith("_max")) {
      const baseKey = getRangeBase(key);
      const minKey = `${baseKey}_min`;
      const maxKey = `${baseKey}_max`;

      // Check if this is a risk rating filter that matches a preset range
      if (usesRiskRatingPresets(baseKey) && config.riskRatingRanges) {
        const minValue = filters[minKey];
        const maxValue = filters[maxKey];

        // Check if both min and max match a preset range
        let matchesPresetRange = false;
        for (const range of Object.values(config.riskRatingRanges)) {
          if (minValue === range.min && maxValue === range.max) {
            matchesPresetRange = true;
            break;
          }
        }

        // If it matches a preset range, remove both min and max together
        if (matchesPresetRange) {
          newFilters[minKey] = null;
          newFilters[maxKey] = null;
        } else {
          // Otherwise, only remove the specific one clicked
          newFilters[key] = null;
        }
      } else {
        // For other range filters, only remove the specific one clicked
        newFilters[key] = null;
      }
    } else if (key === "ordering") {
      newFilters.ordering = config.defaultFilters.ordering || "name";
    } else if (key === "dc_plants_ordering") {
      newFilters.dc_plants_ordering = config.defaultFilters.dc_plants_ordering ?? DEFAULT_DC_PLANTS_ORDERING;
    } else if (key === "has_no_actions") {
      newFilters[key] = undefined;
    } else if (isInventoryDohZoneFilterKey(key)) {
      Object.assign(newFilters, clearInventoryDohZoneFilters(newFilters));
    } else if (typeof newFilters[key] === "string") {
      newFilters[key] = "";
    } else {
      newFilters[key] = null;
    }

    setFilters(newFilters);
  };

  const activeFilters: Array<{
    key: string;
    value: any;
    displayName: string | JSX.Element;
    isSorting: boolean;
  }> = [];

  // Helper function to check if a key is a range filter
  const isRangeFilter = (key: string) => key.endsWith("_min") || key.endsWith("_max");
  const getRangeBase = (key: string) => key.replace(/_min$|_max$/, "");

  // First, collect all range filters by their base key
  const rangeFilters = new Map<string, { minKey: string; maxKey: string; minValue: any; maxValue: any }>();

  // Collect all range filter pairs
  Object.entries(filters).forEach(([key]) => {
    if (isRangeFilter(key)) {
      const baseKey = getRangeBase(key);
      if (!rangeFilters.has(baseKey)) {
        const minKey = `${baseKey}_min`;
        const maxKey = `${baseKey}_max`;
        rangeFilters.set(baseKey, {
          minKey,
          maxKey,
          minValue: filters[minKey],
          maxValue: filters[maxKey],
        });
      }
    }
  });

  const activeDohZone =
    filters.active_doh_zone !== null && filters.active_doh_zone !== undefined && filters.active_doh_zone !== ""
      ? filters.active_doh_zone
      : null;

  // Process range filters
  rangeFilters.forEach(({ minKey, maxKey, minValue, maxValue }) => {
    const baseKey = getRangeBase(minKey);
    if (activeDohZone && baseKey === "doh_days") {
      return;
    }

    const hasMinValue = minValue !== null && minValue !== undefined && minValue !== "";
    const hasMaxValue = maxValue !== null && maxValue !== undefined && maxValue !== "";

    // Show the range filter if either min or max has a value
    if (hasMinValue || hasMaxValue) {
      // Check if this is a risk rating filter that matches a preset range
      const baseKey = getRangeBase(minKey);
      let matchesPresetRange = false;
      let presetRangeName = "";

      if (usesRiskRatingPresets(baseKey) && config.riskRatingRanges && hasMinValue && hasMaxValue) {
        for (const [rangeName, range] of Object.entries(config.riskRatingRanges)) {
          if (minValue === range.min && maxValue === range.max) {
            matchesPresetRange = true;
            presetRangeName = rangeName;
            break;
          }
        }
      }

      // If both values exist and match a preset range, show as a single filter
      if (hasMinValue && hasMaxValue && matchesPresetRange) {
        // Add as a single filter with a special key that represents both min and max
        // Use minKey as the key, but we'll handle removal of both in removeFilter
        if (config.filterLabels[minKey] && config.filterLabels[minKey] !== "") {
          activeFilters.push({
            key: minKey, // Use minKey, but removal will handle both
            value: `${minValue}-${maxValue}`, // Store both values for reference
            displayName: `Risk Score: ${presetRangeName}`,
            isSorting: false,
          });
        }
      } else if (hasMinValue && hasMaxValue) {
        // Both values exist but don't match a preset range, show both as separate filters
        // Add min filter
        if (config.filterLabels[minKey] && config.filterLabels[minKey] !== "") {
          activeFilters.push({
            key: minKey,
            value: minValue,
            displayName: getFilterDisplayName(minKey, minValue),
            isSorting: false,
          });
        }
        // Add max filter
        if (config.filterLabels[maxKey] && config.filterLabels[maxKey] !== "") {
          activeFilters.push({
            key: maxKey,
            value: maxValue,
            displayName: getFilterDisplayName(maxKey, maxValue),
            isSorting: false,
          });
        }
      } else {
        // Only one value exists, show that one
        const displayKey = hasMinValue ? minKey : maxKey;
        const displayValue = hasMinValue ? minValue : maxValue;

        // Only add if the filter label exists (not empty)
        if (config.filterLabels[displayKey] && config.filterLabels[displayKey] !== "") {
          activeFilters.push({
            key: displayKey,
            value: displayValue,
            displayName: getFilterDisplayName(displayKey, displayValue),
            isSorting: false,
          });
        }
      }
    }
  });

  if (activeDohZone && config.filterLabels.active_doh_zone) {
    activeFilters.push({
      key: "active_doh_zone",
      value: activeDohZone,
      displayName: getFilterDisplayName("active_doh_zone", activeDohZone),
      isSorting: false,
    });
  }

  // Process non-range filters
  Object.entries(filters).forEach(([key, value]) => {
    if (activeDohZone && isInventoryDohZoneFilterKey(key)) {
      return;
    }

    if (
      value !== null &&
      value !== "" &&
      value !== undefined &&
      config.filterLabels[key] !== "" && // Skip filters with empty labels
      !isRangeFilter(key) // Skip range filters (already processed above)
    ) {
      activeFilters.push({
        key,
        value,
        displayName: getFilterDisplayName(key, value),
        isSorting: key === "ordering" || key === "dc_plants_ordering",
      });
    }
  });

  const clearAllFilters = () => {
    setFilters({ ...config.defaultFilters });
  };

  // Check if any filters are different from default
  const hasNonDefaultFilters = () => {
    return Object.entries(filters).some(([key, value]) => {
      const defaultValue = config.defaultFilters[key];
      if (key === "ordering" || key === "dc_plants_ordering") {
        return value !== defaultValue;
      }
      if (isRangeFilter(key)) {
        return value !== null && value !== undefined && value !== "";
      }
      return value !== defaultValue && value !== null && value !== "" && value !== undefined;
    });
  };

  const filteredActiveFilters = Array.from(new Map(activeFilters.map(item => [item.displayName, item])).values())
    .sort((a, b) => (a.isSorting === b.isSorting ? 0 : a.isSorting ? -1 : 1));

  return (
    <div className="space-y-3" data-testid="applied-filters">
      {/* Clear All Filters Button */}
      {showClearAllButton !== false && hasNonDefaultFilters() && (
        <div className="flex justify-end">
          <button
            onClick={clearAllFilters}
            className="px-3 py-1 hover:bg-purple-50 text-brand-primary-main border-2 border-brand-primary-main font-bold text-sm rounded-md cursor-pointer transition-colors"
            title="Clear all applied filters"
          >
            Clear all Filters
          </button>
        </div>
      )}

      {/* Applied Filter Cards Row */}
      <div className="flex gap-2 flex-wrap">
        {filteredActiveFilters.map(({ key, displayName, isSorting }) => {
          const isDefaultOrdering = key === "ordering" && filters[key] === config.defaultFilters.ordering;
          const showRemoveButton = !isSorting || !isDefaultOrdering;

          return (
            <div
              key={key}
              data-testid={`applied-filter-${key}`}
              className="bg-brand-primary-50 text-brand-primary-main border border-brand-primary-200 border-2 text-sm px-2 py-1 rounded-md flex items-center gap-1 space-x-2"
            >
              <span className="font-bold text-sm">{displayName}</span>
              {showRemoveButton && (
                <button
                  data-testid={`remove-filter-${key}`}
                  onClick={() => removeFilter(key)}
                  className="text-sm font-bold"
                  title="Remove filter"
                >
                  ✕
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
