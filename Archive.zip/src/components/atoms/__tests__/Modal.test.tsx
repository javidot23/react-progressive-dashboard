import "@testing-library/jest-dom";
import { useRef, useState } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Modal } from "@/components/atoms/Modal";
import { ModalShell } from "@/components/atoms/ModalShell";
import { resetBodyScrollLockForTests } from "@/hooks/useBodyScrollLock";

function OpenModalHarness({ onClose }: { onClose: () => void }) {
  return (
    <Modal isOpen onClose={onClose} title="Test dialog">
      <button type="button">First focusable</button>
    </Modal>
  );
}

function OpenShellHarness({
  onClose,
  closeOnEscape,
  usePortal = false,
}: {
  onClose: () => void;
  closeOnEscape?: boolean;
  usePortal?: boolean;
}) {
  return (
    <ModalShell
      isOpen
      onClose={onClose}
      ariaLabelledBy="shell-title"
      closeOnEscape={closeOnEscape}
      usePortal={usePortal}
      overlayClassName="fixed inset-0 flex items-center justify-center"
    >
      <div className="bg-white p-4 rounded">
        <h2 id="shell-title">Shell dialog</h2>
        <button type="button">Inside shell</button>
      </div>
    </ModalShell>
  );
}

function ClosablePortalHarness({ closeLabel = "Close dialog" }: { closeLabel?: string }) {
  const triggerRef = useRef<HTMLButtonElement>(null);
  const [isOpen, setIsOpen] = useState(true);

  return (
    <>
      <button ref={triggerRef} type="button">
        Open modal
      </button>
      {isOpen ? (
        <ModalShell
          isOpen
          onClose={() => setIsOpen(false)}
          ariaLabelledBy="shell-title"
          usePortal
          triggerRef={triggerRef}
        >
          <div className="bg-white p-4 rounded">
            <h2 id="shell-title">Shell dialog</h2>
            <button type="button" onClick={() => setIsOpen(false)}>
              {closeLabel}
            </button>
          </div>
        </ModalShell>
      ) : null}
    </>
  );
}

async function waitForFocus(element: HTMLElement) {
  await new Promise<void>(resolve => {
    if (document.activeElement === element) {
      resolve();
      return;
    }
    const id = window.setTimeout(() => resolve(), 50);
    element.addEventListener(
      "focus",
      () => {
        window.clearTimeout(id);
        resolve();
      },
      { once: true }
    );
  });
}

describe("Modal accessibility", () => {
  it("closes on Escape and exposes dialog role", async () => {
    const user = userEvent.setup();
    const onClose = jest.fn();
    render(<OpenModalHarness onClose={onClose} />);

    expect(screen.getByRole("dialog", { name: "Test dialog" })).toBeInTheDocument();

    await user.keyboard("{Escape}");
    expect(onClose).toHaveBeenCalled();
  });

  it("moves initial focus into the dialog", async () => {
    render(<OpenModalHarness onClose={jest.fn()} />);

    const dialog = screen.getByRole("dialog", { name: "Test dialog" });
    const close = screen.getByRole("button", { name: /Close Test dialog/i });

    await waitForFocus(close);
    expect(dialog).toContainElement(document.activeElement as HTMLElement | null);
  });
});

describe("ModalShell accessibility", () => {
  beforeEach(() => {
    if (!document.getElementById("root")) {
      const root = document.createElement("div");
      root.id = "root";
      document.body.appendChild(root);
    }
  });

  afterEach(() => {
    resetBodyScrollLockForTests();
  });

  it("does not close on Escape when closeOnEscape is false", async () => {
    const user = userEvent.setup();
    const onClose = jest.fn();
    render(<OpenShellHarness onClose={onClose} closeOnEscape={false} />);

    await user.keyboard("{Escape}");
    expect(onClose).not.toHaveBeenCalled();
  });

  it("uses fixed positioning on the overlay root (not relative)", () => {
    render(<OpenShellHarness onClose={jest.fn()} usePortal />);

    const dialog = screen.getByRole("dialog", { name: "Shell dialog" });
    const overlay = dialog.parentElement;

    expect(overlay).toHaveClass("fixed");
    expect(overlay).not.toHaveClass("relative");
  });

  it("locks body scroll while a portal modal is open", () => {
    render(<OpenShellHarness onClose={jest.fn()} usePortal />);

    expect(document.body.style.overflow).toBe("hidden");
    expect(document.documentElement.style.overflow).toBe("hidden");
  });

  it("marks the app root inert while a portal modal is open", () => {
    if (!("inert" in document.createElement("div"))) {
      return;
    }

    render(<OpenShellHarness onClose={jest.fn()} usePortal />);

    const root = document.getElementById("root");
    expect(root).not.toBeNull();
    expect(root?.inert).toBe(true);
  });

  it("restores body scroll after the last portal modal closes", async () => {
    const user = userEvent.setup();
    render(<ClosablePortalHarness />);

    expect(document.body.style.overflow).toBe("hidden");

    await user.click(screen.getByRole("button", { name: "Close dialog" }));

    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(document.body.style.overflow).toBe("");
    expect(document.documentElement.style.overflow).toBe("");
  });

  it("restores focus to the trigger with preventScroll on close", async () => {
    const user = userEvent.setup();
    const focusSpy = jest.spyOn(HTMLElement.prototype, "focus");

    render(<ClosablePortalHarness />);

    const trigger = screen.getByRole("button", { name: "Open modal" });
    await user.click(screen.getByRole("button", { name: "Close dialog" }));

    expect(focusSpy).toHaveBeenCalledWith(expect.objectContaining({ preventScroll: true }));
    expect(document.activeElement).toBe(trigger);

    focusSpy.mockRestore();
  });

  it("keeps body locked until all portal modals are closed", () => {
    const onCloseA = jest.fn();
    const onCloseB = jest.fn();

    const { unmount: unmountA } = render(<OpenShellHarness onClose={onCloseA} usePortal />);
    const { unmount: unmountB } = render(<OpenShellHarness onClose={onCloseB} usePortal />);

    expect(document.body.style.overflow).toBe("hidden");

    unmountA();
    expect(document.body.style.overflow).toBe("hidden");

    unmountB();
    expect(document.body.style.overflow).toBe("");
    expect(document.documentElement.style.overflow).toBe("");
  });
});
