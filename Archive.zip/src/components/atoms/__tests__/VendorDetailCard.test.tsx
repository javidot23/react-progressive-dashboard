import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import VendorDetailCard from "@/components/atoms/VendorDetailCard";

describe("VendorDetailCard", () => {
  describe("Basic Rendering", () => {
    it("renders with required props", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" />);

      expect(screen.getByText("Test Title")).toBeInTheDocument();
      expect(screen.getByText("Test Value")).toBeInTheDocument();
    });

    it("renders with all props", () => {
      const badge = <span data-testid="test-badge">Badge</span>;

      render(
        <VendorDetailCard title="Test Title" subtitle="Test Subtitle" value="Test Value" badge={badge} hasSpecialLayout={true} />
      );

      expect(screen.getByText("Test Title")).toBeInTheDocument();
      // Subtitle is not rendered in special layout, only in normal layout
      expect(screen.getByText("Test Value")).toBeInTheDocument();
      expect(screen.getByTestId("test-badge")).toBeInTheDocument();
    });

    it("applies correct CSS classes", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" />);

      // Find the root container by traversing up to find the div with bg-white class
      const titleElement = screen.getByText("Test Title");
      let container = titleElement.parentElement;
      while (container && !container.classList.contains("bg-white")) {
        container = container.parentElement;
      }

      expect(container).toHaveClass("bg-white");
      expect(container).toHaveClass("border-1");
      expect(container).toHaveClass("border-neutral-200");
      expect(container).toHaveClass("rounded-md");
      expect(container).toHaveClass("px-2");
      expect(container).toHaveClass("pt-1");
    });
  });

  describe("Title Rendering", () => {
    it("renders title with correct styling", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" />);

      const titleElement = screen.getByText("Test Title");
      expect(titleElement).toHaveClass("text-sm");
      expect(titleElement).toHaveClass("text-[#6E6E6E]");
      expect(titleElement).toHaveClass("font-normal");
      expect(titleElement).toHaveClass("text-nowrap");
    });

    it("renders title in normal layout", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" hasSpecialLayout={false} />);

      const titleElement = screen.getByText("Test Title");
      expect(titleElement.closest("div")).not.toHaveClass("flex");
      expect(titleElement.closest("div")).not.toHaveClass("justify-between");
    });

    it("renders title in special layout", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" hasSpecialLayout={true} />);

      const titleElement = screen.getByText("Test Title");
      // Find the parent div that has flex class
      let parent = titleElement.parentElement;
      while (parent && !parent.classList.contains("flex")) {
        parent = parent.parentElement;
      }
      expect(parent).toHaveClass("flex");
      expect(parent).toHaveClass("justify-between");
      expect(parent).toHaveClass("items-center");
    });

    it("handles long titles without wrapping", () => {
      const longTitle = "This is a very long title that should not wrap due to text-nowrap class";

      render(<VendorDetailCard title={longTitle} value="Test Value" />);

      const titleElement = screen.getByText(longTitle);
      expect(titleElement).toHaveClass("text-nowrap");
    });
  });

  describe("Subtitle Rendering", () => {
    it("renders subtitle when provided", () => {
      render(<VendorDetailCard title="Test Title" subtitle="Test Subtitle" value="Test Value" />);

      expect(screen.getByText("Test Subtitle")).toBeInTheDocument();
    });

    it("does not render subtitle when not provided", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" />);

      expect(screen.queryByText(/here$/)).not.toBeInTheDocument();
    });

    it("renders subtitle with correct styling", () => {
      render(<VendorDetailCard title="Test Title" subtitle="Test Subtitle" value="Test Value" />);

      const subtitleElement = screen.getByText("Test Subtitle");
      expect(subtitleElement).toHaveClass("text-xs");
      expect(subtitleElement).toHaveClass("text-neutral-900");
    });

    it("renders subtitle text as provided", () => {
      render(<VendorDetailCard title="Test Title" subtitle="Custom Subtitle" value="Test Value" />);

      expect(screen.getByText("Custom Subtitle")).toBeInTheDocument();
    });

    it("handles empty subtitle", () => {
      render(<VendorDetailCard title="Test Title" subtitle="" value="Test Value" />);

      // Empty subtitle should not render anything
      expect(screen.queryByText(/here/)).not.toBeInTheDocument();
    });
  });

  describe("Value Rendering", () => {
    it("renders string value with correct styling", () => {
      render(<VendorDetailCard title="Test Title" value="String Value" />);

      const valueElement = screen.getByText("String Value");
      expect(valueElement).toHaveClass("font-bold");
      expect(valueElement).toHaveClass("text-neutral-900");
      expect(valueElement).toHaveClass("text-[17.44px]");
      expect(valueElement).toHaveClass("mt-1");
    });

    it("renders React node value", () => {
      const customValue = (
        <div data-testid="custom-value">
          <span>Custom</span>
          <strong>Value</strong>
        </div>
      );

      render(<VendorDetailCard title="Test Title" value={customValue} />);

      expect(screen.getByTestId("custom-value")).toBeInTheDocument();
      expect(screen.getByText("Custom")).toBeInTheDocument();
      expect(screen.getByText("Value")).toBeInTheDocument();
    });

    it("applies different styling for React node value", () => {
      const customValue = <div data-testid="custom-value">Custom Value</div>;

      render(<VendorDetailCard title="Test Title" value={customValue} />);

      const valueContainer = screen.getByTestId("custom-value").closest("div");
      expect(valueContainer).not.toHaveClass("font-bold");
      expect(valueContainer).not.toHaveClass("text-neutral-900");
      expect(valueContainer).not.toHaveClass("text-xl");
      expect(valueContainer).not.toHaveClass("mt-2");
    });

    it("handles numeric values as strings", () => {
      render(<VendorDetailCard title="Test Title" value="12345" />);

      const valueElement = screen.getByText("12345");
      expect(valueElement).toHaveClass("font-bold");
      expect(valueElement).toHaveClass("text-neutral-900");
      expect(valueElement).toHaveClass("text-[17.44px]");
      expect(valueElement).toHaveClass("mt-1");
    });

    it("handles complex React node values", () => {
      const complexValue = (
        <div data-testid="complex-value">
          <div className="flex items-center gap-2">
            <span className="text-green-500">✓</span>
            <span>Active Status</span>
          </div>
          <div className="text-sm text-gray-500">Last updated: Today</div>
        </div>
      );

      render(<VendorDetailCard title="Status" value={complexValue} />);

      expect(screen.getByTestId("complex-value")).toBeInTheDocument();
      expect(screen.getByText("Active Status")).toBeInTheDocument();
      expect(screen.getByText("Last updated: Today")).toBeInTheDocument();
    });
  });

  describe("Badge Rendering", () => {
    it("renders badge when provided", () => {
      const badge = <span data-testid="test-badge">Badge Text</span>;

      render(<VendorDetailCard title="Test Title" value="Test Value" badge={badge} hasSpecialLayout={true} />);

      expect(screen.getByTestId("test-badge")).toBeInTheDocument();
      expect(screen.getByText("Badge Text")).toBeInTheDocument();
    });

    it("does not render badge when not provided", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" />);

      expect(screen.queryByTestId("test-badge")).not.toBeInTheDocument();
    });

    it("positions badge correctly in special layout", () => {
      const badge = <span data-testid="test-badge">Badge</span>;

      render(<VendorDetailCard title="Test Title" value="Test Value" badge={badge} hasSpecialLayout={true} />);

      const titleElement = screen.getByText("Test Title");
      // Find the parent div that has flex class
      let parent = titleElement.parentElement;
      while (parent && !parent.classList.contains("flex")) {
        parent = parent.parentElement;
      }
      expect(parent).toHaveClass("flex");
      expect(parent).toHaveClass("justify-between");
      expect(parent).toHaveClass("items-center");
      expect(screen.getByTestId("test-badge")).toBeInTheDocument();
    });

    it("does not render badge in normal layout even when provided", () => {
      const badge = <span data-testid="test-badge">Badge</span>;

      render(<VendorDetailCard title="Test Title" value="Test Value" badge={badge} hasSpecialLayout={false} />);

      // Badge should not be rendered in normal layout
      expect(screen.queryByTestId("test-badge")).not.toBeInTheDocument();
    });

    it("renders complex badge components", () => {
      const complexBadge = (
        <div data-testid="complex-badge" className="flex items-center gap-1">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span className="text-xs">Online</span>
        </div>
      );

      render(<VendorDetailCard title="Test Title" value="Test Value" badge={complexBadge} hasSpecialLayout={true} />);

      expect(screen.getByTestId("complex-badge")).toBeInTheDocument();
      expect(screen.getByText("Online")).toBeInTheDocument();
    });
  });

  describe("Layout Variations", () => {
    it("uses normal layout by default", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" />);

      const titleContainer = screen.getByText("Test Title").closest("div");
      expect(titleContainer).not.toHaveClass("flex");
      expect(titleContainer).not.toHaveClass("justify-between");
    });

    it("uses special layout when hasSpecialLayout is true", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" hasSpecialLayout={true} />);

      const titleElement = screen.getByText("Test Title");
      // Find the parent div that has flex class
      let parent = titleElement.parentElement;
      while (parent && !parent.classList.contains("flex")) {
        parent = parent.parentElement;
      }
      expect(parent).toHaveClass("flex");
      expect(parent).toHaveClass("justify-between");
      expect(parent).toHaveClass("items-center");
      expect(parent).toHaveClass("space-x-2");
      expect(parent).toHaveClass("mb-1");
    });

    it("applies margin bottom in special layout", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" hasSpecialLayout={true} />);

      const titleElement = screen.getByText("Test Title");
      // Find the parent div that has flex class
      let parent = titleElement.parentElement;
      while (parent && !parent.classList.contains("flex")) {
        parent = parent.parentElement;
      }
      expect(parent).toHaveClass("mb-1");
    });

    it("does not apply margin bottom in normal layout", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" hasSpecialLayout={false} />);

      const titleContainer = screen.getByText("Test Title").closest("div");
      expect(titleContainer).not.toHaveClass("mb-1");
    });
  });

  describe("Edge Cases", () => {
    it("handles empty title", () => {
      render(<VendorDetailCard title="" value="Test Value" />);

      expect(screen.getByText("Test Value")).toBeInTheDocument();
    });

    it("handles empty string value", () => {
      render(<VendorDetailCard title="Test Title" value="" />);

      expect(screen.getByText("Test Title")).toBeInTheDocument();
      // Empty value should still render with styling (empty string is still a string)
      const container = screen.getByText("Test Title").closest("div.bg-white");
      const valueElement = container?.querySelector(".font-bold");
      // Empty string value will render an empty div with the styling classes
      expect(valueElement).toBeInTheDocument();
    });

    it("handles null badge gracefully", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" badge={null} hasSpecialLayout={true} />);

      expect(screen.getByText("Test Title")).toBeInTheDocument();
      expect(screen.getByText("Test Value")).toBeInTheDocument();
    });

    it("handles undefined props gracefully", () => {
      render(<VendorDetailCard title="Test Title" value="Test Value" subtitle={undefined} badge={undefined} />);

      expect(screen.getByText("Test Title")).toBeInTheDocument();
      expect(screen.getByText("Test Value")).toBeInTheDocument();
    });

    it("handles very long values", () => {
      const longValue = "This is a very long value that might cause layout issues if not handled properly";

      render(<VendorDetailCard title="Test Title" value={longValue} />);

      expect(screen.getByText(longValue)).toBeInTheDocument();
    });

    it("handles special characters in text", () => {
      render(
        <VendorDetailCard
          title="Title with émojis 🎉 & spëcial chars"
          subtitle={"Subtitle with <>&'\" chars"}
          value="Value with ñ, ü, ç characters"
        />
      );

      expect(screen.getByText("Title with émojis 🎉 & spëcial chars")).toBeInTheDocument();
      expect(screen.getByText("Subtitle with <>&'\" chars")).toBeInTheDocument();
      expect(screen.getByText("Value with ñ, ü, ç characters")).toBeInTheDocument();
    });
  });

  describe("Accessibility", () => {
    it("renders semantic HTML structure", () => {
      render(<VendorDetailCard title="Test Title" subtitle="Test Subtitle" value="Test Value" />);

      // Should render div elements with proper content
      expect(screen.getByText("Test Title")).toBeInTheDocument();
      expect(screen.getByText("Test Subtitle")).toBeInTheDocument();
      expect(screen.getByText("Test Value")).toBeInTheDocument();
    });

    it("maintains proper reading order", () => {
      render(<VendorDetailCard title="Title" subtitle="Subtitle" value="Value" />);

      const container = screen.getByText("Title").closest("div.bg-white");
      const titleContainer = container?.querySelector(".flex.flex-col");
      const titleElement = titleContainer?.querySelector(".text-sm");
      const subtitleElement = titleContainer?.querySelector(".text-xs");
      const valueElement = container?.querySelector(".font-bold");

      expect(titleElement).toHaveTextContent("Title");
      expect(subtitleElement).toHaveTextContent("Subtitle");
      expect(valueElement).toHaveTextContent("Value");
    });

    it("supports custom accessibility attributes in React node values", () => {
      const accessibleValue = (
        <div data-testid="accessible-value" role="status" aria-label="Current status">
          Active
        </div>
      );

      render(<VendorDetailCard title="Status" value={accessibleValue} />);

      const valueElement = screen.getByTestId("accessible-value");
      expect(valueElement).toHaveAttribute("role", "status");
      expect(valueElement).toHaveAttribute("aria-label", "Current status");
    });

    it("provides meaningful content structure", () => {
      render(<VendorDetailCard title="Risk Level" subtitle="Current assessment" value="High" hasSpecialLayout={true} />);

      // Title should be clearly identifiable
      expect(screen.getByText("Risk Level")).toBeInTheDocument();
      // Subtitle is not shown in special layout (only in normal layout)
      // Value is prominently displayed
      expect(screen.getByText("High")).toBeInTheDocument();
    });
  });

  describe("Performance", () => {
    it("renders quickly with simple props", () => {
      const renderTime = performance.now();
      render(<VendorDetailCard title="Test Title" value="Test Value" />);
      const endTime = performance.now();

      expect(endTime - renderTime).toBeLessThan(50); // Should render very quickly
    });

    it("handles re-renders efficiently", () => {
      const { rerender } = render(<VendorDetailCard title="Title 1" value="Value 1" />);

      expect(screen.getByText("Title 1")).toBeInTheDocument();

      const rerenderTime = performance.now();
      rerender(<VendorDetailCard title="Title 2" value="Value 2" />);
      const endTime = performance.now();

      expect(endTime - rerenderTime).toBeLessThan(50); // Re-render should be quick
      expect(screen.getByText("Title 2")).toBeInTheDocument();
      expect(screen.queryByText("Title 1")).not.toBeInTheDocument();
    });

    it("handles complex React node values efficiently", () => {
      const complexValue = (
        <div>
          {Array.from({ length: 10 }, (_, i) => (
            <div key={i} className="flex items-center gap-2">
              <span>{`Item ${i + 1}`}</span>
              <button onClick={() => {}}>Action</button>
            </div>
          ))}
        </div>
      );

      const renderTime = performance.now();
      render(<VendorDetailCard title="Complex Value" value={complexValue} />);
      const endTime = performance.now();

      expect(endTime - renderTime).toBeLessThan(100); // Should handle complexity well
      expect(screen.getByText("Item 1")).toBeInTheDocument();
      expect(screen.getByText("Item 10")).toBeInTheDocument();
    });
  });

  describe("Integration", () => {
    it("works with different prop combinations", () => {
      const testCases = [
        { title: "Basic", value: "Basic Value" },
        { title: "With Subtitle", subtitle: "Sub", value: "Value" },
        { title: "Special Layout", value: "Value", hasSpecialLayout: true },
        { title: "With Badge", value: "Value", badge: <span>Badge</span>, hasSpecialLayout: true },
        { title: "All Props", subtitle: "Sub", value: "Value", badge: <span>Badge</span>, hasSpecialLayout: true },
      ];

      testCases.forEach(({ title, ...props }) => {
        const { unmount } = render(<VendorDetailCard title={title} {...props} />);

        expect(screen.getByText(title)).toBeInTheDocument();
        unmount();
      });
    });

    it("maintains state consistency across prop changes", () => {
      const { rerender } = render(<VendorDetailCard title="Initial Title" value="Initial Value" hasSpecialLayout={false} />);

      expect(screen.getByText("Initial Title")).toBeInTheDocument();
      expect(screen.getByText("Initial Value")).toBeInTheDocument();

      // Change to special layout with badge
      rerender(
        <VendorDetailCard
          title="Updated Title"
          subtitle="New Subtitle"
          value="Updated Value"
          badge={<span data-testid="new-badge">New Badge</span>}
          hasSpecialLayout={true}
        />
      );

      expect(screen.getByText("Updated Title")).toBeInTheDocument();
      // Subtitle is not shown in special layout, only in normal layout
      expect(screen.getByText("Updated Value")).toBeInTheDocument();
      expect(screen.getByTestId("new-badge")).toBeInTheDocument();

      // Old content should not be present
      expect(screen.queryByText("Initial Title")).not.toBeInTheDocument();
      expect(screen.queryByText("Initial Value")).not.toBeInTheDocument();
    });

    it("works well as part of larger component trees", () => {
      render(
        <div data-testid="parent-container">
          <div className="grid grid-cols-2 gap-4">
            <VendorDetailCard title="Card 1" value="Value 1" />
            <VendorDetailCard title="Card 2" subtitle="Subtitle 2" value="Value 2" hasSpecialLayout={true} />
          </div>
          <VendorDetailCard title="Card 3" value={<div data-testid="custom-value">Custom Content</div>} />
        </div>
      );

      expect(screen.getByTestId("parent-container")).toBeInTheDocument();
      expect(screen.getByText("Card 1")).toBeInTheDocument();
      expect(screen.getByText("Card 2")).toBeInTheDocument();
      expect(screen.getByText("Card 3")).toBeInTheDocument();
      // Subtitle 2 is not shown in special layout, only in normal layout
      expect(screen.getByTestId("custom-value")).toBeInTheDocument();
    });
  });
});
