import "@testing-library/jest-dom";
import { render, screen, waitFor, fireEvent, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Filters, { FiltersConfig, SortOption, DropdownConfig, RangeConfig, PresetRangeConfig } from "@/components/atoms/Filters";

jest.mock("@/components/atoms/DualRangeSlider", () => ({
  __esModule: true,
  default: function MockDualRangeSlider({ minValue, maxValue, onMinChange, onMaxChange, onChangeEnd }: any) {
    return (
      <div data-testid="dual-range-slider">
        <div data-testid="min-value">{minValue}</div>
        <div data-testid="max-value">{maxValue}</div>
        <button
          data-testid="increase-min"
          onClick={() => {
            onMinChange(minValue + 1);
            if (onChangeEnd) {
              setTimeout(() => onChangeEnd(minValue + 1, maxValue), 500);
            }
          }}
        >
          Increase Min
        </button>
        <button
          data-testid="increase-max"
          onClick={() => {
            onMaxChange(maxValue + 1);
            if (onChangeEnd) {
              setTimeout(() => onChangeEnd(minValue, maxValue + 1), 500);
            }
          }}
        >
          Increase Max
        </button>
      </div>
    );
  },
}));

jest.mock("@/components/atoms/InfoIcon", () => ({
  InfoIcon: function MockInfoIcon() {
    return <div data-testid="info-icon">Info</div>;
  },
}));

jest.mock("@/lib", () => ({
  getDrivingRiskLabel: jest.fn((risk: string) => {
    const labels: Record<string, string> = {
      Operational: "Operational Risk",
      Environmental: "Environmental Risk",
    };
    return labels[risk] || risk;
  }),
}));

jest.mock("@/hooks", () => ({
  useRiskModelDescriptions: () => {
    const labels: Record<string, string> = {
      Operational: "Operational Risk",
      Environmental: "Environmental Risk",
    };
    return {
      getEnrichedMetadata: (risk: string) => ({
        display_name: labels[risk] || risk,
        original_risk_type: risk,
        risk_type: risk,
        risk_description: risk,
      }),
    };
  },
}));

describe("Filters", () => {
  const mockSetFilters = jest.fn();

  const defaultSortOptions: SortOption[] = [
    { label: "Name", value: "name" },
    { label: "Risk Score", value: "risk_score" },
    { label: "Risk Rating", value: "risk_rating" },
  ];

  const defaultFilters = {
    search: "",
    ordering: "name",
  };

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.runOnlyPendingTimers();
    jest.useRealTimers();
  });

  describe("Sort Options", () => {
    it("renders sort dropdown", () => {
      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      expect(screen.getByText("Sort")).toBeInTheDocument();
    });

    it("displays current sort option", () => {
      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
      };

      const filters = {
        ...defaultFilters,
        ordering: "risk_score",
      };

      render(<Filters filters={filters} setFilters={mockSetFilters} config={config} />);

      expect(screen.getByText("Risk Score")).toBeInTheDocument();
    });

    it("changes sort direction when direction buttons are clicked", async () => {
      jest.useRealTimers();

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
      };

      const filters = {
        ...defaultFilters,
        ordering: "name",
      };

      render(<Filters filters={filters} setFilters={mockSetFilters} config={config} />);

      expect(screen.getByText("Sort")).toBeInTheDocument();

      const descButtons = screen.queryAllByTitle("Sort Z → A");
      if (descButtons.length > 0) {
        await userEvent.click(descButtons[0]);
        expect(mockSetFilters).toHaveBeenCalled();
      } else {
        expect(screen.getByText("Sort")).toBeInTheDocument();
      }

      jest.useFakeTimers();
    });

    it("opens sort dropdown and selects option", async () => {
      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Sort")).toBeInTheDocument();
      });

      expect(screen.getByText("Name")).toBeInTheDocument();
    });
  });

  describe("Static Dropdown Filters", () => {
    it("renders static dropdown filter", async () => {
      const dropdownConfig: DropdownConfig = {
        key: "primary_risk",
        label: "Driving Risk",
        options: ["Operational", "Environmental", "Financial"],
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Driving Risk")).toBeInTheDocument();
      });
    });

    it("renders a single static option without empty state or All in the panel", async () => {
      const dropdownConfig: DropdownConfig = {
        key: "federal_cs_ind",
        label: "Filter by schedule",
        options: ["Not Controlled"],
        disableSearch: true,
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Filter by schedule")).toBeInTheDocument();
      });

      const label = screen.getByText("Filter by schedule");
      const trigger = label.parentElement?.querySelector("button");
      expect(trigger).toBeTruthy();
      fireEvent.click(trigger!);

      await waitFor(() => {
        expect(screen.getByText("Not Controlled")).toBeInTheDocument();
      });

      expect(screen.queryByText("No options available")).not.toBeInTheDocument();

      const optionsPanel = screen.getByText("Not Controlled").closest(".shadow-lg");
      expect(optionsPanel).toBeTruthy();
      expect(within(optionsPanel as HTMLElement).getAllByRole("button")).toHaveLength(1);
      expect(within(optionsPanel as HTMLElement).queryByRole("button", { name: "All" })).not.toBeInTheDocument();
    });

    it("opens dropdown and selects option", async () => {
      const dropdownConfig: DropdownConfig = {
        key: "primary_risk",
        label: "Driving Risk",
        options: ["Operational", "Environmental", "Financial"],
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        const dropdownButton = screen.getByText("All").closest("button");
        if (dropdownButton) {
          fireEvent.click(dropdownButton);
        }
      });

      await waitFor(() => {
        expect(screen.getByText("Operational")).toBeInTheDocument();
      });
    });

    it("handles 'All' option selection", async () => {
      const dropdownConfig: DropdownConfig = {
        key: "primary_risk",
        label: "Driving Risk",
        options: ["Operational", "Environmental"],
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
      };

      const filters = {
        ...defaultFilters,
        primary_risk: "Operational",
      };

      render(<Filters filters={filters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Driving Risk")).toBeInTheDocument();
      });

      expect(screen.getByText("Operational")).toBeInTheDocument();
    }, 15000);
  });

  describe("Async Dropdown Filters", () => {
    it("loads async dropdown options", async () => {
      const asyncOptions = jest.fn().mockResolvedValue({
        options: ["Option 1", "Option 2", "Option 3"],
        hasMore: false,
      });

      const dropdownConfig: DropdownConfig = {
        key: "async_filter",
        label: "Async Filter",
        options: asyncOptions,
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(asyncOptions).toHaveBeenCalled();
      });
    });

    it("handles async dropdown loading error", async () => {
      const asyncOptions = jest.fn().mockRejectedValue(new Error("API Error"));

      const dropdownConfig: DropdownConfig = {
        key: "async_filter",
        label: "Async Filter",
        options: asyncOptions,
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(asyncOptions).toHaveBeenCalled();
      });

      await waitFor(() => {
        expect(screen.getByText("Async Filter")).toBeInTheDocument();
      });
    });
  });

  describe("Range Filters", () => {
    it("renders range filter", async () => {
      const rangeConfig: RangeConfig = {
        key: "risk_rating",
        label: "Risk Rating",
        min: 0,
        max: 100,
        minKey: "risk_rating_min",
        maxKey: "risk_rating_max",
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        ranges: [rangeConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Risk Rating")).toBeInTheDocument();
      });
    });

    it("opens range filter dropdown", async () => {
      const rangeConfig: RangeConfig = {
        key: "risk_rating",
        label: "Risk Rating",
        min: 0,
        max: 100,
        minKey: "risk_rating_min",
        maxKey: "risk_rating_max",
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        ranges: [rangeConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Risk Rating")).toBeInTheDocument();
      });

      const riskRatingButton = screen.getByText("Risk Rating").closest("div")?.querySelector("button");
      expect(riskRatingButton).toBeInTheDocument();
    }, 15000);

    it("updates range filter values", async () => {
      const rangeConfig: RangeConfig = {
        key: "risk_rating",
        label: "Risk Rating",
        min: 0,
        max: 100,
        minKey: "risk_rating_min",
        maxKey: "risk_rating_max",
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        ranges: [rangeConfig],
      };

      const filters = {
        ...defaultFilters,
        risk_rating_min: 20,
        risk_rating_max: 80,
      };

      render(<Filters filters={filters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        const rangeButton = screen.getByText("Custom Range").closest("button");
        if (rangeButton) {
          fireEvent.click(rangeButton);
        }
      });

      await waitFor(() => {
        const increaseMinButton = screen.getByTestId("increase-min");
        fireEvent.click(increaseMinButton);
      });

      jest.advanceTimersByTime(500);

      expect(mockSetFilters).toHaveBeenCalled();
    });

    it("clears range filter", async () => {
      const rangeConfig: RangeConfig = {
        key: "risk_rating",
        label: "Risk Rating",
        min: 0,
        max: 100,
        minKey: "risk_rating_min",
        maxKey: "risk_rating_max",
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        ranges: [rangeConfig],
      };

      const filters = {
        ...defaultFilters,
        risk_rating_min: 20,
        risk_rating_max: 80,
      };

      render(<Filters filters={filters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        const rangeButton = screen.getByText("Custom Range").closest("button");
        if (rangeButton) {
          fireEvent.click(rangeButton);
        }
      });

      await waitFor(() => {
        const clearButton = screen.getByText("Clear");
        if (clearButton) {
          fireEvent.click(clearButton);
        }
      });

      expect(mockSetFilters).toHaveBeenCalledWith({
        ...filters,
        risk_rating_min: null,
        risk_rating_max: null,
      });
    });
  });

  describe("Preset Range Filters", () => {
    it("renders preset range filter", async () => {
      const presetConfig: PresetRangeConfig = {
        key: "risk_rating",
        label: "Risk Rating",
        minKey: "risk_rating_min",
        maxKey: "risk_rating_max",
        presets: {
          High: { min: 0.7, max: 1.0 },
          Medium: { min: 0.4, max: 0.7 },
          Low: { min: 0, max: 0.4 },
        },
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        presetRanges: [presetConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Risk Rating")).toBeInTheDocument();
      });
    });

    it("selects preset range", async () => {
      const presetConfig: PresetRangeConfig = {
        key: "risk_rating",
        label: "Risk Rating",
        minKey: "risk_rating_min",
        maxKey: "risk_rating_max",
        presets: {
          High: { min: 0.7, max: 1.0 },
          Medium: { min: 0.4, max: 0.7 },
        },
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        presetRanges: [presetConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Risk Rating")).toBeInTheDocument();
      });

      const riskRatingButton = screen.getByText("Risk Rating").closest("div")?.querySelector("button");
      expect(riskRatingButton).toBeInTheDocument();
    }, 15000);
  });

  describe("has_no_actions Filter", () => {
    it("handles has_no_actions filter correctly", async () => {
      const dropdownConfig: DropdownConfig = {
        key: "has_no_actions",
        label: "Action Status",
        options: ["All", "Not Reviewed", "Reviewed"],
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Action Status")).toBeInTheDocument();
      });

      expect(screen.getByText("Action Status")).toBeInTheDocument();
    }, 15000);
  });

  describe("Search Functionality", () => {
    it("performs search in async dropdown", async () => {
      const asyncOptions = jest
        .fn()
        .mockResolvedValueOnce({
          options: ["Option 1", "Option 2"],
          hasMore: false,
        })
        .mockResolvedValueOnce({
          options: ["Option 1"],
          hasMore: false,
        });

      const dropdownConfig: DropdownConfig = {
        key: "searchable_filter",
        label: "Searchable Filter",
        options: asyncOptions,
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(screen.getByText("Searchable Filter")).toBeInTheDocument();
      });

      await waitFor(
        () => {
          expect(asyncOptions).toHaveBeenCalled();
        },
        { timeout: 3000 }
      );
    }, 15000);
  });

  describe("Custom Order", () => {
    it("renders filters in custom order", async () => {
      const dropdownConfig: DropdownConfig = {
        key: "primary_risk",
        label: "Driving Risk",
        options: ["Operational", "Environmental"],
      };

      const presetConfig: PresetRangeConfig = {
        key: "risk_rating",
        label: "Risk Rating",
        minKey: "risk_rating_min",
        maxKey: "risk_rating_max",
        presets: {
          High: { min: 0.7, max: 1.0 },
        },
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
        presetRanges: [presetConfig],
        customOrder: ["risk_rating", "primary_risk"],
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        const labels = screen.getAllByText(/Risk Rating|Driving Risk/);
        expect(labels.length).toBeGreaterThan(0);
      });
    });
  });

  describe("Edge Cases", () => {
    it("handles empty filters object", () => {
      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
      };

      render(<Filters filters={{}} setFilters={mockSetFilters} config={config} />);

      expect(screen.getByText("Sort")).toBeInTheDocument();
    });

    it("handles missing config properties", () => {
      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
      };

      render(<Filters filters={defaultFilters} setFilters={mockSetFilters} config={config} />);

      expect(screen.getByText("Sort")).toBeInTheDocument();
    });

    it("handles displayMapping function", async () => {
      const displayMapping = jest.fn().mockResolvedValue("Display Value");
      const storeMapping = jest.fn().mockResolvedValue("stored_value");

      const dropdownConfig: DropdownConfig = {
        key: "mapped_filter",
        label: "Mapped Filter",
        options: ["stored_value"],
        displayMapping,
        storeMapping,
      };

      const config: FiltersConfig = {
        sortOptions: defaultSortOptions,
        dropdowns: [dropdownConfig],
      };

      const filters = {
        ...defaultFilters,
        mapped_filter: "stored_value",
      };

      render(<Filters filters={filters} setFilters={mockSetFilters} config={config} />);

      await waitFor(() => {
        expect(displayMapping).toHaveBeenCalledWith("stored_value");
      });
    });
  });

  describe("dynamicMaxValues clamp behavior", () => {
    const rangeConfig: RangeConfig = {
      key: "risk_adjusted_value",
      label: "Risk Adjusted Value",
      min: 0,
      max: 1000,
      step: 1,
      minKey: "risk_adjusted_value_min",
      maxKey: "risk_adjusted_value_max",
    };

    const config: FiltersConfig = {
      sortOptions: defaultSortOptions,
      ranges: [rangeConfig],
    };

    it("clamps the stored max when the dynamic max shrinks below it", async () => {
      jest.useRealTimers();
      const setFilters = jest.fn();
      const filters = {
        ...defaultFilters,
        risk_adjusted_value_max: 500,
      };

      render(
        <Filters filters={filters} setFilters={setFilters} config={config} dynamicMaxValues={{ risk_adjusted_value: 100 }} />
      );

      await waitFor(() => expect(setFilters).toHaveBeenCalledTimes(1));
      expect(setFilters).toHaveBeenCalledWith(expect.objectContaining({ risk_adjusted_value_max: 100 }));
      jest.useFakeTimers();
    });

    it("does not call setFilters when stored max is already within the dynamic max", async () => {
      jest.useRealTimers();
      const setFilters = jest.fn();
      const filters = {
        ...defaultFilters,
        risk_adjusted_value_max: 50,
      };

      render(
        <Filters filters={filters} setFilters={setFilters} config={config} dynamicMaxValues={{ risk_adjusted_value: 100 }} />
      );

      // Wait a tick to make sure no clamp effect fires.
      await new Promise(resolve => setTimeout(resolve, 0));
      expect(setFilters).not.toHaveBeenCalled();
      jest.useFakeTimers();
    });

    it("does not loop when the parent re-renders with a fresh dynamicMaxValues object", async () => {
      jest.useRealTimers();
      const setFilters = jest.fn();
      const filters = {
        ...defaultFilters,
        // Stored value is well within the new dynamic max so the clamp
        // effect should *never* call setFilters, even when the parent
        // hands us a new object reference on every render.
        risk_adjusted_value_max: 50,
      };

      const { rerender } = render(
        <Filters filters={filters} setFilters={setFilters} config={config} dynamicMaxValues={{ risk_adjusted_value: 100 }} />
      );

      // Re-render five times with a fresh object reference but identical
      // values. Without the value-level guard this triggers the clamp
      // effect on every render and (in production) a setFilters loop.
      for (let i = 0; i < 5; i++) {
        rerender(
          <Filters filters={filters} setFilters={setFilters} config={config} dynamicMaxValues={{ risk_adjusted_value: 100 }} />
        );
        await new Promise(resolve => setTimeout(resolve, 0));
      }

      expect(setFilters).not.toHaveBeenCalled();
      jest.useFakeTimers();
    });

    it("clamps both min and max when stored values exceed the dynamic max", async () => {
      jest.useRealTimers();
      const setFilters = jest.fn();
      const filters = {
        ...defaultFilters,
        risk_adjusted_value_min: 200,
        risk_adjusted_value_max: 800,
      };

      render(
        <Filters filters={filters} setFilters={setFilters} config={config} dynamicMaxValues={{ risk_adjusted_value: 100 }} />
      );

      await waitFor(() => expect(setFilters).toHaveBeenCalledTimes(1));
      const updates = setFilters.mock.calls[0][0];
      expect(updates.risk_adjusted_value_min).toBe(100);
      expect(updates.risk_adjusted_value_max).toBe(100);
      jest.useFakeTimers();
    });

    it("does not overwrite concurrent user edits to other keys when clamping", async () => {
      // Race scenario: the user mutates an unrelated filter (``primary_risk``)
      // in the same commit cycle that the dynamic max shrinks. The clamp
      // effect must read the *latest* filters when it patches, not the
      // captured-stale closure — otherwise the user's edit is silently
      // reverted.
      jest.useRealTimers();
      const setFilters = jest.fn();
      const initialFilters = {
        ...defaultFilters,
        primary_risk: "Operational",
        risk_adjusted_value_max: 500,
      };

      const { rerender } = render(
        <Filters
          filters={initialFilters}
          setFilters={setFilters}
          config={config}
          dynamicMaxValues={{ risk_adjusted_value: 1000 }}
        />
      );

      // The user changes ``primary_risk`` (not yet propagated to the parent
      // because the dynamic max race lands first). Simulate the parent
      // re-rendering with the fresh value AND the new dynamic max in the
      // same render commit.
      const updatedFilters = { ...initialFilters, primary_risk: "Environmental" };
      rerender(
        <Filters
          filters={updatedFilters}
          setFilters={setFilters}
          config={config}
          dynamicMaxValues={{ risk_adjusted_value: 100 }}
        />
      );

      await waitFor(() => expect(setFilters).toHaveBeenCalledTimes(1));
      const patched = setFilters.mock.calls[0][0];
      // Clamp landed:
      expect(patched.risk_adjusted_value_max).toBe(100);
      // Crucially, the concurrent ``primary_risk`` edit is preserved:
      expect(patched.primary_risk).toBe("Environmental");
      jest.useFakeTimers();
    });
  });
});
