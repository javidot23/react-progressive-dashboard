import "@testing-library/jest-dom";
import { fireEvent, render, screen } from "@testing-library/react";
import DualRangeSlider from "@/components/atoms/DualRangeSlider";

describe("DualRangeSlider", () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.runOnlyPendingTimers();
    jest.useRealTimers();
  });

  it("keeps the handles at least minGap apart", () => {
    const onMinChange = jest.fn();
    const onMaxChange = jest.fn();

    render(
      <DualRangeSlider
        min={0}
        max={60}
        step={1}
        minGap={1}
        minValue={25}
        maxValue={35}
        onMinChange={onMinChange}
        onMaxChange={onMaxChange}
      />
    );

    const [minInput, maxInput] = screen.getAllByRole("slider");

    // Low handle cannot reach the high handle: dragging it to 35 clamps to 34 (high - minGap).
    fireEvent.change(minInput, { target: { value: "35" } });
    expect(onMinChange).toHaveBeenLastCalledWith(34);

    // High handle cannot reach the low handle: dragging it to 34 clamps to 35 (low + minGap).
    fireEvent.change(maxInput, { target: { value: "34" } });
    expect(onMaxChange).toHaveBeenLastCalledWith(35);
  });
});
