import "@testing-library/jest-dom";
import { createRef, type ComponentPropsWithoutRef } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import {
  GeneralCard,
  GeneralCardAction,
  GeneralCardActionArea,
  GeneralCardContent,
  GeneralCardDescription,
  GeneralCardFooter,
  GeneralCardHeader,
  GeneralCardMedia,
  GeneralCardSection,
  GeneralCardTitle,
  generalCardVariants,
} from "@/components/atoms/GeneralCard";

describe("GeneralCard", () => {
  it("renders with flat as the default CDS-backed surface", () => {
    render(
      <GeneralCard data-testid="card">
        <GeneralCardContent>Body</GeneralCardContent>
      </GeneralCard>
    );

    const card = screen.getByTestId("card");
    expect(card).toHaveAttribute("data-slot", "general-card");
    expect(card).toHaveAttribute("data-variant", "flat");
    expect(card).toHaveAttribute("data-orientation", "vertical");
    expect(card).toHaveClass("bg-white");
    expect(card).toHaveClass("border-0");
    expect(card).toHaveClass("rounded-lg");
    expect(card).toHaveClass("shadow-none");
    expect(card).toHaveClass("@container/card");
    expect(card).toHaveClass("min-w-0");
    expect(card).toHaveClass("w-full");
    expect(card).not.toHaveAttribute("data-size");
    expect(card.className).toContain("[--card-padding-y:16px]");
    expect(card.className).toContain("[--card-padding-x:20px]");
    expect(card.className).toContain("[--card-gap:14px]");
    expect(card.className).toContain(
      "has-[>[data-slot=general-card-action-area]]:shadow-[0_0_16px_0_#00000014,0_0_6px_0_#0000001F]"
    );
  });

  it.each([
    ["outlined", ["border", "border-ui-border-primary", "bg-white"]],
    ["flat", ["border-0", "bg-white", "shadow-none"]],
  ] as const)("applies %s variant classes", (variant, expectedClasses) => {
    render(<GeneralCard data-testid="card" variant={variant} />);
    const card = screen.getByTestId("card");
    expectedClasses.forEach(className => {
      expect(card).toHaveClass(className);
    });
    expect(card).toHaveAttribute("data-variant", variant);
  });

  it("uses the elevated soft dual-layer shadow without a border", () => {
    render(<GeneralCard data-testid="card" variant="elevated" />);
    const card = screen.getByTestId("card");
    expect(card.className).toContain("shadow-[0_0_16px_0_#00000014,0_0_6px_0_#0000001F]");
    expect(card).not.toHaveClass("border");
    expect(card).not.toHaveClass("shadow-raised");
  });

  it("elevates a flat card when it has a direct ActionArea child", () => {
    render(
      <GeneralCard data-testid="card">
        <GeneralCardActionArea>Open</GeneralCardActionArea>
      </GeneralCard>
    );
    const card = screen.getByTestId("card");
    expect(card).toHaveAttribute("data-variant", "flat");
    expect(card.className).toContain(
      "has-[>[data-slot=general-card-action-area]]:shadow-[0_0_16px_0_#00000014,0_0_6px_0_#0000001F]"
    );
  });

  it("does not apply the interactive elevation class to non-flat variants", () => {
    render(
      <GeneralCard data-testid="card" variant="outlined">
        <GeneralCardActionArea>Open</GeneralCardActionArea>
      </GeneralCard>
    );
    const card = screen.getByTestId("card");
    expect(card).toHaveClass("border");
    expect(card.className).not.toContain(
      "has-[>[data-slot=general-card-action-area]]:shadow-[0_0_16px_0_#00000014,0_0_6px_0_#0000001F]"
    );
  });

  it("merges consumer className overrides", () => {
    render(<GeneralCard data-testid="card" className="max-w-sm bg-sky-50" />);
    const card = screen.getByTestId("card");
    expect(card).toHaveClass("max-w-sm");
    expect(card).toHaveClass("bg-sky-50");
  });

  it("forwards refs to the root element", () => {
    const ref = createRef<HTMLDivElement>();
    render(<GeneralCard ref={ref}>Content</GeneralCard>);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
    expect(ref.current).toHaveAttribute("data-slot", "general-card");
  });

  it("renders a polymorphic root and title", () => {
    render(
      <GeneralCard as="article" data-testid="card">
        <GeneralCardHeader>
          <GeneralCardTitle as="h2">Semantic title</GeneralCardTitle>
        </GeneralCardHeader>
      </GeneralCard>
    );

    expect(screen.getByTestId("card").tagName).toBe("ARTICLE");
    expect(screen.getByRole("heading", { level: 2, name: "Semantic title" })).toBeInTheDocument();
  });

  it("accepts intrinsic props for a custom as target", () => {
    render(
      <GeneralCard as="a" href="#inventory" data-testid="card">
        Link card
      </GeneralCard>
    );

    const card = screen.getByTestId("card");
    expect(card.tagName).toBe("A");
    expect(card).toHaveAttribute("href", "#inventory");
  });

  it("infers a precise ref type for intrinsic as targets", () => {
    const anchorRef = createRef<HTMLAnchorElement>();
    render(
      <GeneralCard as="a" href="#details" ref={anchorRef}>
        Details
      </GeneralCard>
    );
    expect(anchorRef.current).toBeInstanceOf(HTMLAnchorElement);
    expect(anchorRef.current).toHaveAttribute("href", "#details");
  });

  it("preserves internal data-slot when consumers attempt to override it", () => {
    render(
      <GeneralCard data-testid="card" data-slot="consumer-override" data-variant="consumer">
        <GeneralCardHeader data-slot="header-override" data-testid="header">
          <GeneralCardTitle data-slot="title-override">Title</GeneralCardTitle>
          <GeneralCardDescription data-slot="description-override">Description</GeneralCardDescription>
          <GeneralCardAction data-slot="action-override" data-testid="action">
            Action
          </GeneralCardAction>
        </GeneralCardHeader>
        <GeneralCardMedia data-slot="media-override" data-testid="media">
          Media
        </GeneralCardMedia>
        <GeneralCardSection data-slot="section-override" data-testid="section">
          Section
        </GeneralCardSection>
        <GeneralCardContent data-slot="content-override" data-testid="content">
          Body
        </GeneralCardContent>
        <GeneralCardFooter data-slot="footer-override" data-testid="footer">
          Footer
        </GeneralCardFooter>
      </GeneralCard>
    );

    expect(screen.getByTestId("card")).toHaveAttribute("data-slot", "general-card");
    expect(screen.getByTestId("card")).toHaveAttribute("data-variant", "flat");
    expect(screen.getByTestId("card")).not.toHaveAttribute("data-size");
    expect(screen.getByTestId("header")).toHaveAttribute("data-slot", "general-card-header");
    expect(screen.getByText("Title")).toHaveAttribute("data-slot", "general-card-title");
    expect(screen.getByText("Description")).toHaveAttribute("data-slot", "general-card-description");
    expect(screen.getByTestId("action")).toHaveAttribute("data-slot", "general-card-action");
    expect(screen.getByTestId("media")).toHaveAttribute("data-slot", "general-card-media");
    expect(screen.getByTestId("section")).toHaveAttribute("data-slot", "general-card-section");
    expect(screen.getByTestId("content")).toHaveAttribute("data-slot", "general-card-content");
    expect(screen.getByTestId("footer")).toHaveAttribute("data-slot", "general-card-footer");
  });

  it("renders all compositional slots with data-slot attributes", () => {
    render(
      <GeneralCard>
        <GeneralCardMedia data-testid="media">
          <img alt="Preview" src="/preview.png" />
        </GeneralCardMedia>
        <GeneralCardHeader data-testid="header">
          <GeneralCardTitle>Title</GeneralCardTitle>
          <GeneralCardDescription>Description</GeneralCardDescription>
          <GeneralCardAction data-testid="action">
            <button type="button">Action</button>
          </GeneralCardAction>
        </GeneralCardHeader>
        <GeneralCardContent data-testid="content">Body</GeneralCardContent>
        <GeneralCardFooter data-testid="footer">
          <button type="button">Footer action</button>
        </GeneralCardFooter>
      </GeneralCard>
    );

    expect(screen.getByTestId("media")).toHaveAttribute("data-slot", "general-card-media");
    expect(screen.getByTestId("header")).toHaveAttribute("data-slot", "general-card-header");
    expect(screen.getByTestId("action")).toHaveAttribute("data-slot", "general-card-action");
    expect(screen.getByTestId("content")).toHaveAttribute("data-slot", "general-card-content");
    expect(screen.getByTestId("footer")).toHaveAttribute("data-slot", "general-card-footer");
    expect(screen.getByText("Description")).toHaveAttribute("data-slot", "general-card-description");
  });

  it("exposes responsive class contracts on header and footer", () => {
    render(
      <GeneralCard>
        <GeneralCardHeader data-testid="header">
          <GeneralCardTitle>Title</GeneralCardTitle>
          <GeneralCardAction>Action</GeneralCardAction>
        </GeneralCardHeader>
        <GeneralCardFooter data-testid="footer">Footer</GeneralCardFooter>
      </GeneralCard>
    );

    const header = screen.getByTestId("header");
    expect(header.className).toContain("@sm/card:grid-cols-[minmax(0,1fr)_auto]");
    expect(header.className).toContain("has-data-[slot=general-card-action]");

    const footer = screen.getByTestId("footer");
    expect(footer).toHaveClass("flex-col");
    expect(footer).toHaveClass("mt-auto");
    expect(footer.className).toContain("@sm/card:flex-row");
  });

  it("cancels padding only for first and last media, not mid-card gap", () => {
    render(
      <GeneralCard>
        <GeneralCardMedia data-testid="first-media">Top</GeneralCardMedia>
        <GeneralCardContent>Body</GeneralCardContent>
        <GeneralCardMedia data-testid="last-media">Bottom</GeneralCardMedia>
      </GeneralCard>
    );

    const first = screen.getByTestId("first-media");
    const last = screen.getByTestId("last-media");

    expect(first.className).toContain("group-data-[orientation=vertical]/card:first:-mt-(--card-padding-y)");
    expect(first.className).toContain("group-data-[orientation=vertical]/card:last:-mb-(--card-padding-y)");
    expect(first.className).not.toContain("-my-(--card-padding-y)");
    expect(last.className).not.toContain("-my-(--card-padding-y)");
  });

  it("supports an intrinsically responsive horizontal orientation", () => {
    render(
      <GeneralCard orientation="horizontal" data-testid="card">
        <GeneralCardMedia data-testid="media">Media</GeneralCardMedia>
        <GeneralCardSection data-testid="section">Body</GeneralCardSection>
      </GeneralCard>
    );

    const card = screen.getByTestId("card");
    expect(card).toHaveAttribute("data-orientation", "horizontal");
    expect(card.className).toContain("grid-cols-[repeat(auto-fit,minmax(min(100%,16rem),1fr))]");
    expect(screen.getByTestId("section").className).toContain("group-data-[orientation=horizontal]/card:flex");
  });

  it("uses comfortable line height for wrapping titles", () => {
    render(<GeneralCardTitle>Long wrapping title</GeneralCardTitle>);
    expect(screen.getByRole("heading")).toHaveClass("leading-snug");
    expect(screen.getByRole("heading")).not.toHaveClass("leading-none");
  });

  it("renders a native button action area without hover background chrome", () => {
    const onClick = jest.fn();
    render(<GeneralCardActionArea onClick={onClick}>Open details</GeneralCardActionArea>);

    const action = screen.getByRole("button", { name: "Open details" });
    expect(action).toHaveAttribute("type", "button");
    expect(action).toHaveAttribute("data-slot", "general-card-action-area");
    expect(action).toHaveClass("cursor-pointer");
    expect(action.className).toContain("focus-visible:outline-2");
    expect(action.className).not.toMatch(/hover:bg-/);
    expect(action.className).not.toMatch(/active:bg-/);
    fireEvent.click(action);
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("supports native link semantics for navigational action areas", () => {
    const ref = createRef<HTMLAnchorElement>();
    render(
      <GeneralCardActionArea as="a" href="#destination" ref={ref}>
        Navigate
      </GeneralCardActionArea>
    );

    const action = screen.getByRole("link", { name: "Navigate" });
    expect(action).toHaveAttribute("href", "#destination");
    expect(ref.current).toBe(action);
  });

  it("honors native disabled behavior for command action areas", () => {
    const onClick = jest.fn();
    render(
      <GeneralCardActionArea disabled onClick={onClick}>
        Disabled command
      </GeneralCardActionArea>
    );

    const action = screen.getByRole("button", { name: "Disabled command" });
    expect(action).toBeDisabled();
    fireEvent.click(action);
    expect(onClick).not.toHaveBeenCalled();
  });

  it("stays passive with no implicit interactive affordances", () => {
    render(<GeneralCard data-testid="card">Passive</GeneralCard>);
    const card = screen.getByTestId("card");
    expect(card).not.toHaveAttribute("role");
    expect(card).not.toHaveAttribute("tabindex");
    expect(card.className).not.toMatch(/cursor-pointer/);
  });

  it("exports a cva helper for variant class generation", () => {
    expect(generalCardVariants({ variant: "elevated" })).toContain("shadow-[0_0_16px_0_#00000014,0_0_6px_0_#0000001F]");
    expect(generalCardVariants()).toContain("[--card-padding-y:16px]");
    expect(generalCardVariants()).toContain("[--card-gap:14px]");
  });

  it("keeps ComponentPropsWithoutRef-compatible polymorphic props", () => {
    // Compile-time contract: as="section" should accept section attributes.
    const props: ComponentPropsWithoutRef<"section"> & {
      as: "section";
      variant: "outlined";
    } = {
      as: "section",
      variant: "outlined",
      "aria-labelledby": "card-title",
    };

    render(
      <GeneralCard {...props} data-testid="card">
        <GeneralCardTitle id="card-title">Section card</GeneralCardTitle>
      </GeneralCard>
    );

    expect(screen.getByTestId("card").tagName).toBe("SECTION");
    expect(screen.getByTestId("card")).toHaveAttribute("aria-labelledby", "card-title");
  });
});
