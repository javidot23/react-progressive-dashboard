import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import AppliedFilters, { AppliedFiltersConfig } from "@/components/atoms/AppliedFilters";

jest.mock("@/hooks", () => ({
  useRiskModelDescriptions: () => {
    const labels: Record<string, string> = {
      Operational: "Operational Risk",
      Environmental: "Environmental Risk",
      Financial: "Financial Risk",
    };
    return {
      getEnrichedMetadata: (risk: string) => ({
        display_name: labels[risk] || risk,
        original_risk_type: risk,
        risk_type: risk,
        risk_description: risk,
      }),
    };
  },
}));

jest.mock("@/lib/vendorUtils", () => ({
  formatNumber: jest.fn((num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(2)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(2)}k`;
    }
    return num.toString();
  }),
}));

describe("AppliedFilters", () => {
  const defaultConfig: AppliedFiltersConfig = {
    filterLabels: {
      search: "Search",
      risk_rating_min: "Risk Score Min",
      risk_rating_max: "Risk Score Max",
      primary_risk: "Driving Risk",
      driving_risk: "Driving Risk",
      ordering: "Ordering",
      risk_adjusted_value_min: "Risk Adjusted Value Min",
      risk_adjusted_value_max: "Risk Adjusted Value Max",
    },
    fieldLabels: {
      name: "Name",
      risk_score: "Risk Score",
      risk_rating: "Risk Score",
    },
    defaultFilters: {
      search: "",
      risk_rating_min: null,
      risk_rating_max: null,
      primary_risk: "",
      ordering: "name",
    },
  };

  const mockSetFilters = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("Rendering", () => {
    it("renders nothing when no filters are applied", () => {
      render(
        <AppliedFilters
          filters={defaultConfig.defaultFilters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      expect(screen.queryByTestId("applied-filters")).toBeInTheDocument();
      expect(screen.queryByText("Clear all Filters")).not.toBeInTheDocument();
    });

    it("renders clear all button when filters are applied", () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        search: "test",
        primary_risk: "Operational",
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      expect(screen.getByText("Clear all Filters")).toBeInTheDocument();
    });

    it("renders applied filter chips", () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        search: "test",
        primary_risk: "Operational",
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      expect(screen.getByText(/Search: test/)).toBeInTheDocument();
      expect(screen.getByText(/Driving Risk: Operational/)).toBeInTheDocument();
    });
  });

  describe("Filter Removal", () => {
    it("removes a filter when X button is clicked", async () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        search: "test",
        primary_risk: "Operational",
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      const removeButtons = screen.getAllByText("✕");
      await userEvent.click(removeButtons[0]);

      expect(mockSetFilters).toHaveBeenCalled();
    });

    it("removes range filter correctly", async () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        risk_rating_min: 0.5,
        risk_rating_max: 0.8,
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      const removeButtons = screen.getAllByText("✕");
      await userEvent.click(removeButtons[0]);

      expect(mockSetFilters).toHaveBeenCalled();
    });

    it("resets ordering to default when removed", async () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        ordering: "-risk_score",
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      const removeButton = screen.getByText("✕");
      await userEvent.click(removeButton);

      expect(mockSetFilters).toHaveBeenCalledWith({
        ...filters,
        ordering: "name",
      });
    });
  });

  describe("Clear All Filters", () => {
    it("clears all filters when clear all button is clicked", async () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        search: "test",
        primary_risk: "Operational",
        risk_rating_min: 0.5,
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      const clearAllButton = screen.getByText("Clear all Filters");
      await userEvent.click(clearAllButton);

      expect(mockSetFilters).toHaveBeenCalledWith(defaultConfig.defaultFilters);
    });
  });

  describe("Range Filters", () => {
    it("displays both min and max when both are set", () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        risk_rating_min: 0.5,
        risk_rating_max: 0.8,
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      expect(screen.getByText(/Risk Score Min: 0.5/)).toBeInTheDocument();
      expect(screen.getByText(/Risk Score Max: 0.8/)).toBeInTheDocument();
    });

    it("displays only min when max is not set", () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        risk_rating_min: 0.5,
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      expect(screen.getByText(/Risk Score Min: 0.5/)).toBeInTheDocument();
      expect(screen.queryByText(/Risk Score Max/)).not.toBeInTheDocument();
    });

    it("displays only max when min is not set", () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        risk_rating_max: 0.8,
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      expect(screen.getByText(/Risk Score Max: 0.8/)).toBeInTheDocument();
      expect(screen.queryByText(/Risk Score Min/)).not.toBeInTheDocument();
    });

    it("collapses effective_risk_rating presets into one chip and clears both bounds on remove", async () => {
      const config = {
        ...defaultConfig,
        filterLabels: {
          ...defaultConfig.filterLabels,
          effective_risk_rating_min: "Risk Score",
          effective_risk_rating_max: "Risk Score",
        },
        riskRatingRanges: {
          Likely: { min: 0.61, max: 0.8 },
        },
      };
      const filters = {
        ...defaultConfig.defaultFilters,
        effective_risk_rating_min: 0.61,
        effective_risk_rating_max: 0.8,
      };

      render(<AppliedFilters filters={filters} setFilters={mockSetFilters} config={config} />);

      expect(screen.getByText("Risk Score: Likely")).toBeInTheDocument();
      await userEvent.click(screen.getByText("✕"));
      expect(mockSetFilters).toHaveBeenCalledWith({
        ...filters,
        effective_risk_rating_min: null,
        effective_risk_rating_max: null,
      });
    });
  });

  describe("Lookup Items", () => {
    it("displays lookup item name when lookupKey is provided", () => {
      const config = {
        ...defaultConfig,
        lookupItems: [
          { vendor_id: 1, name: "Vendor 1" },
          { vendor_id: 2, name: "Vendor 2" },
        ],
        lookupKey: "vendor_id",
        lookupNameKey: "name",
        filterLabels: {
          ...defaultConfig.filterLabels,
          vendor_id: "Vendor",
        },
      };

      const filters = {
        ...defaultConfig.defaultFilters,
        vendor_id: 1,
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={config}
        />
      );

      expect(screen.getByText(/Vendor: Vendor 1/)).toBeInTheDocument();
    });

    it("displays raw value when lookup item not found", () => {
      const config = {
        ...defaultConfig,
        lookupItems: [
          { vendor_id: 1, name: "Vendor 1" },
        ],
        lookupKey: "vendor_id",
        lookupNameKey: "name",
        filterLabels: {
          ...defaultConfig.filterLabels,
          vendor_id: "Vendor",
        },
      };

      const filters = {
        ...defaultConfig.defaultFilters,
        vendor_id: 999,
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={config}
        />
      );

      expect(screen.getByText(/Vendor: 999/)).toBeInTheDocument();
    });

    it("displays (id) Name for multiple filter keys when lookupByFilterKey is provided", () => {
      const config = {
        ...defaultConfig,
        filterLabels: {
          ...defaultConfig.filterLabels,
          vendor_nbr: "Supplier",
          plant_nbr: "Distribution Center",
        },
        lookupByFilterKey: {
          vendor_nbr: {
            items: [
              { vendor_nbr: "V001", name: "Vendor Alpha" },
              { vendor_nbr: "V002", name: "Vendor Beta" },
            ],
            idKey: "vendor_nbr",
            nameKey: "name",
            showIdInLabel: true,
          },
          plant_nbr: {
            items: [
              { plant_nbr: "P001", name: "Plant One" },
              { plant_nbr: "P002", name: "Plant Two" },
            ],
            idKey: "plant_nbr",
            nameKey: "name",
            showIdInLabel: true,
          },
        },
      };

      const filters = {
        ...defaultConfig.defaultFilters,
        vendor_nbr: "V001",
        plant_nbr: "P002",
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={config}
        />
      );

      expect(screen.getByText(/Supplier: \(V001\) Vendor Alpha/)).toBeInTheDocument();
      expect(screen.getByText(/Distribution Center: \(P002\) Plant Two/)).toBeInTheDocument();
    });
  });

  describe("Edge Cases", () => {
    it("handles empty filter labels gracefully", () => {
      const config = {
        ...defaultConfig,
        filterLabels: {
          ...defaultConfig.filterLabels,
          test_filter: "",
        },
      };

      const filters = {
        ...defaultConfig.defaultFilters,
        test_filter: "value",
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={config}
        />
      );

      expect(screen.getByTestId("applied-filters")).toBeInTheDocument();
    });

    it("handles null and undefined filter values", () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        search: null,
        primary_risk: undefined,
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={defaultConfig}
        />
      );

      expect(screen.queryByText("Clear all Filters")).not.toBeInTheDocument();
    });

    it("handles has_no_actions filter", () => {
      const filters = {
        ...defaultConfig.defaultFilters,
        has_no_actions: true,
      };

      const config = {
        ...defaultConfig,
        filterLabels: {
          ...defaultConfig.filterLabels,
          has_no_actions: "Has No Actions",
        },
      };

      render(
        <AppliedFilters
          filters={filters}
          setFilters={mockSetFilters}
          config={config}
        />
      );

      expect(screen.getByText(/Has No Actions: Not Reviewed/)).toBeInTheDocument();
    });
  });
});
