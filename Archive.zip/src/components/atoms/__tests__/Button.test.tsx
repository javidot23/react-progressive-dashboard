import "@testing-library/jest-dom";
import { createRef } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { buttonStyles } from "@/components/atoms/Button.styles";
import { Button, type ButtonAction, type ButtonSize, type ButtonVariant } from "@/components/atoms/Button";

const actions: ButtonAction[] = ["primary", "secondary", "inverse", "danger", "success", "highlight"];
const variants: ButtonVariant[] = ["fill", "outline", "text"];

const expectedActionClasses: Record<ButtonAction, Record<ButtonVariant, string[]>> = {
  primary: {
    fill: ["bg-interactive-primary", "not-disabled:hover:bg-interactive-primary-hover"],
    outline: ["border-interactive-primary", "focus-visible:bg-brand-50"],
    text: ["text-interactive-primary", "not-disabled:active:bg-brand-100"],
  },
  secondary: {
    fill: ["bg-neutral-100", "not-disabled:active:bg-neutral-300"],
    outline: ["border-neutral-200", "not-disabled:hover:bg-neutral-100"],
    text: ["text-interactive-primary", "focus-visible:bg-neutral-100"],
  },
  inverse: {
    fill: ["bg-interactive-primary-inverse", "text-text-primary"],
    outline: ["border-interactive-primary-inverse", "not-disabled:hover:bg-interactive-primary-inverse/10"],
    text: ["text-interactive-primary-inverse", "not-disabled:active:bg-interactive-primary-inverse/20"],
  },
  danger: {
    fill: ["bg-interactive-danger", "not-disabled:active:bg-interactive-danger-active"],
    outline: ["border-interactive-danger", "focus-visible:bg-danger-50"],
    text: ["text-interactive-danger", "not-disabled:active:bg-danger-100"],
  },
  success: {
    fill: ["bg-interactive-success", "not-disabled:active:bg-interactive-success-active"],
    outline: ["border-interactive-success", "focus-visible:bg-success-50"],
    text: ["text-interactive-success", "not-disabled:active:bg-success-100"],
  },
  highlight: {
    fill: ["bg-interactive-highlight", "not-disabled:active:bg-interactive-highlight-active"],
    outline: ["border-interactive-highlight", "focus-visible:bg-highlight-50"],
    text: ["text-interactive-highlight", "not-disabled:active:bg-highlight-100"],
  },
};

describe("Button", () => {
  it("uses the agreed primary fill medium defaults", () => {
    render(<Button>Save</Button>);

    const button = screen.getByRole("button", { name: "Save" });
    expect(button).toHaveAttribute("data-action", "primary");
    expect(button).toHaveAttribute("data-variant", "fill");
    expect(button).toHaveAttribute("data-size", "md");
    expect(button).toHaveClass("h-10 font-button-sm [font-size:var(--cds-text-button-sm-font-size)] leading-button-sm");
    expect(button).toHaveClass("bg-interactive-primary focus-visible:shadow-ring-default");
    expect(button).toHaveClass("text-center not-italic font-bold");
  });

  it.each(actions.flatMap(action => variants.map(variant => [action, variant] as const)))(
    "renders the %s %s combination with native interaction and disabled classes",
    (action, variant) => {
      render(
        <Button action={action} variant={variant}>
          Action
        </Button>
      );

      const button = screen.getByRole("button", { name: "Action" });
      expect(button).toHaveAttribute("data-action", action);
      expect(button).toHaveAttribute("data-variant", variant);
      expectedActionClasses[action][variant].forEach(className => expect(button).toHaveClass(className));
      expect(button.className).toContain("focus-visible:");
      expect(button.className).toContain("not-disabled:hover:");
      expect(button.className).toContain("not-disabled:active:");
      expect(button.className).toContain("disabled:");
    }
  );

  it.each([
    ["sm", "h-8", "font-button-2xs", "[font-size:var(--cds-text-button-2xs-font-size)]", "leading-button-2xs", "[&_svg]:size-3"],
    ["md", "h-10", "font-button-sm", "[font-size:var(--cds-text-button-sm-font-size)]", "leading-button-sm", "[&_svg]:size-4"],
    ["lg", "h-12", "font-button-md", "[font-size:var(--cds-text-button-md-font-size)]", "leading-button-md", "[&_svg]:size-5"],
    ["xl", "h-14", "font-button-lg", "[font-size:var(--cds-text-button-lg-font-size)]", "leading-button-lg", "[&_svg]:size-6"],
  ] as const)("applies the %s size geometry and typography", (size, height, family, fontSize, lineHeight, iconSize) => {
    render(<Button size={size}>Size</Button>);
    expect(screen.getByRole("button", { name: "Size" })).toHaveClass([height, family, fontSize, lineHeight, iconSize].join(" "));
  });

  it("disables interaction and exposes busy state while loading", async () => {
    const user = userEvent.setup();
    const onClick = jest.fn();
    render(
      <Button isLoading onClick={onClick} startIcon={<svg data-testid="start" />} endIcon={<svg data-testid="end" />}>
        Saving
      </Button>
    );

    const button = screen.getByRole("button", { name: "Saving" });
    expect(button).toBeDisabled();
    expect(button).toHaveAttribute("aria-busy", "true");
    expect(button.querySelector('[data-slot="button-spinner"]')).toBeInTheDocument();
    expect(screen.queryByTestId("start")).not.toBeInTheDocument();
    expect(screen.queryByTestId("end")).not.toBeInTheDocument();
    await user.click(button);
    expect(onClick).not.toHaveBeenCalled();
  });

  it("uses native disabled semantics without reporting a busy state", async () => {
    const user = userEvent.setup();
    const onClick = jest.fn();
    render(
      <Button disabled onClick={onClick}>
        Unavailable
      </Button>
    );

    const button = screen.getByRole("button", { name: "Unavailable" });
    expect(button).toBeDisabled();
    expect(button).not.toHaveAttribute("aria-busy");
    await user.click(button);
    expect(onClick).not.toHaveBeenCalled();
  });

  it("renders decorative start and end icons when idle", () => {
    render(
      <Button startIcon={<svg data-testid="start" />} endIcon={<svg data-testid="end" />}>
        Continue
      </Button>
    );

    expect(screen.getByTestId("start").parentElement).toHaveAttribute("aria-hidden", "true");
    expect(screen.getByTestId("end").parentElement).toHaveAttribute("aria-hidden", "true");
  });

  it("forwards refs, native attributes, explicit type, and consumer classes", () => {
    const ref = createRef<HTMLButtonElement>();
    render(
      <Button ref={ref} type="submit" name="save" className="w-full bg-black">
        Save
      </Button>
    );

    expect(ref.current).toBe(screen.getByRole("button", { name: "Save" }));
    expect(ref.current).toHaveAttribute("type", "submit");
    expect(ref.current).toHaveAttribute("name", "save");
    expect(ref.current).toHaveClass("w-full bg-black");
  });

  it("lets consumer classes override matching native interaction styles", () => {
    render(<Button className="not-disabled:hover:bg-black">Override</Button>);

    const button = screen.getByRole("button", { name: "Override" });
    expect(button).toHaveClass("not-disabled:hover:bg-black");
    expect(button).not.toHaveClass("not-disabled:hover:bg-interactive-primary-hover");
  });

  it("lets buttonStyles share the exact component styling without rendering a button", () => {
    const classes = buttonStyles({ action: "danger", variant: "outline", size: "xl" });
    expect(classes).toContain("border-interactive-danger");
    expect(classes).toContain("h-14");
    expect(classes).toContain("focus-visible:shadow-ring-default");
    expect(classes).toContain("not-disabled:hover:bg-danger-50");
  });

  it.each(["sm", "md", "lg", "xl"] as ButtonSize[])("sizes the loading spinner for %s", size => {
    const { unmount } = render(
      <Button size={size} isLoading>
        Loading
      </Button>
    );
    const spinner = screen.getByRole("button", { name: "Loading" }).querySelector('[data-slot="button-spinner"]');
    expect(spinner).toHaveClass({ sm: "size-3", md: "size-4", lg: "size-5", xl: "size-6" }[size]);
    unmount();
  });
});
