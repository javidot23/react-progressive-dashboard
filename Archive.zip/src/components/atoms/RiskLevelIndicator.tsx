import { cn } from "@/lib/utils";
import type { IssueItem } from "@/lib/types";

const riskLevelColors: Record<IssueItem["riskLevel"], string> = {
  Critical: "bg-status-error-main",
  High: "bg-status-warning-main",
  Medium: "bg-status-warning-main", // Using warning color for medium risk
  Low: "bg-status-success-main", // Using success color for low risk
  Watch: "bg-status-warning-main",
};

interface RiskLevelIndicatorProps {
  level: IssueItem["riskLevel"];
  showText?: boolean;
}

export function RiskLevelIndicator({ level, showText = true }: RiskLevelIndicatorProps) {
  const bars = level === "Critical" ? 4 : level === "High" ? 3 : level === "Medium" ? 2 : 1;
  return (
    <div className="flex items-center">
      <div className="w-8 h-2 flex items-center mr-2">
        {Array(4)
          .fill(0)
          .map((_, i) => (
            <span
              key={i}
              className={cn(
                "h-full w-1.5 mx-px rounded-sm", // Added rounded-sm for slight softening
                i < bars ? riskLevelColors[level] : "bg-ui-background-muted"
              )}
            ></span>
          ))}
      </div>
      {showText && <span className="text-sm text-ui-text-secondary">{level}</span>}
    </div>
  );
}
