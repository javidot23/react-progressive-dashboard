import React from "react";

export interface StatusBadgeProps {
  /**
   * Status type - determines the badge appearance
   */
  status: "reviewed" | "not_reviewed";
  /**
   * Size variant of the badge
   * @default "sm"
   */
  size?: "xs" | "sm" | "md";
  /**
   * Additional CSS classes to apply to the badge
   */
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = "sm", className = "" }) => {
  const getStatusInfo = (status: "reviewed" | "not_reviewed") => {
    switch (status) {
      case "reviewed":
        return {
          text: "Reviewed",
          bgColor: "bg-background-tertiary",
          textColor: "text-text-primary",
          borderColor: "border-background-tertiary",
        };
      case "not_reviewed":
        return {
          text: "Not Reviewed",
          bgColor: "bg-interactive-highlight",
          textColor: "text-text-primary-inverse",
          borderColor: "border-interactive-highlight",
        };
      default:
        return {
          text: "Unknown",
          bgColor: "bg-gray-100",
          textColor: "text-gray-800",
          borderColor: "border-gray-200",
        };
    }
  };

  const getSizeClasses = (size: "xs" | "sm" | "md") => {
    switch (size) {
      case "xs":
        return {
          container: "px-1.5 py-0.5 text-xs",
          text: "text-xs",
        };
      case "sm":
        return {
          container: "px-2 py-0.5 text-xs",
          text: "text-xs",
        };
      case "md":
        return {
          container: "px-2.5 py-1 text-sm",
          text: "text-sm",
        };
      default:
        return {
          container: "px-2 py-0.5 text-xs",
          text: "text-xs",
        };
    }
  };

  const statusInfo = getStatusInfo(status);
  const sizeClasses = getSizeClasses(size);

  return (
    <span
      className={`
        inline-flex items-center font-semibold rounded-full border
        ${statusInfo.bgColor} ${statusInfo.textColor} ${statusInfo.borderColor}
        ${sizeClasses.container}
        ${className}
      `}
    >
      <span className={sizeClasses.text}>{statusInfo.text}</span>
    </span>
  );
};

export default StatusBadge;
