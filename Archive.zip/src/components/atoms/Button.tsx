import { forwardRef } from "react";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { buttonStyles, type ButtonSize, type ButtonStyleProps } from "@/components/atoms/Button.styles";
import { cn } from "@/lib/utils";

export type { ButtonAction, ButtonSize, ButtonStyleProps, ButtonVariant } from "@/components/atoms/Button.styles";

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement>, ButtonStyleProps {
  isLoading?: boolean;
  startIcon?: ReactNode;
  endIcon?: ReactNode;
}

const spinnerSizes: Record<ButtonSize, string> = {
  sm: "size-3",
  md: "size-4",
  lg: "size-5",
  xl: "size-6",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      action = "primary",
      variant = "fill",
      size = "md",
      className,
      isLoading = false,
      children,
      disabled,
      startIcon,
      endIcon,
      ...props
    },
    ref
  ) => {
    const isDisabled = disabled || isLoading;

    return (
      <button
        {...props}
        ref={ref}
        className={cn(buttonStyles({ action, variant, size }), className)}
        disabled={isDisabled}
        aria-busy={isLoading || undefined}
        data-action={action}
        data-variant={variant}
        data-size={size}
      >
        {isLoading ? (
          <span
            aria-hidden="true"
            data-slot="button-spinner"
            className={cn("shrink-0 animate-spin rounded-full border-2 border-current border-t-transparent", spinnerSizes[size])}
          />
        ) : (
          startIcon && (
            <span aria-hidden="true" data-slot="button-start-icon" className="inline-flex shrink-0">
              {startIcon}
            </span>
          )
        )}

        {children}

        {!isLoading && endIcon && (
          <span aria-hidden="true" data-slot="button-end-icon" className="inline-flex shrink-0">
            {endIcon}
          </span>
        )}
      </button>
    );
  }
);

Button.displayName = "Button";
