import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import { dateToISO, parseISO, startOfWeek, isSameDay, getToday } from "@/lib/dateUtils";
import { cn } from "@/lib/utils";

function getCalendarWeeks(year: number, month: number): (Date | null)[][] {
  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  const startDay = first.getDay();
  const startOffset = startDay === 0 ? 6 : startDay - 1;
  const weeks: (Date | null)[][] = [];
  let currentWeek: (Date | null)[] = [];

  for (let i = 0; i < startOffset; i++) {
    currentWeek.push(null);
  }

  const d = new Date(first);
  while (d <= last) {
    currentWeek.push(new Date(d));
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
    d.setDate(d.getDate() + 1);
  }

  if (currentWeek.length > 0) {
    while (currentWeek.length < 7) currentWeek.push(null);
    weeks.push(currentWeek);
  }
  return weeks;
}

const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

function formatWeekDisplay(weekYyyyMmDd: string): string {
  const d = new Date(weekYyyyMmDd + "T12:00:00");
  if (isNaN(d.getTime())) return weekYyyyMmDd;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export interface WeekMondayCalendarProps {
  title: string;
  /** Selected week as ISO date of that week's Monday (YYYY-MM-DD). */
  valueMonday: string;
  onSelectWeekMonday: (mondayISO: string) => void;
  /** Return true if the Monday (week start) for this calendar day is not selectable. */
  isWeekMondayDisabled: (weekMonday: Date) => boolean;
}

function WeekMondayCalendarInner({ title, valueMonday, onSelectWeekMonday, isWeekMondayDisabled }: WeekMondayCalendarProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const today = useMemo(getToday, []);
  const selectedMonday = parseISO(valueMonday);

  const [viewMonth, setViewMonth] = useState(() => {
    const base = selectedMonday ?? today;
    return new Date(base.getFullYear(), base.getMonth(), 1);
  });

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (e: MouseEvent | TouchEvent) => {
      const node = rootRef.current;
      const target = e.target as Node;
      if (node && !node.contains(target)) {
        setOpen(false);
      }
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("touchstart", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("touchstart", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  const weeks = getCalendarWeeks(viewMonth.getFullYear(), viewMonth.getMonth());
  const goPrev = () => setViewMonth(m => new Date(m.getFullYear(), m.getMonth() - 1, 1));
  const goNext = () => {
    const next = new Date(viewMonth.getFullYear(), viewMonth.getMonth() + 1, 1);
    if (next <= today) setViewMonth(() => next);
  };

  const handleDayClick = useCallback(
    (day: Date) => {
      const monday = startOfWeek(day);
      if (isWeekMondayDisabled(monday)) return;
      onSelectWeekMonday(dateToISO(monday));
      setOpen(false);
    },
    [isWeekMondayDisabled, onSelectWeekMonday]
  );

  const isInSelectedWeek = useCallback(
    (day: Date) => {
      if (!selectedMonday) return false;
      return isSameDay(startOfWeek(day), selectedMonday);
    },
    [selectedMonday]
  );

  return (
    <div ref={rootRef} className="relative min-w-0 w-full sm:w-[min(100%,280px)]">
      <button
        type="button"
        id={`week-cal-trigger-${title.replace(/\s+/g, "-").toLowerCase()}`}
        aria-expanded={open}
        aria-haspopup="dialog"
        onClick={() => setOpen(o => !o)}
        className={cn(
          "w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-md border border-ui-border-primary",
          "bg-white text-left text-ui-text-primary",
          "hover:border-gray-400 transition-colors",
          "focus:outline-hidden focus:ring-2 focus:ring-brand-primary-main focus:border-transparent"
        )}
      >
        <span className="min-w-0">
          <span className="text-xs font-medium text-ui-text-secondary block truncate">{title}</span>
          <span className="text-sm font-semibold truncate block">{formatWeekDisplay(valueMonday)}</span>
        </span>
        <ChevronDown
          className={cn("h-4 w-4 shrink-0 text-ui-text-secondary transition-transform", open && "rotate-180")}
          aria-hidden
        />
      </button>

      {open && (
        <div
          role="dialog"
          aria-label={title}
          className="absolute top-full left-0 mt-1 z-100 p-3 sm:p-4 bg-white border border-ui-border-primary rounded-md shadow-lg"
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <button
              type="button"
              onClick={goPrev}
              className="p-1.5 rounded hover:bg-gray-100 text-gray-600 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main"
              aria-label={`Previous month (${title})`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <span className="text-xs sm:text-sm font-medium text-gray-800">
              {MONTHS[viewMonth.getMonth()]} {viewMonth.getFullYear()}
            </span>
            <button
              type="button"
              onClick={goNext}
              disabled={new Date(viewMonth.getFullYear(), viewMonth.getMonth() + 1, 1) > today}
              className="p-1.5 rounded hover:bg-gray-100 text-gray-600 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main"
              aria-label={`Next month (${title})`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
          <div className="grid grid-cols-7 gap-0.5 sm:gap-1 text-center">
            {WEEKDAYS.map(w => (
              <div key={w} className="text-[10px] sm:text-xs font-medium text-gray-500 py-1 sm:py-1.5">
                {w}
              </div>
            ))}
            {weeks.flat().map((day, i) => {
              if (!day) {
                return <div key={`empty-${title}-${i}`} className="w-7 h-7 sm:w-9 sm:h-9" />;
              }
              const weekStart = startOfWeek(day);
              const disabled = isWeekMondayDisabled(weekStart);
              const inSelectedWeek = isInSelectedWeek(day);
              return (
                <button
                  key={day.toISOString()}
                  type="button"
                  onClick={() => !disabled && handleDayClick(day)}
                  disabled={disabled}
                  className={cn(
                    "w-7 h-7 sm:w-9 sm:h-9 text-xs sm:text-sm  flex items-center justify-center",
                    disabled && "text-gray-300 cursor-not-allowed",
                    !disabled && inSelectedWeek && "bg-brand-primary-main text-white font-medium",
                    !disabled && !inSelectedWeek && "hover:bg-gray-100 text-gray-700",
                    !disabled &&
                      !inSelectedWeek &&
                      "focus:outline-hidden focus-visible:ring-2 focus-visible:ring-brand-primary-main focus-visible:ring-offset-1"
                  )}
                >
                  {day.getDate()}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export const WeekMondayCalendar = memo(WeekMondayCalendarInner);
