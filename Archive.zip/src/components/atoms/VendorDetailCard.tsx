import React from "react";

interface VendorDetailCardProps {
  title: string | React.ReactNode;
  subtitle?: string;
  value: string | React.ReactNode;
  badge?: React.ReactNode;
  hasSpecialLayout?: boolean;
  index?: number;
  onClick?: () => void;
}

const VendorDetailCard: React.FC<VendorDetailCardProps> = ({
  title,
  subtitle,
  value,
  badge,
  hasSpecialLayout = false,
  index = 0,
  onClick,
}) => {
  const getPaddingClass = () => {
    if (index === 0) {
      return "px-2 pt-1";
    }
    return "px-4 pt-3";
  };

  return (
    <div
      className={`bg-white border-1 border-neutral-200 rounded-md ${getPaddingClass()} ${onClick ? 'cursor-pointer' : ''}`}
      onClick={onClick}
    >
      {hasSpecialLayout ? (
        <div className="flex justify-between items-center space-x-2 mb-1">
          <div className="text-sm text-[#6E6E6E] font-normal text-nowrap">
            {title}
          </div>
          {badge}
        </div>
      ) : (
        <div className="flex flex-col">
          {typeof title === "string" ? (
            <div className="text-sm text-[#6E6E6E] font-normal text-nowrap">
              {title}
            </div>
          ) : (
            <div>{title}</div>
          )}
          {subtitle && (
            <div className="text-xs text-neutral-900">{subtitle}</div>
          )}
        </div>
      )}

      {typeof value === "string" ? (
        <div className="font-bold text-neutral-900 text-[17.44px] mt-1">
          {value}
        </div>
      ) : (
        <div className="mt-1">{value}</div>
      )}
    </div>
  );
};

export default VendorDetailCard;
