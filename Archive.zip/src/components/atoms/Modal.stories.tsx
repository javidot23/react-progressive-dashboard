import { Meta, StoryObj } from "@storybook/react";
import { Modal } from "./Modal";

const meta: Meta<typeof Modal> = {
  title: "Atoms/Modal",
  component: Modal,
  tags: ["autodocs"],
  args: {
    isOpen: true,
    title: "Modal Title",
    children: <p>This is the content of the modal.</p>,
  },
  parameters: {
    docs: {
      description: {
        component: "A basic modal component.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
