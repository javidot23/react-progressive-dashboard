import { useCallback, useEffect, useRef } from "react";

const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

export function getFocusableElements(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
    el => !el.hasAttribute("disabled") && el.getAttribute("aria-hidden") !== "true"
  );
}

interface UseDialogFocusTrapOptions {
  isOpen: boolean;
  onClose: () => void;
  containerRef: React.RefObject<HTMLElement | null>;
  closeOnEscape?: boolean;
  triggerRef?: React.RefObject<HTMLElement | null>;
}

export function useDialogFocusTrap({
  isOpen,
  onClose,
  containerRef,
  closeOnEscape = true,
  triggerRef,
}: UseDialogFocusTrapOptions) {
  const previousFocusRef = useRef<HTMLElement | null>(null);

  const onKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        if (closeOnEscape) {
          event.preventDefault();
          onClose();
        }
        return;
      }

      if (event.key !== "Tab" || !containerRef.current) {
        return;
      }

      const focusable = getFocusableElements(containerRef.current);
      if (focusable.length === 0) {
        event.preventDefault();
        return;
      }

      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      const active = document.activeElement as HTMLElement | null;

      if (event.shiftKey) {
        if (active === first || !containerRef.current.contains(active)) {
          event.preventDefault();
          last.focus({ preventScroll: true });
        }
      } else if (active === last) {
        event.preventDefault();
        first.focus({ preventScroll: true });
      }
    },
    [closeOnEscape, containerRef, onClose]
  );

  useEffect(() => {
    if (!isOpen) {
      return undefined;
    }

    previousFocusRef.current = (triggerRef?.current as HTMLElement | null) ?? (document.activeElement as HTMLElement | null);

    const focusTimer = window.setTimeout(() => {
      if (!containerRef.current) return;
      const focusable = getFocusableElements(containerRef.current);
      if (focusable.length > 0) {
        focusable[0].focus({ preventScroll: true });
      } else {
        containerRef.current.focus({ preventScroll: true });
      }
    }, 0);

    document.addEventListener("keydown", onKeyDown);

    return () => {
      window.clearTimeout(focusTimer);
      document.removeEventListener("keydown", onKeyDown);
      const previousFocus = previousFocusRef.current;
      if (previousFocus?.isConnected) {
        previousFocus.focus({ preventScroll: true });
      }
    };
  }, [isOpen, onKeyDown, containerRef, triggerRef]);
}
