import React, { HTMLAttributes } from 'react'
import { cn } from '@/lib/utils'

export interface TypographyProps extends HTMLAttributes<HTMLElement> {
  variant?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'body1' | 'body2' | 'caption' | 'overline'
  color?: 'primary' | 'secondary' | 'muted' | 'accent' | 'destructive'
  as?: keyof React.JSX.IntrinsicElements
}

export const Typography = ({
  variant = 'body1',
  color = 'primary',
  as,
  className,
  children,
  ...props
}: TypographyProps) => {
  const variants = {
    h1: 'text-4xl font-bold tracking-tight lg:text-5xl',
    h2: 'text-3xl font-semibold tracking-tight',
    h3: 'text-2xl font-semibold tracking-tight',
    h4: 'text-xl font-semibold tracking-tight',
    h5: 'text-lg font-semibold',
    h6: 'text-base font-semibold',
    body1: 'text-base',
    body2: 'text-sm',
    caption: 'text-xs text-ui-text-muted',
    overline: 'text-xs font-medium uppercase tracking-wide'
  }

  const colors = {
    primary: 'text-ui-text-primary',
    secondary: 'text-ui-text-secondary',
    muted: 'text-ui-text-muted',
    accent: 'text-brand-primary-main',
    destructive: 'text-status-error-main'
  }

  const defaultElement = {
    h1: 'h1',
    h2: 'h2',
    h3: 'h3',
    h4: 'h4',
    h5: 'h5',
    h6: 'h6',
    body1: 'p',
    body2: 'p',
    caption: 'span',
    overline: 'span'
  }

  const Component = (as || defaultElement[variant] || 'p') as React.ElementType

  return (
    <Component
      className={cn(variants[variant], colors[color], className)}
      {...props}
    >
      {children}
    </Component>
  )
}
