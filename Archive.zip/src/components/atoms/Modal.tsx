import React from 'react'
import { X } from 'lucide-react'
import { Button } from '@/components/atoms/Button'
import { useDialogFocusTrap } from '@/components/atoms/useDialogFocusTrap'

interface ModalProps {
  isOpen: boolean
  onClose: () => void
  title: string
  children: React.ReactNode
  className?: string
  triggerRef?: React.RefObject<HTMLElement | null>
  positioning?: 'center' | 'dropdown'
  closeOnEscape?: boolean
}

export function Modal({
  isOpen,
  onClose,
  title,
  children,
  className = '',
  triggerRef,
  positioning = 'center',
  closeOnEscape = true,
}: ModalProps) {
  const modalRef = React.useRef<HTMLDivElement>(null)
  const titleId = React.useId()

  useDialogFocusTrap({
    isOpen,
    onClose,
    containerRef: modalRef,
    closeOnEscape,
    triggerRef,
  })

  if (!isOpen) return null

  const header = (
    <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
      <h2 id={titleId} className="text-xl font-semibold text-gray-900">
        {title}
      </h2>
      <Button
        variant="ghost"
        size="sm"
        onClick={onClose}
        className="p-1 hover:bg-gray-100"
        aria-label={`Close ${title}`}
      >
        <X className="h-5 w-5 text-gray-400" aria-hidden />
      </Button>
    </div>
  )

  const dialogProps = {
    ref: modalRef,
    role: 'dialog' as const,
    'aria-modal': true,
    'aria-labelledby': titleId,
    tabIndex: -1,
  }

  if (positioning === 'dropdown') {
    return (
      <>
        <div
          className="fixed inset-0 z-100"
          onClick={onClose}
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.1)' }}
          aria-hidden="true"
        />

        <div
          {...dialogProps}
          className={`bg-white rounded-lg shadow-2xl border border-gray-300 ${className}`}
          style={{
            width: '522px',
            height: '515px',
            position: 'absolute',
            zIndex: 101,
            top: '100%',
            right: '0',
            marginTop: '8px'
          }}
        >
          {header}
          <div className="px-6 py-5">{children}</div>
        </div>
      </>
    )
  }

  return (
    <div className="fixed inset-0 z-9998 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        {...dialogProps}
        className={`relative bg-white rounded-lg shadow-xl max-w-lg w-full mx-4 ${className}`}
      >
        {header}
        <div className="px-6 py-5">{children}</div>
      </div>
    </div>
  )
}
