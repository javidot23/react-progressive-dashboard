import React from "react";

interface CircularProgressProps {
  value: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  trackColor?: string;
  showValue?: boolean;
  className?: string;
  renderCenter?: (value: number) => React.ReactNode;
}

export const CircularProgress: React.FC<CircularProgressProps> = ({
  value,
  size = 48,
  strokeWidth = 4,
  color,
  trackColor = "var(--cds-color-border-primary)",
  showValue = false,
  className = "",
  renderCenter,
}) => {
  const clampedValue = Math.max(0, Math.min(100, value));

  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - clampedValue / 100);
  const center = size / 2;

  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={center} cy={center} r={radius} fill="none" stroke={trackColor} strokeWidth={strokeWidth} />
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          transform={`rotate(-90 ${center} ${center})`}
          style={{ transition: "stroke-dashoffset 0.3s ease" }}
        />
      </svg>
      {(showValue || renderCenter) && (
        <div className="absolute inset-0 flex items-center justify-center">
          {renderCenter ? (
            renderCenter(clampedValue)
          ) : (
            <span className="font-bold text-[12px] text-brand-primary-main">{Math.round(clampedValue)}</span>
          )}
        </div>
      )}
    </div>
  );
};

export default CircularProgress;
