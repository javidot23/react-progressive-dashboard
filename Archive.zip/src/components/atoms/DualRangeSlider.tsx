import React, { useState, useRef, useEffect } from "react";

interface DualRangeSliderProps {
  min: number;
  max: number;
  step: number;
  minValue: number;
  maxValue: number;
  onMinChange: (value: number) => void;
  onMaxChange: (value: number) => void;
  onChangeEnd?: (minValue: number, maxValue: number) => void; // NEW: Called when sliding stops
  debounceMs?: number; // NEW: Optional debounce delay (default 300ms)
  minGap?: number;
}

const formatNumber = (num: number): string => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(2) + "M";
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(2) + "K";
  }
  return num.toString();
};

export default function DualRangeSlider({
  min,
  max,
  step,
  minValue,
  maxValue,
  onMinChange,
  onMaxChange,
  onChangeEnd,
  debounceMs = 300,
  minGap = 0,
}: DualRangeSliderProps) {
  const color = "#461E96";
  const [localMinValue, setLocalMinValue] = useState(minValue);
  const [localMaxValue, setLocalMaxValue] = useState(maxValue);
  const debounceTimeout = useRef<NodeJS.Timeout | null>(null);

  // Update local values when props change
  useEffect(() => {
    setLocalMinValue(minValue);
  }, [minValue]);

  useEffect(() => {
    setLocalMaxValue(maxValue);
  }, [maxValue]);

  const triggerChangeEnd = (newMin: number, newMax: number) => {
    if (debounceTimeout.current) {
      clearTimeout(debounceTimeout.current);
    }

    debounceTimeout.current = setTimeout(() => {
      onChangeEnd?.(newMin, newMax);
    }, debounceMs);
  };

  const handleMinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Math.min(Number(e.target.value), localMaxValue - minGap);
    setLocalMinValue(value);
    onMinChange(value); // Immediate UI update
    triggerChangeEnd(value, localMaxValue); // Debounced API call
  };

  const handleMaxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Math.max(Number(e.target.value), localMinValue + minGap);
    setLocalMaxValue(value);
    onMaxChange(value); // Immediate UI update
    triggerChangeEnd(localMinValue, value); // Debounced API call
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (debounceTimeout.current) {
        clearTimeout(debounceTimeout.current);
      }
    };
  }, []);

  const range = max - min;
  const minPercent = range > 0 ? ((localMinValue - min) / range) * 100 : 0;
  const maxPercent = range > 0 ? ((localMaxValue - min) / range) * 100 : 100;

  return (
    <div className="relative w-full my-2">
      {/* Track background */}
      <div className="h-2 bg-gray-200 rounded-lg relative">
        {/* Active range */}
        <div
          className="absolute h-2 rounded-lg"
          style={{
            left: `${minPercent}%`,
            right: `${100 - maxPercent}%`,
            backgroundColor: color,
          }}
        />
      </div>

      {/* Min Range Input */}
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={localMinValue}
        onChange={handleMinChange}
        className="absolute top-0 w-full h-2 bg-transparent appearance-none cursor-pointer pointer-events-none [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-pointer"
        style={
          {
            background: "transparent",
            WebkitSliderThumb: {
              backgroundColor: "white",
              border: `2px solid ${color}`,
            },
          } as any
        }
      />

      {/* Max Range Input */}
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={localMaxValue}
        onChange={handleMaxChange}
        className="absolute top-0 w-full h-2 bg-transparent appearance-none cursor-pointer pointer-events-none [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-pointer"
        style={
          {
            background: "transparent",
            WebkitSliderThumb: {
              backgroundColor: "white",
              border: `2px solid ${color}`,
            },
          } as any
        }
      />

      {/* Value labels */}
      <div className="flex justify-between text-xs text-gray-500 mt-1">
        <span>{formatNumber(localMinValue)}</span>
        <span>{formatNumber(localMaxValue)}</span>
      </div>

      <style>{`
        input[type="range"]::-webkit-slider-thumb {
          background-color: white !important;
          border: 2px solid ${color} !important;
        }
        input[type="range"]::-moz-range-thumb {
          background-color: white !important;
          border: 2px solid ${color} !important;
          border-radius: 50%;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
}
