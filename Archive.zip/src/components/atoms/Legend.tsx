import React from "react";

export interface LegendItem {
  id: string | number;
  label: string;
  color: string;
  shape?: "square" | "circle" | "line" | "gradient" | "triangle";
  gradient?: string;
  border?: string;
  size?: "sm" | "md" | "lg";
}

export interface LegendProps {
  items: LegendItem[];
  className?: string;
  orientation?: "horizontal" | "vertical";
  spacing?: "sm" | "md" | "lg";
}

const Legend: React.FC<LegendProps> = ({
  items,
  className = "",
  orientation = "horizontal",
  spacing = "md",
}) => {
  const spacingClasses = {
    sm: orientation === "horizontal" ? "space-x-2" : "space-y-2",
    md: orientation === "horizontal" ? "space-x-4" : "space-y-4",
    lg: orientation === "horizontal" ? "space-x-6" : "space-y-6",
  };

  // Fixed size and styling for consistency
  const BASE_SIZE = {
    sm: "w-[6px] h-[6px]",
    md: "w-[8px] h-[8px]",
    lg: "w-[10px] h-[10px]",
  };
  const TEXT_COLOR = "#525252";

  const getShapeElement = (item: LegendItem) => {
    const sizeClass = BASE_SIZE[item.size || "md"];

    switch (item.shape) {
      case "circle":
        return (
          <span
            className={`${sizeClass} block rounded-full`}
            style={{
              background: item.gradient || item.color,
              border: item.border,
            }}
          />
        );
      case "line":
        return (
          <span
            className="block h-[2px] w-4"
            style={{
              backgroundColor: item.color,
              border: item.border,
            }}
          />
        );
      case "gradient":
        return (
          <span
            className={`${sizeClass} block`}
            style={{
              background: item.gradient || item.color,
              border: item.border,
            }}
          />
        );
      case "square":
      default:
        return (
          <span
            className={`${sizeClass} block`}
            style={{
              backgroundColor: item.color,
              border: item.border,
            }}
          />
        );
    }
  };

  return (
    <div
      className={`${
        orientation === "horizontal"
          ? "grid grid-cols-1 sm:grid-cols-2 md:flex md:flex-row gap-2 sm:gap-3 md:gap-0"
          : "flex flex-col"
      } ${orientation === "horizontal" ? "" : spacingClasses[spacing]} ${
        orientation === "horizontal" ? "" : className
      } ${orientation === "vertical" ? className : ""}`}
    >
      {items.map((item) => (
        <div
          key={item.id}
          className={`flex flex-row items-center gap-2 ${
            orientation === "horizontal" ? "md:mr-4" : ""
          }`}
        >
          {getShapeElement(item)}
          <span
            className="text-[13px] leading-none"
            style={{ color: TEXT_COLOR }}
          >
            {item.label}
          </span>
        </div>
      ))}
    </div>
  );
};

export default Legend;
