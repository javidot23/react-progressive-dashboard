import { createPortal } from "react-dom";
import { useRef } from "react";
import { useDialogFocusTrap } from "@/components/atoms/useDialogFocusTrap";
import { useBodyScrollLock } from "@/hooks/useBodyScrollLock";

export interface ModalShellProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  /** id of the visible title element for aria-labelledby */
  ariaLabelledBy: string;
  /** When false, Escape does not close (e.g. DecisionRationaleModal requires submit). */
  closeOnEscape?: boolean;
  className?: string;
  overlayClassName?: string;
  zIndex?: number;
  usePortal?: boolean;
  triggerRef?: React.RefObject<HTMLElement | null>;
  lockScroll?: boolean;
}

/**
 * Accessible dialog shell: backdrop, focus trap, dialog semantics.
 * Use for bespoke modals that need custom layout beyond Modal.tsx.
 */
export function ModalShell({
  isOpen,
  onClose,
  children,
  ariaLabelledBy,
  closeOnEscape = true,
  className = "",
  overlayClassName = "fixed inset-0 flex items-center justify-center overscroll-none p-4",
  zIndex = 9998,
  usePortal = false,
  triggerRef,
  lockScroll = true,
}: ModalShellProps) {
  const dialogRef = useRef<HTMLDivElement>(null);

  useBodyScrollLock(isOpen && usePortal && lockScroll);

  useDialogFocusTrap({
    isOpen,
    onClose,
    containerRef: dialogRef,
    closeOnEscape,
    triggerRef,
  });

  if (!isOpen) return null;

  const content = (
    <div className={overlayClassName} style={{ zIndex }}>
      <div
        className="absolute inset-0 bg-black/50"
        onClick={closeOnEscape ? onClose : undefined}
        aria-hidden="true"
      />
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={ariaLabelledBy}
        tabIndex={-1}
        className={`z-10 ${className}`}
        onClick={e => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );

  if (usePortal) {
    return createPortal(content, document.body);
  }

  return content;
}
