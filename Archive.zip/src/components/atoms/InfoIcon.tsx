import React, { useState, useRef, useEffect } from "react";
import { createPortal } from "react-dom";

interface InfoIconProps {
  color?: string;
  size?: number;
  className?: string;
  tooltip?: string;
  position?: "top" | "bottom" | "left" | "right";
  showTooltip?: boolean;
  ariaLabel?: string;
}

const InfoIcon: React.FC<InfoIconProps> = ({
  color = "#461E96",
  size = 25,
  className = "",
  tooltip = "This tooltip content is for demonstration purposes only.",
  position = "top",
  showTooltip = true,
  ariaLabel = "Show information",
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isClicked, setIsClicked] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 });
  const iconRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const shouldShow = isHovered || isClicked;
    if (!shouldShow || !iconRef.current) return;

    const updatePosition = () => {
      if (!iconRef.current) return;

      const rect = iconRef.current.getBoundingClientRect();
      const isMobile = window.innerWidth < 768;
      const tooltipWidth = isMobile ? 200 : 320;
      const tooltipHeight = 150; // Approximate tooltip height

      let top = 0;
      let left = 0;
      let useBottomPosition = false;

      // Check available space above and below
      const spaceAbove = rect.top;
      const spaceBelow = window.innerHeight - rect.bottom;

      let useLeftPosition = false;
      let useRightPosition = false;

      // Smart positioning: always try to keep tooltip in viewport
      if (position === "left") {
        // Position to the left of the icon
        left = rect.left - tooltipWidth - 10;
        top = rect.top + rect.height / 2;
        useLeftPosition = true;
        useBottomPosition = false;
        useRightPosition = false;
      } else if (position === "right") {
        // Position to the right of the icon
        left = rect.right + 10;
        top = rect.top + rect.height / 2;
        useLeftPosition = false;
        useBottomPosition = false;
        useRightPosition = true;
      } else if (position === "bottom") {
        // Explicitly bottom - check if there's space
        if (spaceBelow >= tooltipHeight + 20) {
          top = rect.bottom + 10;
          left = rect.left + rect.width / 2 - tooltipWidth / 2;
          useBottomPosition = true;
        } else {
          // Not enough space below, flip to top
          top = rect.top - 10;
          left = rect.left + rect.width / 2 - tooltipWidth / 2;
          useBottomPosition = false;
        }
      } else {
        // Default: try top first
        left = rect.left + rect.width / 2 - tooltipWidth / 2;
        if (spaceAbove >= tooltipHeight + 20) {
          // Enough space above
          top = rect.top - 10;
          useBottomPosition = false;
        } else if (spaceBelow >= tooltipHeight + 20) {
          // Not enough above, use bottom
          top = rect.bottom + 10;
          useBottomPosition = true;
        } else {
          // Not enough space either side - use side with more space and constrain
          if (spaceAbove > spaceBelow) {
            top = rect.top - 10;
            useBottomPosition = false;
          } else {
            top = rect.bottom + 10;
            useBottomPosition = true;
          }
        }
      }

      // Keep within viewport horizontally
      if (left < 10) left = 10;
      if (left + tooltipWidth > window.innerWidth - 10) {
        left = window.innerWidth - tooltipWidth - 10;
      }

      // Final check: ensure tooltip doesn't go off screen vertically
      if (useBottomPosition) {
        const wouldExtendTo = top + tooltipHeight;
        if (wouldExtendTo > window.innerHeight - 10) {
          // Constrain to fit in viewport
          top = Math.max(10, window.innerHeight - tooltipHeight - 10);
        }
      }

      // Store position info for triangle rendering
      (iconRef.current as any).useBottomPosition = useBottomPosition;
      (iconRef.current as any).useLeftPosition = useLeftPosition;
      (iconRef.current as any).useRightPosition = useRightPosition;

      setTooltipPosition({ top, left });
    };

    updatePosition();
    window.addEventListener('scroll', updatePosition, true);
    window.addEventListener('resize', updatePosition);

    return () => {
      window.removeEventListener('scroll', updatePosition, true);
      window.removeEventListener('resize', updatePosition);
    };
  }, [isHovered, isClicked, position]);

  // Handle click outside to close tooltip on touch devices
  useEffect(() => {
    if (!isClicked) return;

    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (iconRef.current && !iconRef.current.contains(event.target as Node)) {
        setIsClicked(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, [isClicked]);

  const renderTooltip = () => {
    const shouldShow = isHovered || isClicked;
    if (!shouldShow || !showTooltip || !iconRef.current) return null;

    const isMobile = window.innerWidth < 768;
    const tooltipWidth = isMobile ? 200 : 320;

    // Calculate icon center position
    const iconRect = iconRef.current.getBoundingClientRect();
    const iconCenterX = iconRect.left + iconRect.width / 2;

    // Calculate triangle position relative to tooltip
    const triangleLeft = iconCenterX - tooltipPosition.left;

    // Check position flags (from smart positioning logic)
    const isBottomPosition = (iconRef.current as any).useBottomPosition;
    const isLeftPosition = (iconRef.current as any).useLeftPosition;
    const isRightPosition = (iconRef.current as any).useRightPosition;

    let transform = 'translateY(-100%)';
    let triangleStyle: any = {};

    if (isLeftPosition) {
      // Left position: triangle on right edge, pointing right
      transform = 'translateY(-50%)';
      triangleStyle = {
        top: '50%',
        right: '-5px',
        transform: 'translateY(-50%)',
        borderTop: '6px solid transparent',
        borderBottom: '6px solid transparent',
        borderLeft: '6px solid #211359',
      };
    } else if (isRightPosition) {
      // Right position: triangle on left edge, pointing left
      transform = 'translateY(-50%)';
      triangleStyle = {
        top: '50%',
        left: '-5px',
        transform: 'translateY(-50%)',
        borderTop: '6px solid transparent',
        borderBottom: '6px solid transparent',
        borderRight: '6px solid #211359',
      };
    } else if (isBottomPosition) {
      // Bottom position: triangle on top edge, pointing down
      transform = 'translateY(0)';
      triangleStyle = {
        top: '-5px',
        left: `${triangleLeft}px`,
        transform: 'translateX(-50%)',
        borderLeft: '6px solid transparent',
        borderRight: '6px solid transparent',
        borderBottom: '6px solid #211359',
      };
    } else {
      // Top position (default): triangle on bottom edge, pointing up
      transform = 'translateY(-100%)';
      triangleStyle = {
        bottom: '-5px',
        left: `${triangleLeft}px`,
        transform: 'translateX(-50%)',
        borderLeft: '6px solid transparent',
        borderRight: '6px solid transparent',
        borderTop: '6px solid #211359',
      };
    }

    return createPortal(
      <div
        className="fixed pointer-events-none transition-opacity duration-200"
        style={{
          top: `${tooltipPosition.top}px`,
          left: `${tooltipPosition.left}px`,
          zIndex: 99999,
          transform,
        }}
      >
        <div
          className="bg-[#211359] text-white text-xs rounded-md shadow-xl p-3 font-normal whitespace-normal wrap-break-word relative"
          style={{ width: tooltipWidth }}
        >
          {tooltip}
          {/* Triangle pointer - points to icon */}
          <div
            className="absolute"
            style={{
              width: 0,
              height: 0,
              ...triangleStyle,
            }}
          />
        </div>
      </div>,
      document.body
    );
  };

  const handleClick = () => {
    // Toggle click state for touch devices
    setIsClicked(!isClicked);
  };

  return (
    <div
      ref={iconRef}
      role="button"
      tabIndex={0}
      aria-label={ariaLabel}
      aria-expanded={isClicked}
      className="relative inline-block"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleClick}
      onKeyDown={event => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          handleClick();
        }
      }}
    >
      {renderTooltip()}

      <svg
        data-testid="info-icon"
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
        strokeWidth={1.5}
        stroke="currentColor"
        className={`${showTooltip ? "cursor-pointer" : ""} ${className}`}
        style={{
          width: `${size}px`,
          height: `${size}px`,
          color,
        }}
        aria-hidden
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021
             M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z"
        />
      </svg>
    </div>
  );
};

export default InfoIcon;
