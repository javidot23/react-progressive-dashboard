import { cva } from "class-variance-authority";

export type ButtonAction = "primary" | "secondary" | "inverse" | "danger" | "success" | "highlight";
export type ButtonVariant = "fill" | "outline" | "text";
export type ButtonSize = "sm" | "md" | "lg" | "xl";

export interface ButtonStyleProps {
  action?: ButtonAction;
  variant?: ButtonVariant;
  size?: ButtonSize;
}

const buttonVariants = cva(
  [
    "inline-flex min-w-8 items-center justify-center gap-1 rounded-md px-4 py-1.5 text-center not-italic font-bold transition-colors",
    "focus-visible:outline-hidden focus-visible:shadow-ring-default disabled:pointer-events-none",
  ].join(" "),
  {
    variants: {
      action: {
        primary: null,
        secondary: null,
        inverse: null,
        danger: null,
        success: null,
        highlight: null,
      },
      variant: {
        fill: "border-0",
        outline: "border-2 bg-transparent",
        text: "border-0 bg-transparent",
      },
      size: {
        sm: "h-8 max-h-8 font-button-2xs [font-size:var(--cds-text-button-2xs-font-size)] leading-button-2xs [&_svg]:size-3",
        md: "h-10 max-h-10 font-button-sm [font-size:var(--cds-text-button-sm-font-size)] leading-button-sm [&_svg]:size-4",
        lg: "h-12 max-h-12 font-button-md [font-size:var(--cds-text-button-md-font-size)] leading-button-md [&_svg]:size-5",
        xl: "h-14 max-h-14 font-button-lg [font-size:var(--cds-text-button-lg-font-size)] leading-button-lg [&_svg]:size-6",
      },
    },
    compoundVariants: [
      {
        action: "primary",
        variant: "fill",
        className:
          "bg-interactive-primary text-text-primary-inverse not-disabled:hover:bg-interactive-primary-hover focus-visible:bg-interactive-primary-focus not-disabled:active:bg-interactive-primary-active disabled:bg-interactive-disabled disabled:text-text-primary-inverse",
      },
      {
        action: "primary",
        variant: "outline",
        className:
          "border-interactive-primary text-interactive-primary not-disabled:hover:border-interactive-primary-hover not-disabled:hover:bg-brand-50 not-disabled:hover:text-interactive-primary-hover focus-visible:border-interactive-primary-focus focus-visible:bg-brand-50 focus-visible:text-interactive-primary-focus not-disabled:active:border-interactive-primary-active not-disabled:active:bg-brand-100 not-disabled:active:text-interactive-primary-active disabled:border-transparent disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "primary",
        variant: "text",
        className:
          "text-interactive-primary not-disabled:hover:bg-brand-50 not-disabled:hover:text-interactive-primary-hover focus-visible:bg-brand-50 focus-visible:text-interactive-primary-focus not-disabled:active:bg-brand-100 not-disabled:active:text-interactive-primary-active disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "secondary",
        variant: "fill",
        className:
          "bg-neutral-100 text-interactive-primary not-disabled:hover:bg-neutral-200 not-disabled:hover:text-interactive-primary-hover focus-visible:bg-neutral-200 focus-visible:text-interactive-primary-focus not-disabled:active:bg-neutral-300 not-disabled:active:text-interactive-primary-active disabled:bg-neutral-100 disabled:text-interactive-disabled",
      },
      {
        action: "secondary",
        variant: "outline",
        className:
          "border-neutral-200 text-interactive-primary not-disabled:hover:border-neutral-300 not-disabled:hover:bg-neutral-100 not-disabled:hover:text-interactive-primary-hover focus-visible:border-neutral-300 focus-visible:bg-neutral-100 focus-visible:text-interactive-primary-focus not-disabled:active:border-neutral-400 not-disabled:active:bg-neutral-200 not-disabled:active:text-interactive-primary-active disabled:border-transparent disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "secondary",
        variant: "text",
        className:
          "text-interactive-primary not-disabled:hover:bg-neutral-100 not-disabled:hover:text-interactive-primary-hover focus-visible:bg-neutral-100 focus-visible:text-interactive-primary-focus not-disabled:active:bg-neutral-200 not-disabled:active:text-interactive-primary-active disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "danger",
        variant: "fill",
        className:
          "bg-interactive-danger text-text-primary-inverse not-disabled:hover:bg-interactive-danger-hover focus-visible:bg-interactive-danger-focus not-disabled:active:bg-interactive-danger-active disabled:bg-interactive-disabled disabled:text-text-primary-inverse",
      },
      {
        action: "danger",
        variant: "outline",
        className:
          "border-interactive-danger text-interactive-danger not-disabled:hover:border-interactive-danger-hover not-disabled:hover:bg-danger-50 not-disabled:hover:text-interactive-danger-hover focus-visible:border-interactive-danger-focus focus-visible:bg-danger-50 focus-visible:text-interactive-danger-focus not-disabled:active:border-interactive-danger-active not-disabled:active:bg-danger-100 not-disabled:active:text-interactive-danger-active disabled:border-transparent disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "danger",
        variant: "text",
        className:
          "text-interactive-danger not-disabled:hover:bg-danger-50 not-disabled:hover:text-interactive-danger-hover focus-visible:bg-danger-50 focus-visible:text-interactive-danger-focus not-disabled:active:bg-danger-100 not-disabled:active:text-interactive-danger-active disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "success",
        variant: "fill",
        className:
          "bg-interactive-success text-text-primary-inverse not-disabled:hover:bg-interactive-success-hover focus-visible:bg-interactive-success-focus not-disabled:active:bg-interactive-success-active disabled:bg-interactive-disabled disabled:text-text-primary-inverse",
      },
      {
        action: "success",
        variant: "outline",
        className:
          "border-interactive-success text-interactive-success not-disabled:hover:border-interactive-success-hover not-disabled:hover:bg-success-50 not-disabled:hover:text-interactive-success-hover focus-visible:border-interactive-success-focus focus-visible:bg-success-50 focus-visible:text-interactive-success-focus not-disabled:active:border-interactive-success-active not-disabled:active:bg-success-100 not-disabled:active:text-interactive-success-active disabled:border-transparent disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "success",
        variant: "text",
        className:
          "text-interactive-success not-disabled:hover:bg-success-50 not-disabled:hover:text-interactive-success-hover focus-visible:bg-success-50 focus-visible:text-interactive-success-focus not-disabled:active:bg-success-100 not-disabled:active:text-interactive-success-active disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "highlight",
        variant: "fill",
        className:
          "bg-interactive-highlight text-text-primary-inverse not-disabled:hover:bg-interactive-highlight-hover focus-visible:bg-interactive-highlight-focus not-disabled:active:bg-interactive-highlight-active disabled:bg-interactive-disabled disabled:text-text-primary-inverse",
      },
      {
        action: "highlight",
        variant: "outline",
        className:
          "border-interactive-highlight text-interactive-highlight not-disabled:hover:border-interactive-highlight-hover not-disabled:hover:bg-highlight-50 not-disabled:hover:text-interactive-highlight-hover focus-visible:border-interactive-highlight-focus focus-visible:bg-highlight-50 focus-visible:text-interactive-highlight-focus not-disabled:active:border-interactive-highlight-active not-disabled:active:bg-highlight-100 not-disabled:active:text-interactive-highlight-active disabled:border-transparent disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "highlight",
        variant: "text",
        className:
          "text-interactive-highlight not-disabled:hover:bg-highlight-50 not-disabled:hover:text-interactive-highlight-hover focus-visible:bg-highlight-50 focus-visible:text-interactive-highlight-focus not-disabled:active:bg-highlight-100 not-disabled:active:text-interactive-highlight-active disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "inverse",
        variant: "fill",
        className:
          "bg-interactive-primary-inverse text-text-primary not-disabled:hover:bg-interactive-primary-inverse-hover focus-visible:bg-interactive-primary-inverse-focus not-disabled:active:bg-interactive-primary-inverse-active disabled:bg-interactive-disabled disabled:text-text-primary-inverse",
      },
      {
        action: "inverse",
        variant: "outline",
        className:
          "border-interactive-primary-inverse text-interactive-primary-inverse not-disabled:hover:border-interactive-primary-inverse-hover not-disabled:hover:bg-interactive-primary-inverse/10 not-disabled:hover:text-interactive-primary-inverse-hover focus-visible:border-interactive-primary-inverse-focus focus-visible:bg-interactive-primary-inverse/10 focus-visible:text-interactive-primary-inverse-focus not-disabled:active:border-interactive-primary-inverse-active not-disabled:active:bg-interactive-primary-inverse/20 not-disabled:active:text-interactive-primary-inverse-active disabled:border-transparent disabled:bg-transparent disabled:text-interactive-disabled",
      },
      {
        action: "inverse",
        variant: "text",
        className:
          "text-interactive-primary-inverse not-disabled:hover:bg-interactive-primary-inverse/10 not-disabled:hover:text-interactive-primary-inverse-hover focus-visible:bg-interactive-primary-inverse/10 focus-visible:text-interactive-primary-inverse-focus not-disabled:active:bg-interactive-primary-inverse/20 not-disabled:active:text-interactive-primary-inverse-active disabled:bg-transparent disabled:text-interactive-disabled",
      },
    ],
    defaultVariants: {
      action: "primary",
      variant: "fill",
      size: "md",
    },
  }
);

export function buttonStyles({ action = "primary", variant = "fill", size = "md" }: ButtonStyleProps = {}) {
  return buttonVariants({ action, variant, size });
}
