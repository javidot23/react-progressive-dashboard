import type { Meta, StoryObj } from "@storybook/react";
import { SlidersHorizontal } from "lucide-react";
import { buttonStyles } from "./Button.styles";
import { Button, type ButtonAction, type ButtonSize, type ButtonVariant } from "./Button";

const actions: ButtonAction[] = ["primary", "secondary", "danger", "success", "highlight", "inverse"];
const variants: ButtonVariant[] = ["fill", "outline", "text"];
const sizes: ButtonSize[] = ["sm", "md", "lg", "xl"];

const meta: Meta<typeof Button> = {
  title: "Atoms/Button",
  component: Button,
  tags: ["autodocs"],
  args: {
    action: "primary",
    variant: "fill",
    size: "md",
    children: "Button label",
  },
  argTypes: {
    action: {
      control: "select",
      options: actions,
    },
    variant: {
      control: "inline-radio",
      options: variants,
    },
    size: {
      control: "inline-radio",
      options: sizes,
    },
    isLoading: {
      control: "boolean",
    },
    disabled: {
      control: "boolean",
    },
    startIcon: {
      control: false,
    },
    endIcon: {
      control: false,
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          "A CDS-backed action button with independent semantic action, visual variant, and size axes. Hover, focus, active, and disabled are native interaction states.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {};

export const Secondary: Story = {
  args: {
    action: "secondary",
  },
};

export const AllActionsAndVariants: Story = {
  render: () => (
    <div className="flex flex-col gap-4">
      {actions.map(action => (
        <section
          key={action}
          className={
            action === "inverse" ? "rounded-md bg-background-brand-secondary p-4" : "rounded-md bg-background-primary p-4"
          }
        >
          <h2
            className={
              action === "inverse"
                ? "mb-3 text-sm font-bold capitalize text-text-primary-inverse"
                : "mb-3 text-sm font-bold capitalize"
            }
          >
            {action}
          </h2>
          <div className="flex flex-wrap gap-3">
            {variants.map(variant => (
              <Button key={variant} action={action} variant={variant}>
                {variant}
              </Button>
            ))}
          </div>
        </section>
      ))}
    </div>
  ),
};

export const AllSizes: Story = {
  render: () => (
    <div className="flex flex-wrap items-center gap-3">
      {sizes.map(size => (
        <Button key={size} size={size} startIcon={<SlidersHorizontal aria-hidden="true" />}>
          {size}
        </Button>
      ))}
    </div>
  ),
};

export const WithStartIcon: Story = {
  args: {
    startIcon: <SlidersHorizontal aria-hidden="true" />,
  },
};

export const WithEndIcon: Story = {
  args: {
    endIcon: <SlidersHorizontal aria-hidden="true" />,
  },
};

export const StyledLink: Story = {
  render: () => (
    <a href="#button-link-example" className={buttonStyles()}>
      Button-styled link
    </a>
  ),
};

export const Loading: Story = {
  args: {
    isLoading: true,
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
  },
};

export const DisabledMatrix: Story = {
  render: () => (
    <div className="flex flex-col gap-4">
      {actions.map(action => (
        <section
          key={action}
          className={
            action === "inverse"
              ? "flex flex-wrap gap-3 rounded-md bg-background-brand-secondary p-4"
              : "flex flex-wrap gap-3 rounded-md bg-background-primary p-4"
          }
        >
          {variants.map(variant => (
            <Button key={variant} action={action} variant={variant} disabled>
              {action} {variant}
            </Button>
          ))}
        </section>
      ))}
    </div>
  ),
};
