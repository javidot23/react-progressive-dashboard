import { Meta, StoryObj } from "@storybook/react";
import { Button } from "./Button";
import { SlidersHorizontal } from "lucide-react";

const meta: Meta<typeof Button> = {
  title: "Atoms/Button",
  component: Button,
  tags: ["autodocs"],
  args: {
    children: "Button label",
  },
  argTypes: {
    size: {
      control: "inline-radio",
      options: ["sm", "md", "lg"],
    },
    variant: {
      control: "select",
      options: ["default", "secondary", "outline", "ghost", "destructive"],
    },
    isLoading: {
      control: "boolean",
    },
    disabled: {
      control: "boolean",
    },
    startIcon: {
      control: false,
    },
    endIcon: {
      control: false,
    },
  },
  parameters: {
    docs: {
      description: {
        component: "A versatile and reusable button.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {};

export const Secondary: Story = {
  args: {
    variant: "secondary",
  },
};

export const WithStartIcon: Story = {
  args: {
    startIcon: <SlidersHorizontal aria-hidden="true" />,
  },
};

export const WithEndIcon: Story = {
  args: {
    endIcon: <SlidersHorizontal aria-hidden="true" />,
  },
};

export const Loading: Story = {
  args: {
    isLoading: true,
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
  },
};
