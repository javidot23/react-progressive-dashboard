import React, { useState } from 'react';
import {
  formatMaterialActionActorLabel,
  formatMaterialActionDateOnly,
  formatMaterialActionTimeOnly,
  getMaterialActionSummaryText,
  getNoActionDecisionRationale,
} from '@/lib/materialActionDisplay';
import { MaterialAction } from '@/lib/types';

interface ActionButtonProps {
  actionType: string;
  label: string;
  action?: MaterialAction;
  checked: boolean;
  disabled?: boolean;
  grayed?: boolean;
  onChange: (actionType: string, checked: boolean) => void;
  size?: 'sm' | 'md';
}

const ActionButton: React.FC<ActionButtonProps> = ({
  actionType,
  label,
  action,
  checked,
  disabled = false,
  grayed = true,
  onChange,
  size = 'md'
}) => {
  const [showTooltip, setShowTooltip] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState<'left' | 'right' | 'top' | 'bottom'>('top');

  const calculateTooltipPosition = (element: HTMLElement) => {
    const rect = element.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    const tooltipWidth = 200; // approximate tooltip width
    const tooltipHeight = 80; // approximate tooltip height
    const margin = 16; // safety margin

    // Check available space in each direction
    const spaceAbove = rect.top;
    const spaceBelow = viewportHeight - rect.bottom;
    const spaceLeft = rect.left;
    const spaceRight = viewportWidth - rect.right;

    // Priority: right > left > top > bottom
    // Choose position with most space, ensuring tooltip fits
    if (spaceRight >= tooltipWidth + margin) {
      return 'right';
    } else if (spaceLeft >= tooltipWidth + margin) {
      return 'left';
    } else if (spaceAbove >= tooltipHeight + margin) {
      return 'top';
    } else if (spaceBelow >= tooltipHeight + margin) {
      return 'bottom';
    }

    // Fallback: choose the side with most space
    const spaces = [
      { position: 'right' as const, space: spaceRight },
      { position: 'left' as const, space: spaceLeft },
      { position: 'top' as const, space: spaceAbove },
      { position: 'bottom' as const, space: spaceBelow },
    ];

    return spaces.sort((a, b) => b.space - a.space)[0].position;
  };

  const tooltipBox =
    'absolute z-9999 p-3 text-white text-2xs rounded-md shadow-lg bg-background-brand-secondary min-w-44 max-w-[min(20rem,calc(100vw-2rem))] whitespace-normal wrap-break-word';

  const getTooltipClasses = (position: 'left' | 'right' | 'top' | 'bottom') => {
    switch (position) {
      case 'right':
        return `${tooltipBox} left-full top-1/2 transform -translate-y-1/2 ml-2`;
      case 'left':
        return `${tooltipBox} right-full top-1/2 transform -translate-y-1/2 mr-2`;
      case 'top':
        return `${tooltipBox} bottom-full left-1/2 transform -translate-x-1/2 mb-2`;
      case 'bottom':
        return `${tooltipBox} top-full left-1/2 transform -translate-x-1/2 mt-2`;
      default:
        return `${tooltipBox} bottom-full left-1/2 transform -translate-x-1/2 mb-2`;
    }
  };

  const getArrowClasses = (position: 'left' | 'right' | 'top' | 'bottom') => {
    switch (position) {
      case 'right':
        return 'absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-full w-0 h-0 border-t-4 border-b-4 border-r-4 border-t-transparent border-b-transparent border-r-background-brand-secondary';
      case 'left':
        return 'absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-full w-0 h-0 border-t-4 border-b-4 border-l-4 border-t-transparent border-b-transparent border-l-background-brand-secondary';
      case 'top':
        return 'absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-background-brand-secondary';
      case 'bottom':
        return 'absolute bottom-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-4 border-l-transparent border-r-transparent border-b-background-brand-secondary';
      default:
        return 'absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-background-brand-secondary';
    }
  };

  const buttonSizeClasses = 'gap-2';
  const checkboxSizeClasses = size === 'sm' ? 'w-4 h-4' : 'w-5 h-5';
  const textSizeClasses = size === 'sm' ? 'text-xs font-bold text-brand-primary-main' : 'text-sm font-bold text-brand-primary-main';

  const showActionTooltip = (anchor: HTMLElement) => {
    try {
      const position = calculateTooltipPosition(anchor);
      setTooltipPosition(position);
      setShowTooltip(true);
    } catch {
      setShowTooltip(false);
    }
  };

  const noActionReasonForTooltip =
    action?.action === "no_action"
      ? getNoActionDecisionRationale(action) ?? "No reason provided"
      : null;

  const buttonContent = (
    <label
      className={`flex items-center ${buttonSizeClasses} border border-2 rounded px-2 py-1 transition-all duration-200 ${
        disabled
          ? "border-neutral-200 cursor-not-allowed"
          : "border-neutral-200 hover:border-brand-primary-main hover:bg-purple-50 cursor-pointer"
      }`}
      onMouseEnter={(e) => {
        if (checked) {
          showActionTooltip(e.currentTarget);
        }
      }}
      onMouseLeave={() => setShowTooltip(false)}
      onClick={(e) => {
        if (!disabled) {
          e.preventDefault();
          onChange(actionType, !checked);
        }
      }}
    >
      <input
        type="checkbox"
        checked={checked}
        disabled={disabled}
        onChange={e => {
          if (!disabled) {
            onChange(actionType, e.target.checked);
          }
        }}
        onFocus={(e) => {
          if (checked && action) {
            const label = e.currentTarget.closest("label");
            if (label) showActionTooltip(label as HTMLElement);
          }
        }}
        onBlur={() => setShowTooltip(false)}
        className={`${checkboxSizeClasses} accent-brand-primary-main focus:ring-0 focus:outline-hidden form-checkbox ${disabled && grayed ? 'opacity-50' : ''}`}
      />
      <span className={`${textSizeClasses} ${disabled && grayed ? 'opacity-50' : ''}`}>
        {label}
      </span>
    </label>
  );


  return (
    <div className="relative">
      {buttonContent}
      {showTooltip && checked && action && (
        <div
          className={getTooltipClasses(tooltipPosition)}
          role="tooltip"
        >
          <div className={getArrowClasses(tooltipPosition)} />
          {action.action === "no_action" ? (
            <div>
              Action taken by {formatMaterialActionActorLabel(action)} on{" "}
              {formatMaterialActionDateOnly(action.created_at)} at{" "}
              {formatMaterialActionTimeOnly(action.created_at)} marked as no action required. Reason:{" "}
              {noActionReasonForTooltip ?? "No reason provided"}. You're not able to perform any action on this.
            </div>
          ) : (
            <div>
              Action taken by {formatMaterialActionActorLabel(action)} on{" "}
              {formatMaterialActionDateOnly(action.created_at)} at{" "}
              {formatMaterialActionTimeOnly(action.created_at)}—{getMaterialActionSummaryText(action)}.
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ActionButton;
