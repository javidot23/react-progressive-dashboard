import { Meta, StoryObj } from "@storybook/react";
import profileImage from "@/assets/images/woman-profile.png";
import { Avatar } from "./Avatar";

const meta: Meta<typeof Avatar> = {
  title: "Atoms/Avatar",
  component: Avatar,
  tags: ["autodocs"],
  args: {
    "aria-label": "User Avatar",
  },
  argTypes: {
    size: {
      control: "inline-radio",
      options: ["sm", "md", "lg"],
    },
    src: {
      control: false,
    },
  },
  parameters: {
    docs: {
      description: {
        component: "Represents a user through an image, initials, or a default icon.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const WithImage: Story = {
  args: {
    src: profileImage,
    alt: "Profile portrait of Jane Carter",
    fallback: undefined,
  },
};

export const Initials: Story = {
  args: {
    fallback: "JC",
  },
};

export const DefaultIcon: Story = {
  args: {
    fallback: undefined,
  },
};

export const Small: Story = {
  args: {
    size: "sm",
  },
};

export const Large: Story = {
  args: {
    size: "lg",
  },
};
