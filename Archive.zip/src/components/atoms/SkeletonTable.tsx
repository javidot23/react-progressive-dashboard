import { FC } from 'react';

interface SkeletonTableProps {
  rows?: number;
  columns?: number;
}

const SkeletonTable: FC<SkeletonTableProps> = ({ rows = 5, columns = 7 }) => {
  return (
    <div className="w-full animate-pulse">
      <table className="w-full border text-sm text-left">
        <thead className="bg-ui-background-secondary">
          <tr>
            {Array.from({ length: columns }).map((_, i) => (
              <th key={i} className="px-4 py-2">
                <div className="h-4 bg-gray-200 rounded w-full"></div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: rows }).map((_, rowIndex) => (
            <tr key={rowIndex} className="border-t">
              {Array.from({ length: columns }).map((_, colIndex) => (
                <td key={colIndex} className="px-4 py-2">
                  <div className={`h-4 bg-gray-200 rounded ${
                    colIndex === 0 ? 'w-32' :
                    colIndex === 2 ? 'w-20' : 'w-16'
                  }`}></div>
                  {colIndex === 2 && (
                    <div className="h-3 bg-gray-200 rounded-full w-16 mt-1"></div>
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SkeletonTable;
