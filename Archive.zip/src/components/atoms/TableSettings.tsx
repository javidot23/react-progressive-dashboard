import React, { createContext, useContext, useEffect, useState } from 'react';

interface TableSettings {
  viewMode: 'card' | 'table';
  pageSize: number;
}

interface TableSettingsContextType {
  settings: TableSettings;
  updateSettings: (newSettings: Partial<TableSettings>) => void;
}

const TableSettingsContext = createContext<TableSettingsContextType | undefined>(undefined);

const TABLE_SETTINGS_STORAGE_KEY = 'stratium:tableSettings';

export const TableSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<TableSettings>({
    viewMode: 'card',
    pageSize: 10,
  });

  // Load settings from localStorage on mount
  useEffect(() => {
    try {
      const savedSettings = localStorage.getItem(TABLE_SETTINGS_STORAGE_KEY);
      if (savedSettings) {
        const parsed = JSON.parse(savedSettings);
        setSettings(prev => ({ ...prev, ...parsed }));
      }
    } catch (error) {
      console.error('Failed to load table settings:', error);
    }
  }, []);

  const updateSettings = (newSettings: Partial<TableSettings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...newSettings };

      // Save to localStorage
      try {
        localStorage.setItem(TABLE_SETTINGS_STORAGE_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error('Failed to save table settings:', error);
      }

      return updated;
    });
  };

  return (
    <TableSettingsContext.Provider value={{ settings, updateSettings }}>
      {children}
    </TableSettingsContext.Provider>
  );
};

export const useTableSettings = () => {
  const context = useContext(TableSettingsContext);

  if (context === undefined) {
    throw new Error('useTabbleSettings must be used within a ThemeProvider')
  }
  return context;
};
