import React from 'react';

interface LegendItemProps {
  color: string;
  label: string;
  value?: string | number;
}

export const LegendItem: React.FC<LegendItemProps> = ({ color, label, value }) => {
  return (
    <div className="flex items-center space-x-2">
      <div
        className="w-3 h-3 rounded-full"
        style={{ backgroundColor: color }}
      />
      <span className="text-sm text-ui-text-secondary">
        {label}
      </span>
      {value && (
        <span className="text-sm font-semibold text-ui-text-primary">
          {value}
        </span>
      )}
    </div>
  );
};
