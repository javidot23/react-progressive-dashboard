import { FC } from 'react';

interface SkeletonCardProps {
  showChart?: boolean;
  showBadge?: boolean;
}

const SkeletonCard: FC<SkeletonCardProps> = ({ showChart = false, showBadge = false }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 animate-pulse">
      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div className="h-3 bg-gray-200 rounded w-32"></div>
        {showBadge && <div className="h-6 bg-gray-200 rounded-full w-20"></div>}
      </div>

      {/* Subtitle */}
      <div className="h-2 bg-gray-200 rounded w-16 mb-3"></div>

      {/* Main Value */}
      <div className="h-6 bg-gray-200 rounded w-24 mb-4"></div>

      {/* Chart Area */}
      {showChart && (
        <div className="h-8 bg-gray-200 rounded w-full"></div>
      )}
    </div>
  );
};

export default SkeletonCard;
