import type { Meta, StoryObj } from "@storybook/react";
import { ArrowUp, Clock3, Info, RotateCcw } from "lucide-react";
import warehousePackages from "@/assets/icons/warehouse-packages.svg";
import { Button } from "@/components/atoms/Button";
import {
  GeneralCard,
  GeneralCardAction,
  GeneralCardActionArea,
  GeneralCardContent,
  GeneralCardDescription,
  GeneralCardFooter,
  GeneralCardHeader,
  GeneralCardMedia,
  GeneralCardSection,
  GeneralCardTitle,
} from "@/components/atoms/GeneralCard";

const meta: Meta<typeof GeneralCard> = {
  title: "Atoms/Card",
  component: GeneralCard,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
    backgrounds: {
      default: "page",
      values: [
        { name: "page", value: "#FAFAFA" },
        { name: "white", value: "var(--cds-color-core-gray-0)" },
      ],
    },
    docs: {
      description: {
        component:
          "Future-facing card primitive built on CDS tokens. Passive by default — compose native links and buttons for interactions. Isolated from the legacy Card until the app migrates.",
      },
    },
  },
  argTypes: {
    variant: {
      control: "select",
      options: ["flat", "elevated", "outlined"],
    },
    orientation: {
      control: "inline-radio",
      options: ["vertical", "horizontal"],
    },
    as: {
      control: "select",
      options: ["div", "article", "section"],
    },
  },
  args: {
    variant: "flat",
    orientation: "vertical",
    className: "max-w-md",
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

interface PerformanceProgressProps {
  id: string;
  label: string;
  value: number;
  displayValue: string;
  description?: string;
}

const PerformanceProgress = ({ id, label, value, displayValue, description }: PerformanceProgressProps) => (
  <div className="space-y-2">
    <div className="flex items-center justify-between gap-4">
      <span id={id} className="font-brand text-[12px] font-normal leading-[18px] tracking-normal text-black">
        {label}
      </span>
      <span className="font-brand text-[14px] font-medium leading-[21px] tracking-[-0.15px] text-black">{displayValue}</span>
    </div>
    <div
      role="progressbar"
      aria-labelledby={id}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={value}
      aria-valuetext={displayValue}
      className="h-1.5 overflow-hidden rounded-full bg-background-tertiary"
    >
      <div className="h-full rounded-full bg-[#FFBF00]" style={{ width: `${Math.min(Math.max(value, 0), 100)}%` }} />
    </div>
    {description && <p className="text-sm text-ui-text-muted">{description}</p>}
  </div>
);

const PerformanceMetric = ({ value, label }: { value: string; label: string }) => (
  <div className="flex flex-col gap-0.5">
    <dt className="order-2 font-brand text-[11px] font-normal leading-[18px] tracking-normal text-black">{label}</dt>
    <dd className="order-1 font-brand text-[12px] font-medium leading-[18px] tracking-[0.36px] text-black">{value}</dd>
  </div>
);

const StatusChip = ({ children }: { children: string }) => (
  <span className="inline-flex h-6 items-center justify-center gap-1 rounded-[6px] border border-[#FCA5A5] bg-[#FEF2F2] px-2 py-0.5 font-brand text-[12px] font-medium leading-[18px] text-[#B91C1C]">
    {children}
  </span>
);

interface ProductPerformanceBodyProps {
  titleId: string;
  progressId: string;
}

const ProductPerformanceBody = ({ titleId, progressId }: ProductPerformanceBodyProps) => (
  <>
    <GeneralCardHeader>
      <GeneralCardTitle
        id={titleId}
        as="h2"
        className="font-brand text-[16px] font-semibold uppercase leading-[20.8px] tracking-[-0.31px] text-black"
      >
        Amoxicillin-Clav 875/125mg Tab
      </GeneralCardTitle>
      <GeneralCardDescription className="font-brand text-[14px] font-normal leading-[19.6px] tracking-[-0.15px] text-[#444444]">
        Teva Pharmaceuticals
      </GeneralCardDescription>
    </GeneralCardHeader>
    <GeneralCardContent className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <StatusChip>Not reviewed</StatusChip>
        <StatusChip>Shortage Likely</StatusChip>
      </div>
      <PerformanceProgress
        id={progressId}
        label="Active orders"
        value={45}
        displayValue="180/400 units"
        description="60 units in transit"
      />
      <dl className="grid grid-cols-2 gap-x-4 gap-y-4">
        <PerformanceMetric value="91/100" label="Risk Score" />
        <PerformanceMetric value="$3.20MM" label="Risk Adjusted Value" />
        <PerformanceMetric value="00093-2267-05" label="NDC" />
        <PerformanceMetric value="21 Days" label="Lead Time" />
      </dl>
    </GeneralCardContent>
    <GeneralCardFooter className="justify-between font-brand text-[12px] font-normal leading-[18px] tracking-normal text-[#444444]">
      <span>5 Notes</span>
      <span className="inline-flex items-center gap-1.5">
        <Clock3 aria-hidden="true" className="size-4" />
        Days on Hand: 14
      </span>
    </GeneralCardFooter>
  </>
);

const KpiSparkline = ({
  stroke = "#7C3AED",
  gradientId = "kpi-sparkline-fill",
  className = "h-10 w-[7.5rem] shrink-0",
}: {
  stroke?: string;
  gradientId?: string;
  className?: string;
}) => (
  <svg aria-hidden="true" viewBox="0 0 120 40" className={className} preserveAspectRatio="none">
    <defs>
      <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={stroke} stopOpacity="0.28" />
        <stop offset="100%" stopColor={stroke} stopOpacity="0" />
      </linearGradient>
    </defs>
    <path
      d="M0 28 C12 26, 18 22, 28 24 C40 26, 48 12, 58 14 C70 16, 78 30, 90 22 C100 16, 110 10, 120 12 L120 40 L0 40 Z"
      fill={`url(#${gradientId})`}
    />
    <path
      d="M0 28 C12 26, 18 22, 28 24 C40 26, 48 12, 58 14 C70 16, 78 30, 90 22 C100 16, 110 10, 120 12"
      fill="none"
      stroke={stroke}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const KpiInfoButton = ({ label }: { label: string }) => (
  <button
    type="button"
    aria-label={label}
    className="inline-flex shrink-0 items-center justify-center text-border-tertiary hover:opacity-80 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ui-border-focus"
  >
    <Info aria-hidden="true" className="size-5" strokeWidth={1.5} />
  </button>
);

const KpiValueAtRiskCard = () => (
  <GeneralCard as="article" variant="flat" className="h-full max-w-[302px]" aria-labelledby="kpi-value-at-risk-title">
    <GeneralCardContent className="flex gap-4">
      <div className="flex min-w-0 flex-1 flex-col">
        <h2 id="kpi-value-at-risk-title" className="text-3xl font-semibold tracking-tight text-ui-text-heading">
          $1.16M
        </h2>
        <div className="mt-auto space-y-1 pt-6">
          <p className="font-body-sm text-body-sm leading-body-sm font-medium tracking-normal text-text-primary">Value at Risk</p>
          <p className="inline-flex items-center gap-1 text-sm font-medium text-status-success-main">
            <ArrowUp aria-hidden="true" className="size-3.5 shrink-0" />
            $64.5k since last week
          </p>
        </div>
      </div>
      <div className="flex shrink-0 flex-col items-end justify-between">
        <KpiInfoButton label="About Value at Risk" />
        <KpiSparkline />
      </div>
    </GeneralCardContent>
  </GeneralCard>
);

const KpiPortfolioRiskCard = () => (
  <GeneralCard as="article" variant="flat" className="h-full max-w-[302px]" aria-labelledby="kpi-portfolio-risk-title">
    <GeneralCardContent className="flex flex-col gap-3">
      <div className="flex items-center justify-between gap-2">
        <h2 id="kpi-portfolio-risk-title" className="text-3xl font-semibold tracking-tight text-ui-text-heading">
          40/100
        </h2>
        <KpiInfoButton label="About Current Portfolio Risk" />
      </div>
      <p className="font-body-sm text-body-sm leading-body-sm font-medium tracking-normal text-text-primary">
        Current Portfolio Risk
      </p>
      <p className="inline-flex items-center gap-1 text-sm font-medium text-status-success-main">
        <ArrowUp aria-hidden="true" className="size-3.5 shrink-0" />
        5% since last week
      </p>
      <KpiSparkline stroke="#E36A5D" gradientId="kpi-portfolio-sparkline-fill" className="mt-2 h-12 w-full" />
    </GeneralCardContent>
  </GeneralCard>
);

export const InteractiveActionArea: Story = {
  parameters: {
    docs: {
      description: {
        story:
          "Product-performance cards (passive flat vs ActionArea elevated) plus flat KPI compositions: Value at Risk (split layout) and Current Portfolio Risk (vertical layout).",
      },
    },
  },
  render: () => (
    <div className="flex w-full max-w-6xl flex-col gap-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <GeneralCard as="article" variant="flat" className="h-full" aria-labelledby="product-passive-title">
          <ProductPerformanceBody titleId="product-passive-title" progressId="fill-rate-passive" />
        </GeneralCard>
        <GeneralCard as="article" variant="flat" className="h-full" aria-labelledby="product-interactive-title">
          <GeneralCardActionArea as="a" href="#card-action-destination">
            <ProductPerformanceBody titleId="product-interactive-title" progressId="fill-rate-interactive" />
          </GeneralCardActionArea>
        </GeneralCard>
      </div>
      <div className="flex flex-wrap gap-4">
        <KpiValueAtRiskCard />
        <KpiPortfolioRiskCard />
      </div>
      <span id="card-action-destination" className="sr-only">
        Product details destination
      </span>
    </div>
  ),
};

export const Default: Story = {
  render: args => (
    <GeneralCard {...args}>
      <GeneralCardHeader>
        <GeneralCardTitle>Service level</GeneralCardTitle>
        <GeneralCardDescription>Fill rate for the selected period across all active materials.</GeneralCardDescription>
      </GeneralCardHeader>
      <GeneralCardContent>
        <p className="text-3xl font-semibold text-ui-text-heading">98.4%</p>
      </GeneralCardContent>
    </GeneralCard>
  ),
};

export const Variants: Story = {
  render: () => (
    <div className="grid w-full max-w-4xl gap-4 md:grid-cols-2">
      {(["flat", "elevated", "outlined"] as const).map(variant => (
        <GeneralCard key={variant} variant={variant}>
          <GeneralCardHeader>
            <GeneralCardTitle>{variant}</GeneralCardTitle>
            <GeneralCardDescription>Surface variant using CDS background, border, and elevation tokens.</GeneralCardDescription>
          </GeneralCardHeader>
          <GeneralCardContent>
            <p className="text-sm text-ui-text-secondary">Content stays readable at any card width.</p>
          </GeneralCardContent>
        </GeneralCard>
      ))}
    </div>
  ),
};

export const Spacing: Story = {
  render: () => (
    <GeneralCard className="max-w-md">
      <GeneralCardHeader>
        <GeneralCardTitle>Fixed spacing</GeneralCardTitle>
        <GeneralCardDescription>
          Raw Figma spacing for now: 16px vertical, 20px horizontal, 14px gap (CDS tokens later).
        </GeneralCardDescription>
      </GeneralCardHeader>
      <GeneralCardContent>
        <p className="text-sm text-ui-text-secondary">
          Header, content, and footer share --card-padding-x, --card-padding-y, and --card-gap.
        </p>
      </GeneralCardContent>
    </GeneralCard>
  ),
};

export const WithHeaderAction: Story = {
  render: args => (
    <GeneralCard {...args} as="article">
      <GeneralCardHeader>
        <GeneralCardTitle as="h2">High-risk materials</GeneralCardTitle>
        <GeneralCardDescription>Review materials flagged by the current risk threshold.</GeneralCardDescription>
        <GeneralCardAction>
          <Button size="sm" action="secondary">
            View all
          </Button>
        </GeneralCardAction>
      </GeneralCardHeader>
      <GeneralCardContent>
        <ul className="space-y-2 text-sm text-ui-text-secondary">
          <li>Amoxicillin 500mg — Likely</li>
          <li>Atorvastatin 20mg — Even chance</li>
          <li>Metformin 850mg — Highly likely</li>
        </ul>
      </GeneralCardContent>
    </GeneralCard>
  ),
};

export const WithMediaAndFooter: Story = {
  render: args => (
    <GeneralCard {...args} as="article">
      <GeneralCardMedia className="bg-ui-background-secondary">
        <img
          src={warehousePackages}
          alt="Warehouse packages icon representing inventory readiness"
          className="mx-auto aspect-video max-h-40 w-auto object-contain p-(--card-padding-x)"
        />
      </GeneralCardMedia>
      <GeneralCardHeader>
        <GeneralCardTitle as="h2">Inventory readiness</GeneralCardTitle>
        <GeneralCardDescription>Snapshot of inbound coverage for the next fulfillment window.</GeneralCardDescription>
      </GeneralCardHeader>
      <GeneralCardContent>
        <p className="text-sm text-ui-text-secondary">
          Use the primary action to open the full inventory drill-through, or export the current view for offline review.
        </p>
      </GeneralCardContent>
      <GeneralCardFooter>
        <Button size="sm" variant="fill">
          Open details
        </Button>
        <Button size="sm" action="secondary">
          Export
        </Button>
      </GeneralCardFooter>
    </GeneralCard>
  ),
};

export const LongContent: Story = {
  args: {
    className: "max-w-xs",
  },
  render: args => (
    <GeneralCard {...args}>
      <GeneralCardHeader>
        <GeneralCardTitle>
          Very long card title that should wrap cleanly without overflowing the container on narrow widths
        </GeneralCardTitle>
        <GeneralCardDescription>
          Supporting copy can also be lengthy. The card uses min-w-0 and wrapping so text reflows instead of forcing horizontal
          scroll.
        </GeneralCardDescription>
        <GeneralCardAction>
          <Button size="sm" variant="text">
            More
          </Button>
        </GeneralCardAction>
      </GeneralCardHeader>
      <GeneralCardContent>
        <p className="text-sm text-ui-text-secondary">
          Container queries restack the header action under the title when the card itself is narrow, even inside a wide page
          layout.
        </p>
      </GeneralCardContent>
      <GeneralCardFooter>
        <Button size="sm" variant="fill" className="w-full @sm/card:w-auto">
          Primary action
        </Button>
        <Button size="sm" action="secondary" className="w-full @sm/card:w-auto">
          Secondary
        </Button>
      </GeneralCardFooter>
    </GeneralCard>
  ),
};

export const ResponsiveGrid: Story = {
  parameters: {
    layout: "padded",
  },
  render: () => (
    <div className="grid w-full gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {[
        { title: "OTIF", value: "94.2%", detail: "On-time in-full deliveries" },
        { title: "Value at risk", value: "$1.2M", detail: "Current exposure" },
        { title: "Open issues", value: "18", detail: "Across active suppliers" },
        { title: "Fill rate", value: "97.1%", detail: "Last 7 days" },
        { title: "Backorders", value: "42", detail: "Lines awaiting stock" },
        { title: "Alternates", value: "9", detail: "Ready substitutions" },
      ].map(item => (
        <GeneralCard key={item.title}>
          <GeneralCardHeader>
            <GeneralCardTitle as="h2">{item.title}</GeneralCardTitle>
            <GeneralCardDescription>{item.detail}</GeneralCardDescription>
          </GeneralCardHeader>
          <GeneralCardContent>
            <p className="text-2xl font-semibold text-ui-text-heading">{item.value}</p>
          </GeneralCardContent>
          <GeneralCardFooter>
            <a href="#details" className="text-sm font-medium text-ui-text-link underline-offset-2 hover:underline">
              View details
            </a>
          </GeneralCardFooter>
        </GeneralCard>
      ))}
    </div>
  ),
};

export const SemanticArticle: Story = {
  render: args => (
    <GeneralCard {...args} as="article">
      <GeneralCardHeader>
        <GeneralCardTitle as="h2">Supplier profile</GeneralCardTitle>
        <GeneralCardDescription>Semantic article root with an h2 title for correct document outline.</GeneralCardDescription>
      </GeneralCardHeader>
      <GeneralCardContent>
        <dl className="grid gap-2 text-sm">
          <div className="flex justify-between gap-4">
            <dt className="text-ui-text-muted">Vendor ID</dt>
            <dd className="font-medium text-ui-text-primary">V-10482</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-ui-text-muted">Region</dt>
            <dd className="font-medium text-ui-text-primary">Northeast</dd>
          </div>
        </dl>
      </GeneralCardContent>
    </GeneralCard>
  ),
};

export const ProductPerformanceCard: Story = {
  parameters: {
    docs: {
      description: {
        story:
          "Flat product-performance composition matching the supplied reference. The progress status includes visible text and ARIA values.",
      },
    },
  },
  render: () => (
    <div className="grid w-full max-w-6xl gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {["a", "b", "c"].map(id => (
        <GeneralCard key={id} as="article" variant="flat" className="h-full" aria-labelledby={`product-title-${id}`}>
          <ProductPerformanceBody titleId={`product-title-${id}`} progressId={`fill-rate-${id}`} />
        </GeneralCard>
      ))}
    </div>
  ),
};

export const SupplierPerformanceCard: Story = {
  parameters: {
    docs: {
      description: {
        story:
          "Flat supplier-performance composition matching the second reference pattern. The group heading remains outside the cards.",
      },
    },
  },
  render: () => (
    <section aria-labelledby="supplier-performance-heading" className="w-full max-w-5xl">
      <div className="mb-4 flex items-center gap-2">
        <h2 id="supplier-performance-heading" className="text-lg font-semibold text-ui-text-heading">
          Ajanta Performance
        </h2>
        <button
          type="button"
          aria-label="About supplier performance"
          className="inline-flex size-11 items-center justify-center rounded-full text-ui-text-accent hover:bg-ui-background-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ui-border-focus"
        >
          <Info aria-hidden="true" className="size-5" />
        </button>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {["Ajanta Pharma USA Inc.", "Ajanta Pharma USA Inc. (SD)"].map((supplier, index) => (
          <GeneralCard
            key={supplier}
            as="article"
            variant="outlined"
            className="h-full"
            aria-labelledby={`supplier-title-${index}`}
          >
            <GeneralCardHeader>
              <GeneralCardTitle id={`supplier-title-${index}`} as="h3" className="text-base uppercase">
                {supplier}
              </GeneralCardTitle>
            </GeneralCardHeader>
            <GeneralCardContent className="space-y-6">
              <PerformanceProgress
                id={`supplier-fill-rate-${index}`}
                label="Inbound Fill Rate"
                value={94}
                displayValue="94/100"
              />
              <dl className="grid grid-cols-2 gap-4">
                <PerformanceMetric value="$2M" label="Value at Risk" />
                <PerformanceMetric value="$14M" label="YTD Sales" />
              </dl>
            </GeneralCardContent>
          </GeneralCard>
        ))}
      </div>
    </section>
  ),
};

export const HorizontalOrientation: Story = {
  render: () => (
    <GeneralCard
      as="article"
      orientation="horizontal"
      variant="outlined"
      className="max-w-3xl"
      aria-labelledby="horizontal-card-title"
    >
      <GeneralCardMedia className="min-h-48 bg-ui-background-secondary">
        <img src={warehousePackages} alt="" className="mx-auto max-h-56 object-contain p-8" />
      </GeneralCardMedia>
      <GeneralCardSection>
        <GeneralCardHeader>
          <GeneralCardTitle id="horizontal-card-title" as="h2">
            Inventory coverage
          </GeneralCardTitle>
          <GeneralCardDescription>
            Horizontal cards collapse intrinsically when their own container becomes narrow.
          </GeneralCardDescription>
        </GeneralCardHeader>
        <GeneralCardContent>
          <p className="text-sm text-ui-text-secondary">
            92% of active material locations have sufficient inventory for the next fulfillment window.
          </p>
        </GeneralCardContent>
        <GeneralCardFooter>
          <Button size="sm" variant="fill">
            Review inventory
          </Button>
        </GeneralCardFooter>
      </GeneralCardSection>
    </GeneralCard>
  ),
};

export const FigmaFrameComparison: Story = {
  parameters: {
    docs: {
      description: {
        story:
          "Constrained to the Figma frame (302×328) for visual comparison. The atom itself stays fluid; do not bake fixed dimensions into the component.",
      },
    },
  },
  render: () => (
    <GeneralCard className="h-[328px] w-[302px]" variant="elevated">
      <GeneralCardHeader>
        <GeneralCardTitle as="h2">Figma frame</GeneralCardTitle>
        <GeneralCardDescription>16px vertical padding, 20px horizontal padding, 14px gap, rounded-lg.</GeneralCardDescription>
      </GeneralCardHeader>
      <GeneralCardContent>
        <p className="text-sm text-ui-text-secondary">
          Use this story to compare against the design frame without changing the atom API.
        </p>
      </GeneralCardContent>
      <GeneralCardFooter>
        <Button size="sm" action="secondary">
          Action
        </Button>
      </GeneralCardFooter>
    </GeneralCard>
  ),
};

export const ComposableStates: Story = {
  render: () => (
    <div className="grid w-full max-w-5xl gap-4 md:grid-cols-3">
      <GeneralCard aria-busy="true" aria-label="Loading supplier performance">
        <GeneralCardHeader>
          <div className="h-5 w-2/3 animate-pulse rounded bg-ui-background-muted motion-reduce:animate-none" />
          <div className="h-4 w-1/2 animate-pulse rounded bg-ui-background-muted motion-reduce:animate-none" />
        </GeneralCardHeader>
        <GeneralCardContent className="space-y-3">
          <div className="h-8 animate-pulse rounded bg-ui-background-muted motion-reduce:animate-none" />
          <div className="h-4 animate-pulse rounded bg-ui-background-muted motion-reduce:animate-none" />
        </GeneralCardContent>
      </GeneralCard>
      <GeneralCard as="article">
        <GeneralCardHeader>
          <GeneralCardTitle as="h2">No performance data</GeneralCardTitle>
          <GeneralCardDescription>Adjust the selected period or supplier filters.</GeneralCardDescription>
        </GeneralCardHeader>
        <GeneralCardContent>
          <p className="text-sm text-ui-text-secondary">
            Empty state content is composed without adding boolean props to the Card primitive.
          </p>
        </GeneralCardContent>
      </GeneralCard>
      <GeneralCard as="article" variant="outlined">
        <GeneralCardHeader>
          <GeneralCardTitle as="h2">Unable to load data</GeneralCardTitle>
          <GeneralCardDescription>The latest performance metrics could not be retrieved.</GeneralCardDescription>
        </GeneralCardHeader>
        <GeneralCardFooter>
          <Button size="sm" variant="outline" startIcon={<RotateCcw aria-hidden="true" />}>
            Retry
          </Button>
        </GeneralCardFooter>
      </GeneralCard>
    </div>
  ),
};

export const CollectionSemantics: Story = {
  render: () => (
    <div className="w-full max-w-4xl">
      <h2 id="card-collection" className="mb-4 text-lg font-semibold">
        Supplier performance
      </h2>
      <ul aria-labelledby="card-collection" className="grid list-none gap-4 p-0 sm:grid-cols-2">
        {[
          ["Ajanta Pharma USA Inc.", "94/100"],
          ["Teva Pharmaceuticals", "89/100"],
        ].map(([supplier, score], index) => (
          <GeneralCard key={supplier} as="li" className="h-full">
            <GeneralCardHeader>
              <GeneralCardTitle as="h3">{supplier}</GeneralCardTitle>
              <GeneralCardDescription>Inbound fill rate</GeneralCardDescription>
            </GeneralCardHeader>
            <GeneralCardContent>
              <p className="text-2xl font-semibold">{score}</p>
            </GeneralCardContent>
            <GeneralCardFooter>
              <a
                href={`#supplier-${index}`}
                className="inline-flex min-h-11 items-center py-2 text-sm font-medium text-ui-text-link underline-offset-2 hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ui-border-focus"
              >
                View details
              </a>
            </GeneralCardFooter>
          </GeneralCard>
        ))}
      </ul>
    </div>
  ),
};
