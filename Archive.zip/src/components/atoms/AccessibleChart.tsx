import type { ReactNode } from "react";

interface AccessibleChartProps {
  /** Short description of what the chart shows (required for screen readers). */
  ariaLabel: string;
  children: ReactNode;
  className?: string;
}

/**
 * Wraps chart visuals with role="img" and an accessible name (P6.2).
 * Prefer pairing with visible titles; use sr-only summary tables for complex charts when needed.
 */
export function AccessibleChart({ ariaLabel, children, className }: AccessibleChartProps) {
  return (
    <div role="img" aria-label={ariaLabel} className={className}>
      {children}
    </div>
  );
}
