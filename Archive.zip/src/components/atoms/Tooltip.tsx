import React, { useState, useRef, useEffect, useLayoutEffect, useCallback, ReactNode, useId, type CSSProperties } from "react";
import { createPortal } from "react-dom";

type Placement = "top" | "bottom" | "left" | "right";

/** Only one tooltip may be open at a time (avoids stacked tooltips when moving quickly between triggers). */
const tooltipCloseById = new Map<string, () => void>();
let activeTooltipId: string | null = null;

function tooltipRegister(id: string, close: () => void) {
  tooltipCloseById.set(id, close);
}

function tooltipUnregister(id: string) {
  tooltipCloseById.delete(id);
  if (activeTooltipId === id) activeTooltipId = null;
}

function tooltipRequestOpen(id: string) {
  if (activeTooltipId !== null && activeTooltipId !== id) {
    tooltipCloseById.get(activeTooltipId)?.();
  }
  activeTooltipId = id;
}

function tooltipReleaseIfActive(id: string) {
  if (activeTooltipId === id) activeTooltipId = null;
}

const TOOLTIP_ARROW_COLOR = "white";

const PLACEMENT_STYLES: Record<Placement, { transform: string; arrow: CSSProperties }> = {
  top: {
    transform: "translate(-50%, -100%)",
    arrow: {
      bottom: "-6px",
      left: "50%",
      marginLeft: "-6px",
      borderLeft: "6px solid transparent",
      borderRight: "6px solid transparent",
      borderTop: `6px solid ${TOOLTIP_ARROW_COLOR}`,
      filter: "drop-shadow(0 2px 2px rgba(0,0,0,0.1))",
    },
  },
  bottom: {
    transform: "translate(-50%, 0)",
    arrow: {
      top: "-6px",
      left: "50%",
      marginLeft: "-6px",
      borderLeft: "6px solid transparent",
      borderRight: "6px solid transparent",
      borderBottom: `6px solid ${TOOLTIP_ARROW_COLOR}`,
      filter: "drop-shadow(0 -2px 2px rgba(0,0,0,0.1))",
    },
  },
  left: {
    transform: "translateY(-50%)",
    arrow: {
      top: "50%",
      right: "-6px",
      marginTop: "-6px",
      borderTop: "6px solid transparent",
      borderBottom: "6px solid transparent",
      borderLeft: `6px solid ${TOOLTIP_ARROW_COLOR}`,
    },
  },
  right: {
    transform: "translateY(-50%)",
    arrow: {
      top: "50%",
      left: "-6px",
      marginTop: "-6px",
      borderTop: "6px solid transparent",
      borderBottom: "6px solid transparent",
      borderRight: `6px solid ${TOOLTIP_ARROW_COLOR}`,
    },
  },
};

interface TooltipProps {
  children: ReactNode;
  content: ReactNode;
  position?: Placement;
  disabled?: boolean;
  className?: string;
  /** When set, the tooltip content gets a max height and becomes vertically scrollable. Use for long content (e.g. Applied Filters). Scoped to this instance only. */
  contentMaxHeight?: number;
}

const Tooltip: React.FC<TooltipProps> = ({
  children,
  content,
  position = "top",
  disabled = false,
  className = "",
  contentMaxHeight,
}) => {
  const instanceId = useId();
  const tooltipId = useId();
  const [isOpen, setIsOpen] = useState(false);
  const [geometry, setGeometry] = useState<{ top: number; left: number; width: number; placement: Placement }>({
    top: 0,
    left: 0,
    width: 280,
    placement: "top",
  });

  const containerRef = useRef<HTMLDivElement>(null);
  const popupRef = useRef<HTMLDivElement | null>(null);
  const rafRef = useRef<number | null>(null);
  const closeTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const cancelClose = () => {
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
  };

  useEffect(() => {
    if (disabled) setIsOpen(false);
  }, [disabled]);

  useEffect(() => {
    if (!isOpen || disabled) {
      tooltipUnregister(instanceId);
      tooltipReleaseIfActive(instanceId);
      return;
    }
    const close = () => {
      cancelClose();
      setIsOpen(false);
    };
    tooltipRegister(instanceId, close);
    tooltipRequestOpen(instanceId);
    return () => {
      cancelClose();
      tooltipUnregister(instanceId);
      tooltipReleaseIfActive(instanceId);
    };
  }, [isOpen, disabled, instanceId]);

  const calculatePosition = useCallback(() => {
    if (!containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const isMobile = window.innerWidth < 768;
    const tooltipWidth = isMobile ? 200 : 280;
    const tooltipHeight = 120;
    const spacing = 8;
    const viewportPadding = 10;
    const viewportWidth = document.documentElement.clientWidth;

    let top = 0;
    let left = 0;
    let resolvedPlacement: Placement = position;

    if (position === "left") {
      left = rect.left - tooltipWidth - spacing;
      top = rect.top + rect.height / 2;
      resolvedPlacement = "left";
    } else if (position === "right") {
      left = rect.right + spacing;
      top = rect.top + rect.height / 2;
      resolvedPlacement = "right";
    } else if (position === "bottom") {
      top = rect.bottom + spacing;
      left = rect.left + rect.width / 2;
      resolvedPlacement = "bottom";
    } else {
      left = rect.left + rect.width / 2;
      const spaceAbove = rect.top - viewportPadding;
      const spaceBelow = window.innerHeight - rect.bottom - viewportPadding;

      if (spaceAbove >= tooltipHeight + spacing) {
        top = rect.top - spacing;
        resolvedPlacement = "top";
      } else if (spaceBelow >= tooltipHeight + spacing) {
        top = rect.bottom + spacing;
        resolvedPlacement = "bottom";
      } else {
        top = spaceAbove >= spaceBelow ? rect.top - spacing : rect.bottom + spacing;
        resolvedPlacement = spaceAbove >= spaceBelow ? "top" : "bottom";
      }
    }

    const halfWidth = tooltipWidth / 2;
    const minLeft = halfWidth + viewportPadding;
    const maxLeft = viewportWidth - halfWidth - viewportPadding;
    if (resolvedPlacement === "top" || resolvedPlacement === "bottom") {
      left = Math.max(minLeft, Math.min(maxLeft, left));
    } else {
      if (left < viewportPadding) left = viewportPadding;
      if (left + tooltipWidth > viewportWidth - viewportPadding) {
        left = viewportWidth - tooltipWidth - viewportPadding;
      }
    }

    setGeometry({ top, left, width: tooltipWidth, placement: resolvedPlacement });
  }, [position]);

  useLayoutEffect(() => {
    if (!isOpen || disabled || !containerRef.current) return;
    calculatePosition();
  }, [isOpen, disabled, position, content, calculatePosition]);

  useEffect(() => {
    if (!isOpen || disabled || !containerRef.current) return;

    const onScrollOrResize = () => calculatePosition();
    window.addEventListener("scroll", onScrollOrResize, true);
    window.addEventListener("resize", onScrollOrResize);

    const el = containerRef.current;
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(onScrollOrResize) : null;
    ro?.observe(el);

    return () => {
      window.removeEventListener("scroll", onScrollOrResize, true);
      window.removeEventListener("resize", onScrollOrResize);
      ro?.disconnect();
    };
  }, [isOpen, disabled, calculatePosition]);

  const scheduleClose = () => {
    if (closeTimeoutRef.current) return;
    closeTimeoutRef.current = setTimeout(() => {
      closeTimeoutRef.current = null;
      setIsOpen(false);
    }, 120);
  };

  useEffect(() => {
    if (!isOpen || contentMaxHeight == null) return;

    const onMove = (e: PointerEvent) => {
      if (rafRef.current !== null) return;
      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = null;
        const el = document.elementFromPoint(e.clientX, e.clientY);
        const inside = (containerRef.current?.contains(el ?? null) ?? false) || (popupRef.current?.contains(el ?? null) ?? false);
        if (!inside) scheduleClose();
        else cancelClose();
      });
    };

    document.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      document.removeEventListener("pointermove", onMove);
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      cancelClose();
    };
  }, [isOpen, contentMaxHeight]);

  useEffect(() => {
    if (!isOpen) return;

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        cancelClose();
        setIsOpen(false);
      }
    };
    document.addEventListener("keydown", onKeyDown, true);
    return () => document.removeEventListener("keydown", onKeyDown, true);
  }, [isOpen]);

  const handleMouseEnter = () => {
    if (disabled) return;
    cancelClose();
    tooltipRequestOpen(instanceId);
    calculatePosition();
    setIsOpen(true);
  };

  const handleMouseLeave = () => {
    if (contentMaxHeight == null) setIsOpen(false);
  };

  const handleFocus = () => {
    if (disabled) return;
    cancelClose();
    tooltipRequestOpen(instanceId);
    calculatePosition();
    setIsOpen(true);
  };

  const handleBlur = (e: React.FocusEvent) => {
    const next = e.relatedTarget as Node | null;
    if (next && (containerRef.current?.contains(next) || popupRef.current?.contains(next))) return;
    setIsOpen(false);
  };

  const { top, left, width: tooltipWidth, placement } = geometry;
  const placementStyle = PLACEMENT_STYLES[placement];
  const isScrollable = contentMaxHeight != null;

  const portal =
    isOpen && !disabled && content && containerRef.current
      ? createPortal(
          <div
            ref={isScrollable ? popupRef : undefined}
            id={tooltipId}
            role="tooltip"
            className={`fixed transition-opacity duration-200 animate-in fade-in ${isScrollable ? "pointer-events-auto" : "pointer-events-none"}`}
            style={{
              top: `${top}px`,
              left: `${left}px`,
              zIndex: 999999,
              transform: placementStyle.transform,
            }}
          >
            <div
              className="bg-white text-xs rounded-md shadow-xl p-3 font-normal whitespace-normal wrap-break-word relative"
              style={{ width: tooltipWidth }}
            >
              {contentMaxHeight != null ? (
                <div className="overflow-y-auto overflow-x-hidden overscroll-contain" style={{ maxHeight: contentMaxHeight }}>
                  {content}
                </div>
              ) : (
                content
              )}
              <div className="absolute w-0 h-0" style={placementStyle.arrow} />
            </div>
          </div>,
          document.body
        )
      : null;

  return (
    <div
      ref={containerRef}
      className={`inline-block ${className}`}
      aria-describedby={isOpen ? tooltipId : undefined}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onFocus={handleFocus}
      onBlur={handleBlur}
    >
      {portal}
      {children}
    </div>
  );
};

export default Tooltip;
