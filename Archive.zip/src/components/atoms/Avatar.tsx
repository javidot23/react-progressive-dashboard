import { HTMLAttributes } from "react";
import { CircleUserRound } from "lucide-react";
import { cn } from "@/lib/utils";

export interface AvatarProps extends HTMLAttributes<HTMLDivElement> {
  src?: string;
  alt?: string;
  fallback?: string;
  size?: "sm" | "md" | "lg";
}

export const Avatar = ({ src, alt, fallback, size = "md", className, ...props }: AvatarProps) => {
  const sizes = {
    sm: "h-8 w-8 text-xs",
    md: "h-10 w-10 text-sm",
    lg: "h-12 w-12 text-base",
  };

  return (
    <div className={cn("relative flex shrink-0 overflow-hidden rounded-full", sizes[size], className)} {...props}>
      {src ? (
        <img src={src} alt={alt} className="aspect-square h-full w-full object-cover" />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-gray-100 text-gray-600">
          {fallback ? <span className="font-medium">{fallback}</span> : <CircleUserRound className="h-full w-full p-1" />}
        </div>
      )}
    </div>
  );
};
