interface PageTitleProps {
  title: string
  section?: string
  className?: string
}

export const PageTitle = ({ title, section, className = '' }: PageTitleProps) => {
  return (
    <h1 className={`${className} flex items-baseline max-sm:flex-wrap max-sm:items-center max-sm:gap-1`}>
      <span
        className="font-semibold font-brand max-sm:text-base"
        style={{
          color: 'var(--cencora-brand-700-core, var(--color-brand-700, #461E96))',
          fontFamily: 'var(--text-heading-xl-font-family, Cencora-Gilroy)',
          fontSize: 'var(--text-heading-xl-font-size, 20px)',
          fontStyle: 'normal',
          fontWeight: '600',
          lineHeight: 'var(--text-heading-xl-line-height, 24px)',
          letterSpacing: 'var(--text-heading-xl-letter-spacing, 0)'
        }}
      >
        {title}
      </span>
      {section && (
        <span className="max-sm:flex max-sm:items-center">
          <span
            className="inline-block w-px mx-2 align-middle max-sm:mx-1.5 max-sm:h-4"
            style={{
              height: '28px',
              backgroundColor: '#C8C8C8',
              transform: 'translateY(-2px)'
            }}
          ></span>
          <span
            className="font-semibold font-brand max-sm:text-sm"
            style={{
              color: 'var(--cencora-brand-700-core, var(--color-brand-700, #461E96))',
              fontFamily: 'var(--text-heading-lg-font-family, Cencora-Gilroy)',
              fontSize: 'var(--text-heading-lg-font-size, 18px)',
              fontStyle: 'normal',
              fontWeight: '500',
              lineHeight: 'var(--text-heading-lg-line-height, 24px)'
            }}
          >
            {section}
          </span>
        </span>
      )}
    </h1>
  )
}
