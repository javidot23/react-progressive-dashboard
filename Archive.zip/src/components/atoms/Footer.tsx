
export function Footer() {
  const version =
    import.meta.env.VITE_APP_VERSION ||
    (globalThis as any).__APP_VERSION__;

  return (
    <footer className="w-full bg-ui-background-primary border-t border-[#E2E8F0]">
      <div className="w-full max-w-(--breakpoint-2xl) mx-auto">
        <div className="px-9 space-y-3">
          <div className="text-xs text-[#3B3B3B] py-8">
            Copyright © 2023 - 2026 Cencora, Inc. All Rights Reserved.
            {version && (
              <span className="ml-2 text-ui-neutral-600">v{version}</span>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}
