import { cn } from "@/lib/utils";

export type FooterProps = {
  className?: string;
  contentClassName?: string;
};

export function Footer({ className, contentClassName }: FooterProps) {
  const version = import.meta.env.VITE_APP_VERSION || (globalThis as any).__APP_VERSION__;

  return (
    <footer className={cn("w-full border-t border-[#E2E8F0] bg-ui-background-primary", className)}>
      <div className="w-full max-w-(--breakpoint-2xl) mx-auto">
        <div className={cn("space-y-3 px-9", contentClassName)}>
          <div className="text-xs text-[#3B3B3B] py-8">
            Copyright © 2023 - 2026 Cencora, Inc. All Rights Reserved.
            {version && <span className="ml-2 text-ui-neutral-600">v{version}</span>}
          </div>
        </div>
      </div>
    </footer>
  );
}
