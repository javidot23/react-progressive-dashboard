import { FC } from "react";

interface NoDataStateProps {
  title?: string;
  description?: string;
  icon?: React.ReactNode;
  actionButton?: React.ReactNode;
}

const NoDataState: FC<NoDataStateProps> = ({
  title = "No data found",
  description = "Try adjusting your filters to see more results",
  icon,
  actionButton,
}) => {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      {/* Icon */}
      <div className="mb-6">
        {icon || (
          <svg className="w-16 h-16 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            />
          </svg>
        )}
      </div>

      {/* Title */}
      <h3 className="text-lg font-semibold text-gray-700 mb-2">{title}</h3>

      {/* Description */}
      <p className="text-gray-500 mb-6 max-w-md">{description}</p>

      {/* Action Button */}
      {actionButton && <div>{actionButton}</div>}
    </div>
  );
};

export default NoDataState;
