import { forwardRef, useEffect, useRef, type InputHTMLAttributes } from "react";
import { Check, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "type"> {
  checked?: boolean;
  indeterminate?: boolean;
  onCheckedChange?: (checked: boolean) => void;
}

export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(
  ({ className, checked, indeterminate = false, onCheckedChange, onChange, ...props }, ref) => {
    const internalRef = useRef<HTMLInputElement | null>(null);

    useEffect(() => {
      if (internalRef.current) {
        internalRef.current.indeterminate = indeterminate && !checked;
      }
    }, [indeterminate, checked]);

    const setRefs = (node: HTMLInputElement | null) => {
      internalRef.current = node;
      if (typeof ref === "function") {
        ref(node);
      } else if (ref) {
        ref.current = node;
      }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      onCheckedChange?.(e.target.checked);
      onChange?.(e);
    };

    const showCheck = Boolean(checked);
    const showMinus = indeterminate && !checked;

    return (
      <div className="relative inline-flex items-center justify-center">
        <input
          type="checkbox"
          ref={setRefs}
          className={cn(
            "peer h-4 w-4 shrink-0 rounded-sm border border-gray-300 ring-offset-background",
            "focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
            "disabled:cursor-not-allowed disabled:opacity-50",
            "data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground",
            "appearance-none cursor-pointer",
            showCheck || showMinus ? "bg-ui-interactive-primary border-ui-interactive-primary" : "bg-white border-neutral-300",
            className
          )}
          checked={checked}
          onChange={handleChange}
          {...props}
        />
        {showCheck ? <Check className="absolute h-3 w-3 text-white pointer-events-none" aria-hidden /> : null}
        {showMinus ? <Minus className="absolute h-3 w-3 text-white pointer-events-none" aria-hidden /> : null}
      </div>
    );
  }
);

Checkbox.displayName = "Checkbox";
