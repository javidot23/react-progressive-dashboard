import { useRef, useState } from "react";

interface CalendarDayPickerProps {
  title?: string;
  value?: string | Date | null;
  onSelectDay: ((date: Date | null) => void) | ((iso: string) => void);
  isDayDisabled?: (date: Date) => boolean;
  disabled?: boolean;
}

export function CalendarDayPicker({ title, value, onSelectDay, isDayDisabled, disabled }: CalendarDayPickerProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [displayValue, setDisplayValue] = useState<string>(
    value instanceof Date ? value.toISOString().split("T")[0] : typeof value === "string" ? value : ""
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    setDisplayValue(raw);
    if (!raw) {
      (onSelectDay as (arg: any) => void)(null);
      return;
    }
    const date = new Date(raw + "T00:00:00");
    if (!isNaN(date.getTime())) {
      if (isDayDisabled && isDayDisabled(date)) return;
      // Support both string-based and Date-based handlers
      const handler = onSelectDay as (arg: any) => void;
      handler(raw);
    }
  };

  return (
    <div className="flex flex-col gap-1">
      {title && <label className="text-sm font-medium text-ui-text-secondary">{title}</label>}
      <input
        ref={inputRef}
        type="date"
        value={displayValue}
        onChange={handleChange}
        disabled={disabled}
        className="border border-ui-border-primary rounded-md px-3 py-1.5 text-sm text-ui-text-primary bg-ui-background-primary disabled:opacity-50 disabled:cursor-not-allowed"
      />
    </div>
  );
}
