import React from "react";

export interface RiskBadgeProps {
  /**
   * Risk rating value between 0 and 1 (e.g., 0.85 for 85%)
   */
  riskRating: number;
  /**
   * Whether to show the warning icon for high risk levels
   * @default true
   */
  showIcon?: boolean;
  /**
   * Size variant of the badge
   * @default "sm"
   */
  size?: "xs" | "sm" | "md";
  /**
   * Additional CSS classes to apply to the badge
   */
  className?: string;
}

/**
 * Determines risk badge styling based on risk rating value
 * Uses the same logic as the Plan page (MaterialRiskCard)
 */
const getRiskBadgeInfo = (riskRating: number) => {
  if (riskRating >= 0.0 && riskRating <= 0.2) {
    return {
      text: "Highly Unlikely",
      bgColor: "bg-green-100",
      textColor: "text-green-700",
      borderColor: "border-green-700",
    };
  } else if (riskRating >= 0.21 && riskRating <= 0.4) {
    return {
      text: "Unlikely",
      bgColor: "bg-green-100",
      textColor: "text-green-700",
      borderColor: "border-green-700",
    };
  } else if (riskRating >= 0.41 && riskRating <= 0.6) {
    return {
      text: "Even Chance",
      bgColor: "bg-yellow-100",
      textColor: "text-yellow-700",
      borderColor: "border-yellow-700",
    };
  } else if (riskRating >= 0.61 && riskRating <= 0.8) {
    return {
      text: "Likely",
      bgColor: "bg-yellow-100",
      textColor: "text-yellow-700",
      borderColor: "border-yellow-700",
    };
  } else {
    // 0.81 - 1.0 (Highly Likely)
    return {
      text: "Highly Likely",
      bgColor: "bg-red-100",
      textColor: "text-red-700",
      borderColor: "border-red-700",
    };
  }
};

/**
 * RiskBadge - A reusable component for displaying risk level badges
 *
 * This component provides consistent styling for risk rating indicators
 * across the application, based on the design from the Plan page.
 *
 * @example
 * // Basic usage
 * <RiskBadge riskRating={0.85} />
 *
 * @example
 * // Without icon, larger size
 * <RiskBadge riskRating={0.65} showIcon={false} size="md" />
 */
export const RiskBadge: React.FC<RiskBadgeProps> = ({ riskRating, showIcon = true, size = "sm", className = "" }) => {
  const badgeInfo = getRiskBadgeInfo(riskRating);
  const shouldShowIcon = showIcon;

  // Size-based styling
  const sizeClasses = {
    xs: "px-1 py-0.5 text-2xs",
    sm: "px-1 py-0.5 text-xs",
    md: "px-2 py-1 text-sm",
  };

  return (
    <div
      className={`flex items-center ${badgeInfo.bgColor} ${badgeInfo.textColor} border border-1 ${badgeInfo.borderColor} ${sizeClasses[size]} rounded font-semibold text-nowrap ${className}`}
    >
      {shouldShowIcon && (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={1.5}
          stroke="currentColor"
          className="w-4 h-4 mr-1"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
          />
        </svg>
      )}
      {badgeInfo.text}
    </div>
  );
};

export default RiskBadge;
