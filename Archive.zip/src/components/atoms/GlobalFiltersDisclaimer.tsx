import { useState } from "react";
import { useGlobalFiltersStore } from "@/stores/slices/globalFilters";
import AlertTriangleIcon from "@/assets/icons/alert-triangle-primary.svg";
import RemoveIcon from "@/assets/icons/remove.svg";

const DEFAULT_MESSAGE = "This chart is not filtered based on the global filters you've selected";

interface GlobalFiltersDisclaimerProps {
  message?: string;
}

export default function GlobalFiltersDisclaimer({ message = DEFAULT_MESSAGE }: GlobalFiltersDisclaimerProps) {
  const { filters } = useGlobalFiltersStore();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const hasFilters = Object.keys(filters).length > 0;

  if (!hasFilters) {
    return null;
  }

  if (isCollapsed) {
    return (
      <button
        onClick={() => setIsCollapsed(false)}
        className="mb-4 flex items-center justify-center w-10 h-10 rounded-md bg-[#FFF8BA] border border-[#FFA400] hover:bg-[#FFE066] transition-colors"
        aria-label="Expand disclaimer"
      >
        <svg className="w-5 h-5 text-[#FFA400]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.414A1 1 0 013 6.707V4z"
          />
        </svg>
      </button>
    );
  }

  return (
    <div className="flex items-center gap-3 p-3 bg-[#FFF8BA] border border-[#FFA400] rounded-md">
      <div className="shrink-0 flex items-center justify-center">
        <img
          src={AlertTriangleIcon}
          alt="Warning"
          width={18}
          height={18}
          style={{
            filter:
              "brightness(0) saturate(100%) invert(38%) sepia(78%) saturate(2000%) hue-rotate(350deg) brightness(95%) contrast(90%)",
          }}
        />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <div className="flex-1">
            <h3
              className="text-sm font-bold leading-5"
              style={{
                color: "var(--Cencora-text-heading, var(--color-text-heading, #1E1E1E))",
                fontFamily: "var(--text-body-sm-font-family, Cencora-Gilroy)",
                fontSize: "var(--text-body-sm-font-size, 14px)",
                fontWeight: 700,
                lineHeight: "var(--text-body-sm-line-height, 20px)",
              }}
            >
              Disclaimer
            </h3>
            <p
              className="text-sm leading-5"
              style={{
                color: "var(--Cencora-text-primary, var(--color-text-primary, #3B3B3B))",
                fontFamily: "var(--text-body-sm-font-family, Cencora-Gilroy)",
                fontSize: "var(--text-body-sm-font-size, 14px)",
                fontWeight: 500,
                lineHeight: "var(--text-body-sm-line-height, 20px)",
              }}
            >
              {message}
            </p>
          </div>

          <button
            onClick={() => setIsCollapsed(true)}
            className="shrink-0 hover:opacity-70 transition-opacity"
            aria-label="Collapse disclaimer"
          >
            <img src={RemoveIcon} alt="Close" width={18} height={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
