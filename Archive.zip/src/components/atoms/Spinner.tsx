import { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export interface SpinnerProps extends HTMLAttributes<HTMLDivElement> {
  size?: "sm" | "md" | "lg";
  color?: "primary" | "secondary" | "white";
}

export const Spinner = ({ size = "md", color = "primary", className, ...props }: SpinnerProps) => {
  const sizes = {
    sm: "h-4 w-4",
    md: "h-6 w-6",
    lg: "h-8 w-8",
  };

  const colors = {
    primary: "border-purple-600",
    secondary: "border-gray-600",
    white: "border-white",
  };

  return (
    <div
      className={cn("animate-spin rounded-full border-2 border-t-transparent", sizes[size], colors[color], className)}
      {...props}
    />
  );
};
