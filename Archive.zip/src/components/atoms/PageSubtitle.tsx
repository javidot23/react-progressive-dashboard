import type React from "react";
import { cn } from "@/lib/utils";

interface PageSubtitleProps extends React.HTMLAttributes<HTMLParagraphElement> {
  children: React.ReactNode;
}

export function PageSubtitle({ children, className, ...props }: PageSubtitleProps) {
  return (
    <p className={cn("text-slate-500", className)} {...props}>
      {children}
    </p>
  );
}
