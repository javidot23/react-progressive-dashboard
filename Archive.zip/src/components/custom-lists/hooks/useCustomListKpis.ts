import { queryOptions, useQuery } from "@tanstack/react-query";
import { customListsService } from "@/lib/apiServices";

export const customListKpisQueryKeys = {
  all: ["customListKpis"] as const,
} as const;

const customListKpisQueryOptions = queryOptions({
  queryKey: customListKpisQueryKeys.all,
  queryFn: async () => {
    const response = await customListsService.customListKpiStats();
    return response.data.data;
  },
});

export const useCustomListKpis = () => useQuery(customListKpisQueryOptions);
