import { useMutation, useQueryClient } from "@tanstack/react-query";
import { customListsService, type CustomList } from "@/lib/apiServices";
import { customListsQueryKeys } from "./useCustomLists";
import { customListDetailsQueryKeys } from "../queries/custom-list-details";

interface UpdateCustomListParams {
  listId: string;
  data: Partial<CustomList>;
}

export const useUpdateCustomList = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ listId, data }: UpdateCustomListParams) => customListsService.updateCustomList(listId, data),
    meta: {
      successMessage: "List updated",
      errorMessage: "Couldn't update list",
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: customListsQueryKeys.all });
      queryClient.invalidateQueries({ queryKey: customListDetailsQueryKeys.byId(variables.listId) });
    },
  });
};
