import { useMutation, useQueryClient } from "@tanstack/react-query";
import { customListsService } from "@/lib/apiServices";
import { customListsQueryKeys } from "./useCustomLists";

export const useDeleteCustomList = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (listId: string) => customListsService.deleteCustomList(listId),
    meta: {
      successMessage: "List deleted",
      errorMessage: "Couldn't delete list",
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: customListsQueryKeys.all });
    },
  });
};
