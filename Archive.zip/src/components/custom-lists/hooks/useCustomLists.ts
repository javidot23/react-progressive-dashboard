import { useInfiniteQuery, keepPreviousData } from "@tanstack/react-query";
import { customListsService, type CustomList } from "@/lib/apiServices";

export const customListsQueryKeys = {
  all: ["customLists"] as const,
  list: () => [...customListsQueryKeys.all, "list"] as const,
  infiniteList: (pageSize: number, search?: string) =>
    [...customListsQueryKeys.list(), "infinite", { pageSize, search: search ?? "" }] as const,
} as const;

interface UseCustomListsParams {
  pageSize?: number;
  search?: string;
}

interface CustomListsPageResult {
  results: CustomList[];
  hasMore: boolean;
  count: number;
  offset: number;
}

export function useCustomLists({ pageSize = 10, search }: UseCustomListsParams = {}) {
  const query = useInfiniteQuery({
    queryKey: customListsQueryKeys.infiniteList(pageSize, search),
    queryFn: async ({ pageParam = 0 }): Promise<CustomListsPageResult> => {
      const response = await customListsService.getCustomLists({
        limit: pageSize,
        offset: pageParam,
        ...(search && { search }),
      });
      const data = response.data.data;

      return {
        results: data.results ?? [],
        hasMore: data.next !== null,
        count: data.count,
        offset: pageParam,
      };
    },
    initialPageParam: 0,
    getNextPageParam: lastPage => {
      if (lastPage.hasMore) {
        return lastPage.offset + pageSize;
      }
      return undefined;
    },
    placeholderData: keepPreviousData,
  });

  const allCustomLists = query.data?.pages.flatMap(page => page.results) ?? [];
  const totalCount = query.data?.pages[0]?.count ?? 0;

  return {
    customLists: allCustomLists,
    totalCount,
    hasMore: query.hasNextPage ?? false,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isFetchingNextPage: query.isFetchingNextPage,
    isPending: query.isPending,
    error: query.error,
    isError: query.isError,
    fetchNextPage: query.fetchNextPage,
    refetch: query.refetch,
  };
}

export type { CustomList };
export default useCustomLists;
