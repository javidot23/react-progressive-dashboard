import { customListsService } from "@/lib/apiServices";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { customListDetailsQueryKeys } from "../queries/custom-list-details";
import { customListsQueryKeys } from "./useCustomLists";
import { customListKpisQueryKeys } from "./useCustomListKpis";

type AddMaterialsVariables = {
  entity_ids: string[];
};

export const useAddMaterials = (listId: string) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: AddMaterialsVariables) => {
      const response = await customListsService.addMaterials(listId, payload);
      return response.data.data;
    },
    meta: {
      successMessage: "Materials added",
      errorMessage: "Couldn't add materials",
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: customListDetailsQueryKeys.byId(listId),
      });
      queryClient.invalidateQueries({
        queryKey: customListDetailsQueryKeys.all,
      });
      queryClient.invalidateQueries({
        queryKey: customListsQueryKeys.all,
      });
      queryClient.invalidateQueries({
        queryKey: customListKpisQueryKeys.all,
      });
    },
  });
};
