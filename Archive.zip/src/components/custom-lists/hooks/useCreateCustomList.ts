import { customListsService } from "@/lib/apiServices";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { customListsQueryKeys } from "./useCustomLists";

export const useCreateCustomList = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: customListsService.createCustomList,
    meta: {
      successMessage: "List created",
      errorMessage: "Couldn't create list",
    },
    onSuccess: () => {

      queryClient.invalidateQueries({ queryKey: customListsQueryKeys.all });
      navigate("/custom-lists", { replace: true });
    },
  });
};
