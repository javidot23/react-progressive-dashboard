import { Input } from "@/components/atoms/Input";
import { useCustomLists } from "@/components/custom-lists/hooks/useCustomLists";
import { useDeleteCustomList } from "@/components/custom-lists/hooks/useDeleteCustomList";
import { useUpdateCustomList } from "@/components/custom-lists/hooks/useUpdateCustomList";
import { formatDateTime } from "@/lib/utils";
import { useState, useCallback, useRef, useEffect } from "react";
import { Button } from "@/components";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/molecules/DropdownMenu";
import { useSearchParams } from "react-router-dom";
import { icons, DeleteIcon, PencilIcon, ThreeDotsIcon } from "@/components/custom-lists/components/Icons";

const PANEL_HEIGHT = {
    base: 775,
    sm: 550,
    lg: 600,
};
const SIDEBAR_ITEM_HEIGHT = 72;
const SHIMMER_ITEM_COUNT = 7;

const SidebarItemShimmer = () => (
    <div className="flex gap-2 items-center p-4 animate-pulse" style={{ height: SIDEBAR_ITEM_HEIGHT }}>
        <div className="w-7 h-7 rounded-full bg-gray-200 shrink-0" />
        <div className="w-7 h-7 rounded-md bg-gray-200 shrink-0" />
        <div className="flex flex-col flex-1 gap-1">
            <div className="h-4 bg-gray-200 rounded w-3/4" />
            <div className="h-3 bg-gray-200 rounded w-1/2" />
        </div>
    </div>
);

const SidebarShimmer = () => (
    <div
        className="border border-border-primary rounded-lg w-full lg:w-96 shrink-0 flex flex-col overflow-hidden"
        style={{
            height: PANEL_HEIGHT.base,
            minHeight: PANEL_HEIGHT.base,
        }}
    >
        <div className="p-4 shrink-0">
            <div className="h-6 bg-gray-200 rounded w-24 animate-pulse" />
            <hr className="my-4 border-border-primary" />
            <div className="h-4 bg-gray-200 rounded w-28 mb-2 animate-pulse" />
            <div className="h-10 bg-gray-200 rounded animate-pulse" />
        </div>
        <div className="flex-1 overflow-y-auto">
            {Array.from({ length: SHIMMER_ITEM_COUNT }).map((_, i) => (
                <SidebarItemShimmer key={i} />
            ))}
        </div>
    </div>
);

const SEARCH_DEBOUNCE_MS = 300;

const CustomListSidebar = () => {
    const [searchParams, setSearchParams] = useSearchParams();
    const listId = searchParams.get("listId");
    const [searchQuery, setSearchQuery] = useState("");
    const [debouncedSearch, setDebouncedSearch] = useState("");
    const { customLists, isLoading, isError, error, hasMore, isFetchingNextPage, fetchNextPage, isFetching } = useCustomLists({
        search: debouncedSearch || undefined
    });
    const updateMutation = useUpdateCustomList();
    const deleteMutation = useDeleteCustomList();
    const [selectedList, setSelectedList] = useState<string | null>(null);
    const [editingListId, setEditingListId] = useState<string | null>(null);
    const [editingName, setEditingName] = useState("");

    const observerRef = useRef<IntersectionObserver | null>(null);
    const loadMoreRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedSearch(searchQuery);
        }, SEARCH_DEBOUNCE_MS);

        return () => clearTimeout(timer);
    }, [searchQuery]);

    const activeList = listId ?? customLists[0]?.id ?? "";
    const isSearching = searchQuery !== debouncedSearch || (isFetching && !isFetchingNextPage);

    const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchQuery(e.target.value);
    }, []);

    const handleClearSearch = useCallback(() => {
        setSearchQuery("");
        setDebouncedSearch("");
    }, []);

    useEffect(() => {
        if (!listId && customLists.length > 0 && customLists[0]?.id) {
            setSearchParams({ listId: customLists[0].id }, { replace: true });
        }
    }, [listId, customLists, setSearchParams]);

    useEffect(() => {
        if (observerRef.current) {
            observerRef.current.disconnect();
        }

        observerRef.current = new IntersectionObserver(
            (entries) => {
                if (entries[0].isIntersecting && hasMore && !isFetchingNextPage) {
                    fetchNextPage();
                }
            },
            { threshold: 0.1 }
        );

        if (loadMoreRef.current) {
            observerRef.current.observe(loadMoreRef.current);
        }

        return () => {
            if (observerRef.current) {
                observerRef.current.disconnect();
            }
        };
    }, [hasMore, isFetchingNextPage, fetchNextPage]);

    const handleRenameClick = useCallback((listId: string, currentName: string) => {
        setEditingListId(listId);
        setEditingName(currentName);
    }, []);

    const handleRenameSubmit = useCallback(() => {
        if (!editingListId || !editingName.trim()) return;

        updateMutation.mutate(
            { listId: editingListId, data: { name: editingName.trim() } },
            {
                onSuccess: () => {
                    setEditingListId(null);
                    setEditingName("");
                },
            }
        );
    }, [editingListId, editingName, updateMutation]);

    const handleRenameCancel = useCallback(() => {
        setEditingListId(null);
        setEditingName("");
    }, []);

    const handleDeleteClick = useCallback(
        (listId: string) => {
            deleteMutation.mutate(listId, {
                onSuccess: () => {
                    if (selectedList === listId) {
                        setSelectedList(null);
                    }
                },
            });
        },
        [deleteMutation, selectedList]
    );

    const handleItemClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        const { listid } = e.currentTarget.dataset;
        setSelectedList(listid as string);
        setSearchParams({ listId: listid as string }, { replace: true });
    }, [setSearchParams]);

    const isInitialLoad = isLoading && customLists.length === 0 && !debouncedSearch;
    if (isInitialLoad) {
        return <SidebarShimmer />;
    }

    if (isError) {
        return (
            <div
                className="border border-border-primary rounded-lg w-full lg:w-96 shrink-0 p-4 flex flex-col"
                style={{
                    height: PANEL_HEIGHT.base,
                    minHeight: PANEL_HEIGHT.base,
                }}
            >
                <div className="text-red-500">Error: {error?.message}</div>
            </div>
        );
    }

    return (
        <div
            className="border border-border-primary rounded-lg w-full lg:w-96 shrink-0 flex flex-col overflow-hidden"
            style={{
                height: PANEL_HEIGHT.base,
                minHeight: PANEL_HEIGHT.base,
            }}
        >
            <div className="p-4 shrink-0">
                <p className="text-lg font-semibold">My Lists</p>
                <hr className="my-4 border-border-primary" />
                <div className="relative">
                    <Input
                        placeholder="Search Lists"
                        value={searchQuery}
                        onChange={handleSearchChange}
                        className="pr-8"
                    />
                    {searchQuery && (
                        <button
                            type="button"
                            onClick={handleClearSearch}
                            className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1"
                            aria-label="Clear search"
                        >
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                        </button>
                    )}
                    {isSearching && (
                        <div className="absolute right-8 top-1/2 -translate-y-1/2">
                            <div className="w-4 h-4 border-2 border-gray-300 border-t-brand-primary-main rounded-full animate-spin" />
                        </div>
                    )}
                </div>
            </div>
            <div className={`flex-1 ${customLists.length > 0 ? 'overflow-y-auto' : ''}`}>
                {customLists.length === 0 && !isLoading ? (
                    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center h-full">
                        <div className="w-14 h-14 mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5" stroke="#9CA3AF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                        </div>
                        {debouncedSearch ? (
                            <>
                                <h4 className="text-sm font-medium text-gray-900 mb-1">No lists found</h4>
                                <p className="text-xs text-gray-500">
                                    No lists match "{debouncedSearch}"
                                </p>
                            </>
                        ) : (
                            <>
                                <h4 className="text-sm font-medium text-gray-900 mb-1">No custom lists yet</h4>
                                <p className="text-xs text-gray-500">
                                    Create your first list to get started
                                </p>
                            </>
                        )}
                    </div>
                ) : customLists.map(list => (
                    <div
                        key={list.id}
                        data-listid={list.id}
                        className={`flex gap-2 items-center p-4 cursor-pointer transition-colors ${activeList === list.id ? "bg-[#EEEDFE]" : "hover:bg-gray-50"}`}
                        style={{ minHeight: SIDEBAR_ITEM_HEIGHT }}
                        onClick={handleItemClick}
                    >
                        <div className="flex items-center justify-center w-7 h-7 rounded-full bg-[#461E96] shrink-0">
                            <p className="text-sm text-white">{list.items_count}</p>
                        </div>
                        <div className="w-7 h-7 flex items-center justify-center rounded-md bg-[#DDDBF7] shrink-0">
                            {icons[list.icon as keyof typeof icons]}
                        </div>
                        <div className="flex flex-col flex-1 min-w-0">
                            {editingListId === list.id ? (
                                <div className="flex gap-2 items-center" onClick={e => e.stopPropagation()}>
                                    <Input
                                        value={editingName}
                                        onChange={e => setEditingName(e.target.value)}
                                        onKeyDown={e => {
                                            if (e.key === "Enter") handleRenameSubmit();
                                            if (e.key === "Escape") handleRenameCancel();
                                        }}
                                        autoFocus
                                        className="h-8 text-sm"
                                    />
                                    <Button size="sm" onClick={handleRenameSubmit} disabled={updateMutation.isPending}>
                                        Save
                                    </Button>
                                    <Button size="sm" variant="outline" onClick={handleRenameCancel} disabled={updateMutation.isPending}>
                                        Cancel
                                    </Button>
                                </div>
                            ) : (
                                <>
                                    <div className="font-semibold truncate">{list.name}</div>
                                    <div className="text-xs text-text-secondary truncate">
                                        Updated {list.updated_at ? formatDateTime(list.updated_at) : ""}
                                    </div>
                                </>
                            )}
                        </div>
                        {editingListId !== list.id && (
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" className="text-slate-500 text-xs px-2 shrink-0" onClick={e => e.stopPropagation()}>
                                        <ThreeDotsIcon />
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                    <DropdownMenuItem
                                        onClick={() => {
                                            if (list.id) {
                                                handleRenameClick(list.id, list.name);
                                            }
                                        }}

                                    >
                                        <div className="flex items-center gap-2">
                                            <PencilIcon />
                                            <p className="text-sm">Rename List</p>
                                        </div>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                        onClick={() => {
                                            if (list.id) {
                                                handleDeleteClick(list.id);
                                            }
                                        }}
                                    >
                                        <div className="flex items-center gap-2">
                                            <DeleteIcon />
                                            <p className="text-sm text-red-500">Delete</p>
                                        </div>
                                    </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        )}
                    </div>
                ))}

                <div ref={loadMoreRef} className="h-1" />

                {isFetchingNextPage && (
                    <div className="p-4">
                        <SidebarItemShimmer />
                        <SidebarItemShimmer />
                    </div>
                )}

                {!hasMore && customLists.length > 0 && (
                    <div className="p-4 text-center text-sm text-text-secondary">
                        No more lists
                    </div>
                )}
            </div>
        </div>
    );
};

export { SidebarShimmer };
export default CustomListSidebar;
