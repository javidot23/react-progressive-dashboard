import { useState, useCallback, useMemo, useEffect, useRef } from "react";
import { Input, Pagination } from "@/components/atoms";
import { Button } from "@/components/atoms/Button";
import { materialListQueryOptions, MaterialData } from "@/components/custom-lists/queries/material-list";
import { useQuery } from "@tanstack/react-query";
import { formatDateTime, getMaterialStatusDescription } from "@/lib/utils";
import { useSearchParams } from "react-router-dom";
import { customListDetailsQueryOptions } from "../queries/custom-list-details";
import { useAddMaterials } from "../hooks/useAddMaterials";

const DEFAULT_PAGE = 1;
const DEFAULT_PAGE_SIZE = 10;
const SHIMMER_ROWS = 10;
const SEARCH_DEBOUNCE_MS = 300;

const PANEL_HEIGHT = {
  base: 775,
  sm: 550,
  lg: 600,
};

const ShimmerRow = () => (
  <tr className="border-t animate-pulse h-[41px]">
    <td className="px-4 py-2 w-[50px]">
      <div className="w-4 h-4 bg-gray-200 rounded" />
    </td>
    <td className="px-4 py-2 min-w-[150px]">
      <div className="h-4 bg-gray-200 rounded w-3/4" />
    </td>
    <td className="px-4 py-2 min-w-[120px]">
      <div className="h-4 bg-gray-200 rounded w-2/3" />
    </td>
    <td className="px-4 py-2 min-w-[120px]">
      <div className="h-4 bg-gray-200 rounded w-2/3" />
    </td>
    <td className="px-4 py-2 min-w-[140px]">
      <div className="h-4 bg-gray-200 rounded w-1/2" />
    </td>
    <td className="px-4 py-2 min-w-[150px]">
      <div className="h-4 bg-gray-200 rounded w-2/3" />
    </td>
  </tr>
);

const HeaderShimmer = () => (
  <div className="animate-pulse h-[44px] flex flex-col justify-center">
    <div className="h-6 bg-gray-200 rounded w-48 mb-2" />
    <div className="h-4 bg-gray-200 rounded w-64" />
  </div>
);

const DetailsShimmer = () => (
  <div
    className="flex-1 border border-border-primary rounded-lg min-w-0 flex flex-col overflow-hidden"
    style={{
      height: PANEL_HEIGHT.base,
      minHeight: PANEL_HEIGHT.base,
    }}
  >
    <div className="p-4 sm:p-6 shrink-0">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2 min-h-[44px]">
          <div className="shrink-0 w-11 h-11 bg-gray-200 rounded-lg animate-pulse" />
          <HeaderShimmer />
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="h-8 w-32 bg-gray-200 rounded animate-pulse" />
        </div>
      </div>
    </div>
    <hr className="border-border-primary shrink-0" />
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="relative w-full sm:w-80 px-4 sm:px-0 sm:mx-6 mt-4 sm:mt-6 shrink-0">
        <div className="h-10 bg-gray-200 rounded animate-pulse" />
      </div>
      <div className="px-4 sm:px-6 pb-4 sm:pb-6 mt-2 flex-1 overflow-y-auto">
        <table className="w-full text-sm text-left min-w-max">
          <thead className="font-bold text-ui-text-primary sticky top-0 bg-white z-10 shadow-xs">
            <tr className="h-[41px]">
              <th className="px-4 py-2 w-[50px]">
                <div className="w-4 h-4 bg-gray-200 rounded animate-pulse" />
              </th>
              <th className="px-4 py-2 min-w-[150px]">Material Name</th>
              <th className="px-4 py-2 min-w-[120px]">Material ID</th>
              <th className="px-4 py-2 min-w-[120px]">NDC</th>
              <th className="px-4 py-2 min-w-[140px]">Category</th>
              <th className="px-4 py-2 min-w-[150px]">Material Status</th>
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: SHIMMER_ROWS }).map((_, index) => (
              <ShimmerRow key={`shimmer-${index}`} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

const detailsPanelClass = "flex-1 border border-border-primary rounded-lg min-w-0 flex flex-col overflow-hidden";

const NoListSelectedPanel = () => (
  <div
    className={detailsPanelClass}
    style={{
      height: PANEL_HEIGHT.base,
      minHeight: PANEL_HEIGHT.base,
    }}
  >
    <div className="flex flex-1 flex-col items-center justify-center p-8 text-center">
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-gray-100">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
          <path
            d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5"
            stroke="#9CA3AF"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <h3 className="mb-2 text-lg font-semibold text-gray-900">No list selected</h3>
      <p className="max-w-sm text-sm text-gray-500">
        Choose a list from <span className="font-medium">My Lists</span>, or create a list if you do not have one yet.
      </p>
    </div>
  </div>
);

const ListDataMismatchPanel = () => (
  <div
    className={detailsPanelClass}
    style={{
      height: PANEL_HEIGHT.base,
      minHeight: PANEL_HEIGHT.base,
    }}
  >
    <div className="flex flex-1 flex-col items-center justify-center p-8 text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-50">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
          <path
            d="M12 9V13M12 17H12.01M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z"
            stroke="#D97706"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <h3 className="mb-2 text-lg font-semibold text-gray-900">Unable to load this list</h3>
      <p className="max-w-sm text-sm text-gray-500">
        The response did not match the selected list. Try selecting the list again or refresh the page.
      </p>
    </div>
  </div>
);

const WarningTriangleIcon = () => (
  <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="44" height="44" rx="10" fill="#EF4444" fillOpacity="0.1" />
    <path
      stroke="#9E2305"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M22 27.6248C21.938 27.6248 21.8775 27.6432 21.826 27.6777C21.7746 27.7122 21.7345 27.7612 21.711 27.8185C21.6874 27.8758 21.6814 27.9388 21.6938 27.9995C21.7061 28.0602 21.7362 28.1159 21.7802 28.1594C21.8243 28.203 21.8803 28.2325 21.9411 28.2442C22.0019 28.2559 22.0649 28.2492 22.1219 28.225C22.1789 28.2009 22.2275 28.1603 22.2615 28.1085C22.2954 28.0567 22.3132 27.9959 22.3125 27.934C22.3126 27.8929 22.3046 27.8522 22.2889 27.8142C22.2733 27.7763 22.2502 27.7418 22.2212 27.7127C22.1922 27.6837 22.1577 27.6607 22.1197 27.645C22.0817 27.6294 22.0411 27.6214 22 27.6215M22 25.1248V18.8748M23.3508 13.4665C23.2268 13.214 23.0345 13.0013 22.7957 12.8526C22.557 12.7038 22.2813 12.625 22 12.625C21.7187 12.625 21.443 12.7038 21.2043 12.8526C20.9655 13.0013 20.7732 13.214 20.6492 13.4665L12.755 29.5481C12.66 29.7414 12.6158 29.9558 12.6266 30.1709C12.6374 30.386 12.7029 30.5949 12.8168 30.7777C12.9307 30.9605 13.0893 31.1112 13.2777 31.2157C13.4661 31.3202 13.6779 31.3749 13.8933 31.3748H30.1067C30.3221 31.3749 30.534 31.3202 30.7223 31.2157C30.9107 31.1112 31.0693 30.9605 31.1832 30.7777C31.2972 30.5949 31.3626 30.386 31.3734 30.1709C31.3842 29.9558 31.34 29.7414 31.245 29.5481L23.3508 13.4665Z"
    />
  </svg>
);

interface CustomListItem {
  id: string;
  entity_id: string;
  material: {
    mat_nbr: string;
    name: string;
    ndc: string;
    category: string;
    status: string;
  };
  rank: number | null;
  added_by: {
    id: string;
    first_name: string;
    last_name: string;
  };
  added_at: string;
}

interface CustomListDetailsData {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  items_count: number;
  is_archived: boolean;
  owner: {
    id: string;
    first_name: string;
    last_name: string;
  };
  created_at: string;
  updated_at: string;
  items: CustomListItem[];
}

interface MaterialListTableProps {
  data: MaterialData[] | undefined;
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
  currentPage: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  onToggleSelectAll: () => void;
  isTransitioning?: boolean;
}

const MaterialListTable = ({
  data,
  isLoading,
  isError,
  error,
  currentPage,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  selectedIds,
  onToggleSelect,
  onToggleSelectAll,
  isTransitioning = false,
}: MaterialListTableProps) => {
  const allSelected = data && data.length > 0 && data.every(m => selectedIds.has(m.mat_nbr));
  const someSelected = data && data.some(m => selectedIds.has(m.mat_nbr)) && !allSelected;

  const showShimmer = isLoading || isTransitioning;

  if (isError) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-red-500">Error loading materials: {error?.message || "Unknown error"}</div>
      </div>
    );
  }

  return (
    <div className="w-full flex flex-col h-full overflow-hidden">
      <div className="overflow-y-auto overflow-x-auto flex-1">
        <table className="w-full text-sm text-left min-w-max">
          <thead className="font-bold text-ui-text-primary sticky top-0 bg-white z-10 shadow-xs">
            <tr className="h-[41px]">
              <th className="px-4 py-2 w-[50px]">
                <input
                  type="checkbox"
                  checked={!showShimmer && allSelected}
                  ref={el => {
                    if (el) el.indeterminate = !showShimmer && (someSelected ?? false);
                  }}
                  onChange={onToggleSelectAll}
                  disabled={showShimmer}
                  className="w-4 h-4 rounded border-gray-300 text-brand-primary-main focus:ring-brand-primary-main cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                />
              </th>
              <th className="px-4 py-2 min-w-[150px]">Material Name</th>
              <th className="px-4 py-2 min-w-[120px]">Material ID</th>
              <th className="px-4 py-2 min-w-[150px]">Supplier Name</th>
              <th className="px-4 py-2 min-w-[150px]">Supplier ID</th>
              <th className="px-4 py-2 min-w-[120px]">NDC</th>
              <th className="px-4 py-2 min-w-[140px]">Category</th>
              <th className="px-4 py-2 min-w-[150px]">Material Status</th>
            </tr>
          </thead>
          <tbody>
            {showShimmer ? (
              Array.from({ length: SHIMMER_ROWS }).map((_, index) => <ShimmerRow key={`shimmer-${index}`} />)
            ) : data && data.length > 0 ? (
              data.map(material => (
                <tr
                  key={material.mat_nbr}
                  className={`border-t hover:bg-brand-primary-50 cursor-pointer h-[41px] ${
                    selectedIds.has(material.mat_nbr) ? "bg-brand-primary-50" : ""
                  }`}
                >
                  <td className="px-4 py-2 w-[50px]">
                    <input
                      type="checkbox"
                      checked={selectedIds.has(material.mat_nbr)}
                      onChange={() => onToggleSelect(material.mat_nbr)}
                      onClick={e => e.stopPropagation()}
                      className="w-4 h-4 rounded border-gray-300 text-brand-primary-main focus:ring-brand-primary-main cursor-pointer"
                    />
                  </td>
                  <td className="px-4 py-2 min-w-[150px]">
                    <div className="font-normal truncate">{material.name || "-"}</div>
                  </td>
                  <td className="px-4 py-2 min-w-[120px]">{material.mat_nbr || "-"}</td>
                  <td className="px-4 py-2 min-w-[150px]">{material.vendor || "-"}</td>
                  <td className="px-4 py-2 min-w-[150px]">{material.vendor_nbr || "-"}</td>
                  <td className="px-4 py-2 min-w-[120px]">{material.ndc || "-"}</td>
                  <td className="px-4 py-2 min-w-[140px]">
                    <div className="w-fit bg-[#E8E8E8] text-xs font-semibold px-2 py-1 rounded-full">
                      {material.scrm_mat_grp || "-"}
                    </div>
                  </td>
                  <td className="px-4 py-2 min-w-[150px]">
                    {material.xplant_mat_stat ? getMaterialStatusDescription(material.xplant_mat_stat) : "-"}
                  </td>
                </tr>
              ))
            ) : (
              <tr className="h-[41px]">
                <td colSpan={8} className="px-4 py-6 text-center text-ui-text-secondary">
                  No materials found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="shrink-0 border-t border-gray-200">
        <Pagination
          currentPage={currentPage}
          pageSize={pageSize}
          total={showShimmer ? 0 : total}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
          itemName="Materials"
          isLoading={showShimmer}
        />
      </div>
    </div>
  );
};

const CustomListDetails = () => {
  const [searchParams] = useSearchParams();
  const [currentPage, setCurrentPage] = useState(DEFAULT_PAGE);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  const listId = searchParams.get("listId");

  const lastAppliedSearchRef = useRef(searchQuery);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchQuery);
      if (lastAppliedSearchRef.current !== searchQuery) {
        setCurrentPage(DEFAULT_PAGE);
        lastAppliedSearchRef.current = searchQuery;
      }
    }, SEARCH_DEBOUNCE_MS);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const syncStateRef = useRef<{ listId: string | null; dataUpdatedAt: number }>({
    listId: null,
    dataUpdatedAt: 0,
  });

  const {
    data: customListDetails,
    isSuccess: isCustomListDetailsSuccess,
    isFetching: isCustomListDetailsFetching,
    isError: isCustomListDetailsError,
    error: customListDetailsError,
    dataUpdatedAt,
  } = useQuery(customListDetailsQueryOptions(listId ?? ""));

  const {
    data,
    isLoading,
    isError,
    error,
    isFetching: isMaterialsFetching,
  } = useQuery(materialListQueryOptions(currentPage, pageSize, debouncedSearch || undefined));
  const addMaterials = useAddMaterials(listId ?? "");
  const customListData = customListDetails as CustomListDetailsData | undefined;
  const isDataForCurrentList = customListData?.id === listId;
  const displayData = isDataForCurrentList ? customListData : undefined;

  const isSynced = syncStateRef.current.listId === listId && syncStateRef.current.dataUpdatedAt === dataUpdatedAt;
  const isNavigatingToNewList = syncStateRef.current.listId !== listId;

  useEffect(() => {
    if (!isCustomListDetailsSuccess || !customListData || !isDataForCurrentList) {
      return;
    }

    const needsSync = syncStateRef.current.listId !== listId || syncStateRef.current.dataUpdatedAt !== dataUpdatedAt;

    if (needsSync) {
      // API uses entity_id for add-materials; table rows use mat_nbr — they align for list items (see tests).
      setSelectedIds(new Set(customListData.items?.map(item => item.entity_id) ?? []));
      syncStateRef.current = { listId, dataUpdatedAt };
    }
  }, [isCustomListDetailsSuccess, customListData, isDataForCurrentList, listId, dataUpdatedAt]);

  useEffect(() => {
    setCurrentPage(DEFAULT_PAGE);
    setSearchQuery("");
    setDebouncedSearch("");
    lastAppliedSearchRef.current = "";
  }, [listId]);

  const materials = useMemo(() => (data?.results ?? []) as MaterialData[], [data?.results]);
  const total = data?.count ?? 0;

  const handlePageChange = useCallback((page: number) => setCurrentPage(page), []);

  const handlePageSizeChange = useCallback((size: number) => {
    setPageSize(size);
    setCurrentPage(DEFAULT_PAGE);
  }, []);

  const handleToggleSelect = useCallback((id: string) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  }, []);

  const handleToggleSelectAll = useCallback(() => {
    setSelectedIds(prev => {
      const currentPageIds = materials.map(m => m.mat_nbr);
      if (currentPageIds.length === 0) return prev;

      const allSelected = currentPageIds.every(id => prev.has(id));
      const next = new Set(prev);
      if (allSelected) {
        currentPageIds.forEach(id => next.delete(id));
      } else {
        currentPageIds.forEach(id => next.add(id));
      }
      return next;
    });
  }, [materials]);

  const handleSaveCustomList = useCallback(() => {
    addMaterials.mutate({ entity_ids: Array.from(selectedIds) });
  }, [selectedIds, addMaterials]);

  const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  }, []);

  const handleClearSearch = useCallback(() => {
    setSearchQuery("");
    setDebouncedSearch("");
    setCurrentPage(DEFAULT_PAGE);
  }, []);

  const isSearching = searchQuery !== debouncedSearch || isMaterialsFetching;

  const isTransitioningList = isNavigatingToNewList && !isDataForCurrentList;

  const isListDetailsMismatch = Boolean(listId) && isCustomListDetailsSuccess && Boolean(customListData) && !isDataForCurrentList;

  const isDetailsStillLoading = Boolean(listId) && !isCustomListDetailsError && !isListDetailsMismatch && !displayData;

  const hasChanges = useMemo(() => {
    if (isTransitioningList || isCustomListDetailsFetching || !isSynced) {
      return false;
    }

    const originalIds = new Set(displayData?.items?.map(item => item.entity_id) ?? []);

    if (originalIds.size !== selectedIds.size) return true;

    for (const id of selectedIds) {
      if (!originalIds.has(id)) return true;
    }

    return false;
  }, [displayData?.items, selectedIds, isTransitioningList, isCustomListDetailsFetching, isSynced]);

  if (!listId) {
    return <NoListSelectedPanel />;
  }

  if (isDetailsStillLoading) {
    return <DetailsShimmer />;
  }

  if (isListDetailsMismatch) {
    return <ListDataMismatchPanel />;
  }

  if (isCustomListDetailsError) {
    return (
      <div
        className="flex-1 border border-border-primary rounded-lg min-w-0 flex flex-col overflow-hidden"
        style={{
          height: PANEL_HEIGHT.base,
          minHeight: PANEL_HEIGHT.base,
        }}
      >
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
          <div className="w-16 h-16 mb-4 rounded-full bg-red-100 flex items-center justify-center">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M12 9V13M12 17H12.01M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z"
                stroke="#DC2626"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">List Not Found</h3>
          <p className="text-sm text-gray-500 max-w-sm">
            {(customListDetailsError as Error)?.message ||
              "The custom list you're looking for doesn't exist or has been deleted."}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="flex-1 border border-border-primary rounded-lg min-w-0 flex flex-col overflow-hidden"
      style={{
        height: PANEL_HEIGHT.base,
        minHeight: PANEL_HEIGHT.base,
      }}
    >
      <div className="p-4 sm:p-6 shrink-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2 min-h-[44px]">
            <div className="shrink-0">
              <WarningTriangleIcon />
            </div>
            <div className="min-h-[44px] flex flex-col justify-center min-w-0">
              <div className="text-lg sm:text-xl font-bold truncate">{displayData?.name || "List Name"}</div>
              <div className="text-xs sm:text-sm text-text-secondary">
                {displayData?.items_count} materials • Last updated{" "}
                {displayData?.updated_at ? formatDateTime(displayData.updated_at) : "N/A"}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button
              size="sm"
              onClick={handleSaveCustomList}
              disabled={addMaterials.isPending || !hasChanges || isCustomListDetailsFetching}
              className="text-xs sm:text-sm whitespace-nowrap"
            >
              Save Custom List
            </Button>
          </div>
        </div>
      </div>
      <hr className="border-border-primary shrink-0" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="w-full px-4 sm:px-0 sm:mx-6 mt-4 sm:mt-6 shrink-0">
          <div className="relative w-full sm:w-96">
            <Input
              placeholder="Search by Name, ID, NDC, Supplier Name, Supplier ID"
              value={searchQuery}
              onChange={handleSearchChange}
              className="w-full pr-14 text-xs"
              type="text"
              inputMode="search"
              role="searchbox"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
              {isSearching && (
                <div className="pointer-events-none">
                  <div className="w-4 h-4 border-2 border-gray-300 border-t-brand-primary-main rounded-full animate-spin" />
                </div>
              )}
              {searchQuery.length > 0 && (
                <button
                  type="button"
                  onClick={handleClearSearch}
                  aria-label="Clear search"
                  className="text-gray-400 hover:text-gray-600 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 rounded-sm"
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="block"
                  >
                    <path d="M5 5L15 15M15 5L5 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </button>
              )}
            </div>
          </div>
        </div>
        <div className="px-4 sm:px-6 pb-4 sm:pb-6 mt-2 flex-1 overflow-hidden">
          <MaterialListTable
            data={materials}
            isLoading={isLoading}
            isError={isError}
            error={error}
            currentPage={currentPage}
            pageSize={pageSize}
            total={total}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            selectedIds={selectedIds}
            onToggleSelect={handleToggleSelect}
            onToggleSelectAll={handleToggleSelectAll}
            isTransitioning={isTransitioningList}
          />
        </div>
      </div>
    </div>
  );
};

export default CustomListDetails;
