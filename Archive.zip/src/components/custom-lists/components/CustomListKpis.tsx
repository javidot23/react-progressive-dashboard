import { useCustomListKpis } from "../hooks/useCustomListKpis";

const KpiSkeleton = () => (
  <div className="flex justify-between flex-wrap gap-4">
    <div className="p-6 border border-border-primary rounded-lg flex-1 animate-pulse">
      <div className="flex items-center gap-2">
        <div className="w-12 h-12 bg-gray-200 rounded-lg" />
        <div>
          <div className="h-6 w-12 bg-gray-200 rounded mb-1" />
          <div className="h-4 w-20 bg-gray-200 rounded" />
        </div>
      </div>
    </div>
    <div className="p-6 border border-border-primary rounded-lg flex-1 animate-pulse">
      <div className="flex items-center gap-2">
        <div className="w-12 h-12 bg-gray-200 rounded-lg" />
        <div>
          <div className="h-6 w-12 bg-gray-200 rounded mb-1" />
          <div className="h-4 w-28 bg-gray-200 rounded" />
        </div>
      </div>
    </div>
  </div>
);

const KpiError = ({ message }: { message: string }) => (
  <div className="flex justify-between flex-wrap gap-4">
    <div className="p-6 border border-red-200 bg-red-50 rounded-lg flex-1">
      <div className="flex items-center gap-2">
        <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
          <span className="text-red-500 text-xl">!</span>
        </div>
        <div>
          <div className="text-sm font-medium text-red-800">Failed to load KPIs</div>
          <div className="text-xs text-red-600">{message}</div>
        </div>
      </div>
    </div>
  </div>
);

const FileIcon = () => (
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="10" fill="#EEEDFE" />
    <path
      d="M26 14H18C17.4696 14 16.9609 14.2107 16.5858 14.5858C16.2107 14.9609 16 15.4696 16 16V32C16 32.5304 16.2107 33.0391 16.5858 33.4142C16.9609 33.7893 17.4696 34 18 34H30C30.5304 34 31.0391 33.7893 31.4142 33.4142C31.7893 33.0391 32 32.5304 32 32V20L26 14Z"
      stroke="#461E96"
      strokeWidth="2"
    />
    <path d="M26 14V20H32" stroke="#461E96" strokeWidth="2" />
    <path d="M28 25H20" stroke="#461E96" strokeWidth="2" />
    <path d="M28 29H20" stroke="#461E96" strokeWidth="2" />
    <path d="M22 21H21H20" stroke="#461E96" strokeWidth="2" />
  </svg>
);

const ListIcon = () => (
  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="48" height="48" rx="10" fill="#E7F7FF" />
    <path
      d="M20.25 18C20.25 17.8011 20.329 17.6103 20.4697 17.4697C20.6103 17.329 20.8011 17.25 21 17.25H32.25C32.4489 17.25 32.6397 17.329 32.7803 17.4697C32.921 17.6103 33 17.8011 33 18C33 18.1989 32.921 18.3897 32.7803 18.5303C32.6397 18.671 32.4489 18.75 32.25 18.75H21C20.8011 18.75 20.6103 18.671 20.4697 18.5303C20.329 18.3897 20.25 18.1989 20.25 18ZM32.25 23.25H21C20.8011 23.25 20.6103 23.329 20.4697 23.4697C20.329 23.6103 20.25 23.8011 20.25 24C20.25 24.1989 20.329 24.3897 20.4697 24.5303C20.6103 24.671 20.8011 24.75 21 24.75H32.25C32.4489 24.75 32.6397 24.671 32.7803 24.5303C32.921 24.3897 33 24.1989 33 24C33 23.8011 32.921 23.6103 32.7803 23.4697C32.6397 23.329 32.4489 23.25 32.25 23.25ZM32.25 29.25H21C20.8011 29.25 20.6103 29.329 20.4697 29.4697C20.329 29.6103 20.25 29.8011 20.25 30C20.25 30.1989 20.329 30.3897 20.4697 30.5303C20.6103 30.671 20.8011 30.75 21 30.75H32.25C32.4489 30.75 32.6397 30.671 32.7803 30.5303C32.921 30.3897 33 30.1989 33 30C33 29.8011 32.921 29.6103 32.7803 29.4697C32.6397 29.329 32.4489 29.25 32.25 29.25ZM17.25 17.25H15.75C15.5511 17.25 15.3603 17.329 15.2197 17.4697C15.079 17.6103 15 17.8011 15 18C15 18.1989 15.079 18.3897 15.2197 18.5303C15.3603 18.671 15.5511 18.75 15.75 18.75H17.25C17.4489 18.75 17.6397 18.671 17.7803 18.5303C17.921 18.3897 18 18.1989 18 18C18 17.8011 17.921 17.6103 17.7803 17.4697C17.6397 17.329 17.4489 17.25 17.25 17.25ZM17.25 23.25H15.75C15.5511 23.25 15.3603 23.329 15.2197 23.4697C15.079 23.6103 15 23.8011 15 24C15 24.1989 15.079 24.3897 15.2197 24.5303C15.3603 24.671 15.5511 24.75 15.75 24.75H17.25C17.4489 24.75 17.6397 24.671 17.7803 24.5303C17.921 24.3897 18 24.1989 18 24C18 23.8011 17.921 23.6103 17.7803 23.4697C17.6397 23.329 17.4489 23.25 17.25 23.25ZM17.25 29.25H15.75C15.5511 29.25 15.3603 29.329 15.2197 29.4697C15.079 29.6103 15 29.8011 15 30C15 30.1989 15.079 30.3897 15.2197 30.5303C15.3603 30.671 15.5511 30.75 15.75 30.75H17.25C17.4489 30.75 17.6397 30.671 17.7803 30.5303C17.921 30.3897 18 30.1989 18 30C18 29.8011 17.921 29.6103 17.7803 29.4697C17.6397 29.329 17.4489 29.25 17.25 29.25Z"
      fill="#043E67"
    />
  </svg>
);

const CustomListKpis = () => {
  const { data, isLoading, isError, error } = useCustomListKpis();

  if (isLoading) return <KpiSkeleton />;
  if (isError) return <KpiError message={error?.message ?? "An unexpected error occurred"} />;
  if (!data) return null;

  return (
    <div className="flex justify-between flex-wrap gap-4">
      <div className="p-6 border border-border-primary rounded-lg flex-1">
        <div className="flex items-center gap-2">
          <FileIcon />
          <div>
            <div className="text-xl font-bold">{data.active_lists}</div>
            <div className="text-sm text-text-secondary">Active Lists</div>
          </div>
        </div>
      </div>
      <div className="p-6 border border-border-primary rounded-lg flex-1">
        <div className="flex items-center gap-2">
          <ListIcon />
          <div>
            <div className="text-xl font-bold">{data.total_items_tracked}</div>
            <div className="text-sm text-text-secondary">Products Tracked</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomListKpis;
