import { lookupService } from "@/lib/apiServices";
import { keepPreviousData, queryOptions } from "@tanstack/react-query";

export const materialListQueryKeys = {
    all: ["materialList"] as const,
    paginated: (page: number, pageSize: number, search?: string) =>
        ["materialList", page, pageSize, search ?? ""] as const,
} as const;

export interface MaterialData {
    id: number;
    name: string;
    mat_nbr: string;
    ndc: string;
    category?: string;
    xplant_mat_stat?: string;
    status?: string;
    scrm_mat_grp?: string;
    vendor?: string;
    vendor_nbr?: string;
}

export interface MaterialListResponse {
    count: number;
    next: string | null;
    previous: string | null;
    results: MaterialData[];
}

export const materialListQueryOptions = (page: number = 1, pageSize: number = 10, search?: string) =>
    queryOptions({
        queryKey: materialListQueryKeys.paginated(page, pageSize, search),
        queryFn: async () => {
            const offset = (page - 1) * pageSize;
            const response = await lookupService.getMaterials({
                limit: pageSize,
                offset: offset,
                ...(search && { search }),
            });
            return response.data.data as MaterialListResponse;
        },
        placeholderData: keepPreviousData,
    });
