import { customListsService } from "@/lib/apiServices";
import { queryOptions } from "@tanstack/react-query";

export const customListDetailsQueryKeys = {
  all: ["customListDetails"] as const,
  byId: (listId: string) => [customListDetailsQueryKeys.all, listId] as const,
} as const;

export const customListDetailsQueryOptions = (listId: string) =>
  queryOptions({
    queryKey: customListDetailsQueryKeys.byId(listId),
    queryFn: async () => {
      const response = await customListsService.getCustomListDetails(listId);
      return response.data.data;
    },
    enabled: !!listId,
  });
