import { Bell, CircleUserRound, Settings } from "lucide-react";
import type { ReactNode } from "react";
import { type HeaderAction, type HeaderNavigationConfig } from "@/components/organisms/";
import { StratiumHeader } from "@/components/organisms";
import type { NavbarItem, NavbarSelectEvent } from "@/components/molecules/Navbar";

type StratiumDashboardLayoutBaseProps = {
  children: ReactNode;
  headerActions?: readonly HeaderAction[];
  headerActionsContent?: ReactNode;
  primaryAriaCurrent?: HeaderNavigationConfig<NavbarItem>["ariaCurrent"];
  skipLinkLabel?: string;
  skipLinkTargetId?: string;
};

type StratiumDashboardLayoutWithSectionNavigation<TSectionItem extends NavbarItem> = {
  sectionNavigation: HeaderNavigationConfig<TSectionItem>;
};

type StratiumDashboardLayoutWithoutSectionNavigation = {
  sectionNavigation?: never;
};

type PrimaryItems = readonly NavbarItem[];

type PrimaryItemFor<TPrimaryItems extends PrimaryItems> = TPrimaryItems[number];

export type StratiumDashboardLayoutProps<
  TSectionItem extends NavbarItem = NavbarItem,
  TPrimaryItems extends PrimaryItems = PrimaryItems,
> = StratiumDashboardLayoutBaseProps &
  (StratiumDashboardLayoutWithSectionNavigation<TSectionItem> | StratiumDashboardLayoutWithoutSectionNavigation) & {
    activePrimaryId: PrimaryItemFor<TPrimaryItems>["id"];
    onPrimaryIntent?: HeaderNavigationConfig<PrimaryItemFor<TPrimaryItems>>["onIntent"];
    onPrimarySelect?: (item: PrimaryItemFor<TPrimaryItems>, event: NavbarSelectEvent) => void;
    primaryItems: TPrimaryItems;
  };

const headerActions = [
  {
    id: "notifications",
    label: "Notifications",
    icon: Bell,
    disabled: true,
  },
  {
    id: "settings",
    label: "Settings",
    icon: Settings,
    disabled: true,
  },
  {
    id: "profile",
    label: "Profile",
    icon: CircleUserRound,
    disabled: true,
  },
] satisfies readonly HeaderAction[];

export function StratiumDashboardLayout<
  TSectionItem extends NavbarItem = NavbarItem,
  TPrimaryItems extends PrimaryItems = PrimaryItems,
>(props: StratiumDashboardLayoutProps<TSectionItem, TPrimaryItems>) {
  const handlePrimarySelect = (item: PrimaryItemFor<TPrimaryItems>, event: NavbarSelectEvent) => {
    props.onPrimarySelect?.(item, event);
  };
  const primaryNavigation = {
    items: props.primaryItems,
    activeId: props.activePrimaryId,
    ariaLabel: "Primary navigation",
    ariaCurrent: props.primaryAriaCurrent ?? "page",
    onIntent: props.onPrimaryIntent,
    onSelect: handlePrimarySelect,
  } satisfies HeaderNavigationConfig<PrimaryItemFor<TPrimaryItems>>;
  const resolvedHeaderActions = props.headerActions ?? headerActions;

  return (
    <div className="min-h-screen bg-ui-background-secondary">
      {props.skipLinkTargetId ? (
        <a
          href={`#${props.skipLinkTargetId}`}
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-10000 focus:rounded-md focus:bg-white focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-brand-primary-main focus:shadow-lg"
        >
          {props.skipLinkLabel ?? "Skip to main content"}
        </a>
      ) : null}
      {props.sectionNavigation ? (
        <StratiumHeader
          primaryNavigation={primaryNavigation}
          sectionNavigation={props.sectionNavigation}
          sectionParentId={props.activePrimaryId}
          actions={resolvedHeaderActions}
          actionsContent={props.headerActionsContent}
          className="sticky top-0 z-20"
        />
      ) : (
        <StratiumHeader
          primaryNavigation={primaryNavigation}
          actions={resolvedHeaderActions}
          actionsContent={props.headerActionsContent}
          className="sticky top-0 z-20"
        />
      )}

      {props.children}
    </div>
  );
}
