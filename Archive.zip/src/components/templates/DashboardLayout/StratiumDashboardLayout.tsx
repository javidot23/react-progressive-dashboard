import { Bell, CircleUserRound, Settings } from "lucide-react";
import type { ReactNode } from "react";
import { type HeaderAction, type HeaderNavigationConfig } from "@/components/organisms/";
import { StratiumHeader } from "@/components/organisms";
import type { NavbarItem, NavbarSelectEvent } from "@/components/molecules/Navbar";

type StratiumDashboardLayoutBaseProps<TSectionItem extends NavbarItem> = {
  children: ReactNode;
  sectionNavigation: HeaderNavigationConfig<TSectionItem>;
};

type PrimaryItems = readonly NavbarItem[];

type PrimaryItemFor<TPrimaryItems extends PrimaryItems> = TPrimaryItems[number];

export type StratiumDashboardLayoutProps<
  TSectionItem extends NavbarItem = NavbarItem,
  TPrimaryItems extends PrimaryItems = PrimaryItems,
> = StratiumDashboardLayoutBaseProps<TSectionItem> & {
  activePrimaryId: PrimaryItemFor<TPrimaryItems>["id"];
  onPrimarySelect?: (item: PrimaryItemFor<TPrimaryItems>, event: NavbarSelectEvent) => void;
  primaryItems: TPrimaryItems;
};

const headerActions = [
  {
    id: "notifications",
    label: "Notifications",
    icon: Bell,
    disabled: true,
  },
  {
    id: "settings",
    label: "Settings",
    icon: Settings,
    disabled: true,
  },
  {
    id: "profile",
    label: "Profile",
    icon: CircleUserRound,
    disabled: true,
  },
] satisfies readonly HeaderAction[];

export function StratiumDashboardLayout<
  TSectionItem extends NavbarItem = NavbarItem,
  TPrimaryItems extends PrimaryItems = PrimaryItems,
>(props: StratiumDashboardLayoutProps<TSectionItem, TPrimaryItems>) {
  const handlePrimarySelect = (item: PrimaryItemFor<TPrimaryItems>, event: NavbarSelectEvent) => {
    props.onPrimarySelect?.(item, event);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <StratiumHeader
        primaryNavigation={{
          items: props.primaryItems,
          activeId: props.activePrimaryId,
          ariaLabel: "Primary navigation",
          ariaCurrent: "page",
          onSelect: handlePrimarySelect,
        }}
        sectionNavigation={props.sectionNavigation}
        sectionParentId={props.activePrimaryId}
        actions={headerActions}
        className="sticky top-0 z-20"
      />

      {props.children}
    </div>
  );
}
