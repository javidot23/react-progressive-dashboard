import type { Meta, StoryObj } from "@storybook/react";
import { expect, fn, userEvent, waitFor, within } from "@storybook/test";
import {
  Component,
  Suspense,
  lazy,
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ComponentType,
  type ErrorInfo,
  type ReactNode,
  type RefCallback,
  type RefObject,
} from "react";
import { Link, Navigate, Route, Routes, useLocation, useNavigate } from "react-router";
import type { HeaderNavigationConfig } from "@/components/organisms";
import { isUnmodifiedPrimaryClick, type NavbarItem, type NavbarSelectEvent } from "@/components/molecules/Navbar";
import { dashboardPrimaryItems, type DashboardPrimaryItem } from "./dashboardNavigation";
import { StratiumDashboardLayout } from "./StratiumDashboardLayout";

const embeddedDashboardPreview =
  typeof window !== "undefined" && new URLSearchParams(window.location.search).get("embed") === "true";

const manageSectionIds = ["summary", "demand", "orders", "suppliers", "inventory", "sales", "perfect-order"] as const;

type ManageSectionId = (typeof manageSectionIds)[number];
type StorySectionModule = { default: ComponentType };
type StorySectionImporter = () => Promise<StorySectionModule>;
type StoryMotionMode = "system" | "animated" | "reduced";

type ManageSectionDefinition = {
  id: ManageSectionId;
  label: string;
  placeholderMinHeight: number;
  load: () => Promise<StorySectionModule>;
  Component: ReturnType<typeof lazy>;
};

type ProgrammaticNavigation = {
  behavior: ScrollBehavior;
  targetId: ManageSectionId;
  transactionId: number;
};

const sectionIdSet = new Set<ManageSectionId>(manageSectionIds);
const defaultStoryLoadDelayMs = 280;
const maximumStoryLoadDelayMs = 2_000;
const scrollAlignmentTolerance = 4;
const scrollIdleDelayMs = 180;
const scrollSettleDelayMs = 80;
const storyRouterCommandEvent = "stratium-dashboard-story:router-command";

const storySectionConfigs = [
  {
    id: "summary",
    label: "Summary",
    placeholderMinHeight: 820,
    importer: () => import("./__fixtures__/story-sections/SummaryStorySection"),
  },
  {
    id: "demand",
    label: "Demand",
    placeholderMinHeight: 900,
    importer: () => import("./__fixtures__/story-sections/DemandStorySection"),
  },
  {
    id: "orders",
    label: "Orders",
    placeholderMinHeight: 900,
    importer: () => import("./__fixtures__/story-sections/OrdersStorySection"),
  },
  {
    id: "suppliers",
    label: "Suppliers",
    placeholderMinHeight: 900,
    importer: () => import("./__fixtures__/story-sections/SuppliersStorySection"),
  },
  {
    id: "inventory",
    label: "Inventory",
    placeholderMinHeight: 900,
    importer: () => import("./__fixtures__/story-sections/InventoryStorySection"),
  },
  {
    id: "sales",
    label: "Sales",
    placeholderMinHeight: 900,
    importer: () => import("./__fixtures__/story-sections/SalesStorySection"),
  },
  {
    id: "perfect-order",
    label: "Perfect Order",
    placeholderMinHeight: 900,
    importer: () => import("./__fixtures__/story-sections/PerfectOrderStorySection"),
  },
] satisfies readonly {
  id: ManageSectionId;
  label: string;
  placeholderMinHeight: number;
  importer: StorySectionImporter;
}[];

const previewSectionItems = [
  {
    id: "under-construction",
    label: "Under Construction",
    to: "/#under-construction",
  },
] satisfies readonly NavbarItem[];

type DefaultDashboardLayoutStoryProps = {
  activePrimaryId: DashboardPrimaryItem["id"];
  children: ReactNode;
  onPrimaryIntent?: HeaderNavigationConfig<DashboardPrimaryItem>["onIntent"];
  onPrimarySelect?: (item: DashboardPrimaryItem, event: NavbarSelectEvent) => void;
  primaryAriaCurrent?: HeaderNavigationConfig<NavbarItem>["ariaCurrent"];
  primaryItems: typeof dashboardPrimaryItems;
  sectionNavigation: HeaderNavigationConfig<(typeof previewSectionItems)[number]>;
};

type InteractiveDashboardStoryArgs = {
  initialPrimaryId: DashboardPrimaryItem["id"];
  initialManageSectionId: ManageSectionId;
  lazyDelayMs: number;
  motionMode: StoryMotionMode;
  runPlay: boolean;
  showSectionNavigation: boolean;
};

type DashboardLayoutStoryArgs = DefaultDashboardLayoutStoryProps & InteractiveDashboardStoryArgs;

const viewports = {
  mobile320: {
    name: "Mobile 320",
    styles: {
      width: "320px",
      height: "800px",
    },
  },
  tablet768: {
    name: "Tablet 768",
    styles: {
      width: "768px",
      height: "900px",
    },
  },
  desktop1440: {
    name: "Desktop 1440",
    styles: {
      width: "1440px",
      height: "900px",
    },
  },
};

function normalizeStoryLoadDelay(delayMs: number) {
  if (!Number.isFinite(delayMs)) {
    return defaultStoryLoadDelayMs;
  }

  return Math.min(maximumStoryLoadDelayMs, Math.max(0, delayMs));
}

function waitForMinimumStoryDelay(startedAt: number, minimumDelayMs: number) {
  const elapsed = performance.now() - startedAt;
  const remaining = Math.max(0, minimumDelayMs - elapsed);

  return new Promise<void>(resolve => {
    window.setTimeout(resolve, remaining);
  });
}

function createMemoizedLoader(importer: StorySectionImporter, minimumDelayMs: number): () => Promise<StorySectionModule> {
  let loadPromise: Promise<StorySectionModule> | undefined;

  return () => {
    if (!loadPromise) {
      const startedAt = performance.now();
      loadPromise = importer().then(async sectionModule => {
        await waitForMinimumStoryDelay(startedAt, minimumDelayMs);
        return sectionModule;
      });
    }

    return loadPromise;
  };
}

function createManageSectionDefinitions(minimumDelayMs: number): ManageSectionDefinition[] {
  return storySectionConfigs.map(config => {
    const load = createMemoizedLoader(config.importer, minimumDelayMs);

    return {
      id: config.id,
      label: config.label,
      placeholderMinHeight: config.placeholderMinHeight,
      load,
      Component: lazy(load),
    };
  });
}

function getInitialStoryEntry(initialPrimaryId: DashboardPrimaryItem["id"], initialManageSectionId: ManageSectionId) {
  switch (initialPrimaryId) {
    case "overview":
      return "/#under-construction";
    case "react":
      return "/react#under-construction";
    case "plan":
      return "/plan#under-construction";
    case "manage":
      return `/manage#${initialManageSectionId}`;
  }
}

function prefersReducedStoryMotion(motionMode: StoryMotionMode) {
  if (motionMode === "reduced") {
    return true;
  }
  if (motionMode === "animated") {
    return false;
  }

  return typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function getManageSectionFromHash(hash: string): {
  id: ManageSectionId;
  valid: boolean;
} {
  if (!hash) {
    return { id: "summary", valid: false };
  }

  try {
    const decoded = decodeURIComponent(hash.replace(/^#/, ""));
    const id = decoded as ManageSectionId;
    return sectionIdSet.has(id) ? { id, valid: true } : { id: "summary", valid: false };
  } catch {
    return { id: "summary", valid: false };
  }
}

function getExpectedSectionScrollTop(scrollContainer: HTMLElement, node: HTMLElement) {
  const containerTop = scrollContainer.getBoundingClientRect().top;
  const targetTop = node.getBoundingClientRect().top - containerTop + scrollContainer.scrollTop;
  const scrollMarginTop = Number.parseFloat(window.getComputedStyle(node).scrollMarginTop) || 0;
  const maximumScrollTop = Math.max(0, scrollContainer.scrollHeight - scrollContainer.clientHeight);

  return Math.min(Math.max(0, targetTop - scrollMarginTop), maximumScrollTop);
}

function isSectionAligned(scrollContainer: HTMLElement, node: HTMLElement) {
  return Math.abs(scrollContainer.scrollTop - getExpectedSectionScrollTop(scrollContainer, node)) <= scrollAlignmentTolerance;
}

const scrollIntentKeys = new Set(["ArrowDown", "ArrowUp", "End", "Home", "PageDown", "PageUp"]);

function isEditableTarget(target: EventTarget | null) {
  return (
    target instanceof Element &&
    Boolean(target.closest('input, textarea, select, [contenteditable]:not([contenteditable="false"])'))
  );
}

function isKeyboardScrollIntent(event: KeyboardEvent) {
  if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey || isEditableTarget(event.target)) {
    return false;
  }

  const buttonActivatedWithSpace =
    (event.key === " " || event.code === "Space") &&
    event.target instanceof Element &&
    event.target.closest('button, [role="button"]') !== null;

  return !buttonActivatedWithSpace && (scrollIntentKeys.has(event.key) || event.key === " " || event.code === "Space");
}

function LocationProbe() {
  const location = useLocation();

  return (
    <output data-testid="story-location" className="sr-only" aria-live="polite">
      {location.pathname}
      {location.hash}
    </output>
  );
}

function StoryRouterCommandBridge() {
  const navigate = useNavigate();

  useEffect(() => {
    const handleRouterCommand = (event: Event) => {
      const detail = (event as CustomEvent<unknown>).detail;

      if (typeof detail === "number") {
        navigate(detail);
      } else if (typeof detail === "string") {
        navigate(detail);
      }
    };

    window.addEventListener(storyRouterCommandEvent, handleRouterCommand);
    return () => window.removeEventListener(storyRouterCommandEvent, handleRouterCommand);
  }, [navigate]);

  return null;
}

function useRouteHeading(viewName: string) {
  const headingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    document.title = `${viewName} – Stratium DashboardLayout story`;
    headingRef.current?.focus({ preventScroll: true });
  }, [viewName]);

  return headingRef;
}

function UnderConstructionSection() {
  return (
    <section id="under-construction" aria-labelledby="under-construction-heading" className="scroll-mt-[104px] px-6 py-12">
      <div className="mx-auto max-w-6xl">
        <h2 id="under-construction-heading" className="text-3xl font-bold text-slate-950">
          Under Construction
        </h2>
        <p className="mt-2 text-slate-600">
          This story-only route shows how a page supplies controlled section navigation without importing a production page.
        </p>
        <div className="mt-6 h-[760px] rounded-xl border border-slate-200 bg-white shadow-sm" />
      </div>
    </section>
  );
}

function UnderConstructionPage({
  activePrimaryId,
  path,
  title,
}: {
  activePrimaryId: "overview" | "react" | "plan";
  path: "/" | "/react" | "/plan";
  title: "Overview" | "React" | "Plan";
}) {
  const routeHeadingRef = useRouteHeading(title);
  const sectionItems = [
    {
      id: "under-construction",
      label: "Under Construction",
      to: `${path}#under-construction`,
    },
  ] satisfies readonly NavbarItem[];

  return (
    <StratiumDashboardLayout
      activePrimaryId={activePrimaryId}
      primaryItems={dashboardPrimaryItems}
      sectionNavigation={{
        items: sectionItems,
        activeId: "under-construction",
        ariaLabel: `${title} sections`,
        ariaCurrent: "location",
        onSelect: () => undefined,
      }}
    >
      <main tabIndex={0} className="h-[calc(100vh-104px)] overflow-x-hidden overflow-y-auto overscroll-contain">
        <h1 ref={routeHeadingRef} tabIndex={-1} className="sr-only">
          {title}
        </h1>
        <UnderConstructionSection />
      </main>
    </StratiumDashboardLayout>
  );
}

class SectionErrorBoundary extends Component<{ children: ReactNode; label: string }, { failed: boolean }> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("A Storybook dashboard section failed to load.", error, info);
  }

  render() {
    if (this.state.failed) {
      return (
        <div role="alert" className="rounded-xl border border-red-200 bg-red-50 p-6 text-red-900">
          {this.props.label} could not be loaded.
        </div>
      );
    }

    return this.props.children;
  }
}

function SectionSkeleton({ id, label, minHeight }: { id: ManageSectionId; label: string; minHeight: number }) {
  return (
    <div
      data-testid={`section-skeleton-${id}`}
      role="status"
      aria-busy="true"
      aria-label={`Loading ${label}`}
      className="animate-pulse rounded-xl border border-slate-200 bg-white p-6"
      style={{ minHeight }}
    >
      <div className="h-8 w-48 rounded bg-slate-200" />
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <div className="h-32 rounded bg-slate-100" />
        <div className="h-32 rounded bg-slate-100" />
        <div className="h-32 rounded bg-slate-100" />
      </div>
      <span className="sr-only">Loading {label}</span>
    </div>
  );
}

function ProgressiveSection({
  activated,
  activationDisabled,
  definition,
  onActivate,
  scrollRootRef,
  sectionRef,
}: {
  activated: boolean;
  activationDisabled: boolean;
  definition: ManageSectionDefinition;
  onActivate: (id: ManageSectionId) => void;
  scrollRootRef: RefObject<HTMLElement | null>;
  sectionRef: RefCallback<HTMLElement>;
}) {
  const nodeRef = useRef<HTMLElement | null>(null);
  const { Component: LazySection, id, label, load, placeholderMinHeight } = definition;

  const setNode: RefCallback<HTMLElement> = useCallback(
    node => {
      nodeRef.current = node;
      sectionRef(node);
    },
    [sectionRef]
  );

  useEffect(() => {
    const node = nodeRef.current;
    if (activated || activationDisabled || !node || typeof IntersectionObserver === "undefined") {
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          void load().catch(() => undefined);
          onActivate(id);
          observer.disconnect();
        }
      },
      {
        root: scrollRootRef.current,
        rootMargin: "800px 0px",
        threshold: 0,
      }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [activated, activationDisabled, id, load, onActivate, scrollRootRef]);

  return (
    <section
      ref={setNode}
      id={id}
      data-section-id={id}
      data-activated={activated ? "true" : "false"}
      aria-label={label}
      className="px-6 py-12"
      style={{ minHeight: `calc(${placeholderMinHeight}px + 6rem)` }}
    >
      {activated ? (
        <SectionErrorBoundary label={label}>
          <Suspense fallback={<SectionSkeleton id={id} label={label} minHeight={placeholderMinHeight} />}>
            <LazySection />
          </Suspense>
        </SectionErrorBoundary>
      ) : (
        <SectionSkeleton id={id} label={label} minHeight={placeholderMinHeight} />
      )}
    </section>
  );
}

function useManageStoryController(
  definitions: readonly ManageSectionDefinition[],
  scrollContainerRef: RefObject<HTMLElement | null>,
  motionMode: StoryMotionMode
) {
  const location = useLocation();
  const navigate = useNavigate();
  const initialId = getManageSectionFromHash(location.hash).id;
  const [activeId, setActiveId] = useState<ManageSectionId>(initialId);
  const [activatedIds, setActivatedIds] = useState<Set<ManageSectionId>>(() => new Set(["summary", initialId]));
  const [programmaticNavigation, setProgrammaticNavigation] = useState<ProgrammaticNavigation | null>(null);
  const [nodes] = useState(() => new Map<ManageSectionId, HTMLElement>());
  const [registrationVersion, setRegistrationVersion] = useState(0);
  const [sectionRefCallbacks] = useState(() => {
    const callbacks = new Map<ManageSectionId, RefCallback<HTMLElement>>();

    for (const id of manageSectionIds) {
      callbacks.set(id, node => {
        const previousNode = nodes.get(id);

        if (node && previousNode !== node) {
          nodes.set(id, node);
          setRegistrationVersion(version => version + 1);
        } else if (!node && previousNode) {
          nodes.delete(id);
          setRegistrationVersion(version => version + 1);
        }
      });
    }

    return callbacks;
  });
  const sectionById = useMemo(() => new Map(definitions.map(definition => [definition.id, definition])), [definitions]);
  const nextTransactionId = useRef(0);
  const activeTransactionId = useRef<number | null>(null);
  const expectedLocationHash = useRef<string | null>(null);
  const initialLocationHandled = useRef(false);

  const activateSection = useCallback((id: ManageSectionId) => {
    setActivatedIds(current => {
      if (current.has(id)) {
        return current;
      }

      const next = new Set(current);
      next.add(id);
      return next;
    });
  }, []);

  const prepareSection = useCallback(
    (id: ManageSectionId) => {
      void sectionById
        .get(id)
        ?.load()
        .catch(() => undefined);
    },
    [sectionById]
  );

  const preloadNextSection = useCallback(
    (id: ManageSectionId) => {
      const currentIndex = manageSectionIds.indexOf(id);
      const nextId = manageSectionIds[currentIndex + 1];

      if (nextId) {
        prepareSection(nextId);
      }
    },
    [prepareSection]
  );

  const startProgrammaticNavigation = useCallback((targetId: ManageSectionId, behavior: ScrollBehavior) => {
    nextTransactionId.current += 1;
    activeTransactionId.current = nextTransactionId.current;
    setProgrammaticNavigation({
      targetId,
      behavior,
      transactionId: nextTransactionId.current,
    });
  }, []);

  const writeSectionHash = useCallback(
    (id: ManageSectionId, replace: boolean) => {
      const hash = `#${id}`;
      if (location.hash === hash) {
        return;
      }

      expectedLocationHash.current = hash;
      navigate(
        {
          pathname: location.pathname,
          search: location.search,
          hash,
        },
        {
          preventScrollReset: true,
          replace,
        }
      );
    },
    [location.hash, location.pathname, location.search, navigate]
  );

  const navigateToSection = useCallback(
    (id: ManageSectionId, event: NavbarSelectEvent | null, replace = false) => {
      if (event && !isUnmodifiedPrimaryClick(event)) {
        return;
      }

      event?.preventDefault();
      setActiveId(id);
      activateSection(id);
      prepareSection(id);
      writeSectionHash(id, replace);

      const reducedMotion = prefersReducedStoryMotion(motionMode);
      startProgrammaticNavigation(id, reducedMotion ? "auto" : "smooth");
    },
    [activateSection, motionMode, prepareSection, startProgrammaticNavigation, writeSectionHash]
  );

  const handlePrimarySelect = useCallback(
    (item: DashboardPrimaryItem, event: NavbarSelectEvent) => {
      if (item.id === "manage") {
        navigateToSection("summary", event);
      }
    },
    [navigateToSection]
  );

  const getSectionRef = useCallback(
    (id: ManageSectionId) => {
      const callback = sectionRefCallbacks.get(id);
      if (!callback) {
        throw new Error(`Missing story section ref for ${id}.`);
      }
      return callback;
    },
    [sectionRefCallbacks]
  );

  useLayoutEffect(() => {
    const previousScrollRestoration = window.history.scrollRestoration;
    window.history.scrollRestoration = "manual";

    return () => {
      window.history.scrollRestoration = previousScrollRestoration;
    };
  }, []);

  useEffect(() => {
    const parsedHash = getManageSectionFromHash(location.hash);

    if (expectedLocationHash.current !== null && expectedLocationHash.current === location.hash) {
      expectedLocationHash.current = null;
      return;
    }

    if (!parsedHash.valid) {
      activateSection("summary");
      setActiveId("summary");
      expectedLocationHash.current = "#summary";
      navigate(
        {
          pathname: location.pathname,
          search: location.search,
          hash: "#summary",
        },
        { preventScrollReset: true, replace: true }
      );
      startProgrammaticNavigation("summary", "auto");
      initialLocationHandled.current = true;
      return;
    }

    if (!initialLocationHandled.current) {
      initialLocationHandled.current = true;
      setActiveId(parsedHash.id);
      activateSection(parsedHash.id);
      prepareSection(parsedHash.id);
      startProgrammaticNavigation(parsedHash.id, "auto");
      return;
    }

    setActiveId(parsedHash.id);
    activateSection(parsedHash.id);
    prepareSection(parsedHash.id);
    startProgrammaticNavigation(parsedHash.id, "auto");
  }, [
    activateSection,
    location.hash,
    location.key,
    location.pathname,
    location.search,
    navigate,
    prepareSection,
    startProgrammaticNavigation,
  ]);

  useEffect(() => {
    preloadNextSection(activeId);
  }, [activeId, preloadNextSection]);

  useEffect(() => {
    if (!programmaticNavigation) {
      return;
    }

    const { behavior, targetId, transactionId } = programmaticNavigation;
    const targetNode = nodes.get(targetId);
    const scrollContainer = scrollContainerRef.current;
    if (!targetNode || !scrollContainer) {
      return;
    }
    const activeScrollContainer: HTMLElement = scrollContainer;
    const targetIndex = manageSectionIds.indexOf(targetId);
    const observedNodes = manageSectionIds
      .slice(0, targetIndex + 1)
      .map(id => nodes.get(id))
      .filter((node): node is HTMLElement => node !== undefined);

    let cancelled = false;
    let alignmentTimer: number | null = null;
    let initialFrame: number | null = null;
    let resizeObserver: ResizeObserver | null = null;
    let correctionAttempts = 0;

    const clearResources = () => {
      scrollContainer.removeEventListener("scroll", handleScroll);
      scrollContainer.removeEventListener("scrollend", handleScrollEnd);
      scrollContainer.removeEventListener("wheel", handleManualIntent);
      scrollContainer.removeEventListener("touchstart", handleManualIntent);
      document.removeEventListener("keydown", handleKeyDown);
      resizeObserver?.disconnect();
      resizeObserver = null;

      if (alignmentTimer !== null) {
        window.clearTimeout(alignmentTimer);
        alignmentTimer = null;
      }
      if (initialFrame !== null) {
        window.cancelAnimationFrame(initialFrame);
        initialFrame = null;
      }
    };

    const complete = () => {
      if (cancelled || activeTransactionId.current !== transactionId) {
        return;
      }

      cancelled = true;
      clearResources();
      activeTransactionId.current = null;
      setProgrammaticNavigation(current => (current?.transactionId === transactionId ? null : current));
    };

    const cancel = () => {
      if (cancelled) {
        return;
      }

      cancelled = true;
      clearResources();
      if (activeTransactionId.current === transactionId) {
        activeTransactionId.current = null;
      }
      setProgrammaticNavigation(current => (current?.transactionId === transactionId ? null : current));
    };

    const alignOrComplete = () => {
      alignmentTimer = null;
      if (!targetNode.isConnected) {
        cancel();
        return;
      }

      if (isSectionAligned(scrollContainer, targetNode)) {
        complete();
        return;
      }

      if (correctionAttempts >= 3) {
        cancel();
        return;
      }

      correctionAttempts += 1;
      scrollContainer.scrollTo({
        behavior: "auto",
        top: getExpectedSectionScrollTop(scrollContainer, targetNode),
      });

      scheduleAlignmentCheck(scrollSettleDelayMs);
    };

    const scheduleAlignmentCheck = (delay = scrollIdleDelayMs) => {
      if (cancelled) {
        return;
      }
      if (alignmentTimer !== null) {
        window.clearTimeout(alignmentTimer);
      }
      alignmentTimer = window.setTimeout(alignOrComplete, delay);
    };

    function handleScroll() {
      scheduleAlignmentCheck();
    }

    function handleScrollEnd() {
      scheduleAlignmentCheck(scrollSettleDelayMs);
    }

    function handleManualIntent() {
      const currentScrollTop = activeScrollContainer.scrollTop;
      cancel();
      activeScrollContainer.scrollTo({
        behavior: "auto",
        top: currentScrollTop,
      });
    }

    function handleKeyDown(event: KeyboardEvent) {
      if (isKeyboardScrollIntent(event)) {
        handleManualIntent();
      }
    }

    scrollContainer.addEventListener("scroll", handleScroll, { passive: true });
    scrollContainer.addEventListener("scrollend", handleScrollEnd);
    scrollContainer.addEventListener("wheel", handleManualIntent, { passive: true });
    scrollContainer.addEventListener("touchstart", handleManualIntent, {
      passive: true,
    });
    document.addEventListener("keydown", handleKeyDown);

    if (typeof ResizeObserver !== "undefined") {
      resizeObserver = new ResizeObserver(() => {
        correctionAttempts = 0;
        scheduleAlignmentCheck(scrollSettleDelayMs);
      });
      for (const node of observedNodes) {
        resizeObserver.observe(node);
      }
    }

    initialFrame = window.requestAnimationFrame(() => {
      initialFrame = null;
      scrollContainer.scrollTo({
        behavior,
        top: getExpectedSectionScrollTop(scrollContainer, targetNode),
      });
      scheduleAlignmentCheck(behavior === "auto" ? scrollSettleDelayMs : scrollIdleDelayMs);
    });

    return () => {
      cancelled = true;
      clearResources();
    };
  }, [nodes, programmaticNavigation, registrationVersion, scrollContainerRef]);

  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (programmaticNavigation || nodes.size === 0 || !scrollContainer || typeof IntersectionObserver === "undefined") {
      return;
    }

    const entriesById = new Map<ManageSectionId, IntersectionObserverEntry>();
    const idByNode = new Map<HTMLElement, ManageSectionId>();

    for (const id of manageSectionIds) {
      const node = nodes.get(id);
      if (node) {
        idByNode.set(node, id);
      }
    }

    const commitActiveSection = (id: ManageSectionId) => {
      setActiveId(id);
      activateSection(id);
      writeSectionHash(id, true);
    };

    const activateContainerEnd = () => {
      const maximumScrollTop = Math.max(0, scrollContainer.scrollHeight - scrollContainer.clientHeight);

      if (maximumScrollTop > 0 && scrollContainer.scrollTop >= maximumScrollTop - 2) {
        commitActiveSection("perfect-order");
        return true;
      }

      return false;
    };

    const observer = new IntersectionObserver(
      entries => {
        for (const entry of entries) {
          const id = idByNode.get(entry.target as HTMLElement);
          if (id) {
            entriesById.set(id, entry);
          }
        }

        if (activateContainerEnd()) {
          return;
        }

        const scrollContainerTop = scrollContainer.getBoundingClientRect().top;
        const nextId = manageSectionIds
          .map(id => {
            const entry = entriesById.get(id);
            return entry?.isIntersecting ? { id, entry } : undefined;
          })
          .filter(
            (
              candidate
            ): candidate is {
              id: ManageSectionId;
              entry: IntersectionObserverEntry;
            } => Boolean(candidate)
          )
          .sort(
            (left, right) =>
              Math.abs(left.entry.boundingClientRect.top - scrollContainerTop) -
              Math.abs(right.entry.boundingClientRect.top - scrollContainerTop)
          )[0]?.id;

        if (nextId) {
          commitActiveSection(nextId);
        }
      },
      {
        root: scrollContainer,
        rootMargin: "0px 0px -60% 0px",
        threshold: [0, 0.01, 0.25, 0.5, 0.75],
      }
    );

    for (const node of idByNode.keys()) {
      observer.observe(node);
    }
    scrollContainer.addEventListener("scroll", activateContainerEnd, {
      passive: true,
    });

    return () => {
      observer.disconnect();
      scrollContainer.removeEventListener("scroll", activateContainerEnd);
    };
  }, [activateSection, nodes, programmaticNavigation, registrationVersion, scrollContainerRef, writeSectionHash]);

  return {
    activeId,
    activatedIds,
    getSectionRef,
    handlePrimarySelect,
    navigateToSection,
    prepareSection,
    programmaticNavigation,
    activateSection,
  };
}

function ManageStoryPage({
  definitions,
  motionMode,
  showSectionNavigation,
}: {
  definitions: readonly ManageSectionDefinition[];
  motionMode: StoryMotionMode;
  showSectionNavigation: boolean;
}) {
  const routeHeadingRef = useRouteHeading("Manage");
  const scrollContainerRef = useRef<HTMLElement | null>(null);
  const controller = useManageStoryController(definitions, scrollContainerRef, motionMode);
  const sectionNavigationItems = useMemo(
    () =>
      definitions.map(({ id, label }) => ({
        id,
        label,
        to: `/manage#${id}`,
      })),
    [definitions]
  );

  const content = (
    <main
      ref={scrollContainerRef}
      tabIndex={0}
      data-testid="manage-story-content"
      data-programmatic-target={controller.programmaticNavigation?.targetId}
      className={`w-full overflow-x-hidden overflow-y-auto overscroll-contain ${
        showSectionNavigation ? "h-[calc(100vh-104px)]" : "h-[calc(100vh-64px)]"
      }`}
    >
      <div className="mx-auto max-w-6xl">
        <h1 ref={routeHeadingRef} tabIndex={-1} className="sr-only">
          Manage
        </h1>
        {definitions.map(definition => (
          <ProgressiveSection
            key={definition.id}
            activated={controller.activatedIds.has(definition.id)}
            activationDisabled={controller.programmaticNavigation !== null}
            definition={definition}
            onActivate={controller.activateSection}
            scrollRootRef={scrollContainerRef}
            sectionRef={controller.getSectionRef(definition.id)}
          />
        ))}
      </div>
    </main>
  );

  if (!showSectionNavigation) {
    return (
      <StratiumDashboardLayout
        activePrimaryId={controller.activeId}
        onPrimaryIntent={item => controller.prepareSection(item.id)}
        onPrimarySelect={(item, event) => controller.navigateToSection(item.id, event)}
        primaryAriaCurrent="location"
        primaryItems={sectionNavigationItems}
      >
        {content}
      </StratiumDashboardLayout>
    );
  }

  return (
    <StratiumDashboardLayout
      activePrimaryId="manage"
      onPrimarySelect={controller.handlePrimarySelect}
      primaryItems={dashboardPrimaryItems}
      sectionNavigation={{
        items: sectionNavigationItems,
        activeId: controller.activeId,
        ariaLabel: "Manage sections",
        ariaCurrent: "location",
        onIntent: item => controller.prepareSection(item.id),
        onSelect: (item, event) => controller.navigateToSection(item.id, event),
      }}
    >
      {content}
    </StratiumDashboardLayout>
  );
}

function NotFoundPage() {
  const routeHeadingRef = useRouteHeading("Not found");

  return (
    <main className="mx-auto max-w-4xl px-6 py-16">
      <h1 ref={routeHeadingRef} tabIndex={-1} className="text-4xl font-bold text-slate-950">
        Not found
      </h1>
      <Link to="/" className="mt-6 inline-block font-semibold text-brand-primary-main">
        Return to Overview
      </Link>
    </main>
  );
}

function StoryRouteInitializer({ initialEntry, onReady }: { initialEntry: string; onReady: () => void }) {
  const location = useLocation();
  const currentEntry = `${location.pathname}${location.hash}`;
  const matchesInitialEntry = currentEntry === initialEntry;

  useLayoutEffect(() => {
    if (matchesInitialEntry) {
      onReady();
    }
  }, [matchesInitialEntry, onReady]);

  return matchesInitialEntry ? null : <Navigate to={initialEntry} replace />;
}

function RoutedDashboardStory({
  initialEntry,
  lazyDelayMs,
  motionMode,
  showSectionNavigation,
}: {
  initialEntry: string;
  lazyDelayMs: number;
  motionMode: StoryMotionMode;
  showSectionNavigation: boolean;
}) {
  const [routeReady, setRouteReady] = useState(false);
  const definitions = useMemo(() => createManageSectionDefinitions(lazyDelayMs), [lazyDelayMs]);
  const markRouteReady = useCallback(() => setRouteReady(true), []);

  useLayoutEffect(() => {
    if (!embeddedDashboardPreview) {
      return;
    }

    const docsWindow = window.frameElement?.ownerDocument.defaultView;
    if (!docsWindow) {
      return;
    }

    let frameId: number | undefined;
    let remainingFrames = 4;
    const resetDocsScroll = () => {
      docsWindow.scrollTo({ top: 0, left: 0, behavior: "auto" });
      remainingFrames -= 1;

      if (remainingFrames > 0) {
        frameId = docsWindow.requestAnimationFrame(resetDocsScroll);
      }
    };

    frameId = docsWindow.requestAnimationFrame(resetDocsScroll);

    return () => {
      if (frameId !== undefined) {
        docsWindow.cancelAnimationFrame(frameId);
      }
    };
  }, []);

  return (
    <>
      <LocationProbe />
      <span
        data-testid="story-configuration"
        data-initial-entry={initialEntry}
        data-lazy-delay-ms={lazyDelayMs}
        data-motion-mode={motionMode}
        data-show-section-navigation={showSectionNavigation}
        hidden
      />
      {!embeddedDashboardPreview ? <StoryRouterCommandBridge /> : null}
      {routeReady ? (
        showSectionNavigation ? (
          <Routes>
            <Route index element={<UnderConstructionPage activePrimaryId="overview" path="/" title="Overview" />} />
            <Route path="react" element={<UnderConstructionPage activePrimaryId="react" path="/react" title="React" />} />
            <Route path="plan" element={<UnderConstructionPage activePrimaryId="plan" path="/plan" title="Plan" />} />
            <Route
              path="manage"
              element={<ManageStoryPage definitions={definitions} motionMode={motionMode} showSectionNavigation={true} />}
            />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        ) : (
          <Routes>
            <Route
              path="manage"
              element={<ManageStoryPage definitions={definitions} motionMode={motionMode} showSectionNavigation={false} />}
            />
            <Route path="*" element={<Navigate to={initialEntry} replace />} />
          </Routes>
        )
      ) : (
        <StoryRouteInitializer initialEntry={initialEntry} onReady={markRouteReady} />
      )}
    </>
  );
}

async function expectDisabledActions(canvas: ReturnType<typeof within>) {
  for (const label of ["Notifications", "Settings", "Profile"]) {
    await expect(canvas.getByRole("button", { name: label })).toBeDisabled();
    await expect(canvas.queryByRole("link", { name: label })).not.toBeInTheDocument();
  }
}

const meta = {
  title: "Templates/StratiumDashboardLayout",
  component: StratiumDashboardLayout,
  parameters: {
    a11y: {
      test: "error",
    },
    layout: "fullscreen",
    viewport: {
      viewports,
    },
  },
  decorators: [
    Story => (
      <div className="dashboard-layout-story h-screen overflow-hidden">
        <style>{"html, body, #storybook-root { height: 100%; overflow: hidden !important; }"}</style>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    activePrimaryId: {
      control: false,
      description: "Controlled primary destination rendered as current in Header. Its accepted IDs come from primaryItems.",
    },
    primaryItems: {
      control: false,
      description: "Required primary navigation collection supplied by the consumer.",
    },
    sectionNavigation: {
      control: false,
      description: "Optional controlled secondary items, active ID, accessible label, and callbacks.",
    },
    primaryAriaCurrent: {
      control: false,
      description: 'Optional active-link semantic for primary navigation. Defaults to "page".',
    },
    onPrimarySelect: {
      control: false,
      description: "Optional consumer callback used by Manage to reset an active route to Summary.",
    },
    onPrimaryIntent: {
      control: false,
      description: "Optional consumer callback for primary-link pointer and keyboard intent.",
    },
    children: {
      control: false,
      description: "Page-owned content rendered immediately after the sticky Header.",
    },
  },
  args: {
    activePrimaryId: "overview",
    primaryItems: dashboardPrimaryItems,
    sectionNavigation: {
      items: previewSectionItems,
      activeId: "under-construction",
      ariaLabel: "Overview sections",
      ariaCurrent: "location",
      onSelect: fn(),
    },
    onPrimarySelect: fn(),
    onPrimaryIntent: fn(),
    children: (
      <main className="px-6 py-12">
        <h1>Dashboard layout preview</h1>
      </main>
    ),
  },
} satisfies Meta<DashboardLayoutStoryArgs>;

export default meta;
type Story = StoryObj<DashboardLayoutStoryArgs>;

export const InteractiveDashboard: Story = {
  args: {
    initialPrimaryId: "manage",
    initialManageSectionId: "summary",
    lazyDelayMs: defaultStoryLoadDelayMs,
    motionMode: "system",
    runPlay: false,
    showSectionNavigation: true,
  },
  argTypes: {
    initialPrimaryId: {
      name: "Initial primary module",
      control: "select",
      options: dashboardPrimaryItems.map(item => item.id),
      if: {
        arg: "showSectionNavigation",
        truthy: true,
      },
      description: "Remounts the story at the selected primary route.",
      table: {
        category: "Storybook harness",
      },
    },
    initialManageSectionId: {
      name: "Initial Manage section",
      control: "select",
      options: manageSectionIds,
      description:
        "Remounts Manage at the selected section hash. It is ignored when another initial module uses the two-level Header.",
      table: {
        category: "Storybook harness",
      },
    },
    lazyDelayMs: {
      name: "Lazy loading delay",
      control: {
        type: "range",
        min: 0,
        max: maximumStoryLoadDelayMs,
        step: 40,
      },
      description: "Story-only minimum delay used to make each Suspense fallback observable.",
      table: {
        category: "Storybook harness",
      },
    },
    motionMode: {
      name: "Programmatic scroll motion",
      control: "inline-radio",
      options: ["system", "animated", "reduced"],
      description: "Uses the system preference or explicitly selects animated or reduced motion.",
      table: {
        category: "Storybook harness",
      },
    },
    runPlay: {
      name: "Run play interactions",
      control: "boolean",
      description: "Opt in to the interaction test, then remount or reload the story.",
      table: {
        category: "Storybook harness",
      },
    },
    showSectionNavigation: {
      name: "Show section navigation",
      control: "boolean",
      description:
        "Keeps the default two-level Header when enabled. When disabled, Manage sections become the primary links in a single-row Header.",
      table: {
        category: "Storybook harness",
      },
    },
    activePrimaryId: {
      table: {
        disable: true,
      },
    },
    primaryItems: {
      table: {
        disable: true,
      },
    },
    sectionNavigation: {
      table: {
        disable: true,
      },
    },
    primaryAriaCurrent: {
      table: {
        disable: true,
      },
    },
    onPrimarySelect: {
      table: {
        disable: true,
      },
    },
    onPrimaryIntent: {
      table: {
        disable: true,
      },
    },
    children: {
      table: {
        disable: true,
      },
    },
  },
  render: ({ initialManageSectionId, initialPrimaryId, lazyDelayMs, motionMode, showSectionNavigation }) => {
    const normalizedLazyDelayMs = normalizeStoryLoadDelay(lazyDelayMs);
    const initialEntry = showSectionNavigation
      ? getInitialStoryEntry(initialPrimaryId, initialManageSectionId)
      : `/manage#${initialManageSectionId}`;
    const harnessKey = `${initialEntry}:${normalizedLazyDelayMs}:${motionMode}:${showSectionNavigation}`;

    return (
      <RoutedDashboardStory
        key={harnessKey}
        initialEntry={initialEntry}
        lazyDelayMs={normalizedLazyDelayMs}
        motionMode={motionMode}
        showSectionNavigation={showSectionNavigation}
      />
    );
  },
  parameters: {
    viewport: {
      defaultViewport: "desktop1440",
    },
  },
  play: embeddedDashboardPreview
    ? undefined
    : async ({ args, canvasElement }) => {
        if (!args.runPlay) {
          return;
        }

        const canvas = within(canvasElement);
        const documentElement = canvasElement.ownerDocument.documentElement;
        const storyWindow = canvasElement.ownerDocument.defaultView;
        if (!storyWindow) {
          throw new Error("The Storybook preview window is unavailable.");
        }
        const showSectionNavigation = args.showSectionNavigation;

        const issueRouterCommand = (detail: number | string) => {
          storyWindow.dispatchEvent(
            new storyWindow.CustomEvent(storyRouterCommandEvent, {
              detail,
            })
          );
        };

        await waitFor(() => {
          expect(canvas.getByTestId("story-location")).toBeInTheDocument();
        });
        issueRouterCommand("/manage#summary");
        await waitFor(() => {
          expect(canvas.getByTestId("story-location")).toHaveTextContent("/manage#summary");
        });

        const header = canvas.getByRole("banner");
        await expect(header).toHaveClass("sticky", "top-0", "z-20");
        await expect(canvasElement.ownerDocument.defaultView?.getComputedStyle(header).position).toBe("sticky");
        await expect(canvasElement.ownerDocument.defaultView?.getComputedStyle(header).backgroundColor).toBe(
          "rgb(255, 255, 255)"
        );
        const initialScrollContainer = canvas.getByTestId("manage-story-content");
        const headerRect = header.getBoundingClientRect();
        const initialScrollContainerRect = initialScrollContainer.getBoundingClientRect();
        await expect(Math.abs(initialScrollContainerRect.top - headerRect.bottom)).toBeLessThanOrEqual(1);
        await expect(storyWindow.getComputedStyle(initialScrollContainer).overflowY).toBe("auto");
        await expect(initialScrollContainer.scrollHeight).toBeGreaterThan(initialScrollContainer.clientHeight);
        await expect(initialScrollContainer).toHaveAttribute("tabindex", "0");
        await expect(storyWindow.getComputedStyle(documentElement).overflowY).toBe("hidden");
        await expect(storyWindow.scrollY).toBe(0);
        await expectDisabledActions(canvas);
        await waitFor(
          () => {
            expect(canvas.getByTestId("story-section-content-summary")).toBeInTheDocument();
          },
          { timeout: 4_000 }
        );

        if (showSectionNavigation) {
          for (const [label, destination] of [
            ["Overview", "/#under-construction"],
            ["React", "/react#under-construction"],
            ["Plan", "/plan#under-construction"],
            ["Manage", "/manage#summary"],
          ] as const) {
            const primaryNavigation = canvas.getByRole("navigation", {
              name: "Primary navigation",
            });
            const link = within(primaryNavigation).getByRole("link", {
              name: label,
            });

            await userEvent.click(link);
            await waitFor(() => {
              expect(canvas.getByTestId("story-location")).toHaveTextContent(destination);
            });
            await expect(canvas.getByRole("heading", { level: 1, name: label })).toHaveFocus();
            await expect(
              within(
                canvas.getByRole("navigation", {
                  name: "Primary navigation",
                })
              ).getAllByRole("link", { current: "page" })
            ).toHaveLength(1);
          }
        }

        const sectionNavigation = canvas.getByRole("navigation", {
          name: showSectionNavigation ? "Manage sections" : "Primary navigation",
        });
        if (showSectionNavigation) {
          for (const icon of sectionNavigation.querySelectorAll("svg")) {
            await expect(icon).not.toBeVisible();
          }
        } else {
          await expect(canvas.queryByRole("navigation", { name: "Manage sections" })).not.toBeInTheDocument();
          await expect(within(sectionNavigation).queryAllByRole("link", { current: "page" })).toHaveLength(0);
          await expect(within(sectionNavigation).getAllByRole("link", { current: "location" })).toHaveLength(1);
        }

        const sections = storySectionConfigs.map(({ id, label }) => [id, label] as const);
        const expectObservableSkeleton = normalizeStoryLoadDelay(args.lazyDelayMs) > 0;

        await expect(
          within(sectionNavigation)
            .getAllByRole("link")
            .map(link => link.textContent)
        ).toEqual(sections.map(([, label]) => label));

        const salesSection = canvasElement.querySelector('[data-section-id="sales"]');
        await expect(salesSection).toHaveAttribute("data-activated", "false");
        if (expectObservableSkeleton) {
          await expect(canvas.getByTestId("section-skeleton-sales")).toHaveAttribute("aria-busy", "true");
        }

        const sectionsBySelectionOrder = [
          sections.find(([id]) => id === "sales")!,
          ...sections.filter(([id]) => id !== "summary" && id !== "sales"),
          sections[0],
        ];

        for (const [id, label] of sectionsBySelectionOrder) {
          const link = within(sectionNavigation).getByRole("link", {
            name: label,
          });
          await userEvent.click(link);

          await expect(link).toHaveAttribute("aria-current", "location");
          await expect(
            within(sectionNavigation).getAllByRole("link", {
              current: "location",
            })
          ).toHaveLength(1);

          if (id === "sales" && expectObservableSkeleton) {
            await expect(canvas.getByTestId("section-skeleton-sales")).toHaveAttribute("aria-busy", "true");
          }

          await waitFor(
            () => {
              expect(canvas.getByTestId("story-location")).toHaveTextContent(`/manage#${id}`);
            },
            { timeout: 4_000 }
          );
          await waitFor(
            () => {
              expect(canvas.getByTestId(`story-section-content-${id}`)).toBeInTheDocument();
            },
            { timeout: 4_000 }
          );
        }

        const manageStoryContent = canvas.getByTestId("manage-story-content");
        const demandSectionContent = canvas.getByTestId("story-section-content-demand");
        const demandLoadMoreButton = within(demandSectionContent).getByRole("button", {
          name: "Load more...",
        });
        const demandAdditionalGroups = () => within(demandSectionContent).queryAllByTestId("demand-additional-skeleton-group");

        await expect(demandAdditionalGroups()).toHaveLength(0);
        await expect(canvas.getByTestId("demand-additional-skeleton-count")).toHaveTextContent(
          "0 additional skeleton groups loaded."
        );

        const demandInitialHeight = demandSectionContent.getBoundingClientRect().height;
        await userEvent.click(demandLoadMoreButton);
        await waitFor(() => {
          expect(demandAdditionalGroups()).toHaveLength(1);
          expect(demandSectionContent.getBoundingClientRect().height).toBeGreaterThan(demandInitialHeight);
          expect(canvas.getByTestId("demand-additional-skeleton-count")).toHaveTextContent("1 additional skeleton group loaded.");
        });

        const demandFirstExpandedHeight = demandSectionContent.getBoundingClientRect().height;
        await userEvent.click(demandLoadMoreButton);
        await waitFor(() => {
          expect(demandAdditionalGroups()).toHaveLength(2);
          expect(demandSectionContent.getBoundingClientRect().height).toBeGreaterThan(demandFirstExpandedHeight);
          expect(canvas.getByTestId("demand-additional-skeleton-count")).toHaveTextContent(
            "2 additional skeleton groups loaded."
          );
        });

        const salesLink = within(sectionNavigation).getByRole("link", {
          name: "Sales",
        });
        const immediateStoryMotion =
          args.motionMode === "reduced" ||
          (args.motionMode === "system" && storyWindow.matchMedia("(prefers-reduced-motion: reduce)").matches);

        if (immediateStoryMotion) {
          demandLoadMoreButton.click();
        }

        await userEvent.click(salesLink);
        await expect(salesLink).toHaveAttribute("aria-current", "location");
        await expect(
          within(sectionNavigation).getAllByRole("link", {
            current: "location",
          })
        ).toHaveLength(1);
        await waitFor(() => {
          expect(canvas.getByTestId("story-location")).toHaveTextContent("/manage#sales");
        });

        if (!immediateStoryMotion) {
          await waitFor(() => {
            expect(manageStoryContent).toHaveAttribute("data-programmatic-target", "sales");
          });
          await new Promise<void>(resolve => {
            storyWindow.requestAnimationFrame(() => resolve());
          });
          demandLoadMoreButton.click();
        }

        await waitFor(() => {
          expect(demandAdditionalGroups()).toHaveLength(3);
          expect(salesLink).toHaveAttribute("aria-current", "location");
          expect(
            within(sectionNavigation).getAllByRole("link", {
              current: "location",
            })
          ).toHaveLength(1);
          expect(canvas.getByTestId("story-location")).toHaveTextContent("/manage#sales");
        });

        if (!(salesSection instanceof HTMLElement)) {
          throw new Error("The Sales story section is unavailable.");
        }

        await waitFor(
          () => {
            expect(manageStoryContent).not.toHaveAttribute("data-programmatic-target");
            expect(isSectionAligned(manageStoryContent, salesSection)).toBe(true);
          },
          { timeout: 6_000 }
        );

        const perfectOrderLink = within(sectionNavigation).getByRole("link", {
          name: "Perfect Order",
        });
        await userEvent.click(perfectOrderLink);
        await expect(perfectOrderLink).toHaveAttribute("aria-current", "location");
        await waitFor(() => {
          expect(manageStoryContent).toHaveAttribute("data-programmatic-target", "perfect-order");
        });
        await new Promise<void>(resolve => {
          storyWindow.requestAnimationFrame(() => resolve());
        });

        const manuallySelectedScrollTop = Math.max(0, manageStoryContent.scrollTop - 160);
        manageStoryContent.dispatchEvent(
          new storyWindow.WheelEvent("wheel", {
            bubbles: true,
            deltaY: -160,
          })
        );
        manageStoryContent.scrollTo({ behavior: "auto", top: manuallySelectedScrollTop });
        await waitFor(() => {
          expect(manageStoryContent).not.toHaveAttribute("data-programmatic-target");
        });
        await new Promise(resolve => storyWindow.setTimeout(resolve, scrollIdleDelayMs + scrollSettleDelayMs));
        await expect(Math.abs(manageStoryContent.scrollTop - manuallySelectedScrollTop)).toBeLessThanOrEqual(
          scrollAlignmentTolerance
        );

        const ordersSection = canvasElement.querySelector('[data-section-id="orders"]');
        if (!(ordersSection instanceof HTMLElement)) {
          throw new Error("The Orders story section is unavailable.");
        }

        const originalMatchMedia = storyWindow.matchMedia;
        storyWindow.matchMedia = query => {
          const mediaQuery = originalMatchMedia.call(storyWindow, query);

          if (query !== "(prefers-reduced-motion: reduce)") {
            return mediaQuery;
          }

          return {
            matches: true,
            media: mediaQuery.media,
            onchange: mediaQuery.onchange,
            addListener: mediaQuery.addListener.bind(mediaQuery),
            removeListener: mediaQuery.removeListener.bind(mediaQuery),
            addEventListener: mediaQuery.addEventListener.bind(mediaQuery),
            removeEventListener: mediaQuery.removeEventListener.bind(mediaQuery),
            dispatchEvent: mediaQuery.dispatchEvent.bind(mediaQuery),
          };
        };

        try {
          await userEvent.click(
            within(sectionNavigation).getByRole("link", {
              name: "Orders",
            })
          );
        } finally {
          storyWindow.matchMedia = originalMatchMedia;
        }

        await waitFor(
          () => {
            expect(isSectionAligned(manageStoryContent, ordersSection)).toBe(true);
            expect(canvas.getByTestId("story-location")).toHaveTextContent("/manage#orders");
          },
          { timeout: 4_000 }
        );

        const demandLink = within(sectionNavigation).getByRole("link", {
          name: "Demand",
        });
        const ordersLink = within(sectionNavigation).getByRole("link", {
          name: "Orders",
        });

        await userEvent.click(demandLink);
        await waitFor(() => expect(demandLink).toHaveAttribute("aria-current", "location"), { timeout: 4_000 });
        await userEvent.click(ordersLink);
        await waitFor(() => expect(ordersLink).toHaveAttribute("aria-current", "location"), { timeout: 4_000 });

        issueRouterCommand(-1);
        await waitFor(
          () => {
            expect(canvas.getByTestId("story-location")).toHaveTextContent("/manage#demand");
            expect(demandLink).toHaveAttribute("aria-current", "location");
          },
          { timeout: 4_000 }
        );

        issueRouterCommand(1);
        await waitFor(
          () => {
            expect(canvas.getByTestId("story-location")).toHaveTextContent("/manage#orders");
            expect(ordersLink).toHaveAttribute("aria-current", "location");
          },
          { timeout: 4_000 }
        );

        issueRouterCommand("/manage#%E0%A4%A");
        await waitFor(
          () => {
            expect(canvas.getByTestId("story-location")).toHaveTextContent("/manage#summary");
            expect(
              within(sectionNavigation).getByRole("link", {
                name: "Summary",
              })
            ).toHaveAttribute("aria-current", "location");
          },
          { timeout: 4_000 }
        );

        await userEvent.click(
          within(sectionNavigation).getByRole("link", {
            name: "Sales",
          })
        );
        await waitFor(
          () =>
            expect(
              within(sectionNavigation).getByRole("link", {
                name: "Sales",
              })
            ).toHaveAttribute("aria-current", "location"),
          { timeout: 4_000 }
        );

        await userEvent.click(
          showSectionNavigation
            ? within(
                canvas.getByRole("navigation", {
                  name: "Primary navigation",
                })
              ).getByRole("link", { name: "Manage" })
            : within(sectionNavigation).getByRole("link", { name: "Summary" })
        );
        await waitFor(
          () => {
            expect(canvas.getByTestId("story-location")).toHaveTextContent("/manage#summary");
            expect(
              within(sectionNavigation).getByRole("link", {
                name: "Summary",
              })
            ).toHaveAttribute("aria-current", "location");
          },
          { timeout: 4_000 }
        );
        await expect(storyWindow.getComputedStyle(documentElement).overflowY).toBe("hidden");
        await expect(storyWindow.scrollY).toBe(0);
        await expect(documentElement.scrollWidth).toBeLessThanOrEqual(documentElement.clientWidth);
      },
};
