import type { NavbarItem } from "@/components/molecules/Navbar";

export type StratiumApplicationPrimaryId = "overview" | "react" | "plan" | "manage";

export type StratiumApplicationPrimaryItem = NavbarItem & {
  id: StratiumApplicationPrimaryId;
};

export const stratiumApplicationPrimaryItems = [
  { id: "overview", label: "Overview", to: "/overview" },
  { id: "react", label: "React", to: "/react" },
  { id: "plan", label: "Plan", to: "/plan" },
  { id: "manage", label: "Manage", to: "/manage/summary" },
] as const satisfies readonly StratiumApplicationPrimaryItem[];
