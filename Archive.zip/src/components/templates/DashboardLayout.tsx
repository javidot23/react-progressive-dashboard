import React from "react";
import { Typography } from "@/components/atoms";
import { Footer } from "@/components/atoms/Footer";
import { Header, GreetingBanner } from "@/components/organisms";
import { Banner, BANNER_CONTENT_OVERLAP_CLASS } from "@/components/organisms/Banner";
import { useLocation } from "react-router-dom";
import { ROUTES } from "@/constants/routes";

export interface DashboardLayoutProps {
  children: React.ReactNode;
  pageTitle?: React.ReactNode | string;
  pageSubtitle?: string;
  bannerDescription?: string;
  bannerRightContent?: React.ReactNode;
  className?: string;
  hideBanner?: boolean;
}

const getPageName = (pathname: string): string => {
  const parts = pathname.split("/").filter(Boolean);

  if (parts.length === 0 || parts[0] === "overview") {
    return "Overview";
  }

  if (parts[0] === "react") {
    return "React Module";
  }

  if (parts[0] === "plan") {
    return "Plan Module";
  }

  if (parts[0] === "manage") {
    return "Manage Module";
  }

  return parts[0] ? parts[0].charAt(0).toUpperCase() + parts[0].slice(1) : "Page";
};

export default function DashboardLayout({
  children,
  pageTitle,
  pageSubtitle,
  bannerDescription,
  bannerRightContent,
  className,
  hideBanner = false,
}: DashboardLayoutProps) {
  const path = useLocation().pathname;
  const isOverviewPage = path === ROUTES.OVERVIEW;
  const isDisruptionsMap = path === ROUTES.DISRUPTIONS_MAP;
  const isPlanProductPage = path.startsWith("/plan/vendor/");
  const isMaterialDrillPage = path.startsWith("/react/product/");
  const isIssueDrillPage = path.startsWith("/react/issue/");
  const isWhiteBackground = isDisruptionsMap || isPlanProductPage || isMaterialDrillPage || isIssueDrillPage;
  const shouldShowPageBanner =
    !hideBanner &&
    !isOverviewPage &&
    (path.startsWith(ROUTES.REACT) || path.startsWith(ROUTES.PLAN) || path.startsWith(ROUTES.MANAGE));
  const pageName = shouldShowPageBanner ? getPageName(path) : "";

  const hasBanner = isOverviewPage || shouldShowPageBanner;

  return (
    <div className={`flex min-h-screen flex-col ${isWhiteBackground ? "bg-white" : ""}`}>
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-10000 focus:rounded-md focus:bg-white focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-brand-primary-main focus:shadow-lg"
      >
        Skip to main content
      </a>
      <Header />

      {isOverviewPage && <GreetingBanner rightSideContent={bannerRightContent} description={pageSubtitle} />}
      {shouldShowPageBanner && (
        <Banner
          backgroundClassName="bg-[url('/src/assets/images/banner.svg')]"
          title={pageName}
          description={bannerDescription || pageSubtitle}
          rightSideContent={bannerRightContent}
        />
      )}

      <main
        id="main-content"
        tabIndex={-1}
        className={`relative z-10 w-full max-w-(--breakpoint-2xl) mx-auto flex-1 overflow-x-hidden px-4 pb-8 sm:px-6 lg:px-8 ${hasBanner ? BANNER_CONTENT_OVERLAP_CLASS : ""} ${className ?? ""}`}
      >
        {!hasBanner && (pageTitle || pageSubtitle) && (
          <div className="mb-8 pt-8">
            {pageTitle && (
              <div className="mb-2">
                {typeof pageTitle === "string" ? (
                  <Typography variant="h1" className="text-3xl font-bold text-ui-text-primary">
                    {pageTitle}
                  </Typography>
                ) : (
                  pageTitle
                )}
              </div>
            )}

            {pageSubtitle && (
              <div
                className="text-base font-medium leading-6"
                style={{
                  color: "var(--Cencora-text-secondary, var(--color-text-secondary, #6E6E6E))",
                  fontSize: "var(--text-body-md-font-size, 16px)",
                  fontStyle: "normal",
                  fontWeight: "500",
                  lineHeight: "var(--text-body-md-line-height, 24px)",
                }}
              >
                {pageSubtitle}
              </div>
            )}
          </div>
        )}
        <div className="space-y-4">{children}</div>
      </main>
      <Footer />
    </div>
  );
}
