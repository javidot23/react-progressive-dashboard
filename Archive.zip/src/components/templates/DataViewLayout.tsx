import { InfoIcon, NoDataState, SkeletonTable, useTableSettings } from "@/components/atoms";
import { SkeletonCardGrid } from "@/components/molecules";
import { ReactNode, useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";

const VIEW_MODE = {
  CARD: "card",
  TABLE: "table",
} as const;

interface DataViewLayoutProps<T> {
  title: ReactNode;
  subtitle?: string;
  /** Custom tooltip text shown in the InfoIcon beside the title */
  tooltip?: string;
  data: T[];
  loading?: boolean;
  hasMore?: boolean;
  viewMode?: "card" | "table";
  /** Lock the view to a specific mode — hides the View Settings button */
  lockViewMode?: "card" | "table";
  /** Set to false to hide the View Settings button */
  showViewSettings?: boolean;
  /** Remove the min-height constraint on the container */
  fitContent?: boolean;
  filters?: ReactNode;
  renderCard: (item: T, index: number) => ReactNode;
  renderTable: (data: T[]) => ReactNode;
  onLoadMore?: () => void;
  headerActions?: ReactNode;
  badge?: ReactNode;
  /** Optional error message rendered in place of the data area */
  fetchError?: ReactNode;
  /** Custom title for the empty state */
  emptyTitle?: string;
  /** Custom description for the empty state */
  emptyDescription?: string;
  /** Key extractor for list items (used by some views for stable keys) */
  getItemKey?: (item: any) => string;
}

export default function DataViewLayout<T>({
  title,
  subtitle,
  tooltip,
  data,
  loading,
  hasMore,
  viewMode: controlledViewMode,
  lockViewMode,
  showViewSettings = true,
  fitContent = false,
  filters,
  renderCard,
  renderTable,
  onLoadMore,
  headerActions,
  badge,
  fetchError,
  emptyTitle = "No data found",
  emptyDescription = "Try adjusting your filters or search criteria",
  getItemKey: _getItemKey,
}: DataViewLayoutProps<T>) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [showSettings, setShowSettings] = useState(false);
  const [infiniteScrollLoading, setInfiniteScrollLoading] = useState(false);
  const [isOverflowing, setIsOverflowing] = useState(false);
  const settingsRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const tableSettings = useTableSettings();
  const settings = tableSettings?.settings;
  const updateSettings = tableSettings?.updateSettings;

  const urlViewMode = searchParams.get("view") as "card" | "table" | null;
  const isValidUrlViewMode = urlViewMode === VIEW_MODE.CARD || urlViewMode === VIEW_MODE.TABLE;
  const effectiveViewMode = lockViewMode ?? (isValidUrlViewMode ? urlViewMode : (settings?.viewMode ?? controlledViewMode ?? VIEW_MODE.CARD));
  const canChangeViewMode = !lockViewMode && showViewSettings !== false;

  useEffect(() => {
    if (!isValidUrlViewMode && settings?.viewMode) {
      const newSearchParams = new URLSearchParams(searchParams);
      newSearchParams.set("view", settings.viewMode);
      setSearchParams(newSearchParams, { replace: true });
    }
  }, [settings.viewMode, isValidUrlViewMode, searchParams, setSearchParams]);

  const setViewMode = useCallback(
    (mode: "card" | "table") => {
      const newSearchParams = new URLSearchParams(searchParams);
      newSearchParams.set("view", mode);
      setSearchParams(newSearchParams);
      updateSettings?.({ viewMode: mode });
    },
    [searchParams, setSearchParams, updateSettings]
  );

  useEffect(() => {
    if (infiniteScrollLoading && !loading) {
      setInfiniteScrollLoading(false);
    }
  }, [loading, infiniteScrollLoading]);

  useEffect(() => {
    const container = scrollRef.current;
    if (container) {
      setIsOverflowing(container.scrollHeight > container.clientHeight + 2);
    }
  }, [data, effectiveViewMode]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (settingsRef.current && !settingsRef.current.contains(event.target as Node)) {
        setShowSettings(false);
      }
    }

    if (showSettings) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showSettings]);

  const useScroll = data.length > 4 && effectiveViewMode === "card";

  const handleLoadMore = useCallback(() => {
    if (effectiveViewMode === VIEW_MODE.CARD && onLoadMore && hasMore && !infiniteScrollLoading && !loading) {
      setInfiniteScrollLoading(true);
      onLoadMore();
    }
  }, [effectiveViewMode, onLoadMore, hasMore, infiniteScrollLoading, loading]);

  useEffect(() => {
    if (!useScroll || !scrollRef.current || !hasMore || effectiveViewMode !== VIEW_MODE.CARD) return;
    const container = scrollRef.current;
    let ticking = false;

    const handleScroll = () => {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(() => {
        const { scrollTop, scrollHeight, clientHeight } = container;
        if (scrollHeight - scrollTop - clientHeight < 100 && !infiniteScrollLoading && hasMore) {
          handleLoadMore();
        }
        ticking = false;
      });
    };

    container.addEventListener("scroll", handleScroll);
    return () => {
      container.removeEventListener("scroll", handleScroll);
    };
  }, [useScroll, infiniteScrollLoading, hasMore, effectiveViewMode, handleLoadMore]);

  useEffect(() => {
    if (
      useScroll &&
      scrollRef.current &&
      scrollRef.current.scrollHeight <= scrollRef.current.clientHeight + 2 &&
      !infiniteScrollLoading &&
      !loading &&
      hasMore &&
      effectiveViewMode === "card"
    ) {
      handleLoadMore();
    }
  }, [data, useScroll, infiniteScrollLoading, loading, hasMore, effectiveViewMode, handleLoadMore]);

  return (
    <div className={`bg-ui-background-primary px-6 py-6 overflow-hidden pb-3 ${fitContent ? "" : "min-h-[800px]"} rounded-[10px] border border-[#E2E8F0]`}>
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div className="flex-1">
          <div className="flex flex-row items-center space-x-2">
            <div className="text-ui-text-primary text-xl font-bold">{title}</div>
            {tooltip && <InfoIcon position="bottom" tooltip={tooltip} />}
            {badge}
          </div>
          {subtitle && <div className="text-ui-text-secondary pr-6 text-sm font-normal max-w-[1000px] my-1">{subtitle}</div>}
        </div>
        <div className="flex items-center gap-2 flex-wrap lg:justify-end">
          {headerActions ? (
            <div className="flex items-center gap-2">{headerActions}</div>
          ) : null}
          {canChangeViewMode && (
            <div className="relative shrink-0" ref={settingsRef}>
              <button
                onClick={() => setShowSettings(prev => !prev)}
                className="flex flex-row space-x-2 items-center px-2 py-1 hover:bg-purple-50 text-brand-primary-main border-2 border-brand-primary-main font-bold text-sm rounded-md cursor-pointer transition-colors whitespace-nowrap"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  className="size-6"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={1.5}
                >
                  {/* lines */}
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M8.25 6.75h12 M8.25 12h12 M8.25 17.25h12"
                  />

                  {/* hollow dots (outlined) */}
                  <circle cx="3.75" cy="6.75" r="1.1" className="fill-none" />
                  <circle cx="3.75" cy="12" r="1.1" className="fill-none" />
                  <circle cx="3.75" cy="17.25" r="1.1" className="fill-none" />
                </svg>

                <span className="font-bold">View Settings</span>
              </button>
              {showSettings && (
                <div className="absolute right-0 z-50 mt-2 w-48 bg-ui-background-primary border border-ui-border-primary rounded shadow-sm">
                  {(["card", "table"] as const).map(mode => (
                    <button
                      key={mode}
                      onClick={() => {
                        setViewMode(mode);
                        setShowSettings(false);
                      }}
                      className={`block w-full text-left px-4 text-sm hover:bg-ui-background-muted flex flex-row items-center space-x-6 py-2 text-sm ${
                        effectiveViewMode === mode
                          ? "font-semibold text-brand-primary-main"
                          : ""
                      }`}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={1.5}
                        stroke="currentColor"
                        className={`size-5 ${effectiveViewMode === mode ? "opacity-100" : "opacity-0"}`}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="m4.5 12.75 6 6 9-13.5"
                        />
                      </svg>
                      {mode === "card" ? "Card View" : "Table View"}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {filters && <div className="flex items-center space-x-4 my-6">{filters}</div>}
      {fetchError ? (
        <div className="text-ui-text-error py-4">{fetchError}</div>
      ) : loading && data.length === 0 ? (
        <div>{effectiveViewMode === "card" ? <SkeletonCardGrid count={6} /> : <SkeletonTable rows={10} columns={7} />}</div>
      ) : data.length === 0 ? (
        <NoDataState title={emptyTitle} description={emptyDescription} actionButton={<></>} />
      ) : useScroll ? (
        <div
          id="scroll-container"
          ref={scrollRef}
          style={{ height: "600px", overflowY: "auto", overflowX: "visible", position: "relative" }}
        >
          {data.map((item, i) => (
            <div key={i}>{renderCard(item, i)}</div>
          ))}
          {(infiniteScrollLoading || loading) && (
            <>
              <p className="text-ui-text-muted text-sm text-center py-2">Loading more...</p>
              <div className="py-2">
                <SkeletonCardGrid count={1} />
              </div>
            </>
          )}
          {!hasMore && !infiniteScrollLoading && !loading && isOverflowing && (
            <p className="text-ui-text-muted text-sm text-center py-4">No more results</p>
          )}
        </div>
      ) : (
        <div>
          {effectiveViewMode === "card" ? data.map((item, i) => <div key={i}>{renderCard(item, i)}</div>) : renderTable(data)}
        </div>
      )}
    </div>
  );
}
