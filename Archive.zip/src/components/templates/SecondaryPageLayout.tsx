import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { Typography } from "@/components/atoms/Typography";
import { cn } from "@/lib/utils";

export type SecondaryPageBreadcrumb = {
  label: string;
  /** When provided, renders as a back/nav link. Omit for the current (non-link) crumb. */
  to?: string;
};

export type SecondaryPageLayoutProps = {
  /** Primary page heading. */
  title: ReactNode;
  /** Optional supporting text under the title. */
  description?: ReactNode;
  /**
   * Navigation crumbs above the title.
   * Prefer a single back-style crumb (e.g. "← SUMMARY") for drill-down pages.
   */
  breadcrumbs?: SecondaryPageBreadcrumb[];
  /** Right-side header actions (search, export, filters, custom buttons). */
  headerActions?: ReactNode;
  /** Optional toolbar / filters row below the header. */
  toolbar?: ReactNode;
  /** Main content (tables, charts, forms). */
  children: ReactNode;
  /** Optional side panel — reserved for future two-column layouts. */
  aside?: ReactNode;
  /** Extra content below the main/aside row. */
  footer?: ReactNode;
  /** Classes for the outer wrapper, including page-level padding and margins. */
  className?: string;
  /** Classes for the breadcrumbs area. */
  breadcrumbsClassName?: string;
  /** Classes for the title and header-actions row. */
  headerClassName?: string;
  /** Classes for the toolbar area. */
  toolbarClassName?: string;
  /** Classes for the main content/aside row. Useful for edge-to-edge tables. */
  contentClassName?: string;
  /** Classes for the main content slot. */
  mainClassName?: string;
  /** Classes for the optional side panel. */
  asideClassName?: string;
  /** Classes for the optional footer slot. */
  footerClassName?: string;
  /** Accessible label for the breadcrumb nav when breadcrumbs are present. */
  breadcrumbAriaLabel?: string;
};

/**
 * Reusable content shell for Manage (and similar) secondary / drill-down pages.
 * Owns page chrome only — title, breadcrumbs, actions, toolbar, and content slots.
 * Compose inside `StratiumRoutedPageLayout`, `ManageLayout`, or another app shell.
 */
export function SecondaryPageLayout({
  title,
  description,
  breadcrumbs,
  headerActions,
  toolbar,
  children,
  aside,
  footer,
  className,
  breadcrumbsClassName,
  headerClassName,
  toolbarClassName,
  contentClassName,
  mainClassName,
  asideClassName,
  footerClassName,
  breadcrumbAriaLabel = "Breadcrumb",
}: SecondaryPageLayoutProps) {
  const hasBreadcrumbs = Boolean(breadcrumbs?.length);

  return (
    <div className={cn("flex w-full min-w-0 flex-col gap-4", className)}>
      {hasBreadcrumbs ? (
        <nav aria-label={breadcrumbAriaLabel} className={cn("min-w-0", breadcrumbsClassName)}>
          <ol className="flex flex-wrap items-center gap-x-2 gap-y-1">
            {breadcrumbs!.map((crumb, index) => {
              const key = `${crumb.label}-${index}`;
              return (
                <li key={key} className="min-w-0">
                  {crumb.to ? (
                    <Link
                      to={crumb.to}
                      className="text-xs font-semibold uppercase tracking-wide text-ui-text-secondary transition-colors hover:text-brand-primary-main focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ui-border-focus"
                    >
                      {crumb.label}
                    </Link>
                  ) : (
                    <Typography as="span" variant="caption" color="secondary" className="font-semibold uppercase tracking-wide">
                      {crumb.label}
                    </Typography>
                  )}
                </li>
              );
            })}
          </ol>
        </nav>
      ) : null}

      <div className={cn("flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between", headerClassName)}>
        <div className="min-w-0 space-y-1">
          {typeof title === "string" || typeof title === "number" ? (
            <p className="text-2xl md:text-[48px] font-bold tracking-tight text-[#000000] md:text-[28px]">{title}</p>
          ) : (
            title
          )}
          {description != null && description !== "" ? (
            typeof description === "string" || typeof description === "number" ? (
              <Typography variant="body2" color="secondary">
                {description}
              </Typography>
            ) : (
              description
            )
          ) : null}
        </div>
        {headerActions ? (
          <div className="flex shrink-0 flex-wrap items-center gap-2 sm:justify-end pr-12">{headerActions}</div>
        ) : null}
      </div>

      {toolbar ? <div className={cn("min-w-0", toolbarClassName)}>{toolbar}</div> : null}

      <div
        className={cn(
          "min-w-0",
          aside ? "grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(240px,320px)]" : undefined,
          contentClassName
        )}
      >
        <div className={cn("min-w-0", mainClassName)}>{children}</div>
        {aside ? <aside className={cn("min-w-0", asideClassName)}>{aside}</aside> : null}
      </div>

      {footer ? <div className={cn("min-w-0", footerClassName)}>{footer}</div> : null}
    </div>
  );
}

export default SecondaryPageLayout;
