import React from "react";

interface CardLayoutProps {
  title?: string | React.ReactNode;
  subtitle?: React.ReactNode;
  icon?: React.ReactNode;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  topContent?: React.ReactNode;
}

const CardLayout: React.FC<CardLayoutProps> = ({
  title,
  subtitle,
  icon,
  actions,
  children,
  className = "",
  topContent,
  style,
}) => {
  const hasHeader = title || icon || actions;

  return (
    <div className={`bg-ui-background-primary border border-[#E2E8F0] rounded-[10px] p-6 ${className}`} style={style}>
      {topContent && topContent}
      {hasHeader && (
        <div className="flex items-start justify-between gap-4 mb-2 shrink-0">
          <div className="flex items-center space-x-2 min-w-0">
            {title &&
              (typeof title === "string" ? (
                <h2 className="text-xl font-bold text-color-heading">{title}</h2>
              ) : (
                title
              ))}
            {icon}
          </div>
          {actions}
        </div>
      )}
      {subtitle && <div className="text-sm text-ui-text-secondary mb-4 shrink-0">{subtitle}</div>}
      {children}
    </div>
  );
};

export default CardLayout;
