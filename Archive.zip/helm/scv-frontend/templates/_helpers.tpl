{{- define "scv-frontend.name" -}}
scv-frontend
{{- end }}

{{- define "scv-frontend.fullname" -}}
{{- if .Values.tenantCode -}}
{{- printf "%s-%s" (include "scv-frontend.name" .) .Values.tenantCode | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- include "scv-frontend.name" . -}}
{{- end -}}
{{- end }}

{{- define "scv-frontend.labels" -}}
app: {{ include "scv-frontend.name" . }}
app.kubernetes.io/name: {{ include "scv-frontend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Values.tenantCode }}
tenant: {{ .Values.tenantCode | quote }}
{{- end }}
{{- end }}

{{- define "scv-frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "scv-frontend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
