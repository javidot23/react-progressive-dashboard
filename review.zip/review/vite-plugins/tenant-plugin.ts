import type { Plugin, ResolvedConfig } from 'vite';
import {
  TENANT_CONFIGS,
  isValidTenant,
  type BuildableTenantId,
  type TenantBaseConfig,
} from '../src/tenant/config';

export interface TenantPluginOptions {
  defaultTenant?: BuildableTenantId;
  verbose?: boolean;
}

export function tenantPlugin(options: TenantPluginOptions = {}): Plugin {
  const { defaultTenant = 'stratium', verbose = false } = options;

  let tenant: BuildableTenantId;
  let config: TenantBaseConfig;
  let resolvedConfig: ResolvedConfig;

  return {
    name: 'vite-plugin-tenant',
    enforce: 'pre',

    config(_, { mode }) {
      const envTenant = process.env.VITE_TENANT || defaultTenant;

      if (!isValidTenant(envTenant)) {
        throw new Error(
          `Invalid VITE_TENANT: "${envTenant}". Valid values: ${Object.keys(TENANT_CONFIGS).join(', ')}`,
        );
      }

      tenant = envTenant;
      config = TENANT_CONFIGS[tenant];

      if (!process.env.VITE_APP_TITLE) {
        process.env.VITE_APP_TITLE = config.branding.title;
      }

      if (verbose) {
        console.warn(`\n[Tenant] Building for: ${config.displayName} (${tenant})`);
        console.warn(`  Mode:  ${mode}`);
        console.warn(`  Title: ${config.branding.title}`);
      }

      return {
        define: {
          __TENANT__: JSON.stringify(tenant),
          __TENANT_CONFIG__: JSON.stringify(config),
        },
      };
    },

    configResolved(resolved) {
      resolvedConfig = resolved;
    },

    buildStart() {
      console.warn(
        `\n[Build] ${config.displayName} | Tenant: ${tenant.toUpperCase()} | Title: ${config.branding.title}\n`,
      );
    },

    buildEnd() {
      console.warn(
        `\n[Build Complete] ${tenant.toUpperCase()} | Output: ${resolvedConfig.build.outDir}\n`,
      );
    },
  };
}

export function getTenantDefines(tenant: BuildableTenantId = 'stratium'): Record<string, string> {
  const config = TENANT_CONFIGS[tenant];
  return {
    __TENANT__: JSON.stringify(tenant),
    __TENANT_CONFIG__: JSON.stringify(config),
  };
}

export type { BuildableTenantId, TenantBaseConfig as TenantConfig };
export default tenantPlugin;
