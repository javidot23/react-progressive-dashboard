import type { Plugin } from "vite";
import { loadEnv } from "vite";

function originFromUrl(raw: string | undefined): string | undefined {
  if (!raw?.trim()) return undefined;
  try {
    return new URL(raw.trim()).origin;
  } catch {
    return undefined;
  }
}

function joinOrigins(origins: Array<string | undefined>): string {
  return [...new Set(origins.filter((o): o is string => Boolean(o)))].join(" ");
}

/**
 * Injects a baseline Content-Security-Policy meta tag on production HTML builds.
 * Dev server is unchanged so Vite HMR is not blocked.
 */
export function cspPlugin(mode: string): Plugin {
  return {
    name: "stratium-html-csp",
    transformIndexHtml: {
      order: "post",
      handler(html) {
        if (mode !== "production") {
          return html;
        }

        const env = loadEnv(mode, process.cwd(), "");
        const apiOrigin = originFromUrl(env.VITE_API_BASE_URL);
        const cdcDomain = originFromUrl(env.VITE_CDC_DOMAIN);

        const connectSrc = joinOrigins([
          "'self'",
          apiOrigin,
          cdcDomain,
          "https://bam.nr-data.net",
          "https://*.nr-data.net",
        ]);

        const frameSrc = joinOrigins(["'self'", cdcDomain]);

        const policy = [
          "default-src 'self'",
          "base-uri 'self'",
          "object-src 'none'",
          "frame-ancestors 'self'",
          `script-src 'self'`,
          "style-src 'self' 'unsafe-inline'",
          "img-src 'self' data: blob: https:",
          "font-src 'self' data:",
          `connect-src ${connectSrc}`,
          `frame-src ${frameSrc}`,
          "form-action 'self'",
          "upgrade-insecure-requests",
        ].join("; ");

        const tag = `<meta http-equiv="Content-Security-Policy" content="${policy}" />`;
        if (html.includes("Content-Security-Policy")) {
          return html;
        }
        return html.replace("<head>", `<head>\n    ${tag}`);
      },
    },
  };
}
