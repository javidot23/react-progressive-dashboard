import type { Plugin } from "vite";

/**
 * Injects `<link rel="preload" as="font">` tags for the primary brand fonts so
 * the browser fetches them in parallel with CSS instead of after first paint.
 *
 * - Dev: stable paths under /src/assets/fonts/
 * - Build: content-hashed filenames from the emitted bundle
 *
 * Only normal-weight woff2 faces are preloaded (patterns exclude italic variants).
 */
const BUILD_PATTERNS: RegExp[] = [
  /cencora-gilroy-medium-[^/]+\.woff2$/,
  /cencora-gilroy-semibold-[^/]+\.woff2$/,
  /cencora-gilroy-bold-[^/]+\.woff2$/,
];

const DEV_FONT_HREFS = [
  "/src/assets/fonts/cencora-gilroy-medium.woff2",
  "/src/assets/fonts/cencora-gilroy-semibold.woff2",
  "/src/assets/fonts/cencora-gilroy-bold.woff2",
];

export interface FontPreloadOptions {
  /** Override which emitted font assets get a preload link (build only). */
  patterns?: RegExp[];
  /** Override dev-server font paths. */
  devHrefs?: string[];
}

export function fontPreloadPlugin(options: FontPreloadOptions = {}): Plugin {
  const patterns = options.patterns ?? BUILD_PATTERNS;
  const devHrefs = options.devHrefs ?? DEV_FONT_HREFS;
  let base = "/";

  return {
    name: "stratium-font-preload",
    enforce: "post",
    configResolved(config) {
      base = config.base || "/";
    },
    transformIndexHtml: {
      order: "pre",
      handler(html, ctx) {
        const hrefs = ctx.bundle
          ? Object.keys(ctx.bundle)
              .filter((fileName) => patterns.some((pattern) => pattern.test(fileName)))
              .sort()
              .map((fileName) => `${base}${fileName}`)
          : devHrefs;

        if (!hrefs.length) {
          return html;
        }

        return {
          html,
          // crossorigin is required: CSS @font-face fetches use CORS-anonymous mode.
          tags: hrefs.map((href) => ({
            tag: "link",
            attrs: {
              rel: "preload",
              as: "font",
              type: "font/woff2",
              href,
              crossorigin: true,
            },
            injectTo: "head-prepend" as const,
          })),
        };
      },
    },
  };
}
