import { Meta, StoryObj } from "@storybook/react";
import { Typography } from "./Typography";

const meta: Meta<typeof Typography> = {
  title: "Atoms/Typography",
  component: Typography,
  tags: ["autodocs"],
  args: {
    children: "Typography text",
    variant: "body1",

    color: "primary",
  },
  argTypes: {
    children: {
      control: "text",
      description: "The text or React content rendered inside the component.",
      table: {
        type: { summary: "React.ReactNode" },
      },
    },
    variant: {
      control: "select",
      options: ["h1", "h2", "h3", "h4", "h5", "h6", "body1", "body2", "caption", "overline"],
      description:
        "Controls the visual typography style, including font size, weight, and spacing. It also determines the default HTML element when `as` is not provided.",
      table: {
        type: {
          summary: "'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'body1' | 'body2' | 'caption' | 'overline'",
        },
        defaultValue: { summary: "body1" },
      },
    },
    color: {
      control: "select",
      options: ["primary", "secondary", "muted", "accent", "destructive"],
      description: "Applies a theme-aware text color.",
      table: {
        type: {
          summary: "'primary' | 'secondary' | 'muted' | 'accent' | 'destructive'",
        },
        defaultValue: { summary: "primary" },
      },
    },
    as: {
      control: "select",
      options: ["h1", "h2", "h3", "h4", "h5", "h6", "p", "span", "div", "section"],
      description:
        "Overrides the rendered HTML element without changing the visual style selected by `variant`. Use this to preserve correct document semantics.",
      table: {
        type: { summary: "keyof React.JSX.IntrinsicElements" },
        defaultValue: { summary: "Determined by variant" },
      },
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          "A flexible typography component that applies consistent text styles, semantic HTML elements, and theme-aware colors across the application. Choose a visual variant independently from the rendered element using the `variant` and `as` properties.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {};

export const Secondary: Story = {
  args: {
    color: "secondary",
  },
};

export const Muted: Story = {
  args: {
    color: "muted",
  },
};

export const Accent: Story = {
  args: {
    color: "accent",
  },
};

export const Destructive: Story = {
  args: {
    color: "destructive",
  },
};

export const H1: Story = {
  args: {
    variant: "h1",
  },
};

export const H2: Story = {
  args: {
    variant: "h2",
  },
};

export const H3: Story = {
  args: {
    variant: "h3",
  },
};

export const H4: Story = {
  args: {
    variant: "h4",
  },
};

export const H5: Story = {
  args: {
    variant: "h5",
  },
};

export const H6: Story = {
  args: {
    variant: "h6",
  },
};

export const Body1: Story = {
  args: {
    variant: "body1",
  },
};

export const Body2: Story = {
  args: {
    variant: "body2",
  },
};

export const Caption: Story = {
  args: {
    variant: "caption",
  },
};

export const Overline: Story = {
  args: {
    variant: "overline",
  },
};

export const AllVariants: Story = {
  render: () => (
    <div className="space-y-4">
      <Typography variant="h1">Heading 1</Typography>
      <Typography variant="h2">Heading 2</Typography>
      <Typography variant="h3">Heading 3</Typography>
      <Typography variant="h4">Heading 4</Typography>
      <Typography variant="h5">Heading 5</Typography>
      <Typography variant="h6">Heading 6</Typography>
      <Typography variant="body1">Body 1 text</Typography>
      <Typography variant="body2">Body 2 text</Typography>
      <Typography variant="caption">Caption text</Typography>
      <Typography variant="overline">Overline text</Typography>
    </div>
  ),
};

export const AllColors: Story = {
  render: () => (
    <div className="space-y-2">
      <Typography color="primary">Primary text</Typography>
      <Typography color="secondary">Secondary text</Typography>
      <Typography color="muted">Muted text</Typography>
      <Typography color="accent">Accent text</Typography>
      <Typography color="destructive">Destructive text</Typography>
    </div>
  ),
};

export const SemanticOverride: Story = {
  args: {
    variant: "h2",
    as: "p",
    children: "Visually an H2, semantically a paragraph",
  },
  parameters: {
    docs: {
      description: {
        story: "The `as` property changes the rendered HTML element without changing the selected visual style.",
      },
    },
  },
};

export const LongFormText: Story = {
  args: {
    variant: "body1",
    children: "Typography should remain readable when content spans multiple lines and adapts to the available width.",
  },
  decorators: [
    Story => (
      <div className="max-w-md">
        <Story />
      </div>
    ),
  ],
};
