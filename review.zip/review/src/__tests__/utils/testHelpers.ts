import { act, waitFor } from '@testing-library/react';

/**
 * Test helper utilities for overview page testing
 */

// Test suite to prevent "no tests" error
describe('Test Helpers', () => {
  it('should export helper functions', () => {
    expect(typeof waitForLoadingToFinish).toBe('function');
    expect(typeof validateVendorData).toBe('function');
    expect(typeof validateProductData).toBe('function');
  });
});

// Async utilities
export const waitForLoadingToFinish = async () => {
  await waitFor(() => {
    expect(document.querySelector('[data-testid="spinner"]')).not.toBeInTheDocument();
  }, { timeout: 5000 });
};

export const waitForErrorToAppear = async (errorMessage: string) => {
  await waitFor(() => {
    expect(document.body).toHaveTextContent(errorMessage);
  }, { timeout: 3000 });
};

// Mock data validation helpers
export const validateVendorData = (vendor: any) => {
  expect(vendor).toHaveProperty('id');
  expect(vendor).toHaveProperty('name');
  expect(vendor).toHaveProperty('vendorNbr');
  expect(vendor).toHaveProperty('riskRating');
  expect(vendor).toHaveProperty('drivingRisk');

  expect(typeof vendor.id).toBe('number');
  expect(typeof vendor.name).toBe('string');
  expect(typeof vendor.vendorNbr).toBe('string');
  expect(typeof vendor.riskRating).toBe('number');
  expect(typeof vendor.drivingRisk).toBe('string');

  expect(vendor.riskRating).toBeGreaterThanOrEqual(0);
  expect(vendor.riskRating).toBeLessThanOrEqual(1);
  expect(vendor.name.length).toBeGreaterThan(0);
};

export const validateProductData = (product: any) => {
  expect(product).toHaveProperty('id');
  expect(product).toHaveProperty('name');
  expect(product).toHaveProperty('matNbr');
  expect(product).toHaveProperty('riskRating');
  expect(product).toHaveProperty('drivingRisk');

  expect(typeof product.id).toBe('number');
  expect(typeof product.name).toBe('string');
  expect(typeof product.matNbr).toBe('string');
  expect(typeof product.riskRating).toBe('number');
  expect(typeof product.drivingRisk).toBe('string');

  expect(product.riskRating).toBeGreaterThanOrEqual(0);
  expect(product.riskRating).toBeLessThanOrEqual(1);
  expect(product.name.length).toBeGreaterThan(0);
  expect(product.matNbr).toMatch(/^MAT\d+$/);
};

export const validateServiceLevelData = (dataPoint: any) => {
  expect(dataPoint).toHaveProperty('month');
  expect(dataPoint).toHaveProperty('serviceLevel');
  expect(dataPoint).toHaveProperty('goal');
  expect(dataPoint).toHaveProperty('highImpact');
  expect(dataPoint).toHaveProperty('mediumImpact');

  expect(typeof dataPoint.month).toBe('string');
  expect(typeof dataPoint.serviceLevel).toBe('number');
  expect(typeof dataPoint.goal).toBe('number');
  expect(typeof dataPoint.highImpact).toBe('number');
  expect(typeof dataPoint.mediumImpact).toBe('number');

  expect(dataPoint.serviceLevel).toBeGreaterThanOrEqual(0);
  expect(dataPoint.serviceLevel).toBeLessThanOrEqual(100);
  expect(dataPoint.goal).toBeGreaterThanOrEqual(0);
  expect(dataPoint.goal).toBeLessThanOrEqual(100);
};

// Risk level calculation helpers
export const calculateRiskLevel = (riskRating: number): 'Critical' | 'High' | 'Medium' | 'Watch' => {
  if (riskRating >= 0.9) return 'Critical';
  if (riskRating >= 0.8) return 'High';
  if (riskRating >= 0.6) return 'Medium';
  return 'Watch';
};

export const validateRiskLevelCalculation = (riskRating: number, expectedLevel: string) => {
  const calculatedLevel = calculateRiskLevel(riskRating);
  expect(calculatedLevel).toBe(expectedLevel);
};

// Component testing helpers
export const expectComponentToBeRendered = (testId: string) => {
  const element = document.querySelector(`[data-testid="${testId}"]`);
  expect(element).toBeInTheDocument();
};

export const expectComponentNotToBeRendered = (testId: string) => {
  const element = document.querySelector(`[data-testid="${testId}"]`);
  expect(element).not.toBeInTheDocument();
};

export const expectTextToBeVisible = (text: string) => {
  expect(document.body).toHaveTextContent(text);
};

export const expectTextNotToBeVisible = (text: string) => {
  expect(document.body).not.toHaveTextContent(text);
};

// API testing helpers
export const mockApiSuccess = (data: any) => ({
  status: 200,
  data: { data },
});

export const mockApiError = (message: string, status = 500) => {
  const error = new Error(message) as any;
  error.response = {
    status,
    data: { error: message },
  };
  return error;
};

// Store testing helpers
export const createMockStore = (overrides = {}) => ({
  topRiskiestVendors: [],
  criticalProducts: [],
  loading: {
    topRiskiestVendors: false,
    criticalProducts: false,
  },
  errors: {
    criticalProducts: null,
  },
  ...overrides,
});

export const createLoadingStore = (loadingKeys: string[] = []) => {
  const loading: Record<string, boolean> = {};
  loadingKeys.forEach(key => {
    loading[key] = true;
  });

  return createMockStore({
    loading: {
      topRiskiestVendors: false,
      criticalProducts: false,
      ...loading,
    },
  });
};

export const createErrorStore = (errorKey: string, errorMessage: string) => {
  const errors: Record<string, string | null> = {
    criticalProducts: null,
  };
  errors[errorKey] = errorMessage;

  return createMockStore({
    errors,
  });
};

// Performance testing helpers
export const measureRenderTime = async (renderFn: () => void): Promise<number> => {
  const startTime = performance.now();

  await act(async () => {
    renderFn();
  });

  const endTime = performance.now();
  return endTime - startTime;
};

// Accessibility testing helpers
export const checkAccessibilityRequirements = (container: HTMLElement) => {
  // Check for proper heading structure
  const headings = container.querySelectorAll('h1, h2, h3, h4, h5, h6');
  expect(headings.length).toBeGreaterThan(0);

  // Check for proper button accessibility
  const buttons = container.querySelectorAll('button');
  buttons.forEach(button => {
    expect(button).toBeEnabled();
    expect(button).toHaveAttribute('type');
  });

  // Check for proper link accessibility
  const links = container.querySelectorAll('a');
  links.forEach(link => {
    expect(link).toHaveAttribute('href');
  });
};

// Environment testing helpers
export const mockEnvironmentVariable = (key: string, value: string) => {
  const originalEnv = process.env[key];
  process.env[key] = value;

  return () => {
    if (originalEnv !== undefined) {
      process.env[key] = originalEnv;
    } else {
      delete process.env[key];
    }
  };
};

// Test data generators with realistic values
export const generateRealisticVendor = (id: number) => ({
  id,
  name: `Manufacturing Company ${id}`,
  vendorNbr: `VEN${String(id).padStart(3, '0')}`,
  riskRating: Math.random() * 0.4 + 0.6, // Between 0.6 and 1.0
  drivingRisk: [
    'Supply chain disruption',
    'Financial instability',
    'Regulatory compliance issues',
    'Quality control problems',
    'Geopolitical risks',
  ][id % 5],
});

export const generateRealisticProduct = (id: number) => ({
  id,
  name: `Critical Product ${id}`,
  matNbr: `MAT${String(id).padStart(3, '0')}`,
  riskRating: Math.random() * 0.4 + 0.5, // Between 0.5 and 0.9
  drivingRisk: [
    'Single source supplier',
    'High demand volatility',
    'Long lead times',
    'Quality issues',
    'Regulatory changes',
  ][id % 5],
});

// Cleanup helpers
export const cleanupTestEnvironment = () => {
  localStorage.clear();
  sessionStorage.clear();
  jest.clearAllMocks();
};
