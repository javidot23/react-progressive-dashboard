import React from "react";
import { render, RenderOptions } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter } from "react-router-dom";
import { testBaseURL } from "@/__tests__/mocks/testBaseURL";

// Create a custom render function that includes providers
const AllTheProviders = ({ children }: { children: React.ReactNode }) => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: 0,
      },
      mutations: {
        retry: false,
      },
    },
  });

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>{children}</BrowserRouter>
    </QueryClientProvider>
  );
};

const customRender = (ui: React.ReactElement, options?: Omit<RenderOptions, "wrapper">) =>
  render(ui, { wrapper: AllTheProviders, ...options });

// Mock environment variables for tests
export const mockEnv = {
  VITE_API_BASE_URL: testBaseURL,
  DEV: false,
  PROD: true,
};

// Helper to mock API responses
export const createMockApiResponse = <T,>(data: T, delay = 0) => {
  return new Promise<T>(resolve => {
    setTimeout(() => resolve(data), delay);
  });
};

// Helper to create mock error responses
export const createMockApiError = (message: string, status = 500) => {
  const error = new Error(message) as any;
  error.response = {
    status,
    data: { error: message },
  };
  return Promise.reject(error);
};

// Mock data generators
export const generateMockStatCard = (overrides = {}) => ({
  id: 1,
  title: "Test Stat",
  value: "100",
  change: "+5%",
  changeType: "increase" as const,
  icon: "test-icon",
  ...overrides,
});

export const generateMockVendor = (overrides = {}) => ({
  id: 1,
  name: "Test Vendor",
  vendorNbr: "VEN001",
  riskRating: 0.85,
  drivingRisk: "Supply disruption",
  ...overrides,
});

export const generateMockProduct = (overrides = {}) => ({
  id: 1,
  name: "Test Product",
  matNbr: "MAT001",
  riskRating: 0.75,
  drivingRisk: "High demand volatility",
  ...overrides,
});

export const generateMockServiceLevelData = (overrides = {}) => ({
  month: "Jan 2024",
  serviceLevel: 95,
  goal: 98,
  highImpact: 1200,
  mediumImpact: 800,
  ...overrides,
});

export const generateMockOTIFData = (overrides = {}) => ({
  thisWeekOtif: 0.925,
  lastWeekOtif: 0.9,
  chartData: [
    { week: "Week 1", onTime: 85, inFull: 95 },
    { week: "Week 2", onTime: 90, inFull: 92 },
  ],
  ...overrides,
});

// Test suite to prevent "no tests" error
describe("Test Utils", () => {
  it("should provide custom render function", () => {
    expect(typeof customRender).toBe("function");
  });
});

// Re-export everything from testing-library
export * from "@testing-library/react";

// Override the default render method
export { customRender as render };
