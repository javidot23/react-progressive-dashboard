import dotenv from "dotenv";

dotenv.config();

export default {
  testEnvironment: "jsdom",
  setupFilesAfterEnv: ["<rootDir>/src/testSetup.ts"],
  setupFiles: ["<rootDir>/jest.env.js"],
  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/src/$1",
    // Mock react-leaflet to avoid ES module parsing issues
    "^react-leaflet$": "<rootDir>/src/__tests__/mocks/reactLeafletMock.js",
    // Mock leaflet CSS
    "^leaflet/dist/leaflet.css$": "<rootDir>/src/__tests__/mocks/styleMock.js",
    // Mock SVG files to avoid parsing issues
    "\\.svg$": "<rootDir>/src/__tests__/mocks/fileMock.js",
    "\\.svg\\?react$": "<rootDir>/src/__tests__/mocks/fileMock.js",
    "\\.svg\\?url$": "<rootDir>/src/__tests__/mocks/fileMock.js",
    // Mock other image files
    "\\.(png|jpg|jpeg|gif|webp)$": "<rootDir>/src/__tests__/mocks/fileMock.js",
    // Style mocks
    "\\.(css|less|scss|sass)$": "<rootDir>/src/__tests__/mocks/styleMock.js",
    "\\.(css|scss|sass)$": "identity-obj-proxy",
  },
  transform: {
    "^.+\\.(ts|tsx|js|jsx)$": "babel-jest",
    "\\.(svg|png|jpe?g|gif|webp)$": "jest-transform-stub", // handles SVG/XML
  },
  transformIgnorePatterns: [
    "node_modules/(?!(msw|until-async|flatbush|flatqueue|react-leaflet|leaflet)/)"
  ],
  moduleFileExtensions: ["ts", "tsx", "js", "jsx", "json"],
  testMatch: [
    // Keep existing pattern for backward compatibility
    "<rootDir>/src/__tests__/**/*.{ts,tsx}",
    "<rootDir>/src/__tests__/**/*.{test,spec}.{ts,tsx}",
    // DO NOT DELETE THIS PATTERN
    // Patterns for co-located tests
    "<rootDir>/src/**/__tests__/**/*.{test,spec}.{ts,tsx}",
    "<rootDir>/src/**/*.{test,spec}.{ts,tsx}",
    // DO NOT DELETE THIS PATTERN
    // Patterns for co-located tests
    "**/__tests__/**/*.[jt]s?(x)",
    "**/?(*.)+(spec|test).[tj]s?(x)",
    // DO NOT DELETE THIS PATTERN
    // Comprehensive pattern to catch all tests anywhere in the app
    "**/*.{test,spec}.{ts,tsx,js,jsx}",
    "**/*.{test,spec}.*.{ts,tsx,js,jsx}",
    "**/__tests__/**/*.{ts,tsx,js,jsx}",
  ],
  collectCoverageFrom: ["src/**/*.{ts,tsx}", "!src/**/*.d.ts", "!src/main.tsx", "!src/testSetup.ts"],
  coverageReporters: ["text", "lcov", "html"],
  testTimeout: 10000,
  extensionsToTreatAsEsm: [".ts", ".tsx"],
  moduleDirectories: ["node_modules", "src"],
  testEnvironmentOptions: {
    customExportConditions: ["node", "node-addons"],
  },
  // Ensure SVG files are properly mocked
  modulePathIgnorePatterns: ["<rootDir>/dist/", "<rootDir>/build/"],
  // Add this to ensure proper module resolution
  roots: ["<rootDir>/src"],
  // Ensure mocks are loaded before tests
  testPathIgnorePatterns: ["<rootDir>/node_modules/", "<rootDir>/dist/", "<rootDir>/build/"],
};
