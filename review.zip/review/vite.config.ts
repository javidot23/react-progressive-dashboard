import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import packageJson from "./package.json";
import path from "path";
import { visualizer } from "rollup-plugin-visualizer";
import { cspPlugin, fontPreloadPlugin, tenantPlugin } from "./vite-plugins";

/** Vendor splits for long-term caching and smaller initial route chunks. */
function manualChunks(id: string): string | undefined {
  if (!id.includes("node_modules")) {
    return undefined;
  }

  if (id.includes("@newrelic/")) {
    return "telemetry";
  }

  if (
    id.includes("/leaflet/") ||
    id.includes("\\leaflet\\") ||
    id.includes("react-leaflet")
  ) {
    return "leaflet";
  }

  if (id.includes("recharts")) {
    return "charts";
  }

  if (id.includes("@tanstack/react-query")) {
    return "react-query";
  }

  if (
    id.includes("/react/") ||
    id.includes("\\react\\") ||
    id.includes("/react-dom/") ||
    id.includes("\\react-dom\\") ||
    id.includes("react-router") ||
    id.includes("/scheduler/")
  ) {
    return "react-vendor";
  }

  return undefined;
}

export default defineConfig(({ mode }) => ({
  plugins: [
    react(),
    tailwindcss(),
    fontPreloadPlugin(),
    tenantPlugin({ verbose: true }),
    cspPlugin(mode),
    ...(process.env.ANALYZE
      ? [
          visualizer({
            filename: "dist/stats.html",
            gzipSize: true,
            brotliSize: true,
            template: "treemap",
          }),
        ]
      : []),
  ],
  define: {
    __BUILD_DATE__: JSON.stringify(new Date().toISOString()),
    __APP_VERSION__: JSON.stringify(process.env.VITE_APP_VERSION || packageJson.version),
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
      "@/components": path.resolve(__dirname, "./src/components"),
      "@/lib": path.resolve(__dirname, "./src/lib"),
      "@/hooks": path.resolve(__dirname, "./src/hooks"),
      "@/pages": path.resolve(__dirname, "./src/pages"),
    },
  },
  esbuild:
    mode === "production"
      ? {
          drop: ["debugger"],
          pure: ["console.log", "console.debug", "console.info"],
        }
      : {},
  build: {
    rollupOptions: {
      output: {
        manualChunks,
      },
    },
  },
}));
