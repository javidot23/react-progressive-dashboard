const fs = require("fs");
const path = require("path");

// Function to update MSW syntax in a file
function updateMSWSyntax(filePath) {
  let content = fs.readFileSync(filePath, "utf8");

  // Update imports
  content = content.replace(
    /import\s*{\s*rest\s*}\s*from\s*["']msw["']/g,
    'import {http, HttpResponse} from "msw"'
  );

  // Update rest.get calls
  content = content.replace(
    /rest\.get\("([^"]+)",\s*\([^)]*\)\s*=>\s*\{\s*return\s*res\(\s*ctx\.json\(([^)]+)\)\s*\)\s*;\s*\}/g,
    'http.get("$1", () => { return HttpResponse.json($2); })'
  );

  // Update rest.get calls with delay
  content = content.replace(
    /rest\.get\("([^"]+)",\s*\([^)]*\)\s*=>\s*\{\s*return\s*res\(\s*ctx\.delay\([^)]+\),\s*ctx\.json\(([^)]+)\)\s*\)\s*;\s*\}/g,
    'http.get("$1", () => { return HttpResponse.json($2); })'
  );

  // Update rest.get calls with status
  content = content.replace(
    /rest\.get\("([^"]+)",\s*\([^)]*\)\s*=>\s*\{\s*return\s*res\(\s*ctx\.status\(([^)]+)\)\s*\)\s*;\s*\}/g,
    'http.get("$1", () => { return HttpResponse.json({}, { status: $2 }); })'
  );

  // Update rest.get calls with network error
  content = content.replace(
    /rest\.get\("([^"]+)",\s*\([^)]*\)\s*=>\s*\{\s*return\s*res\.networkError\([^)]+\)\s*;\s*\}/g,
    'http.get("$1", () => { return HttpResponse.error(); })'
  );

  // Update rest.all calls
  content = content.replace(
    /rest\.all\("([^"]+)",\s*\([^)]*\)\s*=>\s*\{\s*return\s*res\(\s*ctx\.status\(([^)]+)\),\s*ctx\.json\(([^)]+)\)\s*\)\s*;\s*\}/g,
    'http.all("$1", () => { return HttpResponse.json($3, { status: $2 }); })'
  );

  fs.writeFileSync(filePath, content);
  console.warn(`Updated: ${filePath}`);
}

// Test files to update
const testFiles = [
  "src/components/manage/supply/__tests__/PurchaseOrderHistory.test.tsx",
  "src/components/manage/supply/__tests__/PurchaseOrderHistory.integration.test.tsx",
  "src/components/manage/supply/__tests__/PurchaseOrderStatus.test.tsx",
  "src/components/manage/supply/__tests__/PurchaseOrderStatus.integration.test.tsx",
];

// Update each file
testFiles.forEach(file => {
  if (fs.existsSync(file)) {
    updateMSWSyntax(file);
  } else {
    console.warn(`File not found: ${file}`);
  }
});

console.warn("MSW syntax update complete!");
